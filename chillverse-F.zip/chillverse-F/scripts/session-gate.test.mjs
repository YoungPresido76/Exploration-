// Exercises the session-limit decision logic against the exact scenarios
// from the bug report. Run: node scripts/session-gate.test.mjs
//
// This models the three independent layers that now have to all agree
// before a run can bank XP:
//   1. launchGame()  — fresh server read at the moment of the tap
//   2. try_consume_session — server refuses rather than over-incrementing
//   3. authorizedGame ref — a result from an uncleared run is discarded

let pass = 0, fail = 0
function check(name, actual, expected) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected)
  console.log(`${ok ? '  PASS' : '  FAIL'}  ${name}${ok ? '' : `\n        expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`}`)
  ok ? pass++ : fail++
}

// ── Layer 2: the SQL routine, transcribed from migration 0105 ──────────
function tryConsumeSession(row, by, limit, cooldownHours, now = Date.now(), today = 'D1') {
  const safeBy = Math.max(by ?? 1, 1)
  const safeLimit = Math.max(limit ?? 15, 1)
  let { count, resetAt } = row

  if (row.lastDate !== today) { count = 0; resetAt = null }
  else if (resetAt !== null && resetAt <= now) { count = 0; resetAt = null }

  if (count + safeBy > safeLimit) {
    return { allowed: false, count, resetAt, limitReached: count >= safeLimit }
  }
  count += safeBy
  if (count >= safeLimit && resetAt === null) resetAt = now + cooldownHours * 3600_000
  return { allowed: true, count, resetAt, limitReached: count >= safeLimit }
}

// ── Layer 1: launchGame's decision ────────────────────────────────────
function canLaunch({ info, plays, cost, limit, maxPlays, unlimitedPlays, requiresPro, isPro }) {
  if (requiresPro && !isPro) return 'pro'
  if (!info.ok) return 'unverified'
  if (info.count + cost > limit) return 'no-sessions'
  if (!unlimitedPlays && plays >= maxPlays) return 'daily-max'
  return 'launch'
}

const LIMIT = 15, MAX_PLAYS = 7

console.log('\nLayer 1 — launch gate')

// The reported bug: session limit reached, player taps a game and hits Play.
check('limit reached, 1-cost game refuses',
  canLaunch({ info: { ok: true, count: 15 }, plays: 0, cost: 1, limit: LIMIT, maxPlays: MAX_PLAYS }),
  'no-sessions')

// The race itself: the OLD code read count=0 because the fetch hadn't landed.
// The new code never reads state here — it reads the server — so the count it
// sees is the real one regardless of how fast the tap was.
check('tap before load still sees real server count',
  canLaunch({ info: { ok: true, count: 15 }, plays: 0, cost: 1, limit: LIMIT, maxPlays: MAX_PLAYS }),
  'no-sessions')

// Partial allowance vs an expensive game (Trivia Clash costs 6).
check('4 left, 6-cost game refuses',
  canLaunch({ info: { ok: true, count: 11 }, plays: 0, cost: 6, limit: LIMIT, maxPlays: MAX_PLAYS }),
  'no-sessions')
check('exactly enough for a 6-cost game launches',
  canLaunch({ info: { ok: true, count: 9 }, plays: 0, cost: 6, limit: LIMIT, maxPlays: MAX_PLAYS }),
  'launch')

// A failed read must not read as a full allowance.
check('failed session read refuses rather than assuming zero used',
  canLaunch({ info: { ok: false, count: 0 }, plays: 0, cost: 1, limit: LIMIT, maxPlays: MAX_PLAYS }),
  'unverified')

check('daily per-game cap refuses even with sessions left',
  canLaunch({ info: { ok: true, count: 0 }, plays: 7, cost: 1, limit: LIMIT, maxPlays: MAX_PLAYS }),
  'daily-max')
check('unlimitedPlays game ignores the daily cap',
  canLaunch({ info: { ok: true, count: 0 }, plays: 99, cost: 1, limit: LIMIT, maxPlays: MAX_PLAYS, unlimitedPlays: true }),
  'launch')

console.log('\nLayer 1 — Pro gate (Uno / Colour Block)')
check('free user refused a Pro game',
  canLaunch({ info: { ok: true, count: 0 }, plays: 0, cost: 4, limit: LIMIT, maxPlays: MAX_PLAYS, requiresPro: true, isPro: false }),
  'pro')
check('subscriber allowed into a Pro game',
  canLaunch({ info: { ok: true, count: 0 }, plays: 0, cost: 4, limit: LIMIT, maxPlays: MAX_PLAYS, requiresPro: true, isPro: true }),
  'launch')
check('Pro check runs before the session check',
  canLaunch({ info: { ok: true, count: 15 }, plays: 0, cost: 4, limit: LIMIT, maxPlays: MAX_PLAYS, requiresPro: true, isPro: false }),
  'pro')

console.log('\nLayer 2 — server consume')
const spent = { count: 15, resetAt: null, lastDate: 'D1' }
check('refuses at the cap and leaves the counter untouched',
  tryConsumeSession(spent, 1, LIMIT, 4.5),
  { allowed: false, count: 15, resetAt: null, limitReached: true })

check('refuses a 6-cost game with 4 left, no partial spend',
  tryConsumeSession({ count: 11, resetAt: null, lastDate: 'D1' }, 6, LIMIT, 4.5),
  { allowed: false, count: 11, resetAt: null, limitReached: false })

const r = tryConsumeSession({ count: 9, resetAt: null, lastDate: 'D1' }, 6, LIMIT, 4.5, 1000)
check('consuming the last of the allowance starts the cooldown',
  { allowed: r.allowed, count: r.count, cooldownSet: r.resetAt !== null },
  { allowed: true, count: 15, cooldownSet: true })

check('negative cost cannot be used to refund the counter',
  tryConsumeSession({ count: 10, resetAt: null, lastDate: 'D1' }, -5, LIMIT, 4.5).count,
  11)

check('client cannot raise its own cap below the free tier',
  tryConsumeSession({ count: 15, resetAt: null, lastDate: 'D1' }, 1, 0, 4.5).allowed,
  false)

check('new day restores the allowance',
  tryConsumeSession({ count: 15, resetAt: null, lastDate: 'D0' }, 1, LIMIT, 4.5).allowed,
  true)

check('elapsed cooldown restores the allowance',
  tryConsumeSession({ count: 15, resetAt: 500, lastDate: 'D1' }, 1, LIMIT, 4.5, 1000).allowed,
  true)

check('unelapsed cooldown still refuses',
  tryConsumeSession({ count: 15, resetAt: 5000, lastDate: 'D1' }, 1, LIMIT, 4.5, 1000).allowed,
  false)

console.log('\nLayer 2 — replay loop from the result screen')
// "Play Again" stays inside the game component and never re-enters
// launchGame, so the server is the only thing standing between a spent
// player and unlimited replays.
let row = { count: 12, resetAt: null, lastDate: 'D1' }
const replayResults = []
for (let i = 0; i < 5; i++) {
  const res = tryConsumeSession(row, 1, LIMIT, 4.5, 1000)
  replayResults.push(res.allowed)
  if (res.allowed) row = { count: res.count, resetAt: res.resetAt, lastDate: 'D1' }
}
check('replays stop dead once the allowance is gone',
  replayResults, [true, true, true, false, false])

console.log('\nLayer 3 — result authorization')
function banksResult(authorizedGame, payloadGameId, consumed) {
  if (authorizedGame !== payloadGameId) return false      // never launched through the gate
  if (consumed && !consumed.allowed) return false          // allowance died mid-run
  return true
}
check('unauthorized run banks nothing', banksResult(null, 'uno', { allowed: true }), false)
check('run of a different game banks nothing', banksResult('tac-zone', 'uno', { allowed: true }), false)
check('authorized run refused by the server banks nothing',
  banksResult('uno', 'uno', { allowed: false }), false)
check('authorized run with room banks normally',
  banksResult('uno', 'uno', { allowed: true }), true)
check('unreachable server does not discard a cleared run',
  banksResult('uno', 'uno', null), true)

console.log(`\n${pass} passed, ${fail} failed\n`)
process.exit(fail === 0 ? 0 : 1)
