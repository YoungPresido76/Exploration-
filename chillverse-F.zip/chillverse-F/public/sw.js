// public/sw.js
//
// Service worker for Chillverse Web Push notifications + offline caching.
// Registered by src/features/notifications/push.ts.

const CACHE_NAME = 'chillverse-shell-v1'
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/dashboard',
  '/favicon.svg',
  '/favicon.ico',
  '/favicon-96x96.png',
  '/apple-touch-icon.png',
  '/web-app-manifest-192x192.png',
  '/web-app-manifest-512x512.png',
]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  )
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      caches.keys().then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
      ),
      self.clients.claim(),
    ])
  )
})

/* ── FETCH / OFFLINE CACHE ─────────────────────────────────────── */

self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)

  // Skip non-GET, Supabase API, and realtime/WebSocket traffic
  if (request.method !== 'GET') return
  if (url.pathname.includes('/rest/v1/')) return
  if (url.pathname.includes('/realtime/')) return
  if (url.pathname.includes('/auth/v1/')) return
  if (request.headers.get('accept')?.includes('text/event-stream')) return

  // 1) Static assets (JS, CSS, images, fonts): Cache First
  if (
    url.pathname.match(/\.(js|css|png|jpg|jpeg|svg|woff|woff2|ico|webmanifest)$/) ||
    url.origin !== self.location.origin
  ) {
    event.respondWith(
      caches.match(request).then((cached) => {
        return (
          cached ||
          fetch(request).then((response) => {
            if (url.origin === self.location.origin && response.ok) {
              const clone = response.clone()
              caches.open(CACHE_NAME).then((cache) => cache.put(request, clone))
            }
            return response
          })
        )
      })
    )
    return
  }

  // 2) HTML navigations (routes): Network First, fallback to cached shell
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const clone = response.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone))
          return response
        })
        .catch(() => {
          return caches.match(request).then((cached) => {
            if (cached) return cached
            return caches.match('/index.html')
          })
        })
    )
    return
  }

  // 3) Everything else: Stale While Revalidate
  event.respondWith(
    caches.match(request).then((cached) => {
      const fetchPromise = fetch(request).then((response) => {
        if (response.ok) {
          const clone = response.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone))
        }
        return response
      })
      return cached || fetchPromise
    })
  )
})

/* ── PUSH NOTIFICATIONS (existing) ─────────────────────────────── */

async function hasVisibleChillverseTab() {
  const clientList = await self.clients.matchAll({
    type: 'window',
    includeUncontrolled: true,
  })
  return clientList.some((client) => client.visibilityState === 'visible')
}

self.addEventListener('push', (event) => {
  if (!event.data) return

  let payload
  try {
    payload = event.data.json()
  } catch {
    payload = { title: 'Chillverse', body: event.data.text() }
  }

  event.waitUntil(
    (async () => {
      const alreadyVisible = await hasVisibleChillverseTab()
      if (alreadyVisible) return

      const title = payload.title || 'Chillverse'
      const options = {
        body: payload.body || '',
        icon: payload.icon || '/web-app-manifest-192x192.png',
        badge: payload.badge || '/favicon-96x96.png',
        tag: payload.tag || 'chillverse-notification',
        renotify: true,
        data: payload.data || {},
      }

      await self.registration.showNotification(title, options)
    })()
  )
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const targetUrl = (event.notification.data && event.notification.data.url) || '/notifications'

  event.waitUntil(
    self.clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        for (const client of clientList) {
          const clientUrl = new URL(client.url)
          if (clientUrl.origin === self.location.origin && 'focus' in client) {
            client.navigate(targetUrl)
            return client.focus()
          }
        }
        if (self.clients.openWindow) {
          return self.clients.openWindow(targetUrl)
        }
      })
  )
})
