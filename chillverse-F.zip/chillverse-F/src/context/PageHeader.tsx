// src/context/PageHeader.tsx
//
// Single source of truth for the app Topbar's title/back-button, so every
// sub-page registers its header here instead of rendering its own title +
// back row inline. Fixes the "two headers stacked on top of each other"
// pattern (Community, Notifications, Settings sub-pages, Games category
// drill-down, etc.) by giving every page one place to say what the top bar
// should show, including pages whose title is dynamic (a club name, a
// player's display name, a game category label) or whose "page" is really
// an in-component view switch that never changes the URL.
//
// AppLayout reads from here first and falls back to the static ROUTE_TITLES
// map for any route that hasn't been migrated yet — see AppLayout.tsx.
import { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react'
import type { ReactNode } from 'react'

export interface PageHeaderConfig {
  /** Text shown in the Topbar. */
  title: string
  /** Whether the Topbar should render a back button. Defaults to true. */
  showBack?: boolean
  /**
   * Called when the back button is tapped. Defaults to browser back
   * (navigate(-1)) if omitted — only provide this when a page needs custom
   * back behavior, e.g. closing an in-page sub-view (Games category
   * drill-down) instead of leaving the route entirely.
   */
  onBack?: () => void
}

interface PageHeaderContextValue {
  header: PageHeaderConfig | null
  /** Registers this render's header config; returns nothing — cleanup is
   *  handled by the calling hook (usePageHeader), not by the caller. */
  setHeader: (config: PageHeaderConfig | null) => void
}

const PageHeaderContext = createContext<PageHeaderContextValue | null>(null)

export function PageHeaderProvider({ children }: { children: ReactNode }) {
  const [header, setHeader] = useState<PageHeaderConfig | null>(null)
  return (
    <PageHeaderContext.Provider value={{ header, setHeader }}>
      {children}
    </PageHeaderContext.Provider>
  )
}

/**
 * Internal — consumed by AppLayout/Topbar only. Pages should use
 * `usePageHeader` below, not this directly.
 */
export function usePageHeaderContext() {
  const ctx = useContext(PageHeaderContext)
  if (!ctx) throw new Error('usePageHeaderContext must be used within a PageHeaderProvider')
  return ctx
}

/**
 * Call from any page to register its Topbar title/back behavior. Re-registers
 * whenever `config.title`, `config.showBack`, or `config.onBack` changes
 * (e.g. a club name arriving after a fetch, or a category drill-down
 * changing the label) and clears itself on unmount so the next page starts
 * from a clean slate rather than inheriting a stale title for one frame.
 *
 * Pass `null` for components that only sometimes own the page header — e.g.
 * a list view rendered both as its own route and embedded inside a parent
 * page's tab (`embedded` prop pattern). This keeps the hook call unconditional
 * (satisfying the rules of hooks) while making it a no-op when the component
 * isn't the one that should own the Topbar, leaving whatever the host page
 * already registered untouched.
 *
 * Usage:
 *   usePageHeader({ title: 'Community' })
 *   usePageHeader({ title: club?.name ?? 'Club' })
 *   usePageHeader({ title: category.label, onBack: () => setCategory(null) })
 *   usePageHeader(embedded ? null : { title: 'Clubs' })
 */
export function usePageHeader(config: PageHeaderConfig | null) {
  const { setHeader } = usePageHeaderContext()
  // Keep the latest onBack in a ref so identity changes to an inline arrow
  // function don't cause an extra register/clear cycle on every render —
  // only title/showBack (and whether onBack is present at all) do.
  const onBackRef = useRef(config?.onBack)
  onBackRef.current = config?.onBack

  const title = config?.title
  const showBack = config?.showBack
  const hasOnBack = !!config?.onBack
  const active = config !== null

  useEffect(() => {
    if (!active) return
    setHeader({
      title: title as string,
      showBack,
      onBack: hasOnBack ? () => onBackRef.current?.() : undefined,
    })
    return () => setHeader(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, title, showBack, hasOnBack, setHeader])
}

/**
 * Imperative variant for the rare case a header needs to change without a
 * clean unmount boundary (none of the current pages need this — prefer
 * `usePageHeader` everywhere else).
 */
export function usePageHeaderSetter() {
  const { setHeader } = usePageHeaderContext()
  return useCallback((config: PageHeaderConfig | null) => setHeader(config), [setHeader])
}
