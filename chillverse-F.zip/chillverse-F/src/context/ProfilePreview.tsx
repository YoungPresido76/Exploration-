// src/context/ProfilePreview.tsx
//
// App-wide "quick profile" overlay — the Discord-style card that pops up
// when you tap ANY avatar in the app. Mounted once near the root (see
// App.tsx) and portaled to document.body so it always sits above
// everything, regardless of which page/modal triggered it.
import { createContext, useCallback, useContext, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'
import ProfilePreviewModal from '../features/profile/ProfilePreviewModal'

interface PreviewTarget {
  id: string
  attack: boolean
  /**
   * Monotonic id for THIS opening. See closeGeneration below — this is
   * what stops one profile's exit animation from closing the next
   * profile that opened while it was still running.
   */
  gen: number
}

interface ProfilePreviewCtx {
  /**
   * `opts.attack` opens the popup with the attack sheet already up. Added
   * for the bounty poster's "Accept the contract" button — sending someone
   * to a profile and making them find the attack button again is a worse
   * answer to "I accept" than just opening it.
   */
  openProfilePreview: (userId: string, opts?: { attack?: boolean }) => void
  closeProfilePreview: () => void
}

const Ctx = createContext<ProfilePreviewCtx | null>(null)

export function ProfilePreviewProvider({ children }: { children: ReactNode }) {
  const [target, setTarget] = useState<PreviewTarget | null>(null)
  const genRef = useRef(0)

  const openProfilePreview = useCallback((id: string, opts?: { attack?: boolean }) => {
    genRef.current += 1
    setTarget({ id, attack: opts?.attack === true, gen: genRef.current })
  }, [])

  // ── Why closing takes a generation ──────────────────────────────────
  //
  // ProfilePreviewModal's close() is `setClosing(true); setTimeout(onClose,
  // 200)` — the state flips immediately, the target is cleared 200ms later
  // once the sheet has animated out. Fine on its own, but every row that
  // sends you from one profile to another (club owner, duo partner, a name
  // in the followers list) calls close() and THEN opens the next profile.
  // The next one lands inside that 200ms window, and the first one's timer
  // — which used to clear the target unconditionally — wiped it a moment
  // later. To the player that reads as "it tries to open the profile and
  // instantly closes the sheet".
  //
  // Now a close only clears the target if the generation it was fired for
  // is still the one on screen. A stale timer for a profile that's already
  // been replaced does nothing.
  const closeGeneration = useCallback((gen: number) => {
    setTarget(cur => (cur && cur.gen !== gen ? cur : null))
  }, [])

  /** Public close — always closes whatever is currently open. */
  const closeProfilePreview = useCallback(() => { setTarget(null) }, [])

  return (
    <Ctx.Provider value={{ openProfilePreview, closeProfilePreview }}>
      {children}
      {target && createPortal(
        <ProfilePreviewModal
          // Keyed on the generation, not the user id: opening the SAME
          // profile again (or swapping to another one mid-close) has to
          // get a clean instance, otherwise it inherits the outgoing
          // one's `closing` flag and renders as an invisible sheet stuck
          // at translateY(100%).
          key={target.gen}
          userId={target.id}
          onClose={() => closeGeneration(target.gen)}
          openAttack={target.attack}
          // Swapping to another profile from inside the sheet (club owner,
          // duo partner) goes through here rather than the /profile/:id
          // route: that route is ProfileRedirect, which opens the popup and
          // then navigate(-1)s straight back off the URL. One setState does
          // the same job with nothing to race.
          onOpenOtherProfile={openProfilePreview}
        />,
        document.body,
      )}
    </Ctx.Provider>
  )
}

/** Throws if used outside the provider — use this in code that's always mounted inside App. */
export function useProfilePreview(): ProfilePreviewCtx {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useProfilePreview must be used within a ProfilePreviewProvider')
  return ctx
}

/** Safe version for shared/leaf components (like Avatar) that may render before the provider mounts. */
export function useProfilePreviewOptional(): ProfilePreviewCtx | null {
  return useContext(Ctx)
}
