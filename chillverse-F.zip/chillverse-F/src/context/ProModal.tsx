// src/context/ProModal.tsx
//
// A plain text popup. This used to be a 9-slide auto-advancing carousel of
// videos, GIFs and full-size PNGs pulled from Adverts/Go pro — roughly 11MB
// of Supabase egress every time it was opened, for a 360x210 box. All of that
// media is gone; the modal now says what Premium gets you and links to /pro.
//
// No network requests, no assets, no timers.

import { X, Crown, Zap, Check } from 'lucide-react'

interface ProModalProps {
  visible: boolean
  onClose: () => void
  onGoPro?: () => void
}

const PERKS: string[] = [
  'Higher session limits across every game',
  'Exclusive avatars, banners and profile skins',
  'Multiplayer and version upgrades unlocked',
  'More movies in the Lounge',
]

export function ProModal({ visible, onClose, onGoPro }: ProModalProps) {
  if (!visible) return null

  return (
    <>
      <style>{`
        @keyframes cv-modalIn   { 0%{opacity:0;transform:scale(0.92)} 100%{opacity:1;transform:scale(1)} }
        @keyframes cv-overlayIn { 0%{opacity:0} 100%{opacity:1} }
        @keyframes cv-shimmer   { 0%{background-position:-200% center} 100%{background-position:200% center} }
        @keyframes cv-crown     { 0%,100%{transform:scale(1) rotate(-8deg)} 50%{transform:scale(1.15) rotate(-8deg)} }
      `}</style>

      <div onClick={onClose} style={{
        position:'fixed',inset:0,zIndex:9999,
        background:'rgba(0,0,0,0.80)',backdropFilter:'blur(14px)',
        display:'flex',alignItems:'center',justifyContent:'center',
        padding:'24px 20px',
        animation:'cv-overlayIn 0.3s ease forwards',
        fontFamily:"'Inter',sans-serif",
      }}>
        <div onClick={e=>e.stopPropagation()} style={{
          width:'100%',maxWidth:360,
          background:'linear-gradient(160deg,#1c1c22,#141418)',
          border:'1px solid var(--border-strong)',
          borderRadius:28,
          boxShadow:'0 32px 80px rgba(0,0,0,0.85),0 0 0 1px color-mix(in srgb, var(--accent) 8%, transparent)',
          overflow:'hidden',
          animation:'cv-modalIn 0.35s cubic-bezier(0.34,1.3,0.64,1) forwards',
          position:'relative',
        }}>

          {/* Top shimmer strip */}
          <div style={{
            position:'absolute',top:0,left:0,right:0,height:2,
            background:'linear-gradient(90deg,transparent,var(--accent),var(--accent2),var(--accent),transparent)',
            backgroundSize:'200% 100%',animation:'cv-shimmer 3s linear infinite',
          }}/>

          {/* Header */}
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'18px 18px 12px'}}>
            <div style={{display:'flex',alignItems:'center',gap:8}}>
              <div style={{
                width:34,height:34,borderRadius:10,
                background:'linear-gradient(135deg,var(--accent),var(--accent2))',
                display:'flex',alignItems:'center',justifyContent:'center',
                boxShadow:'0 4px 14px color-mix(in srgb, var(--accent) 45%, transparent)',
                animation:'cv-crown 2.5s ease-in-out infinite',
              }}>
                <Crown size={17} color="#fff" fill="#fff"/>
              </div>
              <div>
                <div style={{color:'#fff',fontWeight:800,fontSize:15}}>Go Premium</div>
                <div style={{color:'rgba(255,255,255,0.38)',fontSize:11}}>Unlock the full Chillverse</div>
              </div>
            </div>
            <button onClick={onClose} aria-label="Close" style={{
              width:30,height:30,borderRadius:8,
              background:'rgba(255,255,255,0.07)',
              border:'1px solid var(--border-strong)',
              display:'flex',alignItems:'center',justifyContent:'center',
              cursor:'pointer',color:'rgba(255,255,255,0.5)',
            }}>
              <X size={14}/>
            </button>
          </div>

          {/* Message */}
          <div style={{padding:'4px 18px 0'}}>
            <p style={{
              color:'#fff',fontSize:14.5,fontWeight:600,lineHeight:1.55,
              margin:'0 0 14px',
            }}>
              Premium opens up the parts of Chillverse the free tier keeps locked.
            </p>

            <div style={{display:'flex',flexDirection:'column',gap:9,paddingBottom:4}}>
              {PERKS.map(perk => (
                <div key={perk} style={{display:'flex',alignItems:'flex-start',gap:9}}>
                  <div style={{
                    width:18,height:18,borderRadius:6,flexShrink:0,marginTop:1,
                    background:'color-mix(in srgb, var(--accent) 18%, transparent)',
                    border:'1px solid color-mix(in srgb, var(--accent) 35%, transparent)',
                    display:'flex',alignItems:'center',justifyContent:'center',
                  }}>
                    <Check size={11} color="var(--accent)" strokeWidth={3}/>
                  </div>
                  <span style={{color:'rgba(255,255,255,0.72)',fontSize:13,lineHeight:1.45}}>
                    {perk}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Go Pro button */}
          <div style={{padding:'18px 14px 18px'}}>
            <button
              onClick={onGoPro??onClose}
              style={{
                width:'100%',
                background:'linear-gradient(135deg,var(--accent),var(--accent2))',
                border:'none',borderRadius:16,padding:'14px 20px',
                display:'flex',alignItems:'center',justifyContent:'center',gap:8,
                cursor:'pointer',
                boxShadow:'0 6px 24px color-mix(in srgb, var(--accent) 45%, transparent)',
                fontFamily:"'Inter',sans-serif",
                transition:'opacity 0.2s,transform 0.15s',
                position:'relative',overflow:'hidden',
              }}
              onMouseEnter={e=>(e.currentTarget.style.opacity='0.9')}
              onMouseLeave={e=>(e.currentTarget.style.opacity='1')}
              onMouseDown={e=>(e.currentTarget.style.transform='scale(0.97)')}
              onMouseUp={e=>(e.currentTarget.style.transform='scale(1)')}
            >
              <div style={{
                position:'absolute',inset:0,
                background:'linear-gradient(90deg,transparent 0%,rgba(255,255,255,0.15) 50%,transparent 100%)',
                backgroundSize:'200% 100%',animation:'cv-shimmer 2.5s linear infinite',
              }}/>
              <Zap size={16} color="#fff" fill="#fff" style={{position:'relative',zIndex:1}}/>
              <span style={{color:'#fff',fontSize:15,fontWeight:800,letterSpacing:0.3,position:'relative',zIndex:1}}>
                Go Premium
              </span>
            </button>
            <p style={{color:'rgba(255,255,255,0.25)',fontSize:11,textAlign:'center',marginTop:8,lineHeight:1.4}}>
              Tap to view plans &amp; pricing
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
