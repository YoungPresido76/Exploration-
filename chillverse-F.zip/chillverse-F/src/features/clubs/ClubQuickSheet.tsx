// src/features/clubs/ClubQuickSheet.tsx
//
// Tap a club slot on someone's profile and the profile sheet slides
// down while this one draws up in its place — the same handoff
// BadgeQuickSheet and AvatarQuickSheet already do.
//
// It shows the club the way an outsider needs to see it: banner (or the
// flat colour block, matching ClubBannerEditor — never an empty
// placeholder), name, icon, description, who runs it, and one button.
//
// That button is decided server-side by viewer_state, not guessed here,
// so a person only ever sees the action that will actually go through:
// Join for a public club, Apply for one that reviews applications, and
// a plain explanation for invite-only or full. That's the club leader's
// setting doing the deciding, which is the point.
import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Users, ShieldCheck, Crown, Lock, Check, Hourglass } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import ClubIcon from './clubIcons'
import {
  fetchPublicClubPreview, joinPublicClub, applyToClub,
  type PublicClubPreview,
} from './publicClubs'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

// Matches ProfilePreviewModal's child sheets — keep in sync if those move.
const SHEET_HEIGHT_VH = 85
const WIDE_BREAKPOINT = 640

/** The "well organized" purple. Same violet as the Avatar palette's
 *  violet/pink pair, deliberately not accent orange — this is a quality
 *  signal, not a call to action. */
export const ORGANIZED_PURPLE = '#a855f7'

interface Props {
  roomId: string
  /** Falls back onto this while the fetch is in flight, so the sheet
   *  opens with the name already on it instead of a blank header. */
  fallbackName?: string
  fallbackIconKey?: string | null
  fallbackIconUrl?: string | null
  onClose: () => void
  /** Navigate into the club. Caller closes the profile sheet first. */
  onOpenClub: (roomId: string) => void
  /** Opens the owner's own profile. */
  onOpenProfile?: (userId: string) => void
}

export default function ClubQuickSheet({
  roomId, fallbackName, fallbackIconKey, fallbackIconUrl, onClose, onOpenClub, onOpenProfile,
}: Props) {
  const [visible, setVisible] = useState(false)
  const [isWide, setIsWide] = useState(() => typeof window !== 'undefined' && window.innerWidth >= WIDE_BREAKPOINT)
  const [club, setClub] = useState<PublicClubPreview | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [applied, setApplied] = useState(false)

  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [])

  useEffect(() => { requestAnimationFrame(() => setVisible(true)) }, [])

  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= WIDE_BREAKPOINT) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  useEffect(() => {
    let alive = true
    setLoading(true)
    fetchPublicClubPreview(roomId)
      .then(c => { if (alive) { setClub(c); setLoading(false) } })
      .catch(e => { if (alive) { setError(e.message); setLoading(false) } })
    return () => { alive = false }
  }, [roomId])

  function close() { setVisible(false); setTimeout(onClose, 260) }

  // Drag-to-dismiss from anywhere inside the sheet (not just the grab
  // pill) — engages only when the content under the finger is already
  // scrolled to the top, so the body still scrolls normally.
  // See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(close)

  async function handleJoin() {
    if (!club || busy) return
    setBusy(true); setError(null)
    try {
      await joinPublicClub(club.id)
      close()
      onOpenClub(club.id)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function handleApply() {
    if (!club || busy) return
    setBusy(true); setError(null)
    try {
      await applyToClub(club.id)
      setApplied(true)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const name = club?.name ?? fallbackName ?? 'Club'
  const iconKey = club?.icon_key ?? fallbackIconKey ?? null
  const iconUrl = club?.icon_url ?? fallbackIconUrl ?? null
  const organized = !!club?.is_organized
  const state = applied ? 'pending' : club?.viewer_state

  const ownerName = club?.owner ? (club.owner.display_name || club.owner.username) : null

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 20100,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        opacity: visible ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          width: isWide ? 'min(92vw, 460px)' : '100%',
          height: `${SHEET_HEIGHT_VH}vh`,
          borderRadius: '20px 20px 0 0',
          marginTop: 'auto',
          overflowY: 'auto',
          background: 'var(--surface2)',
          boxShadow: '0 -12px 40px -12px var(--sh)',
          transform: visible ? `translateY(${dragY}px)` : 'translateY(100%)',
          transition: dragging ? 'none' : 'transform 0.32s cubic-bezier(0.32,0.72,0,1)',
          zIndex: 20105,
          position: 'relative',
        }}
      >
        {/* ── Banner ─────────────────────────────────────────────── */}
        <div
          style={{
            position: 'relative', width: '100%', aspectRatio: '16 / 7',
            borderRadius: '20px 20px 0 0', overflow: 'hidden',
            display: 'flex', alignItems: 'flex-end',
            background: club?.banner_url
              ? `center / cover no-repeat url(${club.banner_url})`
              : 'linear-gradient(135deg, var(--accent-soft, #3a3a44), var(--surface3))',
          }}
        >
          {club?.banner_url && (
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.18) 55%, transparent 100%)' }} />
          )}

          <button
            type="button" onClick={close} aria-label="Close"
            style={{
              position: 'absolute', top: 12, right: 12, zIndex: 2,
              width: 30, height: 30, borderRadius: '50%', border: 'none', cursor: 'pointer',
              background: 'rgba(0,0,0,0.45)', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
            <X size={16} />
          </button>

          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 11, padding: '0 16px 14px', width: '100%', minWidth: 0 }}>
            <div
              style={{
                width: 48, height: 48, borderRadius: '30%', overflow: 'hidden', flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff',
                background: iconUrl ? 'var(--surface)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
                boxShadow: organized
                  ? `0 0 0 2px ${ORGANIZED_PURPLE}, 0 0 18px -2px ${ORGANIZED_PURPLE}`
                  : '0 2px 10px -2px rgba(0,0,0,0.6)',
              }}
            >
              <ClubIcon iconKey={iconKey} iconUrl={iconUrl} size={22} />
            </div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <p style={{
                fontSize: 18, fontWeight: 800, color: '#fff', margin: 0,
                textShadow: '0 1px 6px rgba(0,0,0,0.7)',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>{name}</p>
              {club && (
                <p style={{ fontSize: 11.5, fontWeight: 700, color: 'rgba(255,255,255,0.82)', margin: '2px 0 0', display: 'flex', alignItems: 'center', gap: 5, textShadow: '0 1px 5px rgba(0,0,0,0.7)' }}>
                  <Users size={11} />
                  {club.member_count}/{club.max_members} members
                </p>
              )}
            </div>
          </div>
        </div>

        <div style={{ padding: '16px 18px 30px' }}>
          {loading ? (
            <>
              <div className="pv-skel" style={{ height: 16, width: '55%', borderRadius: 6, marginBottom: 10 }} />
              <div className="pv-skel" style={{ height: 44, width: '100%', borderRadius: 12, marginBottom: 12 }} />
              <div className="pv-skel" style={{ height: 46, width: '100%', borderRadius: 13 }} />
            </>
          ) : !club ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '20px 0' }}>
              {error ?? "This club isn't available."}
            </p>
          ) : (
            <>
              {organized && (
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 14,
                  padding: '5px 11px', borderRadius: 20,
                  background: `${ORGANIZED_PURPLE}1a`, border: `1px solid ${ORGANIZED_PURPLE}55`,
                }}>
                  <ShieldCheck size={12} style={{ color: ORGANIZED_PURPLE }} />
                  <span style={{ fontSize: 11, fontWeight: 800, color: ORGANIZED_PURPLE }}>Well organized</span>
                </div>
              )}

              {/* ── About ─────────────────────────────────────────── */}
              <p style={LABEL}>About</p>
              <p style={{ fontSize: 12.5, color: club.description ? 'var(--text-dim)' : 'var(--text-muted)', lineHeight: 1.55, marginBottom: 18 }}>
                {club.description || 'This club hasn’t written a description yet.'}
              </p>

              {/* ── Owner ─────────────────────────────────────────── */}
              {club.owner && (
                <>
                  <p style={LABEL}>Owner</p>
                  <button
                    type="button"
                    onClick={() => { if (onOpenProfile && club.owner) { close(); onOpenProfile(club.owner.id) } }}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 11, width: '100%',
                      padding: 11, borderRadius: 14, marginBottom: 18,
                      background: 'var(--surface)', border: '1px solid var(--border)',
                      cursor: onOpenProfile ? 'pointer' : 'default', fontFamily: 'inherit', textAlign: 'left',
                    }}
                  >
                    <Avatar
                      src={club.owner.avatar}
                      name={ownerName ?? club.owner.username}
                      ownerId={club.owner.id}
                      size={38}
                      radius={12}
                      disabled
                    />
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {ownerName}
                      </p>
                      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '1px 0 0' }}>@{club.owner.username}</p>
                    </div>
                    <Crown size={15} style={{ color: '#f5c542', flexShrink: 0 }} />
                  </button>
                </>
              )}

              {error && (
                <p style={{ fontSize: 11.5, color: '#ff6b6b', marginBottom: 10 }}>{error}</p>
              )}

              {/* ── The one button ────────────────────────────────── */}
              {state === 'member' ? (
                <ActionButton onClick={() => { close(); onOpenClub(club.id) }} label="Open club" />
              ) : state === 'can_join' ? (
                <ActionButton onClick={handleJoin} disabled={busy} label={busy ? 'Joining…' : 'Join club'} />
              ) : state === 'can_apply' ? (
                <ActionButton onClick={handleApply} disabled={busy} label={busy ? 'Sending…' : 'Apply to join'} />
              ) : state === 'pending' ? (
                <Notice icon={<Hourglass size={14} />} title="Application sent"
                  body={`${ownerName ? ownerName : 'The club leader'} will review it — you'll be let in if it's approved.`} />
              ) : state === 'full' ? (
                <Notice icon={<Users size={14} />} title="This club is full"
                  body={`It's at its ${club.max_members}-member cap right now.`} />
              ) : (
                <Notice icon={<Lock size={14} />} title="Invite only"
                  body="You'll need a join code or an invite link from someone inside." />
              )}

              {applied && state === 'pending' && (
                <p style={{ fontSize: 11, color: ORGANIZED_PURPLE, marginTop: 9, display: 'flex', alignItems: 'center', gap: 5, justifyContent: 'center' }}>
                  <Check size={11} /> Sent
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>,
    document.body,
  )
}

const LABEL: React.CSSProperties = {
  fontSize: 10, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase',
  color: 'var(--text-muted)', marginBottom: 7,
}

function ActionButton({ label, onClick, disabled }: { label: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      type="button" onClick={onClick} disabled={disabled}
      style={{
        width: '100%', padding: '13px 16px', borderRadius: 14, border: 'none',
        fontSize: 13.5, fontWeight: 800, fontFamily: 'inherit',
        cursor: disabled ? 'default' : 'pointer', color: '#fff',
        opacity: disabled ? 0.6 : 1,
        background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
      }}
    >
      {label}
    </button>
  )
}

function Notice({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div style={{
      display: 'flex', gap: 10, padding: '12px 14px', borderRadius: 14,
      background: 'var(--surface)', border: '1px solid var(--border)',
    }}>
      <span style={{ color: 'var(--text-muted)', flexShrink: 0, marginTop: 1 }}>{icon}</span>
      <div>
        <p style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text-dim)', margin: 0 }}>{title}</p>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '2px 0 0', lineHeight: 1.45 }}>{body}</p>
      </div>
    </div>
  )
}
