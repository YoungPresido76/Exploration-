// src/features/clubs/clubInvites.ts
//
// "Invite to your club" — sent from the three-dot menu on someone's
// profile preview sheet, answered from the Clubs tab.
//
// Deliberately NOT club_add_member (clubs.ts): that one is president-only
// and drops a person into the club without asking, which is the wrong
// shape when any ordinary member can send this. An invite is offered and
// then accepted.
//
// Every read here goes through a SECURITY DEFINER RPC because chat_rooms
// AND room_members are both gated on is_room_member() — an invitee can't
// see the club they were invited to any other way. See migration 0175a.
import { supabase } from '../../shared/lib/supabase'

/** Why a club in the picker can't be invited into. `null` means it can. */
export type InviteBlockReason =
  | 'leaders_only'      // invite-only club, and you're a plain member
  | 'already_member'    // they're already in
  | 'full'
  | 'already_invited'   // a pending invite is already outstanding

export interface ClubInviteOption {
  roomId: string
  name: string
  iconKey: string | null
  iconUrl: string | null
  joinMode: 'public' | 'invite' | 'apply'
  memberCount: number
  canInvite: boolean
  blockReason: InviteBlockReason | null
}

export interface IncomingClubInvite {
  inviteId: string
  roomId: string
  clubName: string
  iconKey: string | null
  iconUrl: string | null
  bannerUrl: string | null
  description: string | null
  memberCount: number
  inviterId: string
  inviterName: string
  inviterAvatar: string
  createdAt: string
  expiresAt: string
}

/** Server-side error codes, turned into something a person can read.
 *  Anything unrecognised falls through to the raw message rather than a
 *  generic "something went wrong", which is useless when debugging. */
const INVITE_ERRORS: Record<string, string> = {
  CV_INVITE_LEADERS_ONLY:      'Oops — only your VP or president can invite to this club',
  CV_ALREADY_MEMBER:           "They're already in this club",
  CV_CLUB_FULL:                'That club is full',
  CV_BLOCKED:                  "You can't invite this person",
  CV_INVITE_DECLINED_RECENTLY: 'They turned down an invite to this club recently',
  CV_INVITE_RATE_LIMIT:        "You've sent a lot of invites today — try again tomorrow",
  CV_SELF_INVITE:              "You're already in it",
  CV_INVITE_NOT_FOUND:         'That invite is gone',
  CV_INVITE_SPENT:             'That invite was already answered',
  CV_INVITE_EXPIRED:           'That invite has expired',
}

function friendlyInviteError(message: string): Error {
  for (const [code, text] of Object.entries(INVITE_ERRORS)) {
    if (message.includes(code)) return new Error(text)
  }
  return new Error(message)
}

/** Why a club row is greyed out in the picker. The picker SHOWS blocked
 *  clubs rather than hiding them — "only your VP or president can invite"
 *  is information, and a club silently missing from the list isn't. */
export function inviteBlockText(reason: InviteBlockReason | null): string | null {
  switch (reason) {
    case 'leaders_only':    return 'Only the VP or president can invite'
    case 'already_member':  return 'Already a member'
    case 'full':            return 'Club is full'
    case 'already_invited': return 'Invite already sent'
    default:                return null
  }
}

/** Every club you're in, each flagged with whether this particular person
 *  can be invited into it. */
export async function fetchClubInviteOptions(targetUserId: string): Promise<ClubInviteOption[]> {
  const { data, error } = await supabase.rpc('club_invite_options', { p_target_id: targetUserId })
  if (error) throw friendlyInviteError(error.message)
  return ((data ?? []) as any[]).map(r => ({
    roomId: r.room_id,
    name: r.name,
    iconKey: r.icon_key,
    iconUrl: r.icon_url,
    joinMode: r.join_mode,
    memberCount: r.member_count ?? 0,
    canInvite: !!r.can_invite,
    blockReason: (r.block_reason ?? null) as InviteBlockReason | null,
  }))
}

export async function sendClubInvite(roomId: string, userId: string): Promise<string> {
  const { data, error } = await supabase.rpc('club_invite_user', {
    p_room_id: roomId, p_user_id: userId,
  })
  if (error) throw friendlyInviteError(error.message)
  return data as string
}

/** The invites waiting on YOU. Carries enough club detail to render the
 *  card without a second lookup — which matters, because a private club
 *  can't be previewed through public_club_preview by an outsider. */
export async function fetchMyClubInvites(): Promise<IncomingClubInvite[]> {
  const { data, error } = await supabase.rpc('my_club_invites')
  if (error) throw friendlyInviteError(error.message)
  return ((data ?? []) as any[]).map(r => ({
    inviteId: r.invite_id,
    roomId: r.room_id,
    clubName: r.club_name,
    iconKey: r.icon_key,
    iconUrl: r.icon_url,
    bannerUrl: r.banner_url,
    description: r.description,
    memberCount: r.member_count ?? 0,
    inviterId: r.inviter_id,
    inviterName: r.inviter_name,
    inviterAvatar: r.inviter_avatar,
    createdAt: r.created_at,
    expiresAt: r.expires_at,
  }))
}

/** Accepting returns the room id to navigate into; declining returns null. */
export async function respondToClubInvite(inviteId: string, accept: boolean): Promise<string | null> {
  const { data, error } = await supabase.rpc('club_respond_invite', {
    p_invite_id: inviteId, p_accept: accept,
  })
  if (error) throw friendlyInviteError(error.message)
  return (data as string | null) ?? null
}
