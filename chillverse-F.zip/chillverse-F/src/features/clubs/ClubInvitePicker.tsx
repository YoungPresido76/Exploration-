// src/features/clubs/ClubInvitePicker.tsx
//
// "Invite to your club" from the three-dot menu on a profile preview.
//
// Blocked clubs are SHOWN greyed with their reason rather than filtered
// out — "only your VP or president can invite" is the answer to a question
// the person is actually asking, and a club that silently isn't in the
// list just looks broken.
//
// Rendered through a portal at a z-index above the profile sheet (20000),
// with a stopPropagation guard on the panel: a portalled child still
// bubbles events up the REACT tree, so without it a tap in here reaches
// ProfilePreviewModal's backdrop handler and closes the profile.
import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Check, Users } from 'lucide-react'
import ClubIcon from './clubIcons'
import {
  fetchClubInviteOptions, sendClubInvite, inviteBlockText,
  type ClubInviteOption,
} from './clubInvites'

const WIDE_BREAKPOINT = 640

interface Props {
  targetUserId: string
  targetName: string
  onClose: () => void
  /** Fired after a successful send so the caller can toast. */
  onSent: (clubName: string) => void
  /** Fired when the server refuses, with a readable reason. */
  onError: (message: string) => void
}

export default function ClubInvitePicker({ targetUserId, targetName, onClose, onSent, onError }: Props) {
  const [visible, setVisible] = useState(false)
  const [isWide, setIsWide] = useState(() => typeof window !== 'undefined' && window.innerWidth >= WIDE_BREAKPOINT)
  const [options, setOptions] = useState<ClubInviteOption[]>([])
  const [loading, setLoading] = useState(true)
  const [sendingId, setSendingId] = useState<string | null>(null)
  const [sentIds, setSentIds] = useState<Set<string>>(new Set())

  useEffect(() => {
    const id = requestAnimationFrame(() => setVisible(true))
    return () => cancelAnimationFrame(id)
  }, [])

  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= WIDE_BREAKPOINT) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  useEffect(() => {
    let active = true
    fetchClubInviteOptions(targetUserId)
      .then(rows => { if (active) setOptions(rows) })
      .catch(e => { if (active) onError(e.message) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
    // onError is a fresh closure each render in the caller; depending on it
    // would refetch the list on every parent render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetUserId])

  function close() {
    setVisible(false)
    setTimeout(onClose, 220)
  }

  async function handleInvite(opt: ClubInviteOption) {
    if (!opt.canInvite) {
      // The row is already labelled; the tap explains it out loud too, for
      // the case where the label got truncated on a narrow phone.
      onError(inviteBlockText(opt.blockReason) ?? "You can't invite them to this club")
      return
    }
    setSendingId(opt.roomId)
    try {
      await sendClubInvite(opt.roomId, targetUserId)
      setSentIds(prev => new Set(prev).add(opt.roomId))
      onSent(opt.name)
      // Leave the sheet open — inviting to a second club is a normal next
      // move, and the row now reads "Invited".
    } catch (e: any) {
      onError(e.message)
    } finally {
      setSendingId(null)
    }
  }

  const panel = (
    <div
      onClick={e => e.stopPropagation()}
      style={{
        width: isWide ? 'min(420px, calc(100vw - 32px))' : '100%',
        maxHeight: '72vh',
        background: 'var(--bg)',
        border: '1px solid var(--border)',
        borderRadius: isWide ? 20 : '20px 20px 0 0',
        boxShadow: '0 -12px 40px -12px var(--sh)',
        transform: visible ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform 0.28s cubic-bezier(0.32,0.72,0,1)',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}
    >
      <div style={{ padding: '10px 0 6px', display: 'flex', justifyContent: 'center', flexShrink: 0 }}>
        <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--border-strong)' }} />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '2px 18px 12px', flexShrink: 0 }}>
        <Users size={15} style={{ color: 'var(--text-dim)' }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>Invite to your club</p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {targetName} decides whether to accept
          </p>
        </div>
        <button type="button" onClick={close} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex' }}>
          <X size={16} />
        </button>
      </div>

      <div style={{ overflowY: 'auto', overscrollBehavior: 'contain', padding: '0 12px 20px' }}>
        {loading ? (
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '22px 0' }}>Loading your clubs…</p>
        ) : options.length === 0 ? (
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '22px 12px', lineHeight: 1.6 }}>
            You're not in any clubs yet. Join or create one and you'll be able to invite people from here.
          </p>
        ) : (
          options.map(opt => {
            const sent = sentIds.has(opt.roomId)
            const blocked = !opt.canInvite && !sent
            const reason = blocked ? inviteBlockText(opt.blockReason) : null
            return (
              <button
                key={opt.roomId}
                type="button"
                onClick={() => !sent && handleInvite(opt)}
                disabled={sendingId === opt.roomId || sent}
                style={{
                  width: '100%', display: 'flex', alignItems: 'center', gap: 11,
                  padding: '11px 10px', borderRadius: 13, marginBottom: 2,
                  background: 'none', border: 'none', textAlign: 'left',
                  cursor: sent ? 'default' : 'pointer',
                  opacity: blocked ? 0.5 : 1,
                }}
              >
                <div style={{
                  width: 38, height: 38, borderRadius: 12, flexShrink: 0,
                  background: 'linear-gradient(135deg, var(--accent), #7c5cff)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#fff', overflow: 'hidden',
                }}>
                  <ClubIcon iconKey={opt.iconKey} iconUrl={opt.iconUrl} size={19} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {opt.name}
                  </p>
                  <p style={{ fontSize: 11, color: reason ? '#ff6b6b' : 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {reason ?? `${opt.memberCount} ${opt.memberCount === 1 ? 'member' : 'members'}`}
                  </p>
                </div>
                {sent ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11.5, fontWeight: 700, color: '#3ecf8e', flexShrink: 0 }}>
                    <Check size={13} /> Invited
                  </span>
                ) : sendingId === opt.roomId ? (
                  <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)', flexShrink: 0 }}>Sending…</span>
                ) : !blocked ? (
                  <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--accent)', flexShrink: 0 }}>Invite</span>
                ) : null}
              </button>
            )
          })
        )}
      </div>
    </div>
  )

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050,
        background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: isWide ? 'center' : 'flex-end', justifyContent: 'center',
        opacity: visible ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      {panel}
    </div>,
    document.body,
  )
}
