// src/features/clubs/ClubRouteResolver.tsx
//
// Wraps the /clubs/:roomId, /clubs/:roomId/info and /clubs/:roomId/settings
// routes. Invite links now use the club's slug instead of its raw room id
// (see buildClubInviteLink in clubs.ts), e.g.
//   /clubs/if-y-2-find-x?code=B5CDFD
// instead of
//   /clubs/94da4e9e-db64-4cd8-8915-6ddaf07722b5?code=B5CDFD
//
// ClubChat.tsx / ClubInfo.tsx / ClubSettings.tsx all still work in terms
// of the real room id internally (RPC calls, realtime filters, etc. — see
// clubs.ts). Rather than thread a resolved id through every one of those
// call sites, this resolver sits in front of them: if the :roomId param
// is already a real id, it renders the child immediately with no extra
// network round trip; if it's a slug, it looks up the real id and swaps
// the URL to the canonical id-based form (preserving the trailing path
// segment and query string), which the child then mounts against as usual.
import { useEffect, useState } from 'react'
import { useParams, useLocation, Navigate } from 'react-router-dom'
import { resolveClubSlug, isClubRoomId } from './clubs'

export default function ClubRouteResolver({ children }: { children: React.ReactNode }) {
  const { roomId } = useParams<{ roomId: string }>()
  const location = useLocation()
  const [resolvedId, setResolvedId] = useState<string | null | undefined>(undefined)
  const [notFound, setNotFound] = useState(false)

  useEffect(() => {
    if (!roomId) return
    if (isClubRoomId(roomId)) {
      setResolvedId(null) // already canonical -- nothing to resolve
      setNotFound(false)
      return
    }
    setResolvedId(undefined)
    setNotFound(false)
    let cancelled = false
    resolveClubSlug(roomId)
      .then(id => {
        if (cancelled) return
        if (id) setResolvedId(id)
        else setNotFound(true)
      })
      .catch(() => { if (!cancelled) setNotFound(true) })
    return () => { cancelled = true }
  }, [roomId])

  if (roomId && isClubRoomId(roomId)) return <>{children}</>

  if (notFound) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 8, padding: 24, textAlign: 'center' }}>
        <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>Club not found</p>
        <p style={{ fontSize: 13, color: 'var(--text-dim)' }}>That link doesn't point to a real club, or it's since been deleted.</p>
      </div>
    )
  }

  if (resolvedId) {
    // Preserve whatever comes after the :roomId segment (/info, /settings)
    // and the query string (?code=...) — only the roomId segment itself
    // is swapped from slug to canonical id.
    const rest = roomId ? location.pathname.slice(location.pathname.indexOf(roomId) + roomId.length) : ''
    return <Navigate replace to={`/clubs/${resolvedId}${rest}${location.search}`} />
  }

  return null // resolving
}
