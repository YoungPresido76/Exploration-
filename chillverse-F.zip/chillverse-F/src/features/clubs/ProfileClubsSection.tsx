// src/features/clubs/ProfileClubsSection.tsx
//
// The Club block inside ProfilePreviewModal, sitting directly under
// Member Since (and above Dynamic Duo).
//
// One slot per club, up to PROFILE_CLUB_LIMIT. Each slot is the club's
// picture and name — and when a club never uploaded a picture, its lucide
// icon_key stands in, which is what ClubIcon already does everywhere else
// in Clubs.
//
// What a slot deliberately does NOT show is the member count. That's
// inside-the-club information; an outsider looking at somebody's profile
// has no business knowing how big their clubs are. The count lives in the
// sheet, where you've been let far enough in to be deciding whether to
// join. The subtitle is the join mode instead, which is the thing that
// actually tells you whether tapping will get you anywhere.
//
// Invite-only clubs still get a slot, but the slot is where they stop:
// tapping one toasts rather than opening the sheet, so the description,
// banner, owner and member count stay inside. Migration 0148 enforces the
// same rule server-side, so this isn't just a UI habit. A private club
// you're already in opens normally — the toast is for outsiders.
//
// Which clubs appear at all is two switches, both of which must be on:
// the member picks them in Edit Profile (room_members.show_on_profile),
// and the club's leader can withdraw the club from member profiles
// entirely (chat_rooms.show_in_member_profiles). Both are applied inside
// public_user_clubs, including on your own profile — so what you see here
// is exactly what everyone else sees.
import { useEffect, useState } from 'react'
import { Users, Lock, Globe, Mail } from 'lucide-react'
import ClubIcon from './clubIcons'
import ClubQuickSheet, { ORGANIZED_PURPLE } from './ClubQuickSheet'
import Toast, { useToast } from '../../shared/components/Toast'
import {
  fetchPublicUserClubs, PRIVATE_CLUB_TOAST, type PublicClubSlot,
} from './publicClubs'

interface Props {
  userId: string
  isMe: boolean
  /** Fires as the club sheet opens and closes so the profile sheet can
   *  slide down out of the way and come back. */
  onSheetToggle?: (open: boolean) => void
  /** Navigate into a club (/clubs/:id). Caller closes the profile sheet. */
  onOpenClub: (roomId: string) => void
  /** Open another player's profile — used by the sheet's owner row. */
  onOpenProfile?: (userId: string) => void
}

const LABEL: React.CSSProperties = {
  fontSize: 10, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase',
  color: 'var(--text-muted)', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 5,
}

const JOIN_MODE_LABEL = {
  public: 'Public',
  invite: 'Invite only',
  apply: 'Apply to join',
} as const

// The profile sheet sits at 20000 and its child sheets at 20100, so a
// default-z toast would render behind both.
const TOAST_Z = 20200

export default function ProfileClubsSection({
  userId, isMe, onSheetToggle, onOpenClub, onOpenProfile,
}: Props) {
  const [clubs, setClubs] = useState<PublicClubSlot[] | null>(null)
  const [openClubId, setOpenClubId] = useState<string | null>(null)
  const { toast, showToast } = useToast()

  useEffect(() => {
    let alive = true
    setClubs(null)
    fetchPublicUserClubs(userId)
      .then(rows => { if (alive) setClubs(rows) })
      .catch(() => { if (alive) setClubs([]) })
    return () => { alive = false }
  }, [userId])

  useEffect(() => { onSheetToggle?.(openClubId !== null) }, [openClubId])

  function tapSlot(club: PublicClubSlot) {
    if (club.is_private && !club.viewer_is_member) {
      showToast({ message: PRIVATE_CLUB_TOAST, icon: Lock, iconColor: 'var(--text-muted)' })
      return
    }
    setOpenClubId(club.id)
  }

  if (clubs === null) {
    return (
      <div className="pv-section">
        <p style={LABEL}><Users size={11} /> Club</p>
        <div className="pv-skel" style={{ height: 56, borderRadius: 15 }} />
      </div>
    )
  }

  // Nothing shown is a real state, not an error. It covers both "not in a
  // club" and "chose not to show them", and it deliberately doesn't
  // distinguish the two on someone else's profile — the section just
  // isn't there, because saying "hidden" leaks the thing they hid.
  if (clubs.length === 0) {
    if (!isMe) return null
    return (
      <div className="pv-section">
        <p style={LABEL}><Users size={11} /> Club</p>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
          Nothing showing — pick your clubs in Edit Profile
        </p>
      </div>
    )
  }

  const openClub = clubs.find(c => c.id === openClubId) ?? null

  return (
    <div className="pv-section">
      <p style={LABEL}><Users size={11} /> {clubs.length === 1 ? 'Club' : 'Clubs'}</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {clubs.map(club => {
          const ModeIcon = club.join_mode === 'public' ? Globe : club.join_mode === 'apply' ? Mail : Lock
          return (
            <button
              key={club.id}
              type="button"
              className="pv-btn"
              onClick={() => tapSlot(club)}
              style={{
                display: 'flex', alignItems: 'center', gap: 11, width: '100%',
                padding: 11, borderRadius: 15, cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
                background: club.is_organized
                  ? `linear-gradient(135deg, ${ORGANIZED_PURPLE}14, var(--surface))`
                  : 'var(--surface)',
                border: club.is_organized
                  ? `1px solid ${ORGANIZED_PURPLE}66`
                  : '1px solid var(--border)',
                boxShadow: club.is_organized
                  ? `0 0 16px -4px ${ORGANIZED_PURPLE}, inset 0 0 22px -14px ${ORGANIZED_PURPLE}`
                  : 'none',
              }}
            >
              <div
                style={{
                  width: 38, height: 38, borderRadius: '30%', overflow: 'hidden', flexShrink: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff',
                  background: club.icon_url ? 'var(--surface2)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
                }}
              >
                <ClubIcon iconKey={club.icon_key} iconUrl={club.icon_url} size={18} />
              </div>

              <div style={{ minWidth: 0, flex: 1 }}>
                <p style={{
                  fontSize: 13, fontWeight: 800, margin: 0,
                  color: club.is_organized ? ORGANIZED_PURPLE : 'var(--text)',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {club.name}
                </p>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <ModeIcon size={10} />
                  {JOIN_MODE_LABEL[club.join_mode]}
                  {club.member_role !== 'member' && (
                    <span style={{ color: 'var(--text-dim)', fontWeight: 700 }}>
                      · {club.member_role === 'president' ? 'President' : 'VP'}
                    </span>
                  )}
                </p>
              </div>
            </button>
          )
        })}
      </div>

      {openClub && (
        <ClubQuickSheet
          roomId={openClub.id}
          fallbackName={openClub.name}
          fallbackIconKey={openClub.icon_key}
          fallbackIconUrl={openClub.icon_url}
          onClose={() => setOpenClubId(null)}
          onOpenClub={onOpenClub}
          onOpenProfile={onOpenProfile}
        />
      )}

      <Toast toast={toast} zIndex={TOAST_Z} />
    </div>
  )
}
