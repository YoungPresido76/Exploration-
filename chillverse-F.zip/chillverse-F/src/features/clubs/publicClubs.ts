// src/features/clubs/publicClubs.ts
//
// Reading a club you are NOT in.
//
// Everything in clubs.ts reads chat_rooms/room_members directly, which
// works because those tables are gated on is_room_member() and the caller
// is always inside the club. The profile sheet is the opposite case: it
// shows a stranger's clubs to someone who isn't in them. That crosses the
// RLS boundary, so it goes through the two SECURITY DEFINER functions
// added in migration 0147 instead. Neither ever returns join_code.
//
// Joining reuses the RPCs that already exist — join_club for a public
// club, request_club_join for an apply-to-join one. Which of the two the
// sheet offers is decided server-side (viewer_state), so the button a
// person sees is always the one that will actually work.

import { supabase } from '../../shared/lib/supabase'
import type { ClubJoinMode, ClubRole } from './clubs'

/** A slot on someone's profile. Deliberately light — the sheet re-fetches
 *  the full picture when it opens. */
export interface PublicClubSlot {
  id: string
  name: string
  slug: string | null
  icon_key: string | null
  icon_url: string | null
  join_mode: ClubJoinMode
  /** Invite-only. The slot shows, the sheet doesn't — tapping toasts. */
  is_private: boolean
  /** Their role in that club, not yours. */
  member_role: ClubRole
  /** Description + picture + a rules channel + onboarding. All four. */
  is_organized: boolean
  /** Whether YOU are also in it. A private club you're already inside
   *  opens normally — the toast is for outsiders. */
  viewer_is_member: boolean
}

/** A row in the Edit Profile picker: every club you're in, shown or not. */
export interface MyProfileClub {
  id: string
  name: string
  icon_key: string | null
  icon_url: string | null
  join_mode: ClubJoinMode
  is_private: boolean
  member_role: ClubRole
  show_on_profile: boolean
  /** The leader's ceiling. False locks the row off entirely. */
  club_allows: boolean
}

/** How many clubs a profile will show at once. */
export const PROFILE_CLUB_LIMIT = 3

/** Where the viewer stands with this club — decides the button. */
export type ClubViewerState =
  | 'member'       // already in
  | 'pending'      // applied, waiting on the president
  | 'can_join'     // public, one tap
  | 'can_apply'    // apply-to-join
  | 'invite_only'  // needs a code or link
  | 'full'

export interface PublicClubPreview {
  id: string
  name: string
  slug: string | null
  description: string | null
  icon_key: string | null
  icon_url: string | null
  banner_url: string | null
  join_mode: ClubJoinMode
  member_count: number
  max_members: number
  created_at: string
  is_organized: boolean
  checklist: {
    has_description: boolean
    has_picture: boolean
    has_rules: boolean
    has_onboarding: boolean
  }
  owner: {
    id: string
    username: string
    display_name: string | null
    avatar: string | null
  } | null
  viewer_state: ClubViewerState
}

export async function fetchPublicUserClubs(userId: string): Promise<PublicClubSlot[]> {
  const { data, error } = await supabase.rpc('public_user_clubs', { p_user_id: userId })
  if (error) throw new Error(error.message)
  return (data ?? []) as PublicClubSlot[]
}

export async function fetchMyProfileClubs(): Promise<MyProfileClub[]> {
  const { data, error } = await supabase.rpc('my_profile_clubs')
  if (error) throw new Error(error.message)
  return (data ?? []) as MyProfileClub[]
}

/** Show or hide one club on your own profile. */
export async function setClubProfileVisibility(roomId: string, show: boolean): Promise<void> {
  const { error } = await supabase.rpc('set_club_profile_visibility', {
    p_room_id: roomId,
    p_show: show,
  })
  if (error) throw new Error(visibilityErrorText(error.message))
}

function visibilityErrorText(message: string): string {
  const m = (message || '').toLowerCase()
  if (m.includes('profile_club_limit')) {
    return `You can show ${PROFILE_CLUB_LIMIT} clubs at a time — hide one first.`
  }
  if (m.includes('club_hides_from_profiles')) {
    return "This club's leader has turned off showing it on member profiles."
  }
  if (m.includes('not in this club')) return "You're not in this club anymore."
  return message || 'Something went wrong.'
}

export async function fetchPublicClubPreview(roomId: string): Promise<PublicClubPreview> {
  const { data, error } = await supabase.rpc('public_club_preview', { p_room_id: roomId })
  if (error) throw new Error(previewErrorText(error.message))
  return data as PublicClubPreview
}

/** Raised by public_club_preview when an outsider reaches for an
 *  invite-only club. The section catches this before it ever fires by
 *  toasting instead of opening the sheet — this is the backstop. */
export const PRIVATE_CLUB_TOAST = 'Oops… this is a private club'

export function isPrivateClubError(message: string): boolean {
  return (message || '').toLowerCase().includes(PRIVATE_CLUB_TOAST.toLowerCase())
}

function previewErrorText(message: string): string {
  if ((message || '').toLowerCase().includes('club_is_private')) return PRIVATE_CLUB_TOAST
  if ((message || '').toLowerCase().includes('club not found')) return "That club doesn't exist anymore."
  return message || 'Something went wrong.'
}

/** One tap into a public club. Returns the room id so the caller can
 *  navigate straight in. */
export async function joinPublicClub(roomId: string): Promise<string> {
  const { data, error } = await supabase.rpc('join_club', { p_room_id: roomId, p_code: null })
  if (error) throw new Error(joinErrorText(error.message))
  return data as string
}

export async function applyToClub(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('request_club_join', { p_room_id: roomId })
  if (error) throw new Error(joinErrorText(error.message))
}

/** The raw `raise exception` strings, in words a player can act on. */
function joinErrorText(message: string): string {
  const m = (message || '').toLowerCase()
  if (m.includes('club_requires_application')) return 'This club reviews applications — tap Apply instead.'
  if (m.includes('invite-only')) return 'This club is invite-only — you need a code or an invite link.'
  if (m.includes('club is full')) return 'This club is full.'
  if (m.includes('already in this club')) return "You're already in this club."
  if (m.includes('not accepting applications')) return "This club isn't accepting applications right now."
  if (m.includes('club not found')) return "That club doesn't exist anymore."
  return message || 'Something went wrong.'
}
