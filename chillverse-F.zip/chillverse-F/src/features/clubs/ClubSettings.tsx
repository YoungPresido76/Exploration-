// src/features/clubs/ClubSettings.tsx
//
// Club Settings, restructured as a Discord-style hub: a short list of
// sections rather than one long scroll of every field. Tapping a row swaps
// the body for that section and the header title follows, so it reads as a
// stack on a phone without adding routes.
//
// Sections: Server Profile, Access, Members, Engagement, Channel Insights.
// President and VP both reach the hub; the president-only bits (invite link,
// mute, transfer, danger zone) stay under Server Profile / the hub footer and
// are simply absent for a VP, same rules as before.
//
// The sections themselves live in ClubSettingsSections.tsx.

import { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  Copy, Check, RefreshCw, Users, Link2, Image, Shield, MessageSquareHeart, BarChart3,
} from 'lucide-react'
import {
  fetchClub, fetchClubMembers, fetchClubChannels, updateClubSettings, regenerateClubCode,
  transferClubOwnership, clearClubChat, deleteClub, buildClubInviteLink,
  type ClubRoom, type ClubMemberRow, type ClubChannel, type ClubRole,
} from './clubs'
import ClubAvatarEditor from './ClubAvatarEditor'
import ClubBannerEditor from './ClubBannerEditor'
import {
  SettingsRow, ToggleRow, AccessSection, EngagementSection, InsightsSection,
  sectionTitle, inputStyle,
} from './ClubSettingsSections'
import { useAuth } from '../auth/useAuth'
import { usePageHeader } from '../../context/PageHeader'

type Section = 'hub' | 'profile' | 'access' | 'engagement' | 'insights'

const SECTION_TITLES: Record<Section, string> = {
  hub: 'Club Settings',
  profile: 'Server Profile',
  access: 'Access',
  engagement: 'Engagement',
  insights: 'Channel Insights',
}

export default function ClubSettings() {
  const { roomId } = useParams<{ roomId: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()
  const myId = user?.id ?? null

  const [club, setClub] = useState<ClubRoom | null>(null)
  const [members, setMembers] = useState<ClubMemberRow[]>([])
  const [channels, setChannels] = useState<ClubChannel[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [section, setSection] = useState<Section>('hub')

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [muted, setMuted] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [linkCopied, setLinkCopied] = useState(false)
  const [regenerating, setRegenerating] = useState(false)

  const [confirmClear, setConfirmClear] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [transferTo, setTransferTo] = useState('')
  const [busy, setBusy] = useState(false)

  // Registered unconditionally, ahead of the loading/error early returns
  // below (rules of hooks). Title tracks `section` — re-registers
  // automatically as the in-page hub/profile/access/engagement/insights
  // drill-down changes, same as the old inline header text did. Back
  // either steps up one level (out of a section, back to the hub) or
  // exits club settings entirely (out of the hub) — same two-destination
  // logic the old button had, now just handed to the Topbar.
  usePageHeader({
    title: SECTION_TITLES[section],
    onBack: () => (section === 'hub'
      ? navigate(club ? `/clubs/${club.id}` : '/chat?tab=clubs')
      : setSection('hub')),
  })

  const load = useCallback(async () => {
    if (!roomId) return
    setLoading(true)
    setLoadError('')
    try {
      const [c, mem, chs] = await Promise.all([
        fetchClub(roomId), fetchClubMembers(roomId), fetchClubChannels(roomId),
      ])
      if (!c) { setLoadError('Club not found, or you left it.'); return }
      setClub(c)
      setMembers(mem)
      setChannels(chs)
      setName(c.name)
      setDescription(c.description ?? '')
      setMuted(c.muted)
    } catch (e: any) {
      setLoadError(e.message)
    } finally {
      setLoading(false)
    }
  }, [roomId])

  useEffect(() => { load() }, [load])

  const myRole: ClubRole | null = members.find(m => m.user_id === myId)?.role ?? null
  const isPresident = myRole === 'president'
  const canManage = myRole === 'president' || myRole === 'vp'
  const vps = members.filter(m => m.role === 'vp')

  async function saveField(patch: Parameters<typeof updateClubSettings>[1]) {
    if (!club) return
    setSaving(true)
    setError('')
    try {
      await updateClubSettings(club.id, patch)
      const fresh = await fetchClub(club.id)
      if (fresh) setClub(fresh)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  function copyLink() {
    if (!club?.join_code) return
    navigator.clipboard.writeText(buildClubInviteLink(club, club.join_code)).then(() => {
      setLinkCopied(true)
      setTimeout(() => setLinkCopied(false), 1500)
    })
  }

  async function handleRegenerate() {
    if (!club) return
    setRegenerating(true)
    setError('')
    try {
      await regenerateClubCode(club.id)
      const fresh = await fetchClub(club.id)
      if (fresh) setClub(fresh)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setRegenerating(false)
    }
  }

  async function handleTransfer() {
    if (!transferTo || !club) return
    setBusy(true)
    setError('')
    try {
      await transferClubOwnership(club.id, transferTo)
      navigate(`/clubs/${club.id}`)
    } catch (e: any) {
      setError(e.message)
      setBusy(false)
    }
  }

  async function handleClear() {
    if (!club) return
    setBusy(true)
    setError('')
    try {
      await clearClubChat(club.id)
      setConfirmClear(false)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function handleDelete() {
    if (!club) return
    setBusy(true)
    setError('')
    try {
      await deleteClub(club.id)
      navigate('/chat?tab=clubs')
    } catch (e: any) {
      setError(e.message)
      setBusy(false)
    }
  }

  if (loading) {
    return <div style={{ padding: 60, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>Loading…</div>
  }
  if (loadError && !club) {
    return (
      <div style={{ maxWidth: 420, margin: '60px auto', textAlign: 'center', padding: '0 20px' }}>
        <p style={{ fontSize: 13, color: '#ff6b6b', marginBottom: 14 }}>{loadError}</p>
        <button onClick={() => navigate('/chat?tab=clubs')} className="neu-card-sm" style={{ padding: '9px 18px', border: 'none', color: 'var(--text)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>Back to Clubs</button>
      </div>
    )
  }
  if (!club) return null

  const joinModeLabel = club.join_mode === 'public' ? 'Public'
    : club.join_mode === 'apply' ? 'Apply to join' : 'Invite only'

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', height: 'calc(100dvh - 60px - var(--dock-space, 0px))', overflowY: 'auto', padding: '14px 16px 40px' }}>
      {/* Title + back button now live in the app Topbar via usePageHeader()
          above — see PAGE_HEADER_MIGRATION_PLAN.md Phase 7. */}
      {error && (
        <div className="neu-inset" style={{ padding: '9px 12px', color: '#ff6b6b', fontSize: 12, marginBottom: 10 }}>{error}</div>
      )}

      {/* ── Hub ── */}
      {section === 'hub' && (
        <>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '4px 0 20px' }}>
            <ClubAvatarEditor club={club} userId={myId ?? ''} canEdit={canManage} onUpdated={setClub} size={84} />
            <p style={{ marginTop: 12, fontSize: 17, fontWeight: 800, color: 'var(--text)' }}>{club.name}</p>
            <p style={{ marginTop: 3, fontSize: 11.5, color: 'var(--text-muted)' }}>
              {isPresident ? 'President' : myRole === 'vp' ? 'VP' : 'Member'} · {members.length} member{members.length === 1 ? '' : 's'}
            </p>
          </div>

          {canManage && (
            <>
              <SettingsRow icon={<Image size={16} />} label="Server Profile" hint="Photo, banner, name and description" onClick={() => setSection('profile')} />
              <SettingsRow icon={<Shield size={16} />} label="Access" hint="Who can join, and how" value={joinModeLabel} onClick={() => setSection('access')} />
            </>
          )}

          <SettingsRow
            icon={<Users size={16} />}
            label="Members"
            hint="Everyone in the club"
            value={String(members.length)}
            onClick={() => navigate(`/clubs/${club.id}/info`)}
          />

          {canManage && (
            <>
              <SettingsRow icon={<MessageSquareHeart size={16} />} label="Engagement" hint="Welcome message for new members" value={club.welcome_enabled === false ? 'Off' : 'On'} onClick={() => setSection('engagement')} />
              <SettingsRow icon={<BarChart3 size={16} />} label="Channel Insights" hint="How the club is doing" value={club.insights_enabled ? 'On' : 'Off'} onClick={() => setSection('insights')} />
            </>
          )}

          {isPresident && (
            <>
              <div style={sectionTitle}>Danger zone</div>
              {confirmClear ? (
                <div className="neu-inset" style={{ padding: 12, marginBottom: 10 }}>
                  <p style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 8 }}>Clear all messages for every member? This can't be undone.</p>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => setConfirmClear(false)} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>Cancel</button>
                    <button onClick={handleClear} disabled={busy} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: 'none', background: '#ff6b6b', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: busy ? 0.7 : 1 }}>Clear chat</button>
                  </div>
                </div>
              ) : (
                <button onClick={() => setConfirmClear(true)} className="neu-card-sm" style={{ width: '100%', padding: '10px 0', border: 'none', background: 'var(--surface2)', color: '#ff6b6b', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', marginBottom: 8 }}>
                  Clear chat
                </button>
              )}
              {confirmDelete ? (
                <div className="neu-inset" style={{ padding: 12 }}>
                  <p style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 8 }}>Delete this club for everyone? This can't be undone.</p>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => setConfirmDelete(false)} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>Cancel</button>
                    <button onClick={handleDelete} disabled={busy} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: 'none', background: '#ff6b6b', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: busy ? 0.7 : 1 }}>Delete club</button>
                  </div>
                </div>
              ) : (
                <button onClick={() => setConfirmDelete(true)} className="neu-card-sm" style={{ width: '100%', padding: '10px 0', border: 'none', background: 'var(--surface2)', color: '#ff6b6b', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>
                  Delete club
                </button>
              )}
            </>
          )}
        </>
      )}

      {/* ── Server Profile ── */}
      {section === 'profile' && (
        <>
          <ClubBannerEditor
            club={club}
            userId={myId ?? ''}
            memberCount={members.length}
            canEdit={canManage}
            onUpdated={setClub}
          />

          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16px 0 4px' }}>
            <ClubAvatarEditor club={club} userId={myId ?? ''} canEdit={canManage} onUpdated={setClub} size={84} />
          </div>

          <div style={sectionTitle}>Club name</div>
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            maxLength={60}
            disabled={!canManage}
            style={inputStyle}
            onBlur={() => { if (name.trim() && name !== club.name) saveField({ name: name.trim() }) }}
          />

          <div style={sectionTitle}>Description</div>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value.slice(0, 300))}
            maxLength={300}
            rows={3}
            disabled={!canManage}
            placeholder="What's this club about?"
            style={{ ...inputStyle, resize: 'vertical', fontWeight: 400, lineHeight: 1.4 }}
            onBlur={() => { if (description !== (club.description ?? '')) saveField({ description }) }}
          />
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 4, textAlign: 'right' }}>{description.length}/300</p>

          {isPresident && (
            <>
              <div style={sectionTitle}>Invite link</div>
              <div className="neu-inset" style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px' }}>
                <Link2 size={14} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
                <span style={{ fontSize: 12, color: 'var(--text-dim)', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {club.join_code ? buildClubInviteLink(club, club.join_code) : ''}
                </span>
                <button onClick={copyLink} style={{ background: 'none', border: 'none', cursor: 'pointer', color: linkCopied ? '#3ecf8e' : 'var(--text-dim)', display: 'flex', flexShrink: 0 }}>
                  {linkCopied ? <Check size={14} /> : <Copy size={14} />}
                </button>
                <button onClick={handleRegenerate} disabled={regenerating} title="Generate a new link — the old one stops working immediately" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', display: 'flex', flexShrink: 0, opacity: regenerating ? 0.5 : 1 }}>
                  <RefreshCw size={14} />
                </button>
              </div>

              <div style={{ marginTop: 20 }}>
                <ToggleRow
                  title="Mute club"
                  hint="Only you and VPs can send messages"
                  on={muted}
                  onChange={next => { setMuted(next); saveField({ muted: next }) }}
                />
              </div>

              {vps.length > 0 && (
                <>
                  <div style={sectionTitle}>Transfer ownership</div>
                  <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>Only a current VP can become president.</p>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <select value={transferTo} onChange={e => setTransferTo(e.target.value)} style={{ ...inputStyle, flex: 1 }}>
                      <option value="">Choose a VP…</option>
                      {vps.map(v => <option key={v.user_id} value={v.user_id}>{v.display_name || v.username}</option>)}
                    </select>
                    <button onClick={handleTransfer} disabled={!transferTo || busy} className="neu-icon" style={{ padding: '0 16px', width: 'auto', height: 'auto', border: 'none', color: 'var(--text)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer', opacity: !transferTo || busy ? 0.6 : 1 }}>
                      Transfer
                    </button>
                  </div>
                </>
              )}
            </>
          )}
        </>
      )}

      {section === 'access' && (
        <AccessSection club={club} canEdit={canManage} onUpdated={setClub} />
      )}

      {section === 'engagement' && (
        <EngagementSection
          club={club}
          channels={channels}
          canEdit={canManage}
          onUpdated={setClub}
          onOnboardingSaved={load}
        />
      )}

      {section === 'insights' && (
        <InsightsSection club={club} canEdit={canManage} onUpdated={setClub} />
      )}

      {saving && <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 14, textAlign: 'center' }}>Saving…</p>}
    </div>
  )
}
