// src/features/clubs/ClubOnboardingEditor.tsx
//
// The onboarding builder, living inside Engagement. Discord's model: a list
// of questions, each with options, each option carrying an emoji and the
// channel that picking it drops you into.
//
// The channel is mandatory per option — an option with no channel does
// nothing when someone picks it, so save_club_onboarding rejects it and the
// error surfaces as the agreed toast copy rather than a Postgres string.
//
// The emoji isn't decoration: whichever option a member picks, that emoji
// rides beside their name in this club's chat (and nowhere else). That's
// what the "i" explains.

import { useEffect, useState } from 'react'
import { Plus, Trash2, Info, X } from 'lucide-react'
import {
  fetchClubOnboarding, saveClubOnboarding,
  type ClubChannel, type OnboardingDraftQuestion,
} from './clubs'

const EMOJI_CHOICES = ['🎮', '💬', '🔥', '🎨', '🎵', '⚽', '📚', '😂', '🧠', '🏆', '🍿', '✨', '🤔', '💀', '🫡', '🐐']

interface ClubOnboardingEditorProps {
  roomId: string
  channels: ClubChannel[]
  canEdit: boolean
  onSaved: () => void
}

export default function ClubOnboardingEditor({ roomId, channels, canEdit, onSaved }: ClubOnboardingEditorProps) {
  const [questions, setQuestions] = useState<OnboardingDraftQuestion[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)
  const [infoOpen, setInfoOpen] = useState(false)

  useEffect(() => {
    fetchClubOnboarding(roomId)
      .then(existing => {
        setQuestions(existing.map(q => ({
          prompt: q.prompt,
          options: q.options.map(o => ({
            label: o.label,
            emoji: o.emoji ?? '',
            channel_id: o.channel_id ?? '',
          })),
        })))
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [roomId])

  function patchQuestion(index: number, patch: Partial<OnboardingDraftQuestion>) {
    setQuestions(qs => qs.map((q, i) => (i === index ? { ...q, ...patch } : q)))
    setSaved(false)
  }

  function patchOption(qIndex: number, oIndex: number, patch: Partial<OnboardingDraftQuestion['options'][number]>) {
    setQuestions(qs => qs.map((q, i) => (
      i === qIndex
        ? { ...q, options: q.options.map((o, j) => (j === oIndex ? { ...o, ...patch } : o)) }
        : q
    )))
    setSaved(false)
  }

  async function save() {
    setSaving(true)
    setError('')
    setSaved(false)
    try {
      await saveClubOnboarding(roomId, questions)
      setSaved(true)
      onSaved()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  const field: React.CSSProperties = {
    width: '100%', background: 'var(--surface2)', border: '1px solid var(--border)',
    boxShadow: 'var(--elev-inset)', borderRadius: 10, padding: '9px 12px', fontSize: 13,
    fontWeight: 600, color: 'var(--text)', outline: 'none', boxSizing: 'border-box',
  }

  if (loading) return <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading…</p>

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>Onboarding</span>
        <button
          type="button"
          onClick={() => setInfoOpen(true)}
          aria-label="Why emojis?"
          className="neu-icon"
          style={{ width: 22, height: 22, borderRadius: '50%', border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}
        >
          <Info size={12} />
        </button>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: 12 }}>
        Ask new members a few questions. Whatever they pick drops them straight into that channel.
      </p>

      {questions.map((question, qIndex) => (
        <div key={qIndex} className="neu-card" style={{ padding: 13, border: 'none', borderRadius: 12, marginBottom: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Question {qIndex + 1}
            </span>
            <span style={{ flex: 1 }} />
            {canEdit && (
              <button
                onClick={() => { setQuestions(qs => qs.filter((_, i) => i !== qIndex)); setSaved(false) }}
                aria-label="Remove question"
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ff6b6b', display: 'flex' }}
              >
                <Trash2 size={13} />
              </button>
            )}
          </div>

          <input
            value={question.prompt}
            onChange={e => patchQuestion(qIndex, { prompt: e.target.value.slice(0, 120) })}
            disabled={!canEdit}
            placeholder="Do you like debates?"
            style={field}
          />

          <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {question.options.map((option, oIndex) => (
              <div key={oIndex} className="neu-inset" style={{ padding: 10, borderRadius: 10 }}>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <select
                    value={option.emoji}
                    onChange={e => patchOption(qIndex, oIndex, { emoji: e.target.value })}
                    disabled={!canEdit}
                    aria-label="Emoji for this option"
                    style={{ ...field, width: 62, padding: '8px 4px', textAlign: 'center', flexShrink: 0 }}
                  >
                    <option value="">–</option>
                    {EMOJI_CHOICES.map(e => <option key={e} value={e}>{e}</option>)}
                  </select>
                  <input
                    value={option.label}
                    onChange={e => patchOption(qIndex, oIndex, { label: e.target.value.slice(0, 60) })}
                    disabled={!canEdit}
                    placeholder="Yes"
                    style={{ ...field, flex: 1 }}
                  />
                  {canEdit && question.options.length > 1 && (
                    <button
                      onClick={() => {
                        patchQuestion(qIndex, { options: question.options.filter((_, j) => j !== oIndex) })
                      }}
                      aria-label="Remove option"
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', flexShrink: 0 }}
                    >
                      <X size={13} />
                    </button>
                  )}
                </div>

                <select
                  value={option.channel_id}
                  onChange={e => patchOption(qIndex, oIndex, { channel_id: e.target.value })}
                  disabled={!canEdit}
                  style={{ ...field, marginTop: 7, fontSize: 12.5 }}
                >
                  <option value="">Pick the channel this sends them to…</option>
                  {channels.map(ch => (
                    <option key={ch.id} value={ch.id}>#{ch.name}{ch.is_private ? ' (private)' : ''}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>

          {canEdit && question.options.length < 6 && (
            <button
              onClick={() => patchQuestion(qIndex, { options: [...question.options, { label: '', emoji: '', channel_id: '' }] })}
              style={{ marginTop: 9, background: 'none', border: 'none', color: 'var(--accent)', fontSize: 11.5, fontWeight: 700, cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 5 }}
            >
              <Plus size={12} /> Add option
            </button>
          )}
        </div>
      ))}

      {canEdit && questions.length < 5 && (
        <button
          onClick={() => { setQuestions(qs => [...qs, { prompt: '', options: [{ label: '', emoji: '', channel_id: '' }] }]); setSaved(false) }}
          className="neu-card-sm"
          style={{ width: '100%', padding: '10px 0', border: 'none', background: 'var(--surface2)', color: 'var(--text)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
        >
          <Plus size={13} /> Add question
        </button>
      )}

      {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 10 }}>{error}</p>}
      {saved && !error && <p style={{ fontSize: 11.5, color: '#3ecf8e', marginTop: 10 }}>Onboarding saved.</p>}

      {canEdit && (
        <button
          onClick={save}
          disabled={saving}
          style={{
            width: '100%', marginTop: 12, padding: '11px 0', borderRadius: 12, border: 'none',
            background: 'var(--accent)', color: '#fff', fontSize: 13, fontWeight: 700,
            cursor: saving ? 'not-allowed' : 'pointer', opacity: saving ? 0.6 : 1,
          }}
        >
          {saving ? 'Saving…' : 'Save onboarding'}
        </button>
      )}

      {infoOpen && (
        <>
          <div onClick={() => setInfoOpen(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)', zIndex: 70 }} />
          <div
            role="dialog"
            style={{
              position: 'fixed', left: 16, right: 16, top: '38%', zIndex: 71, maxWidth: 340,
              margin: '0 auto', background: 'var(--surface)', borderRadius: 16, padding: 18,
              boxShadow: '0 20px 50px -18px rgba(0,0,0,0.6)',
            }}
          >
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', marginBottom: 8 }}>
              Why did we put emojis?
            </p>
            <p style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.55 }}>
              Why not… 🙃
            </p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.55, marginTop: 10 }}>
              Seriously though — the emoji from whatever they pick shows up next to their name
              when they chat in this club. Only here, nowhere else on Chillverse.
            </p>
            <button
              onClick={() => setInfoOpen(false)}
              style={{ width: '100%', marginTop: 14, padding: '10px 0', borderRadius: 10, border: 'none', background: 'var(--accent)', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}
            >
              Got it
            </button>
          </div>
        </>
      )}
    </>
  )
}
