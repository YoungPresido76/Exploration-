// src/features/clubs/ClubInfo.tsx
// The "Club Info" screen, reached by tapping the club name/icon in
// ClubChat's header. A real routed page (like viewing someone's profile)
// instead of a modal sitting on top of the chat — styled with the app's
// shared neumorphic surfaces (neu-card / neu-inset) throughout: centered
// photo, name + description below it, then a members list.
//
// The club photo lives in Club Settings > Server Profile now; this page is
// purely the member roster, grouped Top (president + VPs) / Online / Offline.
// The president can add people straight from their own DM contacts — no
// invite link needed — via the "Add members" sheet.

import { useEffect, useState, useCallback, useMemo } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  Settings, Crown, ShieldCheck, MoreVertical, UserMinus, LogOut, Trash2,
  VolumeX, Volume2, Search, UserPlus, X, Check,
} from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import {
  fetchClub, fetchClubMembers, leaveClub, promoteClubMember, removeClubMember,
  muteClubMember, unmuteClubMember, addClubMemberDirect, fetchDmContacts,
  type ClubRoom, type ClubMemberRow, type ClubRole, type DmContact,
} from './clubs'
import { useAuth } from '../auth/useAuth'
import { usePageHeader } from '../../context/PageHeader'

const ROLE_LABEL: Record<ClubRole, string> = { president: 'President', vp: 'VP', member: 'Member' }
const ROLE_COLOR: Record<ClubRole, string> = { president: '#f5c542', vp: 'var(--accent)', member: 'var(--text-dim)' }

function isMuted(m: ClubMemberRow): boolean {
  return !!m.muted_until && new Date(m.muted_until).getTime() > Date.now()
}
function muteMinutesLeft(m: ClubMemberRow): number {
  if (!m.muted_until) return 0
  return Math.max(0, Math.round((new Date(m.muted_until).getTime() - Date.now()) / 60000))
}

export default function ClubInfo() {
  const { roomId } = useParams<{ roomId: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()
  const myId = user?.id ?? null

  const [club, setClub] = useState<ClubRoom | null>(null)
  const [members, setMembers] = useState<ClubMemberRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const [menuFor, setMenuFor] = useState<string | null>(null)
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0 })
  const [searchOpen, setSearchOpen] = useState(false)
  const [search, setSearch] = useState('')

  const [addOpen, setAddOpen] = useState(false)
  const [dmContacts, setDmContacts] = useState<DmContact[]>([])
  const [contactsLoading, setContactsLoading] = useState(false)
  const [contactSearch, setContactSearch] = useState('')
  const [addingId, setAddingId] = useState<string | null>(null)
  const [justAddedIds, setJustAddedIds] = useState<Set<string>>(new Set())

  // Registered unconditionally, ahead of the loading/error early returns
  // below (rules of hooks) — falls back to /chat?tab=clubs while `club`
  // hasn't loaded yet, same destination the old error-state "Back to
  // Clubs" button used.
  usePageHeader({ title: 'Club Info', onBack: () => navigate(club ? `/clubs/${club.id}` : '/chat?tab=clubs') })

  const load = useCallback(async () => {
    if (!roomId) return
    setLoading(true)
    setError('')
    try {
      const [c, mem] = await Promise.all([fetchClub(roomId), fetchClubMembers(roomId)])
      if (!c) { setError('Club not found, or you left it.'); return }
      setClub(c)
      setMembers(mem)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [roomId])

  useEffect(() => { load() }, [load])

  const myRole: ClubRole | null = members.find(m => m.user_id === myId)?.role ?? null
  const isPresident = myRole === 'president'

  const filteredMembers = useMemo(() => {
    if (!search.trim()) return members
    const q = search.trim().toLowerCase()
    return members.filter(m => m.username.toLowerCase().includes(q) || (m.display_name ?? '').toLowerCase().includes(q))
  }, [members, search])

  // Top = president + VPs, then everyone else split by presence. Someone
  // with show_online_activity off is counted offline rather than having
  // their status leaked by a club list they happen to be in.
  const memberGroups = useMemo(() => {
    const leaders = filteredMembers.filter(m => m.role !== 'member')
    const rest = filteredMembers.filter(m => m.role === 'member')
    const isOnline = (m: ClubMemberRow) =>
      m.show_online_activity && (m.presence === 'online' || m.presence === 'idle' || m.presence === 'dnd')
    const byName = (a: ClubMemberRow, b: ClubMemberRow) =>
      (a.display_name || a.username).localeCompare(b.display_name || b.username)

    const roleRank: Record<ClubRole, number> = { president: 0, vp: 1, member: 2 }
    return [
      { label: 'Top', members: [...leaders].sort((a, b) => roleRank[a.role] - roleRank[b.role] || byName(a, b)) },
      { label: 'Online', members: rest.filter(isOnline).sort(byName) },
      { label: 'Offline', members: rest.filter(m => !isOnline(m)).sort(byName) },
    ].filter(group => group.members.length > 0)
  }, [filteredMembers])

  const menuForMember = menuFor ? members.find(m => m.user_id === menuFor) ?? null : null

  async function handlePromote(userId: string, role: 'member' | 'vp') {
    setBusy(true); setError('')
    try { await promoteClubMember(club!.id, userId, role); await load() }
    catch (e: any) { setError(e.message) }
    finally { setBusy(false); setMenuFor(null) }
  }
  async function handleRemove(userId: string) {
    setBusy(true); setError('')
    try { await removeClubMember(club!.id, userId); await load() }
    catch (e: any) { setError(e.message) }
    finally { setBusy(false); setMenuFor(null) }
  }
  async function handleMute(userId: string) {
    setBusy(true); setError('')
    try { await muteClubMember(club!.id, userId); await load() }
    catch (e: any) { setError(e.message) }
    finally { setBusy(false); setMenuFor(null) }
  }
  async function handleUnmute(userId: string) {
    setBusy(true); setError('')
    try { await unmuteClubMember(club!.id, userId); await load() }
    catch (e: any) { setError(e.message) }
    finally { setBusy(false); setMenuFor(null) }
  }
  async function handleLeave() {
    setBusy(true); setError('')
    try { await leaveClub(club!.id); navigate('/chat?tab=clubs') }
    catch (e: any) { setError(e.message); setBusy(false) }
  }

  async function openAddMembers() {
    setAddOpen(true)
    setContactSearch('')
    setJustAddedIds(new Set())
    if (!myId) return
    setContactsLoading(true)
    try {
      setDmContacts(await fetchDmContacts(myId))
    } catch (e: any) {
      setError(e.message)
    } finally {
      setContactsLoading(false)
    }
  }

  async function handleAddContact(contact: DmContact) {
    if (!club) return
    setAddingId(contact.id)
    try {
      await addClubMemberDirect(club.id, contact.id)
      setJustAddedIds(prev => new Set(prev).add(contact.id))
      await load()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setAddingId(null)
    }
  }

  const memberIds = useMemo(() => new Set(members.map(m => m.user_id)), [members])
  const availableContacts = useMemo(() => {
    const q = contactSearch.trim().toLowerCase()
    return dmContacts
      .filter(c => !memberIds.has(c.id))
      .filter(c => !q || c.username.toLowerCase().includes(q) || (c.display_name ?? '').toLowerCase().includes(q))
  }, [dmContacts, memberIds, contactSearch])

  if (loading) {
    return <div style={{ padding: 60, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>Loading…</div>
  }
  if (error && !club) {
    return (
      <div style={{ maxWidth: 420, margin: '60px auto', textAlign: 'center', padding: '0 20px' }}>
        <p style={{ fontSize: 13, color: '#ff6b6b', marginBottom: 14 }}>{error}</p>
        <button onClick={() => navigate('/chat?tab=clubs')} className="neu-card-sm" style={{ padding: '9px 18px', border: 'none', color: 'var(--text)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>Back to Clubs</button>
      </div>
    )
  }
  if (!club) return null

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', height: 'calc(100dvh - 60px - var(--dock-space, 0px))', overflowY: 'auto', padding: '0 16px 32px' }}>
      {/* Settings gear — page-specific action, not header chrome, so it
          stays here rather than moving into the Topbar (which has no
          generic action slot). Back button + "Club Info" label above it
          used to live in this row too; now registered via usePageHeader()
          — see PAGE_HEADER_MIGRATION_PLAN.md Phase 7. Row only renders at
          all when there's a gear to show, so non-members don't get an
          empty padded gap where it used to sit. */}
      {myRole && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', padding: '14px 0' }}>
          <button onClick={() => navigate(`/clubs/${club.id}/settings`)} className="neu-icon" style={{ width: 36, height: 36, border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
            <Settings size={15} />
          </button>
        </div>
      )}

      {/* No club photo here — you've just come from a screen that showed it.
          This page is the members list, so it opens on the members. */}
      <div style={{ padding: '2px 0 16px' }}>
        <p style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)' }}>Members</p>
        <p style={{ marginTop: 3, fontSize: 12.5, color: 'var(--text-muted)' }}>
          {members.length} in {club.name}
        </p>
      </div>

      {error && (
        <div className="neu-inset" style={{ padding: '10px 14px', color: '#ff6b6b', fontSize: 12, marginBottom: 14 }}>{error}</div>
      )}

      {isPresident && (
        <button onClick={openAddMembers} className="neu-card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', padding: '12px 0', border: 'none', cursor: 'pointer', color: 'var(--accent)', fontSize: 13, fontWeight: 700, marginBottom: 16 }}>
          <UserPlus size={15} /> Add members from your chats
        </button>
      )}

      {/* Members list */}
      <div className="neu-inset" style={{ padding: '14px 12px', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', padding: '0 6px', marginBottom: 8 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', flex: 1 }}>
            Members
          </span>
          <button type="button" onClick={() => setSearchOpen(o => !o)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: searchOpen ? 'var(--accent)' : 'var(--text-muted)' }}>
            <Search size={14} />
          </button>
        </div>

        {searchOpen && (
          <div className="neu-card-sm" style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', marginBottom: 10 }}>
            <Search size={13} style={{ color: 'var(--text-muted)' }} />
            <input autoFocus value={search} onChange={e => setSearch(e.target.value)} placeholder="Search members…"
              style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: 'var(--text)' }} />
          </div>
        )}

        {filteredMembers.length === 0 ? (
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '18px 0' }}>No members match "{search}"</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {memberGroups.map(group => (
            <div key={group.label}>
            <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', padding: '10px 6px 6px' }}>
              {group.label} — {group.members.length}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {group.members.map(m => {
              const canMute = myRole !== 'member' && m.role !== 'president'
              const canKick = myRole === 'president' ? m.role !== 'president' : m.role === 'member'
              const canPromote = myRole === 'president' && m.role !== 'president'
              const canManage = canMute || canKick || canPromote
              const displayName = m.display_name || m.username
              const muted = isMuted(m)
              return (
                <div key={m.user_id} className="neu-card-sm" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 10px', position: 'relative' }}>
                  <Avatar src={m.avatar} name={displayName} userId={m.user_id} size={38} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{displayName}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, fontWeight: 700, color: ROLE_COLOR[m.role] }}>
                      {m.role === 'president' && <Crown size={11} />}
                      {m.role === 'vp' && <ShieldCheck size={11} />}
                      {ROLE_LABEL[m.role]}
                      {muted && <span style={{ display: 'flex', alignItems: 'center', gap: 3, color: '#ff6b6b', fontWeight: 600 }}><VolumeX size={11} /> {muteMinutesLeft(m)}m</span>}
                    </div>
                  </div>
                  {canManage && m.user_id !== myId && (
                    <button
                      onClick={(e) => {
                        if (menuFor === m.user_id) { setMenuFor(null); return }
                        const rect = e.currentTarget.getBoundingClientRect()
                        const menuWidth = 175
                        const left = Math.min(rect.right - menuWidth, window.innerWidth - menuWidth - 8)
                        const top = Math.min(rect.bottom + 4, window.innerHeight - 190)
                        setMenuPos({ top, left: Math.max(8, left) })
                        setMenuFor(m.user_id)
                      }}
                      disabled={busy}
                      style={{ width: 28, height: 28, borderRadius: 8, background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                    >
                      <MoreVertical size={15} />
                    </button>
                  )}
                </div>
              )
            })}
            </div>
            </div>
            ))}
          </div>
        )}
      </div>

      <button onClick={handleLeave} disabled={busy} className="neu-card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', padding: '12px 0', border: 'none', cursor: 'pointer', color: '#ff6b6b', fontSize: 13, fontWeight: 700, opacity: busy ? 0.7 : 1 }}>
        <LogOut size={14} /> Leave club
      </button>

      {/* Member action menu */}
      {menuForMember && (() => {
        const targetCanMute = myRole !== 'member' && menuForMember.role !== 'president'
        const targetCanKick = myRole === 'president' ? menuForMember.role !== 'president' : menuForMember.role === 'member'
        return (
          <>
            <div style={{ position: 'fixed', inset: 0, zIndex: 202 }} onClick={() => setMenuFor(null)} />
            <div className="neu-card" style={{ position: 'fixed', top: menuPos.top, left: menuPos.left, zIndex: 203, minWidth: 175, overflow: 'hidden' }}>
              {myRole === 'president' && menuForMember.role !== 'vp' && (
                <button onClick={() => handlePromote(menuForMember.user_id, 'vp')} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: 'var(--text-dim)' }}>
                  <ShieldCheck size={13} /> Make VP
                </button>
              )}
              {myRole === 'president' && menuForMember.role === 'vp' && (
                <button onClick={() => handlePromote(menuForMember.user_id, 'member')} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: 'var(--text-dim)' }}>
                  <UserMinus size={13} /> Remove VP
                </button>
              )}
              {targetCanMute && (
                isMuted(menuForMember) ? (
                  <button onClick={() => handleUnmute(menuForMember.user_id)} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: 'var(--text-dim)' }}>
                    <Volume2 size={13} /> Unmute
                  </button>
                ) : (
                  <button onClick={() => handleMute(menuForMember.user_id)} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: 'var(--text-dim)' }}>
                    <VolumeX size={13} /> Mute (1h)
                  </button>
                )
              )}
              {targetCanKick && (
                <button onClick={() => handleRemove(menuForMember.user_id)} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: '#ff6b6b' }}>
                  <Trash2 size={13} /> Kick from club
                </button>
              )}
            </div>
          </>
        )
      })()}

      {/* Add members — picks from the president's own DM contacts, adds directly (no invite code needed) */}
      {addOpen && (
        <>
          <div style={{ position: 'fixed', inset: 0, zIndex: 200, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(3px)' }} onClick={() => setAddOpen(false)} />
          <div className="neu-card" style={{
            position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', zIndex: 201,
            width: Math.min(400, window.innerWidth - 32), maxHeight: '80vh', display: 'flex', flexDirection: 'column',
            padding: '18px 0 14px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', padding: '0 18px', marginBottom: 12 }}>
              <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', flex: 1 }}>Add members</p>
              <button onClick={() => setAddOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}><X size={16} /></button>
            </div>
            <div className="neu-inset" style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '0 18px 12px', padding: '8px 12px' }}>
              <Search size={13} style={{ color: 'var(--text-muted)' }} />
              <input autoFocus value={contactSearch} onChange={e => setContactSearch(e.target.value)} placeholder="Search your chats…"
                style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: 'var(--text)' }} />
            </div>
            <div style={{ overflowY: 'auto', padding: '0 12px', flex: 1 }}>
              {contactsLoading ? (
                <div style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '20px 0' }}>Loading…</div>
              ) : availableContacts.length === 0 ? (
                <div style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '20px 0' }}>
                  {dmContacts.length === 0 ? 'You have no direct chats to add from yet.' : 'Everyone from your chats is already in this club.'}
                </div>
              ) : availableContacts.map(c => {
                const justAdded = justAddedIds.has(c.id)
                return (
                  <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 6px' }}>
                    <Avatar src={c.avatar} name={c.display_name || c.username} size={34} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.display_name || c.username}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>@{c.username}</div>
                    </div>
                    <button
                      onClick={() => handleAddContact(c)}
                      disabled={addingId === c.id || justAdded}
                      className="neu-icon"
                      style={{ padding: '6px 10px', width: 'auto', height: 'auto', border: 'none', cursor: justAdded ? 'default' : 'pointer', color: justAdded ? '#3ecf8e' : 'var(--accent)', display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 700 }}
                    >
                      {justAdded ? <><Check size={12} /> Added</> : addingId === c.id ? 'Adding…' : <><UserPlus size={12} /> Add</>}
                    </button>
                  </div>
                )
              })}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
