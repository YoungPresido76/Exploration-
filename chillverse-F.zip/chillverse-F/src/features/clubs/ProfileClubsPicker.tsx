// src/features/clubs/ProfileClubsPicker.tsx
//
// "Show clubs" in Edit Profile — the member's half of club visibility.
// Every club you're in gets a row with a toggle; up to PROFILE_CLUB_LIMIT
// can be on at once.
//
// It saves per-toggle rather than waiting for Save Changes, matching
// WishlistEditor and ArtifactEquipSection, which are the other sections in
// that modal that own their own writes.
//
// Two rows can't be turned on. A club whose leader has switched off
// show_in_member_profiles is locked and says so — the club withdrew
// itself from member profiles, that isn't the member's decision to make.
// And once three are on, the rest go quiet until one is turned off,
// because a profile with eight club slots stops being a profile.
//
// The toggle is optimistic and reverts on failure, since the RPC enforces
// both rules server-side and is the real arbiter.
import { useEffect, useState } from 'react'
import { Lock, Globe, Mail } from 'lucide-react'
import ClubIcon from './clubIcons'
import {
  fetchMyProfileClubs, setClubProfileVisibility, PROFILE_CLUB_LIMIT,
  type MyProfileClub,
} from './publicClubs'

const JOIN_MODE = {
  public: { label: 'Public', Icon: Globe },
  invite: { label: 'Invite only', Icon: Lock },
  apply: { label: 'Apply to join', Icon: Mail },
} as const

export default function ProfileClubsPicker() {
  const [clubs, setClubs] = useState<MyProfileClub[] | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    let alive = true
    fetchMyProfileClubs()
      .then(rows => { if (alive) setClubs(rows) })
      .catch(() => { if (alive) setClubs([]) })
    return () => { alive = false }
  }, [])

  const shownCount = (clubs ?? []).filter(c => c.show_on_profile).length

  async function toggle(club: MyProfileClub) {
    if (busyId) return
    const next = !club.show_on_profile
    setBusyId(club.id)
    setError('')
    setClubs(list => (list ?? []).map(c => c.id === club.id ? { ...c, show_on_profile: next } : c))
    try {
      await setClubProfileVisibility(club.id, next)
    } catch (e: any) {
      setClubs(list => (list ?? []).map(c => c.id === club.id ? { ...c, show_on_profile: !next } : c))
      setError(e.message)
    } finally {
      setBusyId(null)
    }
  }

  return (
    <div>
      <SectionLabel>Show clubs ({shownCount}/{PROFILE_CLUB_LIMIT})</SectionLabel>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 10, marginTop: -4 }}>
        Pick which of your clubs appear on your profile. Anything you leave off is nobody else's business.
      </p>

      {clubs === null ? (
        <div style={{ padding: '20px 0', textAlign: 'center' }}>
          <span style={{ width: 20, height: 20, borderRadius: '50%', border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', display: 'inline-block', animation: 'spin 0.8s linear infinite' }} />
        </div>
      ) : clubs.length === 0 ? (
        <div style={{ padding: '20px 0', textAlign: 'center', background: 'var(--surface)', borderRadius: 14, border: '1px dashed rgba(255,255,255,0.1)' }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>You're not in any clubs yet</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {clubs.map(club => {
            const mode = JOIN_MODE[club.join_mode] ?? JOIN_MODE.invite
            const capped = !club.show_on_profile && shownCount >= PROFILE_CLUB_LIMIT
            const locked = !club.club_allows || capped
            const on = club.show_on_profile

            return (
              <button
                key={club.id}
                type="button"
                onClick={() => { if (!locked) toggle(club) }}
                disabled={locked || busyId === club.id}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10, width: '100%',
                  padding: '9px 12px', borderRadius: 12, textAlign: 'left', fontFamily: 'inherit',
                  background: 'var(--surface)', border: '1px solid var(--border)',
                  cursor: locked ? 'default' : 'pointer',
                  opacity: locked ? 0.55 : 1,
                }}
              >
                <div style={{
                  width: 36, height: 36, borderRadius: 10, overflow: 'hidden', flexShrink: 0, color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: club.icon_url ? 'var(--surface2)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
                }}>
                  <ClubIcon iconKey={club.icon_key} iconUrl={club.icon_url} size={17} />
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {club.name}
                  </div>
                  <div style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 2, display: 'flex', alignItems: 'center', gap: 4 }}>
                    <mode.Icon size={9} />
                    {!club.club_allows
                      ? 'This club is kept off member profiles'
                      : capped
                        ? `Hide another club to show this one`
                        : mode.label}
                  </div>
                </div>

                {/* Toggle pill — same look as ToggleRow in club settings. */}
                <span style={{
                  width: 38, height: 22, borderRadius: 11, flexShrink: 0, position: 'relative',
                  background: on ? 'var(--accent)' : 'var(--surface3)',
                  transition: 'background 0.18s ease',
                }}>
                  <span style={{
                    position: 'absolute', top: 3, left: on ? 19 : 3,
                    width: 16, height: 16, borderRadius: '50%', background: '#fff',
                    transition: 'left 0.18s ease',
                  }} />
                </span>
              </button>
            )
          })}
        </div>
      )}

      {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 8 }}>{error}</p>}
    </div>
  )
}

// Local copy of EditProfileModal's label so this section can live in the
// clubs feature folder without importing back into profile/.
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 10, marginTop: 26 }}>
      {children}
    </p>
  )
}
