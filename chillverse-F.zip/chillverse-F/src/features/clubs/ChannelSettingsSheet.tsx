// src/features/clubs/ChannelSettingsSheet.tsx
//
// The mini settings sheet for a single channel, opened from the channel's
// gear in the drawer. President and VP only.
//
// Three toggles, per the agreed spec:
//   • Allow members to chat here — off makes it read-only for members;
//     president and VP can still post (announcements, rules).
//   • Allow @everyone / @president / @vp — off blocks those pings from
//     members.
//   • Profanity filter — off relaxes the SOFT tier only. Slurs, hate speech
//     and sexual content stay blocked and still auto-delete, in every channel,
//     with no way to switch that off. The UI says so plainly rather than
//     implying the channel becomes a free-for-all.
//
// All three are enforced server-side (trg_club_channel_post_rules and
// auto_hard_violation_message); these switches only flip the flags.

import { useEffect, useState } from 'react'
import { X, Lock } from 'lucide-react'
import {
  updateClubChannelSettings, setClubChannelMembers, fetchClubChannelMemberIds,
  type ClubChannel, type ClubMemberRow,
} from './clubs'
import { ToggleRow } from './ClubSettingsSections'

interface ChannelSettingsSheetProps {
  open: boolean
  channel: ClubChannel | null
  members: ClubMemberRow[]
  myId: string
  onClose: () => void
  onSaved: (channel: ClubChannel) => void
}

export default function ChannelSettingsSheet({
  open, channel, members, myId, onClose, onSaved,
}: ChannelSettingsSheetProps) {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [allowChat, setAllowChat] = useState(true)
  const [allowPings, setAllowPings] = useState(true)
  const [filterOn, setFilterOn] = useState(true)
  const [channelMembers, setChannelMembers] = useState<string[]>([])
  const [error, setError] = useState('')

  useEffect(() => {
    if (!channel) return
    setName(channel.name)
    setDescription(channel.description ?? '')
    setAllowChat(channel.allow_member_chat)
    setAllowPings(channel.allow_role_pings)
    setFilterOn(channel.profanity_filter)
    setError('')
    if (channel.is_private) {
      fetchClubChannelMemberIds(channel.id).then(setChannelMembers).catch(() => {})
    }
  }, [channel])

  if (!open || !channel) return null

  async function save(patch: Parameters<typeof updateClubChannelSettings>[1], optimistic: Partial<ClubChannel>) {
    if (!channel) return
    setError('')
    try {
      await updateClubChannelSettings(channel.id, patch)
      onSaved({ ...channel, ...optimistic })
    } catch (e: any) {
      setError(e.message)
    }
  }

  async function toggleMember(userId: string) {
    if (!channel) return
    const next = channelMembers.includes(userId)
      ? channelMembers.filter(id => id !== userId)
      : [...channelMembers, userId]
    if (next.length === 0) {
      setError('A private channel needs at least one member.')
      return
    }
    setChannelMembers(next)
    setError('')
    try {
      await setClubChannelMembers(channel.id, next)
    } catch (e: any) {
      setError(e.message)
    }
  }

  const field: React.CSSProperties = {
    width: '100%', background: 'var(--surface2)', border: '1px solid var(--border)',
    boxShadow: 'var(--elev-inset)', borderRadius: 10, padding: '10px 13px', fontSize: 13.5,
    fontWeight: 600, color: 'var(--text)', outline: 'none', boxSizing: 'border-box',
  }
  const label: React.CSSProperties = {
    fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase',
    letterSpacing: '0.06em', marginBottom: 6, marginTop: 16, display: 'block',
  }

  return (
    <>
      <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)', zIndex: 60 }} />
      <div
        role="dialog"
        aria-label={`Settings for ${channel.name}`}
        style={{
          position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 61,
          maxWidth: 560, margin: '0 auto', maxHeight: '88dvh', overflowY: 'auto',
          background: 'var(--surface)', borderRadius: '18px 18px 0 0',
          padding: '10px 18px calc(24px + env(safe-area-inset-bottom))',
          boxShadow: '0 -12px 40px -12px rgba(0,0,0,0.5)',
        }}
      >
        <div style={{ width: 38, height: 4, borderRadius: 2, background: 'var(--surface3)', margin: '0 auto 12px' }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', flex: 1, display: 'flex', alignItems: 'center', gap: 6 }}>
            {channel.is_private && <Lock size={13} style={{ color: 'var(--text-muted)' }} />}
            #{channel.name}
          </span>
          <button onClick={onClose} className="neu-icon" style={{ width: 30, height: 30, border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
            <X size={14} />
          </button>
        </div>

        <ToggleRow
          title="Allow members to chat here"
          hint="Off makes this read-only for members. You and your VPs can still post."
          on={allowChat}
          onChange={next => { setAllowChat(next); save({ allowMemberChat: next }, { allow_member_chat: next }) }}
        />

        <ToggleRow
          title="Allow @everyone, @president and @vp"
          hint="Off stops members pinging the whole club or its leaders in this channel."
          on={allowPings}
          onChange={next => { setAllowPings(next); save({ allowRolePings: next }, { allow_role_pings: next }) }}
        />

        <ToggleRow
          title="Profanity filter"
          hint="Off lets mild swearing through here. Slurs, hate speech and sexual content are still blocked and still auto-deleted — that part can't be switched off."
          on={filterOn}
          onChange={next => { setFilterOn(next); save({ profanityFilter: next }, { profanity_filter: next }) }}
        />

        <label style={label}>Channel name</label>
        <input
          value={name}
          onChange={e => setName(e.target.value.slice(0, 40))}
          style={field}
          onBlur={() => { if (name.trim() && name.trim() !== channel.name) save({ name: name.trim() }, { name: name.trim() }) }}
        />

        <label style={label}>Description</label>
        <textarea
          value={description}
          onChange={e => setDescription(e.target.value.slice(0, 300))}
          rows={2}
          placeholder="What's this channel for?"
          style={{ ...field, resize: 'vertical', fontWeight: 400, lineHeight: 1.4 }}
          onBlur={() => { if (description !== (channel.description ?? '')) save({ description }, { description: description || null }) }}
        />

        {channel.is_private && (
          <>
            <label style={label}>Who's in it</label>
            <div style={{ maxHeight: 200, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {members.filter(m => m.user_id !== myId).map(member => {
                const on = channelMembers.includes(member.user_id)
                return (
                  <button
                    key={member.user_id}
                    onClick={() => toggleMember(member.user_id)}
                    className={on ? 'neu-inset' : 'neu-card'}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px',
                      border: on ? '1px solid var(--accent)' : 'none', borderRadius: 10,
                      cursor: 'pointer', color: 'var(--text)', textAlign: 'left',
                    }}
                  >
                    <span style={{ flex: 1, minWidth: 0, fontSize: 12.5, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {member.display_name || member.username}
                    </span>
                    <span style={{ fontSize: 10.5, color: on ? 'var(--accent)' : 'var(--text-muted)' }}>
                      {on ? 'In' : 'Add'}
                    </span>
                  </button>
                )
              })}
            </div>
          </>
        )}

        {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 12 }}>{error}</p>}
      </div>
    </>
  )
}
