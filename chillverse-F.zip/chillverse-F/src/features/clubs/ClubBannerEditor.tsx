// src/features/clubs/ClubBannerEditor.tsx
//
// The wide banner behind the club photo on the Server Profile page. Locked
// until the club has 30 members, which is enforced in update_club_settings
// too — this component just explains the lock rather than letting someone
// discover it as a red error.
//
// Uploads are downscaled to fit 1MB before they leave the phone (see
// imageCompress.ts); the `club-banners` bucket enforces the same ceiling.
// If a club later drops below 30, a DB trigger unequips the banner and
// deletes the object, so this component may simply find banner_url null.

import { useRef, useState } from 'react'
import { ImagePlus, Lock, Trash2 } from 'lucide-react'
import { uploadClubBanner, updateClubSettings, BANNER_MEMBER_THRESHOLD, type ClubRoom } from './clubs'
import ClubIcon from './clubIcons'

interface ClubBannerEditorProps {
  club: ClubRoom
  userId: string
  memberCount: number
  canEdit: boolean
  onUpdated: (club: ClubRoom) => void
}

export default function ClubBannerEditor({ club, userId, memberCount, canEdit, onUpdated }: ClubBannerEditorProps) {
  const fileRef = useRef<HTMLInputElement>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const unlocked = memberCount >= BANNER_MEMBER_THRESHOLD
  const remaining = BANNER_MEMBER_THRESHOLD - memberCount

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setBusy(true)
    setError('')
    try {
      const url = await uploadClubBanner(userId, file)
      await updateClubSettings(club.id, { bannerUrl: url })
      onUpdated({ ...club, banner_url: url })
    } catch (err: any) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  async function removeBanner() {
    setBusy(true)
    setError('')
    try {
      await updateClubSettings(club.id, { bannerUrl: '' })
      onUpdated({ ...club, banner_url: null })
    } catch (err: any) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{ marginBottom: 4 }}>
      <div
        className="neu-inset"
        style={{
          position: 'relative',
          width: '100%',
          aspectRatio: '16 / 6',
          borderRadius: 14,
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'flex-end',
          // No banner is a flat colour block, the same way an unequipped
          // profile banner reads — not an empty placeholder box.
          background: club.banner_url
            ? `center / cover no-repeat url(${club.banner_url})`
            : 'linear-gradient(135deg, var(--accent-soft, #3a3a44), var(--surface3))',
        }}
      >
        {/* Scrim so the club name stays readable over a busy photo. */}
        {club.banner_url && (
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.15) 55%, transparent 100%)' }} />
        )}

        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 10, padding: '0 12px 11px', width: '100%', minWidth: 0 }}>
          <div
            style={{
              width: 38, height: 38, borderRadius: '30%', overflow: 'hidden', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: club.icon_url ? 'var(--surface)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
              boxShadow: '0 2px 10px -2px rgba(0,0,0,0.6)',
            }}
          >
            <ClubIcon iconKey={club.icon_key} iconUrl={club.icon_url} size={18} />
          </div>
          <span
            style={{
              fontSize: 15, fontWeight: 800, color: '#fff', minWidth: 0,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              textShadow: '0 1px 6px rgba(0,0,0,0.7)',
            }}
          >
            {club.name}
          </span>
        </div>

        {canEdit && unlocked && (
          <div style={{ position: 'absolute', right: 8, top: 8, display: 'flex', gap: 6 }}>
            {club.banner_url && (
              <button
                type="button"
                onClick={removeBanner}
                disabled={busy}
                title="Remove banner"
                className="neu-icon"
                style={{ width: 30, height: 30, borderRadius: '50%', border: 'none', cursor: busy ? 'not-allowed' : 'pointer', color: '#ff6b6b' }}
              >
                <Trash2 size={13} />
              </button>
            )}
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={busy}
              title="Change banner"
              className="neu-icon"
              style={{ width: 30, height: 30, borderRadius: '50%', border: 'none', cursor: busy ? 'not-allowed' : 'pointer', color: 'var(--accent)' }}
            >
              <ImagePlus size={13} />
            </button>
          </div>
        )}

        {canEdit && !unlocked && (
          <div style={{ position: 'absolute', right: 10, top: 9, display: 'flex', alignItems: 'center', gap: 5, color: 'rgba(255,255,255,0.75)' }}>
            <Lock size={12} />
            <span style={{ fontSize: 10.5, fontWeight: 600 }}>{remaining} more to unlock</span>
          </div>
        )}

        <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: 'none' }} />
      </div>

      {busy && <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 5 }}>Working…</p>}
      {error && <p style={{ fontSize: 11, color: '#ff6b6b', marginTop: 5 }}>{error}</p>}
      {canEdit && unlocked && !error && !busy && (
        <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 5 }}>
          Big images get shrunk to fit 1MB automatically. Drop under {BANNER_MEMBER_THRESHOLD} members and the banner comes off.
        </p>
      )}
    </div>
  )
}
