// src/features/clubs/CreateChannelSheet.tsx
//
// Replaces the old "type a name, hit create" modal with a draw-up sheet:
// name, description, optional category, and an optional private toggle that
// requires picking at least one member. Slides from the bottom because that's
// where a thumb is, and because the member picker needs room.
//
// Category and the 5th/6th channel slot both unlock at 30 members — below
// that a club has at most 4 channels and grouping them is noise. The same
// rule is enforced in create_club_channel, so this is guidance, not the gate.

import { useMemo, useState } from 'react'
import { X, Hash, Lock, Check } from 'lucide-react'
import {
  createClubChannel, categoriesUnlocked, channelLimitFor,
  type ClubChannel, type ClubMemberRow,
} from './clubs'

interface CreateChannelSheetProps {
  open: boolean
  onClose: () => void
  roomId: string
  myId: string
  members: ClubMemberRow[]
  channels: ClubChannel[]
  onCreated: (channelId: string) => void
}

export default function CreateChannelSheet({
  open, onClose, roomId, myId, members, channels, onCreated,
}: CreateChannelSheetProps) {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('')
  const [isPrivate, setIsPrivate] = useState(false)
  const [picked, setPicked] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const limit = channelLimitFor(members.length)
  const withCategories = categoriesUnlocked(members.length)
  const atLimit = channels.length >= limit

  // Categories already in use, so the second channel in a group doesn't need
  // the name retyped exactly.
  const existingCategories = useMemo(() => {
    const set = new Set<string>()
    channels.forEach(ch => { if (ch.category) set.add(ch.category) })
    return [...set]
  }, [channels])

  const others = members.filter(m => m.user_id !== myId)
  const canSubmit = name.trim().length > 0 && !atLimit && (!isPrivate || picked.length > 0)

  function reset() {
    setName(''); setDescription(''); setCategory('')
    setIsPrivate(false); setPicked([]); setError('')
  }

  function close() {
    if (busy) return
    reset()
    onClose()
  }

  async function submit() {
    if (!canSubmit) return
    setBusy(true)
    setError('')
    try {
      const id = await createClubChannel(roomId, {
        name: name.trim(),
        description: description.trim(),
        category: withCategories ? category.trim() : null,
        isPrivate,
        memberIds: picked,
      })
      reset()
      onCreated(id)
    } catch (e: any) {
      setError(friendly(e.message))
    } finally {
      setBusy(false)
    }
  }

  if (!open) return null

  const label: React.CSSProperties = {
    fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase',
    letterSpacing: '0.06em', marginBottom: 6, marginTop: 16, display: 'block',
  }
  const field: React.CSSProperties = {
    width: '100%', background: 'var(--surface2)', border: '1px solid var(--border)',
    boxShadow: 'var(--elev-inset)', borderRadius: 10, padding: '10px 13px', fontSize: 13.5,
    fontWeight: 600, color: 'var(--text)', outline: 'none', boxSizing: 'border-box',
  }

  return (
    <>
      <div
        onClick={close}
        style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)', zIndex: 60 }}
      />
      <div
        role="dialog"
        aria-label="Create channel"
        style={{
          position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 61,
          maxWidth: 560, margin: '0 auto', maxHeight: '88dvh', overflowY: 'auto',
          background: 'var(--surface)', borderRadius: '18px 18px 0 0',
          padding: '10px 18px calc(24px + env(safe-area-inset-bottom))',
          boxShadow: '0 -12px 40px -12px rgba(0,0,0,0.5)',
        }}
      >
        {/* Grabber */}
        <div style={{ width: 38, height: 4, borderRadius: 2, background: 'var(--surface3)', margin: '0 auto 12px' }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', flex: 1 }}>Create channel</span>
          <button onClick={close} className="neu-icon" style={{ width: 30, height: 30, border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
            <X size={14} />
          </button>
        </div>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
          {channels.length} of {limit} channels used
          {!withCategories && ' · categories unlock at 30 members'}
        </p>

        {atLimit && (
          <div className="neu-inset" style={{ padding: '9px 12px', marginTop: 12, fontSize: 11.5, color: 'var(--text-dim)' }}>
            This club is at its channel limit. Delete one first, or grow to 30 members for two more slots.
          </div>
        )}

        <label style={label}>Channel name</label>
        <div style={{ position: 'relative' }}>
          <Hash size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            value={name}
            onChange={e => setName(e.target.value.slice(0, 40))}
            placeholder="new-channel"
            maxLength={40}
            autoFocus
            style={{ ...field, paddingLeft: 32 }}
          />
        </div>

        <label style={label}>Description <span style={{ textTransform: 'none', fontWeight: 500 }}>(optional)</span></label>
        <textarea
          value={description}
          onChange={e => setDescription(e.target.value.slice(0, 300))}
          rows={2}
          placeholder="What's this channel for?"
          style={{ ...field, resize: 'vertical', fontWeight: 400, lineHeight: 1.4 }}
        />

        {withCategories && (
          <>
            <label style={label}>Category <span style={{ textTransform: 'none', fontWeight: 500 }}>(optional)</span></label>
            <input
              value={category}
              onChange={e => setCategory(e.target.value.slice(0, 30))}
              placeholder="e.g. Gaming"
              list="club-channel-categories"
              style={field}
            />
            <datalist id="club-channel-categories">
              {existingCategories.map(c => <option key={c} value={c} />)}
            </datalist>
          </>
        )}

        <div className="neu-card" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', border: 'none', marginTop: 18 }}>
          <Lock size={15} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>Private channel</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
              Only you, the people you pick, and club leaders can see it.
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={isPrivate}
            onClick={() => { setIsPrivate(!isPrivate); if (isPrivate) setPicked([]) }}
            style={{
              width: 40, height: 24, borderRadius: 12, border: 'none', cursor: 'pointer',
              background: isPrivate ? 'var(--accent)' : 'var(--surface3)', position: 'relative',
              flexShrink: 0, boxShadow: 'var(--elev-inset)',
            }}
          >
            <span style={{ position: 'absolute', top: 3, left: isPrivate ? 19 : 3, width: 18, height: 18, borderRadius: '50%', background: '#fff', transition: 'left 0.15s' }} />
          </button>
        </div>

        {isPrivate && (
          <>
            <label style={label}>Who's in it — pick at least one</label>
            {others.length === 0 ? (
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>There's nobody else in this club yet.</p>
            ) : (
              <div style={{ maxHeight: 220, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {others.map(member => {
                  const on = picked.includes(member.user_id)
                  return (
                    <button
                      key={member.user_id}
                      onClick={() => setPicked(list => on ? list.filter(id => id !== member.user_id) : [...list, member.user_id])}
                      className={on ? 'neu-inset' : 'neu-card'}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px',
                        border: on ? '1px solid var(--accent)' : 'none', borderRadius: 10,
                        cursor: 'pointer', color: 'var(--text)', textAlign: 'left',
                      }}
                    >
                      <span style={{ flex: 1, minWidth: 0, fontSize: 12.5, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {member.display_name || member.username}
                      </span>
                      {member.role !== 'member' && (
                        <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                          {member.role}
                        </span>
                      )}
                      {on && <Check size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />}
                    </button>
                  )
                })}
              </div>
            )}
            <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 6 }}>
              The president and VPs can always see every channel.
            </p>
          </>
        )}

        {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 12 }}>{error}</p>}

        <button
          onClick={submit}
          disabled={!canSubmit || busy}
          style={{
            width: '100%', marginTop: 18, padding: '12px 0', borderRadius: 12, border: 'none',
            background: 'var(--accent)', color: '#fff', fontSize: 13, fontWeight: 700,
            cursor: canSubmit && !busy ? 'pointer' : 'not-allowed',
            opacity: canSubmit && !busy ? 1 : 0.55,
          }}
        >
          {busy ? 'Creating…' : 'Create channel'}
        </button>
      </div>
    </>
  )
}

function friendly(message: string): string {
  if (message.includes('channel_limit_reached')) return "This club has used all its channel slots."
  if (message.includes('private_channel_needs_member')) return 'Pick at least one person for a private channel.'
  return message
}
