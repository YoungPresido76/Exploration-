// src/features/clubs/clubs.ts
// Thin typed layer over the Clubs RPCs. Clubs are `chat_rooms` with
// type = 'club'. All mutations go through these RPCs — direct table
// writes to chat_rooms/club_channels are blocked by RLS. Reading rooms/
// members/messages/channels still goes straight to the tables, same as
// everywhere else in the app.
//
// Phase 1 (see /areas/chillverse-clubs-redesign.md): every club is
// invite-only, always — join_club always needs a code.
//
// Phase 3: clubs are multi-channel now, capped at 4 (enforced server-
// side in create_club_channel). Every club gets a `general` channel on
// creation, set as chat_rooms.default_channel_id — that's the channel a
// new joiner lands in. See ClubChat.tsx for the channel switcher.
//
// Phase 4: creation supports an uploaded icon (uploadClubIcon, bucket
// 'club-icons') and picking up to 3 extra channels at creation time on
// top of the auto-created `general`. See CreateClubModal.tsx.

import { supabase } from '../../shared/lib/supabase'
import { compressImage, ONE_MB } from '../../shared/lib/imageCompress'

export type ClubRole = 'member' | 'vp' | 'president'

export interface ClubRoom {
  id: string
  name: string
  created_by: string
  is_private: boolean
  max_members: number
  icon_key: string | null
  icon_url: string | null
  join_code: string | null
  slug: string | null
  archived_at: string | null
  grace_started_at: string | null
  created_at: string
  pinned_message_id: string | null
  description: string | null
  welcome_message: string | null
  muted: boolean
  default_channel_id: string | null
  // 0130 — settings overhaul
  banner_url: string | null
  join_mode: ClubJoinMode
  welcome_enabled: boolean
  welcome_channel_id: string | null
  insights_enabled: boolean
  onboarding_enabled: boolean
  // 0148 — may members show this club on their profiles at all
  show_in_member_profiles: boolean
}

/** How outsiders get in. Supersedes the is_private boolean, which the
 *  update_club_settings RPC keeps in sync for anything still reading it. */
export type ClubJoinMode = 'public' | 'invite' | 'apply'

export interface ClubChannel {
  id: string
  room_id: string
  name: string
  position: number
  created_at: string
  created_by: string | null
  // 0130 — per-channel settings
  description: string | null
  category: string | null
  is_private: boolean
  allow_member_chat: boolean
  allow_role_pings: boolean
  profanity_filter: boolean
}

export interface ClubInsights {
  members: number
  joined_7d: number
  messages_7d: number
  messages_30d: number
  active_posters_7d: number
  by_channel: { id: string; name: string; is_private: boolean; messages_7d: number }[]
  top_posters: { id: string; username: string; display_name: string | null; messages: number }[]
}

export interface ClubJoinRequest {
  id: string
  room_id: string
  user_id: string
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
  username: string
  display_name: string | null
  avatar: string | null
}

export interface MyClub extends ClubRoom {
  my_role: ClubRole
  member_count: number
}

export interface ClubMemberRow {
  room_id: string
  user_id: string
  role: ClubRole
  joined_at: string
  username: string
  display_name: string | null
  avatar: string
  presence: string | null
  show_online_activity: boolean
  muted_until: string | null
  /** Emoji from the option this member picked during club onboarding.
   *  Shown beside their name in THIS club's chat only. */
  onboarding_emoji: string | null
}

// Errors raised by the RPCs come through as e.message straight from
// Postgres' `raise exception`. A couple are worth surfacing with
// friendlier copy; everything else passes through as-is.
const FRIENDLY_ERRORS: Record<string, string> = {
  club_limit_reached: "You've reached the 2-club limit for free accounts. Go Pro to create more.",
  club_vp_limit_reached: 'This club already has 2 VPs — demote one before promoting another.',
  channel_limit_reached: 'A club can only have 4 channels — 6 once it hits 30 members.',
  option_needs_channel: 'select at least one channel, users who pick this will go into',
  question_needs_prompt: 'Every question needs something to ask.',
  question_needs_option: 'Every question needs at least one option.',
  option_needs_label: 'Every option needs a label.',
  private_channel_needs_member: 'Pick at least one person for a private channel.',
  banner_locked: 'Banners unlock at 30 members.',
  insights_disabled: 'Turn insights on first.',
  'cannot delete the only channel': "You can't delete a club's last channel.",
  'this club is invite-only': 'This club is invite-only — you need a join code or link.',
  'club is full': 'This club is full.',
  'club not found': "That club doesn't exist, or the code is wrong.",
  'already a member of this club': "They're already a member of this club.",
  'not authorized': "Only the president or VP can do that.",
  'you are already in this club': "You're already in this club.",
  'only the president can add members directly': 'Only the president can add members directly.',
  'icon url required': 'Please choose an image first.',
}

function friendlyError(e: any): Error {
  const msg = e?.message ?? 'Something went wrong'
  return new Error(FRIENDLY_ERRORS[msg] ?? msg)
}

/** The invite link for a club — tapping it from anywhere (WhatsApp, SMS,
 *  etc.) opens the app and, if the person is a member already or joins
 *  successfully, drops them straight into the club. See ClubChat.tsx for
 *  the auto-join-on-load side of this.
 *
 *  Uses the club's slug (e.g. "if-y-2-find-x") instead of its raw UUID
 *  when one is set — every club gets a slug at creation time now, so the
 *  id fallback below only ever applies to pre-migration edge cases where
 *  a slug somehow wasn't backfilled. ClubRouteResolver (see App.tsx)
 *  resolves the slug back to the real room id on load. */
export function buildClubInviteLink(club: Pick<ClubRoom, 'id' | 'slug'>, joinCode: string): string {
  return `${window.location.origin}/clubs/${club.slug ?? club.id}?code=${joinCode}`
}

/** Resolves a club's slug (from a shared invite link) to its real room
 *  id. SECURITY DEFINER on the backend — the person tapping the link
 *  isn't a member yet, so normal RLS wouldn't let them see the row. */
export async function resolveClubSlug(slug: string): Promise<string | null> {
  const { data, error } = await supabase.rpc('resolve_club_slug', { p_slug: slug })
  if (error) throw new Error(error.message)
  return (data as string | null) ?? null
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

/** True if the given route param is already a real room id, as opposed
 *  to a club slug. Used by ClubRouteResolver to decide whether a slug
 *  lookup is needed before rendering the club screens. */
export function isClubRoomId(value: string): boolean {
  return UUID_RE.test(value)
}

export async function fetchMyClubs(userId: string): Promise<MyClub[]> {
  const { data, error } = await supabase
    .from('room_members')
    .select('role, chat_rooms!inner(id,name,created_by,is_private,max_members,icon_key,icon_url,join_code,slug,archived_at,grace_started_at,created_at,pinned_message_id,description,welcome_message,muted,default_channel_id)')
    .eq('user_id', userId)
    .eq('chat_rooms.type', 'club')
  if (error) throw new Error(error.message)

  const rows = (data ?? []) as any[]
  if (rows.length === 0) return []

  const roomIds = rows.map(r => r.chat_rooms.id)
  const { data: counts, error: countErr } = await supabase
    .from('room_members')
    .select('room_id')
    .in('room_id', roomIds)
  if (countErr) throw new Error(countErr.message)

  const countByRoom = new Map<string, number>()
  for (const c of counts ?? []) countByRoom.set(c.room_id, (countByRoom.get(c.room_id) ?? 0) + 1)

  return rows
    .map(r => ({
      ...(r.chat_rooms as ClubRoom),
      my_role: r.role as ClubRole,
      member_count: countByRoom.get(r.chat_rooms.id) ?? 1,
    }))
    .sort((a, b) => (a.archived_at ? 1 : 0) - (b.archived_at ? 1 : 0))
}

export async function fetchClub(roomId: string): Promise<ClubRoom | null> {
  const { data, error } = await supabase
    .from('chat_rooms')
    .select('id,name,created_by,is_private,max_members,icon_key,icon_url,join_code,slug,archived_at,grace_started_at,created_at,pinned_message_id,description,welcome_message,muted,default_channel_id,banner_url,join_mode,welcome_enabled,welcome_channel_id,insights_enabled,onboarding_enabled,show_in_member_profiles')
    .eq('id', roomId)
    .eq('type', 'club')
    .maybeSingle()
  if (error) throw new Error(error.message)
  return data as ClubRoom | null
}

export async function fetchClubMembers(roomId: string): Promise<ClubMemberRow[]> {
  const { data, error } = await supabase
    .from('room_members')
    .select('room_id, user_id, role, joined_at, muted_until, onboarding_emoji, profiles!inner(username, display_name, avatar, presence, show_online_activity)')
    .eq('room_id', roomId)
    .order('role', { ascending: true }) // president, vp, member — matches alphabetical only incidentally; re-sorted below
  if (error) throw new Error(error.message)

  const roleOrder: Record<ClubRole, number> = { president: 0, vp: 1, member: 2 }
  return (data ?? [])
    .map((r: any) => ({
      room_id: r.room_id,
      user_id: r.user_id,
      role: r.role as ClubRole,
      joined_at: r.joined_at,
      muted_until: r.muted_until,
      onboarding_emoji: r.onboarding_emoji ?? null,
      username: r.profiles.username,
      display_name: r.profiles.display_name,
      avatar: r.profiles.avatar,
      presence: r.profiles.presence,
      show_online_activity: r.profiles.show_online_activity ?? false,
    }))
    .sort((a, b) => roleOrder[a.role] - roleOrder[b.role])
}

const MAX_ICON_BYTES = 5 * 1024 * 1024 // 5MB — matches the pattern used for feed images elsewhere

function extensionForFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

/** Uploads a club icon to the `club-icons` storage bucket and returns its
 *  public URL. Path is `{userId}/{uuid}.{ext}` — required by the bucket's
 *  RLS (folder[1] must equal auth.uid()). Called before createClub() so
 *  the URL can go straight into create_club's p_icon_url. */
export async function uploadClubIcon(userId: string, file: File): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('Please pick an image file for the club icon.')
  if (file.size > MAX_ICON_BYTES) throw new Error('Icon image is too large — please use a file under 5MB.')

  // Both club images are capped at 1MB in the bucket. Rather than bounce a
  // camera-roll photo, downscale it and upload the smaller version.
  const compressed = await compressImage(file, { maxBytes: ONE_MB, maxDimension: 1024 })

  const path = `${userId}/${crypto.randomUUID()}.${extensionForFile(compressed)}`
  const { error } = await supabase.storage
    .from('club-icons')
    .upload(path, compressed, { contentType: compressed.type, upsert: false })
  if (error) throw new Error(`Failed to upload icon: ${error.message}`)

  const { data } = supabase.storage.from('club-icons').getPublicUrl(path)
  return data.publicUrl
}

export async function createClub(opts: { name: string; iconUrl?: string; extraChannels?: string[] }): Promise<string> {
  const { data, error } = await supabase.rpc('create_club', {
    p_name: opts.name,
    p_is_private: true,
    p_icon_url: opts.iconUrl ?? null,
    p_extra_channels: opts.extraChannels ?? [],
  })
  if (error) throw friendlyError(error)
  return data as string
}

export async function joinClub(opts: { roomId?: string; code: string }): Promise<string> {
  const { data, error } = await supabase.rpc('join_club', {
    p_room_id: opts.roomId ?? null,
    p_code: opts.code,
  })
  if (error) throw friendlyError(error)
  return data as string
}

export async function leaveClub(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('leave_club', { p_room_id: roomId })
  if (error) throw friendlyError(error)
}

export async function deleteClub(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('delete_club', { p_room_id: roomId })
  if (error) throw friendlyError(error)
}

export async function promoteClubMember(roomId: string, userId: string, newRole: 'member' | 'vp'): Promise<void> {
  const { error } = await supabase.rpc('promote_club_member', { p_room_id: roomId, p_user_id: userId, p_new_role: newRole })
  if (error) throw friendlyError(error)
}

export async function removeClubMember(roomId: string, userId: string): Promise<void> {
  const { error } = await supabase.rpc('remove_club_member', { p_room_id: roomId, p_user_id: userId })
  if (error) throw friendlyError(error)
}

export async function muteClubMember(roomId: string, userId: string): Promise<void> {
  const { error } = await supabase.rpc('mute_club_member', { p_room_id: roomId, p_user_id: userId })
  if (error) throw friendlyError(error)
}

export async function unmuteClubMember(roomId: string, userId: string): Promise<void> {
  const { error } = await supabase.rpc('unmute_club_member', { p_room_id: roomId, p_user_id: userId })
  if (error) throw friendlyError(error)
}

export async function updateClubSettings(roomId: string, opts: {
  name?: string; description?: string; welcomeMessage?: string; muted?: boolean;
  joinMode?: ClubJoinMode; welcomeEnabled?: boolean; welcomeChannelId?: string;
  insightsEnabled?: boolean;
  /** Pass '' to unequip the banner and clear the column. */
  bannerUrl?: string;
  /** The leader's ceiling on whether members may advertise this club on
   *  their profiles. Off wins over any member's own choice. */
  showInMemberProfiles?: boolean;
}): Promise<void> {
  const { error } = await supabase.rpc('update_club_settings', {
    p_room_id: roomId,
    p_name: opts.name ?? null,
    p_description: opts.description ?? null,
    p_welcome_message: opts.welcomeMessage ?? null,
    p_muted: opts.muted ?? null,
    p_join_mode: opts.joinMode ?? null,
    p_welcome_enabled: opts.welcomeEnabled ?? null,
    p_welcome_channel_id: opts.welcomeChannelId ?? null,
    p_insights_enabled: opts.insightsEnabled ?? null,
    p_banner_url: opts.bannerUrl ?? null,
    p_show_in_member_profiles: opts.showInMemberProfiles ?? null,
  })
  if (error) throw friendlyError(error)
}

/** Members a club needs before the president/VP can equip a banner. Drop
 *  back under it and the DB trigger unequips it and deletes the object. */
export const BANNER_MEMBER_THRESHOLD = 30

export async function uploadClubBanner(userId: string, file: File): Promise<string> {
  const compressed = await compressImage(file, { maxBytes: ONE_MB, maxDimension: 1600 })
  const path = `${userId}/${crypto.randomUUID()}.${extensionForFile(compressed)}`
  const { error } = await supabase.storage
    .from('club-banners')
    .upload(path, compressed, { contentType: compressed.type, upsert: false })
  if (error) throw new Error(`Failed to upload banner: ${error.message}`)

  const { data } = supabase.storage.from('club-banners').getPublicUrl(path)
  return data.publicUrl
}

export async function fetchClubInsights(roomId: string): Promise<ClubInsights> {
  const { data, error } = await supabase.rpc('club_insights', { p_room_id: roomId })
  if (error) throw friendlyError(error)
  return data as ClubInsights
}

/* ── Setup suggestions (the cards that replaced the raw stats) ───────── */

export interface ClubSetupSuggestions {
  rules_channel_done: boolean
  onboarding_done: boolean
  member_count: number
  member_goal: number
  members_done: boolean
}

export async function fetchClubSetupSuggestions(roomId: string): Promise<ClubSetupSuggestions> {
  const { data, error } = await supabase.rpc('club_setup_suggestions', { p_room_id: roomId })
  if (error) throw friendlyError(error)
  return data as ClubSetupSuggestions
}

/* ── Onboarding ──────────────────────────────────────────────────────── */

export interface OnboardingOption {
  id: string
  question_id: string
  label: string
  emoji: string | null
  channel_id: string | null
  position: number
}

export interface OnboardingQuestion {
  id: string
  room_id: string
  prompt: string
  position: number
  options: OnboardingOption[]
}

/** Shape the editor sends up — ids are assigned server-side on save. */
export interface OnboardingDraftOption {
  label: string
  emoji: string
  channel_id: string
}
export interface OnboardingDraftQuestion {
  prompt: string
  options: OnboardingDraftOption[]
}

export async function fetchClubOnboarding(roomId: string): Promise<OnboardingQuestion[]> {
  const [questionsRes, optionsRes] = await Promise.all([
    supabase.from('club_onboarding_questions')
      .select('id, room_id, prompt, position')
      .eq('room_id', roomId).order('position', { ascending: true }),
    supabase.from('club_onboarding_options')
      .select('id, question_id, label, emoji, channel_id, position')
      .eq('room_id', roomId).order('position', { ascending: true }),
  ])
  if (questionsRes.error) throw new Error(questionsRes.error.message)
  if (optionsRes.error) throw new Error(optionsRes.error.message)

  const options = (optionsRes.data ?? []) as OnboardingOption[]
  return (questionsRes.data ?? []).map((q: any) => ({
    ...q,
    options: options.filter(o => o.question_id === q.id),
  })) as OnboardingQuestion[]
}

export async function saveClubOnboarding(roomId: string, questions: OnboardingDraftQuestion[]): Promise<void> {
  const { error } = await supabase.rpc('save_club_onboarding', {
    p_room_id: roomId,
    p_questions: questions,
  })
  if (error) throw friendlyError(error)
}

export async function submitClubOnboarding(roomId: string, optionIds: string[]): Promise<void> {
  const { error } = await supabase.rpc('submit_club_onboarding', {
    p_room_id: roomId,
    p_option_ids: optionIds,
  })
  if (error) throw friendlyError(error)
}

/** Which questions this member has already answered — empty means they've
 *  never been through the flow, which is what triggers it on open. */
export async function fetchMyOnboardingAnswers(roomId: string, userId: string): Promise<string[]> {
  const { data, error } = await supabase
    .from('club_onboarding_answers')
    .select('question_id')
    .eq('room_id', roomId)
    .eq('user_id', userId)
  if (error) throw new Error(error.message)
  return (data ?? []).map(r => r.question_id as string)
}

export async function fetchClubJoinRequests(roomId: string): Promise<ClubJoinRequest[]> {
  const { data, error } = await supabase
    .from('club_join_requests')
    .select('id, room_id, user_id, status, created_at, profiles:user_id (username, display_name, avatar)')
    .eq('room_id', roomId)
    .eq('status', 'pending')
    .order('created_at', { ascending: true })
  if (error) throw new Error(error.message)
  return (data ?? []).map((r: any) => ({
    id: r.id,
    room_id: r.room_id,
    user_id: r.user_id,
    status: r.status,
    created_at: r.created_at,
    username: r.profiles?.username ?? 'someone',
    display_name: r.profiles?.display_name ?? null,
    avatar: r.profiles?.avatar ?? null,
  }))
}

export async function reviewClubJoinRequest(requestId: string, approve: boolean): Promise<void> {
  const { error } = await supabase.rpc('review_club_join_request', {
    p_request_id: requestId,
    p_approve: approve,
  })
  if (error) throw friendlyError(error)
}

export async function requestClubJoin(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('request_club_join', { p_room_id: roomId })
  if (error) throw friendlyError(error)
}

/** Swaps the club's icon/photo — president OR VP, and usable any time
 *  (not just at creation). Pass the public URL returned by uploadClubIcon. */
export async function updateClubIcon(roomId: string, iconUrl: string): Promise<void> {
  const { error } = await supabase.rpc('update_club_icon', { p_room_id: roomId, p_icon_url: iconUrl })
  if (error) throw friendlyError(error)
}

/** President-only: adds someone straight into the club from Club Info,
 *  no invite link/code needed — typically picked from the president's own
 *  DM contact list. */
export async function addClubMemberDirect(roomId: string, userId: string): Promise<void> {
  const { error } = await supabase.rpc('club_add_member', { p_room_id: roomId, p_user_id: userId })
  if (error) throw friendlyError(error)
}

export interface DmContact {
  id: string
  username: string
  display_name: string | null
  avatar: string
}

/** The president's own DM contacts — the people they already chat with
 *  one-on-one — used to power "add members from your chat list" on the
 *  Club Info screen. Mirrors the room lookup Chat.tsx does for the DM
 *  list, just trimmed to the other person's profile. */
export async function fetchDmContacts(userId: string): Promise<DmContact[]> {
  const { data: memberRows, error: memErr } = await supabase
    .from('room_members').select('room_id').eq('user_id', userId)
  if (memErr) throw new Error(memErr.message)
  const roomIds = (memberRows ?? []).map(r => r.room_id)
  if (!roomIds.length) return []

  const { data: dmRooms, error: roomErr } = await supabase
    .from('chat_rooms').select('id').eq('type', 'dm').in('id', roomIds)
  if (roomErr) throw new Error(roomErr.message)
  const dmRoomIds = (dmRooms ?? []).map(r => r.id)
  if (!dmRoomIds.length) return []

  const { data: otherMembers, error: otherErr } = await supabase
    .from('room_members')
    .select('user_id, profiles!inner(username, display_name, avatar)')
    .in('room_id', dmRoomIds)
    .neq('user_id', userId)
  if (otherErr) throw new Error(otherErr.message)

  const seen = new Set<string>()
  const contacts: DmContact[] = []
  for (const r of (otherMembers ?? []) as any[]) {
    if (seen.has(r.user_id)) continue
    seen.add(r.user_id)
    contacts.push({ id: r.user_id, username: r.profiles.username, display_name: r.profiles.display_name, avatar: r.profiles.avatar })
  }
  return contacts
}

export async function regenerateClubCode(roomId: string): Promise<string> {
  const { data, error } = await supabase.rpc('regenerate_club_code', { p_room_id: roomId })
  if (error) throw friendlyError(error)
  return data as string
}

export async function transferClubOwnership(roomId: string, newPresidentId: string): Promise<void> {
  const { error } = await supabase.rpc('transfer_club_ownership', { p_room_id: roomId, p_new_president_id: newPresidentId })
  if (error) throw friendlyError(error)
}

export async function clearClubChat(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('clear_club_chat', { p_room_id: roomId })
  if (error) throw friendlyError(error)
}

export async function clubPinMessage(roomId: string, messageId: string): Promise<void> {
  const { error } = await supabase.rpc('club_pin_message', { p_room_id: roomId, p_message_id: messageId })
  if (error) throw friendlyError(error)
}

export async function clubUnpinMessage(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('club_unpin_message', { p_room_id: roomId })
  if (error) throw friendlyError(error)
}

export async function clubDeleteMessage(messageId: string): Promise<void> {
  const { error } = await supabase.rpc('club_delete_message', { p_message_id: messageId })
  if (error) throw friendlyError(error)
}

// ── Channels (Phase 3) ──────────────────────────────────────────────────

export async function fetchClubChannels(roomId: string): Promise<ClubChannel[]> {
  const { data, error } = await supabase
    .from('club_channels')
    .select('id, room_id, name, position, created_at, created_by, description, category, is_private, allow_member_chat, allow_role_pings, profanity_filter')
    .eq('room_id', roomId)
    .order('position', { ascending: true })
  if (error) throw new Error(error.message)
  return (data ?? []) as ClubChannel[]
}

export interface NewChannelInput {
  name: string
  description?: string
  category?: string | null
  isPrivate?: boolean
  /** Required when isPrivate — the creator is added automatically on top. */
  memberIds?: string[]
}

export async function createClubChannel(roomId: string, input: NewChannelInput | string): Promise<string> {
  const opts: NewChannelInput = typeof input === 'string' ? { name: input } : input
  const { data, error } = await supabase.rpc('create_club_channel', {
    p_room_id: roomId,
    p_name: opts.name,
    p_description: opts.description?.trim() || null,
    p_category: opts.category?.trim() || null,
    p_is_private: opts.isPrivate ?? false,
    p_member_ids: opts.isPrivate ? (opts.memberIds ?? []) : null,
  })
  if (error) throw friendlyError(error)
  return data as string
}

/** Channels a club may have. Rises with size — categories only start earning
 *  their keep once there are enough channels to group. */
export const CHANNEL_CATEGORY_THRESHOLD = 30

export function channelLimitFor(memberCount: number): number {
  return memberCount >= CHANNEL_CATEGORY_THRESHOLD ? 6 : 4
}

export function categoriesUnlocked(memberCount: number): boolean {
  return memberCount >= CHANNEL_CATEGORY_THRESHOLD
}

export interface ChannelSettingsPatch {
  name?: string
  description?: string | null
  category?: string | null
  allowMemberChat?: boolean
  allowRolePings?: boolean
  profanityFilter?: boolean
}

export async function updateClubChannelSettings(channelId: string, patch: ChannelSettingsPatch): Promise<void> {
  const { error } = await supabase.rpc('update_club_channel_settings', {
    p_channel_id: channelId,
    p_name: patch.name ?? null,
    p_description: patch.description ?? null,
    p_category: patch.category ?? null,
    p_allow_member_chat: patch.allowMemberChat ?? null,
    p_allow_role_pings: patch.allowRolePings ?? null,
    p_profanity_filter: patch.profanityFilter ?? null,
  })
  if (error) throw friendlyError(error)
}

export async function setClubChannelMembers(channelId: string, memberIds: string[]): Promise<void> {
  const { error } = await supabase.rpc('set_club_channel_members', {
    p_channel_id: channelId,
    p_member_ids: memberIds,
  })
  if (error) throw friendlyError(error)
}

export async function fetchClubChannelMemberIds(channelId: string): Promise<string[]> {
  const { data, error } = await supabase
    .from('club_channel_members')
    .select('user_id')
    .eq('channel_id', channelId)
  if (error) throw new Error(error.message)
  return (data ?? []).map(r => r.user_id as string)
}

export async function renameClubChannel(channelId: string, name: string): Promise<void> {
  const { error } = await supabase.rpc('rename_club_channel', { p_channel_id: channelId, p_name: name })
  if (error) throw friendlyError(error)
}

export async function deleteClubChannel(channelId: string): Promise<void> {
  const { error } = await supabase.rpc('delete_club_channel', { p_channel_id: channelId })
  if (error) throw friendlyError(error)
}

export async function setDefaultClubChannel(roomId: string, channelId: string): Promise<void> {
  const { error } = await supabase.rpc('set_default_club_channel', { p_room_id: roomId, p_channel_id: channelId })
  if (error) throw friendlyError(error)
}

// ── Per-channel read state ──────────────────────────────────────────────

export interface ChannelUnread {
  channel_id: string
  unread_count: number
  last_message_at: string | null
}

/** Unread counts for every channel in a club, in one round trip. Counts
 *  exclude my own messages and deleted ones; a channel I've never opened
 *  counts everything. */
export async function fetchChannelUnreads(roomId: string): Promise<ChannelUnread[]> {
  const { data, error } = await supabase.rpc('get_club_channel_unreads', { p_room_id: roomId })
  if (error) throw friendlyError(error)
  return (data ?? []) as ChannelUnread[]
}

/** Move my read position in one channel to now. Separate from
 *  room_members.last_read_at, which still drives the Clubs list badge. */
export async function markChannelRead(channelId: string): Promise<void> {
  const { data: auth } = await supabase.auth.getUser()
  const uid = auth.user?.id
  if (!uid) return
  const { error } = await supabase
    .from('club_channel_reads')
    .upsert({ user_id: uid, channel_id: channelId, last_read_at: new Date().toISOString() },
      { onConflict: 'user_id,channel_id' })
  if (error) console.error('Failed to mark channel read:', error.message)
}
