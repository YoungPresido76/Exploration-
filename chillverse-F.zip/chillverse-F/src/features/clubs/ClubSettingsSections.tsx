// src/features/clubs/ClubSettingsSections.tsx
//
// The individual pages behind the Club Settings hub, plus the two primitives
// (Toggle, SettingsRow) they share with ClubSettings.tsx itself. Split out
// because the hub was already a long file and each of these is a small
// self-contained screen.
//
// Access / Engagement / Insights all follow the same shape: read from the
// club row, write through updateClubSettings, hand the fresh row back up so
// the hub's copy stays in step.

import { useEffect, useState, type CSSProperties, type ReactNode } from 'react'
import { ChevronRight, Globe, Lock, Mail, Check, X, CheckCircle2 } from 'lucide-react'
import {
  updateClubSettings, fetchClubSetupSuggestions, fetchClubJoinRequests, reviewClubJoinRequest,
  type ClubRoom, type ClubChannel, type ClubJoinMode, type ClubSetupSuggestions, type ClubJoinRequest,
} from './clubs'
import ClubOnboardingEditor from './ClubOnboardingEditor'

/* ── shared primitives ─────────────────────────────────────────────────── */

export const sectionTitle: CSSProperties = {
  fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase',
  letterSpacing: '0.06em', marginBottom: 8, marginTop: 20,
}

export const inputStyle: CSSProperties = {
  width: '100%', background: 'var(--surface2)', border: '1px solid var(--border)',
  boxShadow: 'var(--elev-inset)', borderRadius: 10, padding: '10px 13px', fontSize: 13.5,
  fontWeight: 600, color: 'var(--text)', outline: 'none', boxSizing: 'border-box',
}

export function Toggle({ on, onChange, disabled }: { on: boolean; onChange: (next: boolean) => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      disabled={disabled}
      onClick={() => onChange(!on)}
      style={{
        width: 40, height: 24, borderRadius: 12, border: 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        background: on ? 'var(--accent)' : 'var(--surface3)',
        position: 'relative', flexShrink: 0, boxShadow: 'var(--elev-inset)',
        opacity: disabled ? 0.5 : 1,
      }}
    >
      <span style={{ position: 'absolute', top: 3, left: on ? 19 : 3, width: 18, height: 18, borderRadius: '50%', background: '#fff', transition: 'left 0.15s' }} />
    </button>
  )
}

/** One tappable row on the hub: icon, label, optional value, chevron. */
export function SettingsRow({ icon, label, hint, value, onClick }: {
  icon: ReactNode; label: string; hint?: string; value?: string; onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="neu-card"
      style={{
        display: 'flex', alignItems: 'center', gap: 11, width: '100%',
        padding: '12px 14px', border: 'none', cursor: 'pointer', color: 'var(--text)',
        marginBottom: 8, textAlign: 'left',
      }}
    >
      <span style={{ color: 'var(--text-dim)', display: 'flex', flexShrink: 0 }}>{icon}</span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <span style={{ display: 'block', fontSize: 13, fontWeight: 700 }}>{label}</span>
        {hint && <span style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginTop: 1 }}>{hint}</span>}
      </span>
      {value && <span style={{ fontSize: 12, color: 'var(--text-muted)', flexShrink: 0 }}>{value}</span>}
      <ChevronRight size={15} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
    </button>
  )
}

/** A toggle laid out like a card row, for use inside a section. */
export function ToggleRow({ title, hint, on, onChange, disabled }: {
  title: string; hint?: string; on: boolean; onChange: (next: boolean) => void; disabled?: boolean
}) {
  return (
    <div className="neu-card" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', border: 'none', marginBottom: 8 }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{title}</div>
        {hint && <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2, lineHeight: 1.4 }}>{hint}</div>}
      </div>
      <Toggle on={on} onChange={onChange} disabled={disabled} />
    </div>
  )
}

/* ── Access ────────────────────────────────────────────────────────────── */

const JOIN_MODES: { key: ClubJoinMode; label: string; blurb: string; icon: ReactNode }[] = [
  { key: 'public', label: 'Public', blurb: 'Anyone can walk straight in.', icon: <Globe size={17} /> },
  { key: 'invite', label: 'Invite only', blurb: 'Only people with the link or code get in.', icon: <Lock size={17} /> },
  { key: 'apply', label: 'Apply to join', blurb: 'People ask first; you approve or decline.', icon: <Mail size={17} /> },
]

export function AccessSection({ club, canEdit, onUpdated }: {
  club: ClubRoom; canEdit: boolean; onUpdated: (club: ClubRoom) => void
}) {
  const [mode, setMode] = useState<ClubJoinMode>(club.join_mode ?? 'invite')
  const [requests, setRequests] = useState<ClubJoinRequest[]>([])
  const [error, setError] = useState('')
  const [busyId, setBusyId] = useState<string | null>(null)
  const [showOnProfiles, setShowOnProfiles] = useState(club.show_in_member_profiles ?? true)

  useEffect(() => { setShowOnProfiles(club.show_in_member_profiles ?? true) }, [club.show_in_member_profiles])

  async function toggleProfileVisibility(next: boolean) {
    if (!canEdit) return
    setShowOnProfiles(next)
    setError('')
    try {
      await updateClubSettings(club.id, { showInMemberProfiles: next })
      onUpdated({ ...club, show_in_member_profiles: next })
    } catch (e: any) {
      setShowOnProfiles(!next)
      setError(e.message)
    }
  }

  useEffect(() => {
    if (mode !== 'apply') { setRequests([]); return }
    fetchClubJoinRequests(club.id).then(setRequests).catch(() => {})
  }, [club.id, mode])

  async function pick(next: ClubJoinMode) {
    if (!canEdit || next === mode) return
    const previous = mode
    setMode(next)
    setError('')
    try {
      await updateClubSettings(club.id, { joinMode: next })
      onUpdated({ ...club, join_mode: next, is_private: next !== 'public' })
    } catch (e: any) {
      setMode(previous)
      setError(e.message)
    }
  }

  async function review(request: ClubJoinRequest, approve: boolean) {
    setBusyId(request.id)
    setError('')
    try {
      await reviewClubJoinRequest(request.id, approve)
      setRequests(list => list.filter(r => r.id !== request.id))
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusyId(null)
    }
  }

  return (
    <>
      <p style={{ fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.5, marginBottom: 14 }}>
        How can people join your club?
      </p>

      {JOIN_MODES.map(option => {
        const active = mode === option.key
        return (
          <button
            key={option.key}
            onClick={() => pick(option.key)}
            disabled={!canEdit}
            className={active ? 'neu-inset' : 'neu-card'}
            style={{
              display: 'flex', alignItems: 'center', gap: 12, width: '100%', marginBottom: 8,
              padding: '13px 14px', border: active ? '1px solid var(--accent)' : 'none',
              borderRadius: 12, cursor: canEdit ? 'pointer' : 'default', textAlign: 'left',
              color: 'var(--text)', opacity: canEdit ? 1 : 0.7,
            }}
          >
            <span style={{ color: active ? 'var(--accent)' : 'var(--text-dim)', display: 'flex', flexShrink: 0 }}>{option.icon}</span>
            <span style={{ flex: 1, minWidth: 0 }}>
              <span style={{ display: 'block', fontSize: 13, fontWeight: 700 }}>{option.label}</span>
              <span style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{option.blurb}</span>
            </span>
            {active && <Check size={15} style={{ color: 'var(--accent)', flexShrink: 0 }} />}
          </button>
        )
      })}

      {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 8 }}>{error}</p>}

      {/* The club's ceiling on profile visibility. Members each choose
          whether to show a club on their own profile (Edit Profile), but
          this switch is above that: off means nobody advertises this club
          anywhere, whatever they picked. For a club that isn't recruiting,
          that's the point. */}
      <div style={{ marginTop: 16 }}>
        <ToggleRow
          title="Show on member profiles"
          hint="Lets members display this club on their profile. Turn it off and the club stays off everyone's profile, whatever they've picked."
          on={showOnProfiles}
          disabled={!canEdit}
          onChange={toggleProfileVisibility}
        />
      </div>

      {mode === 'apply' && (
        <>
          <div style={sectionTitle}>Pending applications</div>
          {requests.length === 0 ? (
            <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Nobody's waiting right now.</p>
          ) : requests.map(request => (
            <div key={request.id} className="neu-card" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', border: 'none', marginBottom: 8 }}>
              <span style={{ flex: 1, minWidth: 0, fontSize: 12.5, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {request.display_name || request.username}
              </span>
              <button
                onClick={() => review(request, true)}
                disabled={busyId === request.id}
                title="Approve"
                className="neu-icon"
                style={{ width: 30, height: 30, borderRadius: '50%', border: 'none', cursor: 'pointer', color: '#3ecf8e' }}
              >
                <Check size={14} />
              </button>
              <button
                onClick={() => review(request, false)}
                disabled={busyId === request.id}
                title="Decline"
                className="neu-icon"
                style={{ width: 30, height: 30, borderRadius: '50%', border: 'none', cursor: 'pointer', color: '#ff6b6b' }}
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </>
      )}
    </>
  )
}

/* ── Engagement ────────────────────────────────────────────────────────── */

const DEFAULT_WELCOME =
  'Welcome {display_name} to {club_name}! You are member #{member_count}. I hope you enjoy your stay 🎉'

export function EngagementSection({ club, channels, canEdit, onUpdated, onOnboardingSaved }: {
  club: ClubRoom; channels: ClubChannel[]; canEdit: boolean
  onUpdated: (club: ClubRoom) => void
  onOnboardingSaved?: () => void
}) {
  const [enabled, setEnabled] = useState(club.welcome_enabled ?? true)
  const [message, setMessage] = useState(club.welcome_message ?? DEFAULT_WELCOME)
  const [channelId, setChannelId] = useState(club.welcome_channel_id ?? club.default_channel_id ?? '')
  const [error, setError] = useState('')

  // A private channel is a bad home for a welcome — the new member can't see
  // it, and the greeting would advertise a channel they're not in.
  const options = channels.filter(ch => !ch.is_private)

  async function save(patch: Parameters<typeof updateClubSettings>[1], optimistic: Partial<ClubRoom>) {
    setError('')
    try {
      await updateClubSettings(club.id, patch)
      onUpdated({ ...club, ...optimistic })
    } catch (e: any) {
      setError(e.message)
    }
  }

  return (
    <>
      <ToggleRow
        title="Welcome message"
        hint="Posted the first time someone joins the club."
        on={enabled}
        disabled={!canEdit}
        onChange={next => { setEnabled(next); save({ welcomeEnabled: next }, { welcome_enabled: next }) }}
      />

      {enabled && (
        <>
          <div style={sectionTitle}>Message</div>
          <textarea
            value={message}
            onChange={e => setMessage(e.target.value)}
            disabled={!canEdit}
            rows={3}
            style={{ ...inputStyle, resize: 'vertical', fontWeight: 400, lineHeight: 1.4 }}
            onBlur={() => {
              if (message !== (club.welcome_message ?? DEFAULT_WELCOME)) {
                save({ welcomeMessage: message }, { welcome_message: message })
              }
            }}
          />
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 4 }}>
            Placeholders: <code>{'{display_name}'}</code> <code>{'{club_name}'}</code> <code>{'{member_count}'}</code>
          </p>
          {canEdit && (
            <button
              onClick={() => { setMessage(DEFAULT_WELCOME); save({ welcomeMessage: DEFAULT_WELCOME }, { welcome_message: DEFAULT_WELCOME }) }}
              style={{ marginTop: 6, background: 'none', border: 'none', color: 'var(--accent)', fontSize: 11.5, fontWeight: 700, cursor: 'pointer', padding: 0 }}
            >
              Reset to default
            </button>
          )}

          <div style={sectionTitle}>Show it in</div>
          <select
            value={channelId}
            disabled={!canEdit}
            onChange={e => {
              const next = e.target.value
              setChannelId(next)
              if (next) save({ welcomeChannelId: next }, { welcome_channel_id: next })
            }}
            style={inputStyle}
          >
            <option value="">Club default channel</option>
            {options.map(ch => <option key={ch.id} value={ch.id}>#{ch.name}</option>)}
          </select>
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 4 }}>
            Private channels can't be picked — a new member wouldn't be able to see the greeting.
          </p>
        </>
      )}

      {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 10 }}>{error}</p>}

      <div style={{ height: 1, background: 'var(--border)', margin: '22px 0 18px' }} />

      <ClubOnboardingEditor
        roomId={club.id}
        channels={channels}
        canEdit={canEdit}
        onSaved={() => {
          onUpdated({ ...club, onboarding_enabled: true })
          onOnboardingSaved?.()
        }}
      />
    </>
  )
}

/* ── Channel insights ──────────────────────────────────────────────────── */

export function InsightsSection({ club, canEdit, onUpdated }: {
  club: ClubRoom; canEdit: boolean; onUpdated: (club: ClubRoom) => void
}) {
  const [enabled, setEnabled] = useState(club.insights_enabled ?? false)
  const [data, setData] = useState<ClubSetupSuggestions | null>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => { setEnabled(club.insights_enabled ?? false) }, [club.insights_enabled])

  // Keyed off the SAVED value, not the switch position — flipping the switch
  // optimistically and fetching straight away raced the write, and the RPC
  // still saw insights_enabled = false.
  useEffect(() => {
    if (!club.insights_enabled) { setData(null); return }
    let cancelled = false
    setLoading(true)
    setError('')
    fetchClubSetupSuggestions(club.id)
      .then(fresh => { if (!cancelled) setData(fresh) })
      .catch(e => { if (!cancelled) setError(friendlyInsightsError(e.message)) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [club.id, club.insights_enabled, club.onboarding_enabled])

  async function toggle(next: boolean) {
    if (saving) return
    setSaving(true)
    setError('')
    try {
      await updateClubSettings(club.id, { insightsEnabled: next })
      setEnabled(next)
      onUpdated({ ...club, insights_enabled: next })
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <ToggleRow
        title="Channel insights"
        hint="When on, the president and VPs can see how the club is doing. Members never see this."
        on={enabled}
        disabled={!canEdit || saving}
        onChange={toggle}
      />

      {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 8 }}>{error}</p>}
      {club.insights_enabled && loading && (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 12 }}>Checking…</p>
      )}

      {club.insights_enabled && data && (
        <>
          <div style={sectionTitle}>Suggestions</div>

          <SuggestionCard
            image={SUGGESTION_IMAGES.rules}
            text="Make a rule channel for your club"
            done={data.rules_channel_done}
          />
          <SuggestionCard
            image={SUGGESTION_IMAGES.onboarding}
            text="Create onboarding for your members, why?, why not! 🙂🤔"
            done={data.onboarding_done}
          />
          <SuggestionCard
            image={SUGGESTION_IMAGES.members}
            text={`Let's get this club on a roll, have ${data.member_count}/${data.member_goal} members`}
            done={data.members_done}
          />
        </>
      )}
    </>
  )
}

const SUGGESTION_IMAGES = {
  rules: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/Victor_vk.jpg',
  onboarding: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/Rella.jpg',
  members: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/Harrison.jpg',
}

/** One suggestion: small square image, the line of copy, and a tick once the
 *  club has actually done the thing. Each `done` flag is computed live in
 *  club_setup_suggestions, so nothing here needs to be marked off by hand. */
function SuggestionCard({ image, text, done }: { image: string; text: string; done: boolean }) {
  return (
    <div
      className="neu-card"
      style={{
        display: 'flex', alignItems: 'center', gap: 11, padding: '11px 13px',
        border: 'none', marginBottom: 8, opacity: done ? 0.72 : 1,
      }}
    >
      <img
        src={image}
        alt=""
        loading="lazy"
        style={{ width: 42, height: 42, borderRadius: 10, objectFit: 'cover', flexShrink: 0, background: 'var(--surface2)' }}
      />
      <span
        style={{
          flex: 1, minWidth: 0, fontSize: 12.5, fontWeight: 600, color: 'var(--text)',
          lineHeight: 1.4, textDecoration: done ? 'line-through' : 'none',
        }}
      >
        {text}
      </span>
      {done && <CheckCircle2 size={17} style={{ color: '#3ecf8e', flexShrink: 0 }} />}
    </div>
  )
}

function friendlyInsightsError(message: string): string {
  if (message.includes('insights_disabled')) return 'Turn insights on to see the numbers.'
  if (message.includes('not authorized')) return 'Only the president and VPs can see insights.'
  return message
}

