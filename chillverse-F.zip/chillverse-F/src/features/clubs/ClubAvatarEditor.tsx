// src/features/clubs/ClubAvatarEditor.tsx
// The large, centered club photo/icon shown at the top of the Club Info
// and Club Settings profile-style pages. President and VP can swap it any
// time (not just at creation) — tapping the camera badge opens a file
// picker, uploads to the `club-icons` bucket, and saves it via
// update_club_icon. Read-only members just see the icon, no badge.

import { useRef, useState } from 'react'
import { Camera } from 'lucide-react'
import { uploadClubIcon, updateClubIcon, type ClubRoom } from './clubs'
import ClubIcon from './clubIcons'

interface ClubAvatarEditorProps {
  club: ClubRoom
  userId: string
  canEdit: boolean
  onUpdated: (club: ClubRoom) => void
  size?: number
}

export default function ClubAvatarEditor({ club, userId, canEdit, onUpdated, size = 96 }: ClubAvatarEditorProps) {
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState('')

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError('')
    try {
      const url = await uploadClubIcon(userId, file)
      await updateClubIcon(club.id, url)
      onUpdated({ ...club, icon_url: url, icon_key: null })
    } catch (err: any) {
      setError(err.message)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
        <div
          className="neu-card"
          style={{
            width: size, height: size, borderRadius: '30%', overflow: 'hidden',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: club.icon_url ? 'var(--surface)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
            color: '#fff',
          }}
        >
          <ClubIcon iconKey={club.icon_key} iconUrl={club.icon_url} size={Math.round(size * 0.42)} />
        </div>
        {canEdit && (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            title="Change club photo"
            className="neu-icon"
            style={{
              position: 'absolute', bottom: -4, right: -4, width: 32, height: 32, borderRadius: '50%',
              cursor: uploading ? 'not-allowed' : 'pointer', color: 'var(--accent)', opacity: uploading ? 0.6 : 1,
            }}
          >
            <Camera size={14} />
          </button>
        )}
        <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: 'none' }} />
      </div>
      {uploading && <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>Uploading…</span>}
      {error && <span style={{ fontSize: 11, color: '#ff6b6b', textAlign: 'center', maxWidth: 220 }}>{error}</span>}
    </div>
  )
}
