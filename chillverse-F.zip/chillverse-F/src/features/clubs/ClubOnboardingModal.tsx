// src/features/clubs/ClubOnboardingModal.tsx
//
// What a member actually sees: the club's onboarding questions, one card
// each, tap an option, done. Shown once — the moment they've answered, the
// answers table has rows for them and it never opens again.
//
// Picking an option puts them in that channel (submit_club_onboarding does
// the work, including the membership row for private channels) and pins that
// option's emoji beside their name in this club's chat.
//
// Skippable on purpose. A club quiz that traps someone out of the chat until
// they answer is a worse first impression than no quiz at all.

import { useState } from 'react'
import { X } from 'lucide-react'
import { submitClubOnboarding, type OnboardingQuestion } from './clubs'

interface ClubOnboardingModalProps {
  roomId: string
  questions: OnboardingQuestion[]
  clubName: string
  onDone: () => void
  onSkip: () => void
}

export default function ClubOnboardingModal({
  roomId, questions, clubName, onDone, onSkip,
}: ClubOnboardingModalProps) {
  const [picked, setPicked] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const answeredAll = questions.every(q => picked[q.id])

  async function finish() {
    setBusy(true)
    setError('')
    try {
      await submitClubOnboarding(roomId, Object.values(picked))
      onDone()
    } catch (e: any) {
      setError(e.message)
      setBusy(false)
    }
  }

  return (
    <>
      <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 80 }} />
      <div
        role="dialog"
        aria-label={`Welcome to ${clubName}`}
        style={{
          position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 81,
          maxWidth: 560, margin: '0 auto', maxHeight: '90dvh', overflowY: 'auto',
          background: 'var(--surface)', borderRadius: '18px 18px 0 0',
          padding: '10px 18px calc(24px + env(safe-area-inset-bottom))',
          boxShadow: '0 -12px 40px -12px rgba(0,0,0,0.5)',
        }}
      >
        <div style={{ width: 38, height: 4, borderRadius: 2, background: 'var(--surface3)', margin: '0 auto 12px' }} />

        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 14 }}>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)' }}>Welcome to {clubName}</p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>
              A couple of quick questions so we know where to put you.
            </p>
          </div>
          <button onClick={onSkip} aria-label="Skip" className="neu-icon" style={{ width: 30, height: 30, border: 'none', cursor: 'pointer', color: 'var(--text-dim)', flexShrink: 0 }}>
            <X size={14} />
          </button>
        </div>

        {questions.map(question => (
          <div key={question.id} style={{ marginBottom: 16 }}>
            <p style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', marginBottom: 8 }}>{question.prompt}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {question.options.map(option => {
                const on = picked[question.id] === option.id
                return (
                  <button
                    key={option.id}
                    onClick={() => setPicked(p => ({ ...p, [question.id]: option.id }))}
                    className={on ? 'neu-inset' : 'neu-card'}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 10, padding: '11px 13px',
                      border: on ? '1px solid var(--accent)' : 'none', borderRadius: 11,
                      cursor: 'pointer', color: 'var(--text)', textAlign: 'left',
                    }}
                  >
                    {option.emoji && <span style={{ fontSize: 16, flexShrink: 0 }}>{option.emoji}</span>}
                    <span style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{option.label}</span>
                  </button>
                )
              })}
            </div>
          </div>
        ))}

        {error && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginBottom: 10 }}>{error}</p>}

        <button
          onClick={finish}
          disabled={!answeredAll || busy}
          style={{
            width: '100%', padding: '12px 0', borderRadius: 12, border: 'none',
            background: 'var(--accent)', color: '#fff', fontSize: 13, fontWeight: 700,
            cursor: answeredAll && !busy ? 'pointer' : 'not-allowed',
            opacity: answeredAll && !busy ? 1 : 0.55,
          }}
        >
          {busy ? 'Setting you up…' : 'Done'}
        </button>
        <button
          onClick={onSkip}
          style={{ width: '100%', marginTop: 8, padding: '9px 0', background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
        >
          Skip for now
        </button>
      </div>
    </>
  )
}
