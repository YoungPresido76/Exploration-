// src/features/clubs/ClubChat.tsx
// Dedicated Clubs chat screen. Messages render through the exact same
// MessageBurst/MessageLine components Global Chat and DMs use (see
// features/chat/MessageBubble.tsx) — same bubbles, same grouping, same
// long-press/right-click-to-open-menu interaction. Everything else here
// (header, banners, composer, club-specific realtime) is Clubs-specific.

import { useState, useRef, useEffect, useLayoutEffect, useCallback, useMemo, Fragment } from 'react'
import { useParams, useNavigate, useSearchParams } from 'react-router-dom'
import { ArrowLeft, Send, Pin, PinOff, Reply, X, Trash2, Flag, Archive, Settings, Menu, Hash, Copy, Check, AtSign, UserPlus, MessageCircle } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { supabase } from '../../shared/lib/supabase'
import Toast, { useToast } from '../../shared/components/Toast'
import ReportModal from '../safety/ReportModal'
import ReactorsSheet from '../chat/ReactorsSheet'
import { useAuth } from '../auth/useAuth'
import { markChatSeen } from '../chat/useChatUnreadBadge'
import { useProfilePreview } from '../../context/ProfilePreview'
import { containsProfanity, PROFANITY_BLOCKED_MESSAGE } from '../../shared/lib/profanityFilter'
import { notifyMention } from '../achievements/achievements'
import {
  type Message, type GroupedMessage, type ReadReceipt, type MessageReaction,
  groupMessages, MessageBurst, Avatar,
} from '../chat/MessageBubble'
import type { MentionMember } from '../chat/messageContent'
import {
  fetchClub, fetchClubMembers, clubPinMessage, clubUnpinMessage, clubDeleteMessage, joinClub,
  fetchClubChannels, createClubChannel, renameClubChannel, deleteClubChannel, setDefaultClubChannel,
  fetchClubOnboarding, fetchMyOnboardingAnswers, type OnboardingQuestion,
  fetchChannelUnreads, markChannelRead,
  type ClubRoom, type ClubMemberRow, type ClubRole, type ClubChannel,
} from './clubs'
import ClubChannelDrawer from './ClubChannelDrawer'
import CreateChannelSheet from './CreateChannelSheet'
import ClubOnboardingModal from './ClubOnboardingModal'
import ChannelSettingsSheet from './ChannelSettingsSheet'

const MAX_MESSAGE_LENGTH = 2000 // matches the `messages.content` check constraint in the DB
const COMPOSER_MAX_HEIGHT = 120 // px — cap for the auto-growing composer before it scrolls internally, matches Chat.tsx

/** Reserved token only the president can use, to notify the whole club at
 *  once — resolved client-side (and re-verified server-side by
 *  notify_mention) into every other member's id. */
const ALL_MENTION_USERNAME = 'all'

interface RawClubMessage {
  id: string
  sender_id: string | null
  content: string
  created_at: string
  deleted: boolean
  hidden_reason: string | null
  reply_to_id: string | null
  type: string
  channel_id: string | null
  image_url?: string | null
}

const MARK_READ_THROTTLE_MS = 2000 // matches Chat.tsx — minimum gap between last_read_at writes

/** One row of message_reactions. The table's primary key is
 *  (message_id, user_id, emoji), which is also exactly what a realtime DELETE
 *  payload carries — so these three fields are all the client ever needs. */
interface ReactionRow {
  message_id: string
  user_id: string
  emoji: string
}

/** The row of one-tap reactions at the top of the message action sheet.
 *  Same six Discord leads with, so muscle memory carries over. */
const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥']

const TOMBSTONE_LABEL: Record<string, string> = {
  deleted_by_president: 'Message deleted by the president',
  deleted_by_vp: 'Message deleted by a VP',
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

export default function ClubChat() {
  const { roomId } = useParams<{ roomId: string }>()
  const [searchParams, setSearchParams] = useSearchParams()
  const inviteCode = searchParams.get('code')
  const navigate = useNavigate()
  const { user } = useAuth()
  const { openProfilePreview } = useProfilePreview()
  const myId = user?.id ?? null

  const [club, setClub] = useState<ClubRoom | null>(null)
  const [members, setMembers] = useState<ClubMemberRow[]>([])
  const [channels, setChannels] = useState<ClubChannel[]>([])
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null)
  const [rawMessages, setRawMessages] = useState<RawClubMessage[]>([])
  const [messagesLoading, setMessagesLoading] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [composerError, setComposerError] = useState('')
  const [replyTo, setReplyTo] = useState<Message | null>(null)
  // @mention autocomplete — non-null mentionQuery means the caret currently sits
  // right after an "@partial-username" token; mentionStartIndex is where that
  // "@" sits in `text`, used to splice the picked username back in. Mirrors
  // Chat.tsx's implementation so Clubs behaves identically.
  const [mentionQuery, setMentionQuery] = useState<string | null>(null)
  const [mentionStartIndex, setMentionStartIndex] = useState<number | null>(null)
  const [ctxMsg, setCtxMsg] = useState<Message | null>(null)
  const [reportTarget, setReportTarget] = useState<{ id: string; senderName: string } | null>(null)
  const [reactions, setReactions] = useState<ReactionRow[]>([])
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [unreadByChannel, setUnreadByChannel] = useState<Map<string, number>>(new Map())
  const { toast, showToast } = useToast()
  const [ctxChannel, setCtxChannel] = useState<ClubChannel | null>(null)
  const [ctxChannelPos, setCtxChannelPos] = useState({ x: 0, y: 0 })
  const [newChannelName, setNewChannelName] = useState('')
  const [createSheetOpen, setCreateSheetOpen] = useState(false)
  const [settingsChannel, setSettingsChannel] = useState<ClubChannel | null>(null)
  const [onboarding, setOnboarding] = useState<OnboardingQuestion[] | null>(null)
  const [onboardingSkipped, setOnboardingSkipped] = useState(false)
  const [channelBusy, setChannelBusy] = useState(false)
  const [channelError, setChannelError] = useState('')

  const activeChannelIdRef = useRef<string | null>(null)
  activeChannelIdRef.current = activeChannelId

  const subRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const membersRef = useRef<ClubMemberRow[]>([])
  membersRef.current = members
  const lastMarkReadAtRef = useRef(0)

  // Jump-to-message (reply-quote taps) — DOM nodes for every currently-mounted
  // message bubble, keyed by id, so a tap can scrollIntoView + flash a bubble
  // without re-querying the list. Same pattern as Chat.tsx.
  const msgElRefs = useRef<Map<string, HTMLDivElement>>(new Map())
  const registerMsgRef = useCallback((id: string, el: HTMLDivElement | null) => {
    if (el) msgElRefs.current.set(id, el)
    else msgElRefs.current.delete(id)
  }, [])
  const [highlightedMsgId, setHighlightedMsgId] = useState<string | null>(null)

  /** Persists my read position for this club, throttled the same way Chat.tsx
   *  does for DMs/Global. Without this the unread badge on the Clubs list never
   *  clears, since nothing else ever writes room_members.last_read_at for a club. */
  const markRoomAsRead = useCallback((id: string, uid: string) => {
    const now = Date.now()
    if (now - lastMarkReadAtRef.current < MARK_READ_THROTTLE_MS) return
    lastMarkReadAtRef.current = now
    supabase.from('room_members').update({ last_read_at: new Date().toISOString() })
      .eq('room_id', id).eq('user_id', uid)
      .then(({ error }) => { if (error) console.error('Failed to mark club as read:', error.message) })
  }, [])

  const myRole: ClubRole | null = members.find(m => m.user_id === myId)?.role ?? null
  const canModerate = myRole === 'president' || myRole === 'vp'

  // Auto-grow the composer with its content, exactly like Chat.tsx — without
  // this, typing past one line just scrolled the box's own single-line
  // viewport instead of the box visibly getting taller, hiding everything
  // but the last visible slice of a longer message.
  useLayoutEffect(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, COMPOSER_MAX_HEIGHT)}px`
  }, [text])

  // Render-only membership list — real club members plus the reserved "@all"
  // token, so a president's broadcast mention gets the same accent-colour
  // highlight as a real @username in the rendered message body.
  const renderMembers: MentionMember[] = useMemo(() => [
    ...members.map(m => ({ user_id: m.user_id, profile: { username: m.username } })),
    { user_id: '__all__', profile: { username: ALL_MENTION_USERNAME } },
  ], [members])

  const nameFor = useCallback((userId: string | null) => {
    if (!userId) return 'Unknown'
    const m = membersRef.current.find(mb => mb.user_id === userId)
    if (!m) return 'Unknown'
    const name = m.display_name || m.username
    // The emoji they picked during this club's onboarding. Deliberately only
    // here — it doesn't follow them to global chat, DMs or their profile.
    return m.onboarding_emoji ? `${name} ${m.onboarding_emoji}` : name
  }, [])
  const avatarFor = useCallback((userId: string | null) => {
    const m = membersRef.current.find(mb => mb.user_id === userId)
    return m?.avatar ?? null
  }, [])

  // Shape the raw rows into the shared Message type MessageBurst/MessageLine
  // expect — same fields Global/DMs populate, defaults for the ones Clubs
  // doesn't use yet (voice notes, polls, rank tags).
  const messages: Message[] = useMemo(() => rawMessages.map((m): Message => {
    const replySource = m.reply_to_id ? rawMessages.find(r => r.id === m.reply_to_id) : undefined
    return {
      id: m.id, sender_id: m.sender_id, content: m.content, created_at: m.created_at,
      deleted: m.deleted, hidden: false, hidden_reason: m.hidden_reason, reply_to_id: m.reply_to_id,
      replyPreview: replySource?.content, replyPreviewName: replySource ? nameFor(replySource.sender_id) : undefined,
      senderName: nameFor(m.sender_id),
      type: (m.type as Message['type']) ?? 'text', audio_path: null, audio_duration_seconds: null, call_id: null,
      rank_tag_group: null, poll_id: null, image_url: m.image_url ?? null,
      deletedLabel: TOMBSTONE_LABEL[m.hidden_reason ?? ''],
    }
  }), [rawMessages, nameFor, members])

  const groupedMessages: GroupedMessage[] = useMemo(() => groupMessages(messages), [messages])

  // Fold the flat, grouped list into consecutive-sender bursts — same
  // algorithm Chat.tsx uses for Global/DMs.
  const bursts: GroupedMessage[][] = useMemo(() => {
    const out: GroupedMessage[][] = []
    for (const m of groupedMessages) {
      const last = out[out.length - 1]
      if (last && !m.isGroupFirst) last.push(m)
      else out.push([m])
    }
    return out
  }, [groupedMessages])

  const loadMessages = useCallback(async (channelId: string) => {
    if (!roomId) return
    setMessagesLoading(true)
    try {
      const { data: msgs, error: msgErr } = await supabase
        .from('messages')
        .select('id, sender_id, content, created_at, deleted, hidden_reason, reply_to_id, type, channel_id, image_url')
        .eq('room_id', roomId)
        .eq('channel_id', channelId)
        .order('created_at', { ascending: false })
        .limit(50)
      if (msgErr) throw new Error(msgErr.message)
      const rows = [...(msgs ?? [])].reverse()
      setRawMessages(rows)

      // Reactions for exactly the messages just loaded. Scoped by id rather
      // than room so switching channels doesn't accumulate the whole club's
      // reaction history in memory.
      if (rows.length > 0) {
        const { data: reactionRows } = await supabase
          .from('message_reactions')
          .select('message_id, user_id, emoji')
          .in('message_id', rows.map(m => m.id))
        setReactions(reactionRows ?? [])
      } else {
        setReactions([])
      }
    } catch (e: any) {
      setError(e.message)
    } finally {
      setMessagesLoading(false)
    }
  }, [roomId])

  const load = useCallback(async () => {
    if (!roomId) return
    setLoading(true)
    setError('')
    try {
      let c = await fetchClub(roomId)

      // Not a member yet (RLS hides the row) — if the link carried a code,
      // join automatically instead of showing "not found".
      if (!c && inviteCode) {
        try {
          await joinClub({ roomId, code: inviteCode })
          c = await fetchClub(roomId)
        } catch (joinErr: any) {
          setError(joinErr.message)
          setLoading(false)
          return
        }
      }

      if (!c) { setError('Club not found, or you left it.'); setLoading(false); return }

      // Code did its job — drop it from the URL so a refresh/share doesn't
      // re-trigger a join attempt.
      if (inviteCode) setSearchParams({}, { replace: true })

      const [mem, chans] = await Promise.all([fetchClubMembers(roomId), fetchClubChannels(roomId)])
      setClub(c)
      setMembers(mem)
      membersRef.current = mem
      setChannels(chans)

      // Land on the club's designated channel; fall back to the first one
      // if default_channel_id is somehow stale/missing.
      const landing = chans.find(ch => ch.id === c!.default_channel_id) ?? chans[0] ?? null
      const landingId = landing?.id ?? null
      setActiveChannelId(landingId)

      // Onboarding runs once per member: if the club has questions and this
      // member has answered none of them, show the flow. Failures here are
      // swallowed — a broken quiz must never keep someone out of the chat.
      if (c.onboarding_enabled && myId) {
        try {
          const [questions, answered] = await Promise.all([
            fetchClubOnboarding(roomId),
            fetchMyOnboardingAnswers(roomId, myId),
          ])
          if (questions.length > 0 && answered.length === 0) setOnboarding(questions)
        } catch {
          // Ignore — no onboarding is a better failure than no club.
        }
      }
      if (landingId) await loadMessages(landingId)
      else setRawMessages([])
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [roomId, inviteCode, setSearchParams, loadMessages])

  /** Pulls the per-channel unread counts. Cheap (one RPC, one row per
   *  channel) so it's safe to call on entry and whenever a message lands. */
  /** Swipe right from the left edge opens the drawer, matching Discord. Only
   *  a gesture that STARTS near the edge counts, so it can't fight horizontal
   *  scrolling inside the message list, and it has to be clearly horizontal so
   *  a diagonal scroll doesn't trigger it. */
  const touchStartRef = useRef<{ x: number; y: number } | null>(null)

  function onTouchStart(e: React.TouchEvent) {
    const t = e.touches[0]
    touchStartRef.current = t.clientX <= 32 ? { x: t.clientX, y: t.clientY } : null
  }
  function onTouchEnd(e: React.TouchEvent) {
    const start = touchStartRef.current
    touchStartRef.current = null
    if (!start || drawerOpen) return
    const t = e.changedTouches[0]
    const dx = t.clientX - start.x
    const dy = Math.abs(t.clientY - start.y)
    if (dx > 60 && dx > dy * 1.5) setDrawerOpen(true)
  }

  const refreshUnreads = useCallback(async () => {
    if (!roomId) return
    try {
      const rows = await fetchChannelUnreads(roomId)
      setUnreadByChannel(new Map(rows.map(r => [r.channel_id, r.unread_count])))
    } catch { /* a missing badge is not worth surfacing an error banner for */ }
  }, [roomId])

  function switchChannel(channelId: string) {
    setDrawerOpen(false)
    if (channelId === activeChannelId) return
    setActiveChannelId(channelId)
    setReplyTo(null)
    loadMessages(channelId)
    // Opening a channel reads it. Clear the badge locally first so the drawer
    // doesn't show a stale count for the channel you're now looking at.
    setUnreadByChannel(m => { const next = new Map(m); next.set(channelId, 0); return next })
    markChannelRead(channelId).then(refreshUnreads)
  }

  useEffect(() => { load() }, [load])

  useEffect(() => {
    if (bottomRef.current) bottomRef.current.scrollIntoView({ block: 'end' })
  }, [rawMessages.length])

  // Entering the club counts as reading it — bypass the throttle here since
  // this only fires once per mount/room change, not on every message.
  useEffect(() => {
    if (!roomId || !myId || loading) return
    lastMarkReadAtRef.current = 0
    markRoomAsRead(roomId, myId)
    refreshUnreads()
  }, [roomId, myId, loading, markRoomAsRead, refreshUnreads])

  // The channel you're actually looking at stays read as messages land in it;
  // the drawer's other channels keep accumulating counts as normal.
  useEffect(() => {
    if (!activeChannelId || loading) return
    markChannelRead(activeChannelId)
  }, [activeChannelId, rawMessages.length, loading])

  // /clubs/:roomId is reached directly (IconRail's club shortcuts, deep
  // links) without ever mounting ChatHub, so the persistent Topbar dot
  // (useChatUnreadBadge.ts) needs its own "entered chat" signal here too.
  useEffect(() => {
    if (myId) markChatSeen(myId)
  }, [myId])

  // Realtime: new messages, edits (delete tombstone), pin changes, and the
  // channel list itself (another mod adding/renaming/deleting a channel).
  useEffect(() => {
    if (!roomId) return
    if (subRef.current) supabase.removeChannel(subRef.current)
    subRef.current = supabase
      .channel(`club-chat:${roomId}:${Date.now()}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `room_id=eq.${roomId}` }, (payload) => {
        const raw = payload.new as RawClubMessage
        if (raw.channel_id !== activeChannelIdRef.current) {
          // Landed in a channel I'm not reading — bump that channel's badge
          // instead of dropping the event entirely.
          if (raw.sender_id !== myId && raw.channel_id) {
            const chId = raw.channel_id
            setUnreadByChannel(m => { const next = new Map(m); next.set(chId, (next.get(chId) ?? 0) + 1); return next })
          }
          return
        }
        setRawMessages(ms => ms.find(m => m.id === raw.id) ? ms : [...ms, raw])
        if (myId) markRoomAsRead(roomId, myId)
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `room_id=eq.${roomId}` }, (payload) => {
        const raw = payload.new as RawClubMessage
        setRawMessages(ms => ms.map(m => m.id === raw.id ? { ...m, deleted: raw.deleted, hidden_reason: raw.hidden_reason, content: raw.deleted ? m.content : raw.content } : m))
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chat_rooms', filter: `id=eq.${roomId}` }, (payload) => {
        const raw = payload.new as any
        setClub(c => c ? { ...c, pinned_message_id: raw.pinned_message_id, archived_at: raw.archived_at, grace_started_at: raw.grace_started_at, name: raw.name, is_private: raw.is_private, default_channel_id: raw.default_channel_id } : c)
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'room_members', filter: `room_id=eq.${roomId}` }, () => {
        fetchClubMembers(roomId).then(m => { setMembers(m); membersRef.current = m })
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_reactions', filter: `room_id=eq.${roomId}` }, (payload) => {
        // Realtime DELETE payloads only carry the primary key columns, which
        // here is exactly (message_id, user_id, emoji) — enough to drop the
        // right row without a refetch.
        if (payload.eventType === 'DELETE') {
          const old = payload.old as ReactionRow
          setReactions(rs => rs.filter(r => !(r.message_id === old.message_id && r.user_id === old.user_id && r.emoji === old.emoji)))
        } else {
          const row = payload.new as ReactionRow
          setReactions(rs => rs.some(r => r.message_id === row.message_id && r.user_id === row.user_id && r.emoji === row.emoji)
            ? rs : [...rs, row])
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_channels', filter: `room_id=eq.${roomId}` }, () => {
        fetchClubChannels(roomId).then(setChannels)
      })
      .subscribe()
    return () => { if (subRef.current) supabase.removeChannel(subRef.current) }
  }, [roomId])

  /** Flashes the highlight ring on an already-mounted message bubble, then
   *  clears it after the reader's had a moment to spot it. Mirrors
   *  Chat.tsx's flashHighlight/scrollToLoadedMessage. */
  const jumpToReply = useCallback((id: string) => {
    const el = msgElRefs.current.get(id)
    if (!el) {
      showToast({ message: 'Original message not loaded', icon: Reply })
      return
    }
    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    setHighlightedMsgId(id)
    window.setTimeout(() => setHighlightedMsgId(cur => (cur === id ? null : cur)), 1600)
  }, [showToast])

  /** Club members matching the in-progress @mention token, self excluded,
   *  capped to a short list — same shape as Chat.tsx's mentionSuggestions.
   *  The president also gets an "@all" row (when it matches what they've
   *  typed) to tag the whole club at once. */
  function mentionSuggestions(): (ClubMemberRow | 'all')[] {
    if (mentionQuery === null) return []
    const q = mentionQuery.toLowerCase()
    const memberMatches = members
      .filter(mb => mb.user_id !== myId)
      .filter(mb => mb.username.toLowerCase().startsWith(q) || (mb.display_name ?? '').toLowerCase().startsWith(q))
      .slice(0, 6)
    const suggestions: (ClubMemberRow | 'all')[] = []
    if (myRole === 'president' && ALL_MENTION_USERNAME.startsWith(q)) suggestions.push('all')
    return [...suggestions, ...memberMatches].slice(0, 6)
  }

  /** Splices `@username ` (or `@all `) in at the token the dropdown was
   *  triggered from, replacing whatever partial text was already typed. */
  function applyMention(pick: ClubMemberRow | 'all') {
    if (mentionStartIndex === null) return
    const cursor = textareaRef.current?.selectionStart ?? text.length
    const before = text.slice(0, mentionStartIndex)
    const after = text.slice(cursor)
    const insertion = `@${pick === 'all' ? ALL_MENTION_USERNAME : pick.username} `
    setText(before + insertion + after)
    setMentionQuery(null)
    setMentionStartIndex(null)
    requestAnimationFrame(() => {
      const el = textareaRef.current
      if (!el) return
      const pos = before.length + insertion.length
      el.focus()
      el.setSelectionRange(pos, pos)
    })
  }

  function handleTextChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    const value = e.target.value
    setText(value)
    setComposerError('')

    // Detect an in-progress "@partial" token right at the caret — only opens
    // when the "@" is at the very start of the message or right after
    // whitespace, so it doesn't fire mid-word. Same pattern as Chat.tsx.
    const cursor = e.target.selectionStart ?? value.length
    const uptoCursor = value.slice(0, cursor)
    const match = uptoCursor.match(/(?:^|\s)@([a-zA-Z0-9_]{0,32})$/)
    if (match) {
      setMentionQuery(match[1])
      setMentionStartIndex(cursor - match[1].length - 1)
    } else {
      setMentionQuery(null)
      setMentionStartIndex(null)
    }
  }

  function handleComposerKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (mentionQuery !== null) {
      if (e.key === 'Escape') { e.preventDefault(); setMentionQuery(null); setMentionStartIndex(null); return }
      if (e.key === 'Enter' && !e.shiftKey) {
        const top = mentionSuggestions()[0]
        if (top) { e.preventDefault(); applyMention(top); return }
      }
    }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg() }
  }

  async function sendMsg() {
    const trimmed = text.trim()
    if (!trimmed || !roomId || !myId || !activeChannelId || sending) return
    if (trimmed.length > MAX_MESSAGE_LENGTH) return
    if (containsProfanity(trimmed)) { setComposerError(PROFANITY_BLOCKED_MESSAGE); return }

    setSending(true)
    setComposerError('')
    try {
      const payload: { room_id: string; sender_id: string; content: string; reply_to_id?: string; channel_id: string } = {
        room_id: roomId, sender_id: myId, content: trimmed, channel_id: activeChannelId,
      }
      if (replyTo) payload.reply_to_id = replyTo.id
      const { data: inserted, error: sendErr } = await supabase
        .from('messages').insert(payload)
        .select('id, sender_id, content, created_at, deleted, hidden_reason, reply_to_id, type, channel_id, image_url').single()
      if (sendErr) throw new Error(sendErr.message)
      if (inserted) setRawMessages(ms => ms.find(m => m.id === inserted.id) ? ms : [...ms, inserted])

      // @mentions — the president's "@all" tags every other member; anyone
      // else's @username tokens resolve against actual club membership.
      // notify_mention() re-verifies membership server-side either way.
      if (inserted) {
        const mentionedIds = myRole === 'president' && /(?:^|\s)@all(?:\s|$)/i.test(trimmed)
          ? members.filter(mb => mb.user_id !== myId).map(mb => mb.user_id)
          : (() => {
              const matches = trimmed.match(/@([a-zA-Z0-9_]{2,32})/g) ?? []
              const usernames = new Set(matches.map(t => t.slice(1).toLowerCase()))
              return members.filter(mb => mb.user_id !== myId && usernames.has(mb.username.toLowerCase())).map(mb => mb.user_id)
            })()
        if (mentionedIds.length > 0) notifyMention(inserted.id, mentionedIds).catch(console.error)
      }

      setText('')
      setReplyTo(null)
      setMentionQuery(null)
      setMentionStartIndex(null)
    } catch (e: any) {
      setComposerError(e.message)
    } finally {
      setSending(false)
    }
  }

  async function handlePin(messageId: string) {
    if (!roomId) return
    setCtxMsg(null)
    try { await clubPinMessage(roomId, messageId) } catch (e: any) { setError(e.message) }
  }
  async function handleUnpin() {
    if (!roomId) return
    setCtxMsg(null)
    try { await clubUnpinMessage(roomId) } catch (e: any) { setError(e.message) }
  }
  /** Two different delete paths, same button:
   *  - my own message → direct update, allowed by the `messages_update` RLS
   *    policy (sender_id = auth.uid()). No tombstone label, exactly like
   *    Chat.tsx's deleteMsg does for Global/DMs.
   *  - someone else's, as president/vp → club_delete_message RPC, which
   *    stamps hidden_reason so the burst renders "deleted by the president".
   *  The RPC rejects non-mods outright, so a member deleting their own
   *  message could never have worked through it. */
  async function handleDelete(msg: Message) {
    setCtxMsg(null)
    try {
      if (msg.sender_id === myId) {
        const { error: delErr } = await supabase.from('messages').update({ deleted: true }).eq('id', msg.id).eq('sender_id', myId)
        if (delErr) throw new Error(delErr.message)
        setRawMessages(ms => ms.map(m => m.id === msg.id ? { ...m, deleted: true } : m))
      } else {
        await clubDeleteMessage(msg.id)
      }
    } catch (e: any) { setError(e.message) }
  }

  /** Tally the flat reaction rows into per-message pills, in the order each
   *  emoji first appeared on that message (so pills don't reshuffle as counts
   *  change). */
  const reactionsByMessage = useMemo(() => {
    const map = new Map<string, MessageReaction[]>()
    for (const r of reactions) {
      const list = map.get(r.message_id) ?? []
      const existing = list.find(x => x.emoji === r.emoji)
      if (existing) {
        existing.count += 1
        if (r.user_id === myId) existing.mine = true
      } else {
        list.push({ emoji: r.emoji, count: 1, mine: r.user_id === myId })
      }
      map.set(r.message_id, list)
    }
    return map
  }, [reactions, myId])

  const reactionsFor = useCallback((msg: Message) => reactionsByMessage.get(msg.id) ?? [], [reactionsByMessage])

  /** Which message's "who reacted" sheet is open, if any. Only the id is
   *  stored; rows are re-derived from `reactions` on each render (see
   *  reactorsSheetRows below) so a reaction changing in real time while
   *  the sheet is open updates it immediately. */
  const [reactorsSheetMsgId, setReactorsSheetMsgId] = useState<string | null>(null)
  const openReactors = useCallback((msg: Message, _emoji: string) => setReactorsSheetMsgId(msg.id), [])
  const reactorsSheetRows = useMemo(
    () => reactorsSheetMsgId ? reactions.filter(r => r.message_id === reactorsSheetMsgId) : [],
    [reactorsSheetMsgId, reactions],
  )
  const reactorUserLookup = useCallback((userId: string) => {
    const m = membersRef.current.find(mb => mb.user_id === userId)
    if (!m) return undefined
    return { name: m.display_name || m.username, avatar: m.avatar }
  }, [])

  /** Toggle my reaction of one emoji on one message. Optimistic on both
   *  paths — realtime echoes the same change back, and the dedupe guards in
   *  the subscription make the echo a no-op. */
  const toggleReaction = useCallback(async (msg: Message, emoji: string) => {
    if (!myId || !roomId) return
    const mine = reactions.some(r => r.message_id === msg.id && r.user_id === myId && r.emoji === emoji)

    if (mine) {
      setReactions(rs => rs.filter(r => !(r.message_id === msg.id && r.user_id === myId && r.emoji === emoji)))
      const { error: delErr } = await supabase.from('message_reactions').delete()
        .eq('message_id', msg.id).eq('user_id', myId).eq('emoji', emoji)
      if (delErr) setReactions(rs => [...rs, { message_id: msg.id, user_id: myId, emoji }])
    } else {
      setReactions(rs => [...rs, { message_id: msg.id, user_id: myId, emoji }])
      const { error: insErr } = await supabase.from('message_reactions')
        .insert({ message_id: msg.id, user_id: myId, emoji, room_id: roomId })
      if (insErr) setReactions(rs => rs.filter(r => !(r.message_id === msg.id && r.user_id === myId && r.emoji === emoji)))
    }
  }, [myId, roomId, reactions])

  function mentionSender(msg: Message) {
    const sender = membersRef.current.find(mb => mb.user_id === msg.sender_id)
    setCtxMsg(null)
    if (!sender) return
    setText(t => (t ? t + ' ' : '') + '@' + sender.username + ' ')
    textareaRef.current?.focus()
  }

  function dmSender(msg: Message) {
    setCtxMsg(null)
    if (msg.sender_id) navigate('/chat', { state: { openDmWith: msg.sender_id } })
  }

  const [renameTarget, setRenameTarget] = useState<ClubChannel | null>(null)

  function openCreateSheet() {
    setCreateSheetOpen(true)
  }

  function openRenameChannel(ch: ClubChannel) {
    setCtxChannel(null)
    setDrawerOpen(false)
    setNewChannelName(ch.name)
    setChannelError('')
    setRenameTarget(ch)
  }
  function closeChannelModal() {
    setRenameTarget(null)
  }

  async function submitChannelModal() {
    const name = newChannelName.trim()
    if (!name || !roomId) return
    setChannelBusy(true)
    setChannelError('')
    try {
      if (renameTarget) {
        await renameClubChannel(renameTarget.id, name)
        setChannels(cs => cs.map(c => c.id === renameTarget.id ? { ...c, name } : c))
      } else {
        const newId = await createClubChannel(roomId, name)
        const fresh = await fetchClubChannels(roomId)
        setChannels(fresh)
        switchChannel(newId)
      }
      closeChannelModal()
    } catch (e: any) {
      setChannelError(e.message)
    } finally {
      setChannelBusy(false)
    }
  }

  async function handleSetDefaultChannel(ch: ClubChannel) {
    if (!roomId) return
    setCtxChannel(null)
    try {
      await setDefaultClubChannel(roomId, ch.id)
      setClub(c => c ? { ...c, default_channel_id: ch.id } : c)
    } catch (e: any) {
      setChannelError(e.message)
    }
  }

  async function handleDeleteChannel(ch: ClubChannel) {
    if (!roomId) return
    setCtxChannel(null)
    try {
      await deleteClubChannel(ch.id)
      const fresh = await fetchClubChannels(roomId)
      setChannels(fresh)
      if (activeChannelId === ch.id) {
        const c2 = await fetchClub(roomId)
        const landing = fresh.find(c => c.id === c2?.default_channel_id) ?? fresh[0] ?? null
        setClub(c2)
        if (landing) switchChannel(landing.id)
      }
    } catch (e: any) {
      setChannelError(e.message)
    }
  }

  const avatarForBurst = (msg: Message, isMine: boolean): string | null => isMine ? null : avatarFor(msg.sender_id)
  const readReceiptFor = (_msg: Message): ReadReceipt => null // group context — no meaningful per-message read state

  if (loading) {
    return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>Loading…</div>
  }
  if (error && !club) {
    return (
      <div style={{ maxWidth: 500, margin: '60px auto', textAlign: 'center' }}>
        <p style={{ fontSize: 13, color: '#ff6b6b', marginBottom: 14 }}>{error}</p>
        <button onClick={() => navigate('/chat?tab=clubs')} style={{ padding: '9px 18px', borderRadius: 10, border: 'none', background: 'var(--surface)', color: 'var(--text)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>Back to Clubs</button>
      </div>
    )
  }
  if (!club) return null

  const activeChannel = channels.find(ch => ch.id === activeChannelId) ?? null
  const channelReadOnly = !!activeChannel && !activeChannel.allow_member_chat && !canModerate
  const pinnedMsg = club.pinned_message_id ? messages.find(m => m.id === club.pinned_message_id) : null
  const isArchived = !!club.archived_at
  const inGrace = !!club.grace_started_at && !isArchived

  return (
    <div
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      style={{
        maxWidth: 720, margin: '0 auto', display: 'flex', flexDirection: 'column',
        // The app Topbar is suppressed on this route (see AppLayout), so this
        // header is now the topmost thing on screen and has to clear the
        // status bar / notch itself.
        paddingTop: 'env(safe-area-inset-top)',
        height: 'calc(100dvh - var(--dock-space, 0px) - env(safe-area-inset-top))',
      }}>
      <ClubChannelDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        club={club}
        channels={channels}
        activeChannelId={activeChannelId}
        memberCount={members.length}
        unreadByChannel={unreadByChannel}
        canModerate={canModerate}
        onSelectChannel={switchChannel}
        onAddChannel={() => { setDrawerOpen(false); openCreateSheet() }}
        onChannelSettings={ch => { setDrawerOpen(false); setSettingsChannel(ch) }}
        onChannelMenu={(ch, x, y) => { setCtxChannel(ch); setCtxChannelPos({ x, y }) }}
        onOpenInfo={() => navigate(`/clubs/${club.id}/info`)}
        onOpenSettings={() => navigate(`/clubs/${club.id}/settings`)}
        showSettings={!!myRole}
      />

      {/* Header — one bar, Discord-style: the CHANNEL is the title and the club
          name is the subtitle, since which channel you're in is what changes
          as you move around. The hamburger (or a swipe right from the message
          list) opens the channel drawer, which is where the club identity,
          the channel list and settings now live. */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 4px 12px', borderBottom: '1px solid var(--border)' }}>
        <button onClick={() => navigate('/chat?tab=clubs')} aria-label="Back to Clubs" className="neu-icon" style={{ width: 34, height: 34, border: 'none', cursor: 'pointer', color: 'var(--text-dim)', flexShrink: 0 }}>
          <ArrowLeft size={15} />
        </button>
        <button
          onClick={() => setDrawerOpen(true)}
          aria-label="Open channels"
          aria-expanded={drawerOpen}
          style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0, background: 'none', border: 'none', cursor: 'pointer', padding: 0, textAlign: 'left' }}
        >
          <Menu size={17} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 15, fontWeight: 800, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              <Hash size={13} style={{ opacity: 0.6, flexShrink: 0 }} />
              {activeChannel?.name ?? club.name}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {club.name} · {members.length} member{members.length === 1 ? '' : 's'}
            </div>
          </div>
        </button>
        {myRole && (
          <button onClick={() => navigate(`/clubs/${club.id}/settings`)} aria-label="Club settings" className="neu-icon" style={{ width: 34, height: 34, border: 'none', cursor: 'pointer', color: 'var(--text-dim)', flexShrink: 0 }}>
            <Settings size={15} />
          </button>
        )}
      </div>

      {isArchived && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', background: 'rgba(255,107,107,0.1)', borderBottom: '1px solid rgba(255,107,107,0.25)', color: '#ff6b6b', fontSize: 12 }}>
          <Archive size={13} /> This club is archived — the president's Pro subscription lapsed. It'll be deleted 7 days after archiving unless they renew.
        </div>
      )}
      {inGrace && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', background: 'rgba(245,197,66,0.1)', borderBottom: '1px solid rgba(245,197,66,0.25)', color: '#f5c542', fontSize: 12 }}>
          <Flag size={13} /> This club will be archived soon unless the president renews Pro.
        </div>
      )}
      {pinnedMsg && !pinnedMsg.deleted && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 14px', background: 'var(--surface)', borderBottom: '1px solid var(--border)' }}>
          <Pin size={12} style={{ color: 'var(--accent)', flexShrink: 0 }} />
          <span style={{ fontSize: 12, color: 'var(--text-dim)', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            <strong>{pinnedMsg.senderName}:</strong> {pinnedMsg.content}
          </span>
          {canModerate && (
            <button onClick={handleUnpin} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', flexShrink: 0 }}>
              <PinOff size={13} />
            </button>
          )}
        </div>
      )}
      {error && (
        <div style={{ padding: '9px 14px', fontSize: 12, color: '#ff6b6b' }}>{error}</div>
      )}

      {/* Messages — same MessageBurst/MessageLine bubbles as Global Chat and DMs */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 12px', display: 'flex', flexDirection: 'column' }}>
        {messagesLoading ? (
          <div style={{ margin: 'auto', fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center' }}>Loading…</div>
        ) : bursts.length === 0 ? (
          <div style={{ margin: 'auto', fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center' }}>No messages yet. Say hi!</div>
        ) : bursts.map(burst => {
          const first = burst[0]
          const isMine = first.sender_id === myId
          return (
            <Fragment key={first.id}>
              <MessageBurst
                reactionsFor={reactionsFor}
                onOpenReactors={openReactors}
                burst={burst}
                isMine={isMine}
                senderLabel={first.senderName ?? 'Unknown'}
                avatarUrl={avatarForBurst(first, isMine)}
                onOpenProfile={(msg) => { if (msg.sender_id) openProfilePreview(msg.sender_id) }}
                onContextMenu={(m) => setCtxMsg(m)}
                onDoubleClick={m => setReplyTo(m)}
                formatTime={formatTime}
                readReceiptFor={readReceiptFor}
                starredIds={new Set()}
                isGroupChat
                members={renderMembers}
                onJumpToReply={jumpToReply}
                highlightedMsgId={highlightedMsgId}
                registerRef={registerMsgRef}
              />
            </Fragment>
          )
        })}
        <div ref={bottomRef} />
      </div>

      {/* Message action menu — opened via long-press (mobile) / right-click
          (desktop), same native contextmenu trigger MessageLine uses
          everywhere else. Renders as the same grouped bottom sheet Global
          Chat and DMs use (.cv-ctx-sheet in app/index.css): Reply first,
          then the rest, danger actions last in their own card. */}
      {ctxMsg && (() => {
        const isMine = ctxMsg.sender_id === myId
        const primaryItems = [
          { icon: <Reply size={14} />, label: 'Reply', action: () => { setReplyTo(ctxMsg); setCtxMsg(null) } },
        ]
        const middleItems = [
          {
            icon: <Copy size={14} />, label: 'Copy',
            action: () => {
              navigator.clipboard.writeText(ctxMsg.content)
              showToast({ message: 'Copied', icon: Check })
              setCtxMsg(null)
            },
          },
          ...(canModerate ? [
            club.pinned_message_id === ctxMsg.id
              ? { icon: <PinOff size={14} />, label: 'Unpin', action: handleUnpin }
              : { icon: <Pin size={14} />, label: 'Pin', action: () => handlePin(ctxMsg.id) },
          ] : []),
          ...(!isMine ? [
            { icon: <AtSign size={14} />, label: 'Mention', action: () => mentionSender(ctxMsg) },
            { icon: <UserPlus size={14} />, label: 'View Profile', action: () => { if (ctxMsg.sender_id) openProfilePreview(ctxMsg.sender_id); setCtxMsg(null) } },
            { icon: <MessageCircle size={14} />, label: 'DM the user', action: () => dmSender(ctxMsg) },
          ] : []),
        ]
        const dangerItems = [
          ...(!isMine ? [{
            icon: <Flag size={14} />, label: 'Report',
            action: () => { setReportTarget({ id: ctxMsg.id, senderName: ctxMsg.senderName || 'this user' }); setCtxMsg(null) },
          }] : []),
          // Mine → always deletable (RLS lets a sender update their own row).
          // Someone else's → president/vp only, via the club RPC.
          ...(isMine || canModerate ? [
            { icon: <Trash2 size={14} />, label: 'Delete', action: () => handleDelete(ctxMsg) },
          ] : []),
        ]
        const groups = [primaryItems, middleItems, dangerItems].filter(g => g.length > 0)
        return (
          <>
            <div className="cv-ctx-sheet-backdrop" style={{ position: 'fixed', inset: 0, zIndex: 90 }}
              onClick={() => setCtxMsg(null)}
              onContextMenu={e => { e.preventDefault(); setCtxMsg(null) }} />
            <div className="cv-ctx-sheet">
              <div className="cv-ctx-sheet-handle" />
              <div className="cv-ctx-reactions">
                {QUICK_REACTIONS.map(emoji => {
                  const mine = reactions.some(r => r.message_id === ctxMsg.id && r.user_id === myId && r.emoji === emoji)
                  return (
                    <button
                      key={emoji}
                      type="button"
                      className={`cv-emoji cv-ctx-reaction${mine ? ' active' : ''}`}
                      onClick={() => { toggleReaction(ctxMsg, emoji); setCtxMsg(null) }}>
                      {emoji}
                    </button>
                  )
                })}
              </div>
              {groups.map((group, gi) => (
                <div key={gi} className="cv-ctx-sheet-group">
                  {group.map(({ icon, label, action }) => (
                    <button key={label} type="button" onClick={action}
                      className={`cv-ctx-sheet-item${label === 'Delete' || label === 'Report' ? ' danger' : ''}`}>
                      {icon} {label}
                    </button>
                  ))}
                </div>
              ))}
            </div>
          </>
        )
      })()}

      {/* Channel action menu — president/vp only, opened via the "..." beside a
          channel in the drawer. Sits above the drawer's own z-index. */}
      {ctxChannel && (
        <>
          <div style={{ position: 'fixed', inset: 0, zIndex: 99 }} onClick={() => setCtxChannel(null)} />
          <div style={{ position: 'fixed', left: Math.min(ctxChannelPos.x, window.innerWidth - 175), top: Math.min(ctxChannelPos.y, window.innerHeight - 160), zIndex: 100, background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 14, overflow: 'hidden', boxShadow: 'var(--elev-popover)', minWidth: 165 }}>
            <button onClick={() => openRenameChannel(ctxChannel)} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: 'var(--text-dim)' }}>
              <Hash size={13} /> Rename
            </button>
            {club.default_channel_id !== ctxChannel.id && (
              <button onClick={() => handleSetDefaultChannel(ctxChannel)} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: 'var(--text-dim)' }}>
                <Pin size={13} /> Set as landing channel
              </button>
            )}
            {channels.length > 1 && (
              <button onClick={() => handleDeleteChannel(ctxChannel)} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12.5, color: '#ff6b6b' }}>
                <Trash2 size={13} /> Delete channel
              </button>
            )}
          </div>
        </>
      )}

      {/* Add / rename channel — small shared modal for both flows. */}
      {renameTarget && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }} onClick={closeChannelModal}>
          <div className="neu-card" style={{ width: '100%', maxWidth: 320, borderRadius: 18, padding: 20 }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
              <p style={{ fontSize: 14.5, fontWeight: 800, color: 'var(--text)', flex: 1 }}>{renameTarget ? 'Rename channel' : 'Add a channel'}</p>
              <button onClick={closeChannelModal} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', display: 'flex' }}><X size={16} /></button>
            </div>
            <input
              value={newChannelName}
              onChange={e => setNewChannelName(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') submitChannelModal() }}
              maxLength={40}
              autoFocus
              placeholder="Channel name"
              className="neu-inset"
              style={{ width: '100%', border: 'none', borderRadius: 10, padding: '10px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', marginBottom: 10 }}
            />
            {channelError && <p style={{ fontSize: 11.5, color: '#ff6b6b', marginBottom: 8 }}>{channelError}</p>}
            <button onClick={submitChannelModal} disabled={!newChannelName.trim() || channelBusy}
              style={{ width: '100%', padding: '10px 0', borderRadius: 10, border: 'none', background: 'var(--accent)', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: !newChannelName.trim() || channelBusy ? 0.6 : 1 }}>
              {channelBusy ? 'Saving…' : renameTarget ? 'Save' : 'Create channel'}
            </button>
          </div>
        </div>
      )}

      {onboarding && !onboardingSkipped && club && (
        <ClubOnboardingModal
          roomId={roomId ?? ''}
          questions={onboarding}
          clubName={club.name}
          onDone={async () => {
            setOnboarding(null)
            if (!roomId) return
            // Answers can add them to a private channel and set their emoji,
            // so both the channel list and the member rows are now stale.
            const [mem, chans] = await Promise.all([fetchClubMembers(roomId), fetchClubChannels(roomId)])
            setMembers(mem)
            membersRef.current = mem
            setChannels(chans)
          }}
          onSkip={() => setOnboardingSkipped(true)}
        />
      )}

      <CreateChannelSheet
        open={createSheetOpen}
        onClose={() => setCreateSheetOpen(false)}
        roomId={roomId ?? ''}
        myId={myId ?? ''}
        members={members}
        channels={channels}
        onCreated={async id => {
          setCreateSheetOpen(false)
          if (!roomId) return
          const fresh = await fetchClubChannels(roomId)
          setChannels(fresh)
          switchChannel(id)
        }}
      />

      <ChannelSettingsSheet
        open={!!settingsChannel}
        channel={settingsChannel}
        members={members}
        myId={myId ?? ''}
        onClose={() => setSettingsChannel(null)}
        onSaved={updated => {
          setChannels(cs => cs.map(c => (c.id === updated.id ? updated : c)))
          setSettingsChannel(updated)
        }}
      />

      {/* Composer */}
      {isArchived ? (
        <div style={{ padding: '14px', textAlign: 'center', fontSize: 12.5, color: 'var(--text-muted)', borderTop: '1px solid var(--border)' }}>
          This club is archived — new messages are disabled.
        </div>
      ) : channelReadOnly ? (
        // "Allow members to chat here" is off. The president and VP keep their
        // composer so they can actually post the announcements/rules this mode
        // exists for; the DB trigger enforces the same split.
        <div style={{ padding: '14px', textAlign: 'center', fontSize: 12.5, color: 'var(--text-muted)', borderTop: '1px solid var(--border)' }}>
          Only the president and VPs can post in #{activeChannel?.name}.
        </div>
      ) : (
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: 10 }}>
          {/* Reply bar — distinct accent-tinted one-liner, matching Global Chat/DMs
              instead of a plain muted pill. */}
          {replyTo && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', background: 'var(--surface2)', borderRadius: 10, marginBottom: 8 }}>
              <Reply size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />
              <div style={{ flex: 1, fontSize: 12, color: 'var(--text-dim)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                <span style={{ color: 'var(--accent)', fontWeight: 600 }}>Replying to {replyTo.sender_id === myId ? 'yourself' : (replyTo.senderName || 'Unknown')}: </span>{replyTo.content}
              </div>
              <button onClick={() => setReplyTo(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', flexShrink: 0 }}><X size={13} /></button>
            </div>
          )}
          {composerError && (
            <div style={{ fontSize: 11.5, color: '#ff6b6b', marginBottom: 6, padding: '0 4px' }}>{composerError}</div>
          )}
          <div style={{ position: 'relative' }}>
            {/* @mention autocomplete — opens while typing "@partial" in the
                composer, listing only this club's members that match (plus
                "@all" for the president). Positioned above the composer so
                it never gets pushed off-screen by the keyboard. */}
            {mentionQuery !== null && (() => {
              const suggestions = mentionSuggestions()
              if (suggestions.length === 0) return null
              return (
                <div style={{
                  position: 'absolute', left: 0, right: 0, bottom: '100%', marginBottom: 6,
                  background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 12,
                  boxShadow: 'var(--elev-popover)', overflow: 'hidden', zIndex: 50,
                }}>
                  {suggestions.map(pick => pick === 'all' ? (
                    <button
                      key="all"
                      type="button"
                      onClick={() => applyMention('all')}
                      style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}
                      onMouseEnter={e => { e.currentTarget.style.background = 'var(--surface)' }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'none' }}
                    >
                      <div style={{ width: 24, height: 24, borderRadius: 8, background: 'var(--accent)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <AtSign size={13} />
                      </div>
                      <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--accent)' }}>everyone</span>
                      <span style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>@all · notifies the whole club</span>
                    </button>
                  ) : (
                    <button
                      key={pick.user_id}
                      type="button"
                      onClick={() => applyMention(pick)}
                      style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}
                      onMouseEnter={e => { e.currentTarget.style.background = 'var(--surface)' }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'none' }}
                    >
                      <Avatar name={pick.display_name || pick.username} avatarUrl={pick.avatar} size={24} radius={8} />
                      <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)' }}>{pick.display_name || pick.username}</span>
                      <span style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>@{pick.username}</span>
                    </button>
                  ))}
                </div>
              )
            })()}
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
              <div style={{ flex: 1, background: 'var(--surface)', boxShadow: 'var(--elev-inset)', border: '1px solid var(--border)', borderRadius: 12, padding: '9px 12px', display: 'flex', alignItems: 'flex-end' }} className="neu-inset">
                <textarea
                  ref={textareaRef}
                  rows={1}
                  value={text}
                  onChange={handleTextChange}
                  onKeyDown={handleComposerKeyDown}
                  placeholder="Type a message…"
                  maxLength={MAX_MESSAGE_LENGTH}
                  style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'var(--text)', fontSize: 13.5, resize: 'none', maxHeight: COMPOSER_MAX_HEIGHT, overflowY: 'auto', lineHeight: 1.4, fontFamily: 'inherit' }}
                />
              </div>
              <button
                onClick={(e) => { ripple(e); sendMsg() }}
                disabled={!text.trim() || sending || !activeChannelId}
                className="ripple-wrap"
                style={{ width: 42, height: 42, borderRadius: 12, border: 'none', background: 'var(--accent)', color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, opacity: !text.trim() || sending || !activeChannelId ? 0.6 : 1, boxShadow: '0 4px 14px -4px var(--accent-soft)' }}
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {reportTarget && myId && (
        <ReportModal
          reporterId={myId}
          targetType="message"
          targetId={reportTarget.id}
          targetLabel={`message from ${reportTarget.senderName}`}
          onClose={() => setReportTarget(null)}
        />
      )}

      {reactorsSheetMsgId && reactorsSheetRows.length > 0 && (
        <ReactorsSheet
          reactions={reactorsSheetRows}
          getUser={reactorUserLookup}
          onClose={() => setReactorsSheetMsgId(null)}
        />
      )}

      <Toast toast={toast} />

    </div>
  )
}
