// src/features/clubs/ClubInvitesSheet.tsx
//
// The invites waiting on YOU — opened from the banner at the top of the
// Clubs tab, and by tapping a 'club_invite' notification.
//
// This does NOT go through ClubQuickSheet / public_club_preview. That
// path raises club_is_private for an outsider looking at an invite-only
// club, which is exactly the club you're most likely to be invited to.
// my_club_invites() carries the club detail itself for that reason.
import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Users, Check, Clock } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import ClubIcon from './clubIcons'
import { fetchMyClubInvites, respondToClubInvite, type IncomingClubInvite } from './clubInvites'

const WIDE_BREAKPOINT = 640

function expiresIn(iso: string): string {
  const ms = new Date(iso).getTime() - Date.now()
  if (ms <= 0) return 'expired'
  const days = Math.floor(ms / 86400000)
  if (days >= 1) return `${days}d left`
  const hours = Math.max(1, Math.floor(ms / 3600000))
  return `${hours}h left`
}

interface Props {
  onClose: () => void
  /** Navigate into the club after accepting. */
  onOpenClub: (roomId: string) => void
  /** Called whenever the pending count changes, so the caller's banner
   *  can update without refetching. */
  onCountChange?: (count: number) => void
}

export default function ClubInvitesSheet({ onClose, onOpenClub, onCountChange }: Props) {
  const [visible, setVisible] = useState(false)
  const [isWide, setIsWide] = useState(() => typeof window !== 'undefined' && window.innerWidth >= WIDE_BREAKPOINT)
  const [invites, setInvites] = useState<IncomingClubInvite[]>([])
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const id = requestAnimationFrame(() => setVisible(true))
    return () => cancelAnimationFrame(id)
  }, [])

  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= WIDE_BREAKPOINT) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  useEffect(() => {
    let active = true
    fetchMyClubInvites()
      .then(rows => { if (active) { setInvites(rows); onCountChange?.(rows.length) } })
      .catch(e => { if (active) setError(e.message) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function close() {
    setVisible(false)
    setTimeout(onClose, 220)
  }

  async function respond(invite: IncomingClubInvite, accept: boolean) {
    setBusyId(invite.inviteId)
    setError(null)
    try {
      const roomId = await respondToClubInvite(invite.inviteId, accept)
      const remaining = invites.filter(i => i.inviteId !== invite.inviteId)
      setInvites(remaining)
      onCountChange?.(remaining.length)
      if (accept && roomId) {
        close()
        // Let the sheet finish sliding down before the route changes, so
        // the club screen doesn't mount underneath a moving overlay.
        setTimeout(() => onOpenClub(roomId), 230)
      } else if (remaining.length === 0) {
        close()
      }
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusyId(null)
    }
  }

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050,
        background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: isWide ? 'center' : 'flex-end', justifyContent: 'center',
        opacity: visible ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: isWide ? 'min(440px, calc(100vw - 32px))' : '100%',
          maxHeight: '78vh',
          background: 'var(--bg)',
          border: '1px solid var(--border)',
          borderRadius: isWide ? 20 : '20px 20px 0 0',
          boxShadow: '0 -12px 40px -12px var(--sh)',
          transform: visible ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 0.28s cubic-bezier(0.32,0.72,0,1)',
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
        }}
      >
        <div style={{ padding: '10px 0 6px', display: 'flex', justifyContent: 'center', flexShrink: 0 }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--border-strong)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '2px 18px 12px', flexShrink: 0 }}>
          <Users size={15} style={{ color: 'var(--text-dim)' }} />
          <p style={{ flex: 1, fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>Club invites</p>
          <button type="button" onClick={close} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        {error && (
          <div style={{ margin: '0 16px 12px', padding: '9px 13px', borderRadius: 11, background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.25)', color: '#ff6b6b', fontSize: 12 }}>
            {error}
          </div>
        )}

        <div style={{ overflowY: 'auto', overscrollBehavior: 'contain', padding: '0 16px 22px' }}>
          {loading ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '22px 0' }}>Loading…</p>
          ) : invites.length === 0 ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '22px 0' }}>No invites right now.</p>
          ) : (
            invites.map(inv => (
              <div key={inv.inviteId} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 15, overflow: 'hidden', marginBottom: 12 }}>
                {/* Banner, or the flat colour block — matching ClubQuickSheet,
                    which never renders a placeholder image. */}
                <div style={{ height: 62, background: inv.bannerUrl ? 'transparent' : 'linear-gradient(120deg, var(--accent), #7c5cff)', position: 'relative', overflow: 'hidden' }}>
                  {inv.bannerUrl && <img src={inv.bannerUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                </div>

                <div style={{ padding: '0 14px 14px' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, marginTop: -18 }}>
                    <div style={{
                      width: 44, height: 44, borderRadius: 14, flexShrink: 0,
                      background: 'linear-gradient(135deg, var(--accent), #7c5cff)',
                      border: '3px solid var(--surface)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color: '#fff', overflow: 'hidden',
                    }}>
                      <ClubIcon iconKey={inv.iconKey} iconUrl={inv.iconUrl} size={20} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0, paddingBottom: 2 }}>
                      <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {inv.clubName}
                      </p>
                      <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                        {inv.memberCount} {inv.memberCount === 1 ? 'member' : 'members'}
                      </p>
                    </div>
                  </div>

                  {inv.description && (
                    <p style={{ fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.55, marginTop: 10, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                      {inv.description}
                    </p>
                  )}

                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 11 }}>
                    <Avatar src={inv.inviterAvatar} name={inv.inviterName} size={20} radius={7} disabled />
                    <span style={{ fontSize: 11.5, color: 'var(--text-muted)', flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      Invited by {inv.inviterName}
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10.5, color: 'var(--text-muted)', flexShrink: 0 }}>
                      <Clock size={11} /> {expiresIn(inv.expiresAt)}
                    </span>
                  </div>

                  <div style={{ display: 'flex', gap: 8, marginTop: 13 }}>
                    <button
                      type="button"
                      onClick={() => respond(inv, true)}
                      disabled={busyId === inv.inviteId}
                      style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '10px 0', borderRadius: 11, border: 'none', background: 'var(--accent)', color: '#fff', fontWeight: 800, fontSize: 12.5, cursor: 'pointer', opacity: busyId === inv.inviteId ? 0.7 : 1 }}
                    >
                      <Check size={14} /> Accept
                    </button>
                    <button
                      type="button"
                      onClick={() => respond(inv, false)}
                      disabled={busyId === inv.inviteId}
                      style={{ padding: '10px 18px', borderRadius: 11, border: '1px solid var(--border)', background: 'none', color: 'var(--text-dim)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer', opacity: busyId === inv.inviteId ? 0.7 : 1 }}
                    >
                      Decline
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>,
    document.body,
  )
}
