// src/features/clubs/ClubChannelDrawer.tsx
// The slide-in channel panel for a club — the thing that used to be a row of
// pills above the message list. Pills cost a permanent row on a screen that
// already stacks a header, a composer and the dock; this trades that row for a
// swipe. Discord's mobile app works the same way.
//
// Deliberately dumb: every piece of state lives in ClubChat, which already
// owns channels, membership and the active channel. This file is layout plus
// the swipe/escape affordances.
import { useEffect } from 'react'
import { Hash, Plus, Settings, UserRoundPlus, MoreVertical, Lock, SlidersHorizontal } from 'lucide-react'
import ClubIcon from './clubIcons'
import { channelLimitFor } from './clubs'
import type { ClubRoom, ClubChannel } from './clubs'

export interface ClubChannelDrawerProps {
  open: boolean
  onClose: () => void
  club: ClubRoom
  channels: ClubChannel[]
  activeChannelId: string | null
  memberCount: number
  /** Unread message count per channel id — absent or 0 means "read". */
  unreadByChannel: Map<string, number>
  canModerate: boolean
  onSelectChannel: (channelId: string) => void
  onAddChannel: () => void
  /** Opens the rename / set-default / delete menu for one channel (mods only). */
  onChannelMenu: (channel: ClubChannel, x: number, y: number) => void
  /** Opens the per-channel toggles sheet (mods only). */
  onChannelSettings: (channel: ClubChannel) => void
  onOpenInfo: () => void
  onOpenSettings: () => void
  /** Hidden for someone viewing a club they haven't joined. */
  showSettings: boolean
}

export default function ClubChannelDrawer({
  open, onClose, club, channels, activeChannelId, memberCount, unreadByChannel,
  canModerate, onSelectChannel, onAddChannel, onChannelMenu, onChannelSettings,
  onOpenInfo, onOpenSettings, showSettings,
}: ClubChannelDrawerProps) {
  // Escape closes it on desktop; on mobile the backdrop tap and the swipe
  // handled up in ClubChat do the same job.
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  // Uncategorised channels first under a plain "Channels" heading, then each
  // category in the order its first channel appears. Below 30 members nothing
  // has a category, so this collapses to exactly the old flat list.
  const groups: { label: string | null; channels: ClubChannel[] }[] = []
  for (const channel of channels) {
    const label = channel.category?.trim() || null
    const existing = groups.find(g => g.label === label)
    if (existing) existing.channels.push(channel)
    else groups.push({ label, channels: [channel] })
  }
  groups.sort((a, b) => (a.label === null ? -1 : b.label === null ? 1 : 0))

  return (
    <>
      <div
        className={`cv-drawer-backdrop${open ? ' open' : ''}`}
        onClick={onClose}
        aria-hidden={!open}
      />
      <aside
        className={`cv-drawer${open ? ' open' : ''}`}
        aria-hidden={!open}
        aria-label="Channels"
      >
        {/* Club identity — tapping through to Club Info, same destination the
            old header title had. */}
        <div className="cv-drawer-club" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="cv-drawer-club-icon" style={{
            background: club.icon_url ? 'var(--surface)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
          }}>
            <ClubIcon iconKey={club.icon_key} iconUrl={club.icon_url} size={20} />
          </div>
          <div className="cv-drawer-club-name" style={{ minWidth: 0, flex: 1, textAlign: 'left' }}>
            {club.name}
          </div>
          <button
            type="button"
            onClick={onOpenInfo}
            aria-label={`Members (${memberCount})`}
            title="Members"
            className="neu-icon"
            style={{ width: 32, height: 32, borderRadius: '50%', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', flexShrink: 0 }}
          >
            <UserRoundPlus size={15} />
          </button>
        </div>

        {groups.map(group => (
          <div key={group.label ?? '__none'}>
            <div className="cv-drawer-section-label">{group.label ?? 'Channels'}</div>
            <nav className="cv-drawer-channels">
              {group.channels.map(ch => {
            const active = ch.id === activeChannelId
            const unread = unreadByChannel.get(ch.id) ?? 0
            // An unread channel you're currently reading isn't unread — the
            // count is refreshed on switch, but this avoids a flash of bold
            // on the channel that's open right now.
                const showUnread = unread > 0 && !active
                return (
                  <div key={ch.id} className={`cv-drawer-channel${active ? ' active' : ''}`}>
                    <button
                      type="button"
                      onClick={() => onSelectChannel(ch.id)}
                      className={`cv-drawer-channel-btn${showUnread ? ' unread' : ''}`}
                    >
                      {ch.is_private
                        ? <Lock size={13} style={{ flexShrink: 0, opacity: 0.7 }} />
                        : <Hash size={14} style={{ flexShrink: 0, opacity: 0.7 }} />}
                      <span className="cv-drawer-channel-name">{ch.name}</span>
                      {showUnread && (
                        <span className="cv-drawer-badge">{unread > 99 ? '99+' : unread}</span>
                      )}
                    </button>
                    {canModerate && (
                      <>
                        <button
                          type="button"
                          aria-label={`Settings for ${ch.name}`}
                          onClick={e => { e.stopPropagation(); onChannelSettings(ch) }}
                          className="cv-drawer-channel-more"
                        >
                          <SlidersHorizontal size={13} />
                        </button>
                        <button
                          type="button"
                          aria-label={`Options for ${ch.name}`}
                          onClick={e => { e.stopPropagation(); onChannelMenu(ch, e.clientX, e.clientY) }}
                          className="cv-drawer-channel-more"
                        >
                          <MoreVertical size={13} />
                        </button>
                      </>
                    )}
                  </div>
                )
              })}
            </nav>
          </div>
        ))}

        {/* The cap is enforced server-side by create_club_channel; hiding the
            button once it's reached just avoids a guaranteed error. It rises
            from 4 to 6 at 30 members, alongside categories. */}
        {canModerate && channels.length < channelLimitFor(memberCount) && (
          <button type="button" onClick={onAddChannel} className="cv-drawer-add">
            <Plus size={13} /> Add channel
          </button>
        )}

        {showSettings && (
          <button type="button" onClick={onOpenSettings} className="cv-drawer-footer-btn">
            <Settings size={14} /> Club settings
          </button>
        )}
      </aside>
    </>
  )
}
