// src/features/halo-ai/HaloComingSoon.tsx
//
// What players see at /halo while Halo AI is still rolling out — the same
// treatment Version History gets (see marketing/Version.tsx): one card, a
// "coming sooner than you think" line, and a one-time notification on
// close so the user knows they'll be told when it actually lands.
//
// This is NOT the maintenance gate. FeatureGateScreen ("temporarily
// unavailable") means a working feature was paused by an admin; this
// means the feature hasn't launched to players yet. Different promise,
// different screen — a rollout that says "we broke it" reads as a fault.
//
// Controlled by the `system:halo_ai_released` flag, which is read
// fail-CLOSED (see HaloAI.tsx): unknown state means not yet released, so
// a flag-fetch hiccup can never leak an unlaunched feature.
import { useNavigate } from 'react-router-dom'
import { X } from 'lucide-react'
import { useProfile } from '../profile/useProfile'
import { supabase } from '../../shared/lib/supabase'
import haloMascotImg from '../../assets/halo-mascot.png'

export default function HaloComingSoon() {
  const navigate = useNavigate()
  const { profile } = useProfile()

  async function handleClose() {
    if (profile?.id) {
      try {
        await supabase.rpc('notify_self', {
          p_type:  'halo_coming_soon',
          p_title: `Hey ${profile.username}`,
          p_body:  "You're on the list — we'll notify you the moment Halo AI opens up.",
          p_icon:  'sparkles',
          p_meta:  {},
        })
      } catch (err) {
        console.error('[HaloComingSoon] coming-soon notify failed', err)
      }
    }
    navigate(-1)
  }

  return (
    <>
      <style>{`
        @keyframes haloPopIn { from { opacity:0; transform: scale(0.9) } to { opacity:1; transform: scale(1) } }
        @keyframes haloBob   { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-7px) } }
      `}</style>

      <div style={{
        minHeight: '70vh',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 20,
      }}>
        <div style={{
          width: '100%', maxWidth: 400,
          background: 'linear-gradient(160deg,#1a0f2e,#0d1a2e)',
          border: '1.5px solid rgba(155,109,255,0.35)',
          borderRadius: 24, overflow: 'hidden',
          boxShadow: '0 30px 80px rgba(0,0,0,0.5), 0 0 0 1px rgba(155,109,255,0.1)',
          animation: 'haloPopIn 0.28s cubic-bezier(0.34,1.56,0.64,1) both',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 20px 0' }}>
            <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: 'uppercase', color: 'rgba(155,109,255,0.8)' }}>Halo AI</span>
            <button onClick={handleClose} style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,0.5)' }}>
              <X size={14} />
            </button>
          </div>

          <div style={{ padding: '10px 24px 28px', textAlign: 'center' }}>
            <img
              src={haloMascotImg}
              alt=""
              aria-hidden="true"
              style={{ width: 96, height: 96, objectFit: 'contain', margin: '0 auto 14px', display: 'block', animation: 'haloBob 4.2s ease-in-out infinite' }}
            />
            <p style={{
              fontSize: 16, lineHeight: 1.65, fontWeight: 700,
              color: '#fff', marginBottom: 24,
            }}>
              Halo isn't taking questions yet. This one is coming sooner than you think<span style={{ color: '#9b6dff' }}>…</span>
            </p>
            <button
              onClick={handleClose}
              style={{
                width: '100%', padding: '13px 0', borderRadius: 14,
                background: 'linear-gradient(135deg,#9b6dff,#4f8ef7)',
                border: 'none', cursor: 'pointer',
                fontSize: 14, fontWeight: 800, color: '#fff',
                letterSpacing: 0.3,
                boxShadow: '0 8px 24px rgba(155,109,255,0.4)',
              }}
            >
              Got it
            </button>
          </div>
        </div>
      </div>
    </>
  )
}
