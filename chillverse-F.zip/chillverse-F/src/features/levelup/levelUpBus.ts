// src/features/levelup/levelUpBus.ts
//
// Tiny global store behind the LEVEL UP celebration.
//
// Two jobs:
//
//  1. QUEUE — level-ups are *detected* the moment they happen (right after
//     award_xp resolves), but they are not necessarily *shown* then. They
//     sit in this queue until the app is in a state where a full-screen
//     celebration is welcome.
//
//  2. BLOCKS — any part of the app can say "not right now" by acquiring a
//     block. While at least one block is held, the overlay renders nothing
//     and the queue just keeps waiting. The moment the last block is
//     released the overlay pops. This is what keeps the celebration out of
//     an in-progress game and off the win/lose result screen: Games.tsx
//     holds a block for as long as `activeGame` is set (which spans both
//     the game itself and its ResultScreen), and AppLayout holds one for
//     the standalone /play/* game routes.
//
// Deliberately a module-level store rather than React context: XP is
// awarded from non-component code (gameSession.ts, achievements.ts), which
// has no way to reach a provider.

export interface LevelUpEvent {
  /** Stable key so the same level can't be queued twice. */
  id: string
  /** The level the player just reached. */
  level: number
  /** The level they were on before. */
  previousLevel: number
  /** Lifetime XP at the moment the level-up was detected. */
  xp: number
}

interface Snapshot {
  queue: LevelUpEvent[]
  blocked: boolean
}

// Referentially stable — useSyncExternalStore compares snapshots by
// identity, so this object is only ever replaced when something changes.
let snapshot: Snapshot = { queue: [], blocked: false }

const listeners = new Set<() => void>()
/** Held block tokens. Non-empty => celebrations are paused. */
const blocks = new Map<string, string>()

let tokenSeq = 0

function commit(next: Snapshot) {
  snapshot = next
  for (const listener of listeners) listener()
}

export function subscribeLevelUp(listener: () => void): () => void {
  listeners.add(listener)
  return () => { listeners.delete(listener) }
}

export function getLevelUpSnapshot(): Snapshot {
  return snapshot
}

/**
 * Queue a level-up for celebration. Safe to call more than once for the
 * same level — duplicates are dropped, so a detector that runs on both a
 * poll and an explicit post-XP check can't double-pop the overlay.
 */
export function enqueueLevelUp(event: LevelUpEvent): void {
  if (snapshot.queue.some(e => e.id === event.id)) return
  commit({ ...snapshot, queue: [...snapshot.queue, event] })
}

/** Drop the front of the queue — called when the player dismisses. */
export function dismissLevelUp(): void {
  if (snapshot.queue.length === 0) return
  commit({ ...snapshot, queue: snapshot.queue.slice(1) })
}

/**
 * Pause all celebrations until the returned function is called. Multiple
 * holders are fine; the gate only opens once every one of them releases.
 * `reason` is for debugging only.
 */
export function blockCelebrations(reason: string): () => void {
  const token = `${reason}#${++tokenSeq}`
  blocks.set(token, reason)
  syncBlocked()
  return () => {
    blocks.delete(token)
    syncBlocked()
  }
}

function syncBlocked() {
  const blocked = blocks.size > 0
  if (blocked === snapshot.blocked) return
  commit({ ...snapshot, blocked })
}

/** Debug helper — which holders are currently suppressing celebrations. */
export function activeCelebrationBlocks(): string[] {
  return [...new Set(blocks.values())]
}
