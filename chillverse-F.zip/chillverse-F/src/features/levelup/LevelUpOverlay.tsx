// src/features/levelup/LevelUpOverlay.tsx
//
// The full-screen "LEVEL UP" celebration — starburst, banner, confetti.
//
// Mounted ONCE in AppLayout, next to BadgeEarnedModal. It renders nothing
// unless there's a level-up waiting AND nothing is holding a celebration
// block (see levelUpBus.ts), so it can never land on top of a game in
// progress or a win/lose result screen. Those hold a block; when the
// player backs out to the lobby the block drops and this appears.

import { useEffect, useState } from 'react'
import type React from 'react'
import { createPortal } from 'react-dom'
import { useAuth } from '../auth/useAuth'
import { useLevelUpCelebration } from './useLevelUp'
import { useLevelUpWatcher } from './levelUpDetector'
import { getXpProgress } from '../../shared/lib/level'
import { isGameSoundEnabled } from '../games/soundSettings'
import { vibrate } from '../../shared/lib/vibrate'

/** Auto-dismiss timing. Long enough to read, short enough not to nag. */
const AUTO_DISMISS_MS = 5200

// Fixed confetti layout — varied but stable across re-renders, same
// approach as the sparkle field in BadgeEarnedModal.
const CONFETTI_COLORS = ['#4fd0ff', '#ffd76a', '#ffffff', '#3d7bff', '#f5c542', '#9b6dff']
const CONFETTI = Array.from({ length: 34 }, (_, i) => ({
  left:     (i * 37) % 100,
  size:     5 + ((i * 3) % 6),
  ratio:    i % 3 === 0 ? 2.2 : 1,
  color:    CONFETTI_COLORS[i % CONFETTI_COLORS.length],
  delay:    ((i * 13) % 9) / 10,
  duration: 2.4 + ((i * 7) % 16) / 10,
  drift:    (i % 2 === 0 ? 1 : -1) * (20 + ((i * 11) % 70)),
  spin:     (i % 2 === 0 ? 1 : -1) * (180 + ((i * 29) % 540)),
}))

function playLevelUpSound() {
  if (!isGameSoundEnabled()) return
  try {
    const audio = new Audio('/sounds/praise-bling.wav')
    audio.volume = 0.55
    audio.play().catch(() => {})
  } catch { /* autoplay blocked — silent is fine */ }
}

export default function LevelUpOverlay() {
  const { session } = useAuth()
  const userId = session?.user?.id ?? null
  const { current, dismiss } = useLevelUpCelebration()
  const [leaving, setLeaving] = useState(false)

  useLevelUpWatcher(userId)

  // Auto-dismiss. Keyed on the event id so a second queued level-up
  // (from a multi-level XP drop) gets its own full timer.
  useEffect(() => {
    if (!current) return
    setLeaving(false)
    playLevelUpSound()
    vibrate([20, 60, 20, 60, 40]) // celebratory level-up haptic
    const exit = setTimeout(() => setLeaving(true), AUTO_DISMISS_MS)
    const gone = setTimeout(dismiss, AUTO_DISMISS_MS + 260)
    return () => { clearTimeout(exit); clearTimeout(gone) }
  }, [current?.id, dismiss])

  // Esc closes it, same as tapping.
  useEffect(() => {
    if (!current) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') dismiss() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [current, dismiss])

  if (!current) return null

  const progress = getXpProgress(current.xp)
  const pct = Math.round((progress.current / progress.max) * 100)
  const xpToNext = Math.max(0, progress.max - progress.current)

  return createPortal(
    <div
      role="dialog"
      aria-live="polite"
      aria-label={`Level up. You reached level ${current.level}.`}
      onClick={dismiss}
      style={{
        position: 'fixed', inset: 0, zIndex: 9997,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        padding: 20, cursor: 'pointer', overflow: 'hidden',
        background: `
          radial-gradient(circle at 50% 42%, rgba(61,123,255,0.30) 0%, transparent 55%),
          rgba(6,8,18,0.78)
        `,
        backdropFilter: 'blur(6px)',
        WebkitBackdropFilter: 'blur(6px)',
        animation: leaving
          ? 'lvlFadeOut 0.25s ease-in forwards'
          : 'lvlFadeIn 0.28s ease-out both',
      }}
    >
      {/* ── Confetti ─────────────────────────────────────────── */}
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
        {CONFETTI.map((c, i) => (
          <span
            key={i}
            style={{
              position: 'absolute',
              left: `${c.left}%`,
              top: '38%',
              width: c.size,
              height: c.size * c.ratio,
              background: c.color,
              borderRadius: c.ratio === 1 ? 1 : 2,
              opacity: 0,
              animation: `lvlConfetti ${c.duration}s cubic-bezier(0.25,0.6,0.4,1) ${c.delay}s both`,
              ['--lvl-drift' as unknown as string]: `${c.drift}px`,
              ['--lvl-spin' as unknown as string]: `${c.spin}deg`,
            } as React.CSSProperties}
          />
        ))}
      </div>

      {/* ── Rays behind the star ─────────────────────────────── */}
      <div
        aria-hidden
        style={{
          position: 'absolute', width: 520, height: 520, borderRadius: '50%',
          background: 'conic-gradient(from 0deg, rgba(79,208,255,0.16) 0deg 12deg, transparent 12deg 30deg)',
          maskImage: 'radial-gradient(circle, #000 20%, transparent 68%)',
          WebkitMaskImage: 'radial-gradient(circle, #000 20%, transparent 68%)',
          animation: 'lvlRays 14s linear infinite',
          marginTop: -70, pointerEvents: 'none',
        }}
      />

      {/* ── Star + level number ──────────────────────────────── */}
      <div style={{
        position: 'relative', marginBottom: -18,
        animation: 'lvlStarIn 0.62s cubic-bezier(0.2,1.5,0.45,1) both',
      }}>
        <svg width="188" height="188" viewBox="0 0 100 100" style={{ display: 'block', filter: 'drop-shadow(0 0 26px rgba(79,208,255,0.55))' }}>
          <defs>
            <linearGradient id="lvlStarFill" x1="20%" y1="0%" x2="80%" y2="100%">
              <stop offset="0%"   stopColor="#8ee9ff" />
              <stop offset="45%"  stopColor="#4fd0ff" />
              <stop offset="100%" stopColor="#2f6bff" />
            </linearGradient>
          </defs>
          <path
            d="M50 4 L61 36 L95 36 L67 56 L78 90 L50 69 L22 90 L33 56 L5 36 L39 36 Z"
            fill="url(#lvlStarFill)"
            stroke="rgba(255,255,255,0.9)"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
        </svg>
        <span style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          paddingTop: 6,
          fontSize: 52, fontWeight: 900, color: '#fff',
          fontStyle: 'italic', letterSpacing: '-2px',
          textShadow: '0 3px 10px rgba(6,20,60,0.55)',
          animation: 'lvlNumberIn 0.45s cubic-bezier(0.34,1.56,0.64,1) 0.24s both',
        }}>
          {current.level}
        </span>
      </div>

      {/* ── LEVEL UP banner ──────────────────────────────────── */}
      <div style={{
        position: 'relative',
        transform: 'skewX(-11deg)',
        background: 'linear-gradient(180deg,#ffffff 0%,#eef4ff 100%)',
        borderRadius: 4,
        padding: '10px 34px',
        boxShadow: '0 10px 34px rgba(6,20,60,0.5), 0 0 0 3px rgba(47,107,255,0.9)',
        animation: 'lvlBannerIn 0.5s cubic-bezier(0.2,1.35,0.4,1) 0.16s both',
      }}>
        <span style={{
          display: 'inline-block', transform: 'skewX(11deg)',
          fontSize: 'clamp(30px, 9vw, 44px)', fontWeight: 900,
          fontStyle: 'italic', letterSpacing: '-1px', lineHeight: 1,
          whiteSpace: 'nowrap',
        }}>
          <span style={{ color: '#122552' }}>LEVEL </span>
          <span style={{ color: '#2f6bff' }}>UP</span>
        </span>
        {/* Trailing swoosh, like the reference art */}
        <span aria-hidden style={{
          position: 'absolute', left: '100%', top: '38%',
          width: 46, height: 7, marginLeft: 5,
          background: 'linear-gradient(90deg,#ffffff,rgba(255,255,255,0))',
          borderRadius: 4,
        }} />
        <span aria-hidden style={{
          position: 'absolute', right: '100%', top: '62%',
          width: 30, height: 5, marginRight: 5,
          background: 'linear-gradient(270deg,#4fd0ff,rgba(79,208,255,0))',
          borderRadius: 4,
        }} />
      </div>

      {/* ── XP progress to the next level ────────────────────── */}
      <div style={{
        marginTop: 26, width: 'min(320px, 88vw)', textAlign: 'center',
        animation: 'lvlInfoIn 0.45s ease-out 0.5s both',
      }}>
        <p style={{ fontSize: 13, fontWeight: 700, color: 'rgba(255,255,255,0.92)', marginBottom: 10 }}>
          You reached Level {current.level}
        </p>

        <div style={{
          height: 8, borderRadius: 5, overflow: 'hidden',
          background: 'rgba(255,255,255,0.14)',
          border: '1px solid rgba(255,255,255,0.12)',
        }}>
          <div style={{
            height: '100%', width: `${pct}%`, borderRadius: 5,
            background: 'linear-gradient(90deg,#4fd0ff,#2f6bff)',
            boxShadow: '0 0 12px rgba(79,208,255,0.7)',
            animation: 'lvlBarFill 0.9s cubic-bezier(0.2,0.8,0.3,1) 0.6s both',
            ['--lvl-bar' as unknown as string]: `${pct}%`,
          } as React.CSSProperties} />
        </div>

        <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)', marginTop: 8 }}>
          {progress.current.toLocaleString()} / {progress.max.toLocaleString()} XP
          {' · '}
          {xpToNext.toLocaleString()} to Level {current.level + 1}
        </p>

        <button
          type="button"
          onClick={dismiss}
          style={{
            marginTop: 20, padding: '11px 34px', borderRadius: 14, border: 'none',
            background: 'linear-gradient(135deg,#4fd0ff,#2f6bff)',
            color: '#fff', fontSize: 14, fontWeight: 800, cursor: 'pointer',
            boxShadow: '0 8px 26px rgba(47,107,255,0.45)',
          }}
        >
          Continue
        </button>
      </div>

      <style>{`
        @keyframes lvlFadeIn  { from { opacity: 0 } to { opacity: 1 } }
        @keyframes lvlFadeOut { from { opacity: 1 } to { opacity: 0 } }
        @keyframes lvlStarIn {
          0%   { opacity: 0; transform: scale(0.2) rotate(-140deg); }
          100% { opacity: 1; transform: scale(1) rotate(0deg); }
        }
        @keyframes lvlNumberIn {
          0%   { opacity: 0; transform: scale(2.1); }
          100% { opacity: 1; transform: scale(1); }
        }
        @keyframes lvlBannerIn {
          0%   { opacity: 0; transform: skewX(-11deg) translateX(-70px) scale(0.85); }
          100% { opacity: 1; transform: skewX(-11deg) translateX(0) scale(1); }
        }
        @keyframes lvlInfoIn {
          from { opacity: 0; transform: translateY(12px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes lvlBarFill {
          from { width: 0%; }
          to   { width: var(--lvl-bar); }
        }
        @keyframes lvlRays {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes lvlConfetti {
          0%   { opacity: 0; transform: translate(0,0) rotate(0deg) scale(0.6); }
          8%   { opacity: 1; }
          100% { opacity: 0; transform: translate(var(--lvl-drift), 78vh) rotate(var(--lvl-spin)) scale(1); }
        }
        @media (prefers-reduced-motion: reduce) {
          @keyframes lvlConfetti { 0%, 100% { opacity: 0; } }
        }
      `}</style>
    </div>,
    document.body,
  )
}
