// src/features/levelup/levelUpDetector.ts
//
// Works out *when* the player levelled up.
//
// There is no level_up trigger in the database — award_xp() just bumps
// profiles.xp and recomputes profiles.level inline (migration 0021), and
// XP is granted from several unrelated places: game sessions, exploration
// chambers, achievement unlocks, weekly-mission claims, Halo moments,
// admin grants. Rather than instrument every one of those, this module
// keeps a per-user "last level we celebrated" baseline in localStorage and
// compares it against the real row.
//
//   - checkForLevelUp() is cheap (one indexed single-row select) and is
//     called right after any client-side XP award for an instant reaction.
//   - useLevelUpWatcher() re-checks on mount, on tab focus, and on a slow
//     interval, which catches the grants that happen server-side or while
//     the tab was in the background.
//
// The baseline is deliberately in localStorage, not memory: a player who
// levels up during a game and closes the tab before the celebration shows
// still gets it the next time they open the app.

import { useEffect } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { cumulativeXpForLevel } from '../../shared/lib/level'
import { enqueueLevelUp } from './levelUpBus'

/** How often the safety-net poll runs while the app is open. */
const POLL_MS = 60_000

const baselineKey = (userId: string) => `cv_level_seen_${userId}`

function readBaseline(userId: string): number | null {
  try {
    const raw = localStorage.getItem(baselineKey(userId))
    if (raw == null) return null
    const n = Number(raw)
    return Number.isFinite(n) ? n : null
  } catch {
    return null
  }
}

function writeBaseline(userId: string, level: number): void {
  try { localStorage.setItem(baselineKey(userId), String(level)) } catch { /* private mode */ }
}

// De-dupes overlapping checks (e.g. the post-XP call and the poll landing
// at the same moment) so we only ever have one request in flight per user.
const inFlight = new Map<string, Promise<void>>()

/**
 * Write the level-up into the notifications table so it survives the
 * celebration — the bell and the Notifications page have had level_up
 * styling all along (color, 'trending-up' icon, "Level Up" label, a route
 * to /dashboard) with nothing to populate it.
 *
 * Deliberately fire-and-forget: the overlay is the actual reward, and a
 * failed insert should never hold it up or throw. Only reached once per
 * level per device, since the caller writes the baseline in the same
 * branch. Goes through notify_self (migration 0106), which forces the
 * target to auth.uid() — the caller's own id is no longer passed.
 */
function recordLevelUpNotification(level: number, xp: number): void {
  const toNext = Math.max(0, cumulativeXpForLevel(level + 1) - xp)
  supabase.rpc('notify_self', {
    p_type:    'level_up',
    p_title:   `Level ${level} reached`,
    p_body:    `You're now Level ${level} — ${toNext.toLocaleString()} XP to Level ${level + 1}.`,
    p_icon:    'trending-up',
    p_meta:    { level },
  }).then(({ error }) => {
    if (error) console.error('[levelUp] notification insert failed:', error)
  })
}

/**
 * Compare the player's real level against the last one we celebrated and
 * queue a celebration if it went up.
 *
 * Never throws — a failed check just means we try again on the next poll.
 * First run for a user only records the baseline: we don't want to greet
 * a returning level-27 player with a "LEVEL 27" party on their first load.
 */
export async function checkForLevelUp(userId: string | null | undefined): Promise<void> {
  if (!userId) return

  const existing = inFlight.get(userId)
  if (existing) return existing

  const run = (async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('level, xp')
      .eq('id', userId)
      .maybeSingle<{ level: number | null; xp: number | null }>()

    if (error || !data) return

    const level = Number(data.level) || 1
    const xp    = Number(data.xp) || 0
    const seen  = readBaseline(userId)

    // No baseline yet — this is the first time we've looked at this
    // account on this device. Record and stay quiet.
    if (seen == null) { writeBaseline(userId, level); return }

    // Level went down (a rollback, or an admin correction). Resync
    // silently so the next real level-up still fires.
    if (level <= seen) {
      if (level < seen) writeBaseline(userId, level)
      return
    }

    // Queue one celebration per level crossed, so a big XP drop that
    // spans two levels shows both instead of skipping one. Capped, since
    // an admin granting 500k XP shouldn't mean 50 modals.
    const from = Math.max(seen, level - 3)
    for (let l = from + 1; l <= level; l++) {
      enqueueLevelUp({ id: `${userId}:${l}`, level: l, previousLevel: l - 1, xp })
      recordLevelUpNotification(l, l === level ? xp : cumulativeXpForLevel(l))
    }
    writeBaseline(userId, level)
  })()
    .catch(() => { /* offline / transient — retried by the poll */ })
    .finally(() => { inFlight.delete(userId) })

  inFlight.set(userId, run)
  return run
}

/**
 * Safety net for XP awarded outside the client's sight — mission claims,
 * Halo moments, admin grants — and for level-ups that landed while the tab
 * was hidden. Mount once, alongside the overlay.
 */
export function useLevelUpWatcher(userId: string | null): void {
  useEffect(() => {
    if (!userId) return

    checkForLevelUp(userId)

    const onFocus = () => { if (!document.hidden) checkForLevelUp(userId) }
    const timer = setInterval(onFocus, POLL_MS)
    document.addEventListener('visibilitychange', onFocus)
    window.addEventListener('focus', onFocus)

    return () => {
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onFocus)
      window.removeEventListener('focus', onFocus)
    }
  }, [userId])
}
