// src/features/levelup/useLevelUp.ts
//
// React bindings for levelUpBus.ts.

import { useEffect, useSyncExternalStore } from 'react'
import {
  subscribeLevelUp, getLevelUpSnapshot, dismissLevelUp, blockCelebrations,
  type LevelUpEvent,
} from './levelUpBus'

/**
 * The level-up that should be on screen *right now*, or null.
 *
 * Returns null whenever any part of the app is holding a celebration
 * block, even if a level-up is waiting — the event stays queued and this
 * flips back to it as soon as the block lifts.
 */
export function useLevelUpCelebration(): {
  current: LevelUpEvent | null
  waiting: number
  dismiss: () => void
} {
  const snap = useSyncExternalStore(subscribeLevelUp, getLevelUpSnapshot, getLevelUpSnapshot)
  return {
    current: snap.blocked ? null : (snap.queue[0] ?? null),
    waiting: snap.queue.length,
    dismiss: dismissLevelUp,
  }
}

/**
 * Hold a celebration block for as long as `active` is true.
 *
 * Used by anything that owns the whole screen and shouldn't be interrupted
 * — an in-progress game, a win/lose result screen, a fullscreen cutscene.
 * The block is released automatically on unmount, so a player quitting a
 * game mid-way (or the tab navigating away) can never strand the queue.
 */
export function useCelebrationBlock(active: boolean, reason: string): void {
  useEffect(() => {
    if (!active) return
    return blockCelebrations(reason)
  }, [active, reason])
}
