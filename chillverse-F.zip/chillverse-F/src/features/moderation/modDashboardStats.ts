// src/features/moderation/modDashboardStats.ts
import { supabase } from '../../shared/lib/supabase'

export interface ModAlertStats {
  pending: number
  escalated: number
  bans_issued_7d: number
  resolved_today: number
  resolved_yesterday: number
}

export interface ModReportStats {
  open: number
  escalated: number
  actioned_today: number
  actioned_yesterday: number
  /** Null until at least one report has been reviewed in the last 7 days. */
  avg_resolution_min_7d: number | null
}

export interface ModTicketStats {
  unclaimed: number
  mine: number
  resolved_today: number
}

export interface ModRedeemWatchStats {
  flagged_accounts: number
  failed_15m: number
}

export interface ModUserStats {
  banned: number
  verified: number
  strikes_30d: number
}

export interface ModRoleStats {
  admins: number
  moderators: number
  staff: number
}

export interface ModBadgeStats {
  available: number
  granted_manually_30d: number
}

export interface ModFilterStats {
  total_terms: number
  active_terms: number
  categories: number
}

export interface ModSettingsStats {
  strike_alert_threshold: number
}

export interface ModLogStats {
  actions_today: number
  active_mods_7d: number
}

export interface ModHandoffStats {
  open_notes: number
}

export interface ModDashboardStats {
  generated_at: string
  alerts: ModAlertStats
  reports: ModReportStats
  tickets: ModTicketStats
  redeem_watch: ModRedeemWatchStats
  users: ModUserStats
  roles: ModRoleStats
  badges: ModBadgeStats
  filters: ModFilterStats
  settings: ModSettingsStats
  log: ModLogStats
  handoff: ModHandoffStats
}

/** Fetches the full Concourse dashboard payload in one round trip. The RPC
 *  itself re-checks is_staff() server-side — this call fails safely even
 *  if invoked without ModerationPanel.tsx's own useModRole() guard. */
export async function fetchModDashboardStats(): Promise<{ data: ModDashboardStats | null; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_dashboard_stats')

  if (error) {
    console.error('fetchModDashboardStats error:', error)
    if (error.message?.includes('CV_MOD_FORBIDDEN')) {
      return { data: null, error: "You don't have permission to view this." }
    }
    return { data: null, error: 'Failed to load dashboard stats. Please try again.' }
  }

  return { data: data as ModDashboardStats, error: null }
}

export interface ModActivityRow {
  moderator_id: string
  username: string
  actions: number
  /** Consecutive days ending today with at least one logged action. */
  streak_days: number
}

/** Leaderboard for the "Mod activity" wing — who's handling what over the
 *  last p_days (default 7). Streak is always computed over a 90-day
 *  lookback regardless of p_days, so a longer-running streak isn't
 *  artificially capped by a short leaderboard window. */
export async function fetchModActivityLeaderboard(days = 7): Promise<{ data: ModActivityRow[]; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_activity_leaderboard', { p_days: days })
  if (error) {
    console.error('fetchModActivityLeaderboard error:', error)
    return { data: [], error: 'Failed to load mod activity. Please try again.' }
  }
  return { data: (data as ModActivityRow[] | null) ?? [], error: null }
}
