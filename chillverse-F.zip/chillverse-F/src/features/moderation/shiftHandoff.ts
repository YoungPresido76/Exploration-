// src/features/moderation/shiftHandoff.ts
import { supabase } from '../../shared/lib/supabase'
import { friendlyError } from './moderation'

export interface HandoffNote {
  id: string
  author_id: string
  author_username: string
  body: string
  created_at: string
  is_read: boolean
}

/** Newest first, capped at 50 — matches list_handoff_notes(). Includes whether *I've* read each one. */
export async function fetchHandoffNotes(): Promise<{ data: HandoffNote[]; error: string | null }> {
  const { data, error } = await supabase.rpc('list_handoff_notes')
  return { data: (data as HandoffNote[] | null) ?? [], error: friendlyError(error) }
}

export async function postHandoffNote(body: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('post_handoff_note', { p_body: body })
  return { error: friendlyError(error) }
}

export async function markHandoffNoteRead(noteId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mark_handoff_note_read', { p_note_id: noteId })
  return { error: friendlyError(error) }
}
