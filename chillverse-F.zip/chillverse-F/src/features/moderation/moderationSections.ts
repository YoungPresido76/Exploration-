// src/features/moderation/moderationSections.ts
//
// The moderation "wings" — shared between ModerationPanel.tsx's Concourse
// home (grid, grouped into categories) and its wing screen switch. Grouped
// into 4 categories (unlike adminSections.ts's flat list) because 12 wings
// is dense enough that the mockup's grouping genuinely earns its keep here.
import {
  Bell, Flag, Ticket, Gift, Users, UserCog, TrendingUp, Award, SlidersHorizontal,
  Settings, ScrollText, ClipboardList, Gavel,
} from 'lucide-react'

export type ModerationGroup = 'queue' | 'people' | 'safety' | 'system'

export const MODERATION_GROUPS: { key: ModerationGroup; label: string }[] = [
  { key: 'queue', label: 'Triage queue' },
  { key: 'people', label: 'People & team' },
  { key: 'safety', label: 'Content safety' },
  { key: 'system', label: 'System' },
]

export type ModerationSection =
  | 'alerts' | 'reports' | 'tickets' | 'redeem' | 'appeals' | 'users' | 'roles' | 'mod_activity'
  | 'badges' | 'filters' | 'settings' | 'log' | 'handoff'

export interface ModerationSectionMeta {
  key: ModerationSection
  label: string
  description: string
  icon: typeof Bell
  /** CSS-var color token used for the wing's icon chip on the Concourse grid. */
  tint: string
  group: ModerationGroup
  /** Minimum role required to see/open this wing — mirrors useModRole()'s isStaff/isModOrAdmin/isAdmin gates. */
  access: 'staff' | 'moderator' | 'admin'
}

export const MODERATION_SECTIONS: ModerationSectionMeta[] = [
  { key: 'alerts', label: 'Alerts', description: 'Accounts that crossed the strike threshold', icon: Bell, tint: 'var(--red)', group: 'queue', access: 'staff' },
  { key: 'reports', label: 'Reports', description: 'Player-submitted and auto-flagged content reports', icon: Flag, tint: 'var(--gold)', group: 'queue', access: 'staff' },
  { key: 'tickets', label: 'Tickets', description: 'Support requests from players', icon: Ticket, tint: 'var(--blue)', group: 'queue', access: 'staff' },
  { key: 'redeem', label: 'Redeem watch', description: 'Suspicious redeem-code activity — a read-only log', icon: Gift, tint: 'var(--red)', group: 'queue', access: 'moderator' },
  { key: 'appeals', label: 'Appeals', description: 'Players disputing a post takedown — read-only', icon: Gavel, tint: 'var(--gold)', group: 'queue', access: 'staff' },
  { key: 'users', label: 'Users', description: 'Search, ban, verify, and review account history', icon: Users, tint: 'var(--blue)', group: 'people', access: 'staff' },
  { key: 'roles', label: 'Roles', description: 'Promote or demote staff members', icon: UserCog, tint: 'var(--accent)', group: 'people', access: 'admin' },
  { key: 'mod_activity', label: 'Mod activity', description: "Who's handling what, and activity streaks", icon: TrendingUp, tint: 'var(--purple)', group: 'people', access: 'staff' },
  { key: 'badges', label: 'Badges', description: 'Manage badge availability', icon: Award, tint: 'var(--gold)', group: 'safety', access: 'staff' },
  { key: 'filters', label: 'Filters', description: 'Banned-term categories and patterns', icon: SlidersHorizontal, tint: 'var(--purple)', group: 'safety', access: 'admin' },
  { key: 'settings', label: 'Settings', description: 'Strike alert threshold', icon: Settings, tint: 'var(--text-muted)', group: 'system', access: 'admin' },
  { key: 'log', label: 'Audit log', description: 'Every moderation action, in order', icon: ScrollText, tint: 'var(--blue)', group: 'system', access: 'staff' },
  { key: 'handoff', label: 'Shift handoff', description: "Notes for whoever's on next", icon: ClipboardList, tint: 'var(--green)', group: 'system', access: 'staff' },
]
