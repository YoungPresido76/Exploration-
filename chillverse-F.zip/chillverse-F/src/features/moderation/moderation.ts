// src/features/moderation/moderation.ts
import { supabase } from '../../shared/lib/supabase'
import { isPending } from '../admin/adminRequests'

export type StaffRole = 'user' | 'staff' | 'moderator' | 'admin'

export interface UserModerationRow {
  user_id: string
  role: StaffRole
  is_banned: boolean
  banned_until: string | null
  ban_reason: string | null
  banned_by: string | null
  banned_at: string | null
  is_verified: boolean
}

export interface ContentReport {
  id: string
  reporter_id: string | null
  target_type: 'user' | 'post' | 'comment' | 'message'
  target_id: string
  reason: string
  details: string | null
  status: 'open' | 'reviewed' | 'actioned' | 'dismissed'
  escalated_to_mod: boolean
  escalation_note: string | null
  escalated_by: string | null
  escalated_at: string | null
  created_at: string
  reporter?: { username: string } | null
}

export interface ModerationLogEntry {
  id: string
  moderator_id: string | null
  action: string
  target_type: string
  target_id: string | null
  reason: string | null
  metadata: Record<string, unknown>
  created_at: string
  moderator?: { username: string } | null
}

/** Shared across moderation.ts and staffTickets.ts — both call the same family of mod_ and staff_ RPCs. */
export function friendlyError(error: { message: string } | null): string | null {
  if (!error) return null
  const msg = error.message
  if (msg.includes('CV_MOD_FORBIDDEN')) return "You don't have permission to do that."
  if (msg.includes('CV_MOD_SELF')) return "You can't do that to your own account."
  if (msg.includes('CV_MOD_NOT_FOUND')) return 'That could not be found — it may have already been removed.'
  if (msg.includes('CV_MOD_REASON_REQUIRED')) return 'Please enter a reason.'
  if (msg.includes('CV_MOD_INSUFFICIENT')) return 'Only a moderator or admin can do that — escalate this instead.'
  if (msg.includes('CV_MOD_BAD_ROLE')) return 'Invalid role.'
  if (msg.includes('CV_MOD_BAD_STATUS')) return 'Invalid status.'
  if (msg.includes('CV_MOD_SELF_DEMOTE')) return 'Ask another admin to change your own role.'
  return 'Something went wrong. Please try again.'
}

/** My own staff role + ban status, used to gate the UI. Falls back to 'user' / not banned if no row exists yet. */
export async function getMyModerationStatus(userId: string): Promise<{ role: StaffRole; isBanned: boolean; bannedUntil: string | null; banReason: string | null; isVerified: boolean }> {
  const { data } = await supabase
    .from('user_moderation')
    .select('role, is_banned, banned_until, ban_reason, is_verified')
    .eq('user_id', userId)
    .maybeSingle()

  if (!data) return { role: 'user', isBanned: false, bannedUntil: null, banReason: null, isVerified: false }

  const currentlyBanned = data.is_banned && (!data.banned_until || new Date(data.banned_until) > new Date())
  return { role: data.role as StaffRole, isBanned: currentlyBanned, bannedUntil: data.banned_until, banReason: data.ban_reason, isVerified: data.is_verified ?? false }
}

/**
 * The public slice of another player's moderation row: their staff role, and
 * whether they are currently banned or verified.
 *
 * user_moderation is no longer readable across accounts — its SELECT policy
 * is now "your own row, or staff", because the table also holds ban_reason,
 * banned_by and banned_at, which are internal mod notes and were readable by
 * anyone. This RPC is what replaces those direct lookups; it returns nothing
 * else, and folds is_banned + banned_until into one boolean server-side so a
 * lapsed suspension can't read as active because a caller forgot to compare
 * the date.
 */
export async function getPublicModerationFlags(
  userId: string,
): Promise<{ role: StaffRole; isBanned: boolean; isVerified: boolean }> {
  const { data } = await supabase
    .rpc('public_moderation_flags', { p_user_id: userId })
    .maybeSingle()

  const row = data as { role: string; is_banned: boolean; is_verified: boolean } | null
  if (!row) return { role: 'user', isBanned: false, isVerified: false }
  return {
    role: (row.role as StaffRole) ?? 'user',
    isBanned: !!row.is_banned,
    isVerified: !!row.is_verified,
  }
}

/** Moderator/admin ids the leaderboard leaves off the board. Ids only — the
 *  old query read roles straight off user_moderation, which is now closed. */
export async function getStaffExcludedLeaderboardIds(): Promise<string[]> {
  const { data } = await supabase.rpc('staff_excluded_leaderboard_ids')
  if (!Array.isArray(data)) return []
  // A setof uuid comes back as a bare array of strings through PostgREST.
  return data as string[]
}

export interface PostAppeal {
  id: string
  post_id: string
  author_id: string
  username: string
  display_name: string | null
  avatar: string | null
  reason: string
  excerpt: string
  post_created_at: string | null
  taken_down_at: string
  appealed_at: string
}

/**
 * Takes a feed post down: hides it, records the PUBLIC reason shown in its
 * place, and queues the notice its author sees on next login.
 *
 * Not a delete — the row stays so there is something to show in the timeline
 * and something to appeal against. The body is blanked server-side, since RLS
 * makes a taken-down post readable by everyone.
 */
export async function takedownPost(postId: string, reason: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_takedown_post', { p_post_id: postId, p_reason: reason.trim() })
  return { error: friendlyError(error) }
}

/** Appeals waiting in the mod centre. Read-only: the only control is clear. */
export async function fetchPostAppeals(): Promise<{ data: PostAppeal[]; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_list_appeals')
  return { data: (data ?? []) as PostAppeal[], error: friendlyError(error) }
}

/** Clears an appeal off the list. The takedown record itself is kept — it is
 *  the audit trail for why the post is hidden. */
export async function clearPostAppeal(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_clear_appeal', { p_id: id })
  return { error: friendlyError(error) }
}

export async function fetchOpenReports(): Promise<{ data: ContentReport[]; error: string | null }> {
  const { data, error } = await supabase
    .from('content_reports')
    .select('*, reporter:profiles!content_reports_reporter_id_fkey(username)')
    .order('created_at', { ascending: false })
    .limit(100)

  return { data: (data as ContentReport[] | null) ?? [], error: friendlyError(error) }
}

export async function getReportContext(reportId: string): Promise<{ data: Record<string, unknown> | null; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_get_report_context', { p_report_id: reportId })
  return { data: data as Record<string, unknown> | null, error: friendlyError(error) }
}

export async function reviewReport(reportId: string, status: 'reviewed' | 'actioned' | 'dismissed'): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_review_report', { p_report_id: reportId, p_status: status })
  return { error: friendlyError(error) }
}

/** Staff-tier: hand a report to a moderator instead of deleting/banning directly. */
export async function escalateReport(reportId: string, note: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_escalate_report', { p_report_id: reportId, p_note: note })
  return { error: friendlyError(error) }
}

export interface StaffUserSearchRow {
  user_id: string
  username: string
  display_name: string | null
  avatar: string | null
  role: StaffRole
  is_banned: boolean
}

// ── Live-typeahead search for the Users tab. Unlike searchUserByUsername
//    (which requires the exact, full username), this matches partial
//    username/display-name substrings — so a moderator can start typing
//    and pick from a short list instead of having to already know exactly
//    who they're looking for. Staff-gated server-side, capped at 8 rows,
//    and returns only what's needed to render a result row (no email or
//    wallet data — that's the admin-only search on the Admin dashboard). ─
export async function searchStaffUsers(query: string): Promise<{ data: StaffUserSearchRow[]; error: string | null }> {
  const trimmed = query.trim()
  if (!trimmed) return { data: [], error: null }
  const { data, error } = await supabase.rpc('mod_search_users', { p_search: trimmed, p_limit: 8 })
  if (error) return { data: [], error: friendlyError(error) }
  return { data: (data ?? []) as StaffUserSearchRow[], error: null }
}

export async function searchUserByUsername(username: string): Promise<{ data: (UserModerationRow & { username: string; display_name: string | null }) | null; error: string | null }> {
  const { data: profile, error: pErr } = await supabase
    .from('profiles')
    .select('id, username, display_name')
    .ilike('username', username.trim())
    .maybeSingle()

  if (pErr || !profile) return { data: null, error: pErr ? 'Search failed.' : 'No user found with that username.' }

  const { data: mod } = await supabase
    .from('user_moderation')
    .select('*')
    .eq('user_id', profile.id)
    .maybeSingle()

  return {
    data: {
      user_id: profile.id,
      username: profile.username,
      display_name: profile.display_name,
      role: (mod?.role as StaffRole) ?? 'user',
      is_banned: mod?.is_banned ?? false,
      banned_until: mod?.banned_until ?? null,
      ban_reason: mod?.ban_reason ?? null,
      banned_by: mod?.banned_by ?? null,
      banned_at: mod?.banned_at ?? null,
      is_verified: mod?.is_verified ?? false,
    },
    error: null,
  }
}

export async function setVerified(targetId: string, verified: boolean): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_set_verified', { p_target_id: targetId, p_verified: verified })
  return { error: friendlyError(error) }
}

export async function banUser(targetId: string, reason: string, durationHours: number | null): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_ban_user', { p_target_id: targetId, p_reason: reason, p_duration_hours: durationHours })
  if (error) return { error: friendlyError(error) }

  // Best-effort: the ban itself already succeeded and is fully in effect
  // regardless of whether the email goes out, so a failure here is logged
  // but not surfaced as if the ban itself failed.
  const { error: emailError } = await supabase.functions.invoke('send-ban-notice', {
    body: { target_user_id: targetId },
  })
  if (emailError) console.error('[moderation] ban notice email failed to send:', emailError)

  return { error: null }
}

/**
 * Writes (or clears) the notice OTHER players see on a suspended account's
 * profile. Deliberately separate from banUser: this text is public and is
 * NOT ban_reason, which stays internal to the mod tools. Passing an empty
 * title clears the whole notice — the headline is what carries it, so a
 * reason with no headline would render as a floating sentence.
 *
 * Kept as its own RPC rather than extra parameters on mod_ban_user for two
 * reasons: adding defaulted params there would leave the old 3-arg signature
 * in place and make every call ambiguous through PostgREST (the trap that
 * forced the pvp_skip_cooldown and update_club_settings drops), and a notice
 * often needs editing after the ban is already in force.
 */
export async function setPublicNotice(
  targetId: string,
  title: string,
  reason: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_set_public_notice', {
    p_target_id: targetId,
    p_title: title.trim() || null,
    p_reason: reason.trim() || null,
  })
  return { error: friendlyError(error) }
}

export async function unbanUser(targetId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_unban_user', { p_target_id: targetId })
  return { error: friendlyError(error) }
}

/** Role changes are owner-gated since migration 0160b: the owner's own row
 *  can't be edited at all, and any other admin's change is queued for
 *  approval instead of applied — `pending` says which happened. */
export async function setUserRole(targetId: string, role: StaffRole): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_set_role', { p_target_id: targetId, p_role: role })
  if (error) return { pending: false, error: friendlyError(error) }
  return { pending: isPending(data), error: null }
}

export async function deleteMessage(messageId: string, reason?: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_delete_message', { p_message_id: messageId, p_reason: reason ?? null })
  return { error: friendlyError(error) }
}

export async function deletePost(postId: string, reason?: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_delete_post', { p_post_id: postId, p_reason: reason ?? null })
  return { error: friendlyError(error) }
}

export async function deleteComment(commentId: string, reason?: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_delete_comment', { p_comment_id: commentId, p_reason: reason ?? null })
  return { error: friendlyError(error) }
}

export async function fetchModerationLog(): Promise<{ data: ModerationLogEntry[]; error: string | null }> {
  const { data, error } = await supabase
    .from('moderation_log')
    .select('*, moderator:profiles!moderation_log_moderator_id_fkey(username)')
    .order('created_at', { ascending: false })
    .limit(100)

  return { data: (data as ModerationLogEntry[] | null) ?? [], error: friendlyError(error) }
}

export interface Strike {
  id: string
  category: string
  target_type: 'message' | 'post' | 'comment'
  target_id: string
  created_at: string
}

export interface StaffAlert {
  id: string
  user_id: string
  strike_count: number
  resolved: boolean
  escalated: boolean
  escalation_note: string | null
  escalated_by: string | null
  escalated_at: string | null
  created_at: string
  user?: { username: string } | null
}

/** Strike history for one user — shown on their card in the Users tab. */
export async function fetchStrikes(userId: string): Promise<{ data: Strike[]; error: string | null }> {
  const { data, error } = await supabase
    .from('strikes')
    .select('id, category, target_type, target_id, created_at')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })

  return { data: (data as Strike[] | null) ?? [], error: friendlyError(error) }
}

/** Unresolved staff pings — someone just crossed the strike threshold and needs a ban/no-ban decision. */
export async function fetchUnresolvedAlerts(): Promise<{ data: StaffAlert[]; error: string | null }> {
  const { data, error } = await supabase
    .from('staff_alerts')
    .select('*, user:profiles!staff_alerts_user_id_fkey(username)')
    .eq('resolved', false)
    .order('created_at', { ascending: false })

  return { data: (data as StaffAlert[] | null) ?? [], error: friendlyError(error) }
}

export async function resolveAlert(alertId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_resolve_alert', { p_alert_id: alertId })
  return { error: friendlyError(error) }
}

/** Staff-tier: hand a strike alert to a moderator instead of banning directly. */
export async function escalateAlert(alertId: string, note: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_escalate_alert', { p_alert_id: alertId, p_note: note })
  return { error: friendlyError(error) }
}

export async function unhideContent(targetType: 'message' | 'post' | 'comment', targetId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_unhide_content', { p_target_type: targetType, p_target_id: targetId })
  return { error: friendlyError(error) }
}

// ── Bulk report actions ───────────────────────────────────────────────

/** Flips every currently-open report in the list to 'dismissed' in one call. Returns how many were actually changed. */
export async function bulkDismissReports(reportIds: string[]): Promise<{ count: number; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_bulk_dismiss_reports', { p_report_ids: reportIds })
  return { count: (data as number | null) ?? 0, error: friendlyError(error) }
}

/**
 * Bulk delete-and-action and bulk ban loop over the existing single-item
 * RPCs (mod_delete_* / mod_ban_user already carry the right permission
 * checks and audit logging per item; report targets are heterogeneous by
 * type, so there's no single atomic RPC that would meaningfully simplify
 * this). Best-effort: one failure doesn't block the rest of the batch.
 */
export async function bulkDeleteAndActionReports(reports: ContentReport[]): Promise<{ succeeded: string[]; failed: string[] }> {
  const succeeded: string[] = []
  const failed: string[] = []
  await Promise.all(reports.map(async r => {
    let result: { error: string | null }
    if (r.target_type === 'message') result = await deleteMessage(r.target_id, 'Deleted from report review (bulk)')
    else if (r.target_type === 'post') result = await deletePost(r.target_id, 'it went against our Terms and Conditions')
    else if (r.target_type === 'comment') result = await deleteComment(r.target_id, 'Deleted from report review (bulk)')
    else { failed.push(r.id); return }

    if (result.error) { failed.push(r.id); return }
    const { error: reviewError } = await reviewReport(r.id, 'actioned')
    if (reviewError) { failed.push(r.id); return }
    succeeded.push(r.id)
  }))
  return { succeeded, failed }
}

/** Bans every user behind a set of user-type reports, then dismisses those reports. */
export async function bulkBanReportedUsers(reports: ContentReport[], reason: string, durationHours: number | null): Promise<{ succeeded: string[]; failed: string[] }> {
  const succeeded: string[] = []
  const failed: string[] = []
  await Promise.all(reports.map(async r => {
    if (r.target_type !== 'user') { failed.push(r.id); return }
    const { error: banError } = await banUser(r.target_id, reason, durationHours)
    if (banError) { failed.push(r.id); return }
    const { error: reviewError } = await reviewReport(r.id, 'actioned')
    if (reviewError) { failed.push(r.id); return }
    succeeded.push(r.id)
  }))
  return { succeeded, failed }
}

// ── Word filter (banned terms) ────────────────────────────────────────

export type BannedTermCategory =
  | 'hate_speech' | 'profanity' | 'threat_of_violence'
  | 'self_harm_directed' | 'doxxing' | 'illegal_activity' | 'phishing_scam'

export const BANNED_TERM_CATEGORY_LABELS: Record<BannedTermCategory, string> = {
  hate_speech: 'Hate speech',
  profanity: 'Profanity',
  threat_of_violence: 'Threat of violence',
  self_harm_directed: 'Self-harm (directed at someone)',
  doxxing: 'Doxxing',
  illegal_activity: 'Illegal activity solicitation',
  phishing_scam: 'Phishing / scam',
}

export interface BannedTerm {
  id: string
  category: BannedTermCategory
  pattern: string
  active: boolean
  created_by: string | null
  created_at: string
}

export async function fetchBannedTerms(): Promise<{ data: BannedTerm[]; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_list_banned_terms')
  return { data: (data as BannedTerm[] | null) ?? [], error: friendlyError(error) }
}

export async function addBannedTerm(category: BannedTermCategory, pattern: string): Promise<{ data: BannedTerm | null; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_add_banned_term', { p_category: category, p_pattern: pattern })
  return { data: data as BannedTerm | null, error: friendlyError(error) }
}

export async function updateBannedTerm(id: string, updates: { pattern?: string; active?: boolean }): Promise<{ data: BannedTerm | null; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_update_banned_term', {
    p_id: id, p_pattern: updates.pattern ?? null, p_active: updates.active ?? null,
  })
  return { data: data as BannedTerm | null, error: friendlyError(error) }
}

export async function deleteBannedTerm(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_delete_banned_term', { p_id: id })
  return { error: friendlyError(error) }
}

// ── Strike threshold / moderation settings ──────────────────────────────

export interface ModerationSettings {
  id: number
  strike_alert_threshold: number
  updated_at: string
  updated_by: string | null
}

export async function fetchModerationSettings(): Promise<{ data: ModerationSettings | null; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_get_settings')
  return { data: data as ModerationSettings | null, error: friendlyError(error) }
}

export async function updateStrikeThreshold(threshold: number): Promise<{ data: ModerationSettings | null; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_update_strike_threshold', { p_threshold: threshold })
  return { data: data as ModerationSettings | null, error: friendlyError(error) }
}

// ── User notes / history timeline ───────────────────────────────────────

export type UserHistoryEntry =
  | { type: 'strike'; id: string; created_at: string; category: string; target_type: string }
  | { type: 'log'; id: string; created_at: string; action: string; reason: string | null; metadata: Record<string, unknown>; moderator: string | null }
  | { type: 'note'; id: string; created_at: string; note: string; author: string | null }

export async function fetchUserHistory(userId: string): Promise<{ data: UserHistoryEntry[]; error: string | null }> {
  const { data, error } = await supabase.rpc('mod_get_user_history', { p_user_id: userId })
  return { data: (data as UserHistoryEntry[] | null) ?? [], error: friendlyError(error) }
}

export async function addUserNote(userId: string, note: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('mod_add_user_note', { p_user_id: userId, p_note: note })
  return { error: friendlyError(error) }
}
