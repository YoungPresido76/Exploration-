// src/features/moderation/useModRole.ts
import { useEffect, useState } from 'react'
import { useAuth } from '../auth/useAuth'
import { getMyModerationStatus, type StaffRole } from './moderation'

interface ModRoleState {
  role: StaffRole
  isStaff: boolean
  isAdmin: boolean
  isModOrAdmin: boolean
  isVerified: boolean
  /** Staff/Moderator/Admin or Verified — the only roles allowed to create a poll. */
  canCreatePoll: boolean
  loading: boolean
}

// ── Shared, like useProfile ──────────────────────────────────────────
//
// 26 components call this, and every one of them used to hit
// user_moderation on mount. Unlike the profile row this one is close to
// immutable within a session — your role doesn't change while you're
// using the app — so it's cached for the whole session rather than on a
// short TTL, with one in-flight request shared by every caller.
//
// Getting it from cache also means `loading` is false on the very first
// render for everything mounted after the first check. That matters:
// AppLayout holds a BLANK SCREEN while roleLoading is true on the
// maintenance path, and several screens hide staff-only controls behind
// it, so a per-component loading flag was a visible flash each time.
interface Snapshot {
  role: StaffRole
  isVerified: boolean
  loading: boolean
}

let snapshot: Snapshot = { role: 'user', isVerified: false, loading: true }
let fetchedFor: string | null = null
let inFlight: Promise<void> | null = null
const listeners = new Set<() => void>()

function setSnapshot(next: Snapshot) {
  snapshot = next
  listeners.forEach(l => l())
}

function load(userId: string, force: boolean): Promise<void> {
  if (!force && fetchedFor === userId && !snapshot.loading) return Promise.resolve()
  if (inFlight && !force) return inFlight

  if (fetchedFor !== userId) setSnapshot({ role: 'user', isVerified: false, loading: true })

  inFlight = getMyModerationStatus(userId)
    .then(status => {
      fetchedFor = userId
      setSnapshot({ role: status.role, isVerified: status.isVerified, loading: false })
    })
    .catch(() => {
      fetchedFor = userId
      setSnapshot({ role: 'user', isVerified: false, loading: false })
    })
    .finally(() => { inFlight = null })

  return inFlight
}

/** Drop the cached role — sign-out, or an account switch. */
export function resetModRoleCache() {
  fetchedFor = null
  inFlight = null
  setSnapshot({ role: 'user', isVerified: false, loading: false })
}

/** Re-read the role from the server (e.g. right after a promotion in admin). */
export function refreshModRole() {
  if (fetchedFor) void load(fetchedFor, true)
}

/** Reads the signed-in user's moderator/admin role. Defaults to 'user' while loading or if no session. */
export function useModRole(): ModRoleState {
  const { user } = useAuth()
  const [, forceRender] = useState(0)

  useEffect(() => {
    const listener = () => forceRender(n => n + 1)
    listeners.add(listener)
    return () => { listeners.delete(listener) }
  }, [])

  useEffect(() => {
    if (!user) {
      if (fetchedFor !== null || snapshot.loading || snapshot.role !== 'user') resetModRoleCache()
      return
    }
    if (fetchedFor && fetchedFor !== user.id) resetModRoleCache()
    void load(user.id, false)
  }, [user])

  const role = snapshot.role
  const isStaff = role === 'staff' || role === 'moderator' || role === 'admin'
  return {
    role,
    isStaff,
    isAdmin: role === 'admin',
    isModOrAdmin: role === 'moderator' || role === 'admin',
    isVerified: snapshot.isVerified,
    canCreatePoll: isStaff || snapshot.isVerified,
    loading: user ? snapshot.loading : false,
  }
}
