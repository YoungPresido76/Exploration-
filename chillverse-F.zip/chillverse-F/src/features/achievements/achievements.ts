// src/lib/achievements.ts
import { supabase } from '../../shared/lib/supabase'
import { emitBadgeSeen } from '../../shared/lib/badgeBus'
import { checkForLevelUp } from '../levelup/levelUpDetector'

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  category: 'xp' | 'streak' | 'games' | 'social' | 'rank' | 'special' | 'mall' | 'premium' | 'cinema' | 'pvp' | 'impostor'
  xp_reward: number
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  reward_type: 'xp' | 'profile_pic' | 'banner' | null
  reward_url: string | null
  reward_item_id: string | null
}

export interface PlayerAchievement {
  achievement_id: string
  unlocked_at: string
}

// ── Fetch all achievement definitions ────────────────────────
export async function getAllAchievements(): Promise<Achievement[]> {
  const { data } = await supabase.from('achievements').select('*').order('category').order('xp_reward')
  return (data ?? []) as Achievement[]
}

// ── Fetch a single achievement (used for post tag previews) ──
const achievementCache = new Map<string, Achievement | null>()
export async function getAchievementById(id: string): Promise<Achievement | null> {
  if (achievementCache.has(id)) return achievementCache.get(id) ?? null
  const { data } = await supabase.from('achievements').select('*').eq('id', id).single()
  const ach = (data as Achievement) ?? null
  achievementCache.set(id, ach)
  return ach
}

// ── Fetch which ones a player has unlocked ───────────────────
export async function getPlayerAchievements(userId: string): Promise<PlayerAchievement[]> {
  const { data } = await supabase
    .from('player_achievements')
    .select('achievement_id, unlocked_at')
    .eq('user_id', userId)
  return (data ?? []) as PlayerAchievement[]
}

// ── Unlock an achievement + send notification ─────────────────
// Note: this no longer fires the "Halo Saw That" reaction itself — when a
// batch of achievements unlock together (e.g. a new player clearing several
// easy conditions at once), firing that reaction once per achievement here
// used to flood the toast pipeline with several Halo commendations back to
// back. checkAndUnlockAchievements() now fires it (at most) once per batch,
// after every unlock in the batch has resolved — see below.
export async function unlockAchievement(userId: string, achievementId: string): Promise<boolean> {
  // Idempotent — ignore if already unlocked
  const { error } = await supabase
    .from('player_achievements')
    .insert({ user_id: userId, achievement_id: achievementId })

  if (error) return false // already unlocked or DB error

  // Fetch achievement details for notification + reward granting
  const { data: ach } = await supabase
    .from('achievements')
    .select('title, description, icon, xp_reward, reward_type, reward_item_id')
    .eq('id', achievementId)
    .single()

  if (ach) {
    // ── Grant the XP reward ──
    // award_xp is SECURITY DEFINER and only allows auth.uid() = p_user_id,
    // so this only ever runs for the currently-logged-in player.
    if (ach.xp_reward > 0) {
      const { error: xpError } = await supabase.rpc('award_xp', {
        p_user_id: userId,
        p_xp: ach.xp_reward,
      })
      if (xpError) console.error('[unlockAchievement] award_xp failed:', xpError)
      else checkForLevelUp(userId)
    }

    // ── Grant the profile_pic / banner reward into inventory ──
    // The client used to insert the row itself, naming the item — which
    // meant the item id was attacker-controlled. grant_achievement_reward
    // takes only the achievement id and looks the reward up server-side,
    // so the worst a forged call can do is re-grant something already
    // earned. Idempotent: re-granting an owned item is a no-op.
    if ((ach.reward_type === 'profile_pic' || ach.reward_type === 'banner') && ach.reward_item_id) {
      const { error: invError } = await supabase.rpc('grant_achievement_reward', {
        p_achievement_id: achievementId,
      })
      if (invError) {
        console.error('[unlockAchievement] inventory grant failed:', invError)
      }
    }

    await supabase.rpc('notify_self', {
      p_type: 'achievement',
      p_title: `Achievement Unlocked: ${ach.title}`,
      p_body: ach.description,
      p_icon: ach.icon,
      p_meta: { achievement_id: achievementId, xp_reward: ach.xp_reward },
    })
  }

  return true
}

// ── Check and unlock achievements based on current player state ──
export interface AchievementCheckPayload {
  userId: string
  xp: number
  level: number
  streak: number
  totalSessions: number
  gamesPlayed: Set<string>
  topScore: number
  gameRanks: Record<string, string>
  followingCount: number
  followerCount: number
  messagesSent: number
  dmSent: boolean
  profileComplete: boolean
  joinedEarly: boolean
  playedAfterMidnight: boolean
  completedIn30Sec: boolean
  perfectScore: boolean
  // ── New fields ──
  mallItemCount: number          // total mall items owned
  modelCount: number             // models owned (sub_category = 'model')
  diamondPurchaseCount: number   // total diamond purchase transactions
  diamondTopUpCount: number      // total top-up events
  ownsAllWilliamItems: boolean   // owns all items with brand = 'william'
  animeTriviaWins: number        // times won anime_trivia game
  totalGameWins: number          // total wins across all games
  chillverseVersion: number      // profile app version (2 = v2)
  completedWeeklyMission: boolean
  ownsSabrina: boolean           // owns item named 'Sabrina'
  totalGameLosses: number        // total game losses
  moviesWatched: number          // movies watched count
  giftsGiven: number             // gifts sent to other users
  flashSalesUsed: number         // flash sale purchases made
  // ── UNO / Pattern King ──
  unoMatchesWon: number          // total UNO wins
  unoFastestWinSec: number       // fastest UNO win, in seconds (Infinity if none)
  patternKingFastestWinSec: number // fastest Pattern King clear, in seconds (Infinity if none)
  // ── PvP ──
  pvpSoloKills: number            // kills landed with a single card (no combo assist)
  pvpFirstBloodClaims: number     // times this player has claimed First Blood
  pvpRevengeKills: number         // kills landed via a spent Revenge Shot
  pvpBrutalCombos: number         // three-card BRUTAL combo attacks landed
  pvpEliminationSurvivals: number // Elimination Rounds survived to the payout
  pvpMostWantedReached: boolean   // ever flagged Most Wanted (pvp_state.most_wanted)
  // ── Impostor ──
  // All five come from game_sessions.metadata.stats, which _impostor_finish
  // writes server-side. Matches played before that migration have no stats
  // blob, so they count toward impostorMatches only.
  impostorMatches: number         // finished Impostor matches
  impostorCatches: number         // thieves caught, all matches
  impostorSurvivals: number       // rounds survived as a thief
  impostorSweeps: number          // rounds where this police cleared the board
  impostorCleanMatch: boolean     // a whole match as thief, never caught
}

export async function checkAndUnlockAchievements(payload: AchievementCheckPayload) {
  const { userId } = payload

  // Already unlocked set
  const { data: existing } = await supabase
    .from('player_achievements')
    .select('achievement_id')
    .eq('user_id', userId)
  const unlocked = new Set((existing ?? []).map((r: { achievement_id: string }) => r.achievement_id))
  // Every id newly unlocked during this single check-run — used below to
  // fire at most one "Halo Saw That" reaction for the whole batch, instead
  // of one per achievement (which used to flood new/active players with a
  // wall of Halo commendation toasts whenever several conditions cleared
  // at once).
  const newlyUnlocked: string[] = []

  async function tryUnlock(id: string) {
    if (!unlocked.has(id)) {
      const success = await unlockAchievement(userId, id)
      if (success) {
        unlocked.add(id)
        newlyUnlocked.push(id)
      }
    }
  }

  // ── XP Milestones ──
  if (payload.xp >= 100)    await tryUnlock('xp_100')
  if (payload.xp >= 500)    await tryUnlock('xp_500')
  if (payload.xp >= 1000)   await tryUnlock('xp_1000')
  if (payload.xp >= 5000)   await tryUnlock('xp_5000')
  if (payload.xp >= 10000)  await tryUnlock('xp_10000')
  if (payload.xp >= 25000)  await tryUnlock('xp_25000')
  if (payload.xp >= 50000)  await tryUnlock('xp_50000')
  if (payload.xp >= 100000) await tryUnlock('xp_100000')

  // ── Level Milestones ──
  if (payload.level >= 5)  await tryUnlock('level_5')
  if (payload.level >= 10) await tryUnlock('level_10')
  if (payload.level >= 25) await tryUnlock('level_25')
  if (payload.level >= 50) await tryUnlock('level_50')

  // ── Streaks ──
  if (payload.streak >= 3)   await tryUnlock('streak_3')
  if (payload.streak >= 7)   await tryUnlock('streak_7')
  if (payload.streak >= 14)  await tryUnlock('streak_14')
  if (payload.streak >= 30)  await tryUnlock('streak_30')
  if (payload.streak >= 60)  await tryUnlock('streak_60')
  if (payload.streak >= 100) await tryUnlock('streak_100')

  // ── First plays ──
  const GAME_MAP: Record<string, string> = {
    trivia_clash: 'play_trivia',
    speed_math: 'play_speed_math', rapid_sort: 'play_rapid_sort',
    arrow_dash: 'play_arrow_dash', pattern_memory: 'play_pattern',
    two_truths: 'play_two_truths', tac_zone: 'play_tac_zone',
    liars_grid: 'play_liars_grid',
    uno: 'uno_first_draw', pattern_king: 'pk_memory_rookie',
  }
  for (const [game, achId] of Object.entries(GAME_MAP)) {
    if (payload.gamesPlayed.has(game)) await tryUnlock(achId)
  }
  if (Object.keys(GAME_MAP).every(g => payload.gamesPlayed.has(g))) await tryUnlock('play_all_games')

  // ── Score milestones ──
  if (payload.topScore >= 50)  await tryUnlock('score_50')
  if (payload.topScore >= 100) await tryUnlock('score_100')
  if (payload.topScore >= 250) await tryUnlock('score_250')
  if (payload.topScore >= 500) await tryUnlock('score_500')

  // ── Session counts ──
  if (payload.totalSessions >= 10)  await tryUnlock('sessions_10')
  if (payload.totalSessions >= 50)  await tryUnlock('sessions_50')
  if (payload.totalSessions >= 100) await tryUnlock('sessions_100')
  if (payload.totalSessions >= 500) await tryUnlock('sessions_500')

  // ── Game ranks ──
  const ranks = Object.values(payload.gameRanks)
  if (ranks.includes('intermediate') || ranks.includes('advanced') || ranks.includes('master')) await tryUnlock('rank_intermediate')
  if (ranks.includes('advanced') || ranks.includes('master')) await tryUnlock('rank_advanced')
  if (ranks.includes('master')) await tryUnlock('rank_master')
  if (Object.keys(GAME_MAP).length > 0 && Object.keys(GAME_MAP).every(g => payload.gameRanks[g] === 'master')) await tryUnlock('rank_master_all')

  // ── Global rank tiers (based on XP) ──
  if (payload.xp >= 1500)    await tryUnlock('tier_bronze')
  if (payload.xp >= 15000)   await tryUnlock('tier_silver')
  if (payload.xp >= 63000)   await tryUnlock('tier_gold')
  if (payload.xp >= 165000)  await tryUnlock('tier_platinum')
  if (payload.xp >= 345000)  await tryUnlock('tier_diamond')
  if (payload.xp >= 675000)  await tryUnlock('tier_legend')

  // ── Social ──
  if (payload.messagesSent >= 1)  await tryUnlock('social_first_msg')
  if (payload.followingCount >= 1)  await tryUnlock('social_follow_1')
  if (payload.followingCount >= 10) await tryUnlock('social_follow_10')
  if (payload.followerCount >= 1)   await tryUnlock('social_followed')
  if (payload.dmSent)               await tryUnlock('social_dm')

  // ── Special ──
  if (payload.joinedEarly)           await tryUnlock('special_early')
  if (payload.profileComplete)       await tryUnlock('special_profile')
  if (payload.playedAfterMidnight)   await tryUnlock('special_night_owl')
  if (payload.completedIn30Sec)      await tryUnlock('special_speed_run')
  if (payload.perfectScore)          await tryUnlock('special_perfect')

  // ── Mall & Inventory ──
  if (payload.mallItemCount >= 20)    await tryUnlock('mall_hoarder')
  if (payload.modelCount >= 5)        await tryUnlock('brands_active')
  if (payload.ownsAllWilliamItems)    await tryUnlock('willamtronic')
  if (payload.ownsSabrina)            await tryUnlock('sabrina_fan')

  // ── Premium / Diamonds ──
  if (payload.diamondPurchaseCount >= 1)  await tryUnlock('diamond_purse')
  if (payload.diamondTopUpCount >= 5)     await tryUnlock('premium_lifestyle')

  // ── Games extended ──
  if (payload.animeTriviaWins >= 10)  await tryUnlock('animatron')
  if (payload.totalGameWins >= 50)    await tryUnlock('counting_stars')
  if (payload.totalGameLosses >= 10)  await tryUnlock('badluck')

  // ── App / Platform ──
  if (payload.chillverseVersion >= 2) await tryUnlock('gen2')
  if (payload.completedWeeklyMission) await tryUnlock('runner_up')

  // ── Social extended ──
  if (payload.followerCount >= 100)   await tryUnlock('super_star')
  if (payload.followerCount >= 20)    await tryUnlock('lone_star')
  if (payload.followingCount >= 30)   await tryUnlock('that_one_follow_up')
  if (payload.giftsGiven >= 5)        await tryUnlock('blessed_hands')

  // ── Cinema ──
  if (payload.moviesWatched >= 5)     await tryUnlock('cinema_sim')

  // ── Shop / Sales ──
  if (payload.flashSalesUsed >= 5)    await tryUnlock('smart_sim')

  // ── UNO ──
  if (payload.unoMatchesWon >= 1)              await tryUnlock('uno_beginners_luck')
  if (payload.unoFastestWinSec <= 120)         await tryUnlock('uno_speed_demon')
  if (payload.unoMatchesWon >= 5)              await tryUnlock('uno_fire')
  if (payload.unoMatchesWon >= 30)             await tryUnlock('uno_master')

  // ── Pattern King ──
  if (payload.patternKingFastestWinSec <= 30)  await tryUnlock('pk_quick_thinker')
  if (payload.gameRanks['pattern_king'] === 'master') await tryUnlock('pk_memory_genius')

  // ── PvP ──
  if (payload.pvpSoloKills >= 5)          await tryUnlock('pvp_lone_wolf')
  if (payload.pvpFirstBloodClaims >= 1)   await tryUnlock('pvp_first_blood')
  if (payload.pvpRevengeKills >= 1)       await tryUnlock('pvp_payback')
  if (payload.pvpBrutalCombos >= 1)       await tryUnlock('pvp_brutal_combo')
  if (payload.pvpEliminationSurvivals >= 1) await tryUnlock('pvp_last_standing')
  if (payload.pvpMostWantedReached)       await tryUnlock('pvp_most_wanted')

  // ── Impostor ──
  if (payload.impostorMatches >= 1)    await tryUnlock('impostor_rookie')
  if (payload.impostorMatches >= 25)   await tryUnlock('impostor_legend')
  if (payload.impostorCatches >= 5)    await tryUnlock('impostor_catch_5')
  if (payload.impostorSurvivals >= 5)  await tryUnlock('impostor_ghost_5')
  if (payload.impostorSweeps >= 1)     await tryUnlock('impostor_sweep')
  if (payload.impostorCleanMatch)      await tryUnlock('impostor_untouchable')

  // "Halo Saw That" (Halo Moments plan §4.7) — low-frequency flavor
  // reaction on top of a REAL unlock event. Fired at most once per call to
  // checkAndUnlockAchievements(), regardless of how many achievements just
  // unlocked in this batch — never once per achievement. Fire-and-forget,
  // same convention as triggerAchievementCheck — never blocks or fails the
  // achievement check itself.
  if (newlyUnlocked.length > 0) {
    const { notifyHaloSawThat } = await import('../halo-moments/haloMoments')
    notifyHaloSawThat(userId).catch(console.error)
  }
}

// ── Notification helpers ──────────────────────────────────────
export async function getNotifications(userId: string) {
  const { data } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50)
  return data ?? []
}

export async function markNotificationsRead(userId: string) {
  await supabase.from('notifications').update({ read: true }).eq('user_id', userId).eq('read', false)
  // Tell the bell in the Topbar it can drop its count now — it has no other
  // way to learn about a read that happened in this tab.
  emitBadgeSeen('notifications')
}

export async function getUnreadCount(userId: string): Promise<number> {
  const { count } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('read', false)
  return count ?? 0
}

// ── Social notification senders ───────────────────────────────
// These are now thin wrappers over per-action RPCs (migration 0105).
// The title/body used to be composed here and passed to
// insert_notification, which meant any authenticated client could send
// any user arbitrary text under a legitimate notification type — it
// renders in the bell indistinguishably from a real Chillverse message.
// The RPCs take the actor from auth.uid(), verify the action against the
// row that proves it (a follows row, a profile_likes row, a calls row, a
// messages row) and compose the copy server-side, so there is no longer
// a text argument to abuse on these paths.
//
// The actor argument each of these used to take is gone: the server uses
// the caller's own identity, so passing someone else's id was never
// meaningful and is now impossible.

export async function notifyFollow(targetId: string) {
  const { error } = await supabase.rpc('notify_follow', { p_target: targetId })
  if (error) console.error('notify_follow error:', error)
}

export async function notifyProfileView(profileId: string) {
  const { error } = await supabase.rpc('notify_profile_view', { p_target: profileId })
  if (error) console.error('notify_profile_view error:', error)
}

export async function notifyProfileLike(profileId: string) {
  const { error } = await supabase.rpc('notify_profile_like', { p_target: profileId })
  if (error) console.error('notify_profile_like error:', error)
}

// Takes the message id, not its text — the preview is derived from the
// stored row server-side, so a notification can never claim the message
// said something it didn't. Also fans out to the room's other members in
// one call, replacing the old per-recipient client loop.
export async function notifyMessage(messageId: string) {
  const { error } = await supabase.rpc('notify_message', { p_message_id: messageId })
  if (error) console.error('notify_message error:', error)
}

// @mentions — takes the message id + the ids the client resolved from
// @username tokens against the room's membership. notify_mention()
// re-verifies each id is actually a member of that message's room before
// sending, and composes "You were tagged in {room}" server-side.
export async function notifyMention(messageId: string, mentionedUserIds: string[]) {
  if (mentionedUserIds.length === 0) return
  const { error } = await supabase.rpc('notify_mention', { p_message_id: messageId, p_mentioned_ids: mentionedUserIds })
  if (error) console.error('notify_mention error:', error)
}

export async function notifyMissedCall(calleeId: string) {
  const { error } = await supabase.rpc('notify_missed_call', { p_callee: calleeId })
  if (error) console.error('notify_missed_call error:', error)
}

// Rank Tag — fans out to every user currently in the tagged rank group.
// The actual fan-out INSERT happens server-side in notify_rank_tag() (one
// bulk query, not a client loop) since a popular group could be thousands
// of users; this is just the thin RPC call.
export async function notifyRankTag(senderId: string, rankGroup: string, opts: { messageId?: string; postId?: string }) {
  await supabase.rpc('notify_rank_tag', {
    p_rank_group: rankGroup,
    p_sender_id:  senderId,
    p_message_id: opts.messageId ?? null,
    p_post_id:    opts.postId ?? null,
  })
}

// notifyRankUp / notifyFollowersRankUp / notifyFollowersStreak used to
// live here. All three were dead — nothing in the app ever called them,
// and the rank_up / followed_rank_up / streak rows in production come
// from server-side functions (update_streak, recompute_leaderboard_rank_badges)
// instead. They were also three more client loops sending arbitrary text
// to other users, so they're removed rather than migrated.
