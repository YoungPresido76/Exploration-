// src/pages/Mall.tsx
import type React from 'react'
import { useState, useMemo, useCallback, useEffect, createContext, useContext } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import {
  ChevronRight, Image as ImageIcon, Shirt, Zap,
  Lock, X, ShoppingBag, Heart, Eye, Sparkles, Swords, Gift as GiftIcon, Plus,
  Timer, Hourglass, Palette,
} from 'lucide-react'

import { ripple } from '../../shared/lib/ripple'
import { useRealViewportHeight, useSheetDrag } from '../../shared/hooks/useBottomSheet'
import { supabase } from '../../shared/lib/supabase'
import { updateMissionProgress } from '../missions/weeklyMissions'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { isProActive } from '../../shared/lib/proPlans'
import { useMallItems } from './useMallItems'
import { useMallNewBadges, NewDot } from './useMallNewBadges'
import BattleCardsSection from '../pvp/BattleCardsSection'
import { useWallet } from './useWallet'
import SendGiftModal, { giftResultMessage } from './SendGiftModal'
import type { MallItem, MallRarity } from '../../shared/types'
import { fetchCollabs, collabTitle } from '../collab/collabApi'
import PageOnboarding from '../onboarding/PageOnboarding'
import ProfileEffectPreview from './ProfileEffectPreview'
import CustomizeSheet from './CustomizeSheet'
import { canHaveVariants, fetchItemVariants, type VariantPurchaseResult } from './itemVariants'
import { usePageHeader } from '../../context/PageHeader'
import { useFeatureFlags } from '../../shared/lib/featureFlags'
import { useModRole } from '../moderation/useModRole'
import FeatureGateScreen from '../../shared/components/FeatureGateScreen'
import Avatar from '../../shared/components/Avatar'

// Whether the viewing user has an active Pro (Orbit/Void) plan. Provided
// once at the top of Mall() and read by SquareCard/RectCard/ItemModal so
// is_pro_locked items don't need isPro threaded through every page wrapper.
const MallProContext = createContext(false)
// User's current total XP, read by SquareCard/RectCard/ItemModal so
// unlock_xp gated items can be checked without prop-drilling profile.xp
// through every page wrapper.
const MallXpContext = createContext(0)
// Published collab id → name, for items tagged to a collab (migration
// 0124). Same reason as the two above: the item sheet is reached through
// four different page wrappers, and threading a lookup map through all of
// them to render one line of text isn't worth it.
const MallCollabContext = createContext<Record<string, string>>({})


/* ══════════════════════════════════════════════════════
   WISHLIST TOAST
══════════════════════════════════════════════════════ */
function WishlistToast({ message, onDone }: { message: string; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 2500); return () => clearTimeout(t) }, [])
  return (
    <div style={{
      position: 'fixed', bottom: 90, left: '50%',
      zIndex: 9999, background: 'color-mix(in srgb, var(--nav) 94%, transparent)', border: '1px solid rgba(255,77,139,0.35)',
      borderRadius: 14, padding: '11px 18px', display: 'flex', alignItems: 'center', gap: 9,
      boxShadow: 'var(--elev-raise)', backdropFilter: 'blur(10px)',
      animation: 'feedInCenter 0.25s ease-out both', whiteSpace: 'nowrap',
    }}>
      <Heart size={14} style={{ color: '#ff4d8b', fill: '#ff4d8b', flexShrink: 0 }} />
      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)' }}>{message}</span>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   RARITY
══════════════════════════════════════════════════════ */
const RARITY_META: Record<MallRarity, { color: string; bg: string }> = {
  Common: { color: '#888899', bg: 'rgba(136,136,153,0.14)' },
  Rare:   { color: '#4f8ef7', bg: 'rgba(79,142,247,0.14)' },
  Epic:   { color: '#9b6dff', bg: 'rgba(155,109,255,0.14)' },
  Mythic: { color: 'var(--accent)', bg: 'linear-gradient(135deg,color-mix(in srgb, var(--accent) 18%, transparent),rgba(245,197,66,0.14))' },
}

function RarityBadge({ rarity }: { rarity: MallRarity }) {
  const meta = RARITY_META[rarity]
  return (
    <span style={{
      fontSize: 9.5, fontWeight: 700, padding: '2px 7px', borderRadius: 8,
      background: meta.bg, color: meta.color, whiteSpace: 'nowrap',
    }}>
      {rarity}
    </span>
  )
}

// Small inline SVG orb icon — same look as the one on the Wallet page's
// Orbs tab, kept as a local copy since that one isn't exported.
function OrbIcon({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="5" fill="#34d399" opacity="0.9" />
      <circle cx="12" cy="12" r="9" stroke="#34d399" strokeWidth="1.2" opacity="0.35" fill="none" />
      <circle cx="17.5" cy="12" r="2" fill="#34d399" opacity="0.7" />
    </svg>
  )
}

/* ══════════════════════════════════════════════════════
   UNLOCK / LOCK STATUS
   Pro-locked items unlock for any active Pro plan (Orbit or Void).
   Avatar/group-requirement items are still locked until real
   ownership-checking is wired up (needs user_inventory join).
══════════════════════════════════════════════════════ */
interface LockInfo {
  locked: boolean
  reason: string | null
  /** True only for the limited-time case. Cards use it to grey out harder
   *  than a normal Pro/XP lock (that item is coming back for you; this one
   *  isn't), and ItemModal uses it to swap in the "limited time item"
   *  panel instead of the generic lock strip. */
  expired?: boolean
}

/** Milliseconds left on an item's limited-time window. Null when the item
 *  has no timer at all; negative once the window has closed. */
export function timeLeftMs(item: MallItem): number | null {
  if (!item.available_until) return null
  return new Date(item.available_until).getTime() - Date.now()
}

/** True once an item's `available_until` window has closed, OR — for
 *  collab items that were locked manually instead of via a timer — once
 *  an admin has marked it as ended through the lock message (the "Ended
 *  collab item" convention used in the Mall editor). Used to split ended
 *  items out of their category's everyday listing and into a dedicated
 *  "Ended" tab, so expired stock never crowds active items out of the
 *  default view.
 *
 *  Deliberately does NOT treat every is_locked item as ended — a
 *  "Requires specific avatar(s)" or "Not available right now" lock means
 *  the item is still a live, ownable item that's just gated, not retired,
 *  and it needs to stay in its normal tab. Only a lock message that
 *  actually says "ended" counts. */
export function isItemEnded(item: MallItem): boolean {
  const left = timeLeftMs(item)
  if (left != null && left <= 0) return true
  if (item.is_locked && item.lock_message && /ended/i.test(item.lock_message)) return true
  return false
}

/** "2d 4h left" / "3h 12m left" / "8m left" — the countdown shown on cards
 *  and in the item sheet while a limited-time item is still buyable. */
function formatTimeLeft(ms: number): string {
  if (ms <= 0) return 'Ended'
  const minutes = Math.floor(ms / 60_000)
  const days = Math.floor(minutes / 1440)
  const hours = Math.floor((minutes % 1440) / 60)
  const mins = minutes % 60
  if (days > 0) return `${days}d ${hours}h left`
  if (hours > 0) return `${hours}h ${mins}m left`
  return `${Math.max(1, mins)}m left`
}

function getLockInfo(item: MallItem, hasOwnedRequirement: boolean, isPro: boolean, userXp: number): LockInfo {
  // Checked first and on its own: an expired window beats every other
  // gate. A Pro member with the XP for an item still can't buy it once
  // the timer runs out, so "Requires Pro" would be a misleading reason.
  const left = timeLeftMs(item)
  if (left != null && left <= 0) {
    return { locked: true, reason: 'Limited time — ended', expired: true }
  }
  // Manual admin lock — independent of the timer above. The admin's own
  // message (e.g. "Limited time item") is what shows on the card/sheet,
  // same disabled-purchase treatment as any other lock reason.
  if (item.is_locked) {
    return { locked: true, reason: item.lock_message || 'Not available right now' }
  }
  if (item.is_pro_locked) {
    return isPro ? { locked: false, reason: null } : { locked: true, reason: 'Requires Pro' }
  }
  if (item.unlock_xp != null) {
    // XP-gated item: locked until the user's XP meets the threshold.
    return userXp >= item.unlock_xp
      ? { locked: false, reason: null }
      : { locked: true, reason: `Requires ${item.unlock_xp.toLocaleString()} XP` }
  }
  if (item.category === 'profile_pic' && !item.price_gems && !hasOwnedRequirement) {
    // A profile_pic with no direct price/XP path and no confirmed
    // requirement ownership is gated behind an avatar/group link we
    // haven't verified yet.
    return { locked: true, reason: 'Requires specific avatar(s)' }
  }
  return { locked: false, reason: null }
}

/* ══════════════════════════════════════════════════════
   CARD COMPONENTS
══════════════════════════════════════════════════════ */
// Grid-card thumbnail: uses the static image_url when there is one. If an
// item has no poster but does have a video (animated_url), we render the
// video itself with no autoplay — the browser just displays frame 1, which
// looks identical to a static poster without needing a separate asset.
/** Corner ribbon on a card whose limited-time window is still open. Turns
 *  from accent to red inside the last 6 hours so a closing window reads as
 *  urgent at a glance, without needing the player to open the sheet. */
function LimitedRibbon({ msLeft, compact = false }: { msLeft: number; compact?: boolean }) {
  const urgent = msLeft <= 6 * 3_600_000
  return (
    <div style={{
      position: 'absolute', top: compact ? 5 : 7, left: compact ? 5 : 7, zIndex: 2,
      display: 'flex', alignItems: 'center', gap: 3,
      padding: compact ? '2.5px 5px' : '3px 7px', borderRadius: 20,
      background: urgent ? 'rgba(255,79,79,0.92)' : 'rgba(0,0,0,0.55)',
      backdropFilter: 'blur(4px)',
      border: urgent ? '1px solid rgba(255,255,255,0.25)' : '1px solid rgba(255,255,255,0.14)',
      color: '#fff', fontSize: compact ? 7.5 : 8.5, fontWeight: 800, letterSpacing: '0.02em',
      whiteSpace: 'nowrap', pointerEvents: 'none',
    }}>
      <Timer size={compact ? 8 : 9} />
      {formatTimeLeft(msLeft)}
    </div>
  )
}

/** Diagonal "ENDED" stamp across an expired card's artwork. The greyscale
 *  alone reads as "locked"; this says which kind of locked it is before
 *  the player even taps. */
function EndedStamp() {
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 2, display: 'flex',
      alignItems: 'center', justifyContent: 'center', pointerEvents: 'none',
    }}>
      <div style={{
        transform: 'rotate(-12deg)',
        padding: '3px 10px', borderRadius: 6,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(3px)',
        border: '1px solid rgba(255,255,255,0.25)',
        color: 'rgba(255,255,255,0.92)', fontSize: 8.5, fontWeight: 900,
        letterSpacing: '0.12em', textTransform: 'uppercase',
      }}>
        Ended
      </div>
    </div>
  )
}

function CardThumb({ item, style }: { item: MallItem; style: React.CSSProperties }) {
  if (item.image_url) {
    return <div style={{ ...style, background: `url(${item.image_url}) center/cover` }} />
  }
  if (item.animated_url && /\.(mp4|webm)$/i.test(item.animated_url)) {
    return (
      <div style={{ ...style, background: 'var(--surface2)' }}>
        <video src={item.animated_url} muted playsInline preload="metadata" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>
    )
  }
  return <div style={{ ...style, background: 'var(--surface2)' }} />
}

function SquareCard({ item, onSelect, onWishlist, wishlisted, likeCount = 0, compact = false, isNew = false }: { item: MallItem; onSelect: (item: MallItem) => void; onWishlist?: (item: MallItem) => void; wishlisted?: boolean; likeCount?: number; compact?: boolean; isNew?: boolean }) {
  const isPro = useContext(MallProContext)
  const userXp = useContext(MallXpContext)
  const lock = getLockInfo(item, false, isPro, userXp)
  const isMythic = item.rarity === 'Mythic'
  const msLeft = timeLeftMs(item)
  const counting = msLeft != null && msLeft > 0

  return (
    <div
      onClick={(e) => { ripple(e); onSelect(item) }}
      className="ripple-wrap"
      style={{
        background: 'var(--surface)', border: isMythic ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' : '1px solid rgba(255,255,255,0.05)',
        borderRadius: compact ? 13 : 16, padding: compact ? 7 : 10, cursor: 'pointer', position: 'relative',
        boxShadow: isMythic ? '0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent),4px 4px 10px var(--neu-dark)' : '4px 4px 10px var(--neu-dark),-2px -2px 8px var(--neu-light)',
        opacity: lock.expired ? 0.42 : lock.locked ? 0.55 : 1,
      }}
    >
      <div style={{ position: 'relative' }}>
        {counting && <LimitedRibbon msLeft={msLeft} compact={compact} />}
        {lock.expired && <EndedStamp />}
        {isNew && <NewDot />}
        <CardThumb item={item} style={{
          width: '100%', aspectRatio: '1 / 1', borderRadius: compact ? 10 : 12, marginBottom: compact ? 6 : 8, overflow: 'hidden',
          filter: lock.expired ? 'grayscale(1)' : lock.locked ? 'grayscale(0.6)' : 'none',
        }} />
      </div>
      <div style={{ fontSize: compact ? 10.5 : 12.5, fontWeight: 700, color: 'var(--text)', marginBottom: compact ? 3 : 4, lineHeight: 1.25, whiteSpace: compact ? 'nowrap' : 'normal', overflow: compact ? 'hidden' : 'visible', textOverflow: compact ? 'ellipsis' : 'clip' }}>{item.name}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {!compact && <RarityBadge rarity={item.rarity} />}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          {lock.locked ? (
            <Lock size={compact ? 11 : 13} color="var(--text-muted)" />
          ) : item.price_gems != null ? (
            <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: compact ? 10 : 11.5, fontWeight: 700, color: 'var(--text)' }}>
              💎 {item.price_gems.toLocaleString()}
            </span>
          ) : null}
          {!lock.locked && onWishlist && (
            <button type="button" onClick={e => { e.stopPropagation(); onWishlist(item) }}
              style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', padding: '2px 4px', color: wishlisted ? '#ff4d8b' : 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 3 }}>
              <Heart size={compact ? 11 : 13} style={{ fill: wishlisted ? '#ff4d8b' : 'none' }} />
              {!compact && <span style={{ fontSize: 9, fontWeight: 700, color: wishlisted ? '#ff4d8b' : 'var(--text-muted)', minWidth: 10 }}>{likeCount}</span>}
            </button>
          )}
        </div>
      </div>
      {lock.locked && lock.reason && (
        <div style={{ fontSize: compact ? 8.5 : 9.5, color: 'var(--text-muted)', marginTop: 4 }}>{lock.reason}</div>
      )}
    </div>
  )
}

function RectCard({ item, onSelect, onWishlist, wishlisted, likeCount = 0, isNew = false }: { item: MallItem; onSelect: (item: MallItem) => void; onWishlist?: (item: MallItem) => void; wishlisted?: boolean; likeCount?: number; isNew?: boolean }) {
  const isPro = useContext(MallProContext)
  const userXp = useContext(MallXpContext)
  const lock = getLockInfo(item, false, isPro, userXp)
  const isMythic = item.rarity === 'Mythic'
  const msLeft = timeLeftMs(item)

  return (
    <div
      onClick={(e) => { ripple(e); onSelect(item) }}
      className="ripple-wrap"
      style={{
        background: 'var(--surface)', border: isMythic ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' : '1px solid rgba(255,255,255,0.05)',
        borderRadius: 18, padding: 12, cursor: 'pointer', position: 'relative',
        boxShadow: isMythic ? '0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent),4px 4px 10px var(--neu-dark)' : '4px 4px 10px var(--neu-dark),-2px -2px 8px var(--neu-light)',
        opacity: lock.expired ? 0.42 : lock.locked ? 0.55 : 1,
      }}
    >
      <div style={{ position: 'relative' }}>
        {msLeft != null && msLeft > 0 && <LimitedRibbon msLeft={msLeft} />}
        {lock.expired && <EndedStamp />}
        {isNew && <NewDot />}
        <CardThumb item={item} style={{
          width: '100%', aspectRatio: '3 / 4', borderRadius: 14, marginBottom: 10, overflow: 'hidden',
          filter: lock.expired ? 'grayscale(1)' : lock.locked ? 'grayscale(0.6)' : 'none',
        }} />
      </div>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', marginBottom: 5, lineHeight: 1.3 }}>{item.name}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <RarityBadge rarity={item.rarity} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          {lock.locked ? (
            <Lock size={13} color="var(--text-muted)" />
          ) : item.price_gems != null ? (
            <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11.5, fontWeight: 700, color: 'var(--text)' }}>
              💎 {item.price_gems.toLocaleString()}
            </span>
          ) : item.price_orbs != null ? (
            <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11.5, fontWeight: 700, color: 'var(--text)' }}>
              <OrbIcon size={12} /> {item.price_orbs.toLocaleString()}
            </span>
          ) : item.unlock_xp != null ? (
            <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11.5, fontWeight: 700, color: 'var(--text)' }}>
              <Zap size={11} color="#f5c542" /> {item.unlock_xp.toLocaleString()} XP
            </span>
          ) : null}
          {!lock.locked && onWishlist && (
            <button type="button" onClick={e => { e.stopPropagation(); onWishlist(item) }}
              style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', padding: '2px 4px', color: wishlisted ? '#ff4d8b' : 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 3 }}>
              <Heart size={13} style={{ fill: wishlisted ? '#ff4d8b' : 'none' }} />
              <span style={{ fontSize: 9, fontWeight: 700, color: wishlisted ? '#ff4d8b' : 'var(--text-muted)', minWidth: 10 }}>{likeCount}</span>
            </button>
          )}
        </div>
      </div>
      {lock.locked && lock.reason && (
        <div style={{ fontSize: 9.5, color: 'var(--text-muted)', marginTop: 4 }}>{lock.reason}</div>
      )}
    </div>
  )
}

function BannerCard({ item, onSelect, onWishlist, wishlisted, likeCount = 0, isNew = false }: { item: MallItem; onSelect: (item: MallItem) => void; onWishlist?: (item: MallItem) => void; wishlisted?: boolean; likeCount?: number; isNew?: boolean }) {
  const isPro = useContext(MallProContext)
  const userXp = useContext(MallXpContext)
  const lock = getLockInfo(item, false, isPro, userXp)
  const isMythic = item.rarity === 'Mythic'
  const msLeft = timeLeftMs(item)

  return (
    <div
      onClick={(e) => { ripple(e); onSelect(item) }}
      className="ripple-wrap"
      style={{
        background: 'var(--surface)', border: isMythic ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' : '1px solid rgba(255,255,255,0.05)',
        borderRadius: 14, padding: 9, cursor: 'pointer', position: 'relative',
        boxShadow: isMythic ? '0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent),4px 4px 10px var(--neu-dark)' : '4px 4px 10px var(--neu-dark),-2px -2px 8px var(--neu-light)',
        opacity: lock.expired ? 0.42 : lock.locked ? 0.55 : 1,
      }}
    >
      {/* Wide/landscape image slot — the shape itself is the cue that this
          is a banner, even at small card size. */}
      <div style={{
        width: '100%', aspectRatio: '2.2 / 1', borderRadius: 10, marginBottom: 7, overflow: 'hidden', position: 'relative',
        background: item.image_url ? `url(${item.image_url}) center/cover` : 'var(--surface2)',
        filter: lock.expired ? 'grayscale(1)' : lock.locked ? 'grayscale(0.6)' : 'none',
      }}>
        {msLeft != null && msLeft > 0 && <LimitedRibbon msLeft={msLeft} compact />}
        {lock.expired && <EndedStamp />}
        {/* Bottom-left, not the default top-right — the wishlist heart and
            LimitedRibbon already claim the top corners on this card shape. */}
        {isNew && <NewDot style={{ top: 'auto', right: 'auto', bottom: 4, left: 4 }} />}
        {!lock.locked && onWishlist && (
          <button type="button" onClick={e => { e.stopPropagation(); onWishlist(item) }}
            style={{ position: 'absolute', top: 5, right: 5, background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(4px)', border: 'none', borderRadius: 20, cursor: 'pointer', padding: '3px 6px', color: wishlisted ? '#ff4d8b' : '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
            <Heart size={10.5} style={{ fill: wishlisted ? '#ff4d8b' : 'none' }} />
            <span style={{ fontSize: 8.5, fontWeight: 700 }}>{likeCount}</span>
          </button>
        )}
      </div>
      <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text)', marginBottom: 3, lineHeight: 1.25, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <RarityBadge rarity={item.rarity} />
        {lock.locked ? (
          <Lock size={11} color="var(--text-muted)" style={{ flexShrink: 0 }} />
        ) : item.price_gems != null ? (
          <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 10.5, fontWeight: 700, color: 'var(--text)', flexShrink: 0 }}>
            💎 {item.price_gems.toLocaleString()}
          </span>
        ) : null}
      </div>
      {lock.locked && lock.reason && (
        <div style={{ fontSize: 8.5, color: 'var(--text-muted)', marginTop: 4 }}>{lock.reason}</div>
      )}
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   PURCHASE TOAST
══════════════════════════════════════════════════════ */
function PurchaseToast({ message, onDone }: { message: string; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 2800); return () => clearTimeout(t) }, [])
  return (
    <div style={{
      position: 'fixed', bottom: 90, left: '50%',
      zIndex: 9999, background: 'color-mix(in srgb, var(--nav) 94%, transparent)',
      border: '1px solid color-mix(in srgb, var(--accent) 40%, transparent)',
      borderRadius: 14, padding: '11px 18px',
      display: 'flex', alignItems: 'center', gap: 9,
      boxShadow: 'var(--elev-raise)', backdropFilter: 'blur(12px)',
      animation: 'feedInCenter 0.25s ease-out both', whiteSpace: 'nowrap',
    }}>
      <ShoppingBag size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />
      <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)' }}>{message}</span>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   DETAIL / CONFIRM MODAL
══════════════════════════════════════════════════════ */
const BUY_LABEL: Partial<Record<MallItem['category'], string>> = {
  profile_pic: 'Buy Profile Pic',
  banner: 'Buy Banner',
  avatar_skin: 'Buy Avatar',
}

// Shared sizing for the "profile header mockup" preview (banner + the
// overlapping avatar + name/username), used automatically for banners and
// on-demand (behind the eye-toggle) for profile pics.
const MOCK_BANNER_H = 110
const MOCK_AVATAR_SIZE = 56
const MOCK_TOTAL_H = 194 // banner (110) + overlapping avatar's visible half (28) + name/username block + padding

// The buy sheet is always exactly this tall — same fixed height as the
// profile preview sheet (see SHEET_HEIGHT_VH in ProfilePreviewModal.tsx) —
// regardless of how much or how little info a given item has. Short
// content just leaves breathing room at the bottom; long content scrolls
// inside the sheet. No more "sheet height depends on content" behavior.
//
// This is measured against the REAL visible viewport (useRealViewportHeight),
// not a raw CSS vh unit, which is always a bit shorter than the layout
// viewport because it excludes the browser's address bar/toolbar. 92 (not
// 85) compensates for that gap so the sheet reads the same height it did
// back when it was sized off raw vh, without reintroducing the old bug
// where the top of the sheet could render above the real top edge of the
// screen.
const BUY_SHEET_HEIGHT_VH = 92

// Small square thumbnail size for the profile-pic item view (the "just the
// small pic" per-item image, distinct from the full profile-header mockup
// which now only appears on demand for profile pics).
const PIC_THUMB_SIZE = 108

function ItemModal({
  item, walletBalance, orbBalance, userId, onClose, onPurchased, onWishlist, wishlisted, previewProfile, onGift, onVariantResult, onPurchaseFailed,
}: {
  item: MallItem
  walletBalance: number
  orbBalance: number
  userId: string | null
  onClose: () => void
  onPurchased: (item: MallItem) => void
  onWishlist?: (item: MallItem) => void
  wishlisted?: boolean
  previewProfile?: { avatar: string; displayName: string; username: string; banner?: string | null } | null
  onGift?: (item: MallItem) => void
  /** Result copy from a colour purchase attempt, for the page-level toast. */
  onVariantResult?: (message: string) => void
  /** Failure copy from a regular (gem/orb) purchase attempt, for the same page-level toast. */
  onPurchaseFailed?: (message: string) => void
}) {
  const isPro = useContext(MallProContext)
  const userXp = useContext(MallXpContext)
  // Called unconditionally (hook rules) and then indexed: null unless the
  // item is tagged to a collab that's CURRENTLY published, since only
  // published collabs are in the map. An unpublished or deleted one leaves
  // the line unrendered rather than showing a dangling name.
  const collabMap = useContext(MallCollabContext)
  const collabName = item.collab_id ? (collabMap[item.collab_id] ?? null) : null
  const navigate = useNavigate()

  // Real visible height (accounts for mobile browser chrome — see
  // useBottomSheet.ts) instead of a raw `vh` figure, which on phones can
  // be taller than what's actually on screen and pushes the top of the
  // sheet (drag handle, Preview/wishlist/close row) off the top edge
  // where no amount of scrolling can reach it.
  const realVh = useRealViewportHeight()
  const sheetHeightPx = Math.round(realVh * (BUY_SHEET_HEIGHT_VH / 100))
  const { dragY, dragging, dragHandleProps, sheetProps } = useSheetDrag(onClose)

  // Lock the page behind the sheet while it's open, and hide the portaled
  // dock (see body.cv-sheet-open in index.css — same mechanism RegionMap's
  // sheet already uses). Without the class the dock stays visible and this
  // sheet stops short to avoid overlapping it, reading as "cut off" above
  // the nav; with it, the dock disappears and the sheet is free to sit
  // flush against the true bottom edge instead of reserving space for a
  // nav that's no longer there.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  // Re-tick once a minute so an open sheet counts down live and flips to
  // the "limited time item" panel the moment the window closes, instead of
  // leaving a stale Buy button that would only fail server-side.
  const [, setClock] = useState(0)
  useEffect(() => {
    if (!item.available_until) return
    const t = setInterval(() => setClock(c => c + 1), 30_000)
    return () => clearInterval(t)
  }, [item.available_until])
  const sheetMsLeft = timeLeftMs(item)
  const lock = getLockInfo(item, false, isPro, userXp)
  // Single status pill for the header row: a live countdown while the
  // item's still buyable, or the lock reason once it isn't (which already
  // covers "ended" — getLockInfo returns locked:true with that reason the
  // moment the window closes, so this never needs to branch on expired
  // separately). At most one of the two ever applies.
  const statusPill = sheetMsLeft != null && sheetMsLeft > 0 && !lock.locked
    ? { label: formatTimeLeft(sheetMsLeft), icon: <Timer size={12} />, tone: sheetMsLeft <= 6 * 3_600_000 ? 'urgent' as const : 'active' as const }
    : lock.locked
      ? { label: lock.reason ?? 'Locked', icon: <Lock size={12} />, tone: 'muted' as const }
      : null
  const canAffordGems = item.price_gems != null && walletBalance >= item.price_gems
  const canAffordOrbs = item.price_orbs != null && orbBalance >= item.price_orbs
  const [buying, setBuying] = useState(false)
  const [alreadyOwned, setAlreadyOwned] = useState(false)
  const [checkingOwn, setCheckingOwn] = useState(true)
  // Only banners show the full profile-header mockup automatically — it's
  // the one thing that fills the whole header, so it's worth previewing up
  // front. Profile pics show just their own small thumbnail by default;
  // the full "how it'll look on your profile" mockup is revealed on demand
  // via the eye-toggle below (see showPicPreview). Avatars get their own
  // full-but-shrunk image treatment further down.
  const isBanner = item.category === 'banner'
  const isProfilePic = item.category === 'profile_pic'
  // Profile card effects share the profile_pic category (they live in the
  // "Profile card effect" sub-tab under Profile Pics) but behave nothing
  // like a normal profile pic: the sheet shows only the static poster
  // (image_url), never an inline mockup, and "Preview" opens a full-screen
  // look at the real profile with the effect playing over it instead of
  // toggling a small mockup in place.
  const isCardEffect = item.sub_category === 'Profile card effect'
  const mockBannerSrc = isBanner ? (item.animated_url || item.image_url) : previewProfile?.banner
  // 'rocket' is the DB default for profiles.avatar (no avatar equipped) —
  // same sentinel the shared Avatar component treats as "no src". Must be
  // normalized here too, or it gets passed straight into an <img src="rocket">
  // and renders the browser's broken-image icon instead of the letter fallback.
  const rawPreviewAvatar = previewProfile?.avatar && previewProfile.avatar !== 'rocket' ? previewProfile.avatar : undefined
  const mockAvatarSrc = isProfilePic && !isCardEffect ? (item.animated_url || item.image_url) : rawPreviewAvatar
  // Card-effect thumb: static poster only. If an item has no poster (no
  // image_url), fall back to the video itself with no autoplay so the
  // browser just shows frame 1 — never the animated version here.
  const cardEffectPosterSrc = item.image_url || null
  const cardEffectPosterIsVideo = !item.image_url && !!item.animated_url && /\.(mp4|webm)$/i.test(item.animated_url)

  // ── Profile-pic-only: on-demand "preview on profile" toggle ──────────
  const [showPicPreview, setShowPicPreview] = useState(false)
  // ── Card-effect-only: full-screen "how it'll actually look" preview,
  // which draws up the real profile (via ProfileEffectPreview) instead of
  // the small in-sheet mockup other categories use. ──
  const [showEffectPreview, setShowEffectPreview] = useState(false)

  // ── Colour variants ("Customise this item") ──
  // Only banners and plain profile pics can carry colours, so the lookup
  // is skipped entirely for every other category rather than firing a
  // query per item sheet that could never return anything.
  const [hasVariants, setHasVariants] = useState(false)
  const [showCustomize, setShowCustomize] = useState(false)
  useEffect(() => {
    if (!canHaveVariants(item.category, item.sub_category)) { setHasVariants(false); return }
    let active = true
    fetchItemVariants(item.id).then(list => { if (active) setHasVariants(list.length > 0) })
    return () => { active = false }
  }, [item.id, item.category, item.sub_category])
  // ── Profile-pic-only: occasional nudge bubble pointing at the eye
  // toggle, reminding people it's there. Only fires some of the time (not
  // on every single view of a profile pic) and only until the person
  // actually taps preview or dismisses it. ──
  const [showPreviewNudge, setShowPreviewNudge] = useState(false)
  useEffect(() => {
    if (!isProfilePic || isCardEffect) return
    if (Math.random() > 0.35) return // fires roughly 1 in ~3 opens, not every time
    const showT = setTimeout(() => setShowPreviewNudge(true), 1100)
    const hideT = setTimeout(() => setShowPreviewNudge(false), 6500)
    return () => { clearTimeout(showT); clearTimeout(hideT) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item.id, isProfilePic])

  // Check if user already owns this item.
  //
  // Owning means HOLDING A COPY, not having a row. An inventory row
  // survives at quantity 0 once the last copy is spent — that's true of
  // every consumable, and also of Necromancy, which is a permanent card
  // that pvp_attack spends on revive. Testing the row alone made this
  // sheet say "Owned" and refuse the buy for an item the player no
  // longer had. send_gift() was corrected the same way (0174a).
  useEffect(() => {
    if (!userId || !item.id) { setCheckingOwn(false); return }
    supabase.from('user_inventory').select('quantity').eq('user_id', userId).eq('item_id', item.id).maybeSingle()
      .then(({ data }) => { setAlreadyOwned((data?.quantity ?? 0) > 0); setCheckingOwn(false) })
  }, [userId, item.id])

  const isXpUnlock = item.price_gems == null && item.price_orbs == null && item.unlock_xp != null
  // Whether the buy button should be enabled: a free XP unlock, an
  // affordable Diamond purchase, or an affordable Orb purchase.
  const affordable = isXpUnlock || canAffordGems || canAffordOrbs

  async function handleBuy() {
    if (!userId || buying || (alreadyOwned && !item.is_consumable)) return
    if (!isXpUnlock && !affordable) return
    setBuying(true)
    try {
      if (!isXpUnlock) {
        // Atomic, server-priced purchase: balance check, deduction, inventory
        // insert, and transaction log all happen in one DB transaction.
        const { error } = await supabase.rpc('purchase_mall_item', {
          p_user_id: userId,
          p_item_id: item.id,
        })
        if (error) {
          if (error.message === 'insufficient_funds') {
            onPurchaseFailed?.('Purchase failed — not enough diamonds.')
          } else if (error.message.includes('item_expired')) {
            // Race: the window closed between the sheet rendering and the
            // tap landing. The server is the authority, so surface its
            // answer rather than letting the stale button look broken.
            onPurchaseFailed?.('This was a limited time item and it just ended — it can no longer be bought.')
            onClose()
          } else if (error.message.includes('item_locked')) {
            // Race: an admin locked it between the sheet rendering and the
            // tap landing.
            onPurchaseFailed?.(item.lock_message || 'This item is not available right now.')
            onClose()
          } else if (error.message.includes('dead')) {
            // PvP gate: Battle Cards can't be bought while dead.
            onPurchaseFailed?.('Sorry, you died recently — regenerate first.')
          } else if (error.message.includes('jailed')) {
            onPurchaseFailed?.("You're in jail — Battle Cards are unavailable until you're out.")
          } else {
            console.error('purchase error:', error)
            onPurchaseFailed?.('Purchase failed. Please try again.')
          }
          return
        }
      } else {
        // XP-unlock items are free, but "free" and "you have the XP" are
        // both decisions the server has to make — this used to insert
        // straight into user_inventory from the browser, which meant the
        // only thing standing between a player and any item in the Mall
        // was the client agreeing not to ask. claim_xp_unlock_item
        // re-checks price, unlock_xp, the timer, and the real profile XP.
        const { error } = await supabase.rpc('claim_xp_unlock_item', {
          p_item_id: item.id,
        })
        if (error) {
          if (error.message.includes('xp_too_low')) {
            onPurchaseFailed?.("You don't have enough XP to unlock this yet.")
          } else if (error.message.includes('item_expired')) {
            onPurchaseFailed?.('This was a limited time item and it just ended — it can no longer be unlocked.')
            onClose()
          } else if (error.message.includes('item_locked')) {
            onPurchaseFailed?.(item.lock_message || 'This item is not available right now.')
            onClose()
          } else {
            console.error('xp unlock error:', error)
            onPurchaseFailed?.('Unlock failed. Please try again.')
          }
          return
        }
      }

      // Weekly missions: generic purchase counter + per-category tiers
      updateMissionProgress(userId, 'items_purchased', 1).catch(console.error)
      const categoryMetric: Partial<Record<MallItem['category'], string>> = {
        avatar_skin: 'avatar_skins_bought',
        chat_theme: 'chat_themes_bought',
        profile_pic: 'profile_pics_bought',
        xp_booster: 'xp_boosters_bought',
      }
      const catMetric = categoryMetric[item.category]
      if (catMetric) updateMissionProgress(userId, catMetric, 1).catch(console.error)

      onPurchased(item)
      onClose()
    } catch (err) {
      console.error('purchase error:', err)
      onPurchaseFailed?.('Purchase failed. Please try again.')
    } finally {
      setBuying(false)
    }
  }

  const buyLabelBase = BUY_LABEL[item.category] ?? 'Buy'

  return (
    <>
    {/* Backdrop + sheet. When the effect preview opens, this whole thing
        slides down out of the way and stops accepting input — rather than
        staying mounted underneath the preview and fighting it for stacking
        order, it's just gone. It swings back up once the preview closes,
        since it was never unmounted, just parked below the viewport. */}
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{
        // Not portaled — lives inside <main className="z-10">, capped below
        // the dock's z-index regardless of the 800 set here. Previously
        // padded by --dock-space to stop short of the (still-visible) dock;
        // now that this sheet adds cv-sheet-open (see the effect above) the
        // dock hides itself while open, so the sheet sits flush at the true
        // bottom edge instead of leaving a gap for a nav that's not there.
        position: 'fixed', inset: 0, zIndex: 800, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        transform: showEffectPreview ? 'translateY(100%)' : 'translateY(0)',
        opacity: showEffectPreview ? 0 : 1,
        pointerEvents: showEffectPreview ? 'none' : 'auto',
        transition: 'transform 0.32s cubic-bezier(0.32,0.72,0,1), opacity 0.28s ease',
      }}
    >
      {/* sheetProps: drag-to-dismiss from anywhere inside the sheet, not just
          the handle — engages only when the content under the finger is
          already scrolled to the top. See useBottomSheet.ts. */}
      <div {...sheetProps} style={{
        background: 'var(--surface)', borderRadius: '20px 20px 0 0', padding: '0 20px 24px', width: '100%', maxWidth: 460,
        border: '1px solid var(--border)', borderBottom: 'none', boxShadow: '0 -12px 40px -12px var(--sh)',
        position: 'relative', height: sheetHeightPx, maxHeight: sheetHeightPx, overflowY: 'auto', overscrollBehavior: 'contain',
        display: 'flex', flexDirection: 'column',
        transform: `translateY(${dragY}px)`,
        transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.16,1,0.3,1)',
        animation: dragging ? undefined : 'slideUp 0.28s cubic-bezier(0.16,1,0.3,1) both',
      }}>
        {/* Drag handle — real swipe-down-to-dismiss, tracked via pointer
            events (see useSheetDrag). Give it generous hit-area padding
            since the visible bar is only 4px tall. */}
        <div
          {...dragHandleProps}
          style={{ ...dragHandleProps.style, padding: '10px 0 8px', margin: '0 auto', flexShrink: 0, display: 'flex', justifyContent: 'center' }}
        >
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        {/* Header: preview eye (profile pics only) + status pill (timer /
            locked / expired — whichever applies, never more than one at
            once) + customize + wishlist heart + close. Keeping the status
            here instead of as a full-width strip lower in the sheet is
            what stops the sheet from turning into a stack of bordered
            boxes; it's still exactly as visible, just compact. */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 8, margin: '14px 0', flexShrink: 0, position: 'relative' }}>
          {isProfilePic && !lock.locked && (
            <div style={{ position: 'relative', marginRight: 'auto' }}>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  if (isCardEffect) { setShowEffectPreview(true) } else { setShowPicPreview(v => !v) }
                  setShowPreviewNudge(false)
                }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', borderRadius: 20,
                  background: (showPicPreview || showEffectPreview) ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'rgba(255,255,255,0.06)',
                  border: (showPicPreview || showEffectPreview) ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid transparent',
                  cursor: 'pointer', color: (showPicPreview || showEffectPreview) ? 'var(--accent)' : 'var(--text-dim)',
                  fontSize: 11.5, fontWeight: 700,
                }}
              >
                <Eye size={14} /> {isCardEffect ? 'Preview' : (showPicPreview ? 'Hide preview' : 'Preview')}
              </button>
              {/* Occasional nudge bubble — points at the preview button,
                  only shows some of the time, and disappears on its own or
                  the moment the person taps preview. */}
              {showPreviewNudge && (
                <div
                  onClick={(e) => { e.stopPropagation(); setShowPicPreview(true); setShowPreviewNudge(false) }}
                  style={{
                    position: 'absolute', top: '100%', left: 0, marginTop: 8, zIndex: 5,
                    display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', borderRadius: 12,
                    background: 'rgba(20,20,24,0.97)', border: '1px solid color-mix(in srgb, var(--accent) 30%, transparent)',
                    boxShadow: 'var(--elev-raise)', cursor: 'pointer', whiteSpace: 'nowrap',
                    animation: 'feedIn 0.25s ease-out both',
                  }}
                >
                  <div style={{ position: 'absolute', top: -5, left: 16, width: 9, height: 9, background: 'rgba(20,20,24,0.97)', borderLeft: '1px solid color-mix(in srgb, var(--accent) 30%, transparent)', borderTop: '1px solid color-mix(in srgb, var(--accent) 30%, transparent)', transform: 'rotate(45deg)' }} />
                  <Sparkles size={12} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                  <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--text)' }}>Tap preview to see how it'll look</span>
                </div>
              )}
            </div>
          )}
          {/* Status pill — one slot, three possible states. A live
              countdown while the window's open; the lock reason (Pro,
              XP, avatar-gated, admin-locked, or "ended") once it isn't.
              lock.locked already covers the expired case, so only one of
              these two conditions is ever true at a time. */}
          {statusPill && (
            <div
              style={{
                display: 'flex', alignItems: 'center', gap: 5, padding: '6px 10px', borderRadius: 20,
                fontSize: 10.5, fontWeight: 800, whiteSpace: 'nowrap', maxWidth: 128,
                background: statusPill.tone === 'urgent' ? 'rgba(255,79,79,0.12)' : statusPill.tone === 'active' ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'rgba(255,255,255,0.06)',
                border: statusPill.tone === 'urgent' ? '1px solid rgba(255,79,79,0.28)' : statusPill.tone === 'active' ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' : '1px solid var(--border)',
                color: statusPill.tone === 'urgent' ? 'var(--red)' : statusPill.tone === 'active' ? 'var(--accent)' : 'var(--text-dim)',
              }}
            >
              {statusPill.icon}
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{statusPill.label}</span>
            </div>
          )}
          {/* Customize — icon button, same treatment as the wishlist
              heart next to it, rather than a full-width box lower down.
              Same gating as before: only for items with colour variants,
              and only while the item is actually buyable. */}
          {hasVariants && !lock.locked && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); ripple(e); setShowCustomize(true) }}
              aria-label="Customize this item"
              className="ripple-wrap"
              style={{ width: 30, height: 30, borderRadius: 9, background: 'color-mix(in srgb, var(--accent) 12%, transparent)', border: '1px solid color-mix(in srgb, var(--accent) 28%, transparent)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}
            >
              <Palette size={14} />
            </button>
          )}
          {onWishlist && !lock.locked && !item.is_consumable && item.category !== 'xp_booster' && item.category !== 'pvp_card' && (
            <button type="button" onClick={(e) => { e.stopPropagation(); onWishlist(item) }}
              style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: wishlisted ? '#ff4d8b' : 'var(--text-dim)' }}>
              <Heart size={14} style={{ fill: wishlisted ? '#ff4d8b' : 'none' }} />
            </button>
          )}
          <button onClick={onClose} style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)' }}>
            <X size={14} />
          </button>
        </div>

        {isProfilePic ? (
          /* ── Profile pic: small standalone thumbnail by default. The
             full "how it'll look on your profile" mockup only appears
             once the person taps the eye/Preview toggle above — banners
             are the only category that auto-shows the full mockup. ── */
          <div style={{ flexShrink: 0 }}>
            <div style={{
              width: PIC_THUMB_SIZE, height: PIC_THUMB_SIZE, margin: '0 auto 14px', borderRadius: 22,
              overflow: 'hidden', background: 'var(--surface2)', border: '1px solid var(--border)',
              boxShadow: 'var(--elev-raise)',
            }}>
              {isCardEffect ? (
                cardEffectPosterSrc ? (
                  <img src={cardEffectPosterSrc} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : cardEffectPosterIsVideo ? (
                  <video src={item.animated_url!} muted playsInline preload="metadata" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : null
              ) : mockAvatarSrc ? (
                /\.(mp4|webm)$/i.test(mockAvatarSrc) ? (
                  <video src={mockAvatarSrc} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <img src={mockAvatarSrc} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                )
              ) : null}
            </div>

            {showPicPreview && !isCardEffect && (
              <div style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', marginBottom: 16, border: '1px solid var(--border)', minHeight: MOCK_TOTAL_H, animation: 'feedIn 0.25s ease-out both' }}>
                <div style={{ position: 'relative', width: '100%', height: MOCK_BANNER_H, background: 'var(--surface2)' }}>
                  {previewProfile?.banner ? (
                    /\.(mp4|webm)$/i.test(previewProfile.banner) ? (
                      <video src={previewProfile.banner} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <img src={previewProfile.banner} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    )
                  ) : (
                    <div style={{ width: '100%', height: '100%', background: 'linear-gradient(135deg,rgba(79,142,247,0.18),rgba(155,109,255,0.14))' }} />
                  )}
                </div>
                <div style={{ background: 'var(--surface)', padding: `${MOCK_AVATAR_SIZE / 2 + 8}px 14px 14px` }}>
                  <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{previewProfile?.displayName || 'You'}</div>
                  {previewProfile?.username && (
                    <div style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 2 }}>@{previewProfile.username}</div>
                  )}
                </div>
                <div style={{
                  position: 'absolute', left: 14, top: MOCK_BANNER_H - MOCK_AVATAR_SIZE / 2,
                  width: MOCK_AVATAR_SIZE, height: MOCK_AVATAR_SIZE, borderRadius: 16, padding: 2,
                  background: 'linear-gradient(135deg,var(--accent),#4f8ef7)', border: '3px solid var(--surface)',
                }}>
                  {mockAvatarSrc ? (
                    /\.(mp4|webm)$/i.test(mockAvatarSrc) ? (
                      <video src={mockAvatarSrc} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', borderRadius: 12, objectFit: 'cover', display: 'block' }} />
                    ) : (
                      <img src={mockAvatarSrc} alt="" style={{ width: '100%', height: '100%', borderRadius: 12, objectFit: 'cover', display: 'block' }} />
                    )
                  ) : (
                    <Avatar
                      src={null}
                      name={previewProfile?.displayName || previewProfile?.username || 'You'}
                      size={MOCK_AVATAR_SIZE - 4}
                      radius={12}
                      disabled
                    />
                  )}
                </div>
              </div>
            )}
          </div>
        ) : isBanner ? (
          /* ── Banner: previews automatically inside the profile-header
             mockup (this is the only category that does, since a banner
             IS the whole header). The avatar chip is positioned with
             `position: absolute`, not a negative margin — a negative
             margin on a child with no padding/border above it collapses
             with the parent's own margin and escapes upward, which is
             what was clipping the avatar against the banner before.
             Absolute positioning can't collapse, so it can't get clipped. ── */
          <div style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', marginBottom: 16, border: '1px solid var(--border)', minHeight: MOCK_TOTAL_H }}>
            <div style={{ position: 'relative', width: '100%', height: MOCK_BANNER_H, background: 'var(--surface2)' }}>
              {mockBannerSrc ? (
                /\.(mp4|webm)$/i.test(mockBannerSrc) ? (
                  <video src={mockBannerSrc} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <img src={mockBannerSrc} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                )
              ) : (
                <div style={{ width: '100%', height: '100%', background: 'linear-gradient(135deg,rgba(79,142,247,0.18),rgba(155,109,255,0.14))' }} />
              )}
            </div>
            <div style={{ background: 'var(--surface)', padding: `${MOCK_AVATAR_SIZE / 2 + 8}px 14px 14px` }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{previewProfile?.displayName || 'You'}</div>
              {previewProfile?.username && (
                <div style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 2 }}>@{previewProfile.username}</div>
              )}
            </div>
            {/* Avatar overlapping the banner by half its own height —
                absolutely positioned relative to the mockup container so it
                always renders on top and can never be clipped by a
                collapsed margin. */}
            <div style={{
              position: 'absolute', left: 14, top: MOCK_BANNER_H - MOCK_AVATAR_SIZE / 2,
              width: MOCK_AVATAR_SIZE, height: MOCK_AVATAR_SIZE, borderRadius: 16, padding: 2,
              background: 'linear-gradient(135deg,var(--accent),#4f8ef7)', border: '3px solid var(--surface)',
            }}>
              {mockAvatarSrc ? (
                /\.(mp4|webm)$/i.test(mockAvatarSrc) ? (
                  <video src={mockAvatarSrc} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', borderRadius: 12, objectFit: 'cover', display: 'block' }} />
                ) : (
                  <img src={mockAvatarSrc} alt="" style={{ width: '100%', height: '100%', borderRadius: 12, objectFit: 'cover', display: 'block' }} />
                )
              ) : (
                <Avatar
                  src={null}
                  name={previewProfile?.displayName || previewProfile?.username || 'You'}
                  size={MOCK_AVATAR_SIZE - 4}
                  radius={12}
                  disabled
                />
              )}
            </div>
          </div>
        ) : (
          /* ── Avatar (and any other) items: no profile-header mockup —
             instead the WHOLE image is shown, shrunk down to fit inside
             the frame (objectFit: contain, not cover), so nothing gets
             cropped off the top/bottom/sides. Framed at MOCK_TOTAL_H so
             the sheet still lines up with the banner/profile-pic sheets. ── */
          <div style={{
            width: '100%', height: MOCK_TOTAL_H,
            borderRadius: 16, marginBottom: 16, overflow: 'hidden', background: 'var(--surface2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 14,
          }}>
            {item.animated_url ? (
              /\.(mp4|webm)$/i.test(item.animated_url) ? (
                <video
                  src={item.animated_url}
                  autoPlay loop muted playsInline
                  style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                />
              ) : (
                // gif (or any still-image fallback) — browsers animate gifs natively
                <img src={item.animated_url} alt={item.name} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
              )
            ) : item.image_url ? (
              <img src={item.image_url} alt={item.name} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
            ) : null}
          </div>
        )}

        {item.sub_category && (
          <div style={{ fontSize: 10.5, color: 'var(--text-muted)', textAlign: 'center', textTransform: 'uppercase', letterSpacing: 0.6, fontWeight: 700, marginBottom: 6 }}>
            {item.sub_category}
          </div>
        )}
        <div style={{ fontSize: 18, fontWeight: 800, textAlign: 'center', marginBottom: 6, color: 'var(--text)' }}>{item.name}</div>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 14 }}>
          <RarityBadge rarity={item.rarity} />
        </div>
        {item.description && (
          <div style={{ fontSize: 12.5, color: 'var(--text-dim)', textAlign: 'center', lineHeight: 1.6, marginBottom: 18 }}>
            {item.description}
          </div>
        )}

        {/* Collab provenance — sits immediately after the description, and
            glows, because it's the one line here that says this item came
            from somewhere rather than describing what it does. Tapping it
            goes to that collab's wing. Only renders when the collab is
            still published (see collabName above). */}
        {collabName && (
          <button
            type="button"
            onClick={(e) => { ripple(e); navigate('/lab/collab') }}
            className="mall-collab-line"
            aria-label={`From the ${collabTitle(collabName)} collab — open the Collab wing`}
          >
            <Sparkles size={13} aria-hidden="true" />
            <span>From <strong>{collabTitle(collabName)}</strong></span>
          </button>
        )}

        {item.category !== 'pvp_card' && (
          <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-dim)', textAlign: 'center', marginBottom: 18 }}>
            Give your profile a distinct look
          </div>
        )}

        {lock.expired ? (
          /* Limited-time item whose window has closed. Deliberately its own
             panel rather than the generic grey lock strip: the player isn't
             missing a requirement they can go and meet, the item is simply
             gone, and the copy has to say that plainly so nobody grinds XP
             or buys Pro expecting it to unlock. */
          <div style={{
            textAlign: 'center', padding: '20px 16px', borderRadius: 16,
            background: 'var(--surface2)', border: '1px solid var(--border)',
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 14, margin: '0 auto 12px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'color-mix(in srgb, var(--accent) 12%, transparent)',
              color: 'var(--accent)',
            }}>
              <Hourglass size={20} />
            </div>
            <div style={{ fontSize: 14.5, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>
              Limited time item
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.6, marginBottom: 10 }}>
              This one was only in the Mall for a limited time, and that window has closed. It can't be bought or gifted any more.
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600 }}>
              Ended {new Date(item.available_until!).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}
            </div>
            {alreadyOwned && (
              <div style={{ fontSize: 11.5, color: '#3ecf8e', fontWeight: 700, marginTop: 12 }}>
                ✓ You got this one in time — it's in your inventory
              </div>
            )}
          </div>
        ) : lock.locked ? (
          <div style={{ textAlign: 'center', padding: 12, background: 'var(--surface2)', borderRadius: 12, fontSize: 12, color: 'var(--text-muted)' }}>
            <Lock size={14} style={{ marginBottom: 4 }} /> {lock.reason}
          </div>
        ) : (
          <>
            {alreadyOwned && !item.is_consumable ? (
              <div style={{ textAlign: 'center', padding: 12, background: 'rgba(62,207,142,0.08)', borderRadius: 12, fontSize: 12, color: '#3ecf8e', fontWeight: 700, border: '1px solid rgba(62,207,142,0.2)', marginBottom: 14 }}>
                ✓ Already in your inventory
              </div>
            ) : (
              <>
                {item.price_gems != null && (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'var(--surface2)', borderRadius: 12, padding: 12, marginBottom: 14, fontSize: 18, fontWeight: 800, color: 'var(--text)' }}>
                    💎 {item.price_gems.toLocaleString()} Diamonds
                  </div>
                )}
                {item.price_orbs != null && (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'var(--surface2)', borderRadius: 12, padding: 12, marginBottom: 14, fontSize: 18, fontWeight: 800, color: 'var(--text)' }}>
                    <OrbIcon size={18} /> {item.price_orbs.toLocaleString()} Orbs
                  </div>
                )}
                {isXpUnlock && (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'var(--surface2)', borderRadius: 12, padding: 12, marginBottom: 14, fontSize: 15, fontWeight: 800, color: 'var(--text)' }}>
                    <Zap size={15} color="#f5c542" /> {item.unlock_xp!.toLocaleString()} XP reached — free unlock
                  </div>
                )}
                {item.price_gems != null && !canAffordGems && (
                  <div style={{ fontSize: 11, color: '#ff6b6b', textAlign: 'center', marginBottom: 10 }}>
                    Not enough Diamonds to buy this item.
                  </div>
                )}
                {item.price_orbs != null && !canAffordOrbs && (
                  <div style={{ fontSize: 11, color: '#ff6b6b', textAlign: 'center', marginBottom: 10 }}>
                    Not enough Orbs to unlock this item.
                  </div>
                )}
              </>
            )}

            <div style={{ display: 'flex', alignItems: 'stretch', gap: 8 }}>
              {!(alreadyOwned && !item.is_consumable) && (
                <button
                  disabled={checkingOwn || buying || (!isXpUnlock && !affordable)}
                  onClick={(e) => { ripple(e); handleBuy() }}
                  className="ripple-wrap"
                  style={{
                    flex: 1, padding: 13, borderRadius: 14, border: 'none',
                    cursor: buying || (!isXpUnlock && !affordable) ? 'not-allowed' : 'pointer',
                    background: buying || (!isXpUnlock && !affordable) ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
                    color: buying || (!isXpUnlock && !affordable) ? 'var(--text-muted)' : '#fff',
                    fontSize: 14, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                    boxShadow: buying || (!isXpUnlock && !affordable) ? 'none' : '0 4px 16px color-mix(in srgb, var(--accent) 35%, transparent)',
                    transition: 'background-color var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
                  }}
                >
                  <ShoppingBag size={14} /> {buying ? 'Buying…' : item.price_gems != null || item.price_orbs != null ? buyLabelBase : 'Unlock'}
                </button>
              )}
              {/* Gift is available for Diamond-priced items regardless of
                  whether you already own one yourself — you're buying a
                  fresh copy for someone else, not spending your own copy.
                  Orb/XP-unlock items have nothing to charge (send_gift is
                  priced off mall_items.price_gems), so no gift icon there. */}
              {onGift && item.price_gems != null && (
                <button
                  type="button"
                  onClick={(e) => { ripple(e); onGift(item) }}
                  className="ripple-wrap"
                  aria-label="Gift this item"
                  style={{
                    width: alreadyOwned && !item.is_consumable ? '100%' : 48, flexShrink: 0, borderRadius: 14, border: '1px solid var(--border)',
                    background: 'var(--surface2)', color: 'var(--text-dim)', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                    fontSize: 14, fontWeight: 800, padding: alreadyOwned && !item.is_consumable ? 13 : 0,
                  }}
                >
                  <GiftIcon size={17} /> {alreadyOwned && !item.is_consumable ? 'Gift to a friend' : null}
                </button>
              )}
            </div>
            {/* Customize now lives as an icon button up in the header,
                next to the wishlist heart — see hasVariants near the top
                of this sheet. Kept out of the action row here so Buy/Gift
                stay the only weighted actions this low in the sheet. */}
          </>
        )}
      </div>
    </div>

    {showEffectPreview && isCardEffect && userId && (
      <ProfileEffectPreview
        userId={userId}
        videoUrl={item.animated_url}
        onClose={() => setShowEffectPreview(false)}
      />
    )}

    {showCustomize && (
      <CustomizeSheet
        itemId={item.id}
        itemName={item.name}
        itemImageUrl={item.image_url}
        userId={userId}
        ownsItem={alreadyOwned}
        onClose={() => setShowCustomize(false)}
        onResult={(_result: VariantPurchaseResult, message: string) => onVariantResult?.(message)}
      />
    )}
    </>
  )
}

/* ══════════════════════════════════════════════════════
   SUB-PAGE WRAPPER — these are in-page view switches (openSection state,
   not a route change), so the title/back button they need is registered
   with the app Topbar via usePageHeader() rather than drawn inline. This
   replaced an inline back-button row that fought the app's own Topbar for
   the same strip of screen (both were `position: fixed; top: 0`).
══════════════════════════════════════════════════════ */
function SubPage({ title, onBack, children }: { title: string; onBack: () => void; children: React.ReactNode }) {
  usePageHeader({ title, onBack })
  return (
    <div style={{ maxWidth: 700, margin: '0 auto', animation: 'feedIn 0.25s ease-out both' }}>
      {children}
    </div>
  )
}

// Battle Cards buys through the same purchase_mall_item RPC as everything
// else, so the wallet refresh here is the same call the other sections make.
// Split into its own tiny component (rather than inlined in the openSection
// switch) purely so usePageHeader can be called unconditionally at the top
// of a component, per the rules of hooks.
function BattleCardsSubPage({ userId, onBack, onPurchased }: { userId: string | null; onBack: () => void; onPurchased: () => void }) {
  usePageHeader({ title: 'Battle Cards', onBack })
  return (
    <div style={{ padding: '0 20px 30px' }}>
      <BattleCardsSection userId={userId} onPurchased={onPurchased} />
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   PROFILE PICS SUB-PAGE
══════════════════════════════════════════════════════ */
// "Classic" covers every existing profile pic (sub_category is null on all
// of them). "Profile card effect" is the new tab holding the Discord-style
// animated effects — same pattern as the Avatar sub-tabs below.
//
// "Ended" is appended dynamically (see ProfilePicsPage) rather than being
// a fixed member of this list. A profile pic that was tagged "Classic" or
// "Profile card effect" while it was live gets pulled out of that tab the
// moment its available_until window closes and re-homed under "Ended" —
// keeping the everyday tabs free of dead event stock without losing the
// item's place in the wider Profile Pics category.
const PROFILE_PIC_SUB_CATEGORIES = ['Classic', 'Profile card effect']

function ProfilePicsPage({ items, onBack, onSelect, onWishlist, wishlisted, likeCounts, initialTab, isNewFn }: { items: MallItem[]; onBack: () => void; onSelect: (item: MallItem) => void; onWishlist?: (item: MallItem) => void; wishlisted?: Set<string>; likeCounts?: Record<string, number>; initialTab?: string; isNewFn?: (item: MallItem) => boolean }) {
  const profilePicItems = items.filter(i => i.category === 'profile_pic')
  const hasEnded = profilePicItems.some(isItemEnded)
  const tabs = hasEnded ? [...PROFILE_PIC_SUB_CATEGORIES, 'Ended'] : PROFILE_PIC_SUB_CATEGORIES
  const [activeTab, setActiveTab] = useState(initialTab ?? PROFILE_PIC_SUB_CATEGORIES[0])
  // A deep link (e.g. from the Mall page's "Shop All") always requests a
  // live tab, so falling back to Classic here is safe even if "Ended"
  // isn't in `tabs` yet on first render.
  const effectiveTab = tabs.includes(activeTab) ? activeTab : PROFILE_PIC_SUB_CATEGORIES[0]
  const profilePics = profilePicItems.filter(i => {
    const ended = isItemEnded(i)
    if (effectiveTab === 'Ended') return ended
    if (ended) return false
    return effectiveTab === 'Classic' ? !i.sub_category : i.sub_category === effectiveTab
  })

  return (
    <SubPage title="Profile Pics" onBack={onBack}>
      <div style={{ display: 'flex', gap: 6, marginBottom: 18, overflowX: 'auto' }}>
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={(e) => { ripple(e); setActiveTab(tab) }}
            className="ripple-wrap"
            style={{
              padding: '7px 14px', borderRadius: 20, cursor: 'pointer', whiteSpace: 'nowrap',
              fontSize: 12, fontWeight: 600, fontFamily: 'inherit',
              background: effectiveTab === tab ? 'var(--active)' : 'transparent',
              color: effectiveTab === tab ? 'var(--text)' : 'var(--text-dim)',
              border: effectiveTab === tab ? '1px solid var(--border-strong)' : '1px solid transparent',
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {profilePics.length === 0 ? (
        <EmptyState label={`No items in "${effectiveTab}" yet.`} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
          {profilePics.map(item => <SquareCard key={item.id} item={item} onSelect={onSelect} onWishlist={onWishlist} wishlisted={wishlisted?.has(item.id)} likeCount={likeCounts?.[item.id] ?? 0} isNew={isNewFn?.(item) ?? false} compact />)}
        </div>
      )}
    </SubPage>
  )
}

/* ══════════════════════════════════════════════════════
   AVATARS SUB-PAGE — with sub-category tabs
══════════════════════════════════════════════════════ */
// 'Animated Characters' was retired in Aug 2026 — the four items in it were
// full-size 720p mp4s (~14MB of egress per Mall visit) and nobody had bought
// one. The items are deactivated; this tab goes with them.
const AVATAR_SUB_CATEGORIES = ['Models and brand', 'Others', 'Power up characters']

function AvatarsPage({ items, onBack, onSelect, onWishlist, wishlisted, likeCounts, isNewFn }: { items: MallItem[]; onBack: () => void; onSelect: (item: MallItem) => void; onWishlist?: (item: MallItem) => void; wishlisted?: Set<string>; likeCounts?: Record<string, number>; isNewFn?: (item: MallItem) => boolean }) {
  const avatarItems = items.filter(i => i.category === 'avatar_skin')
  const hasEnded = avatarItems.some(isItemEnded)
  const tabs = hasEnded ? [...AVATAR_SUB_CATEGORIES, 'Ended'] : AVATAR_SUB_CATEGORIES
  const [activeTab, setActiveTab] = useState(AVATAR_SUB_CATEGORIES[0])
  const effectiveTab = tabs.includes(activeTab) ? activeTab : AVATAR_SUB_CATEGORIES[0]
  // Same re-homing rule as ProfilePicsPage: an avatar that closes its
  // event window drops out of whichever model/character tab it lived in
  // and only shows up under "Ended", so the browsable brand/character
  // tabs stay limited to what's actually still purchasable.
  const avatars = avatarItems.filter(i => {
    const ended = isItemEnded(i)
    if (effectiveTab === 'Ended') return ended
    return !ended && i.sub_category === effectiveTab
  })

  return (
    <SubPage title="Avatars" onBack={onBack}>
      <div style={{ display: 'flex', gap: 6, marginBottom: 18, overflowX: 'auto' }}>
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={(e) => { ripple(e); setActiveTab(tab) }}
            className="ripple-wrap"
            style={{
              padding: '7px 14px', borderRadius: 20, cursor: 'pointer', whiteSpace: 'nowrap',
              fontSize: 12, fontWeight: 600, fontFamily: 'inherit',
              background: effectiveTab === tab ? 'var(--active)' : 'transparent',
              color: effectiveTab === tab ? 'var(--text)' : 'var(--text-dim)',
              border: effectiveTab === tab ? '1px solid var(--border-strong)' : '1px solid transparent',
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {avatars.length === 0 ? (
        <EmptyState label={`No avatars in "${effectiveTab}" yet.`} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
          {avatars.map(item => <RectCard key={item.id} item={item} onSelect={onSelect} onWishlist={onWishlist} wishlisted={wishlisted?.has(item.id)} likeCount={likeCounts?.[item.id] ?? 0} isNew={isNewFn?.(item) ?? false} />)}
        </div>
      )}
    </SubPage>
  )
}

/** Shared "All / Ended" pill row for sub-pages that don't otherwise have
 *  sub-category tabs (Consumables, Banners). Only rendered by the caller
 *  when hasEnded is true, so a category with no expired stock keeps its
 *  original plain, tab-less layout. */
function EndedTabRow({ activeTab, onChange }: { activeTab: 'All' | 'Ended'; onChange: (tab: 'All' | 'Ended') => void }) {
  return (
    <div style={{ display: 'flex', gap: 6, marginBottom: 18 }}>
      {(['All', 'Ended'] as const).map(tab => (
        <button
          key={tab}
          onClick={(e) => { ripple(e); onChange(tab) }}
          className="ripple-wrap"
          style={{
            padding: '7px 14px', borderRadius: 20, cursor: 'pointer', whiteSpace: 'nowrap',
            fontSize: 12, fontWeight: 600, fontFamily: 'inherit',
            background: activeTab === tab ? 'var(--active)' : 'transparent',
            color: activeTab === tab ? 'var(--text)' : 'var(--text-dim)',
            border: activeTab === tab ? '1px solid var(--border-strong)' : '1px solid transparent',
          }}
        >
          {tab}
        </button>
      ))}
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   CONSUMABLES SUB-PAGE
══════════════════════════════════════════════════════ */
function ConsumablesPage({ items, onBack, onSelect, wishlisted, likeCounts, isNewFn }: { items: MallItem[]; onBack: () => void; onSelect: (item: MallItem) => void; wishlisted?: Set<string>; likeCounts?: Record<string, number>; isNewFn?: (item: MallItem) => boolean }) {
  const allConsumables = items.filter(i => i.category === 'xp_booster' || i.is_consumable)
  const hasEnded = allConsumables.some(isItemEnded)
  const [activeTab, setActiveTab] = useState<'All' | 'Ended'>('All')
  const consumables = allConsumables.filter(i => activeTab === 'Ended' ? isItemEnded(i) : !isItemEnded(i))
  return (
    <SubPage title="Consumables" onBack={onBack}>
      {hasEnded && <EndedTabRow activeTab={activeTab} onChange={setActiveTab} />}
      {consumables.length === 0 ? (
        <EmptyState label={activeTab === 'Ended' ? 'No ended consumables.' : 'No consumables available yet.'} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
          {consumables.map(item => <RectCard key={item.id} item={item} onSelect={onSelect} wishlisted={wishlisted?.has(item.id)} likeCount={likeCounts?.[item.id] ?? 0} isNew={isNewFn?.(item) ?? false} />)}
        </div>
      )}
    </SubPage>
  )
}

function BannersPage({ items, onBack, onSelect, onWishlist, wishlisted, likeCounts, isNewFn }: { items: MallItem[]; onBack: () => void; onSelect: (item: MallItem) => void; onWishlist?: (item: MallItem) => void; wishlisted?: Set<string>; likeCounts?: Record<string, number>; isNewFn?: (item: MallItem) => boolean }) {
  const allBanners = items.filter(i => i.sub_category === 'album' || i.category === 'banner')
  const hasEnded = allBanners.some(isItemEnded)
  const [activeTab, setActiveTab] = useState<'All' | 'Ended'>('All')
  const banners = allBanners.filter(i => activeTab === 'Ended' ? isItemEnded(i) : !isItemEnded(i))
  return (
    <SubPage title="Banners" onBack={onBack}>
      {hasEnded && <EndedTabRow activeTab={activeTab} onChange={setActiveTab} />}
      {banners.length === 0 ? (
        <EmptyState label={activeTab === 'Ended' ? 'No ended banners.' : 'No banners available yet.'} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
          {banners.map(item => <BannerCard key={item.id} item={item} onSelect={onSelect} onWishlist={onWishlist} wishlisted={wishlisted?.has(item.id)} likeCount={likeCounts?.[item.id] ?? 0} isNew={isNewFn?.(item) ?? false} />)}
        </div>
      )}
    </SubPage>
  )
}

function EmptyState({ label }: { label: string }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
      <ShoppingBag size={28} style={{ opacity: 0.35 }} />
      <div style={{ fontSize: 13 }}>{label}</div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   FEATURED BUNDLES (migrations 0106 + 0108)

   Admin-configured bundles: each has a name, one fixed Diamond price, and
   a set of Mall items. Tapping a banner opens the sheet below, and one
   purchase grants everything in it — four items or forty, the price is
   whatever the admin set.

   0108 made this a list rather than a single slot. Every published bundle
   gets a banner on the Mall page, but only the pinned one shows its item
   thumbnails underneath; for the rest the banner is the whole pitch and
   the contents live in the sheet behind "View bundle". That keeps the
   page from turning into an endless wall of strips as bundles pile up.

   `price_gems` can be null. That's the display-only case: artwork plus a
   browsable item row with no buy-all button, which is how this slot
   behaved before it became a bundle.
══════════════════════════════════════════════════════ */
interface BundleItem {
  id: string
  name: string
  category: MallItem['category']
  rarity: MallRarity
  image_url: string | null
  animated_url: string | null
  price_gems: number | null
  is_consumable: boolean
}

interface MallBundle {
  id: string
  name: string | null
  image_url: string | null
  price_gems: number | null
  is_pinned: boolean
  items: BundleItem[]
  total_value_gems: number
}

// The bundle sheet shows items as a grid rather than the horizontal strip
// on the Mall page — the whole point of opening it is seeing everything
// you're getting at once, without scrolling sideways to find item four.
function BundleItemTile({ item, owned, onTap }: { item: BundleItem; owned: boolean; onTap: () => void }) {
  const meta = RARITY_META[item.rarity] ?? RARITY_META.Common
  const posterIsVideo = !item.image_url && !!item.animated_url && /\.(mp4|webm)$/i.test(item.animated_url)

  return (
    <div
      onClick={(e) => { ripple(e); onTap() }}
      className="ripple-wrap"
      style={{ cursor: 'pointer', position: 'relative' }}
    >
      <div style={{
        width: '100%', aspectRatio: '1/1', borderRadius: 14, overflow: 'hidden',
        background: item.image_url ? `url(${item.image_url}) center/cover` : 'var(--surface2)',
        border: `1px solid ${item.rarity === 'Mythic' ? 'color-mix(in srgb, var(--accent) 30%, transparent)' : 'rgba(255,255,255,0.06)'}`,
        boxShadow: 'var(--elev-raise-sm)', position: 'relative',
      }}>
        {posterIsVideo && (
          <video src={item.animated_url!} muted playsInline preload="metadata" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        )}
        {/* Owned items still come with the bundle, they just won't be
            granted twice — saying so up front is fairer than letting
            someone find out after paying. */}
        {owned && (
          <div style={{
            position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 10, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase',
            color: 'rgba(255,255,255,0.9)',
          }}>
            Owned
          </div>
        )}
      </div>
      <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text)', marginTop: 6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
        {item.name}
      </div>
      <div style={{ fontSize: 9.5, fontWeight: 700, color: meta.color, marginTop: 1 }}>{item.rarity}</div>
    </div>
  )
}

function BundleSheet({
  bundle, walletBalance, userId, onClose, onPurchased, onOpenItem,
}: {
  bundle: MallBundle
  walletBalance: number
  userId: string | null
  onClose: () => void
  onPurchased: (message: string) => void
  onOpenItem: (itemId: string) => void
}) {
  const [buying, setBuying] = useState(false)
  const [ownedIds, setOwnedIds] = useState<Set<string>>(new Set())
  const [error, setError] = useState<string | null>(null)
  const realVh = useRealViewportHeight()
  const bundleSheetHeightPx = Math.round(realVh * 0.88)
  const { dragY, dragging, dragHandleProps, sheetProps } = useSheetDrag(onClose)

  // Same lock + dock-hide treatment as the buy sheet above.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  // Which of these the player already has, so the sheet can grey those
  // tiles out and the button can say what's actually left to gain.
  useEffect(() => {
    if (!userId || bundle.items.length === 0) return
    let active = true
    supabase.from('user_inventory').select('item_id').eq('user_id', userId).in('item_id', bundle.items.map(i => i.id))
      .then(({ data }) => {
        if (!active) return
        setOwnedIds(new Set((data ?? []).map((r: { item_id: string }) => r.item_id)))
      })
    return () => { active = false }
  }, [userId, bundle.items])

  const price = bundle.price_gems
  const buyable = price != null && bundle.items.length > 0
  // Consumables stack, so owning one doesn't mean there's nothing to gain
  // — only cosmetics are ever skipped at grant time. This mirrors exactly
  // what purchase_mall_bundle() counts as grantable server-side, so the
  // button never promises something the RPC would then refuse.
  const isSkipped = (i: BundleItem) => !i.is_consumable && ownedIds.has(i.id)
  const skippedCount = bundle.items.filter(isSkipped).length
  const newCount = bundle.items.length - skippedCount
  const ownsEverything = bundle.items.length > 0 && newCount === 0
  const canAfford = price != null && walletBalance >= price
  const saving = price != null ? bundle.total_value_gems - price : 0

  async function handleBuy() {
    if (!userId || buying || !buyable || ownsEverything || !canAfford) return
    setBuying(true)
    setError(null)
    try {
      // Server-priced and atomic: the client sends an id and nothing else,
      // so there's no price or item list here to tamper with.
      const { data, error: rpcError } = await supabase.rpc('purchase_mall_bundle', {
        p_bundle_id: bundle.id,
      })
      if (rpcError) {
        if (rpcError.message.includes('insufficient_funds')) setError('Not enough Diamonds for this bundle.')
        else if (rpcError.message.includes('already_owned')) setError('You already own everything in this bundle.')
        else if (rpcError.message.includes('bundle_unavailable')) setError('This bundle is no longer available.')
        else { console.error('bundle purchase error:', rpcError); setError('Purchase failed. Please try again.') }
        return
      }

      const granted = (data?.granted as number) ?? bundle.items.length
      const skipped = (data?.skipped as number) ?? 0

      updateMissionProgress(userId, 'items_purchased', granted).catch(console.error)

      onPurchased(skipped > 0
        ? `${granted} item${granted === 1 ? '' : 's'} added — you already owned the rest.`
        : `${bundle.name ?? 'Bundle'} unlocked — ${granted} item${granted === 1 ? '' : 's'} added!`)
      onClose()
    } catch (err) {
      console.error('bundle purchase error:', err)
      setError('Purchase failed. Please try again.')
    } finally {
      setBuying(false)
    }
  }

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{
        // Dock hides itself via cv-sheet-open (see the effect above) so
        // this sits flush at the true bottom edge — no reserved dock gap.
        position: 'fixed', inset: 0, zIndex: 800, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      {/* sheetProps: drag-to-dismiss from anywhere inside the sheet. */}
      <div {...sheetProps} style={{
        background: 'var(--surface)', borderRadius: '20px 20px 0 0', padding: '0 20px 24px', width: '100%', maxWidth: 460,
        border: '1px solid var(--border)', borderBottom: 'none', boxShadow: '0 -12px 40px -12px var(--sh)',
        position: 'relative', maxHeight: bundleSheetHeightPx, overflowY: 'auto', overscrollBehavior: 'contain',
        display: 'flex', flexDirection: 'column',
        transform: `translateY(${dragY}px)`,
        transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.16,1,0.3,1)',
        animation: dragging ? undefined : 'slideUp 0.28s cubic-bezier(0.16,1,0.3,1) both',
      }}>
        <div
          {...dragHandleProps}
          style={{ ...dragHandleProps.style, padding: '10px 0 8px', display: 'flex', justifyContent: 'center', flexShrink: 0 }}
        >
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', margin: '12px 0 4px', flexShrink: 0 }}>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            style={{ width: 32, height: 32, borderRadius: 10, border: 'none', background: 'var(--surface2)', color: 'var(--text-dim)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >
            <X size={15} />
          </button>
        </div>

        {bundle.image_url && (
          <div style={{
            width: '100%', aspectRatio: '2/1', borderRadius: 16, marginBottom: 14, flexShrink: 0,
            background: `var(--surface2) url(${bundle.image_url}) center/cover`,
            boxShadow: 'var(--elev-raise-sm)',
          }} />
        )}

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Sparkles size={15} style={{ color: 'var(--accent)', flexShrink: 0 }} />
          <h2 style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
            {bundle.name ?? 'Featured Bundle'}
          </h2>
        </div>
        <p style={{ fontSize: 12, color: 'var(--text-dim)', margin: '0 0 16px' }}>
          {bundle.items.length} item{bundle.items.length === 1 ? '' : 's'}
          {buyable ? ' — one price for all of them' : ' in this collection'}
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(88px, 1fr))', gap: 12, marginBottom: 18 }}>
          {bundle.items.map(item => (
            <BundleItemTile
              key={item.id}
              item={item}
              owned={isSkipped(item)}
              onTap={() => onOpenItem(item.id)}
            />
          ))}
        </div>

        {buyable && (
          <>
            {/* Price block. The saving is only worth showing when the items
                actually have individual prices to compare against — an
                all-XP-unlock bundle would otherwise claim a fake discount. */}
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
              padding: '13px 15px', borderRadius: 14, marginBottom: 12,
              background: 'var(--surface2)', border: '1px solid var(--border)',
            }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 2 }}>Bundle price</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text)' }}>💎 {price!.toLocaleString()}</div>
              </div>
              {saving > 0 && (
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <div style={{ fontSize: 11.5, color: 'var(--text-muted)', textDecoration: 'line-through' }}>
                    {bundle.total_value_gems.toLocaleString()}
                  </div>
                  <div style={{ fontSize: 11.5, fontWeight: 800, color: '#4fd18a' }}>
                    Save {saving.toLocaleString()}
                  </div>
                </div>
              )}
            </div>

            {skippedCount > 0 && !ownsEverything && (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.5 }}>
                You already own {skippedCount} of these — the price is for the
                bundle, so you'll be charged in full and receive the {newCount} you don't have.
              </p>
            )}

            {error && <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '0 0 12px' }}>{error}</p>}

            <button
              onClick={handleBuy}
              disabled={buying || ownsEverything || !canAfford || !userId}
              className="btn-primary"
              style={{
                width: '100%', padding: '13px 0', fontSize: 14, fontWeight: 800,
                opacity: (buying || ownsEverything || !canAfford) ? 0.5 : 1,
                cursor: (buying || ownsEverything || !canAfford) ? 'default' : 'pointer',
              }}
            >
              {buying ? 'Purchasing…'
                : ownsEverything ? 'You own everything in this bundle'
                : !canAfford ? `Need ${(price! - walletBalance).toLocaleString()} more Diamonds`
                : `Buy all ${bundle.items.length} — 💎 ${price!.toLocaleString()}`}
            </button>
            <p style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: 'center', margin: '10px 0 0' }}>
              Balance: 💎 {walletBalance.toLocaleString()}
            </p>
          </>
        )}

        {!buyable && (
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', textAlign: 'center', margin: 0, lineHeight: 1.5 }}>
            Tap any item to view and buy it on its own.
          </p>
        )}
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   TOP-LEVEL SECTION MENU CONFIG
══════════════════════════════════════════════════════ */
const SECTIONS = [
  { id: 'profile_pics', label: 'Profile Pics', sub: 'Square cards, no sub-categories', Icon: ImageIcon, iconBg: 'rgba(79,142,247,0.15)',  iconColor: '#4f8ef7' },
  { id: 'avatars',      label: 'Avatars',      sub: 'Models, Others, Power up',        Icon: Shirt,     iconBg: 'rgba(255,77,139,0.15)', iconColor: '#ff4d8b' },
  { id: 'consumables',  label: 'Consumables',  sub: 'XP boosters and more',             Icon: Zap,       iconBg: 'rgba(245,197,66,0.15)', iconColor: '#f5c542' },
  { id: 'banners',      label: 'Banners',       sub: 'Profile banner images',            Icon: ImageIcon, iconBg: 'rgba(155,109,255,0.15)', iconColor: '#9b6dff' },
  { id: 'battle_cards', label: 'Battle Cards',  sub: 'Attack cards for PvP',             Icon: Swords,    iconBg: 'rgba(255,77,109,0.15)',  iconColor: '#ff4d6d' },
] as const

/* ══════════════════════════════════════════════════════
   MAIN MALL PAGE
══════════════════════════════════════════════════════ */
export default function Mall() {
  const navigate = useNavigate()
  const { items, loading: itemsLoading } = useMallItems()
  const { wallet, refetch: refetchWallet } = useWallet()
  const { session } = useAuth()
  const userId = session?.user?.id ?? null
  const { isNew, hasNew, markViewed } = useMallNewBadges(userId)
  const { profile } = useProfile()
  const isPro = isProActive(profile)
  const userXp = profile?.xp ?? 0
  const { isEnabled: isMallFlagEnabled, loading: mallFlagLoading } = useFeatureFlags()
  const { isStaff: mallIsStaff } = useModRole()
  const [openSection, setOpenSection] = useState<string | null>(null)
  const [profilePicsInitialTab, setProfilePicsInitialTab] = useState<string>('Classic')
  const [selectedItem, setSelectedItem] = useState<MallItem | null>(null)

  // Opening an item's sheet is what "views" it for the new-item badge
  // cascade — see useMallNewBadges.ts. Every entry point into the sheet
  // (front-page strip, category grid, bundle contents, deep link) already
  // funnels through setSelectedItem, so one effect here covers all of them
  // rather than repeating the call at each click handler.
  useEffect(() => {
    if (selectedItem) markViewed(selectedItem.id)
  }, [selectedItem, markViewed])

  const [wishlisted, setWishlisted] = useState<Set<string>>(new Set())
  const [toast, setToast] = useState<string | null>(null)
  const [purchaseToast, setPurchaseToast] = useState<string | null>(null)
  const [giftItem, setGiftItem] = useState<MallItem | null>(null)
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({})
  const diamondBalance = wallet?.gem_balance ?? 0
  const orbBalance = wallet?.orb_balance ?? 0

  // Limited-time items are evaluated against Date.now() at render, so the
  // page needs a heartbeat to re-render — otherwise a countdown sits
  // frozen and an item that just ended keeps looking buyable until the
  // player navigates away. Only runs while something is actually on a
  // timer, so the usual all-null catalog costs nothing.
  const [, setMallClock] = useState(0)
  const hasTimedItems = useMemo(() => items.some(i => i.available_until != null), [items])
  useEffect(() => {
    if (!hasTimedItems) return
    const t = setInterval(() => setMallClock(c => c + 1), 30_000)
    return () => clearInterval(t)
  }, [hasTimedItems])

  // Published collab names, keyed by id — only fetched when something in
  // the catalog is actually tagged, so the usual untagged catalog costs
  // no request. get_collabs() returns published rows only, which is
  // exactly the set whose names are safe to show on an item.
  const [collabNames, setCollabNames] = useState<Record<string, string>>({})
  const hasCollabItems = useMemo(() => items.some(i => i.collab_id != null), [items])
  useEffect(() => {
    if (!hasCollabItems) { setCollabNames({}); return }
    let alive = true
    fetchCollabs().then(({ data }) => {
      if (!alive) return
      const map: Record<string, string> = {}
      for (const c of data) map[c.id] = c.name
      setCollabNames(map)
    })
    return () => { alive = false }
  }, [hasCollabItems])

  // Deep link from a collab item tile (/mall?item=<id>) — opens that
  // item's sheet directly instead of dropping the visitor at the top of
  // the Mall to hunt for it. The param is consumed once and stripped, so
  // a back-navigation or refresh doesn't reopen a sheet the player closed.
  const [searchParams, setSearchParams] = useSearchParams()
  const deepLinkItemId = searchParams.get('item')
  useEffect(() => {
    if (!deepLinkItemId || !items.length) return
    const hit = items.find(i => i.id === deepLinkItemId)
    if (hit) setSelectedItem(hit)
    setSearchParams(prev => {
      const next = new URLSearchParams(prev)
      next.delete('item')
      return next
    }, { replace: true })
  }, [deepLinkItemId, items, setSearchParams])

  // Load like counts for all visible items + subscribe to realtime changes
  useEffect(() => {
    if (!items.length) return
    // Initial load
    // Load counts from public view + poll every 30s for cross-user live updates
    async function loadCounts() {
      const { data } = await supabase.from('wishlist_counts').select('item_id, count')
      if (!data) return
      const counts: Record<string, number> = {}
      for (const row of data) {
        counts[row.item_id as string] = row.count as number
      }
      setLikeCounts(counts)
    }
    loadCounts()
    const poll = setInterval(loadCounts, 30_000)
    return () => clearInterval(poll)
  }, [items.length])

  // Load existing wishlist ids
  useEffect(() => {
    if (!userId) return
    supabase.from('wishlist').select('item_id').eq('user_id', userId)
      .then(({ data }) => {
        setWishlisted(new Set((data ?? []).map((r: { item_id: string }) => r.item_id)))
      })
  }, [userId])

  const handleWishlist = useCallback(async (item: MallItem) => {
    if (!userId) return
    if (wishlisted.has(item.id)) return // already wishlisted, tap does nothing (remove from profile)
    await supabase.from('wishlist').upsert({
      user_id: userId,
      item_id: item.id,
      item_name: item.name,
      item_type: item.category,
      item_image: item.image_url ?? null,
    }, { onConflict: 'user_id,item_id' })
    setWishlisted(prev => new Set([...prev, item.id]))
    setToast('This item has been added to your wishlist.')
    // Weekly mission: wishlist_adds
    if (userId) updateMissionProgress(userId, 'wishlist_adds', 1).catch(console.error)
  }, [userId, wishlisted])

  function handleGiftSent(outcome: Parameters<typeof giftResultMessage>[0], recipientName: string) {
    setGiftItem(null)
    setPurchaseToast(giftResultMessage(outcome, recipientName))
  }

  // Featured bundles — admin-controlled name, artwork, fixed price and
  // contents (migrations 0106 + 0108). Each comes back fully resolved from
  // the RPC (names, rarities, prices) rather than being looked up in
  // `items`, because the sheet needs the server's own view of what's in
  // the bundle and what it's worth — the same data the purchase is priced
  // against. Empty array when nothing is published, which hides the
  // section entirely.
  //
  // Already sorted pinned-first server-side, so the render order below is
  // just the array order.
  const [bundles, setBundles] = useState<MallBundle[]>([])
  const [openBundleId, setOpenBundleId] = useState<string | null>(null)
  const openBundle = bundles.find(b => b.id === openBundleId) ?? null
  useEffect(() => {
    let active = true
    supabase.rpc('get_mall_bundles').then(({ data }) => {
      if (!active || !data) return
      setBundles(data as MallBundle[])
    })
    return () => { active = false }
  }, [])

  // Per-category preview strips for the "Shop" advertisement rows —
  // each SECTIONS entry gets a horizontal-scroll sample of its catalog
  // plus a "Shop All" button that opens the full category page.
  // Ended event items are excluded from every preview strip below — they
  // still live inside their category's sub-page under the "Ended" tab,
  // but the front-page teasers are meant to advertise what's actually
  // buyable right now, not stock that's already closed.
  const categoryPreviews = useMemo(() => ({
    profile_pics: items.filter(i => i.category === 'profile_pic' && !i.sub_category && !isItemEnded(i)).slice(0, 8),
    avatars:      items.filter(i => i.category === 'avatar_skin' && !isItemEnded(i)).slice(0, 8),
    consumables:  items.filter(i => (i.category === 'xp_booster' || i.is_consumable) && !isItemEnded(i)).slice(0, 8),
    banners:      items.filter(i => (i.sub_category === 'album' || i.category === 'banner') && !isItemEnded(i)).slice(0, 8),
    // Without this key the preview strip is empty, and the render loop
    // below bails on `if (!preview.length) return null` — which silently
    // hides the whole Battle Cards row even though the section is
    // configured in SECTIONS.
    // Battle Consumables are pvp_card rows too — category can't change,
    // because get_pvp_cards filters on it and they'd drop out of the
    // attack sheet and quick slots. They belong on the Consumables shelf
    // above (they carry mall_items.is_consumable), not here.
    battle_cards: items.filter(
      i => i.category === 'pvp_card'
        && i.sub_category !== 'Battle Consumables'
        && !isItemEnded(i),
    ).slice(0, 8),
  } as Record<string, MallItem[]>), [items])

  // Full (un-sliced, all-tabs) membership per category — used only to
  // decide whether a category's "Shop All" pill should show a dot. Has to
  // be broader than categoryPreviews above: that one is a single-tab,
  // 8-item advertisement strip, so a new item outside the first 8, or
  // sitting in a tab other than Classic/Models, would otherwise never
  // light the category up even though it's genuinely new and unopened.
  const categoryFullItems = useMemo(() => ({
    profile_pics: items.filter(i => i.category === 'profile_pic'),
    avatars:      items.filter(i => i.category === 'avatar_skin'),
    consumables:  items.filter(i => i.category === 'xp_booster' || i.is_consumable),
    banners:      items.filter(i => i.sub_category === 'album' || i.category === 'banner'),
    battle_cards: items.filter(i => i.category === 'pvp_card' && i.sub_category !== 'Battle Consumables'),
  } as Record<string, MallItem[]>), [items])

  if (!mallFlagLoading && !isMallFlagEnabled('system:mall') && !mallIsStaff) {
    return (
      <FeatureGateScreen
        title="Mall is temporarily unavailable"
        message="An admin has paused the Mall for maintenance. The rest of Chillverse is still open — check back soon."
      />
    )
  }

  return (
    <MallProContext.Provider value={isPro}>
    <MallXpContext.Provider value={userXp}>
    <MallCollabContext.Provider value={collabNames}>
    <PageOnboarding pageKey="mall" />
      <style>{`
        @keyframes slideInRight { from { transform: translateX(100%) } to { transform: translateX(0) } }
        @keyframes feedIn { from { opacity:0; transform: translateY(12px) } to { opacity:1; transform: translateY(0) } }
        @keyframes feedInCenter {
          from { opacity:0; transform: translateX(-50%) translateY(12px) }
          to   { opacity:1; transform: translateX(-50%) translateY(0) }
        }
        @keyframes slideUp { from { transform: translateY(100%) } to { transform: translateY(0) } }

        /* Profile Effects banner: aspect-ratio steps up on wider viewports
           (phone → tablet) so background-size:contain never has to shrink
           the artwork more than necessary to avoid cropping it. */
        .effects-banner { aspect-ratio: 1.6 / 1; }
        @media (min-width: 420px) { .effects-banner { aspect-ratio: 1.9 / 1; } }
        @media (min-width: 700px) { .effects-banner { aspect-ratio: 2.4 / 1; } }
        @media (min-width: 1000px) { .effects-banner { aspect-ratio: 3 / 1; } }
      `}</style>

      {!openSection && (
      <div style={{ maxWidth: 700, margin: '0 auto' }}>
        {/* Balance + top-up row. The back button that used to live here was
            removed — /mall is a top-level dock destination, so the app
            Topbar already correctly shows no back button; this one was a
            leftover duplicate. See PAGE_HEADER_MIGRATION_PLAN.md Phase 1. */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', marginBottom: 20 }}>
          {/* Balance + top-up, as one control. The old full-width "Buy
              Diamonds" card was a lot of page for a link people only need
              occasionally — the plus does the same job from here, right
              next to the number that prompts it. */}
          <button
            type="button"
            onClick={(e) => { ripple(e); navigate('/buy-diamonds') }}
            aria-label={`${diamondBalance.toLocaleString()} Diamonds — buy more`}
            className="ripple-wrap"
            style={{
              display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface2)',
              border: '1px solid var(--border)', padding: '6px 6px 6px 13px', borderRadius: 20,
              fontSize: 12, fontWeight: 700, color: 'var(--text)', cursor: 'pointer',
              fontFamily: 'inherit', position: 'relative', overflow: 'hidden',
            }}
          >
            💎 {diamondBalance.toLocaleString()} Diamonds
            <span style={{
              width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
              background: 'rgba(79,142,247,0.18)', color: '#4f8ef7',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Plus size={13} strokeWidth={3} />
            </span>
          </button>
        </div>

        {itemsLoading && (
          <div style={{ textAlign: 'center', padding: 20, fontSize: 12, color: 'var(--text-muted)' }}>Loading catalog…</div>
        )}

        {/* Featured bundles — admin-controlled (migrations 0106 + 0108):
            name, artwork, one fixed price, and whichever existing Mall
            items staff picked. The artwork carries its own title, so
            there's no heading row above it repeating the name and price —
            the banner is the ad. Tapping it opens the bundle sheet, which
            is where the price, the item list and the buy button live.

            Only the pinned bundle shows its thumbnails on the page. Every
            other one is banner-only: people tap "View bundle" to see
            what's inside. Otherwise each new bundle would add another
            strip and the Mall's actual categories would sink below three
            screens of promos. */}
        {bundles.map((bundle, i) => (
          <div key={bundle.id} style={{ marginBottom: 26, animation: 'feedIn 0.35s ease-out both', animationDelay: `${i * 0.05}s` }}>
            <div
              className="effects-banner ripple-wrap"
              onClick={(e) => { ripple(e); setOpenBundleId(bundle.id) }}
              style={{
                position: 'relative', width: '100%', borderRadius: 20, overflow: 'hidden',
                marginBottom: bundle.is_pinned && bundle.items.length > 0 ? 12 : 0,
                boxShadow: 'var(--elev-raise)',
                background: `var(--surface2) url(${bundle.image_url}) center/contain no-repeat`,
                cursor: 'pointer',
              }}
            >
              {/* Without this the artwork gives no hint it's tappable —
                  the 0105 banner wasn't, so people have learned it isn't.
                  On unpinned bundles it's the only way in, so it's the one
                  overlay that always stays. */}
              {bundle.items.length > 0 && (
                <div style={{ position: 'absolute', bottom: 12, right: 14, display: 'flex', alignItems: 'center', gap: 4, fontSize: 10.5, fontWeight: 800, color: 'rgba(255,255,255,0.92)', background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(6px)', padding: '5px 10px', borderRadius: 20 }}>
                  {bundle.price_gems != null ? 'View bundle' : 'View all'} <ChevronRight size={11} />
                </div>
              )}
            </div>
            {bundle.is_pinned && bundle.items.length > 0 && (
              <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 4 }}>
                {bundle.items.map(bundleItem => {
                  const full = items.find(i => i.id === bundleItem.id)
                  return (
                    <div
                      key={bundleItem.id}
                      onClick={(e) => { ripple(e); if (full) setSelectedItem(full); else setOpenBundleId(bundle.id) }}
                      className="ripple-wrap"
                      style={{ flex: '0 0 96px', cursor: 'pointer' }}
                    >
                      <CardThumb
                        item={(full ?? bundleItem) as MallItem}
                        style={{ width: 96, height: 96, borderRadius: 14, boxShadow: 'var(--elev-raise-sm)' }}
                      />
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        ))}

        {SECTIONS.map((section, i) => {
          const preview = categoryPreviews[section.id] ?? []
          if (!preview.length) return null
          const sectionHasNew = hasNew(categoryFullItems[section.id] ?? preview)
          return (
            <div key={section.id} style={{ marginBottom: 26, animation: 'feedIn 0.35s ease-out both', animationDelay: `${i * 0.05}s` }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)' }}>{section.label}</div>
                  {sectionHasNew && <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#ff4d6d', flexShrink: 0 }} />}
                </div>
                <button
                  onClick={(e) => { ripple(e); setProfilePicsInitialTab('Classic'); setOpenSection(section.id) }}
                  className="ripple-wrap"
                  style={{
                    display: 'flex', alignItems: 'center', gap: 2, background: 'var(--surface2)', border: '1px solid var(--border)',
                    borderRadius: 20, padding: '5px 10px', fontSize: 11, fontWeight: 700, color: 'var(--text-dim)',
                    cursor: 'pointer', fontFamily: 'inherit',
                  }}
                >
                  Shop All <ChevronRight size={12} />
                </button>
              </div>
              <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 4 }}>
                {preview.map(item => (
                  <div
                    key={item.id}
                    onClick={(e) => { ripple(e); setSelectedItem(item) }}
                    className="ripple-wrap"
                    style={{ flex: '0 0 96px', cursor: 'pointer', position: 'relative' }}
                  >
                    <CardThumb item={item} style={{ width: 96, height: 96, borderRadius: 14, boxShadow: 'var(--elev-raise-sm)' }} />
                    {isNew(item) && <NewDot />}
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
      )}

      {/* Sub-pages */}
      {openSection === 'profile_pics' && <ProfilePicsPage items={items} onBack={() => setOpenSection(null)} onSelect={setSelectedItem} onWishlist={handleWishlist} wishlisted={wishlisted} likeCounts={likeCounts} initialTab={profilePicsInitialTab} isNewFn={isNew} />}
      {openSection === 'avatars'      && <AvatarsPage      items={items} onBack={() => setOpenSection(null)} onSelect={setSelectedItem} onWishlist={handleWishlist} wishlisted={wishlisted} likeCounts={likeCounts} isNewFn={isNew} />}
      {openSection === 'consumables'  && <ConsumablesPage  items={items} onBack={() => setOpenSection(null)} onSelect={setSelectedItem} wishlisted={wishlisted} likeCounts={likeCounts} isNewFn={isNew} />}
      {openSection === 'banners'      && <BannersPage       items={items} onBack={() => setOpenSection(null)} onSelect={setSelectedItem} onWishlist={handleWishlist} wishlisted={wishlisted} likeCounts={likeCounts} isNewFn={isNew} />}
      {openSection === 'battle_cards' && (
        <BattleCardsSubPage userId={userId} onBack={() => setOpenSection(null)} onPurchased={refetchWallet} />
      )}

      {/* Bundle sheet — slides up from the banner. Tapping an item inside
          it hands off to the normal single-item sheet rather than stacking
          two sheets on top of each other. */}
      {openBundle && (
        <BundleSheet
          bundle={openBundle}
          walletBalance={diamondBalance}
          userId={userId}
          onClose={() => setOpenBundleId(null)}
          onOpenItem={(itemId) => {
            const full = items.find(i => i.id === itemId)
            if (!full) return
            setOpenBundleId(null)
            setSelectedItem(full)
          }}
          onPurchased={(message) => {
            setPurchaseToast(message)
            refetchWallet?.()
          }}
        />
      )}

      {/* Detail / confirm modal */}
      {selectedItem && (
        <ItemModal
          item={selectedItem}
          walletBalance={diamondBalance}
          orbBalance={orbBalance}
          userId={userId}
          onClose={() => setSelectedItem(null)}
          onWishlist={handleWishlist}
          wishlisted={wishlisted.has(selectedItem.id)}
          previewProfile={profile ? { avatar: profile.avatar, displayName: profile.display_name ?? profile.username, username: profile.username, banner: profile.banner_url } : null}
          onGift={(item) => { setSelectedItem(null); setGiftItem(item) }}
          onVariantResult={(message) => { setPurchaseToast(message); refetchWallet?.() }}
          onPurchaseFailed={(message) => setPurchaseToast(message)}
          onPurchased={(item) => {
            setPurchaseToast(`${item.name} added to your inventory!`)
            setWishlisted(prev => {
              if (!prev.has(item.id)) return prev
              const next = new Set(prev)
              next.delete(item.id)
              return next
            })
            refetchWallet?.()
          }}
        />
      )}
      {giftItem && (
        <SendGiftModal
          target={{ itemId: giftItem.id, itemName: giftItem.name, itemImage: giftItem.image_url }}
          onClose={() => setGiftItem(null)}
          onSent={handleGiftSent}
        />
      )}
      {purchaseToast && <PurchaseToast message={purchaseToast} onDone={() => setPurchaseToast(null)} />}

      {/* Wishlist toast */}
      {toast && <WishlistToast message={toast} onDone={() => setToast(null)} />}
    </MallCollabContext.Provider>
    </MallXpContext.Provider>
    </MallProContext.Provider>
  )
}
