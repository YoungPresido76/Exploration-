// src/features/economy/flashSale.ts
// Shared read side of the Flash Sale CMS (migrations 0097 + 0107). Both
// BuyDiamonds.tsx's embedded section and the Game Zone card/modal
// (GamesZone.tsx) poll the same public.get_active_flash_sale() RPC through
// this hook, so they always agree on whether a sale is live right now.
import { useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'

export interface FlashSaleItem {
  id: string
  diamonds: number
  original_price_cents: number
  discount_pct: number
  sale_price_cents: number
}

export interface ActiveFlashSale {
  type: 'weekly_special' | 'monthly_mega'
  title: string
  subtitle: string | null
  image_url: string | null
  starts_at: string
  ends_at: string
  items: FlashSaleItem[]
}

export function formatNaira(cents: number): string {
  return `₦${Math.round(cents / 100).toLocaleString()}`
}

export function formatFlashCountdown(endsAt: string): string {
  const diffMs = new Date(endsAt).getTime() - Date.now()
  if (diffMs <= 0) return 'Ending soon'
  const totalMinutes = Math.floor(diffMs / 60000)
  const hours = Math.floor(totalMinutes / 60)
  const minutes = totalMinutes % 60
  if (hours > 0) return `Ends in ${hours}h ${minutes}m`
  return `Ends in ${minutes}m`
}

/** Small "1H" / "24H" style tag for how long the whole sale window runs
 *  (starts_at → ends_at), not how much time is left — that's
 *  formatFlashCountdown's job. */
export function formatFlashDurationTag(startsAt: string, endsAt: string): string {
  const durationMs = new Date(endsAt).getTime() - new Date(startsAt).getTime()
  const hours = Math.round(durationMs / 3600000)
  if (hours >= 24) return `${Math.round(hours / 24)}D SALE`
  if (hours >= 1) return `${hours}H SALE`
  const minutes = Math.max(1, Math.round(durationMs / 60000))
  return `${minutes}M SALE`
}

/** Polls get_active_flash_sale() every 60s and re-renders every 30s purely
 *  to keep any on-screen countdown fresh. Returns null while none of the
 *  two schedules (weekly_special / monthly_mega) is currently open — the
 *  card/section this drives should render nothing in that case. */
export function useActiveFlashSale() {
  const [flashSale, setFlashSale] = useState<ActiveFlashSale | null>(null)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    let cancelled = false

    function load() {
      supabase.rpc('get_active_flash_sale').then(({ data, error }) => {
        if (cancelled) return
        if (error) {
          console.error('get_active_flash_sale error:', error)
          setFlashSale(null)
          return
        }
        setFlashSale((data as ActiveFlashSale | null) ?? null)
      })
    }

    load()
    const refreshInterval = setInterval(load, 60000)
    const countdownInterval = setInterval(() => setTick(t => t + 1), 30000)

    return () => {
      cancelled = true
      clearInterval(refreshInterval)
      clearInterval(countdownInterval)
    }
  }, [])

  return { flashSale, tick }
}
