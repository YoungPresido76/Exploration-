// src/features/economy/RedeemCodeModal.tsx
import { useState } from 'react'
import { X, Gift, Sparkles, Loader2 } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { redeemCode, REDEEM_TOAST_MESSAGE, type RedeemSuccessResult } from './redeemCodes'

const CURRENCY_LABEL: Record<string, string> = {
  diamonds: 'Diamonds',
  orbs: 'Orbs',
  vouchers: 'Vouchers',
}

export default function RedeemCodeModal({
  onClose,
  onToast,
  onRedeemed,
}: {
  onClose: () => void
  onToast: (message: string, tone: 'success' | 'error') => void
  /** Called after a successful redemption so the caller can refresh wallet/inventory state. */
  onRedeemed: () => void
}) {
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const [success, setSuccess] = useState<RedeemSuccessResult | null>(null)

  async function handleSubmit() {
    const trimmed = code.trim()
    if (!trimmed || busy) return
    setBusy(true)
    const { data, error } = await redeemCode(trimmed)
    setBusy(false)

    if (error) {
      onToast(error, 'error')
      return
    }
    if (!data) return

    if (!data.success) {
      onToast(REDEEM_TOAST_MESSAGE[data.reason], 'error')
      return
    }

    setSuccess(data)
    onRedeemed()

    const rewardMessage = data.reward_type === 'currency'
      ? `Code redeemed! +${data.currency_amount?.toLocaleString()} ${CURRENCY_LABEL[data.currency_type ?? '']} added.`
      : data.stackable
        ? `Code redeemed! ${data.item_name} added — use it to upgrade.`
        : `Code redeemed! ${data.item_name} added to your collection.`
    onToast(rewardMessage, 'success')
  }

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 9500,
        background: 'rgba(0,0,0,0.6)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 20,
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <div
        style={{
          width: '100%', maxWidth: 420,
          background: 'var(--surface)',
          borderRadius: 20,
          border: '1px solid var(--border)',
          boxShadow: 'var(--elev-raise)',
          padding: '20px 20px 24px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'rgba(240,192,96,0.15)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Gift size={18} style={{ color: '#f0c060' }} />
            </div>
            <h2 style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)', margin: 0 }}>Redeem Code</h2>
          </div>
          <button
            type="button"
            onClick={(e) => { ripple(e); onClose() }}
            style={{
              width: 32, height: 32, borderRadius: 9,
              background: 'var(--surface-2, rgba(255,255,255,0.06))',
              border: '1px solid var(--border)', color: 'var(--text-dim)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
            }}
          >
            <X size={16} />
          </button>
        </div>

        {success ? (
          <div style={{ textAlign: 'center', padding: '12px 0 4px' }}>
            <Sparkles size={40} style={{ color: '#f0c060', marginBottom: 10 }} />
            <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', margin: '0 0 6px' }}>Reward unlocked!</p>
            <p style={{ fontSize: 13, color: 'var(--text-dim)', margin: '0 0 20px' }}>
              {success.reward_type === 'currency'
                ? `+${success.currency_amount?.toLocaleString()} ${CURRENCY_LABEL[success.currency_type ?? '']}`
                : success.item_name}
            </p>
            <button
              type="button"
              onClick={(e) => { ripple(e); onClose() }}
              style={{
                width: '100%', padding: '13px 0', borderRadius: 13, border: 'none',
                background: 'linear-gradient(135deg,#ff9d3d,#ff7a1a)',
                color: '#1a0f00', fontWeight: 800, fontSize: 14.5, cursor: 'pointer',
              }}
            >
              Nice!
            </button>
          </div>
        ) : (
          <>
            <p style={{ fontSize: 13, color: 'var(--text-dim)', margin: '0 0 14px' }}>
              Enter a code to redeem currency, a mall item, banner, avatar artefact, or PvP card.
            </p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="CHLVERS_XXXXX"
              autoCapitalize="characters"
              autoCorrect="off"
              spellCheck={false}
              onKeyDown={(e) => { if (e.key === 'Enter') handleSubmit() }}
              style={{
                width: '100%', boxSizing: 'border-box', padding: '14px 16px',
                borderRadius: 13, border: '1px solid var(--border)',
                background: 'var(--surface-2, rgba(255,255,255,0.04))',
                color: 'var(--text)', fontSize: 16, fontWeight: 700, letterSpacing: 1,
                textAlign: 'center', marginBottom: 14, outline: 'none',
              }}
            />
            <button
              type="button"
              disabled={!code.trim() || busy}
              onClick={(e) => { ripple(e); handleSubmit() }}
              style={{
                width: '100%', padding: '13px 0', borderRadius: 13, border: 'none',
                background: !code.trim() || busy ? 'var(--surface-2, rgba(255,255,255,0.08))' : 'linear-gradient(135deg,#ff9d3d,#ff7a1a)',
                color: !code.trim() || busy ? 'var(--text-muted)' : '#1a0f00',
                fontWeight: 800, fontSize: 14.5,
                cursor: !code.trim() || busy ? 'default' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}
            >
              {busy ? <Loader2 size={16} className="spin" /> : null}
              {busy ? 'Redeeming…' : 'Redeem'}
            </button>
          </>
        )}
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } } .spin { animation: spin 0.8s linear infinite; }`}</style>
    </div>
  )
}
