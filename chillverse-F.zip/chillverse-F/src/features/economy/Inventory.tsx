// src/features/economy/Inventory.tsx
//
// One screen for everything a player owns. Three different backends feed it
// — bought cosmetics (user_inventory), battle skills (get_pvp_cards) and
// titles (player_artifacts) — and inventoryModel.ts flattens all three into
// a single list so the tabs, the filter sheet and the grid can treat them
// the same way. This file is deliberately about layout and write paths
// only; the filtering/sorting rules live in the model.
import { useState, useEffect, useCallback, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Package, Filter, MoreHorizontal, X, CheckCircle2, CircleDashed,
  Shield, Snowflake, Clock, Swords, Zap, Plus, ChevronRight,
  Pencil, Store, Network, Crown, ArrowUp,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { useWallet } from './useWallet'
import { usePvpCards, useQuickSlots } from '../pvp/usePvpCards'
import {
  setQuickSlot, upgradeCard, pvpErrorMessage, isAttackCard,
  cardBlockedUntil, formatCooldownRemaining, type PvpCard,
} from '../pvp/pvp'
import { getXpProgress } from '../../shared/lib/level'
import { MAX_ENERGY } from '../exploration/explorationMaps'
import { updateMissionProgress } from '../missions/weeklyMissions'
import type { MallItem } from '../../shared/types'
import ConsumableIcon, { isConsumableIconCategory } from './ConsumableIcon'
import InventoryFilterSheet from './InventoryFilterSheet'
import {
  canHaveVariants, fetchItemVariants, fetchOwnedVariantIds, type ItemVariant,
} from './itemVariants'
import {
  buildInventoryItems, filterAndSortItems, countActiveFilters, isManuallyUsable,
  CATEGORIES, RARITY_COLOR, DEFAULT_FILTERS,
  type InvItem, type InvFilters, type InvCategory,
  type InventoryEntry, type OwnedTitle,
} from './inventoryModel'

/* ══════════════════════════════════════════════════
   DATA
══════════════════════════════════════════════════ */

/**
 * What actually "conflicts" when equipping — normally just the mall
 * category (only one avatar skin, one xp booster, etc. at a time). Profile
 * card effects and albums both live under the profile_pic/banner categories
 * for browsing purposes, but each is its own independent slot: equipping an
 * effect must NOT unequip your actual profile picture, and vice versa.
 */
function equipSlot(item: MallItem): string {
  if (item.sub_category === 'Profile card effect') return 'profile_card_effect'
  if (item.sub_category === 'album') return 'album'
  return item.category
}

function useInventory(userId: string | null) {
  const [inventory, setInventory] = useState<InventoryEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId) { setInventory([]); setLoading(false); return }
    let active = true
    setLoading(true)

    supabase
      .from('user_inventory')
      .select('id, item_id, is_equipped, quantity, acquired_at, equipped_variant_id, item:mall_items(*)')
      .eq('user_id', userId)
      .then(({ data, error }) => {
        if (!active) return
        if (error) { console.error('inventory fetch:', error); setLoading(false); return }
        setInventory((data ?? []) as unknown as InventoryEntry[])
        setLoading(false)
      })

    return () => { active = false }
  }, [userId])

  return { inventory, setInventory, loading }
}

/** Owned titles — player_artifacts joined to artifacts (migration 0096). */
function useOwnedTitles(userId: string | null) {
  const [titles, setTitles] = useState<OwnedTitle[]>([])
  const [loading, setLoading] = useState(true)
  const [tick, setTick] = useState(0)
  const refetch = useCallback(() => setTick(t => t + 1), [])

  useEffect(() => {
    if (!userId) { setTitles([]); setLoading(false); return }
    let active = true
    setLoading(true)

    supabase
      .from('player_artifacts')
      .select('artifact_id, is_equipped, unlocked_at, artifacts(name, media_url, tier)')
      .eq('user_id', userId)
      .then(({ data, error }) => {
        if (!active) return
        if (error) { console.error('titles fetch:', error); setLoading(false); return }
        setTitles((data ?? []).map((row: Record<string, unknown>) => {
          const a = row.artifacts as { name?: string; media_url?: string | null; tier?: string } | null
          return {
            artifact_id: row.artifact_id as string,
            name: a?.name ?? 'Title',
            tier: a?.tier ?? 'common',
            media_url: a?.media_url ?? null,
            is_equipped: !!row.is_equipped,
            unlocked_at: (row.unlocked_at as string | null) ?? null,
          }
        }))
        setLoading(false)
      })

    return () => { active = false }
  }, [userId, tick])

  return { titles, setTitles, loading, refetch }
}

/**
 * Exploration energy. Refills server-side, so the only honest way to show
 * it is to ask the RPC — same call and same 60s refresh Exploration.tsx
 * uses, so the two screens never disagree.
 */
function useExplorationEnergy(userId: string | null) {
  const [energy, setEnergy] = useState<number | null>(null)

  useEffect(() => {
    if (!userId) { setEnergy(null); return }
    let active = true

    const refresh = async () => {
      const { data, error } = await supabase.rpc('get_exploration_energy', { p_user_id: userId })
      if (active && !error && typeof data === 'number') setEnergy(Math.round(data))
    }

    refresh()
    const iv = setInterval(refresh, 60_000)
    return () => { active = false; clearInterval(iv) }
  }, [userId])

  return energy
}

/* ══════════════════════════════════════════════════
   TOAST
══════════════════════════════════════════════════ */
interface ToastMsg { text: string; equipped: boolean }

function EquipToast({ msg, onDone }: { msg: ToastMsg; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 2800); return () => clearTimeout(t) }, [])
  return (
    <div style={{
      position: 'fixed', bottom: 90, left: '50%', transform: 'translateX(-50%)',
      zIndex: 20200, background: 'color-mix(in srgb, var(--nav) 94%, transparent)',
      border: `1px solid ${msg.equipped ? 'color-mix(in srgb, var(--accent) 40%, transparent)' : 'var(--border-strong)'}`,
      borderRadius: 14, padding: '11px 18px',
      display: 'flex', alignItems: 'center', gap: 9,
      boxShadow: 'var(--elev-raise)', backdropFilter: 'blur(12px)',
      animation: 'invFeedIn 0.25s ease-out both', whiteSpace: 'nowrap',
    }}>
      {msg.equipped
        ? <CheckCircle2 size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />
        : <CircleDashed size={14} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />}
      <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)' }}>{msg.text}</span>
    </div>
  )
}

/* ══════════════════════════════════════════════════
   SHARED BITS
══════════════════════════════════════════════════ */

/**
 * Thumbnail for any InvItem — image, video poster, consumable art or fallback.
 *
 * `fit` defaults to 'cover' for grid tiles, where a consistent square matters
 * more than seeing every pixel. The detail modal passes 'contain' so tall
 * avatar art isn't cropped to a letterbox strip.
 *
 * A percentage `size` needs aspectRatio rather than `height: 100%` — the
 * modal body is auto-height, so a percentage height there resolves to zero.
 */
function ItemThumb({ item, size, radius = 12, fit = 'cover' }: {
  item: InvItem
  size: number | string
  radius?: number
  fit?: 'cover' | 'contain'
}) {
  const color = RARITY_COLOR[item.rarity]
  const mallItem = item.source.kind === 'mall' ? item.source.entry.item : null
  const animated = mallItem?.animated_url ?? null
  const isConsumableArt = mallItem ? isConsumableIconCategory(mallItem.category) : false
  const relative = typeof size === 'string'

  const backdrop = `linear-gradient(135deg, ${color}20, ${color}08)`

  return (
    <div style={{
      width: size,
      height: relative ? undefined : size,
      aspectRatio: relative ? '1 / 1' : undefined,
      borderRadius: radius, flexShrink: 0,
      background: isConsumableArt
        ? undefined
        : item.imageUrl
        ? `url(${item.imageUrl}) center/${fit} no-repeat, ${backdrop}`
        : backdrop,
      border: `1px solid ${color}30`,
      display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    }}>
      {mallItem && isConsumableIconCategory(mallItem.category) ? (
        <ConsumableIcon category={mallItem.category} imageUrl={mallItem.image_url} style={{ width: '100%', height: '100%' }} />
      ) : !item.imageUrl && animated && /\.(mp4|webm)$/i.test(animated) ? (
        <video src={animated} muted playsInline preload="metadata"
          style={{ width: '100%', height: '100%', objectFit: fit }} />
      ) : !item.imageUrl ? (
        <Package size={relative ? 34 : 20} style={{ color: `${color}66` }} />
      ) : null}
    </div>
  )
}

function EquippedPill() {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 10.5, fontWeight: 800, padding: '5px 9px', borderRadius: 9,
      background: 'color-mix(in srgb, var(--accent) 18%, transparent)',
      border: '1px solid color-mix(in srgb, var(--accent) 35%, transparent)',
      color: 'var(--accent)', whiteSpace: 'nowrap',
    }}>
      Equipped <CheckCircle2 size={11} style={{ color: '#3ecf8e' }} />
    </span>
  )
}

/* ══════════════════════════════════════════════════
   HEADER
══════════════════════════════════════════════════ */
function InventoryHeader({ activeFilters, onOpenFilters }: {
  activeFilters: number
  onOpenFilters: () => void
}) {
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  const roundBtn: React.CSSProperties = {
    width: 44, height: 44, borderRadius: 14, flexShrink: 0, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'var(--surface)', border: '1px solid var(--border)',
    color: 'var(--text-dim)', position: 'relative',
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
      <p style={{ flex: 1, minWidth: 0, fontSize: 12.5, color: 'var(--text-muted)', margin: 0 }}>
        Manage your gear and build
      </p>

      <button
        type="button"
        onClick={(e) => { ripple(e); onOpenFilters() }}
        className="ripple-wrap"
        aria-label={activeFilters ? `Filters, ${activeFilters} active` : 'Filters'}
        style={{
          ...roundBtn,
          background: activeFilters ? 'color-mix(in srgb, var(--accent) 16%, transparent)' : 'var(--surface)',
          border: `1px solid ${activeFilters ? 'color-mix(in srgb, var(--accent) 45%, transparent)' : 'var(--border)'}`,
          color: activeFilters ? 'var(--accent)' : 'var(--text-dim)',
        }}
      >
        <Filter size={17} fill={activeFilters ? 'currentColor' : 'none'} />
        {activeFilters > 0 && (
          <span
            aria-hidden
            style={{
              position: 'absolute', top: 3, right: 3, width: 7, height: 7,
              borderRadius: '50%', background: 'var(--accent)',
              boxShadow: '0 0 0 2px var(--surface)',
            }}
          />
        )}
      </button>

      <div style={{ position: 'relative' }}>
        <button type="button" onClick={() => setMenuOpen(o => !o)} aria-label="More options" style={roundBtn}>
          <MoreHorizontal size={19} />
        </button>
        {menuOpen && (
          <>
            <div onClick={() => setMenuOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 40 }} />
            <div style={{
              position: 'absolute', top: 52, right: 0, zIndex: 41, minWidth: 176,
              background: 'var(--surface2)', border: '1px solid var(--border-strong)',
              borderRadius: 14, padding: 6, boxShadow: 'var(--elev-popover)',
            }}>
              <MenuRow icon={<Store size={15} />} label="Go to Mall" onTap={() => { setMenuOpen(false); navigate('/mall') }} />
              <MenuRow icon={<Network size={15} />} label="Battle deck" onTap={() => { setMenuOpen(false); navigate('/skill-tree') }} />
              <MenuRow icon={<Crown size={15} />} label="Artifacts" onTap={() => { setMenuOpen(false); navigate('/artifacts') }} />
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function MenuRow({ icon, label, onTap }: { icon: React.ReactNode; label: string; onTap: () => void }) {
  return (
    <button type="button" onClick={onTap} style={{
      display: 'flex', alignItems: 'center', gap: 10, width: '100%',
      padding: '10px 11px', borderRadius: 10, cursor: 'pointer',
      background: 'none', border: 'none', textAlign: 'left',
      fontSize: 13, fontWeight: 600, color: 'var(--text)',
    }}>
      <span style={{ display: 'flex', color: 'var(--text-dim)' }}>{icon}</span>
      {label}
    </button>
  )
}

/* ══════════════════════════════════════════════════
   PLAYER CARD
══════════════════════════════════════════════════ */
function PlayerCard({ name, level, xp, titleName, titleColor, energy }: {
  name: string
  level: number
  xp: number
  titleName: string | null
  titleColor: string
  /** Exploration energy, or null until the refill-aware RPC answers. */
  energy: number | null
}) {
  const { current, max } = getXpProgress(xp)
  const pct = Math.min(100, Math.round((current / max) * 100))

  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 20,
      padding: 16, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 14,
      boxShadow: 'var(--elev-raise-sm)',
    }}>
      {/* Level crest */}
      <div style={{
        width: 58, height: 66, flexShrink: 0, display: 'grid', placeItems: 'center',
        borderRadius: 14,
        background: 'linear-gradient(160deg, color-mix(in srgb, var(--accent) 26%, transparent), color-mix(in srgb, var(--accent) 6%, transparent))',
        border: '1px solid color-mix(in srgb, var(--accent) 40%, transparent)',
      }}>
        <span style={{ fontSize: 22, fontWeight: 900, color: 'var(--text)', lineHeight: 1 }}>{level}</span>
        <span style={{ fontSize: 8.5, fontWeight: 800, letterSpacing: 1, color: 'var(--accent)' }}>LEVEL</span>
      </div>

      {/* Identity + XP */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontSize: 17, fontWeight: 900, color: 'var(--text)', margin: 0,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {name}
        </p>
        <p style={{
          fontSize: 12.5, fontWeight: 700, color: titleName ? titleColor : 'var(--text-muted)',
          margin: '1px 0 7px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {titleName ?? 'No title equipped'}
        </p>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 5px' }}>
          {current.toLocaleString()} / {max.toLocaleString()} XP
        </p>
        <div style={{ height: 5, borderRadius: 3, background: 'var(--surface3)', overflow: 'hidden' }}>
          <div style={{
            width: `${pct}%`, height: '100%', borderRadius: 3,
            background: 'linear-gradient(90deg, var(--accent), var(--accent2))',
            transition: 'width 0.4s ease',
          }} />
        </div>
      </div>

      {/* Exploration energy — refills server-side, so this is a live figure. */}
      <div style={{ flexShrink: 0, textAlign: 'center', minWidth: 68 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
          <Zap size={16} style={{ color: '#f5c542' }} />
          <span style={{ fontSize: 20, fontWeight: 900, color: 'var(--text)', lineHeight: 1 }}>
            {energy ?? '—'}
          </span>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)' }}>
            /{MAX_ENERGY}
          </span>
        </div>
        <p style={{ fontSize: 9, fontWeight: 800, letterSpacing: 0.8, color: 'var(--text-muted)', margin: '3px 0 5px' }}>
          ENERGY
        </p>
        <div style={{ height: 4, borderRadius: 2, background: 'var(--surface3)', overflow: 'hidden' }}>
          <div style={{
            width: `${Math.min(100, ((energy ?? 0) / MAX_ENERGY) * 100)}%`, height: '100%',
            borderRadius: 2, background: '#f5c542', transition: 'width 0.4s ease',
          }} />
        </div>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════
   CURRENT LOADOUT
══════════════════════════════════════════════════ */
function LoadoutCard({
  avatarUrl, playerName, slots, effect, title, onTapSlot, onChangeAvatar, onTapEffect, onTapTitle,
}: {
  avatarUrl: string | null
  playerName: string
  /** Fixed length 3. */
  slots: (PvpCard | null)[]
  effect: InvItem | null
  title: InvItem | null
  onTapSlot: (slot: 1 | 2 | 3) => void
  onChangeAvatar: () => void
  onTapEffect: () => void
  onTapTitle: () => void
}) {
  return (
    <div style={{
      display: 'flex', flexWrap: 'wrap', gap: 16, marginBottom: 20, padding: 14,
      borderRadius: 20, background: 'var(--surface)',
      border: '1px solid color-mix(in srgb, var(--accent) 28%, transparent)',
      boxShadow: 'var(--elev-raise-sm)',
    }}>
      {/* Avatar */}
      <div style={{
        position: 'relative', flex: '1 1 190px', minWidth: 160, minHeight: 230,
        borderRadius: 14, overflow: 'hidden',
        background: avatarUrl
          ? `url(${avatarUrl}) center/cover`
          : 'linear-gradient(160deg, color-mix(in srgb, var(--accent) 14%, transparent), var(--surface2))',
        border: '1px solid var(--border)',
        display: 'grid', placeItems: 'center',
      }}>
        {!avatarUrl && (
          <span style={{ fontSize: 44, fontWeight: 900, color: 'color-mix(in srgb, var(--accent) 45%, transparent)' }}>
            {playerName.trim().charAt(0).toUpperCase() || '?'}
          </span>
        )}
        <button
          type="button"
          onClick={(e) => { ripple(e); onChangeAvatar() }}
          className="ripple-wrap"
          style={{
            position: 'absolute', left: 12, right: 12, bottom: 12,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            padding: '11px 0', borderRadius: 12, cursor: 'pointer',
            background: 'rgba(10,10,14,0.72)', backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255,255,255,0.14)',
            color: '#fff', fontSize: 13, fontWeight: 700,
          }}
        >
          <Pencil size={13} /> Change Avatar
        </button>
      </div>

      {/* Slots */}
      <div style={{ flex: '1 1 240px', minWidth: 210 }}>
        <p style={{
          fontSize: 10.5, fontWeight: 800, letterSpacing: 1.1, textTransform: 'uppercase',
          color: 'var(--text-muted)', margin: '2px 0 12px',
        }}>
          Current loadout
        </p>

        <SlotLabel>Skills</SlotLabel>
        <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
          {([1, 2, 3] as const).map(n => {
            const card = slots[n - 1]
            const color = card ? RARITY_COLOR[card.rarity] : 'var(--border-strong)'
            return (
              <button
                key={n}
                type="button"
                onClick={(e) => { ripple(e); onTapSlot(n) }}
                className="ripple-wrap"
                style={{
                  flex: 1, minWidth: 0, cursor: 'pointer', background: 'none',
                  border: 'none', padding: 0, textAlign: 'center',
                }}
              >
                <span style={{
                  display: 'grid', placeItems: 'center', width: '100%', aspectRatio: '1 / 1',
                  borderRadius: 13, position: 'relative', overflow: 'hidden',
                  background: card && card.image_url
                    ? `url(${card.image_url}) center/cover`
                    : card ? `linear-gradient(150deg, ${color}28, ${color}0a)` : 'var(--surface2)',
                  border: card ? `1.5px solid ${color}` : '1.5px dashed var(--border-strong)',
                }}>
                  {!card && <Plus size={20} style={{ color: 'var(--text-muted)' }} />}
                  {card && !card.image_url && <Swords size={20} style={{ color }} />}
                  {card && (
                    <span style={{
                      position: 'absolute', left: 4, bottom: 4,
                      fontSize: 8.5, fontWeight: 800, padding: '2px 5px', borderRadius: 6,
                      background: 'rgba(10,10,14,0.75)', color: '#fff',
                    }}>
                      Lv.{card.card_level}
                    </span>
                  )}
                </span>
                <span style={{
                  display: 'block', fontSize: 11, fontWeight: 700, marginTop: 6,
                  color: card ? 'var(--text)' : 'var(--text-muted)',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {card ? card.name : 'Empty'}
                </span>
              </button>
            )
          })}
        </div>

        <SlotLabel>Effect</SlotLabel>
        <LoadoutRow item={effect} emptyLabel="No effect equipped" onTap={onTapEffect} />

        <SlotLabel>Title</SlotLabel>
        <LoadoutRow item={title} emptyLabel="No title equipped" onTap={onTapTitle} />
      </div>
    </div>
  )
}

function SlotLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{
      fontSize: 10, fontWeight: 800, letterSpacing: 1, textTransform: 'uppercase',
      color: 'var(--text-muted)', margin: '0 0 8px',
    }}>
      {children}
    </p>
  )
}

function LoadoutRow({ item, emptyLabel, onTap }: {
  item: InvItem | null; emptyLabel: string; onTap: () => void
}) {
  return (
    <button
      type="button"
      onClick={(e) => { ripple(e); onTap() }}
      className="ripple-wrap"
      style={{
        display: 'flex', alignItems: 'center', gap: 11, width: '100%',
        padding: 0, marginBottom: 16, cursor: 'pointer',
        background: 'none', border: 'none', textAlign: 'left',
      }}
    >
      {item ? (
        <ItemThumb item={item} size={40} radius={10} />
      ) : (
        <span style={{
          width: 40, height: 40, borderRadius: 10, display: 'grid', placeItems: 'center',
          border: '1.5px dashed var(--border-strong)', flexShrink: 0,
        }}>
          <Plus size={16} style={{ color: 'var(--text-muted)' }} />
        </span>
      )}
      <span style={{ flex: 1, minWidth: 0 }}>
        <span style={{
          display: 'block', fontSize: 13.5, fontWeight: 700,
          color: item ? 'var(--text)' : 'var(--text-muted)',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {item ? item.name : emptyLabel}
        </span>
        {item && (
          <span style={{ display: 'block', fontSize: 11.5, fontWeight: 700, color: RARITY_COLOR[item.rarity] }}>
            {item.rarity}
          </span>
        )}
      </span>
      <ChevronRight size={16} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
    </button>
  )
}

/* ══════════════════════════════════════════════════
   CATEGORY TABS
══════════════════════════════════════════════════ */
function CategoryTabs({ value, counts, onChange }: {
  value: InvCategory | 'all'
  counts: Record<string, number>
  onChange: (c: InvCategory | 'all') => void
}) {
  const tabs: { id: InvCategory | 'all'; label: string }[] = [
    { id: 'all', label: 'All' },
    ...CATEGORIES,
  ]

  return (
    <div style={{
      display: 'flex', gap: 6, marginBottom: 16, padding: 5,
      borderRadius: 16, background: 'var(--surface2)', border: '1px solid var(--border)',
      overflowX: 'auto', scrollbarWidth: 'none',
    }}>
      {tabs.map(tab => {
        const selected = value === tab.id
        const count = tab.id === 'all' ? counts.all : counts[tab.id] ?? 0
        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onChange(tab.id)}
            aria-pressed={selected}
            style={{
              display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0,
              padding: '10px 15px', borderRadius: 12, cursor: 'pointer',
              fontSize: 13, fontWeight: 700, whiteSpace: 'nowrap',
              background: selected ? 'color-mix(in srgb, var(--accent) 20%, transparent)' : 'transparent',
              border: `1px solid ${selected ? 'color-mix(in srgb, var(--accent) 45%, transparent)' : 'transparent'}`,
              color: selected ? 'var(--accent)' : 'var(--text-muted)',
              transition: 'background 0.15s, color 0.15s, border-color 0.15s',
            }}
          >
            {tab.label}
            <span style={{ fontSize: 10.5, fontWeight: 800, opacity: 0.7 }}>{count}</span>
          </button>
        )
      })}
    </div>
  )
}

/* ══════════════════════════════════════════════════
   ITEM CARD
══════════════════════════════════════════════════ */
function ItemCard({ item, onTap }: { item: InvItem; onTap: () => void }) {
  const color = RARITY_COLOR[item.rarity]

  return (
    <div
      onClick={(e) => { ripple(e); onTap() }}
      className="ripple-wrap"
      style={{
        display: 'flex', gap: 12, padding: 12, borderRadius: 16, cursor: 'pointer',
        background: 'var(--surface)', position: 'relative',
        border: item.equipped
          ? '1.5px solid color-mix(in srgb, var(--accent) 45%, transparent)'
          : `1px solid ${item.rarity === 'Mythic' ? `${color}33` : 'var(--border)'}`,
        boxShadow: item.equipped ? '0 0 0 1px color-mix(in srgb, var(--accent) 12%, transparent)' : 'none',
        transition: 'border-color 0.2s, box-shadow 0.2s',
      }}
    >
      <ItemThumb item={item} size={72} />

      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6 }}>
          <p style={{
            flex: 1, minWidth: 0, fontSize: 14, fontWeight: 800, color: 'var(--text)',
            margin: 0, lineHeight: 1.25,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>
            {item.name}
          </p>
          {item.isNew && (
            <span style={{
              fontSize: 8.5, fontWeight: 800, letterSpacing: 0.5, padding: '2px 5px',
              borderRadius: 5, background: 'color-mix(in srgb, var(--accent) 20%, transparent)',
              color: 'var(--accent)', flexShrink: 0,
            }}>
              NEW
            </span>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color }}>{item.rarity}</span>
          {item.level !== null && (
            <span style={{ fontSize: 11.5, color: 'var(--text-muted)', marginLeft: 'auto' }}>
              Lv. {item.level}
            </span>
          )}
        </div>

        {item.meta && (
          <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '4px 0 0', lineHeight: 1.3 }}>
            {item.meta}
          </p>
        )}

        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-end', gap: 7, marginTop: 'auto', paddingTop: 8 }}>
          {item.upgradeable && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 3,
              fontSize: 10.5, fontWeight: 800, color: '#3ecf8e',
            }}>
              <ArrowUp size={11} /> Upgrade
            </span>
          )}
          {item.equipped
            ? <EquippedPill />
            : item.quantity > 1
            ? <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)' }}>x{item.quantity}</span>
            : <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)' }}>x{item.quantity}</span>}
        </div>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════
   DETAIL SHEET
══════════════════════════════════════════════════ */
function DetailModal({
  item, busy, activeUntil, userId, equippedVariantId, onEquip, onUnequip, onUse, onSlot, onRemoveFromSlot, currentSlot, onUpgrade, vouchers, onClose,
}: {
  item: InvItem
  busy: boolean
  activeUntil: string | null
  userId: string | null
  /** Which bought colour this item is currently wearing, null for its own. */
  equippedVariantId: string | null
  /** Passing a colour equips the item wearing it; null equips the original. */
  onEquip: (variant?: ItemVariant | null) => void
  onUnequip: () => void
  onUse: () => void
  onSlot: (slot: 1 | 2 | 3) => void
  /** Clears whichever quick slot this card currently sits in. No-op if it isn't slotted. */
  onRemoveFromSlot: () => void
  /** The quick slot (1-3) this skill card is currently assigned to, or null if it isn't slotted. */
  currentSlot: 1 | 2 | 3 | null
  onUpgrade: () => void
  vouchers: number
  onClose: () => void
}) {
  // Lock the page behind the modal while it's open. A fixed-position
  // overlay does not stop the page underneath from scrolling, which on
  // mobile reads as the modal drifting off-screen. Inner content still
  // scrolls via its own overflowY.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [])

  // Cooldown labels are computed fresh on every render from
  // cooldown_ends_at, so a plain re-render tick is all a live countdown
  // needs here — no refetch.
  const [, setTick] = useState(0)
  useEffect(() => {
    if (item.source.kind !== 'skill') return
    const id = setInterval(() => setTick(t => t + 1), 15_000)
    return () => clearInterval(id)
  }, [item.source.kind])

  const color = RARITY_COLOR[item.rarity]
  const mallItem = item.source.kind === 'mall' ? item.source.entry.item : null
  const manualConsumable = mallItem ? isManuallyUsable(mallItem) : false
  const autoConsumable = mallItem?.category === 'streak_freeze'
  // Regenerate and Quick Charge are stackable like the other xp_booster
  // consumables but apply from their own dedicated flow (the Regenerate
  // button on a dead profile; Quick Charge from a recharging card in the
  // attack sheet) rather than a generic "Use" here — see isManuallyUsable.
  const pvpUtilityConsumable = mallItem?.sub_category?.startsWith('PvP ') ?? false
  const description = mallItem?.description
    ?? (item.source.kind === 'skill' ? item.source.card.description : null)

  const categoryLabel = CATEGORIES.find(c => c.id === item.category)?.label ?? 'Item'

  // ── Bought colours for this item ──
  // Only the ones this player actually paid for are listed; the swatch
  // grid for buying more lives in the Mall, not here. Fetched per open
  // rather than with the whole inventory so a player with no variants at
  // all never pays for the queries.
  const [ownedVariants, setOwnedVariants] = useState<ItemVariant[]>([])
  useEffect(() => {
    if (!mallItem || !userId || !canHaveVariants(mallItem.category, mallItem.sub_category)) {
      setOwnedVariants([])
      return
    }
    let active = true
    Promise.all([fetchItemVariants(mallItem.id), fetchOwnedVariantIds(userId)])
      .then(([all, ownedIds]) => {
        if (active) setOwnedVariants(all.filter(v => ownedIds.has(v.id)))
      })
    return () => { active = false }
  }, [mallItem, userId])

  return (
    <div
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
      style={{
        position: 'fixed', inset: 0, zIndex: 20150,
        background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
      }}
    >
      <div style={{
        background: 'var(--surface)', borderRadius: 24, padding: 24,
        width: '100%', maxWidth: 340, maxHeight: '88vh', overflowY: 'auto',
        border: `1px solid ${item.equipped ? 'color-mix(in srgb, var(--accent) 30%, transparent)' : 'var(--border)'}`,
        boxShadow: 'var(--elev-popover)', position: 'relative',
        animation: 'invModalIn 0.22s cubic-bezier(0.34,1.56,0.64,1) both',
      }}>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          style={{
            position: 'absolute', top: 14, right: 14, width: 30, height: 30,
            borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none',
            cursor: 'pointer', display: 'grid', placeItems: 'center', color: 'var(--text-dim)',
          }}
        >
          <X size={13} />
        </button>

        <ItemThumb item={item} size="100%" radius={16} fit="contain" />

        <p style={{
          fontSize: 10, fontWeight: 800, letterSpacing: 1, textTransform: 'uppercase',
          color, textAlign: 'center', margin: '16px 0 6px',
        }}>
          {categoryLabel}
        </p>
        <p style={{ fontSize: 19, fontWeight: 800, textAlign: 'center', color: 'var(--text)', margin: '0 0 6px' }}>
          {item.name}
        </p>
        <p style={{ textAlign: 'center', margin: '0 0 12px' }}>
          <span style={{ fontSize: 10, fontWeight: 700, padding: '3px 10px', borderRadius: 20, background: `${color}22`, color }}>
            {item.rarity}
          </span>
        </p>

        {description && (
          <p style={{ fontSize: 12.5, color: 'var(--text-dim)', textAlign: 'center', lineHeight: 1.6, margin: '0 0 16px' }}>
            {description}
          </p>
        )}

        {item.meta && (
          <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', margin: '0 0 14px' }}>
            {item.meta}
          </p>
        )}

        {item.source.kind === 'skill' && (() => {
          const recharging = formatCooldownRemaining(cardBlockedUntil(item.source.card))
          if (!recharging) return null
          return (
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              fontSize: 11.5, fontWeight: 700, color: '#ffb454',
              background: 'rgba(255,180,84,0.10)', border: '1px solid rgba(255,180,84,0.3)',
              borderRadius: 10, padding: '8px 10px', marginBottom: 14,
            }}>
              <Clock size={12} /> Recharging — ready in {recharging}
            </div>
          )
        })()}

        {mallItem?.is_consumable && (
          <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', margin: '0 0 14px' }}>
            Owned: <span style={{ color: 'var(--text)', fontWeight: 700 }}>x{item.quantity}</span>
          </p>
        )}

        {/* Actions */}
        {item.source.kind === 'skill' ? (
          <>
            <SlotLabel>{currentSlot ? `In slot ${currentSlot}` : 'Put in a slot'}</SlotLabel>
            {isAttackCard(item.source.card) ? (
              <>
                <div style={{ display: 'flex', gap: 8 }}>
                  {([1, 2, 3] as const).map(n => {
                    const active = currentSlot === n
                    return (
                      <button
                        key={n}
                        type="button"
                        onClick={(e) => { ripple(e); onSlot(n) }}
                        className="ripple-wrap"
                        disabled={busy}
                        style={{
                          flex: 1, padding: 13, borderRadius: 13, cursor: busy ? 'not-allowed' : 'pointer',
                          background: active ? 'color-mix(in srgb, var(--accent) 20%, transparent)' : 'var(--surface2)',
                          border: `1px solid ${active ? 'var(--accent)' : 'var(--border-strong)'}`,
                          color: active ? 'var(--accent)' : 'var(--text)', fontSize: 13.5, fontWeight: 800,
                        }}
                      >
                        {n}
                      </button>
                    )
                  })}
                </div>
                {currentSlot && (
                  <button
                    type="button"
                    onClick={(e) => { ripple(e); onRemoveFromSlot() }}
                    className="ripple-wrap"
                    disabled={busy}
                    style={{
                      width: '100%', marginTop: 8, padding: 11, borderRadius: 12,
                      cursor: busy ? 'not-allowed' : 'pointer', background: 'none',
                      border: '1px solid var(--border)', color: 'var(--text-muted)',
                      fontSize: 12.5, fontWeight: 700,
                    }}
                  >
                    Remove from slot {currentSlot}
                  </button>
                )}
              </>
            ) : (
              <p style={{
                fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.5, textAlign: 'center',
                padding: 13, borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)',
              }}>
                {item.source.card.card_kind === 'passive'
                  ? 'Works on its own while you own it — no slot needed.'
                  : 'Used on yourself in a fight, not from a slot.'}
              </p>
            )}

            <UpgradeSection card={item.source.card} vouchers={vouchers} busy={busy} onUpgrade={onUpgrade} />
          </>
        ) : manualConsumable ? (
          <>
            {activeUntil && (
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                fontSize: 11.5, fontWeight: 700, color: 'var(--text-dim)',
                background: 'var(--surface2)', borderRadius: 10, padding: '8px 10px', marginBottom: 10,
              }}>
                <Clock size={12} />
                Active until {new Date(activeUntil).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
              </div>
            )}
            <PrimaryButton
              busy={busy}
              onTap={onUse}
              icon={mallItem?.category === 'rank_shield' ? <Shield size={15} /> : <Zap size={15} />}
              label={busy ? 'Activating…' : activeUntil ? 'Use another' : 'Use'}
            />
          </>
        ) : autoConsumable ? (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            textAlign: 'center', padding: 13, borderRadius: 14,
            background: 'var(--surface2)', border: '1px solid var(--border)',
            fontSize: 12, color: 'var(--text-dim)', fontWeight: 600, lineHeight: 1.5,
          }}>
            <Snowflake size={15} style={{ color: '#6dd5ff', flexShrink: 0 }} />
            One freeze covers one missed day. Run out mid-gap and the streak still resets.
          </div>
        ) : pvpUtilityConsumable ? (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            textAlign: 'center', padding: 13, borderRadius: 14,
            background: 'var(--surface2)', border: '1px solid var(--border)',
            fontSize: 12, color: 'var(--text-dim)', fontWeight: 600, lineHeight: 1.5,
          }}>
            <Zap size={15} style={{ color: 'var(--accent)', flexShrink: 0 }} />
            {mallItem?.sub_category === 'PvP Quick Charge'
              ? "Used from a recharging card in the attack sheet — not from here."
              : 'Used from your profile while you\u2019re down — not from here.'}
          </div>
        ) : item.equipped ? (
          <button
            type="button"
            onClick={(e) => { ripple(e); onUnequip() }}
            className="ripple-wrap"
            disabled={busy}
            style={{
              width: '100%', padding: 13, borderRadius: 14, cursor: busy ? 'not-allowed' : 'pointer',
              border: '1px solid var(--border-strong)', background: 'var(--surface2)',
              color: 'var(--text-dim)', fontSize: 14, fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            }}
          >
            <CircleDashed size={15} /> Unequip
          </button>
        ) : (
          <PrimaryButton busy={busy} onTap={() => onEquip(null)} icon={<CheckCircle2 size={15} />} label="Equip" />
        )}

        {/* Colours bought for this item. The original always leads — a
            colour is an extra slot on the item, never a replacement, so
            switching back has to be one tap away. Tapping a colour equips
            the item wearing it, which is the same equip action with a
            different URL behind it. */}
        {ownedVariants.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <p style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.06em', color: 'var(--text-muted)', margin: '0 0 8px' }}>
              COLOURS
            </p>
            <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
              <VariantChip
                label="Original"
                imageUrl={mallItem?.image_url ?? null}
                active={item.equipped && equippedVariantId === null}
                busy={busy}
                onTap={() => onEquip(null)}
              />
              {ownedVariants.map(v => (
                <VariantChip
                  key={v.id}
                  label={v.name}
                  imageUrl={v.image_url}
                  active={item.equipped && equippedVariantId === v.id}
                  busy={busy}
                  onTap={() => onEquip(v)}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/** One colour in the detail modal's COLOURS strip. */
function VariantChip({ label, imageUrl, active, busy, onTap }: {
  label: string
  imageUrl: string | null
  active: boolean
  busy: boolean
  onTap: () => void
}) {
  return (
    <button
      type="button"
      disabled={busy}
      onClick={(e) => { ripple(e); onTap() }}
      className="ripple-wrap"
      style={{
        flexShrink: 0, width: 62, padding: 0, background: 'none', border: 'none',
        cursor: busy ? 'not-allowed' : 'pointer', textAlign: 'center', fontFamily: 'inherit',
      }}
    >
      <div style={{
        width: 62, height: 62, borderRadius: 13, overflow: 'hidden', background: 'var(--surface2)',
        border: active ? '2px solid var(--accent)' : '1px solid var(--border)',
        boxShadow: active ? '0 0 0 3px color-mix(in srgb, var(--accent) 16%, transparent)' : 'none',
      }}>
        {imageUrl && <img src={imageUrl} alt={label} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
      </div>
      <div style={{
        fontSize: 9.5, fontWeight: 700, marginTop: 4,
        color: active ? 'var(--accent)' : 'var(--text-muted)',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>
        {label}
      </div>
    </button>
  )
}

/**
 * Lets a player spend spare copies (+ Vouchers, where the card needs them)
 * to raise a skill card's level. Buying more copies in the Mall is what
 * fills the copy count this reads from — this button is where that
 * finally turns into a level.
 */
function UpgradeSection({ card, vouchers, busy, onUpgrade }: {
  card: PvpCard; vouchers: number; busy: boolean; onUpgrade: () => void
}) {
  const maxed = card.card_level >= card.max_level
  const copiesNeeded = 1 + card.upgrade_copies
  const hasCopies = card.copies >= copiesNeeded
  const hasVouchers = vouchers >= card.upgrade_vouchers
  const ready = !maxed && hasCopies && hasVouchers

  return (
    <div style={{ marginTop: 14 }}>
      <SlotLabel>Upgrade</SlotLabel>
      <div style={{
        borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)',
        padding: 13, display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>
            Level {card.card_level} <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>/ {card.max_level}</span>
          </span>
          <span style={{ fontSize: 11, color: hasCopies ? 'var(--text-dim)' : '#ff8095', fontWeight: 600 }}>
            {card.copies}/{copiesNeeded} copies
          </span>
        </div>

        {!maxed && card.upgrade_vouchers > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>Cost to upgrade</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: hasVouchers ? 'var(--text)' : '#ff8095' }}>
              {card.upgrade_vouchers.toLocaleString()} Vouchers
            </span>
          </div>
        )}

        {maxed ? (
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', textAlign: 'center', margin: 0 }}>
            Fully upgraded.
          </p>
        ) : (
          <button
            type="button"
            onClick={(e) => { ripple(e); onUpgrade() }}
            className="ripple-wrap"
            disabled={busy || !ready}
            style={{
              width: '100%', padding: 12, borderRadius: 12, border: 'none',
              cursor: busy || !ready ? 'not-allowed' : 'pointer',
              background: ready ? 'linear-gradient(135deg,#3ecf8e,#34a877)' : 'var(--surface3)',
              color: ready ? '#fff' : 'var(--text-dim)',
              fontSize: 13, fontWeight: 800,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            }}
          >
            <ArrowUp size={14} />
            {busy
              ? 'Upgrading…'
              : !hasCopies
              ? `Need ${copiesNeeded - card.copies} more cop${copiesNeeded - card.copies === 1 ? 'y' : 'ies'}`
              : !hasVouchers
              ? 'Not enough Vouchers'
              : `Upgrade to Lv ${card.card_level + 1}`}
          </button>
        )}
      </div>
    </div>
  )
}

function PrimaryButton({ busy, onTap, icon, label }: {
  busy: boolean; onTap: () => void; icon: React.ReactNode; label: string
}) {
  return (
    <button
      type="button"
      onClick={(e) => { ripple(e); onTap() }}
      className="ripple-wrap"
      disabled={busy}
      style={{
        width: '100%', padding: 13, borderRadius: 14, border: 'none',
        cursor: busy ? 'not-allowed' : 'pointer',
        background: busy ? 'var(--surface3)' : 'linear-gradient(135deg, var(--accent), var(--accent2))',
        color: busy ? 'var(--text-muted)' : '#fff', fontSize: 14, fontWeight: 800,
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
        boxShadow: busy ? 'none' : '0 4px 18px color-mix(in srgb, var(--accent) 35%, transparent)',
      }}
    >
      {icon} {label}
    </button>
  )
}

/* ══════════════════════════════════════════════════
   SLOT PICKER
══════════════════════════════════════════════════ */
function SlotPicker({ slot, cards, current, busy, onPick, onClose }: {
  slot: 1 | 2 | 3
  cards: PvpCard[]
  current: string | null
  busy: boolean
  onPick: (itemId: string | null) => void
  onClose: () => void
}) {
  // Lock the page behind the modal while it's open. A fixed-position
  // overlay does not stop the page underneath from scrolling, which on
  // mobile reads as the modal drifting off-screen. Inner content still
  // scrolls via its own overflowY.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [])

  return (
    <div
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
      style={{
        position: 'fixed', inset: 0, zIndex: 20150,
        background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
      }}
    >
      <div style={{
        background: 'var(--surface)', borderRadius: 24, padding: 22,
        width: '100%', maxWidth: 360, maxHeight: '80vh', overflowY: 'auto',
        border: '1px solid var(--border)', boxShadow: 'var(--elev-popover)',
        animation: 'invModalIn 0.22s cubic-bezier(0.34,1.56,0.64,1) both',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <h2 style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)', margin: 0 }}>Slot {slot}</h2>
          <button type="button" onClick={onClose} aria-label="Close"
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex' }}>
            <X size={18} />
          </button>
        </div>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', margin: '0 0 16px' }}>
          Pick the skill you want to reach in a fight.
        </p>

        {cards.length === 0 && (
          <p style={{
            fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center',
            padding: '26px 14px', border: '1px dashed var(--border-strong)', borderRadius: 14,
          }}>
            No attack skills yet. Pick some up in the Mall.
          </p>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {cards.map(card => {
            const color = RARITY_COLOR[card.rarity]
            const inSlot = current === card.item_id
            return (
              <button
                key={card.item_id}
                type="button"
                disabled={busy}
                onClick={(e) => { ripple(e); onPick(inSlot ? null : card.item_id) }}
                className="ripple-wrap"
                style={{
                  display: 'flex', alignItems: 'center', gap: 11, padding: '11px 13px',
                  borderRadius: 13, cursor: busy ? 'not-allowed' : 'pointer', width: '100%', textAlign: 'left',
                  border: inSlot ? `1.5px solid ${color}` : '1px solid var(--border)',
                  background: inSlot ? `linear-gradient(160deg, ${color}18, var(--surface))` : 'var(--surface2)',
                }}
              >
                <span style={{
                  width: 34, height: 34, borderRadius: 10, flexShrink: 0, display: 'grid', placeItems: 'center',
                  background: card.image_url ? `url(${card.image_url}) center/cover` : `${color}22`,
                  border: `1px solid ${color}44`,
                }}>
                  {!card.image_url && <Swords size={15} style={{ color }} />}
                </span>
                <span style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ display: 'block', fontSize: 13.5, fontWeight: 700, color: 'var(--text)' }}>{card.name}</span>
                  <span style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)' }}>
                    Lv {card.card_level} · {Math.round(card.current_damage)} dmg
                  </span>
                </span>
                {inSlot && <CheckCircle2 size={16} style={{ color, flexShrink: 0 }} />}
              </button>
            )
          })}
        </div>

        {current && (
          <button
            type="button"
            disabled={busy}
            onClick={(e) => { ripple(e); onPick(null) }}
            className="ripple-wrap"
            style={{
              width: '100%', marginTop: 14, padding: 12, borderRadius: 13,
              cursor: busy ? 'not-allowed' : 'pointer', background: 'var(--surface2)',
              border: '1px solid var(--border-strong)', color: 'var(--text-dim)',
              fontSize: 13.5, fontWeight: 700,
            }}
          >
            Clear slot {slot}
          </button>
        )}
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════
   PAGE
══════════════════════════════════════════════════ */
export default function Inventory() {
  usePageHeader({ title: 'Inventory' })
  const { session } = useAuth()
  const userId = session?.user?.id ?? null

  const { profile, refetch: refetchProfile } = useProfile()
  const { wallet, refetch: refetchWallet } = useWallet()
  const vouchers = wallet?.voucher_balance ?? 0
  const { inventory, setInventory, loading: invLoading } = useInventory(userId)
  const { owned: ownedCards, loading: cardsLoading, refetch: refetchCards } = usePvpCards()
  const { bySlot, loading: slotsLoading, refetch: refetchSlots } = useQuickSlots(userId)
  const { titles, setTitles, loading: titlesLoading } = useOwnedTitles(userId)
  const energy = useExplorationEnergy(userId)

  const [filters, setFilters] = useState<InvFilters>({ ...DEFAULT_FILTERS })
  const [sheetOpen, setSheetOpen] = useState(false)
  const [selected, setSelected] = useState<InvItem | null>(null)
  const [pickerSlot, setPickerSlot] = useState<1 | 2 | 3 | null>(null)
  const [toast, setToast] = useState<ToastMsg | null>(null)
  const [busy, setBusy] = useState(false)

  const loading = invLoading || cardsLoading || slotsLoading || titlesLoading

  /** ISO timestamp a manual boost is active until, or null. */
  const activeUntilFor = useCallback((item: MallItem): string | null => {
    const until =
      item.category === 'rank_shield' ? profile?.rank_shield_until :
      item.category === 'xp_booster' ? profile?.xp_booster_until :
      null
    return until && new Date(until) > new Date() ? until : null
  }, [profile])

  const slottedIds = useMemo(() => new Set(bySlot.filter(Boolean) as string[]), [bySlot])

  const items = useMemo(
    () => buildInventoryItems({ entries: inventory, cards: ownedCards, slottedIds, titles, activeUntilFor }),
    [inventory, ownedCards, slottedIds, titles, activeUntilFor],
  )

  const visible = useMemo(() => filterAndSortItems(items, filters), [items, filters])

  const counts = useMemo(() => {
    const out: Record<string, number> = { all: items.length }
    for (const c of CATEGORIES) out[c.id] = 0
    for (const item of items) out[item.category] = (out[item.category] ?? 0) + 1
    return out
  }, [items])

  /* ── Loadout summary ─────────────────────────────── */
  const slotCards = useMemo(
    () => bySlot.map(id => (id ? ownedCards.find(c => c.item_id === id) ?? null : null)),
    [bySlot, ownedCards],
  )
  const attackCards = useMemo(() => ownedCards.filter(isAttackCard), [ownedCards])
  const equippedEffect = useMemo(() => items.find(i => i.category === 'effects' && i.equipped) ?? null, [items])
  const equippedTitle = useMemo(() => items.find(i => i.category === 'titles' && i.equipped) ?? null, [items])

  /* ── Write paths ─────────────────────────────────── */

  /**
   * Equips an inventory row. `variant` is a bought colour of that same
   * item — passing null (the default) equips the item's original colour,
   * which is also what every pre-variant call site means. The colour only
   * changes which URL gets written to the profile; ownership, the equip
   * slot and everything else is still the item's.
   */
  const equipMall = useCallback(async (entry: InventoryEntry, variant: ItemVariant | null = null) => {
    const { item } = entry
    const wornUrl = variant?.image_url ?? item.image_url
    setInventory(prev => prev.map(e => ({
      ...e,
      is_equipped: equipSlot(e.item) === equipSlot(item) ? e.id === entry.id : e.is_equipped,
      equipped_variant_id: e.id === entry.id ? (variant?.id ?? null) : e.equipped_variant_id,
    })))
    setToast({ text: variant ? `Equipped ${item.name} · ${variant.name}` : `Equipped ${item.name}`, equipped: true })
    setSelected(null)

    const sameSlot = inventory
      .filter(e => equipSlot(e.item) === equipSlot(item) && e.is_equipped && e.id !== entry.id)
      .map(e => e.id)
    if (sameSlot.length) {
      await supabase.from('user_inventory').update({ is_equipped: false }).in('id', sameSlot)
    }
    await supabase.from('user_inventory')
      .update({ is_equipped: true, equipped_variant_id: variant?.id ?? null })
      .eq('id', entry.id)

    if (!userId) return
    if (item.sub_category === 'Profile card effect') {
      await supabase.from('profiles').update({ equipped_profile_effect_url: item.animated_url }).eq('id', userId)
    } else if (item.category === 'profile_pic' && item.sub_category !== 'album') {
      await supabase.from('profiles').update({ avatar: wornUrl ?? item.name }).eq('id', userId)
    } else if (item.category === 'avatar_skin') {
      await supabase.from('profiles').update({ equipped_avatar: wornUrl ?? item.name }).eq('id', userId)
    } else if (item.sub_category === 'album') {
      await supabase.from('profiles').update({ banner_url: wornUrl }).eq('id', userId)
    }

    if (item.category === 'avatar_skin') {
      updateMissionProgress(userId, 'avatar_equipped', 1).catch(console.error)
    } else if (item.category === 'profile_pic' && item.sub_category !== 'album') {
      updateMissionProgress(userId, 'profile_pic_changed', 1).catch(console.error)
    }

    refetchProfile()
  }, [inventory, setInventory, userId, refetchProfile])

  const unequipMall = useCallback(async (entry: InventoryEntry) => {
    const { item } = entry
    setInventory(prev => prev.map(e => (e.id === entry.id ? { ...e, is_equipped: false, equipped_variant_id: null } : e)))
    setToast({ text: `Unequipped ${item.name}`, equipped: false })
    setSelected(null)

    await supabase.from('user_inventory')
      .update({ is_equipped: false, equipped_variant_id: null })
      .eq('id', entry.id)

    if (!userId) return
    if (item.sub_category === 'Profile card effect') {
      await supabase.from('profiles').update({ equipped_profile_effect_url: null }).eq('id', userId)
    } else if (item.category === 'profile_pic' && item.sub_category !== 'album') {
      // 'rocket' is the "no avatar equipped" sentinel (DB default + what
      // Avatar.tsx treats as no src) — NOT a literal emoji glyph. Using an
      // actual emoji here made it render as-is instead of falling back to
      // the display-name initial.
      await supabase.from('profiles').update({ avatar: 'rocket' }).eq('id', userId)
    } else if (item.category === 'avatar_skin') {
      await supabase.from('profiles').update({ equipped_avatar: null }).eq('id', userId)
    } else if (item.sub_category === 'album') {
      await supabase.from('profiles').update({ banner_url: null }).eq('id', userId)
    }
    refetchProfile()
  }, [setInventory, userId, refetchProfile])

  const useConsumable = useCallback(async (entry: InventoryEntry) => {
    if (!userId || busy) return
    const { item } = entry
    setBusy(true)
    try {
      const { error } = await supabase.rpc('use_consumable', { p_user_id: userId, p_item_id: item.id })
      if (error) {
        setToast({
          text: error.message === 'not_owned' ? 'You no longer own this item.'
            : error.message === 'not_manually_usable' ? 'This one applies on its own.'
            : 'Could not use this item. Try again.',
          equipped: false,
        })
        return
      }
      setInventory(prev => prev
        .map(e => (e.id === entry.id ? { ...e, quantity: e.quantity - 1 } : e))
        .filter(e => e.quantity > 0))
      setToast({ text: `${item.name} activated!`, equipped: true })
      setSelected(null)
      refetchProfile()
    } finally {
      setBusy(false)
    }
  }, [userId, busy, setInventory, refetchProfile])

  const equipTitle = useCallback(async (artifactId: string, name: string) => {
    setBusy(true)
    try {
      const { error } = await supabase.rpc('set_equipped_artifact', { p_artifact_id: artifactId })
      if (error) { setToast({ text: 'Could not equip that title.', equipped: false }); return }
      setTitles(prev => prev.map(t => ({ ...t, is_equipped: t.artifact_id === artifactId })))
      setToast({ text: `Equipped ${name}`, equipped: true })
      setSelected(null)
    } finally {
      setBusy(false)
    }
  }, [setTitles])

  const unequipTitle = useCallback(async (name: string) => {
    setBusy(true)
    try {
      const { error } = await supabase.rpc('unequip_artifact')
      if (error) { setToast({ text: 'Could not unequip that title.', equipped: false }); return }
      setTitles(prev => prev.map(t => ({ ...t, is_equipped: false })))
      setToast({ text: `Unequipped ${name}`, equipped: false })
      setSelected(null)
    } finally {
      setBusy(false)
    }
  }, [setTitles])

  const assignSlot = useCallback(async (slot: 1 | 2 | 3, itemId: string | null) => {
    if (busy) return
    setBusy(true)
    try {
      await setQuickSlot(slot, itemId)
      refetchSlots()
      refetchCards()
      setToast({
        text: itemId ? `Slot ${slot} updated` : `Slot ${slot} cleared`,
        equipped: !!itemId,
      })
      setPickerSlot(null)
      setSelected(null)
    } catch (e) {
      setToast({ text: pvpErrorMessage(e), equipped: false })
    } finally {
      setBusy(false)
    }
  }, [busy, refetchSlots, refetchCards])

  /** Consumes copies (and Vouchers, per-card) to raise a skill card's level. */
  const upgradeSkill = useCallback(async (card: PvpCard) => {
    if (busy) return
    setBusy(true)
    try {
      const newLevel = await upgradeCard(card.item_id)
      refetchCards()
      refetchWallet()
      setToast({ text: `${card.name} is now Lv ${newLevel}`, equipped: true })
      setSelected(prev =>
        prev && prev.source.kind === 'skill' && prev.source.card.item_id === card.item_id
          ? {
              ...prev,
              level: newLevel,
              source: {
                kind: 'skill',
                card: {
                  ...prev.source.card,
                  card_level: newLevel,
                  copies: prev.source.card.copies - prev.source.card.upgrade_copies,
                },
              },
            }
          : prev
      )
    } catch (e) {
      setToast({ text: pvpErrorMessage(e), equipped: false })
    } finally {
      setBusy(false)
    }
  }, [busy, refetchCards, refetchWallet])

  /** Routes a tapped item's primary action to the right backend. */
  function handleEquip(item: InvItem, variant: ItemVariant | null = null) {
    if (item.source.kind === 'mall') equipMall(item.source.entry, variant)
    else if (item.source.kind === 'title') equipTitle(item.source.title.artifact_id, item.name)
  }
  function handleUnequip(item: InvItem) {
    if (item.source.kind === 'mall') unequipMall(item.source.entry)
    else if (item.source.kind === 'title') unequipTitle(item.name)
  }

  function jumpTo(category: InvCategory) {
    setFilters(f => ({ ...f, category }))
    document.getElementById('inv-grid')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  /**
   * Tapping a loadout slot used to always open the slot picker. A filled
   * slot now opens the same detail modal the grid uses instead — recharge
   * time, copies owned and the Voucher cost to upgrade — so a player can
   * check a card without leaving it. An empty slot still opens the picker,
   * since there's nothing to show details for.
   */
  function handleTapSlot(slot: 1 | 2 | 3) {
    const card = slotCards[slot - 1]
    if (!card) { setPickerSlot(slot); return }
    const invItem = items.find(i => i.source.kind === 'skill' && i.source.card.item_id === card.item_id)
    if (invItem) setSelected(invItem)
    else setPickerSlot(slot)
  }

  const displayName = profile?.display_name || profile?.username || 'Player'
  const avatarUrl = profile?.equipped_avatar?.startsWith('http')
    ? profile.equipped_avatar
    : profile?.avatar?.startsWith('http')
    ? profile.avatar
    : null

  const selectedActiveUntil = selected?.source.kind === 'mall'
    ? activeUntilFor(selected.source.entry.item)
    : null

  /** Which quick slot (1-3) the selected skill card currently occupies, if any. */
  const selectedSlot = useMemo(() => {
    if (selected?.source.kind !== 'skill') return null
    const idx = bySlot.indexOf(selected.source.card.item_id)
    return idx === -1 ? null : ((idx + 1) as 1 | 2 | 3)
  }, [selected, bySlot])

  return (
    <>
      <style>{`
        @keyframes invFeedIn {
          from { opacity:0; transform: translateX(-50%) translateY(12px) }
          to   { opacity:1; transform: translateX(-50%) translateY(0) }
        }
        @keyframes invModalIn {
          from { opacity:0; transform: scale(0.88) }
          to   { opacity:1; transform: scale(1) }
        }
      `}</style>

      <div style={{ maxWidth: 760, margin: '0 auto', paddingBottom: 40 }}>
        <InventoryHeader
          activeFilters={countActiveFilters(filters)}
          onOpenFilters={() => setSheetOpen(true)}
        />

        <PlayerCard
          name={displayName}
          level={profile?.level ?? 1}
          xp={profile?.xp ?? 0}
          titleName={equippedTitle?.name ?? null}
          titleColor={equippedTitle ? RARITY_COLOR[equippedTitle.rarity] : 'var(--text-muted)'}
          energy={energy}
        />

        <LoadoutCard
          avatarUrl={avatarUrl}
          playerName={displayName}
          slots={slotCards}
          effect={equippedEffect}
          title={equippedTitle}
          onTapSlot={handleTapSlot}
          onChangeAvatar={() => jumpTo('avatars')}
          onTapEffect={() => (equippedEffect ? setSelected(equippedEffect) : jumpTo('effects'))}
          onTapTitle={() => (equippedTitle ? setSelected(equippedTitle) : jumpTo('titles'))}
        />

        <div id="inv-grid" style={{ scrollMarginTop: 16 }}>
          <CategoryTabs
            value={filters.category}
            counts={counts}
            onChange={category => setFilters(f => ({ ...f, category }))}
          />

          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
              <span style={{
                width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
                borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
              }} />
            </div>
          ) : visible.length === 0 ? (
            <div style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
              padding: '56px 20px', textAlign: 'center',
            }}>
              <Package size={38} style={{ opacity: 0.2 }} />
              <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-dim)', margin: 0 }}>
                {items.length === 0 ? 'Your inventory is empty' : 'Nothing matches these filters'}
              </p>
              <p style={{ fontSize: 12.5, color: 'var(--text-muted)', margin: 0 }}>
                {items.length === 0
                  ? 'Head to the Mall to pick up some items.'
                  : 'Try widening the category or rarity.'}
              </p>
              {items.length > 0 && (
                <button
                  type="button"
                  onClick={() => setFilters({ ...DEFAULT_FILTERS })}
                  style={{
                    marginTop: 4, padding: '10px 20px', borderRadius: 12, cursor: 'pointer',
                    background: 'var(--surface2)', border: '1px solid var(--border-strong)',
                    color: 'var(--text)', fontSize: 13, fontWeight: 700,
                  }}
                >
                  Clear filters
                </button>
              )}
            </div>
          ) : (
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12,
            }}>
              {visible.map(item => (
                <ItemCard key={item.key} item={item} onTap={() => setSelected(item)} />
              ))}
            </div>
          )}

          {!loading && visible.length > 0 && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 12, marginTop: 26,
              fontSize: 12, fontWeight: 600, color: 'var(--text-muted)',
            }}>
              <span style={{ flex: 1, height: 1, background: 'var(--border)' }} />
              {visible.length} item{visible.length === 1 ? '' : 's'}
              <span style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            </div>
          )}
        </div>
      </div>

      {sheetOpen && (
        <InventoryFilterSheet
          filters={filters}
          onApply={setFilters}
          onClose={() => setSheetOpen(false)}
        />
      )}

      {pickerSlot && (
        <SlotPicker
          slot={pickerSlot}
          cards={attackCards}
          current={bySlot[pickerSlot - 1]}
          busy={busy}
          onPick={itemId => assignSlot(pickerSlot, itemId)}
          onClose={() => setPickerSlot(null)}
        />
      )}

      {selected && (
        <DetailModal
          item={selected}
          busy={busy}
          activeUntil={selectedActiveUntil}
          userId={userId}
          equippedVariantId={selected.source.kind === 'mall' ? (selected.source.entry.equipped_variant_id ?? null) : null}
          onEquip={(variant) => handleEquip(selected, variant)}
          onUnequip={() => handleUnequip(selected)}
          onUse={() => selected.source.kind === 'mall' && useConsumable(selected.source.entry)}
          onSlot={slot => selected.source.kind === 'skill' && assignSlot(slot, selected.source.card.item_id)}
          onRemoveFromSlot={() => selectedSlot && assignSlot(selectedSlot, null)}
          currentSlot={selectedSlot}
          onUpgrade={() => selected.source.kind === 'skill' && upgradeSkill(selected.source.card)}
          vouchers={vouchers}
          onClose={() => setSelected(null)}
        />
      )}

      {toast && <EquipToast msg={toast} onDone={() => setToast(null)} />}
    </>
  )
}
