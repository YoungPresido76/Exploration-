// src/features/economy/useMallNewItemsBadge.ts
//
// Powers the dot on the Dashboard's "Mall" quick-action tile — the top of
// the badge cascade described in useMallNewBadges.ts. Dashboard doesn't
// load the full item catalog, so unlike the in-Mall dots (computed
// client-side from items already in memory) this one goes through the
// has_new_mall_items() RPC (migration 0169b). Same shape as
// useChatUnreadBadge.ts: recheck on mount/visibility/realtime INSERT,
// and recompute (not blindly clear) on a 'mall' badge-seen event, since
// viewing one item doesn't guarantee no other new item remains.
import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { useBadgeSeen } from '../../shared/lib/badgeBus'

export function useMallNewItemsBadge(): boolean {
  const { user } = useAuth()
  const [hasNew, setHasNew] = useState(false)

  const recheck = useCallback(() => {
    if (!user) { setHasNew(false); return }
    supabase.rpc('has_new_mall_items').then(({ data, error }) => {
      if (!error) setHasNew(!!data)
    })
  }, [user])

  useEffect(() => { recheck() }, [recheck])

  // A view row written anywhere in this tab (any Mall item sheet closing)
  // re-runs the real check rather than assuming the whole badge clears —
  // there may still be other new stock elsewhere in the catalog.
  useBadgeSeen('mall', recheck)

  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') recheck() }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [recheck])

  useEffect(() => {
    if (!user) return
    const ch = supabase
      .channel('mall-new-items-badge')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'mall_items' }, recheck)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [user, recheck])

  return hasNew
}
