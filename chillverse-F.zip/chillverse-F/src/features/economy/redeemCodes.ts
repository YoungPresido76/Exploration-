// src/features/economy/redeemCodes.ts
//
// Client API for the Redeem Code system. Every call here is a thin wrapper
// around a SECURITY DEFINER RPC (migration 0114_redeem_codes_system) — the
// three underlying tables (redeem_codes, redeem_code_redemptions,
// redeem_code_attempts) have RLS enabled with no policies, so nothing here
// can be bypassed by talking to the tables directly.
import { supabase } from '../../shared/lib/supabase'
import { isPending } from '../admin/adminRequests'

function friendlyRedeemError(message: string): string {
  if (message.includes('CV_ADMIN_FORBIDDEN')) return "You don't have permission to do that."
  if (message.includes('CV_ADMIN_NOT_FOUND')) return 'Not found.'
  if (message.includes('CV_ADMIN_VALIDATION')) return message.split(': ').slice(1).join(': ') || 'Invalid input.'
  if (message.includes('CV_REDEEM_AUTH')) return 'Please sign in to redeem a code.'
  return message
}

// ── Player-facing ──────────────────────────────────────────────────────

export type RedeemFailureReason =
  | 'invalid' | 'expired' | 'not_active_yet' | 'used_up' | 'already_redeemed' | 'already_owned'

export interface RedeemSuccessResult {
  success: true
  reward_type: 'currency' | 'item'
  currency_type: 'diamonds' | 'orbs' | 'vouchers' | null
  currency_amount: number | null
  item_id: string | null
  item_name: string | null
  item_category: string | null
  item_image_url: string | null
  stackable: boolean
}

export interface RedeemFailureResult {
  success: false
  reason: RedeemFailureReason
}

export type RedeemResult = RedeemSuccessResult | RedeemFailureResult

/** Redeems a code for the signed-in user. Never throws for expected outcomes
 *  (invalid/expired/used-up/etc.) — those come back as {success:false, reason}.
 *  A thrown error here means something unexpected happened (network, auth). */
export async function redeemCode(codeInput: string): Promise<{ data: RedeemResult | null; error: string | null }> {
  const { data, error } = await supabase.rpc('redeem_code', { p_code_input: codeInput })
  if (error) return { data: null, error: friendlyRedeemError(error.message) }
  return { data: data as RedeemResult, error: null }
}

export const REDEEM_TOAST_MESSAGE: Record<RedeemFailureReason, string> = {
  invalid: 'Invalid code. Please check and try again.',
  not_active_yet: "This code isn't active yet.",
  expired: 'This code has expired.',
  used_up: 'This code has already been fully claimed.',
  already_redeemed: "You've already redeemed this code.",
  already_owned: 'You already own this item — try another code.',
}

// ── Admin: create / list / manage ────────────────────────────────────────

export interface AdminRedeemCode {
  id: string
  code: string
  reward_type: 'currency' | 'item'
  currency_type: 'diamonds' | 'orbs' | 'vouchers' | null
  currency_amount: number | null
  item_id: string | null
  item_name: string | null
  item_image_url: string | null
  max_redemptions: number | null
  redemption_count: number
  active_from: string | null
  expires_at: string | null
  is_active: boolean
  source: 'auto' | 'manual'
  created_at: string
}

export interface CreateRedeemCodeInput {
  autoGenerate: boolean
  code?: string
  codeLength?: number
  rewardType: 'currency' | 'item'
  currencyType?: 'diamonds' | 'orbs' | 'vouchers'
  currencyAmount?: number
  itemId?: string
  maxRedemptions?: number | null
  activeFrom?: string | null
  expiresAt?: string | null
}

export async function adminCreateRedeemCode(
  input: CreateRedeemCodeInput,
): Promise<{ data: { id: string; code: string } | null; pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_create_redeem_code', {
    p_auto_generate: input.autoGenerate,
    p_code: input.code ?? null,
    p_code_length: input.codeLength ?? 5,
    p_reward_type: input.rewardType,
    p_currency_type: input.currencyType ?? null,
    p_currency_amount: input.currencyAmount ?? null,
    p_item_id: input.itemId ?? null,
    p_max_redemptions: input.maxRedemptions ?? null,
    p_active_from: input.activeFrom ?? null,
    p_expires_at: input.expiresAt ?? null,
  })
  if (error) return { data: null, pending: false, error: friendlyRedeemError(error.message) }
  // Non-owner admins queue the code for approval instead of minting it
  // (migration 0160b) — there is no code to show yet.
  if (isPending(data)) return { data: null, pending: true, error: null }
  return { data: data as { id: string; code: string }, pending: false, error: null }
}

export async function adminListRedeemCodes(query?: string): Promise<{ data: AdminRedeemCode[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_list_redeem_codes', { p_query: query ?? null })
  if (error) return { data: [], error: friendlyRedeemError(error.message) }
  return { data: (data ?? []) as AdminRedeemCode[], error: null }
}

export async function adminSetRedeemCodeActive(id: string, active: boolean): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_set_redeem_code_active', { p_id: id, p_active: active })
  if (error) return { pending: false, error: friendlyRedeemError(error.message) }
  return { pending: isPending(data), error: null }
}

/** Permanently deletes a code. Only allowed when it has never been redeemed
 *  (redemption_count === 0) — the server enforces this too. For a code with
 *  redemption history, deactivate it instead so the audit trail stays intact. */
export async function adminDeleteRedeemCode(id: string): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_delete_redeem_code', { p_id: id })
  if (error) return { pending: false, error: friendlyRedeemError(error.message) }
  return { pending: isPending(data), error: null }
}

export interface RedeemCodeRedemptionRow {
  user_id: string
  username: string
  redeemed_at: string
}

export async function adminListRedeemCodeRedemptions(
  codeId: string,
): Promise<{ data: RedeemCodeRedemptionRow[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_list_redeem_code_redemptions', { p_code_id: codeId })
  if (error) return { data: [], error: friendlyRedeemError(error.message) }
  return { data: (data ?? []) as RedeemCodeRedemptionRow[], error: null }
}

// ── Item search composer (mall item picker for item-reward codes) ───────
// Mirrors adminOps.ts's searchMallItems — kept local so this file has no
// dependency on the admin ops module for a single shared shape.
export interface RedeemMallItemOption {
  id: string
  name: string
  image_url: string | null
  category: string
}

export async function searchRedeemMallItems(query: string): Promise<{ data: RedeemMallItemOption[]; error: string | null }> {
  if (!query.trim()) return { data: [], error: null }
  const { data, error } = await supabase
    .from('mall_items')
    .select('id, name, image_url, category')
    .eq('is_active', true)
    .ilike('name', `%${query.trim()}%`)
    .order('name')
    .limit(8)
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as RedeemMallItemOption[], error: null }
}

// ── Staff: suspicious activity (mod + admin) ─────────────────────────────

export interface SuspiciousRedeemActivityRow {
  user_id: string
  username: string
  failed_count: number
  attempted_codes: string[]
  last_attempt_at: string
}

export async function listSuspiciousRedeemActivity(
  windowMinutes = 15,
  threshold = 5,
): Promise<{ data: SuspiciousRedeemActivityRow[]; error: string | null }> {
  const { data, error } = await supabase.rpc('list_suspicious_redeem_activity', {
    p_window_minutes: windowMinutes,
    p_threshold: threshold,
  })
  if (error) return { data: [], error: friendlyRedeemError(error.message) }
  return { data: (data ?? []) as SuspiciousRedeemActivityRow[], error: null }
}
