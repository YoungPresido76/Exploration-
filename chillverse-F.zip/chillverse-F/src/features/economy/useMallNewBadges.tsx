// src/features/economy/useMallNewBadges.ts
//
// Backs the Mall's "new item" dot cascade: Dashboard's Mall tile lights up
// -> opening the Mall shows a dot on whichever category tile(s) hold the
// new stock -> opening that category shows a dot on the specific new
// item(s) -> opening an item's sheet clears its own dot, and clears every
// ancestor (category, then Dashboard) the moment nothing new remains
// underneath it. There's no separate "clear the whole category" action —
// every level's dot is just a live aggregate over the same per-item state,
// so it can't get out of sync with itself.
//
// Definition of "new": item.created_at is within the last NEW_ITEM_WINDOW_DAYS
// AND the user has no mall_item_views row for it yet (see migration
// 0169a). The recency half of that exists so an item that's been sitting
// in the Mall for months doesn't light up forever just because a
// particular user has never happened to open it — the dot means "added
// since you last looked", not "exists and you haven't looked", and
// without the recency bound those are the same thing for anyone who
// rarely visits the Mall.
import { useCallback, useEffect, useMemo, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import type { MallItem } from '../../shared/types'
import { emitBadgeSeen } from '../../shared/lib/badgeBus'

const NEW_ITEM_WINDOW_DAYS = 14

function isRecent(item: MallItem): boolean {
  const ageMs = Date.now() - new Date(item.created_at).getTime()
  return ageMs <= NEW_ITEM_WINDOW_DAYS * 24 * 60 * 60 * 1000
}

interface UseMallNewBadges {
  /** True if this specific item should show a dot right now. */
  isNew: (item: MallItem) => boolean
  /** True if any item in this list should show a dot — for a category
   *  header or "Shop All" pill, pass that category's full item list (not
   *  just the preview slice), so a new item outside the first few
   *  preview cards still lights the category up. */
  hasNew: (categoryItems: MallItem[]) => boolean
  /** Call the moment an item's detail sheet opens. Optimistic locally
   *  (the dot disappears immediately) with a fire-and-forget write to
   *  mall_item_views; a failed write just means the dot can reappear on
   *  next load, which is a far better failure mode than the dot getting
   *  stuck lit forever on a transient network error. */
  markViewed: (itemId: string) => void
}

export function useMallNewBadges(userId: string | null): UseMallNewBadges {
  const [viewedIds, setViewedIds] = useState<Set<string>>(new Set())

  useEffect(() => {
    if (!userId) { setViewedIds(new Set()); return }
    let active = true
    supabase
      .from('mall_item_views')
      .select('item_id')
      .then(({ data }) => {
        if (!active || !data) return
        setViewedIds(new Set(data.map(r => r.item_id as string)))
      })
    return () => { active = false }
  }, [userId])

  const isNew = useCallback((item: MallItem): boolean => {
    if (!userId) return false
    return isRecent(item) && !viewedIds.has(item.id)
  }, [userId, viewedIds])

  const hasNew = useCallback((categoryItems: MallItem[]): boolean => {
    return categoryItems.some(isNew)
  }, [isNew])

  const markViewed = useCallback((itemId: string) => {
    if (!userId || viewedIds.has(itemId)) return
    // Optimistic: the dot for this item (and, on next render, any ancestor
    // whose last new item this was) clears immediately.
    setViewedIds(prev => new Set(prev).add(itemId))
    // Tells the Dashboard tile's badge (which can't see this item list) to
    // re-run its own has_new_mall_items() check rather than waiting for a
    // remount — see useMallNewItemsBadge.ts.
    emitBadgeSeen('mall')
    supabase
      .from('mall_item_views')
      .upsert({ user_id: userId, item_id: itemId }, { onConflict: 'user_id,item_id', ignoreDuplicates: true })
      .then(({ error }) => {
        if (error) {
          console.error('Failed to record mall_item_views row — this item\'s dot may reappear on next load:', error.message)
        }
      })
  }, [userId, viewedIds])

  return useMemo(() => ({ isNew, hasNew, markViewed }), [isNew, hasNew, markViewed])
}

/** Small dot badge — same visual language as .dock-center-dot (BottomDock.tsx),
 *  just positioned as an absolute corner overlay instead of docked next to an
 *  icon, since it needs to sit on top of item art and category tiles rather
 *  than beside a nav icon. */
export function NewDot({ style }: { style?: React.CSSProperties } = {}) {
  return (
    <span
      aria-label="New"
      style={{
        position: 'absolute', top: -3, right: -3, width: 10, height: 10, borderRadius: '50%',
        background: '#ff4d6d', border: '2px solid var(--surface)', boxShadow: '0 0 0 1px rgba(0,0,0,0.15)',
        ...style,
      }}
    />
  )
}
