// src/features/economy/useDiamondPurchase.ts
//
// The Paystack checkout + credit-diamonds flow, extracted out of
// BuyDiamonds.tsx so any surface that sells a diamond pack or a flash-sale
// item can trigger a real purchase instead of just linking over to
// /buy-diamonds. Used by BuyDiamonds.tsx (regular packs + its embedded
// flash-sale rows) and by the Game Zone flash-sale modal (GamesZone.tsx).
import { useEffect, useRef, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { checkAndAwardAutoBadges } from '../badges/badges'
import { updateMissionProgress } from '../missions/weeklyMissions'

declare global {
  interface Window {
    PaystackPop?: {
      setup: (opts: Record<string, unknown>) => { openIframe: () => void }
    }
  }
}

export type PurchaseModalKind = 'success' | 'cancelled' | 'error'

/** Anything with an id/diamonds/price that can be bought this way — a
 *  regular Pack (priceCents) or a flash-sale item (sale_price_cents). */
export interface PurchasableItem {
  id: string
  diamonds: number
  priceCents?: number
  sale_price_cents?: number
}

export function getPurchasePriceCents(item: PurchasableItem): number {
  return item.priceCents ?? item.sale_price_cents ?? 0
}

/** Loads the Paystack inline script once per app load (idempotent — safe to
 *  call from multiple mounted components). */
export function useLoadPaystackScript() {
  const loaded = useRef(false)
  useEffect(() => {
    if (loaded.current || document.querySelector('script[src*="paystack"]')) {
      loaded.current = true
      return
    }
    const script = document.createElement('script')
    script.src = 'https://js.paystack.co/v1/inline.js'
    script.async = true
    script.onload = () => { loaded.current = true }
    document.head.appendChild(script)
  }, [])
}

/** Whether the signed-in user's very first pack should get the double-
 *  diamonds bonus — same check BuyDiamonds.tsx's hero banner uses. */
export function useIsFirstPurchase(): boolean {
  const { user } = useAuth()
  const [isFirstPurchase, setIsFirstPurchase] = useState(false)
  useEffect(() => {
    if (!user) return
    supabase
      .from('user_wallets')
      .select('first_purchase_claimed')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setIsFirstPurchase(!data.first_purchase_claimed)
      })
  }, [user])
  return isFirstPurchase
}

export function useDiamondPurchase() {
  const { user, session } = useAuth()
  useLoadPaystackScript()

  const [loading, setLoading] = useState(false)
  const [modal, setModal] = useState<PurchaseModalKind | null>(null)
  const [activeItem, setActiveItem] = useState<PurchasableItem | null>(null)
  const lastOpts = useRef<{ isFirstPurchase?: boolean; missionKey?: string } | undefined>(undefined)

  function purchase(item: PurchasableItem, opts?: { isFirstPurchase?: boolean; missionKey?: string }) {
    lastOpts.current = opts
    if (!session?.user?.email || !user) return
    if (!window.PaystackPop) {
      alert('Payment system loading, please try again in a second.')
      return
    }

    const ref = `cv_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`

    const handler = window.PaystackPop.setup({
      key: import.meta.env.VITE_PAYSTACK_PUBLIC_KEY as string,
      email: session.user.email,
      amount: getPurchasePriceCents(item),
      currency: 'NGN',
      ref,
      metadata: {
        user_id: user.id,
        pack_id: item.id,
        diamonds: item.diamonds,
        is_first_purchase: !!opts?.isFirstPurchase,
      },
      callback: function (response: { reference: string }) {
        // Paystack's inline.js (v1) rejects async functions for `callback`
        // (its validator checks the function's shape, and async functions
        // don't pass). Keep this wrapper synchronous and run the actual
        // async work in an inner IIFE.
        setLoading(true)
        ;(async () => {
          try {
            const { error } = await supabase.functions.invoke('credit-diamonds', {
              body: { reference: response.reference, user_id: user.id },
            })
            if (error) throw error
            setActiveItem(item)
            checkAndAwardAutoBadges(user.id)
            if (opts?.missionKey) {
              updateMissionProgress(user.id, opts.missionKey, 1).catch(console.error)
            }
            setModal('success')
          } catch (err) {
            console.error('credit-diamonds error:', err)
            // Payment confirmed by Paystack but crediting failed.
            // Show error so user knows to contact support — do NOT silently
            // show success, as that leaves them with missing diamonds.
            setActiveItem(item)
            setModal('error')
          } finally {
            setLoading(false)
          }
        })()
      },
      onClose: () => {
        setActiveItem(item)
        setModal('cancelled')
      },
    })

    handler.openIframe()
  }

  function retry() {
    setModal(null)
    if (activeItem) {
      const item = activeItem
      const opts = lastOpts.current
      setTimeout(() => purchase(item, opts), 100)
    }
  }

  function closeModal() {
    setModal(null)
  }

  return { loading, modal, activeItem, purchase, retry, closeModal }
}
