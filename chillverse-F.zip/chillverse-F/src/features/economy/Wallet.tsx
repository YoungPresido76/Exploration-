// src/pages/Wallet.tsx
import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Clock, ShoppingBag, Ticket, Play, Loader2, Gift, CheckCircle2, XCircle } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { useWallet } from './useWallet'
import { useWatchAdForOrbs } from '../ads/useWatchAdForOrbs'
import RedeemCodeModal from './RedeemCodeModal'
import Toast, { useToast } from '../../shared/components/Toast'

// ─── Types ────────────────────────────────────────────────────
interface DiamondTx {
  id: string
  created_at: string
  amount: number          // positive = credit, negative = debit
  description: string
  pack_id?: string | null
}

interface OrbTx {
  id: string
  created_at: string
  amount: number          // positive = credit, negative = debit
  description: string
  source?: string | null
}

interface VoucherTx {
  id: string
  created_at: string
  amount: number          // positive = earned, negative = spent
  description: string
  source?: string | null
}

// ─── Helpers ──────────────────────────────────────────────────
function fmt(n: number) { return n.toLocaleString() }
function relTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  if (d < 7) return `${d}d ago`
  return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
}

// ─── Currency Card ────────────────────────────────────────────
function CurrencyCard({
  icon,
  label,
  amount,
  sub,
  accent,
  bg,
  border,
}: {
  icon: React.ReactNode
  label: string
  amount: string
  sub: string
  accent: string
  bg: string
  border: string
}) {
  return (
    <div
      style={{
        flex: 1,
        minWidth: 0,
        background: bg,
        border: `1px solid ${border}`,
        borderRadius: 18,
        padding: '16px 14px',
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
        boxShadow: 'var(--elev-raise-sm)',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
        <span style={{ color: accent, display: 'flex', alignItems: 'center' }}>{icon}</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.7px' }}>{label}</span>
      </div>
      <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--text)', lineHeight: 1.1 }}>{amount}</div>
      <div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>{sub}</div>
    </div>
  )
}

// ─── Orb Icon (SVG inline) ────────────────────────────────────
function OrbIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="5" fill="#34d399" opacity="0.9" />
      <circle cx="12" cy="12" r="9" stroke="#34d399" strokeWidth="1.2" opacity="0.35" fill="none" />
      <circle cx="17.5" cy="12" r="2" fill="#34d399" opacity="0.7" />
    </svg>
  )
}

// ─── Voucher Icon (SVG inline, smaller) ───────────────────────
function VoucherIcon({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="2" y="6" width="20" height="12" rx="3" stroke="#f0c060" strokeWidth="1.5" fill="none" />
      <circle cx="7" cy="12" r="2" fill="#f0c060" opacity="0.8" />
      <line x1="11" y1="9" x2="19" y2="9" stroke="#f0c060" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
      <line x1="11" y1="12" x2="17" y2="12" stroke="#f0c060" strokeWidth="1.2" strokeLinecap="round" opacity="0.4" />
    </svg>
  )
}

// ─── Transaction Row ──────────────────────────────────────────
function TxRow({
  icon,
  label,
  sub,
  amount,
  amountColor,
}: {
  icon: React.ReactNode
  label: string
  sub: string
  amount: string
  amountColor: string
}) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 0',
      borderBottom: '1px solid var(--border)',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 11,
        background: 'var(--surface2)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
      }}>
        {icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', marginBottom: 2 }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{sub}</div>
      </div>
      <div style={{ fontSize: 13.5, fontWeight: 700, color: amountColor, flexShrink: 0 }}>{amount}</div>
    </div>
  )
}

// ─── Section Header ───────────────────────────────────────────
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 10, marginTop: 28 }}>
      {children}
    </p>
  )
}

// ─── Empty State ──────────────────────────────────────────────
function EmptyState({ label }: { label: string }) {
  return (
    <div style={{ padding: '26px 0', textAlign: 'center' }}>
      <Clock size={24} style={{ color: 'var(--text-muted)', margin: '0 auto 8px', display: 'block' }} />
      <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{label}</p>
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────
export default function Wallet() {
  const navigate = useNavigate()
  // Preserves the page's original "always back to Dashboard" behavior
  // (this page can be reached from several places, e.g. the Wallet row in
  // Settings), rather than the default browser-back.
  usePageHeader({ title: 'Wallet', onBack: () => navigate('/dashboard') })
  const [searchParams] = useSearchParams()
  const { user } = useAuth()
  const { wallet, loading: walletLoading, refetch: refetchWallet } = useWallet()
  const watchAd = useWatchAdForOrbs(() => refetchWallet())

  // Redeem code modal + a bump counter to re-trigger the tx history fetches below
  const [redeemOpen, setRedeemOpen] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)
  const { toast, showToast } = useToast()

  // Diamond transaction history
  const [diamondTxs, setDiamondTxs] = useState<DiamondTx[]>([])
  const [txLoading, setTxLoading] = useState(true)

  // Orb transaction history (ad rewards, mall spends, etc.)
  const [orbTxs, setOrbTxs] = useState<OrbTx[]>([])
  const [orbTxLoading, setOrbTxLoading] = useState(true)

  // Voucher transaction history (PvP rewards, card upgrade spends)
  const [voucherTxs, setVoucherTxs] = useState<VoucherTx[]>([])
  const [voucherTxLoading, setVoucherTxLoading] = useState(true)

  // Active tab: 'diamonds' | 'orbs' | 'vouchers' — deep-linkable via ?tab=orbs
  // (used by the Dashboard's "Missions" card).
  const initialTab = searchParams.get('tab')
  const [activeTab, setActiveTab] = useState<'diamonds' | 'orbs' | 'vouchers'>(
    initialTab === 'orbs' || initialTab === 'vouchers' ? initialTab : 'diamonds',
  )

  useEffect(() => {
    if (!user) return
    setTxLoading(true)
    ;(async () => {
      try {
        const { data } = await supabase
          .from('diamond_transactions')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(30)
        setDiamondTxs((data as DiamondTx[]) ?? [])
      } catch {
        // table may not exist yet
      } finally {
        setTxLoading(false)
      }
    })()
  }, [user, refreshKey])

  useEffect(() => {
    if (!user) return
    setOrbTxLoading(true)
    ;(async () => {
      try {
        const { data } = await supabase
          .from('orb_transactions')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(40)
        setOrbTxs((data as OrbTx[]) ?? [])
      } catch {
        // table may not exist yet
      } finally {
        setOrbTxLoading(false)
      }
    })()
  }, [user, refreshKey])

  useEffect(() => {
    if (!user) return
    setVoucherTxLoading(true)
    ;(async () => {
      try {
        const { data } = await supabase
          .from('voucher_transactions')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(40)
        setVoucherTxs((data as VoucherTx[]) ?? [])
      } catch {
        // table may not exist yet
      } finally {
        setVoucherTxLoading(false)
      }
    })()
  }, [user, refreshKey])

  const diamonds = wallet?.gem_balance ?? 0
  const orbs = wallet?.orb_balance ?? 0
  const vouchers = wallet?.voucher_balance ?? 0

  // Debit-only views for "spent" sections
  const diamondSpends = diamondTxs.filter(t => t.amount < 0)

  const tabs = [
    { key: 'diamonds' as const, label: '💎 Diamonds' },
    { key: 'orbs' as const, label: 'Orbs' },
    { key: 'vouchers' as const, label: 'Vouchers' },
  ]

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', paddingBottom: 56 }}>

      {/* ── Top bar ── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 20px', marginBottom: 24, paddingTop: 4 }}>
        <p style={{ flex: 1, fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>Your currencies &amp; spending history</p>
        <button
          type="button"
          onClick={(e) => { ripple(e); setRedeemOpen(true) }}
          aria-label="Redeem code"
          style={{
            width: 38, height: 38, borderRadius: 11,
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            boxShadow: 'var(--elev-raise-sm)',
            color: '#f0c060',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', flexShrink: 0,
          }}
        >
          <Gift size={17} />
        </button>
      </div>

      {redeemOpen && (
        <RedeemCodeModal
          onClose={() => setRedeemOpen(false)}
          onToast={(message, tone) => showToast({
            message,
            icon: tone === 'success' ? CheckCircle2 : XCircle,
            iconColor: tone === 'success' ? '#4ade80' : '#f87171',
          })}
          onRedeemed={() => { refetchWallet(); setRefreshKey(k => k + 1) }}
        />
      )}
      <Toast toast={toast} />

      {/* ── Currency Cards ── */}
      <div style={{ padding: '0 20px', marginBottom: 8 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          {/* Diamonds */}
          <CurrencyCard
            icon={<span style={{ fontSize: 16 }}>💎</span>}
            label="Diamonds"
            amount={walletLoading ? '—' : fmt(diamonds)}
            sub="Premium currency"
            accent="#4f8ef7"
            bg="rgba(79,142,247,0.07)"
            border="rgba(79,142,247,0.2)"
          />
          {/* Orbs */}
          <CurrencyCard
            icon={<OrbIcon size={16} />}
            label="Orbs"
            amount={walletLoading ? '—' : fmt(orbs)}
            sub="Earn by watching ads"
            accent="#34d399"
            bg="rgba(52,211,153,0.07)"
            border="rgba(52,211,153,0.18)"
          />
          {/* Vouchers — slightly smaller card */}
          <div
            style={{
              flex: '0 0 auto',
              width: 90,
              background: 'rgba(240,192,96,0.07)',
              border: '1px solid rgba(240,192,96,0.2)',
              borderRadius: 18,
              padding: '13px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: 5,
              boxShadow: 'var(--elev-raise-sm)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <VoucherIcon size={13} />
              <span style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px' }}>Vouchers</span>
            </div>
            <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text)', lineHeight: 1.1 }}>
              {walletLoading ? '—' : fmt(vouchers)}
            </div>
            <div style={{ fontSize: 9.5, color: 'var(--text-muted)' }}>Earned in PvP</div>
          </div>
        </div>

        {/* Buy more diamonds CTA */}
        <button
          type="button"
          onClick={(e) => { ripple(e); navigate('/buy-diamonds') }}
          className="ripple-wrap btn-primary"
          style={{ width: '100%', marginTop: 14, padding: '11px 0', borderRadius: 13, fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}
        >
          💎 Buy Diamonds
        </button>
      </div>

      {/* ── Tabs ── */}
      <div style={{ padding: '0 20px', marginTop: 28 }}>
        <div style={{ display: 'flex', gap: 6, background: 'var(--surface)', borderRadius: 14, padding: 4 }}>
          {tabs.map(t => (
            <button
              key={t.key}
              type="button"
              onClick={() => setActiveTab(t.key)}
              style={{
                flex: 1, padding: '8px 4px', borderRadius: 11,
                fontSize: 11.5, fontWeight: 700,
                background: activeTab === t.key ? 'var(--surface2)' : 'transparent',
                border: activeTab === t.key ? '1px solid rgba(255,255,255,0.08)' : '1px solid transparent',
                color: activeTab === t.key ? 'var(--text)' : 'var(--text-muted)',
                cursor: 'pointer', transition: 'background-color var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ─── TAB: DIAMONDS ─── */}
      {activeTab === 'diamonds' && (
        <div style={{ padding: '0 20px' }}>
          <SectionLabel>Diamond Purchases</SectionLabel>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 18, padding: '0 16px', boxShadow: 'var(--elev-raise-sm)' }}>
            {txLoading ? (
              <div style={{ padding: '24px 0', textAlign: 'center' }}>
                <div style={{ width: 20, height: 20, border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto' }} />
              </div>
            ) : diamondTxs.filter(t => t.amount > 0).length === 0 ? (
              <EmptyState label="No diamond purchases yet" />
            ) : (
              diamondTxs.filter(t => t.amount > 0).map(tx => (
                <TxRow
                  key={tx.id}
                  icon={<span style={{ fontSize: 15 }}>💎</span>}
                  label={tx.description || 'Diamond Top-up'}
                  sub={relTime(tx.created_at)}
                  amount={`+${fmt(tx.amount)} 💎`}
                  amountColor="#3ecf8e"
                />
              ))
            )}
          </div>

          <SectionLabel>Spent on Items</SectionLabel>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 18, padding: '0 16px', boxShadow: 'var(--elev-raise-sm)' }}>
            {txLoading ? (
              <div style={{ padding: '24px 0', textAlign: 'center' }}>
                <div style={{ width: 20, height: 20, border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto' }} />
              </div>
            ) : diamondSpends.length === 0 ? (
              <EmptyState label="No spending history yet" />
            ) : (
              diamondSpends.map(tx => (
                <TxRow
                  key={tx.id}
                  icon={<ShoppingBag size={14} style={{ color: 'var(--text-dim)' }} />}
                  label={tx.description || 'Mall purchase'}
                  sub={relTime(tx.created_at)}
                  amount={`${fmt(tx.amount)} 💎`}
                  amountColor="#ff6b6b"
                />
              ))
            )}
          </div>
        </div>
      )}

      {/* ─── TAB: ORBS ─── */}
      {activeTab === 'orbs' && (
        <div style={{ padding: '0 20px' }}>
          <SectionLabel>Missions</SectionLabel>
          <div style={{
            background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 18,
            padding: 16, boxShadow: 'var(--elev-raise-sm)', display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12, flexShrink: 0,
              background: 'rgba(52,211,153,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <OrbIcon size={20} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)' }}>Watch an ad</div>
              <div style={{
                fontSize: 11.5, marginTop: 2,
                color: watchAd.status === 'coming_soon' ? '#f5c542' : 'var(--text-muted)',
              }}>
                {watchAd.status === 'playing'
                  ? watchAd.secondsRemaining !== null
                    ? `Watching… ${watchAd.secondsRemaining}s left, keep this tab open`
                    : 'Loading ad…'
                  : watchAd.status === 'success'
                    ? `+${watchAd.orbsEarned} Orbs credited!`
                    : watchAd.status === 'coming_soon'
                      ? (watchAd.errorMessage ?? 'This update is coming sooner than you think — stay tuned!')
                      : watchAd.status === 'error' || watchAd.status === 'capped'
                        ? watchAd.errorMessage
                        : 'Earn 15 Orbs, up to 10 times a day'}
              </div>
            </div>
            <button
              type="button"
              disabled={watchAd.status === 'loading_ticket' || watchAd.status === 'playing' || watchAd.status === 'crediting'}
              onClick={(e) => { ripple(e); watchAd.status === 'success' || watchAd.status === 'error' ? watchAd.reset() : watchAd.watchAd() }}
              className="ripple-wrap btn-primary"
              style={{
                flexShrink: 0, padding: '9px 16px', borderRadius: 12, fontSize: 12.5, fontWeight: 700,
                display: 'flex', alignItems: 'center', gap: 6,
                opacity: (watchAd.status === 'loading_ticket' || watchAd.status === 'playing' || watchAd.status === 'crediting') ? 0.6 : 1,
                cursor: (watchAd.status === 'loading_ticket' || watchAd.status === 'playing' || watchAd.status === 'crediting') ? 'default' : 'pointer',
              }}
            >
              {watchAd.status === 'playing' ? (
                <><Loader2 size={13} style={{ animation: 'spin 0.8s linear infinite' }} /> {watchAd.secondsRemaining !== null ? `${watchAd.secondsRemaining}s` : '…'}</>
              ) : watchAd.status === 'loading_ticket' || watchAd.status === 'crediting' ? (
                <><Loader2 size={13} style={{ animation: 'spin 0.8s linear infinite' }} /> Loading</>
              ) : watchAd.status === 'success' ? (
                'Done'
              ) : watchAd.status === 'capped' ? (
                'Come back later'
              ) : watchAd.status === 'coming_soon' ? (
                'Coming Soon'
              ) : (
                <><Play size={13} /> Watch</>
              )}
            </button>
          </div>

          <SectionLabel>Orb Activity</SectionLabel>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 18, padding: '0 16px', boxShadow: 'var(--elev-raise-sm)' }}>
            {orbTxLoading ? (
              <div style={{ padding: '24px 0', textAlign: 'center' }}>
                <div style={{ width: 20, height: 20, border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto' }} />
              </div>
            ) : orbTxs.length === 0 ? (
              <div style={{ padding: '36px 0', textAlign: 'center' }}>
                <OrbIcon size={28} />
                <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 10, fontWeight: 600 }}>No Orb activity yet</p>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>Watch an ad above to earn your first Orbs</p>
              </div>
            ) : (
              orbTxs.map(tx => (
                <TxRow
                  key={tx.id}
                  icon={<OrbIcon size={15} />}
                  label={tx.description || (tx.amount > 0 ? 'Orbs earned' : 'Orbs spent')}
                  sub={relTime(tx.created_at)}
                  amount={`${tx.amount > 0 ? '+' : ''}${fmt(tx.amount)} Orbs`}
                  amountColor={tx.amount > 0 ? '#3ecf8e' : '#ff6b6b'}
                />
              ))
            )}
          </div>
        </div>
      )}

      {/* ─── TAB: VOUCHERS ─── */}
      {activeTab === 'vouchers' && (
        <div style={{ padding: '0 20px' }}>
          <SectionLabel>Voucher Activity</SectionLabel>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 18, padding: '0 16px', boxShadow: 'var(--elev-raise-sm)' }}>
            {voucherTxLoading ? (
              <div style={{ padding: '24px 0', textAlign: 'center' }}>
                <div style={{ width: 20, height: 20, border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto' }} />
              </div>
            ) : voucherTxs.length === 0 ? (
              <div style={{ padding: '36px 0', textAlign: 'center' }}>
                <Ticket size={26} style={{ color: '#f0c060', margin: '0 auto', display: 'block' }} />
                <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 10, fontWeight: 600 }}>No Voucher activity yet</p>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>Win PvP battles to earn Vouchers, spend them on card upgrades</p>
              </div>
            ) : (
              voucherTxs.map(tx => (
                <TxRow
                  key={tx.id}
                  icon={<VoucherIcon size={15} />}
                  label={tx.description || (tx.amount > 0 ? 'Vouchers earned' : 'Vouchers spent')}
                  sub={relTime(tx.created_at)}
                  amount={`${tx.amount > 0 ? '+' : ''}${fmt(tx.amount)}`}
                  amountColor={tx.amount > 0 ? '#3ecf8e' : '#ff6b6b'}
                />
              ))
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  )
}
