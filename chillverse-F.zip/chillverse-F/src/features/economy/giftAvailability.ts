// src/features/economy/giftAvailability.ts
//
// Whether a wishlist row can still be gifted. SendGiftModal already
// re-resolves the live mall_items row before charging and refuses on an
// inactive item, but by then the gift page is open and the player has
// already committed a tap — so the same rules are applied up front here
// and the tap just toasts instead.
//
// The wishlist table only snapshots item_id/name/image, so availability
// has to be looked up against mall_items. wishlist.item_id is a text
// column and older rows can hold something that isn't a real item id, so
// anything that isn't a UUID is left alone and falls through to
// SendGiftModal's name-based lookup exactly as before.

import { supabase } from '../../shared/lib/supabase'

/** Toast copy for a wishlist item that can't be gifted any more. Matches
 *  the 'unavailable' case in giftResultMessage() so both paths read the
 *  same to the player. */
export const GIFT_UNAVAILABLE_MESSAGE = 'This item is no longer available'

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

/**
 * Given the item ids on a wishlist, returns the subset that can no longer
 * be gifted — pulled off the shelf, admin-locked, past its limited-time
 * window, deleted outright, or with no diamond price (gifting always
 * charges diamonds, so a price-less item has nothing to charge).
 *
 * Pro/XP gates are deliberately NOT treated as unavailable: those are
 * gates on the person buying for themselves, and gifting one is how a
 * player gets an item they couldn't unlock alone.
 */
export async function fetchUngiftableItemIds(itemIds: (string | null)[]): Promise<Set<string>> {
  const ids = [...new Set(itemIds.filter((id): id is string => !!id && UUID_RE.test(id)))]
  const blocked = new Set<string>()
  if (ids.length === 0) return blocked

  const { data, error } = await supabase
    .from('mall_items')
    .select('id, is_active, is_locked, available_until, price_gems')
    .in('id', ids)
  // On a network failure, block nothing — SendGiftModal still refuses an
  // unavailable item, so the worst case is the old behaviour.
  if (error) return blocked

  const now = Date.now()
  const seen = new Set<string>()
  for (const row of data ?? []) {
    seen.add(row.id)
    const ended = row.available_until != null && new Date(row.available_until).getTime() <= now
    if (!row.is_active || row.is_locked || ended || row.price_gems == null) blocked.add(row.id)
  }
  // An id that came back with no row at all is a deleted item.
  for (const id of ids) if (!seen.has(id)) blocked.add(id)

  return blocked
}
