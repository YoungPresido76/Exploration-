// src/features/economy/InventoryFilterSheet.tsx
//
// Opened by the funnel button in the Inventory header. Edits a *draft* of
// the filters and only hands them back on "Apply Filters", so half-made
// selections never flicker the grid behind the sheet.
import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, SlidersHorizontal, ArrowUp, Star, Circle, Filter } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import {
  CATEGORIES, RARITIES, RARITY_COLOR, SORT_LABELS, DEFAULT_FILTERS,
  countActiveFilters,
  type InvFilters, type InvSort,
} from './inventoryModel'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

const SHEET_MAX_VH = 88
const WIDE_BREAKPOINT = 640

export default function InventoryFilterSheet({
  filters, onApply, onClose,
}: {
  filters: InvFilters
  onApply: (next: InvFilters) => void
  onClose: () => void
}) {
  const [draft, setDraft] = useState<InvFilters>(filters)
  const [visible, setVisible] = useState(false)
  const [isWide, setIsWide] = useState(
    () => typeof window !== 'undefined' && window.innerWidth >= WIDE_BREAKPOINT,
  )

  // Lock the page behind the sheet while it's open. A fixed-position
  // overlay does not stop the page underneath from scrolling, which on
  // mobile reads as the sheet drifting off-screen. Inner content still
  // scrolls via its own overflowY.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [])

  useEffect(() => { requestAnimationFrame(() => setVisible(true)) }, [])
  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= WIDE_BREAKPOINT) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  function close() { setVisible(false); setTimeout(onClose, 260) }

  // Drag-to-dismiss from anywhere inside the sheet (not just the grab
  // pill) — engages only when the content under the finger is already
  // scrolled to the top, so the body still scrolls normally.
  // See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(close)
  function apply() { onApply(draft); close() }

  const activeCount = countActiveFilters(draft)

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 20100,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        opacity: visible ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        role="dialog"
        aria-label="Filter inventory"
        style={{
          width: isWide ? 'min(92vw, 460px)' : '100%',
          maxHeight: `${SHEET_MAX_VH}vh`,
          borderRadius: '20px 20px 0 0',
          marginTop: 'auto',
          overflowY: 'auto',
          background: 'var(--surface2)',
          padding: '10px 20px 24px',
          boxShadow: '0 -12px 40px -12px var(--sh)',
          transform: visible ? `translateY(${dragY}px)` : 'translateY(100%)',
          transition: dragging ? 'none' : 'transform 0.32s cubic-bezier(0.32,0.72,0,1)',
          position: 'relative',
        }}
      >
        {/* Grabber */}
        <div style={{
          width: 42, height: 4, borderRadius: 3, background: 'var(--border-strong)',
          margin: '0 auto 16px',
        }} />

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
          <h2 style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
            Filter Inventory
          </h2>
          <button
            type="button"
            onClick={close}
            aria-label="Close filters"
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--text-muted)', display: 'flex', padding: 4,
            }}
          >
            <X size={19} />
          </button>
        </div>

        {/* Category */}
        <SectionLabel>Category</SectionLabel>
        <ChipRow>
          <Chip
            label="All"
            selected={draft.category === 'all'}
            onTap={() => setDraft(d => ({ ...d, category: 'all' }))}
          />
          {CATEGORIES.map(c => (
            <Chip
              key={c.id}
              label={c.label}
              selected={draft.category === c.id}
              onTap={() => setDraft(d => ({ ...d, category: c.id }))}
            />
          ))}
        </ChipRow>

        {/* Rarity */}
        <SectionLabel>Rarity</SectionLabel>
        <ChipRow>
          <Chip
            label="All"
            selected={draft.rarity === 'all'}
            onTap={() => setDraft(d => ({ ...d, rarity: 'all' }))}
          />
          {RARITIES.map(r => (
            <Chip
              key={r}
              label={r}
              color={RARITY_COLOR[r]}
              selected={draft.rarity === r}
              onTap={() => setDraft(d => ({ ...d, rarity: r }))}
            />
          ))}
        </ChipRow>

        {/* Status */}
        <SectionLabel>Status</SectionLabel>
        <ChipRow>
          <Chip label="All"        selected={draft.status === 'all'}        onTap={() => setDraft(d => ({ ...d, status: 'all' }))} />
          <Chip label="Equipped"   selected={draft.status === 'equipped'}   onTap={() => setDraft(d => ({ ...d, status: 'equipped' }))} />
          <Chip label="Unequipped" selected={draft.status === 'unequipped'} onTap={() => setDraft(d => ({ ...d, status: 'unequipped' }))} />
        </ChipRow>

        {/* Special */}
        <SectionLabel>Special</SectionLabel>
        <ChipRow>
          <Chip label="All" selected={draft.special === 'all'} onTap={() => setDraft(d => ({ ...d, special: 'all' }))} />
          <Chip
            label="Ready to use"
            color="#4f8ef7"
            icon={<Circle size={9} fill="#4f8ef7" strokeWidth={0} />}
            selected={draft.special === 'ready'}
            onTap={() => setDraft(d => ({ ...d, special: 'ready' }))}
          />
          <Chip
            label="Upgradeable"
            color="#3ecf8e"
            icon={<ArrowUp size={12} />}
            selected={draft.special === 'upgradeable'}
            onTap={() => setDraft(d => ({ ...d, special: 'upgradeable' }))}
          />
          <Chip
            label="New"
            color="var(--accent)"
            icon={<Star size={12} />}
            selected={draft.special === 'new'}
            onTap={() => setDraft(d => ({ ...d, special: 'new' }))}
          />
        </ChipRow>

        {/* Sort */}
        <SectionLabel>Sort by</SectionLabel>
        <div style={{
          position: 'relative', display: 'flex', alignItems: 'center', gap: 10,
          padding: '0 14px', height: 50, marginBottom: 24,
          borderRadius: 14, background: 'var(--surface)', border: '1px solid var(--border-strong)',
        }}>
          <SlidersHorizontal size={15} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>
            {SORT_LABELS[draft.sort]}
          </span>
          <select
            value={draft.sort}
            aria-label="Sort by"
            onChange={e => setDraft(d => ({ ...d, sort: e.target.value as InvSort }))}
            style={{
              position: 'absolute', inset: 0, width: '100%', height: '100%',
              opacity: 0, cursor: 'pointer', border: 'none', appearance: 'none',
            }}
          >
            {(Object.keys(SORT_LABELS) as InvSort[]).map(s => (
              <option key={s} value={s}>{SORT_LABELS[s]}</option>
            ))}
          </select>
          <span style={{
            marginLeft: 'auto', color: 'var(--text-muted)', fontSize: 11, pointerEvents: 'none',
          }}>
            ▾
          </span>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 12 }}>
          <button
            type="button"
            onClick={(e) => { ripple(e); setDraft({ ...DEFAULT_FILTERS }) }}
            className="ripple-wrap"
            style={{
              flex: 1, height: 52, borderRadius: 15, cursor: 'pointer',
              background: 'var(--surface)', border: '1px solid var(--border-strong)',
              color: 'var(--text-dim)', fontSize: 15, fontWeight: 700,
            }}
          >
            Reset
          </button>
          <button
            type="button"
            onClick={(e) => { ripple(e); apply() }}
            className="ripple-wrap"
            style={{
              flex: 1.4, height: 52, borderRadius: 15, cursor: 'pointer', border: 'none',
              background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
              color: '#fff', fontSize: 15, fontWeight: 800,
              boxShadow: '0 4px 18px color-mix(in srgb, var(--accent) 35%, transparent)',
            }}
          >
            Apply Filters
          </button>
        </div>

        {/* Live count */}
        <div style={{
          marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
          fontSize: 12.5, fontWeight: 700,
          color: activeCount > 0 ? 'var(--accent)' : 'var(--text-muted)',
        }}>
          <Filter size={13} />
          {activeCount === 0
            ? 'No filters active'
            : `${activeCount} filter${activeCount === 1 ? '' : 's'} active`}
        </div>
      </div>
    </div>,
    document.body,
  )
}

/* ── Bits ────────────────────────────────────────────────────────── */

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{
      fontSize: 10.5, fontWeight: 800, letterSpacing: 1.1, textTransform: 'uppercase',
      color: 'var(--text-muted)', margin: '0 0 10px',
    }}>
      {children}
    </p>
  )
}

function ChipRow({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, marginBottom: 24 }}>
      {children}
    </div>
  )
}

function Chip({ label, selected, onTap, color, icon }: {
  label: string
  selected: boolean
  onTap: () => void
  /** Rarity/status tint. Falls back to the theme accent when selected. */
  color?: string
  icon?: React.ReactNode
}) {
  const tint = color ?? 'var(--accent)'
  return (
    <button
      type="button"
      onClick={onTap}
      aria-pressed={selected}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '11px 17px', borderRadius: 13, cursor: 'pointer',
        fontSize: 13.5, fontWeight: 700, lineHeight: 1,
        background: selected
          ? (color ? `color-mix(in srgb, ${tint} 22%, transparent)` : 'var(--accent)')
          : 'var(--surface)',
        border: `1px solid ${selected || color ? `color-mix(in srgb, ${tint} ${selected ? 65 : 32}%, transparent)` : 'var(--border-strong)'}`,
        color: selected
          ? (color ? tint : '#fff')
          : (color ? tint : 'var(--text-dim)'),
        transition: 'background 0.15s, border-color 0.15s, color 0.15s',
      }}
    >
      {icon}
      {label}
    </button>
  )
}
