// src/pages/BuyDiamonds.tsx
import { useNavigate } from 'react-router-dom'
import { ripple } from '../../shared/lib/ripple'
import { useWallet } from './useWallet'
import { useDiamondPurchase, useIsFirstPurchase } from './useDiamondPurchase'
import PurchaseResultModal from './PurchaseResultModal'
import { useActiveFlashSale, formatNaira, formatFlashCountdown } from './flashSale'
import { usePageHeader } from '../../context/PageHeader'

// ─── Types ────────────────────────────────────────────────────

interface Pack {
  id: string
  emoji: string
  label: string
  badge?: string
  priceCents: number          // Paystack kobo (naira × 100)
  priceDisplay: string        // "₦1,500"
  diamonds: number
  accentColor: string
  borderColor: string
  badgeBg: string
  image: string
}

const PACKS: Pack[] = [
  {
    id: 'starter',
    emoji: '🌱',
    label: 'Starter',
    priceCents: 100000,
    priceDisplay: '₦1,000',
    diamonds: 100,
    accentColor: '#3ecf8e',
    borderColor: 'rgba(62,207,142,0.25)',
    badgeBg: 'rgba(62,207,142,0.15)',
    image:
      'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Diamond%20purchase/file_0000000006b471f4ac931b4afa86d286.png',
  },
  {
    id: 'popular',
    emoji: '⭐',
    label: 'Popular',
    badge: 'POPULAR',
    priceCents: 300000,
    priceDisplay: '₦3,000',
    diamonds: 310,
    accentColor: 'var(--accent)',
    borderColor: 'color-mix(in srgb, var(--accent) 30%, transparent)',
    badgeBg: 'color-mix(in srgb, var(--accent) 15%, transparent)',
    image:
      'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Diamond%20purchase/file_00000000710071f4807acc7a14ca9b74.png',
  },
  {
    id: 'best_value',
    emoji: '💎',
    label: 'Best Value',
    badge: 'BEST VALUE',
    priceCents: 480000,
    priceDisplay: '₦4,800',
    diamonds: 520,
    accentColor: '#9b6dff',
    borderColor: 'rgba(155,109,255,0.3)',
    badgeBg: 'rgba(155,109,255,0.15)',
    image:
      'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Diamond%20purchase/file_0000000054c07243b4c896fb762a7a29.png',
  },
  {
    id: 'mega',
    emoji: '🚀',
    label: 'Mega',
    priceCents: 860000,
    priceDisplay: '₦8,600',
    diamonds: 1040,
    accentColor: '#f5c542',
    borderColor: 'rgba(245,197,66,0.25)',
    badgeBg: 'rgba(245,197,66,0.15)',
    image:
      'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Diamond%20purchase/file_0000000090c0724393707e2243921377.png',
  },
  {
    id: 'ultimate',
    emoji: '👑',
    label: 'Ultimate',
    badge: 'ULTIMATE',
    priceCents: 1500000,
    priceDisplay: '₦15,000',
    diamonds: 2180,
    accentColor: '#e040fb',
    borderColor: 'rgba(224,64,251,0.3)',
    badgeBg: 'rgba(224,64,251,0.15)',
    image:
      'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Diamond%20purchase/file_000000009fd071f4838edf08c8b4f12b.png',
  },
]

// Flash sale items now come from migration 0097's public.get_active_flash_sale()
// RPC (Ops-console-editable weekly_special / monthly_mega rules) via the
// shared useActiveFlashSale() hook — see ./flashSale.ts.

// getPurchasePriceCents (from useDiamondPurchase.ts) already handles both
// Pack (priceCents) and FlashSaleItem (sale_price_cents) shapes, so a plain
// Pack satisfies PurchasableItem as-is — no local alias needed here anymore.

// ─── Pack Card ────────────────────────────────────────────────
function PackCard({
  pack,
  isFirstPurchase,
  onBuy,
  loading,
}: {
  pack: Pack & { image: string }
  isFirstPurchase: boolean
  onBuy: (pack: Pack & { image: string }) => void
  loading: boolean
}) {
  const bonus = isFirstPurchase ? pack.diamonds : 0
  const total = pack.diamonds + bonus

  return (
    <div
      style={{
        background: 'var(--surface)',
        border: `1px solid ${pack.borderColor}`,
        borderRadius: 18,
        padding: 16,
        position: 'relative',
        overflow: 'hidden',
        boxShadow: `4px 4px 12px var(--neu-dark),-2px -2px 8px var(--neu-light), 0 0 0 0 ${pack.borderColor}`,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
      }}
    >
      {/* Subtle glow behind */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(ellipse at 70% 0%,${pack.borderColor.replace('0.3', '0.08').replace('0.25', '0.06')},transparent 70%)`,
          pointerEvents: 'none',
        }}
      />

      {/* Badge */}
      {pack.badge && (
        <div
          style={{
            position: 'absolute',
            top: 12,
            right: 12,
            background: pack.badgeBg,
            color: pack.accentColor,
            fontSize: 9,
            fontWeight: 800,
            padding: '3px 8px',
            borderRadius: 8,
            letterSpacing: '0.6px',
            border: `1px solid ${pack.borderColor}`,
          }}
        >
          {pack.badge}
        </div>
      )}

      {/* Image */}
      <div
        style={{
          width: '100%',
          aspectRatio: '1',
          borderRadius: 14,
          overflow: 'hidden',
          background: 'var(--surface2)',
          flexShrink: 0,
        }}
      >
        <img
          src={(pack as unknown as { image: string }).image}
          alt={pack.label}
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          loading="lazy"
        />
      </div>

      {/* Label */}
      <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
        {pack.emoji} {pack.label}
      </div>

      {/* Diamonds */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            fontSize: 13,
            fontWeight: 700,
            color: 'var(--text)',
          }}
        >
          {isFirstPurchase ? (
            <span>
              <span style={{ textDecoration: 'line-through', color: 'var(--text-muted)', fontWeight: 600 }}>
                {pack.diamonds.toLocaleString()}
              </span>{' '}
              <span style={{ color: pack.accentColor }}>{total.toLocaleString()} 💎</span>
            </span>
          ) : (
            <span>{pack.diamonds.toLocaleString()} 💎</span>
          )}
        </div>
        {isFirstPurchase && (
          <div
            style={{
              fontSize: 10.5,
              fontWeight: 700,
              color: pack.accentColor,
              background: pack.badgeBg,
              borderRadius: 7,
              padding: '2px 7px',
              display: 'inline-block',
              width: 'fit-content',
            }}
          >
            +{pack.diamonds.toLocaleString()} first purchase bonus!
          </div>
        )}
      </div>

      {/* Buy button */}
      <button
        onClick={(e) => {
          ripple(e)
          onBuy(pack as unknown as Pack & { image: string })
        }}
        disabled={loading}
        className="ripple-wrap"
        style={{
          width: '100%',
          padding: '11px 0',
          borderRadius: 13,
          border: 'none',
          cursor: loading ? 'not-allowed' : 'pointer',
          background: loading
            ? 'var(--surface3)'
            : `linear-gradient(135deg,${pack.accentColor},${pack.accentColor}cc)`,
          color: loading ? 'var(--text-muted)' : '#fff',
          fontSize: 14,
          fontWeight: 800,
          fontFamily: 'inherit',
          boxShadow: loading ? 'none' : `0 4px 16px ${pack.borderColor}`,
          transition: 'background-color var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
          marginTop: 2,
        }}
      >
        {pack.priceDisplay}
      </button>
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────
export default function BuyDiamonds() {
  const navigate = useNavigate()
  const { wallet } = useWallet()
  usePageHeader({ title: 'Buy Diamonds', onBack: () => navigate('/mall') })

  const isFirstPurchase = useIsFirstPurchase()
  const { loading, modal, activeItem, purchase, retry, closeModal } = useDiamondPurchase()
  const { flashSale, tick: flashSaleTick } = useActiveFlashSale()

  function handleBuy(pack: Pack & { image: string }) {
    purchase(pack, { isFirstPurchase, missionKey: 'diamond_packs_bought' })
  }

  return (
    <>
      <div style={{ maxWidth: 700, margin: '0 auto', paddingBottom: 48 }}>
        {/* Balance chip. Title/back button now live in the app Topbar via
            usePageHeader() — see PAGE_HEADER_MIGRATION_PLAN.md Phase 1.
            Back intentionally returns to /mall (not browser back): this
            page is always entered from Mall's "buy more" button. */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            marginBottom: 24,
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 5,
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: 10,
              padding: '6px 12px',
              boxShadow: 'var(--elev-raise-sm)',
            }}
          >
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>
              💎 {(wallet?.gem_balance ?? 0).toLocaleString()}
            </span>
          </div>
        </div>

        {/* Hero / first purchase banner */}
        {isFirstPurchase && (
          <div
            className="neu-card"
            style={{
              padding: '16px 18px',
              marginBottom: 20,
              background:
                'linear-gradient(135deg,rgba(62,207,142,0.08),rgba(79,142,247,0.06))',
              border: '1px solid rgba(62,207,142,0.2)',
              borderRadius: 16,
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                position: 'absolute',
                right: -16,
                top: -16,
                width: 100,
                height: 100,
                borderRadius: '50%',
                background:
                  'radial-gradient(circle,rgba(62,207,142,0.15),transparent 70%)',
                pointerEvents: 'none',
              }}
            />
            <div style={{ fontSize: 18, marginBottom: 4 }}>🎁</div>
            <div
              style={{
                fontSize: 14,
                fontWeight: 800,
                color: 'var(--text)',
                marginBottom: 3,
              }}
            >
              First Purchase Bonus — Double Diamonds!
            </div>
            <div
              style={{ fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.5 }}
            >
              Your very first pack gets 2× the diamonds automatically. No code
              needed.
            </div>
          </div>
        )}

        {/* Pack grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: 14,
          }}
        >
          {(PACKS as unknown as (Pack & { image: string })[]).map((pack, i) => (
            <div
              key={pack.id}
              style={{
                animation: 'feedIn 0.35s ease-out both',
                animationDelay: `${i * 0.07}s`,
              }}
            >
              <PackCard
                pack={pack}
                isFirstPurchase={isFirstPurchase}
                onBuy={handleBuy}
                loading={loading}
              />
            </div>
          ))}
        </div>

        {/* ── Flash Sales — CMS-driven (migration 0097), hidden entirely
             when no weekly_special / monthly_mega window is currently open ── */}
        {flashSale && flashSale.items.length > 0 && (
          <div style={{ marginTop: 36 }}>
            {/* Header */}
            <div style={{ marginBottom: 14, textAlign: 'center' }}>
              <div
                style={{
                  display: 'inline-block',
                  fontFamily: '"Georgia", "Times New Roman", serif',
                  fontSize: 22,
                  fontWeight: 700,
                  fontStyle: 'italic',
                  letterSpacing: '0.5px',
                  background: 'linear-gradient(135deg, var(--accent), #f5c542)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                ⚡ {flashSale.title}
              </div>
              {flashSale.subtitle && (
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>
                  {flashSale.subtitle}
                </div>
              )}
              <div
                key={flashSaleTick}
                style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--accent)', marginTop: 5 }}
              >
                {formatFlashCountdown(flashSale.ends_at)}
              </div>
            </div>

            {/* Flash pack rows */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {flashSale.items.map((item, i) => (
                <div
                  key={item.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    background: 'var(--surface)',
                    border: '1px solid color-mix(in srgb, var(--accent) 20%, transparent)',
                    borderRadius: 14,
                    padding: '12px 16px',
                    gap: 12,
                    animation: 'feedIn 0.35s ease-out both',
                    animationDelay: `${i * 0.06}s`,
                    boxShadow: '0 0 0 0 transparent',
                  }}
                >
                  {/* Left — diamond amount */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 10,
                        background: 'color-mix(in srgb, var(--accent) 10%, transparent)',
                        border: '1px solid color-mix(in srgb, var(--accent) 20%, transparent)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 16,
                        flexShrink: 0,
                      }}
                    >
                      ⚡
                    </div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
                        {item.diamonds.toLocaleString()} 💎
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 1 }}>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)', textDecoration: 'line-through' }}>
                          {formatNaira(item.original_price_cents)}
                        </span>
                        <span style={{ fontSize: 9.5, fontWeight: 800, color: 'var(--accent)' }}>
                          -{Math.round(item.discount_pct)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right — price button */}
                  <button
                    onClick={(e) => {
                      ripple(e)
                      purchase(item, { isFirstPurchase: false })
                    }}
                    disabled={loading}
                    className="ripple-wrap"
                    style={{
                      padding: '9px 18px',
                      borderRadius: 11,
                      border: 'none',
                      cursor: loading ? 'not-allowed' : 'pointer',
                      background: loading ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),#f5c542)',
                      color: '#fff',
                      fontSize: 13,
                      fontWeight: 800,
                      fontFamily: 'inherit',
                      flexShrink: 0,
                      boxShadow: loading ? 'none' : '0 4px 14px color-mix(in srgb, var(--accent) 35%, transparent)',
                      transition: 'background-color var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
                    }}
                  >
                    {formatNaira(item.sale_price_cents)}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer note */}
        <div
          style={{
            marginTop: 24,
            textAlign: 'center',
            fontSize: 11,
            color: 'var(--text-muted)',
            lineHeight: 1.6,
          }}
        >
          Payments are processed securely by Paystack. Diamonds are non-refundable.
        </div>
      </div>

      {/* Modals */}
      {modal && (
        <PurchaseResultModal
          kind={modal}
          item={activeItem}
          onClose={() => {
            closeModal()
            if (modal === 'success') navigate('/wallet')
          }}
          onRetry={modal === 'cancelled' || modal === 'error' ? retry : undefined}
        />
      )}

      <style>{`
        @keyframes fadeIn { from{opacity:0} to{opacity:1} }
        @keyframes popIn  { from{opacity:0;transform:scale(0.82) translateY(30px)} to{opacity:1;transform:scale(1) translateY(0)} }
        @keyframes feedIn { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
      `}</style>
    </>
  )
}
