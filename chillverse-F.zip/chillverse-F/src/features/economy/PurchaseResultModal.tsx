// src/features/economy/PurchaseResultModal.tsx
// Success / cancelled / error result screen shown after a Paystack
// checkout attempt. Pulled out of BuyDiamonds.tsx (unchanged) so the Game
// Zone flash-sale modal (GamesZone.tsx) can show the exact same result UI
// after a purchase made from there.
import { X } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import type { PurchaseModalKind, PurchasableItem } from './useDiamondPurchase'

const MODAL_IMG =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Onboarding/e0cda9106501f1ad6c3c37ff5c1cbe98.jpg'

export default function PurchaseResultModal({
  kind,
  item,
  onClose,
  onRetry,
}: {
  kind: PurchaseModalKind
  item: PurchasableItem | null
  onClose: () => void
  onRetry?: () => void
}) {
  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 500,
        background: 'rgba(0,0,0,0.72)',
        backdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
        animation: 'fadeIn 0.2s ease both',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: 360,
          background: 'var(--surface2)',
          borderRadius: 24,
          border: '1px solid var(--border)',
          boxShadow: 'var(--elev-popover)',
          overflow: 'visible',
          position: 'relative',
          animation: 'popIn 0.38s cubic-bezier(0.34,1.56,0.64,1) both',
        }}
      >
        {/* Close */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: 14,
            right: 14,
            width: 28,
            height: 28,
            borderRadius: 8,
            background: 'rgba(255,255,255,0.06)',
            border: 'none',
            cursor: 'pointer',
            color: 'var(--text-dim)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10,
          }}
        >
          <X size={13} />
        </button>

        {/* Big box — blurred bg + cutout */}
        <div
          style={{
            position: 'relative',
            height: 200,
            borderRadius: '24px 24px 0 0',
            overflow: 'visible',
            background:
              kind === 'success'
                ? 'linear-gradient(160deg,rgba(62,207,142,0.12),rgba(79,142,247,0.08))'
                : 'linear-gradient(160deg,color-mix(in srgb, var(--accent) 12%, transparent),rgba(245,197,66,0.08))',
            borderBottom: '1px solid var(--border)',
          }}
        >
          {/* blurred bg */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              borderRadius: '24px 24px 0 0',
              overflow: 'hidden',
            }}
          >
            <img
              src={MODAL_IMG}
              alt=""
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                opacity: 0.18,
                filter: 'blur(4px)',
                transform: 'scale(1.1)',
              }}
            />
          </div>
          {/* character cutout overflowing box */}
          <div
            style={{
              position: 'absolute',
              bottom: -8,
              left: '50%',
              transform: 'translateX(-50%)',
              width: 160,
              height: 220,
              zIndex: 5,
            }}
          >
            <img
              src={MODAL_IMG}
              alt=""
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                objectPosition: 'center top',
                borderRadius: 16,
                boxShadow: 'var(--elev-popover)',
                filter:
                  kind === 'success'
                    ? 'drop-shadow(0 8px 24px rgba(62,207,142,0.3))'
                    : 'drop-shadow(0 8px 24px color-mix(in srgb, var(--accent) 30%, transparent))',
              }}
            />
          </div>
        </div>

        {/* Content */}
        <div style={{ padding: '28px 20px 22px', textAlign: 'center' }}>
          <div style={{ fontSize: 24, marginBottom: 8 }}>
            {kind === 'success' ? '🎉' : kind === 'error' ? '⚠️' : '😔'}
          </div>
          <div
            style={{
              fontSize: 16,
              fontWeight: 800,
              color: 'var(--text)',
              marginBottom: 6,
            }}
          >
            {kind === 'success' ? 'Thank you for your purchase' : kind === 'error' ? 'Payment received, crediting failed' : 'Payment cancelled'}
          </div>
          {kind === 'success' && item && (
            <div
              style={{
                fontSize: 13,
                color: 'var(--text-dim)',
                lineHeight: 1.6,
                marginBottom: 20,
              }}
            >
              💎 Diamonds have been added to your wallet.
            </div>
          )}
          {kind === 'error' && (
            <div
              style={{
                fontSize: 13,
                color: 'var(--text-dim)',
                lineHeight: 1.6,
                marginBottom: 20,
              }}
            >
              Your payment went through but we couldn't credit your diamonds automatically. Please contact support — your purchase is recorded and will be resolved.
            </div>
          )}
          {kind === 'cancelled' && (
            <div
              style={{
                fontSize: 13,
                color: 'var(--text-dim)',
                marginBottom: 20,
              }}
            >
              No charge was made. You can try again anytime.
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {kind === 'cancelled' && onRetry && (
              <button
                onClick={(e) => {
                  ripple(e)
                  onRetry()
                }}
                className="ripple-wrap"
                style={{
                  width: '100%',
                  padding: 13,
                  borderRadius: 14,
                  border: 'none',
                  cursor: 'pointer',
                  background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
                  color: '#fff',
                  fontSize: 14,
                  fontWeight: 800,
                  fontFamily: 'inherit',
                  boxShadow: '0 4px 20px color-mix(in srgb, var(--accent) 35%, transparent)',
                }}
              >
                Try Again
              </button>
            )}
            <button
              onClick={(e) => {
                ripple(e)
                onClose()
              }}
              className="ripple-wrap"
              style={{
                width: '100%',
                padding: 13,
                borderRadius: 14,
                border: '1px solid var(--border-strong)',
                cursor: 'pointer',
                background: 'var(--surface)',
                color: 'var(--text-dim)',
                fontSize: 14,
                fontWeight: 700,
                fontFamily: 'inherit',
              }}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
