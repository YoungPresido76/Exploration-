// src/features/economy/itemVariants.ts
//
// "Customise this item" — alternate colours for a banner or profile pic.
//
// A colour is an add-on to an item you already own, never a way to get the
// item itself. Buying one adds a slot inside that inventory item; the
// original colour is never spent or replaced, so a player can switch back
// and forth freely afterwards. Colours can't be gifted — send_gift only
// ever moves mall_items rows — which is exactly why the "you must own the
// item first" rule holds: the base item is the giftable thing, the colour
// is something you go and buy for yourself.
//
// Everything that matters is enforced in purchase_item_variant() on the
// server (ownership, double-buy, price, the item still being on sale).
// The client checks are only there so the player gets a toast instead of a
// raw Postgres error.

import { supabase } from '../../shared/lib/supabase'

export interface ItemVariant {
  id: string
  item_id: string
  name: string
  image_url: string
  price_gems: number
  sort_order: number
}

/** Only these can carry colours. Card effects are profile_pic rows too but
 *  they're .mp4 — a "colour" there would mean five more video uploads — so
 *  they're excluded, matching the check inside admin_save_item_variant. */
export function canHaveVariants(category: string, subCategory: string | null): boolean {
  if (subCategory === 'Profile card effect') return false
  return category === 'banner' || category === 'profile_pic'
}

export async function fetchItemVariants(itemId: string): Promise<ItemVariant[]> {
  const { data, error } = await supabase
    .from('mall_item_variants')
    .select('id, item_id, name, image_url, price_gems, sort_order')
    .eq('item_id', itemId)
    .order('sort_order', { ascending: true })
    .order('created_at', { ascending: true })
  if (error) return []
  return (data ?? []) as ItemVariant[]
}

/** Ids of the colours this player has bought, across every item. Small
 *  enough to fetch whole — a player can own at most 5 per item. */
export async function fetchOwnedVariantIds(userId: string): Promise<Set<string>> {
  const { data, error } = await supabase
    .from('user_item_variants')
    .select('variant_id')
    .eq('user_id', userId)
  if (error) return new Set()
  return new Set((data ?? []).map(r => r.variant_id as string))
}

export type VariantPurchaseResult =
  | 'success'
  | 'must_own_item'
  | 'already_owned'
  | 'insufficient'
  | 'unavailable'
  | 'error'

export async function purchaseItemVariant(variantId: string): Promise<VariantPurchaseResult> {
  const { error } = await supabase.rpc('purchase_item_variant', { p_variant_id: variantId })
  if (!error) return 'success'
  const message = error.message || ''
  if (message.includes('must_own_item')) return 'must_own_item'
  if (message.includes('already_owned')) return 'already_owned'
  if (message.includes('insufficient_funds')) return 'insufficient'
  if (message.includes('item_expired') || message.includes('item_locked')
    || message.includes('item_not_found') || message.includes('variant_not_found')) return 'unavailable'
  return 'error'
}

export function variantPurchaseMessage(result: VariantPurchaseResult, itemName: string): string {
  switch (result) {
    case 'success':       return 'Colour added to your inventory 🎨'
    case 'must_own_item': return `Please buy ${itemName} first to customise it.`
    case 'already_owned': return 'You already own this colour.'
    case 'insufficient':  return 'Not enough Diamonds for this colour.'
    case 'unavailable':   return 'This item is no longer available.'
    default:              return 'Could not buy that colour. Please try again.'
  }
}
