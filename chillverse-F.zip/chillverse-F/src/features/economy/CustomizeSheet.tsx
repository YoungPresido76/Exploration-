// src/features/economy/CustomizeSheet.tsx
//
// The sheet behind "Customize this item" in the Mall. The item sheet
// closes and this draws up in its place, showing the colours that item
// comes in. Pick one and its price appears; buy it and it lands in the
// inventory as an extra slot on the item you already own.
//
// Deliberately shows the colours to non-owners too. Seeing what an item
// can become is half the reason to buy the item, so the swatches always
// render — it's the Buy tap that stops and says to get the item first.
//
// Portaled to document.body for the same reason ProfileEffectPreview is:
// AppLayout wraps page content in a z-indexed <main>, which caps anything
// rendered through the normal tree no matter how high its own z-index.

import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Check, Palette, Lock } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { useRealViewportHeight, useSheetDrag } from '../../shared/hooks/useBottomSheet'
import {
  fetchItemVariants, fetchOwnedVariantIds, purchaseItemVariant,
  variantPurchaseMessage, type ItemVariant, type VariantPurchaseResult,
} from './itemVariants'

const SHEET_HEIGHT_VH = 78

export default function CustomizeSheet({
  itemId, itemName, itemImageUrl, userId, ownsItem, onClose, onResult,
}: {
  itemId: string
  itemName: string
  /** The item's original colour — always shown first, always already owned. */
  itemImageUrl: string | null
  userId: string | null
  /** Whether this player owns the base item. Buying is blocked without it. */
  ownsItem: boolean
  onClose: () => void
  /** Fires for every finished buy attempt, successful or not, so the caller
   *  can toast and refresh. */
  onResult: (result: VariantPurchaseResult, message: string) => void
}) {
  const realVh = useRealViewportHeight()
  const sheetHeightPx = Math.round(realVh * (SHEET_HEIGHT_VH / 100))
  const { dragY, dragging, dragHandleProps, sheetProps } = useSheetDrag(onClose)

  const [variants, setVariants] = useState<ItemVariant[]>([])
  const [owned, setOwned] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [picked, setPicked] = useState<ItemVariant | null>(null)
  const [buying, setBuying] = useState(false)

  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  useEffect(() => {
    let active = true
    Promise.all([
      fetchItemVariants(itemId),
      userId ? fetchOwnedVariantIds(userId) : Promise.resolve(new Set<string>()),
    ]).then(([list, ownedIds]) => {
      if (!active) return
      setVariants(list)
      setOwned(ownedIds)
      setLoading(false)
    })
    return () => { active = false }
  }, [itemId, userId])

  async function handleBuy() {
    if (!picked || buying) return
    // Checked here as well as server-side so the common case toasts
    // instantly instead of after a round trip. purchase_item_variant
    // raises must_own_item regardless, so this is only a shortcut.
    if (!ownsItem) {
      onResult('must_own_item', variantPurchaseMessage('must_own_item', itemName))
      return
    }
    setBuying(true)
    const result = await purchaseItemVariant(picked.id)
    setBuying(false)
    if (result === 'success') setOwned(prev => new Set(prev).add(picked.id))
    onResult(result, variantPurchaseMessage(result, itemName))
    if (result === 'success') onClose()
  }

  const pickedOwned = picked != null && owned.has(picked.id)

  return createPortal(
    <div
      onClick={onClose}
      className="sheet-or-modal sheet-or-modal-over-dock"
      style={{
        position: 'fixed', inset: 0, zIndex: 20020, background: 'rgba(0,0,0,0.6)',
        backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      {/* sheetProps: drag-to-dismiss from anywhere inside the sheet, not just
          the handle. See useBottomSheet.ts. */}
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--surface)', borderRadius: '20px 20px 0 0', padding: '0 20px 24px',
          width: '100%', maxWidth: 460, border: '1px solid var(--border)', borderBottom: 'none',
          boxShadow: '0 -12px 40px -12px var(--sh)',
          height: sheetHeightPx, maxHeight: sheetHeightPx, overflowY: 'auto', overscrollBehavior: 'contain',
          display: 'flex', flexDirection: 'column',
          transform: `translateY(${dragY}px)`,
          transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.16,1,0.3,1)',
          animation: dragging ? undefined : 'slideUp 0.28s cubic-bezier(0.16,1,0.3,1) both',
        }}
      >
        <div {...dragHandleProps} style={{ ...dragHandleProps.style, padding: '10px 0 8px', margin: '0 auto', flexShrink: 0, display: 'flex', justifyContent: 'center' }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '10px 0 4px', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Palette size={16} style={{ color: 'var(--accent)' }} />
            <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)' }}>Customise</span>
          </div>
          <button onClick={onClose} style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)' }}>
            <X size={14} />
          </button>
        </div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 16px', lineHeight: 1.5 }}>
          Other colours {itemName} comes in.
        </p>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '28px 0' }}>
            <span style={{ width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', display: 'inline-block', animation: 'spin 0.8s linear infinite' }} />
          </div>
        ) : (
          <>
            {/* Swatches. The original always leads and is always owned —
                buying a colour never costs you the one you started with. */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 18 }}>
              <Swatch
                label="Original"
                imageUrl={itemImageUrl}
                selected={picked === null}
                ownedTag
                onTap={() => setPicked(null)}
              />
              {variants.map(v => (
                <Swatch
                  key={v.id}
                  label={v.name}
                  imageUrl={v.image_url}
                  selected={picked?.id === v.id}
                  ownedTag={owned.has(v.id)}
                  onTap={() => setPicked(v)}
                />
              ))}
            </div>

            <div style={{ flex: 1 }} />

            {picked === null ? (
              <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', lineHeight: 1.55, margin: 0 }}>
                Pick a colour to see what it costs.
              </p>
            ) : (
              <>
                <button
                  type="button"
                  disabled={buying || pickedOwned}
                  onClick={(e) => { ripple(e); handleBuy() }}
                  className="ripple-wrap"
                  style={{
                    width: '100%', padding: 13, borderRadius: 14, border: 'none', marginBottom: 10,
                    cursor: buying || pickedOwned ? 'not-allowed' : 'pointer',
                    background: pickedOwned ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
                    color: pickedOwned ? 'var(--text-muted)' : '#fff',
                    fontSize: 14, fontWeight: 800,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                    boxShadow: pickedOwned ? 'none' : '0 4px 16px color-mix(in srgb, var(--accent) 35%, transparent)',
                    animation: 'feedIn 0.22s ease-out both',
                  }}
                >
                  {pickedOwned
                    ? <><Check size={15} /> You own this colour</>
                    : !ownsItem
                      ? <><Lock size={14} /> 💎 {picked.price_gems.toLocaleString()}</>
                      : <>💎 {buying ? 'Buying…' : `${picked.price_gems.toLocaleString()} Diamonds`}</>}
                </button>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: 'center', lineHeight: 1.55, margin: 0 }}>
                  You still keep your existing colour — this is only added as a slot in your inventory item, so you can customise at any time.
                </p>
              </>
            )}
          </>
        )}
      </div>
    </div>,
    document.body,
  )
}

function Swatch({ label, imageUrl, selected, ownedTag, onTap }: {
  label: string
  imageUrl: string | null
  selected: boolean
  ownedTag: boolean
  onTap: () => void
}) {
  return (
    <button
      type="button"
      onClick={(e) => { ripple(e); onTap() }}
      className="ripple-wrap"
      style={{
        padding: 0, background: 'none', border: 'none', cursor: 'pointer',
        textAlign: 'center', fontFamily: 'inherit',
      }}
    >
      <div style={{
        width: '100%', aspectRatio: '1 / 1', borderRadius: 14, overflow: 'hidden',
        background: 'var(--surface2)', position: 'relative',
        border: selected ? '2px solid var(--accent)' : '1px solid var(--border)',
        boxShadow: selected ? '0 0 0 3px color-mix(in srgb, var(--accent) 18%, transparent)' : 'none',
        transition: 'border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)',
      }}>
        {imageUrl && <img src={imageUrl} alt={label} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
        {ownedTag && (
          <span style={{
            position: 'absolute', top: 4, right: 4, width: 18, height: 18, borderRadius: '50%',
            background: 'rgba(0,0,0,0.6)', color: '#3ecf8e',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Check size={11} />
          </span>
        )}
      </div>
      <div style={{
        fontSize: 10.5, fontWeight: 700, marginTop: 5,
        color: selected ? 'var(--accent)' : 'var(--text-dim)',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>
        {label}
      </div>
    </button>
  )
}
