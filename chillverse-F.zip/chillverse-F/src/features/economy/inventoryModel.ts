// src/features/economy/inventoryModel.ts
//
// The inventory screen shows things that live in three different places:
// bought cosmetics (user_inventory → mall_items), battle skills
// (get_pvp_cards) and titles (player_artifacts). The grid, the category
// tabs and the filter sheet all need to treat them as one list, so this
// module flattens them into a single `InvItem` shape and owns the
// filtering/sorting rules. Kept free of React so the page component stays
// about layout.
import { canUpgrade, type PvpCard } from '../pvp/pvp'
import { isConsumableIconCategory } from './ConsumableIcon'
import type { MallItem } from '../../shared/types'

/* ── Source rows ─────────────────────────────────────────────────── */

export interface InventoryEntry {
  id: string
  item_id: string
  is_equipped: boolean
  quantity: number
  /** user_inventory.acquired_at — powers the "Recently Acquired" sort. */
  acquired_at?: string | null
  /** Which bought colour is currently worn. Null means the item's own
   *  original colour, which is why nothing needed backfilling when the
   *  column landed. */
  equipped_variant_id?: string | null
  item: MallItem
}

/** A row of player_artifacts joined to artifacts — the TITLE slot. */
export interface OwnedTitle {
  artifact_id: string
  name: string
  tier: string
  media_url: string | null
  is_equipped: boolean
  unlocked_at: string | null
}

/* ── Vocabulary ──────────────────────────────────────────────────── */

export type InvCategory =
  | 'skills' | 'avatars' | 'profile_pics' | 'effects'
  | 'boosts' | 'consumables' | 'titles'

export type InvRarity = 'Common' | 'Rare' | 'Epic' | 'Mythic'
export type InvStatus = 'equipped' | 'unequipped'
export type InvSpecial = 'ready' | 'upgradeable' | 'new'
export type InvSort = 'recent' | 'rarity' | 'name' | 'level'

/** Every category, in the order the filter sheet lists them. */
export const CATEGORIES: { id: InvCategory; label: string }[] = [
  { id: 'skills',       label: 'Skills' },
  { id: 'avatars',      label: 'Avatars' },
  { id: 'profile_pics', label: 'Profile Pics' },
  { id: 'effects',      label: 'Effects' },
  { id: 'boosts',       label: 'Boosts' },
  { id: 'consumables',  label: 'Consumables' },
  { id: 'titles',       label: 'Titles' },
]

// No Legendary tier exists in mall_items or artifacts — don't offer a filter
// chip that can only ever return nothing.
export const RARITIES: InvRarity[] = ['Common', 'Rare', 'Epic', 'Mythic']

export const RARITY_COLOR: Record<InvRarity, string> = {
  Common: '#8b95a5',
  Rare:   '#4f8ef7',
  Epic:   '#9b6dff',
  Mythic: '#ff6b4a',
}

const RARITY_RANK: Record<InvRarity, number> = {
  Common: 0, Rare: 1, Epic: 2, Mythic: 3,
}

export const SORT_LABELS: Record<InvSort, string> = {
  recent: 'Recently Acquired',
  rarity: 'Rarity',
  name:   'Name (A–Z)',
  level:  'Level',
}

/** How long a freshly acquired item keeps its "New" flag. */
const NEW_WINDOW_MS = 72 * 60 * 60 * 1000

/* ── The flattened item ──────────────────────────────────────────── */

export type InvSource =
  | { kind: 'mall'; entry: InventoryEntry }
  | { kind: 'skill'; card: PvpCard }
  | { kind: 'title'; title: OwnedTitle }

export interface InvItem {
  key: string
  category: InvCategory
  name: string
  rarity: InvRarity
  imageUrl: string | null
  equipped: boolean
  quantity: number
  /** Skill level, or null for anything that doesn't level. */
  level: number | null
  /** Secondary line under the rarity, e.g. "38 dmg · 12h recharge". */
  meta: string | null
  /** ms epoch, 0 when the source row has no timestamp. */
  acquiredAt: number
  isNew: boolean
  readyToUse: boolean
  upgradeable: boolean
  source: InvSource
}

/* ── Category mapping ────────────────────────────────────────────── */

/**
 * Which tab a purchased item belongs under. Battle cards are deliberately
 * absent: they arrive as PvpCards instead (mall_items rows for them exist,
 * but the card RPC is the one that knows level and damage).
 */
function mallCategory(item: MallItem): InvCategory {
  if (item.category === 'avatar_skin') return 'avatars'
  if (item.sub_category === 'Profile card effect') return 'effects'
  if (item.category === 'profile_effect' || item.category === 'chat_theme') return 'effects'
  if (isConsumableIconCategory(item.category)) return 'boosts'
  if (item.category === 'profile_pic' || item.category === 'banner') return 'profile_pics'
  // Catch-all so a new mall category can never vanish from the tabs.
  return 'consumables'
}

/**
 * Manually activated boosts — the only ones with a generic "Use" button
 * that calls use_consumable(). PvP utility items (Regenerate, Quick
 * Charge) also live under the 'xp_booster' category — mall_items has no
 * category slot of its own for them — but use_consumable() only knows how
 * to apply 'rank_shield' and a real XP boost, so routing one of these
 * through it would silently burn the item for nothing. They apply through
 * their own dedicated flow instead (the Regenerate button on a dead
 * profile; Quick Charge from a recharging card in the attack sheet).
 */
export function isManuallyUsable(item: MallItem): boolean {
  if (item.sub_category?.startsWith('PvP ')) return false
  return item.category === 'rank_shield' || item.category === 'xp_booster'
}

function titleRarity(tier: string): InvRarity {
  const normalized = tier.charAt(0).toUpperCase() + tier.slice(1).toLowerCase()
  return (RARITIES as string[]).includes(normalized) ? normalized as InvRarity : 'Common'
}

function skillMeta(card: PvpCard): string {
  const parts = [`${Math.round(card.current_damage)} dmg`]
  if (card.cooldown_minutes >= 60) parts.push(`${card.cooldown_minutes / 60}h recharge`)
  else if (card.cooldown_minutes > 0) parts.push(`${card.cooldown_minutes}m recharge`)
  return parts.join(' · ')
}

/* ── Build ───────────────────────────────────────────────────────── */

export function buildInventoryItems({
  entries, cards, slottedIds, titles, activeUntilFor, now = Date.now(),
}: {
  entries: InventoryEntry[]
  /** Owned cards only. */
  cards: PvpCard[]
  /** item_ids currently sitting in one of the 3 quick slots. */
  slottedIds: Set<string>
  titles: OwnedTitle[]
  /** ISO string while a boost is running, else null. */
  activeUntilFor: (item: MallItem) => string | null
  now?: number
}): InvItem[] {
  const items: InvItem[] = []

  for (const entry of entries) {
    // Battle cards come from the card RPC instead — skipping them here is
    // what stops every skill appearing twice in the grid.
    if (entry.item.category === 'pvp_card') continue

    const acquiredAt = entry.acquired_at ? Date.parse(entry.acquired_at) : 0
    const active = activeUntilFor(entry.item)
    items.push({
      key: `mall:${entry.id}`,
      category: mallCategory(entry.item),
      name: entry.item.name,
      rarity: entry.item.rarity as InvRarity,
      imageUrl: entry.item.image_url,
      equipped: entry.is_equipped,
      quantity: entry.quantity,
      level: null,
      meta: active ? 'Active now' : null,
      acquiredAt: Number.isNaN(acquiredAt) ? 0 : acquiredAt,
      isNew: acquiredAt > 0 && now - acquiredAt < NEW_WINDOW_MS,
      readyToUse: isManuallyUsable(entry.item) && !active && entry.quantity > 0,
      upgradeable: false,
      source: { kind: 'mall', entry },
    })
  }

  for (const card of cards) {
    // A battle consumable is a card mechanically — it slots, it combos, it
    // comes from get_pvp_cards — but to a player it is stock, so it belongs
    // on the Consumables tab beside the boosts rather than under Skills
    // where every row is something they keep.
    const consumable = card.is_consumable
    items.push({
      key: `skill:${card.item_id}`,
      category: consumable ? 'consumables' : 'skills',
      name: card.name,
      rarity: card.rarity as InvRarity,
      imageUrl: card.image_url,
      equipped: slottedIds.has(card.item_id),
      // Copies are ammunition for a consumable and upgrade fuel for a card,
      // so only one of the two is a quantity worth showing on the tile.
      quantity: consumable ? card.copies : 1,
      level: consumable ? null : card.card_level,
      meta: consumable
        ? `${card.copies} use${card.copies === 1 ? '' : 's'} left`
        : skillMeta(card),
      // get_pvp_cards doesn't return an acquired timestamp, so these sort
      // to the bottom of "Recently Acquired" rather than faking a date.
      acquiredAt: 0,
      isNew: false,
      readyToUse: false,
      upgradeable: canUpgrade(card),
      source: { kind: 'skill', card },
    })
  }

  for (const title of titles) {
    const acquiredAt = title.unlocked_at ? Date.parse(title.unlocked_at) : 0
    items.push({
      key: `title:${title.artifact_id}`,
      category: 'titles',
      name: title.name,
      rarity: titleRarity(title.tier),
      imageUrl: title.media_url,
      equipped: title.is_equipped,
      quantity: 1,
      level: null,
      meta: null,
      acquiredAt: Number.isNaN(acquiredAt) ? 0 : acquiredAt,
      isNew: acquiredAt > 0 && now - acquiredAt < NEW_WINDOW_MS,
      readyToUse: false,
      upgradeable: false,
      source: { kind: 'title', title },
    })
  }

  return items
}

/* ── Filters ─────────────────────────────────────────────────────── */

export interface InvFilters {
  category: InvCategory | 'all'
  rarity: InvRarity | 'all'
  status: InvStatus | 'all'
  special: InvSpecial | 'all'
  sort: InvSort
}

export const DEFAULT_FILTERS: InvFilters = {
  category: 'all', rarity: 'all', status: 'all', special: 'all', sort: 'recent',
}

/** Sort isn't counted — changing the order doesn't hide anything. */
export function countActiveFilters(f: InvFilters): number {
  return [f.category, f.rarity, f.status, f.special].filter(v => v !== 'all').length
}

function matchesSpecial(item: InvItem, special: InvSpecial): boolean {
  if (special === 'ready') return item.readyToUse
  if (special === 'upgradeable') return item.upgradeable
  return item.isNew
}

export function filterAndSortItems(items: InvItem[], f: InvFilters): InvItem[] {
  const filtered = items.filter(item => {
    if (f.category !== 'all' && item.category !== f.category) return false
    if (f.rarity !== 'all' && item.rarity !== f.rarity) return false
    if (f.status === 'equipped' && !item.equipped) return false
    if (f.status === 'unequipped' && item.equipped) return false
    if (f.special !== 'all' && !matchesSpecial(item, f.special)) return false
    return true
  })

  const byName = (a: InvItem, b: InvItem) => a.name.localeCompare(b.name)

  return filtered.sort((a, b) => {
    switch (f.sort) {
      case 'rarity':
        return RARITY_RANK[b.rarity] - RARITY_RANK[a.rarity] || byName(a, b)
      case 'name':
        return byName(a, b)
      case 'level':
        return (b.level ?? -1) - (a.level ?? -1) || byName(a, b)
      default:
        return b.acquiredAt - a.acquiredAt || byName(a, b)
    }
  })
}
