// src/features/mino/useMino.ts
//
// Shared hooks for Mino Games: the server state + live countdown, the horror
// sting, and the AI typewriter effect.

import { useCallback, useEffect, useRef, useState } from 'react'
import { isGameSoundEnabled } from '../games/soundSettings'
import { startTicking, stopTicking } from '../games/sfx'
import { fetchMinoState, type MinoState } from './minoApi'
import { MINO_AMBIENCE_SRC, MINO_HORROR_SRC } from './minoConfig'

// ── Horror sting ────────────────────────────────────────────────────────
let horrorAudio: HTMLAudioElement | null = null

/**
 * Plays the Mino sting once. Respects the same "Game sound" setting as the
 * rest of the app (Settings → Game sound), so a muted player stays muted.
 *
 * Browsers refuse audio that isn't tied to a user gesture — that's fine
 * here, since this only ever fires from a tap on the Mino card. The catch
 * is still needed for the autoplay-policy edge cases (e.g. a modal reopened
 * programmatically after a navigation).
 */
export function playMinoHorror(): void {
  if (!isGameSoundEnabled()) return
  if (typeof window === 'undefined') return
  if (!horrorAudio) {
    horrorAudio = new Audio(MINO_HORROR_SRC)
    horrorAudio.preload = 'auto'
  }
  horrorAudio.currentTime = 0
  horrorAudio.volume = 0.6
  horrorAudio.play().catch(() => {})
}

// ── Ambience bed ────────────────────────────────────────────────────────
// The sting is 3s, but people linger on this sheet reading the leaderboard,
// and silence after the scare deflates it. This is a separate small looping
// file rather than one long track: a 2MB one-shot has to finish downloading
// before the first note plays, so on a slow connection the scare lands late
// or not at all, and it re-costs data on every open.
let ambienceAudio: HTMLAudioElement | null = null

export function startMinoAmbience(): void {
  if (!isGameSoundEnabled()) return
  if (typeof window === 'undefined') return
  if (!ambienceAudio) {
    ambienceAudio = new Audio(MINO_AMBIENCE_SRC)
    ambienceAudio.loop = true
    ambienceAudio.preload = 'auto'
  }
  ambienceAudio.volume = 0.25 // sits under the sting, never competes with it
  ambienceAudio.play().catch(() => {})
}

export function stopMinoAmbience(): void {
  if (!ambienceAudio) return
  ambienceAudio.pause()
  ambienceAudio.currentTime = 0
}

// ── Server state + countdown ────────────────────────────────────────────
export interface UseMinoResult {
  state: MinoState | null
  loading: boolean
  /** Seconds until the window opens (if shut) or closes (if open). */
  secondsToBoundary: number
  refetch: () => void
}

export function useMinoState(enabled = true): UseMinoResult {
  const [state, setState] = useState<MinoState | null>(null)
  const [loading, setLoading] = useState(true)
  const [secondsToBoundary, setSecondsToBoundary] = useState(0)
  const [tick, setTick] = useState(0)

  // Offset between the server's clock and this device's, measured once per
  // fetch. The countdown runs off server time so a player who sets their
  // phone forward doesn't see a fake-open window (they'd be refused by the
  // RPC anyway, but showing an open door that won't budge is worse UX than
  // showing it shut).
  const clockOffsetRef = useRef(0)

  const refetch = useCallback(() => setTick(t => t + 1), [])

  useEffect(() => {
    if (!enabled) { setLoading(false); return }
    let active = true
    setLoading(true)
    fetchMinoState().then(s => {
      if (!active) return
      if (s) clockOffsetRef.current = s.serverNow - Date.now()
      setState(s)
      setLoading(false)
    })
    return () => { active = false }
  }, [enabled, tick])

  useEffect(() => {
    if (!state) return
    function update() {
      const serverNow = Date.now() + clockOffsetRef.current
      const remaining = Math.max(0, Math.round((state!.nextBoundary - serverNow) / 1000))
      setSecondsToBoundary(remaining)
      // The window just flipped — re-read rather than guessing the new state.
      if (remaining === 0) refetch()
    }
    update()
    const id = setInterval(update, 1000)
    return () => clearInterval(id)
  }, [state, refetch])

  return { state, loading, secondsToBoundary, refetch }
}

// ── Typewriter ──────────────────────────────────────────────────────────
/**
 * Reveals `text` one character at a time. Returns the visible slice plus a
 * `done` flag so callers can gate the "start" button until the AI has
 * finished speaking.
 */
export function useTypewriter(text: string, msPerChar = 32): { shown: string; done: boolean } {
  const [count, setCount] = useState(0)

  useEffect(() => {
    setCount(0)
    if (!text) return
    const id = setInterval(() => {
      setCount(c => {
        if (c >= text.length) { clearInterval(id); return c }
        return c + 1
      })
    }, msPerChar)
    return () => clearInterval(id)
  }, [text, msPerChar])

  return { shown: text.slice(0, count), done: count >= text.length }
}

// ── Round timer ─────────────────────────────────────────────────────────
/**
 * A per-round countdown. `key` restarts it — pass the round index so each
 * new round gets a fresh clock without the caller juggling effects.
 *
 * onExpire fires exactly once per round. It's held in a ref so a caller
 * that passes an inline arrow (almost all of them) doesn't restart the
 * timer on every render.
 */
export function useCountdown(seconds: number, key: unknown, onExpire: () => void, paused = false) {
  const [remaining, setRemaining] = useState(seconds)

  // Every Mino stage runs on this hook, so the countdown tick lives here
  // rather than being repeated in each stage. Stops on pause, on expiry
  // and on unmount so it can never outlive the run.
  useEffect(() => {
    if (!paused && remaining > 0 && remaining <= 5) startTicking()
    else stopTicking()
  }, [remaining, paused])
  useEffect(() => stopTicking, [])
  const expiredRef = useRef(false)
  const onExpireRef = useRef(onExpire)
  onExpireRef.current = onExpire

  useEffect(() => {
    setRemaining(seconds)
    expiredRef.current = false
  }, [key, seconds])

  useEffect(() => {
    if (paused) return
    const id = setInterval(() => {
      setRemaining(r => {
        if (r <= 1) {
          if (!expiredRef.current) {
            expiredRef.current = true
            onExpireRef.current()
          }
          clearInterval(id)
          return 0
        }
        return r - 1
      })
    }, 1000)
    return () => clearInterval(id)
  }, [key, seconds, paused])

  return remaining
}
