// src/features/mino/MinoModal.tsx
//
// The Mino Games detail sheet — the "normal game modal" equivalent, reached
// by tapping the Mino card on the Games hero slider.
//
// Layout mirrors GameDetailModal (bottom sheet on touch, centred dialog on a
// real desktop pointer) so Mino doesn't feel like a different app. What's
// different: the live open/close countdown, and the leaderboard embedded
// under the description.
import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { ArrowLeft, Play, Lock, Clock, Trophy, Skull } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { ripple } from '../../shared/lib/ripple'
import { fetchMinoLeaderboard, type MinoLeaderboardRow } from './minoApi'
import {
  MINO_ACCENT, MINO_MODAL_IMAGE, MINO_STAGES, MINO_WINDOW_LABEL,
  formatDuration,
} from './minoConfig'
import { useMinoState } from './useMino'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

const UPPER_TAGS = ['Solo', 'Dystopian']
const TAGS = ['Hard', 'Extreme', 'Rewarding', 'Nice experience']
const SHEET_HEIGHT_VH = 92

function computeIsDesktop(): boolean {
  if (typeof window === 'undefined') return false
  const pointerFine = window.matchMedia ? window.matchMedia('(pointer: fine)').matches : true
  return pointerFine && window.innerWidth >= 820
}

interface Props {
  onClose: () => void
  onPlay: () => void
  /** Bumped by the parent after a run so the state and board re-read. */
  refreshKey?: number
}

export default function MinoModal({ onClose, onPlay, refreshKey = 0 }: Props) {
  const [isDesktop, setIsDesktop] = useState(computeIsDesktop)
  const [entered, setEntered] = useState(false)
  const [closing, setClosing] = useState(false)
  const [board, setBoard] = useState<MinoLeaderboardRow[] | null>(null)

  const { state, loading, secondsToBoundary, refetch } = useMinoState()

  useEffect(() => { refetch() }, [refreshKey, refetch])

  useEffect(() => {
    fetchMinoLeaderboard(15).then(setBoard)
  }, [refreshKey])

  useEffect(() => {
    function onResize() { setIsDesktop(computeIsDesktop()) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  useEffect(() => {
    const t = requestAnimationFrame(() => setEntered(true))
    document.body.style.overflow = 'hidden'
    return () => { cancelAnimationFrame(t); document.body.style.overflow = '' }
  }, [])

  function close() {
    setClosing(true)
    setTimeout(onClose, 220)
  }

  // Drag-to-dismiss from anywhere inside the sheet — engages only when the
  // content under the finger is already scrolled to the top, so the body
  // still scrolls normally. See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(close)

  const stageDef = state ? MINO_STAGES[state.stage] : null

  // One line covering every possible door state, so the button label and the
  // subtitle can never disagree with each other.
  const status = useMemo(() => {
    if (loading || !state) return { label: 'Checking…', sub: '', canPlay: false }
    if (state.completed) {
      return {
        label: 'Completed',
        sub: 'You survived all four stages. More rounds coming soon.',
        canPlay: false,
      }
    }
    if (!state.isOpen) {
      return {
        label: `Opens in ${formatDuration(secondsToBoundary)}`,
        sub: `Mino runs ${MINO_WINDOW_LABEL} every night. Locks in the morning.`,
        canPlay: false,
      }
    }
    if (state.playedTonight) {
      return {
        label: 'Come back tomorrow night',
        sub: 'Tonight\'s attempt is spent. The next round opens tomorrow.',
        canPlay: false,
      }
    }
    return {
      label: `Play · Stage ${state.stage}`,
      sub: `Closes in ${formatDuration(secondsToBoundary)}`,
      canPlay: true,
    }
  }, [loading, state, secondsToBoundary])

  const sheetStyle: React.CSSProperties = isDesktop
    ? {
        width: 'min(92vw, 460px)', maxHeight: '85vh', borderRadius: 20,
        transform: entered && !closing ? 'scale(1)' : 'scale(0.94)',
        opacity: entered && !closing ? 1 : 0,
      }
    : {
        width: '100%', height: `${SHEET_HEIGHT_VH}vh`,
        borderRadius: '20px 20px 0 0', marginTop: 'auto',
        transform: entered && !closing ? `translateY(${dragY}px)` : 'translateY(100%)',
      }

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 2600,
        background: 'rgba(0,0,0,0.72)',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: isDesktop ? 'center' : 'flex-end',
        opacity: entered && !closing ? 1 : 0, transition: 'opacity 220ms',
      }}
    >
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          ...sheetStyle,
          background: 'var(--bg, #0b0b0d)',
          border: '1px solid var(--border)',
          overflowY: 'auto',
          transition: dragging ? 'none' : 'transform 260ms cubic-bezier(0.32,0.72,0,1), opacity 220ms',
        }}
      >
        {/* Banner */}
        <div style={{ position: 'relative' }}>
          <img
            src={MINO_MODAL_IMAGE}
            alt="Mino Games"
            style={{ width: '100%', aspectRatio: '16/10', objectFit: 'cover', display: 'block' }}
          />
          <div style={{
            position: 'absolute', inset: 0,
            background: 'linear-gradient(to top, var(--bg, #0b0b0d) 2%, rgba(0,0,0,0.15) 55%)',
          }} />
          <button type="button" onClick={close} style={{
            position: 'absolute', top: 14, left: 14, width: 34, height: 34, borderRadius: 10,
            background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(6px)',
            border: '1px solid rgba(255,255,255,0.18)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
          }}>
            <ArrowLeft size={16} />
          </button>
        </div>

        <div style={{ padding: '4px 18px 30px' }}>
          <h2 style={{ fontSize: 24, fontWeight: 900, color: 'var(--text)', margin: '0 0 8px' }}>
            Mino Game
          </h2>

          {/* Upper tags */}
          <div style={{ display: 'flex', gap: 7, marginBottom: 14, flexWrap: 'wrap' }}>
            {UPPER_TAGS.map(t => (
              <span key={t} style={{
                fontSize: 11, fontWeight: 800, padding: '4px 11px', borderRadius: 8,
                background: 'var(--surface2)', border: '1px solid var(--border)',
                color: 'var(--text-dim)',
              }}>{t}</span>
            ))}
            {stageDef && !state?.completed && (
              <span style={{
                fontSize: 11, fontWeight: 800, padding: '4px 11px', borderRadius: 8,
                background: 'rgba(193,18,31,0.14)', border: `1px solid ${MINO_ACCENT}`,
                color: MINO_ACCENT,
              }}>{stageDef.name}</span>
            )}
          </div>

          {/* Window countdown */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 9,
            padding: '11px 14px', borderRadius: 12, marginBottom: 16,
            background: state?.isOpen ? 'rgba(193,18,31,0.1)' : 'var(--surface2)',
            border: `1px solid ${state?.isOpen ? 'rgba(193,18,31,0.35)' : 'var(--border)'}`,
          }}>
            <Clock size={15} color={state?.isOpen ? MINO_ACCENT : 'var(--text-dim)'} />
            <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>
              {state?.isOpen ? 'Open now' : 'Closed'}
            </span>
            <span style={{ fontSize: 12, color: 'var(--text-dim)', marginLeft: 'auto', fontVariantNumeric: 'tabular-nums' }}>
              {loading ? '—' : state?.isOpen
                ? `Closes in ${formatDuration(secondsToBoundary)}`
                : `Opens in ${formatDuration(secondsToBoundary)}`}
            </span>
          </div>

          <p style={{ fontSize: 13.5, lineHeight: 1.62, color: 'var(--text-dim)', margin: '0 0 16px' }}>
            A series of deadly games. Which can you win? Go far to earn a huge amount of XP —
            fail, and you get kicked with no rewards.
          </p>

          {/* Tags */}
          <div style={{ display: 'flex', gap: 7, marginBottom: 20, flexWrap: 'wrap' }}>
            {TAGS.map(t => (
              <span key={t} style={{
                fontSize: 11, fontWeight: 700, padding: '5px 11px', borderRadius: 999,
                background: 'var(--surface)', border: '1px solid var(--border)',
                color: 'var(--text-dim)',
              }}>{t}</span>
            ))}
          </div>

          {/* Play */}
          <button
            type="button"
            disabled={!status.canPlay}
            onClick={(e) => { if (!status.canPlay) return; ripple(e); onPlay() }}
            style={{
              width: '100%', padding: '15px 0', borderRadius: 14, border: 'none',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              fontSize: 15, fontWeight: 900,
              cursor: status.canPlay ? 'pointer' : 'default',
              background: status.canPlay ? MINO_ACCENT : 'var(--surface2)',
              color: status.canPlay ? '#fff' : 'var(--text-dim)',
              marginBottom: 8,
            }}
          >
            {status.canPlay ? <Play size={16} /> : <Lock size={15} />}
            {status.label}
          </button>
          {status.sub && (
            <p style={{ fontSize: 12, color: 'var(--text-dim)', textAlign: 'center', margin: '0 0 26px' }}>
              {status.sub}
            </p>
          )}

          {/* Leaderboard */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 12 }}>
            <Trophy size={15} color={MINO_ACCENT} />
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
              Who's still standing
            </p>
          </div>

          {board === null ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{ height: 52, borderRadius: 12, background: 'var(--surface2)' }} />
              ))}
            </div>
          ) : board.length === 0 ? (
            <div style={{
              padding: '22px 16px', borderRadius: 12, textAlign: 'center',
              background: 'var(--surface2)', border: '1px solid var(--border)',
            }}>
              <Skull size={20} color="var(--text-dim)" style={{ marginBottom: 8 }} />
              <p style={{ fontSize: 12.5, color: 'var(--text-dim)', margin: 0 }}>
                Nobody has survived a stage yet. Be the first.
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {board.map((row, i) => (
                <div key={row.userId} style={{
                  display: 'flex', alignItems: 'center', gap: 11,
                  padding: '9px 13px', borderRadius: 12,
                  background: 'var(--surface2)',
                  border: `1px solid ${row.completed ? 'rgba(193,18,31,0.4)' : 'var(--border)'}`,
                }}>
                  <span style={{
                    fontSize: 12, fontWeight: 900, color: 'var(--text-dim)',
                    width: 16, textAlign: 'center', flexShrink: 0,
                  }}>{i + 1}</span>
                  <Avatar src={row.avatar} name={row.displayName || row.username} userId={row.userId} size={32} />
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <p style={{
                      fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: 0,
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                    }}>
                      {row.displayName || row.username}
                    </p>
                    <p style={{ fontSize: 11, color: 'var(--text-dim)', margin: 0 }}>
                      {row.completed ? 'Survivor' : `Stage ${row.stage} reached`}
                      {row.totalSeconds > 0 && ` · ${formatDuration(row.totalSeconds)}`}
                    </p>
                  </div>
                  {row.completed && <span style={{ fontSize: 15 }}>👑</span>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body,
  )
}
