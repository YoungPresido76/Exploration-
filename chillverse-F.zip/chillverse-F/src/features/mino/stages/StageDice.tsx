// src/features/mino/stages/StageDice.tsx
//
// Stage 1 — "Beginner". Three rounds. The AI rolls a die out of sight; the
// player picks the result from three options inside five seconds.
//
// The roll is generated at the START of the round and never rendered until
// the player has committed, which is the whole tension of the stage. The
// animation on screen is decorative: it cycles faces at random and has no
// relationship to the stored answer.
import { useEffect, useMemo, useRef, useState } from 'react'
import { ripple } from '../../../shared/lib/ripple'
import { MINO_ACCENT, MINO_STAGES, shuffle } from '../minoConfig'
import { useCountdown } from '../useMino'
import { StageHeader, type StageProps } from './StageKit'

const DICE_FACES = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
const STAGE = MINO_STAGES[1]
const ROLL_MS = 1400

interface Round {
  answer: number          // 1..6
  options: number[]       // 3 values, one of which is `answer`
}

function makeRound(): Round {
  const answer = 1 + Math.floor(Math.random() * 6)
  const pool = [1, 2, 3, 4, 5, 6].filter(n => n !== answer)
  const decoys = shuffle(pool).slice(0, 2)
  return { answer, options: shuffle([answer, ...decoys]) }
}

export default function StageDice({ onWin, onLose }: StageProps) {
  const [round, setRound] = useState(0)
  const [rolling, setRolling] = useState(true)
  const [face, setFace] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const startedAt = useRef(Date.now())

  // Regenerated per round. useMemo keyed on `round` means the answer is
  // fixed the moment the round begins — it is never re-rolled in response
  // to what the player taps.
  const current = useMemo(() => makeRound(), [round])

  // Decorative face cycling while "rolling".
  useEffect(() => {
    setRolling(true)
    setPicked(null)
    const spin = setInterval(() => setFace(Math.floor(Math.random() * 6)), 90)
    const stop = setTimeout(() => { clearInterval(spin); setRolling(false) }, ROLL_MS)
    return () => { clearInterval(spin); clearTimeout(stop) }
  }, [round])

  const elapsed = () => Math.round((Date.now() - startedAt.current) / 1000)

  // The clock only runs once the roll animation has settled and the options
  // are actually tappable — starting it during the animation would eat most
  // of a five-second round before the player could act.
  const remaining = useCountdown(
    STAGE.seconds,
    round,
    () => { if (picked === null) onLose('Too slow. The dice waited for no one.', elapsed()) },
    rolling,
  )

  function choose(n: number) {
    if (picked !== null || rolling) return
    setPicked(n)

    if (n !== current.answer) {
      setTimeout(() => onLose(`It was a ${current.answer}. You guessed ${n}.`, elapsed()), 900)
      return
    }
    setTimeout(() => {
      if (round + 1 >= STAGE.rounds) onWin(elapsed())
      else setRound(r => r + 1)
    }, 800)
  }

  const revealed = picked !== null

  return (
    <div>
      <StageHeader
        label="Stage 1 · Beginner" round={round} rounds={STAGE.rounds}
        remaining={rolling ? STAGE.seconds : remaining} total={STAGE.seconds}
      />

      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        padding: '30px 0 34px',
      }}>
        <div style={{
          fontSize: 88, lineHeight: 1,
          color: revealed
            ? (picked === current.answer ? 'var(--accent, #3ecf8e)' : MINO_ACCENT)
            : 'var(--text)',
          filter: rolling ? 'blur(1px)' : 'none',
          transform: rolling ? 'rotate(-6deg)' : 'none',
          transition: 'transform 160ms, color 200ms',
        }}>
          {revealed ? DICE_FACES[current.answer - 1] : DICE_FACES[face]}
        </div>
        <p style={{
          fontSize: 13, color: 'var(--text-dim)', margin: '16px 0 0', textAlign: 'center',
        }}>
          {rolling ? 'The AI is rolling…' : revealed ? '' : 'What number was it?'}
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {current.options.map(n => {
          const isPicked = picked === n
          const isAnswer = revealed && n === current.answer
          return (
            <button
              key={n}
              type="button"
              disabled={rolling || revealed}
              onClick={(e) => { ripple(e); choose(n) }}
              style={{
                padding: '20px 0', borderRadius: 16, cursor: rolling ? 'default' : 'pointer',
                fontSize: 26, fontWeight: 900,
                background: isAnswer ? 'rgba(62,207,142,0.16)'
                  : isPicked ? 'rgba(193,18,31,0.18)' : 'var(--surface2)',
                border: `1px solid ${isAnswer ? 'var(--accent, #3ecf8e)' : isPicked ? MINO_ACCENT : 'var(--border)'}`,
                color: 'var(--text)',
                opacity: rolling ? 0.4 : 1,
                transition: 'opacity 200ms, background 200ms, border-color 200ms',
              }}
            >
              {n}
            </button>
          )
        })}
      </div>
    </div>
  )
}
