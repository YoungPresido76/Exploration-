// src/features/mino/stages/StageGrid.tsx
//
// Stage 3 — "Gambler". One round, no second chances. Twenty face-down cards
// hide three diamonds and four bombs; the player gets four opens and ten
// seconds. Find all three diamonds to survive. Touch a bomb and it ends
// immediately, mid-round.
//
// Ten seconds rather than the six originally specced: four taps in six
// seconds on a twenty-card grid leaves no time to even read the board, and
// the stage is already brutal on the odds alone.
import { useMemo, useRef, useState } from 'react'
import { ripple } from '../../../shared/lib/ripple'
import {
  MINO_ACCENT, MINO_GRID_BOMBS, MINO_GRID_DIAMONDS, MINO_GRID_PICKS,
  MINO_GRID_SIZE, MINO_STAGES, shuffle,
} from '../minoConfig'
import { useCountdown } from '../useMino'
import { StageHeader, type StageProps } from './StageKit'

const STAGE = MINO_STAGES[3]
type Cell = 'diamond' | 'bomb' | 'blank'

function makeGrid(): Cell[] {
  const cells: Cell[] = [
    ...Array<Cell>(MINO_GRID_DIAMONDS).fill('diamond'),
    ...Array<Cell>(MINO_GRID_BOMBS).fill('bomb'),
    ...Array<Cell>(MINO_GRID_SIZE - MINO_GRID_DIAMONDS - MINO_GRID_BOMBS).fill('blank'),
  ]
  return shuffle(cells)
}

export default function StageGrid({ onWin, onLose }: StageProps) {
  const grid = useMemo(() => makeGrid(), [])
  const [opened, setOpened] = useState<number[]>([])
  const [dead, setDead] = useState(false)
  const startedAt = useRef(Date.now())

  const found = opened.filter(i => grid[i] === 'diamond').length
  const picksLeft = MINO_GRID_PICKS - opened.length
  const elapsed = () => Math.round((Date.now() - startedAt.current) / 1000)

  const remaining = useCountdown(
    STAGE.seconds,
    'grid',
    () => onLose('Out of time. The grid keeps its diamonds.', elapsed()),
    dead,
  )

  function open(i: number) {
    if (dead || opened.includes(i) || picksLeft <= 0) return
    const next = [...opened, i]
    setOpened(next)

    if (grid[i] === 'bomb') {
      setDead(true)
      setTimeout(() => onLose('You died!', elapsed()), 1200)
      return
    }

    const diamonds = next.filter(n => grid[n] === 'diamond').length
    if (diamonds >= MINO_GRID_DIAMONDS) {
      setTimeout(() => onWin(elapsed()), 700)
      return
    }
    if (next.length >= MINO_GRID_PICKS) {
      setDead(true)
      setTimeout(() => onLose(`Four cards, ${diamonds} diamond${diamonds === 1 ? '' : 's'}. Not enough.`, elapsed()), 1000)
    }
  }

  return (
    <div>
      <StageHeader
        label="Stage 3 · Gambler" round={0} rounds={1}
        remaining={remaining} total={STAGE.seconds}
      />

      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        <Stat label="Diamonds" value={`${found}/${MINO_GRID_DIAMONDS}`} />
        <Stat label="Opens left" value={`${Math.max(0, picksLeft)}`} />
      </div>

      {dead && (
        <p style={{
          fontSize: 17, fontWeight: 900, color: MINO_ACCENT,
          textAlign: 'center', margin: '0 0 16px', letterSpacing: 0.4,
        }}>
          You died!
        </p>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
        {grid.map((cell, i) => {
          const isOpen = opened.includes(i)
          const isBomb = isOpen && cell === 'bomb'
          const isDiamond = isOpen && cell === 'diamond'
          return (
            <button
              key={i}
              type="button"
              disabled={dead || isOpen || picksLeft <= 0}
              onClick={(e) => { ripple(e); open(i) }}
              style={{
                aspectRatio: '1/1', borderRadius: 12, fontSize: 22,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: dead || isOpen ? 'default' : 'pointer',
                background: isBomb ? 'rgba(193,18,31,0.22)'
                  : isDiamond ? 'rgba(56,189,248,0.18)'
                  : isOpen ? 'var(--surface)' : 'var(--surface2)',
                border: `1px solid ${isBomb ? MINO_ACCENT : isDiamond ? '#38bdf8' : 'var(--border)'}`,
                color: 'var(--text-dim)',
                transition: 'background 200ms, border-color 200ms',
              }}
            >
              {isOpen ? (cell === 'bomb' ? '💣' : cell === 'diamond' ? '💎' : '·') : ''}
            </button>
          )
        })}
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div style={{
      flex: 1, padding: '10px 14px', borderRadius: 12,
      background: 'var(--surface2)', border: '1px solid var(--border)',
    }}>
      <p style={{
        fontSize: 10, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase',
        color: 'var(--text-dim)', margin: '0 0 3px',
      }}>{label}</p>
      <p style={{ fontSize: 16, fontWeight: 900, color: 'var(--text)', margin: 0 }}>{value}</p>
    </div>
  )
}
