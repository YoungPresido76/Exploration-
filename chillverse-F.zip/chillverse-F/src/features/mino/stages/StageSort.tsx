// src/features/mino/stages/StageSort.tsx
//
// Stage 2 — "Sorter". Three rounds. Each round scrambles six words drawn
// from four categories; the player taps a word, then taps its category.
//
// The clock is SIX SECONDS PER WORD, not per board. Six seconds for the
// whole board is twelve taps in six seconds, which is not a difficulty
// curve, it's a wall. Every successful placement resets it.
import { useMemo, useRef, useState } from 'react'
import { Check } from 'lucide-react'
import { ripple } from '../../../shared/lib/ripple'
import {
  MINO_ACCENT, MINO_CATEGORIES, MINO_STAGES, MINO_WORDS,
  pickRandom, shuffle, type MinoCategory,
} from '../minoConfig'
import { useCountdown } from '../useMino'
import { StageHeader, type StageProps } from './StageKit'

const STAGE = MINO_STAGES[2]
const WORDS_PER_ROUND = 6

interface Item { word: string; category: MinoCategory }

/**
 * Six words spanning at least three categories, no duplicates. Drawn fresh
 * every round from a bank of ~75 words, so two players on the same night
 * are very unlikely to see the same board.
 */
function makeBoard(): Item[] {
  const items: Item[] = []
  const used = new Set<string>()
  // Seed one from each category first so a board can never be six words of
  // the same kind (which would make the category taps meaningless).
  for (const cat of MINO_CATEGORIES) {
    const word = pickRandom(MINO_WORDS[cat])
    if (used.has(word)) continue
    used.add(word)
    items.push({ word, category: cat })
  }
  while (items.length < WORDS_PER_ROUND) {
    const cat = pickRandom([...MINO_CATEGORIES])
    const word = pickRandom(MINO_WORDS[cat])
    if (used.has(word)) continue
    used.add(word)
    items.push({ word, category: cat })
  }
  return shuffle(items).slice(0, WORDS_PER_ROUND)
}

export default function StageSort({ onWin, onLose }: StageProps) {
  const [round, setRound] = useState(0)
  const [placed, setPlaced] = useState<string[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [wrong, setWrong] = useState<string | null>(null)
  const startedAt = useRef(Date.now())

  const board = useMemo(() => makeBoard(), [round])
  const elapsed = () => Math.round((Date.now() - startedAt.current) / 1000)

  // Keyed on the placement count as well as the round, so the clock restarts
  // on every correct answer rather than running down across the whole board.
  const remaining = useCountdown(
    STAGE.seconds,
    `${round}:${placed.length}`,
    () => onLose('The clock beat you to it.', elapsed()),
  )

  function tapWord(word: string) {
    if (placed.includes(word)) return
    setSelected(s => (s === word ? null : word))
  }

  function tapCategory(cat: MinoCategory) {
    if (!selected) return
    const item = board.find(i => i.word === selected)
    if (!item) return

    if (item.category !== cat) {
      // One wrong placement ends the night — there is no partial credit in
      // this event, and a retry would make the six-second clock pointless.
      setWrong(selected)
      setTimeout(() => onLose(`"${item.word}" was not ${cat}.`, elapsed()), 850)
      return
    }

    const next = [...placed, selected]
    setPlaced(next)
    setSelected(null)

    if (next.length >= WORDS_PER_ROUND) {
      setTimeout(() => {
        if (round + 1 >= STAGE.rounds) {
          onWin(elapsed())
        } else {
          setPlaced([])
          setRound(r => r + 1)
        }
      }, 550)
    }
  }

  return (
    <div>
      <StageHeader
        label="Stage 2 · Sorter" round={round} rounds={STAGE.rounds}
        remaining={remaining} total={STAGE.seconds}
      />

      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '10px 14px', borderRadius: 12, background: 'var(--surface2)',
        border: '1px solid var(--border)', marginBottom: 18,
      }}>
        <span style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>
          {placed.length}/{WORDS_PER_ROUND} sorted
        </span>
        <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>
          {selected ? 'Now pick its category' : 'Tap a word'}
        </span>
      </div>

      {/* Words */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 24 }}>
        {board.map(item => {
          const isPlaced = placed.includes(item.word)
          const isSelected = selected === item.word
          const isWrong = wrong === item.word
          return (
            <button
              key={item.word}
              type="button"
              disabled={isPlaced}
              onClick={(e) => { ripple(e); tapWord(item.word) }}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '11px 15px', borderRadius: 12, fontSize: 14, fontWeight: 700,
                cursor: isPlaced ? 'default' : 'pointer',
                background: isWrong ? 'rgba(193,18,31,0.2)'
                  : isPlaced ? 'rgba(62,207,142,0.12)'
                  : isSelected ? 'var(--accent, #3ecf8e)' : 'var(--surface2)',
                border: `1px solid ${isWrong ? MINO_ACCENT : isPlaced ? 'rgba(62,207,142,0.4)' : isSelected ? 'transparent' : 'var(--border)'}`,
                color: isSelected ? '#06251a' : isPlaced ? 'var(--text-dim)' : 'var(--text)',
                opacity: isPlaced ? 0.55 : 1,
                transition: 'background 160ms, color 160ms, opacity 160ms',
              }}
            >
              {isPlaced && <Check size={13} />}
              {item.word}
            </button>
          )
        })}
      </div>

      {/* Categories */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
        {MINO_CATEGORIES.map(cat => (
          <button
            key={cat}
            type="button"
            disabled={!selected}
            onClick={(e) => { ripple(e); tapCategory(cat) }}
            style={{
              padding: '18px 10px', borderRadius: 14, fontSize: 14, fontWeight: 800,
              cursor: selected ? 'pointer' : 'default',
              background: 'var(--surface)',
              border: `1px solid ${selected ? MINO_ACCENT : 'var(--border)'}`,
              color: 'var(--text)',
              opacity: selected ? 1 : 0.45,
              transition: 'opacity 200ms, border-color 200ms',
            }}
          >
            {cat}
          </button>
        ))}
      </div>
    </div>
  )
}
