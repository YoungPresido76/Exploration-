// src/features/mino/stages/StageMath.tsx
//
// Stage 4 — "Final". Four equations, fifteen seconds each, typed answers.
//
// Typed rather than multiple choice on purpose: this is the last thing
// standing between a player and 590 diamonds, and a three-option tap would
// hand a 1-in-3 chance to someone who can't do the maths at all.
//
// Every generated equation resolves to a whole number. A stage that can
// eliminate a player over a rounding convention would be a bug, not a
// difficulty setting.
import { useMemo, useRef, useState } from 'react'
import { ripple } from '../../../shared/lib/ripple'
import { MINO_ACCENT, MINO_STAGES } from '../minoConfig'
import { useCountdown } from '../useMino'
import { StageHeader, type StageProps } from './StageKit'

const STAGE = MINO_STAGES[4]

interface Equation { text: string; answer: number }

function randInt(min: number, max: number): number {
  return min + Math.floor(Math.random() * (max - min + 1))
}

/**
 * Difficulty ramps with the round index — the fourth question is meaningfully
 * harder than the first, so a player who scrapes through early doesn't coast.
 */
function makeEquation(round: number): Equation {
  switch (round) {
    case 0: {
      // a × b + c
      const a = randInt(12, 19), b = randInt(6, 9), c = randInt(20, 90)
      return { text: `${a} × ${b} + ${c}`, answer: a * b + c }
    }
    case 1: {
      // (a + b) × c − d
      const a = randInt(14, 28), b = randInt(9, 22), c = randInt(4, 8), d = randInt(15, 60)
      return { text: `(${a} + ${b}) × ${c} − ${d}`, answer: (a + b) * c - d }
    }
    case 2: {
      // a² − b × c. Built from a square so the answer stays clean.
      const a = randInt(11, 19), b = randInt(7, 13), c = randInt(4, 9)
      return { text: `${a}² − ${b} × ${c}`, answer: a * a - b * c }
    }
    default: {
      // (a × b) ÷ c + d — c is a factor of the product by construction, so
      // the division is always exact.
      const c = randInt(3, 9), q = randInt(11, 24), b = randInt(4, 9)
      const a = c * q
      const d = randInt(25, 95)
      return { text: `(${a} × ${b}) ÷ ${c} + ${d}`, answer: (a * b) / c + d }
    }
  }
}

export default function StageMath({ onWin, onLose }: StageProps) {
  const [round, setRound] = useState(0)
  const [value, setValue] = useState('')
  const [locked, setLocked] = useState(false)
  const startedAt = useRef(Date.now())

  const eq = useMemo(() => makeEquation(round), [round])
  const elapsed = () => Math.round((Date.now() - startedAt.current) / 1000)

  const remaining = useCountdown(
    STAGE.seconds,
    round,
    () => { if (!locked) onLose(`Time. The answer was ${eq.answer}.`, elapsed()) },
    locked,
  )

  function submit() {
    if (locked || value.trim() === '') return
    setLocked(true)

    if (Number(value.trim()) !== eq.answer) {
      setTimeout(() => onLose(`Wrong. ${eq.text} = ${eq.answer}.`, elapsed()), 900)
      return
    }
    setTimeout(() => {
      if (round + 1 >= STAGE.rounds) {
        onWin(elapsed())
      } else {
        setValue('')
        setLocked(false)
        setRound(r => r + 1)
      }
    }, 700)
  }

  const correct = locked && Number(value.trim()) === eq.answer

  return (
    <div>
      <StageHeader
        label="Stage 4 · Final" round={round} rounds={STAGE.rounds}
        remaining={remaining} total={STAGE.seconds}
      />

      <div style={{
        padding: '38px 16px', borderRadius: 18, textAlign: 'center',
        background: 'var(--surface2)', border: '1px solid var(--border)',
        marginBottom: 18,
      }}>
        <p style={{
          fontSize: 30, fontWeight: 900, color: 'var(--text)', margin: 0,
          letterSpacing: 0.5, fontVariantNumeric: 'tabular-nums',
        }}>
          {eq.text}
        </p>
      </div>

      <input
        type="text"
        inputMode="numeric"
        pattern="-?[0-9]*"
        autoFocus
        value={value}
        disabled={locked}
        onChange={e => setValue(e.target.value.replace(/[^0-9-]/g, ''))}
        onKeyDown={e => { if (e.key === 'Enter') submit() }}
        placeholder="Your answer"
        style={{
          width: '100%', padding: '16px 18px', borderRadius: 14,
          fontSize: 20, fontWeight: 800, textAlign: 'center',
          fontVariantNumeric: 'tabular-nums',
          background: 'var(--surface)',
          border: `1px solid ${locked ? (correct ? 'var(--accent, #3ecf8e)' : MINO_ACCENT) : 'var(--border)'}`,
          color: 'var(--text)', outline: 'none', marginBottom: 12,
          transition: 'border-color 200ms',
        }}
      />

      <button
        type="button"
        disabled={locked || value.trim() === ''}
        onClick={(e) => { ripple(e); submit() }}
        style={{
          width: '100%', padding: '15px 0', borderRadius: 14, border: 'none',
          fontSize: 15, fontWeight: 900, cursor: locked ? 'default' : 'pointer',
          background: MINO_ACCENT, color: '#fff',
          opacity: locked || value.trim() === '' ? 0.45 : 1,
          transition: 'opacity 200ms',
        }}
      >
        Lock it in
      </button>
    </div>
  )
}
