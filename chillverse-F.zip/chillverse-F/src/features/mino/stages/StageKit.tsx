// src/features/mino/stages/StageKit.tsx
// Small presentational pieces shared by all four Mino stages, so each stage
// file holds only its own game logic.
import { MINO_ACCENT } from '../minoConfig'

/** The contract every stage implements. Stages never talk to the server. */
export interface StageProps {
  /** All rounds survived. The shell handles payout + the win modal. */
  onWin: (secondsElapsed: number) => void
  /** Eliminated. `reason` is shown in red on the death screen. */
  onLose: (reason: string, secondsElapsed: number) => void
}

export function TimerRing({ remaining, total }: { remaining: number; total: number }) {
  const pct = total > 0 ? remaining / total : 0
  const urgent = remaining <= 2
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '8px 14px', borderRadius: 999,
      background: urgent ? 'rgba(193,18,31,0.18)' : 'var(--surface2)',
      border: `1px solid ${urgent ? MINO_ACCENT : 'var(--border)'}`,
      transition: 'background 200ms, border-color 200ms',
    }}>
      <div style={{ position: 'relative', width: 28, height: 28, flexShrink: 0 }}>
        <svg width={28} height={28} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={14} cy={14} r={12} fill="none" stroke="var(--border)" strokeWidth={3} />
          <circle
            cx={14} cy={14} r={12} fill="none"
            stroke={urgent ? MINO_ACCENT : 'var(--accent, #3ecf8e)'}
            strokeWidth={3} strokeLinecap="round"
            strokeDasharray={2 * Math.PI * 12}
            strokeDashoffset={2 * Math.PI * 12 * (1 - pct)}
            style={{ transition: 'stroke-dashoffset 900ms linear' }}
          />
        </svg>
      </div>
      <span style={{
        fontSize: 15, fontWeight: 900, fontVariantNumeric: 'tabular-nums',
        color: urgent ? MINO_ACCENT : 'var(--text)',
      }}>
        {remaining}s
      </span>
    </div>
  )
}

/** "Round 2 / 3" as filled pips. */
export function RoundPips({ current, total }: { current: number; total: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {Array.from({ length: total }).map((_, i) => (
        <span key={i} style={{
          width: i === current ? 18 : 7, height: 7, borderRadius: 999,
          background: i < current ? 'var(--accent, #3ecf8e)' : i === current ? MINO_ACCENT : 'var(--border)',
          transition: 'width 220ms, background 220ms',
        }} />
      ))}
    </div>
  )
}

/** Header row every stage shares: round progress on the left, clock on the right. */
export function StageHeader({
  round, rounds, remaining, total, label,
}: { round: number; rounds: number; remaining: number; total: number; label: string }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 12, marginBottom: 22,
    }}>
      <div>
        <p style={{
          fontSize: 10, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase',
          color: 'var(--text-dim)', margin: '0 0 7px',
        }}>
          {label}
        </p>
        <RoundPips current={round} total={rounds} />
      </div>
      <TimerRing remaining={remaining} total={total} />
    </div>
  )
}
