// src/features/mino/minoConfig.ts
//
// Static config for Mino Games. Everything here is presentation-layer only —
// the authoritative copies of the window hours, the XP table and the stage
// count all live in Postgres (migration mino_games_foundation), because a
// player who can edit
// these values in devtools could otherwise pay themselves.
//
// The numbers below are duplicated purely so the UI can render "you'll earn
// 400 XP" before the server has confirmed anything. If the two ever drift,
// the server wins and the UI is just briefly wrong.

export const MINO_GAME_KEY = 'mino_games'

/** Matches mino_is_open() in the migration. Display only — never gating. */
export const MINO_TZ_LABEL = 'WAT'
export const MINO_WINDOW_LABEL = '7:00 PM – 1:00 AM'

export const MINO_MODAL_IMAGE =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/announcement-images/a9d32f8f-de97-4efc-9f19-aa82ac241988.jpg'

/** Share card art for the mino_stage highlight. */
export const MINO_SHARE_PNG =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/Minocard.png'

/**
 * Horror sting, played once when the Mino modal opens.
 *
 * ── WHERE TO PUT THE FILE ──────────────────────────────────────────────
 *   public/sounds/mino-horror.mp3
 *
 * It sits next to the existing praise-treasure.wav / praise-bling.wav. Keep
 * the extension honest — if the file is really a .wav, name it .wav here and
 * on disk rather than relabelling it, since renaming does not convert it.
 * Keep it short (1–3s) and small (<150KB): this downloads every time the
 * modal opens, and a multi-megabyte ambience loop is a cruel thing to do to
 * someone on mobile data.
 */
export const MINO_HORROR_SRC = '/sounds/mino-horror.mp3'

/**
 * Looping ambience, played under the modal while it stays open.
 *
 * ── WHERE TO PUT THE FILE ──────────────────────────────────────────────
 *   public/sounds/mino-horror-loop.mp3
 *
 * Deliberately a separate small file from the sting above rather than one
 * long track. A single 2MB one-shot has to finish downloading before it
 * makes any sound at all, so the scare arrives after the player has
 * already read half the leaderboard.
 */
export const MINO_AMBIENCE_SRC = '/sounds/mino-horror-loop.mp3'

export const MINO_ACCENT = '#c1121f'

// ── Stages ──────────────────────────────────────────────────────────────
export type MinoStageId = 1 | 2 | 3 | 4

export interface MinoStageDef {
  id: MinoStageId
  name: string
  /** Rounds inside the stage. All must be cleared to survive the night. */
  rounds: number
  /** Seconds on the clock per round. */
  seconds: number
  /** Mirrors the v_rewards array in mino_finish_stage(). Display only. */
  xp: number
  /** The AI's typewritten briefing before the first round. */
  briefing: string
}

export const MINO_STAGES: Record<MinoStageId, MinoStageDef> = {
  1: {
    id: 1,
    name: 'Beginner',
    rounds: 3,
    seconds: 5,
    xp: 400,
    briefing: 'In this first round, you must guess what dice number showed up when the AI rolled it.',
  },
  2: {
    id: 2,
    name: 'Sorter',
    rounds: 3,
    // Per word, not per board — six words in six seconds total is twelve taps
    // in six seconds, which nobody clears. The clock resets on each placement.
    seconds: 6,
    xp: 800,
    briefing: 'Six words. Four categories. Six seconds each — the clock resets every time you place one. Sort them all, or the night ends here.',
  },
  3: {
    id: 3,
    name: 'Gambler',
    rounds: 1,
    seconds: 10,
    xp: 1500,
    briefing: 'Three diamonds are hidden in this grid. You get four cards. Some of the others are bombs. Choose carefully.',
  },
  4: {
    id: 4,
    name: 'Final',
    rounds: 4,
    seconds: 15,
    xp: 2500,
    briefing: 'Last stage. Four equations, fifteen seconds each. No hints, no second guesses. Solve them and you walk out of here.',
  },
}

export const MINO_FINAL_STAGE: MinoStageId = 4
export const MINO_COMPLETION_DIAMONDS = 590

/** Stage 2's word bank. Each round draws 6 words spanning several categories. */
export const MINO_CATEGORIES = ['Food', 'Living thing', 'Country', 'AI'] as const
export type MinoCategory = (typeof MINO_CATEGORIES)[number]

// Kept generously large so two players on the same night are unlikely to
// see the same board — the whole event is one shot per night, and "my
// friend already told me the answers" would gut it.
export const MINO_WORDS: Record<MinoCategory, string[]> = {
  Food: [
    'Egg', 'Jollof', 'Bread', 'Mango', 'Suya', 'Pizza', 'Rice', 'Plantain',
    'Yam', 'Pepper soup', 'Noodles', 'Beans', 'Chocolate', 'Akara', 'Moi moi',
    'Pounded yam', 'Sushi', 'Pancake', 'Garri', 'Chin chin',
  ],
  'Living thing': [
    'Tree', 'Dog', 'Lion', 'Grass', 'Eagle', 'Goat', 'Shark', 'Bamboo',
    'Snail', 'Cactus', 'Whale', 'Mosquito', 'Palm tree', 'Tortoise', 'Frog',
    'Butterfly', 'Mushroom', 'Camel', 'Parrot', 'Seaweed',
  ],
  Country: [
    'Canada', 'Nigeria', 'Japan', 'Brazil', 'Ghana', 'Kenya', 'France', 'Egypt',
    'Mexico', 'Norway', 'Peru', 'India', 'Chile', 'Morocco', 'Vietnam',
    'Portugal', 'Senegal', 'Iceland', 'Cuba', 'Nepal',
  ],
  AI: [
    'Claude', 'Halo', 'ChatGPT', 'Gemini', 'Copilot', 'Alexa', 'Siri',
    'Midjourney', 'Perplexity', 'Grok', 'DeepSeek', 'Llama', 'Mistral',
    'Bard', 'Watson', 'Cortana',
  ],
}

// ── Stage 3 grid ────────────────────────────────────────────────────────
export const MINO_GRID_SIZE = 20      // total cards on the board
export const MINO_GRID_DIAMONDS = 3   // must find all of these
export const MINO_GRID_BOMBS = 4      // instant death
export const MINO_GRID_PICKS = 4      // free opens

// ── Helpers ─────────────────────────────────────────────────────────────

/** "1h 24m" / "6m 12s" / "48s" — used for countdowns and survival times. */
export function formatDuration(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${sec}s`
  return `${sec}s`
}

/** Fisher–Yates. Returns a new array; does not mutate the input. */
export function shuffle<T>(input: T[]): T[] {
  const arr = [...input]
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr
}

export function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}
