// src/features/mino/minoApi.ts
//
// Thin wrapper over the Mino RPCs (migration mino_games_foundation). Every
// rule the event has — the 7pm–1am WAT window, one attempt a night, which
// stage you're allowed to attempt, the XP, the diamonds — is decided
// server-side. Nothing in this file is a gate; it just relays what the
// server said.
//
// NOTE ON THE STAGE NUMBER: the client never tells the server which stage
// it just cleared. mino_finish_stage() reads that from mino_runs itself and
// reports only pass/fail, so a tampered client can't claim it beat Stage 4
// on its first night and collect the diamonds.

import { supabase } from '../../shared/lib/supabase'
import { createHighlight } from '../highlights/highlights'
import { MINO_GAME_KEY, MINO_STAGES, type MinoStageId } from './minoConfig'

export interface MinoState {
  /** The stage this player is allowed to attempt next (1–4). */
  stage: MinoStageId
  totalXp: number
  totalSeconds: number
  completed: boolean
  isOpen: boolean
  playedTonight: boolean
  /** True only when the event is open AND tonight's attempt is unspent. */
  canPlay: boolean
  /** Epoch ms of the next open/close flip — count down to this. */
  nextBoundary: number
  /**
   * Server time at the moment of the read, as epoch ms. The countdown is
   * driven from this plus elapsed local ticks rather than Date.now(), so a
   * device with a wrong clock still sees the right numbers.
   */
  serverNow: number
}

interface MinoStateRow {
  is_open: boolean
  server_now: string
  opens_at: string
  closes_at: string
  stage: number
  completed: boolean
  played_tonight: boolean
  total_xp: number
  total_seconds: number
}

export async function fetchMinoState(): Promise<MinoState | null> {
  const { data, error } = await supabase.rpc('mino_state').maybeSingle<MinoStateRow>()
  if (error || !data) {
    console.error('fetchMinoState error:', error)
    return null
  }

  // While open, the thing worth counting down to is closing time; while
  // closed, it's the next opening. mino_state() hands back both.
  const nextBoundary = data.is_open
    ? new Date(data.closes_at).getTime()
    : new Date(data.opens_at).getTime()

  return {
    stage: Math.min(Math.max(data.stage, 1), 4) as MinoStageId,
    totalXp: data.total_xp,
    totalSeconds: data.total_seconds,
    completed: data.completed,
    isOpen: data.is_open,
    playedTonight: data.played_tonight,
    canPlay: data.is_open && !data.played_tonight && !data.completed,
    nextBoundary,
    serverNow: new Date(data.server_now).getTime(),
  }
}

export interface MinoFinishResult {
  /** The stage now waiting — already advanced on a pass, reset to 1 on a fail. */
  stage: MinoStageId
  completed: boolean
  xpAwarded: number
  diamonds: number
  totalXp: number
  totalSeconds: number
  /**
   * False only when a Stage 1 attempt was lost — that stage is a pure
   * 1-in-3 guess, so losing it costs time rather than the whole night and
   * the player may go again until the window shuts. Every other outcome,
   * win or lose, ends the night.
   */
  nightBurned: boolean
}

interface MinoFinishRow {
  stage: number
  completed: boolean
  xp_awarded: number
  diamonds: number
  total_xp: number
  total_seconds: number
  night_burned: boolean
}

/**
 * Reports the outcome of tonight's attempt. Passing always ends the night;
 * so does failing anything above Stage 1. Check `nightBurned` in the result
 * rather than assuming — a lost Stage 1 leaves tonight's attempt unspent.
 *
 * The server re-checks the window and the one-a-night lock before paying
 * anything, so an error here is usually a legitimate refusal rather than a
 * bug: 'mino_closed' (the window shut mid-run), 'mino_already_played_tonight'
 * (a second tab got there first), 'mino_already_completed'.
 *
 * No game_sessions row is written from here — mino_finish_stage() inserts
 * it inside its own transaction, so doing it again would double-log the
 * play and inflate the Activity Goals counter.
 */
export async function finishMinoStage(
  passed: boolean,
  seconds: number,
): Promise<{ data: MinoFinishResult | null; error: string | null }> {
  const { data, error } = await supabase
    .rpc('mino_finish_stage', { p_passed: passed, p_seconds: Math.round(seconds) })
    .maybeSingle<MinoFinishRow>()

  if (error) {
    console.error('finishMinoStage error:', error)
    return { data: null, error: friendlyMinoError(error.message) }
  }
  if (!data) return { data: null, error: 'No response from server' }

  return {
    data: {
      stage: Math.min(Math.max(data.stage, 1), 4) as MinoStageId,
      completed: data.completed,
      xpAwarded: data.xp_awarded,
      diamonds: data.diamonds,
      totalXp: data.total_xp,
      totalSeconds: data.total_seconds,
      nightBurned: data.night_burned,
    },
    error: null,
  }
}

function friendlyMinoError(raw: string): string {
  if (/mino_closed/.test(raw)) return 'Mino closed while you were playing. Come back at 7pm.'
  if (/already_played_tonight/.test(raw)) return "You've already taken tonight's attempt."
  if (/already_completed/.test(raw)) return "You've already survived Mino Games."
  return 'Something went wrong saving your run.'
}

export interface MinoLeaderboardRow {
  userId: string
  username: string
  displayName: string | null
  avatar: string | null
  stage: number
  totalXp: number
  totalSeconds: number
  completed: boolean
}

export async function fetchMinoLeaderboard(limit = 20): Promise<MinoLeaderboardRow[]> {
  const { data, error } = await supabase.rpc('mino_leaderboard', { p_limit: limit })
  if (error || !data) {
    console.error('fetchMinoLeaderboard error:', error)
    return []
  }
  return (data as Array<{
    user_id: string; username: string; display_name: string | null; avatar: string | null
    stage: number; total_xp: number; total_seconds: number; completed: boolean
  }>).map(r => ({
    userId: r.user_id,
    username: r.username,
    displayName: r.display_name,
    avatar: r.avatar,
    stage: r.stage,
    totalXp: r.total_xp,
    totalSeconds: r.total_seconds,
    completed: r.completed,
  }))
}

/**
 * Posts the shareable highlight for a survived stage.
 *
 * The body deliberately omits the player's name — every highlight card and
 * the generated share PNG both render the author separately, so including
 * it here would print it twice ("Player X Player X passed…").
 *
 * dedupKey is per stage-number rather than per attempt: a player who fails
 * Stage 1 and re-clears it three weeks later shouldn't spam the feed with
 * the same milestone again.
 */
export async function shareMinoStage(userId: string, stage: MinoStageId, completed: boolean) {
  const stageName = MINO_STAGES[stage].name
  const body = completed
    ? 'Survived every round of Mino Games and walked out.'
    : `Passed the ${ordinal(stage)} round in Mino's Game — ${stageName} stage cleared.`

  return createHighlight({
    authorId: userId,
    kind: 'mino_stage',
    gameKey: MINO_GAME_KEY,
    body,
    value: stage,
    dedupKey: completed ? 'mino:complete' : `mino:stage:${stage}`,
  })
}

function ordinal(n: number): string {
  return ['first', 'second', 'third', 'fourth'][n - 1] ?? `${n}th`
}
