// src/features/mino/MinoRun.tsx
//
// The full-screen run: AI briefing → the stage itself → survived/eliminated.
//
// The shell owns every server call. Stages are pure games — they report a
// win or a loss and nothing else — which keeps the payout logic in one place
// and means a bug in a stage can't accidentally pay someone.
import { useEffect, useState } from 'react'
import { X, Share2, Clock } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { ripple } from '../../shared/lib/ripple'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { shareHighlight } from '../highlights/shareHighlight'
import { finishMinoStage, shareMinoStage } from './minoApi'
import {
  MINO_ACCENT, MINO_COMPLETION_DIAMONDS, MINO_STAGES,
  formatDuration, type MinoStageId,
} from './minoConfig'
import { useTypewriter } from './useMino'
import StageDice from './stages/StageDice'
import StageSort from './stages/StageSort'
import StageGrid from './stages/StageGrid'
import StageMath from './stages/StageMath'

type Phase = 'briefing' | 'playing' | 'won' | 'lost'

interface Props {
  stage: MinoStageId
  onExit: (outcome: 'won' | 'lost' | 'quit') => void
}

export default function MinoRun({ stage, onExit }: Props) {
  const { session } = useAuth()
  const userId = session?.user?.id ?? ''
  const { profile } = useProfile()

  const [phase, setPhase] = useState<Phase>('briefing')
  const [seconds, setSeconds] = useState(0)
  const [deathReason, setDeathReason] = useState('')
  const [xpAwarded, setXpAwarded] = useState(0)
  const [diamonds, setDiamonds] = useState(0)
  const [completedAll, setCompletedAll] = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)
  const [canRetryTonight, setCanRetryTonight] = useState(false)
  const [sharing, setSharing] = useState(false)
  const [shared, setShared] = useState(false)

  const def = MINO_STAGES[stage]
  const { shown, done } = useTypewriter(def.briefing)

  async function handleWin(secondsElapsed: number) {
    setSeconds(secondsElapsed)
    setPhase('won')
    const { data, error } = await finishMinoStage(true, secondsElapsed)
    if (error) { setSaveError(error); return }
    if (!data) return
    setXpAwarded(data.xpAwarded)
    setDiamonds(data.diamonds)
    setCompletedAll(data.completed)
    if (userId) shareMinoStage(userId, stage, data.completed).catch(console.error)
  }

  async function handleLose(reason: string, secondsElapsed: number) {
    setSeconds(secondsElapsed)
    setDeathReason(reason)
    setPhase('lost')
    // Losing Stage 1 is forgiven — it's a coin flip, so it costs time
    // rather than the night. The server decides; don't re-derive the rule
    // here or the two will drift apart.
    const { data } = await finishMinoStage(false, secondsElapsed)
    setCanRetryTonight(data ? !data.nightBurned : false)
  }

  async function handleShare() {
    if (!profile || sharing) return
    setSharing(true)
    try {
      await shareHighlight(
        {
          id: 'mino-local', author_id: userId, kind: 'mino_stage',
          game_key: 'mino_games', likes_count: 0, created_at: new Date().toISOString(),
          value: stage, map_id: null, badge_id: null, achievement_id: null,
          body: completedAll
            ? 'Survived every round of Mino Games and walked out.'
            : `passed ${ordinal(stage)} round in Mino's Game`,
        },
        profile.display_name || profile.username,
      )
      setShared(true)
    } catch (e) {
      console.error('Mino share failed:', e)
    } finally {
      setSharing(false)
    }
  }

  // Guard against a stray back-swipe mid-run being read as a quit: the
  // server has already burned the night either way once a stage resolves.
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = '' }
  }, [])

  const name = profile?.display_name || profile?.username || 'Player'

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 3000, overflowY: 'auto',
      background: 'radial-gradient(120% 80% at 50% 0%, #23070b 0%, var(--bg, #0b0b0d) 62%)',
    }}>
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '20px 18px 60px' }}>

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 8 }}>
          {phase !== 'playing' && (
            <button
              type="button"
              onClick={() => onExit(phase === 'won' ? 'won' : phase === 'lost' ? 'lost' : 'quit')}
              style={iconBtn}
            >
              <X size={17} />
            </button>
          )}
        </div>

        {/* ── Briefing ────────────────────────────────────────────── */}
        {phase === 'briefing' && (
          <div style={{ paddingTop: 40 }}>
            <p style={{
              fontSize: 10, fontWeight: 900, letterSpacing: 1.4, textTransform: 'uppercase',
              color: MINO_ACCENT, margin: '0 0 14px',
            }}>
              Stage {stage} · {def.name}
            </p>
            <p style={{
              fontSize: 19, lineHeight: 1.55, color: 'var(--text)', fontWeight: 600,
              margin: '0 0 8px', minHeight: 120,
            }}>
              {shown}
              <span style={{
                display: 'inline-block', width: 9, height: 20, marginLeft: 3,
                background: MINO_ACCENT, verticalAlign: 'text-bottom',
                animation: 'minoCaret 900ms steps(2) infinite',
              }} />
            </p>
            <p style={{ fontSize: 12.5, color: 'var(--text-dim)', margin: '0 0 30px' }}>
              {def.rounds} round{def.rounds === 1 ? '' : 's'} · {def.seconds}s each · {def.xp.toLocaleString()} XP if you survive
            </p>
            <button
              type="button"
              disabled={!done}
              onClick={(e) => { ripple(e); setPhase('playing') }}
              style={{ ...primaryBtn, opacity: done ? 1 : 0.4 }}
            >
              {done ? 'Begin' : '…'}
            </button>
          </div>
        )}

        {/* ── The stage ───────────────────────────────────────────── */}
        {phase === 'playing' && (
          <div style={{ paddingTop: 12 }}>
            {stage === 1 && <StageDice onWin={handleWin} onLose={handleLose} />}
            {stage === 2 && <StageSort onWin={handleWin} onLose={handleLose} />}
            {stage === 3 && <StageGrid onWin={handleWin} onLose={handleLose} />}
            {stage === 4 && <StageMath onWin={handleWin} onLose={handleLose} />}
          </div>
        )}

        {/* ── Survived ────────────────────────────────────────────── */}
        {phase === 'won' && (
          <div style={{ paddingTop: 30, textAlign: 'center' }}>
            <p style={{
              fontSize: 11, fontWeight: 900, letterSpacing: 1.4, textTransform: 'uppercase',
              color: 'var(--accent, #3ecf8e)', margin: '0 0 10px',
            }}>
              {completedAll ? 'Mino Games complete' : `${def.name} stage passed`}
            </p>
            <h2 style={{ fontSize: 25, fontWeight: 900, color: 'var(--text)', margin: '0 0 26px' }}>
              {completedAll ? 'You have completed Mino Games.' : 'You survived.'}
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 22 }}>
              <Avatar src={profile?.avatar} name={name} size={82} radius={26} ring={MINO_ACCENT} />
              <p style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)', margin: '12px 0 14px' }}>{name}</p>

              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
                <Pill icon={<Clock size={12} />} text={formatDuration(seconds)} />
                <Pill text="Survived this round" tone="good" />
              </div>
            </div>

            {(xpAwarded > 0 || diamonds > 0) && (
              <div style={{
                display: 'flex', gap: 10, justifyContent: 'center', marginBottom: 24,
              }}>
                {xpAwarded > 0 && <Reward label="XP earned" value={`+${xpAwarded.toLocaleString()}`} />}
                {diamonds > 0 && <Reward label="Diamonds" value={`+${diamonds.toLocaleString()}`} />}
              </div>
            )}

            {saveError && (
              <p style={{ fontSize: 12.5, color: MINO_ACCENT, margin: '0 0 18px' }}>
                Couldn't save your run: {saveError}
              </p>
            )}

            <button
              type="button"
              disabled={sharing || shared}
              onClick={(e) => { ripple(e); handleShare() }}
              style={{ ...secondaryBtn, marginBottom: 10 }}
            >
              <Share2 size={15} />
              {shared ? 'Shared' : sharing ? 'Preparing…' : 'Share to Highlights'}
            </button>

            <p style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.55, margin: '18px 0 22px' }}>
              {completedAll
                ? `Mino Games is closed to you now — nobody runs it twice. More rounds coming soon. Your ${MINO_COMPLETION_DIAMONDS} diamonds are in your wallet as "Mino Games Survivor".`
                : 'That\'s tonight done. Come back tomorrow night to face the next round.'}
            </p>

            <button type="button" onClick={(e) => { ripple(e); onExit('won') }} style={primaryBtn}>
              Done
            </button>
          </div>
        )}

        {/* ── Eliminated ──────────────────────────────────────────── */}
        {phase === 'lost' && (
          <div style={{ paddingTop: 50, textAlign: 'center' }}>
            <p style={{
              fontSize: 34, fontWeight: 900, color: MINO_ACCENT, margin: '0 0 12px',
              letterSpacing: 0.5,
            }}>
              Eliminated
            </p>
            <p style={{ fontSize: 15, color: 'var(--text)', margin: '0 0 6px', fontWeight: 600 }}>
              {deathReason}
            </p>
            <p style={{ fontSize: 13, color: 'var(--text-dim)', margin: '0 0 30px' }}>
              No XP. No rewards. You lasted {formatDuration(seconds)}.
            </p>

            <div style={{
              padding: '16px 18px', borderRadius: 14, textAlign: 'left',
              background: 'var(--surface2)', border: '1px solid var(--border)',
              marginBottom: 26,
            }}>
              <p style={{ fontSize: 13, color: 'var(--text-dim)', margin: 0, lineHeight: 1.6 }}>
                {canRetryTonight
                  ? 'The dice owe you nothing. Tonight\'s attempt is still yours — go again before Mino shuts at 1:00 AM.'
                  : 'Your run is back to Stage 1. Mino opens again tomorrow night — you can start over then.'}
              </p>
            </div>

            <button
              type="button"
              onClick={(e) => { ripple(e); onExit(canRetryTonight ? 'quit' : 'lost') }}
              style={primaryBtn}
            >
              {canRetryTonight ? 'Try again' : 'Leave'}
            </button>
          </div>
        )}
      </div>

      <style>{`@keyframes minoCaret { 0%,49%{opacity:1} 50%,100%{opacity:0} }`}</style>
    </div>
  )
}

function ordinal(n: number): string {
  return ['first', 'second', 'third', 'fourth'][n - 1] ?? `${n}th`
}

function Pill({ icon, text, tone }: { icon?: React.ReactNode; text: string; tone?: 'good' }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 11.5, fontWeight: 800, padding: '6px 12px', borderRadius: 999,
      background: tone === 'good' ? 'rgba(62,207,142,0.14)' : 'var(--surface2)',
      border: `1px solid ${tone === 'good' ? 'rgba(62,207,142,0.35)' : 'var(--border)'}`,
      color: tone === 'good' ? 'var(--accent, #3ecf8e)' : 'var(--text-dim)',
    }}>
      {icon}{text}
    </span>
  )
}

function Reward({ label, value }: { label: string; value: string }) {
  return (
    <div style={{
      padding: '12px 20px', borderRadius: 14,
      background: 'var(--surface2)', border: '1px solid var(--border)',
    }}>
      <p style={{
        fontSize: 10, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase',
        color: 'var(--text-dim)', margin: '0 0 3px',
      }}>{label}</p>
      <p style={{ fontSize: 18, fontWeight: 900, color: 'var(--text)', margin: 0 }}>{value}</p>
    </div>
  )
}

const iconBtn: React.CSSProperties = {
  width: 34, height: 34, borderRadius: 10, background: 'var(--surface)',
  border: '1px solid var(--border)', color: 'var(--text-dim)',
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
}

const primaryBtn: React.CSSProperties = {
  width: '100%', padding: '15px 0', borderRadius: 14, border: 'none',
  fontSize: 15, fontWeight: 900, cursor: 'pointer',
  background: MINO_ACCENT, color: '#fff',
}

const secondaryBtn: React.CSSProperties = {
  width: '100%', padding: '13px 0', borderRadius: 14,
  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
  fontSize: 14, fontWeight: 800, cursor: 'pointer',
  background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text)',
}
