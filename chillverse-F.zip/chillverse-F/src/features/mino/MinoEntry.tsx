// src/features/mino/MinoEntry.tsx
//
// Owns the Mino modal ↔ run handoff so GamesZone only has to render one
// component and flip one boolean. Also the single place the horror sting
// fires, which keeps it from double-playing if the modal ever re-mounts.
import { useEffect, useRef, useState } from 'react'
import MinoModal from './MinoModal'
import MinoRun from './MinoRun'
import { fetchMinoState } from './minoApi'
import type { MinoStageId } from './minoConfig'
import { playMinoHorror, startMinoAmbience, stopMinoAmbience } from './useMino'
import { useGamePresence } from '../games/useGamePresence'

interface Props {
  open: boolean
  onClose: () => void
}

export default function MinoEntry({ open, onClose }: Props) {
  const [runStage, setRunStage] = useState<MinoStageId | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const playedRef = useRef(false)

  // Live ticker: "Playing Mino Games" for the whole time the sheet is up —
  // lobby/info browsing included, not just an active briefing→stage→result
  // run. `open` covers both since starting a run never flips it false.
  useGamePresence(open ? 'mino-games' : null)

  // The sting plays on open, once per opening. Tied to `open` rather than to
  // mount so reopening it later in the same session sounds again.
  useEffect(() => {
    if (open && !playedRef.current) {
      playedRef.current = true
      playMinoHorror()
      startMinoAmbience()
    }
    if (!open) {
      playedRef.current = false
      stopMinoAmbience()
    }
  }, [open])

  // Covers the paths that skip the `open → false` transition entirely:
  // navigating away with the sheet up, or dropping straight into a run.
  useEffect(() => stopMinoAmbience, [])

  async function startRun() {
    // Re-read immediately before launching rather than trusting the state the
    // modal fetched on open — a player can sit on this sheet past 1am, and
    // the RPC would refuse the payout after they'd already played a stage.
    const fresh = await fetchMinoState()
    if (!fresh || !fresh.canPlay) { setRefreshKey(k => k + 1); return }
    // The bed belongs to the sheet, not the games — a loop droning under a
    // 5-second countdown fights the tension rather than building it.
    stopMinoAmbience()
    setRunStage(fresh.stage)
  }

  if (runStage !== null) {
    return (
      <MinoRun
        stage={runStage}
        onExit={() => { setRunStage(null); setRefreshKey(k => k + 1) }}
      />
    )
  }

  if (!open) return null

  return <MinoModal onClose={onClose} onPlay={startRun} refreshKey={refreshKey} />
}
