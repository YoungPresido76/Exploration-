// src/features/admin/SecurityOpsSection.tsx
//
// The "Integrity" wing of the ops console. Rendered inside AdminOpsPanel.
//
// A note on what this can and can't do, because it shapes the whole UI:
// you cannot log a *blocked* attempt. When RLS rejects a write, the
// statement rolls back and takes any log row with it — I tested this. So
// there is no "someone just tried X" feed to render, and pretending
// otherwise would be worse than useless.
//
// What this shows instead is violated invariants: states the economy
// should never be able to reach. That catches the aftermath of any hole,
// including ones nobody has found yet, which is the more useful signal.
// A scan runs hourly via pg_cron; the button forces one now.
import { useEffect, useState } from 'react'
import { ShieldAlert, ShieldCheck, RefreshCw, Check, ChevronDown, ChevronUp, Gift, BadgeCheck, ShieldOff, Trash2 } from 'lucide-react'
import { SectionTitle } from '../settings/settingsShared'
import { Modal, fieldLabel, inputStyle } from './adminModal'
import { ripple } from '../../shared/lib/ripple'
import {
  fetchSecurityEvents, runIntegrityScan, resolveSecurityEvent,
  revokeBypassedItems, revokeItemFinding, markItemAsGift, setOfficialAccount,
  SECURITY_KIND_LABEL,
  type SecurityEvent, type SecuritySeverity,
} from './adminOps'

/** Kinds whose `detail` carries an item_id — the only ones a single
 *  finding can be individually revoked for. Mirrors the check the
 *  admin_bulk_revoke_by_kind RPC enforces server-side. */
const ITEM_KINDS = new Set(['unpaid_item', 'xp_gate_bypassed', 'expired_item_acquired', 'reward_without_achievement'])
function hasRevocableItem(event: SecurityEvent): boolean {
  return ITEM_KINDS.has(event.kind) && typeof event.detail?.item_id === 'string'
}

// Hardcoded hex rather than var(--red) so the `${color}22` alpha suffix
// below produces valid CSS — same reasoning as StatusOpsSection.
const SEVERITY_COLOR: Record<SecuritySeverity, string> = {
  critical: '#ff4f4f',
  warn: '#f5c542',
  info: '#4f8ef7',
}

function timeAgo(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(ms / 60_000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

function ResolveModal({ event, onClose, onResolved }: {
  event: SecurityEvent
  onClose: () => void
  onResolved: (id: string) => void
}) {
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    setSaving(true)
    setError('')
    const { error: err } = await resolveSecurityEvent(event.id, note)
    setSaving(false)
    if (err) { setError(err); return }
    onResolved(event.id)
    onClose()
  }

  return (
    <Modal title="Dismiss finding" onClose={onClose}>
      <p style={{ fontSize: 12, color: 'var(--text)', margin: '0 0 4px', fontWeight: 600 }}>
        {event.summary}
      </p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Dismissing only clears it from this list. If the underlying state is still
        wrong, the next hourly scan will re-open it — so this can't accidentally
        hide a live problem.
      </p>
      <p style={fieldLabel}>WHAT DID YOU CONCLUDE?</p>
      <textarea
        value={note}
        onChange={e => setNote(e.target.value)}
        rows={3}
        placeholder="e.g. Revoked the item, or: expected, granted manually for support"
        style={{ ...inputStyle, resize: 'vertical', marginBottom: 14 }}
      />
      <button
        type="button"
        onClick={(e) => { ripple(e); save() }}
        disabled={saving}
        className="ripple-wrap"
        style={{
          width: '100%', padding: 11, borderRadius: 12, border: 'none',
          background: saving ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
          color: saving ? 'var(--text-muted)' : '#fff', fontSize: 13, fontWeight: 800,
          cursor: saving ? 'default' : 'pointer',
        }}
      >
        {saving ? 'Saving…' : 'Dismiss finding'}
      </button>
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 10 }}>{error}</p>}
    </Modal>
  )
}

function RevokeBypassedModal({ count, onClose, onRevoked }: {
  count: number
  onClose: () => void
  onRevoked: () => void
}) {
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    setSaving(true)
    setError('')
    const { error: err } = await revokeBypassedItems(note.trim() || undefined)
    setSaving(false)
    if (err) { setError(err); return }
    onRevoked()
    onClose()
  }

  return (
    <Modal title="Revoke bypassed items" onClose={onClose}>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Deletes the item from every player's inventory across all {count} open XP-requirement
        finding{count === 1 ? '' : 's'}, notifies each player why, and resolves the findings. This
        is a real fix — it won't come back on the next scan. Accounts you've marked official are
        skipped automatically.
      </p>
      <p style={fieldLabel}>NOTE (OPTIONAL)</p>
      <textarea
        value={note}
        onChange={e => setNote(e.target.value)}
        rows={2}
        placeholder="Defaults to: Revoked — XP requirement not met. Player notified."
        style={{ ...inputStyle, resize: 'vertical', marginBottom: 14 }}
      />
      <button
        type="button"
        onClick={(e) => { ripple(e); save() }}
        disabled={saving}
        className="ripple-wrap"
        style={{
          width: '100%', padding: 11, borderRadius: 12, border: 'none',
          background: saving ? 'var(--surface3)' : 'linear-gradient(135deg,var(--red),#ff8a4f)',
          color: saving ? 'var(--text-muted)' : '#fff', fontSize: 13, fontWeight: 800,
          cursor: saving ? 'default' : 'pointer',
        }}
      >
        {saving ? 'Revoking…' : `Revoke ${count} item${count === 1 ? '' : 's'}`}
      </button>
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 10 }}>{error}</p>}
    </Modal>
  )
}

function RevokeItemModal({ event, onClose, onRevoked }: {
  event: SecurityEvent
  onClose: () => void
  onRevoked: (id: string) => void
}) {
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    setSaving(true)
    setError('')
    const { error: err } = await revokeItemFinding(event.id, note.trim() || undefined)
    setSaving(false)
    if (err) { setError(err); return }
    onRevoked(event.id)
    onClose()
  }

  return (
    <Modal title="Revoke item" onClose={onClose}>
      <p style={{ fontSize: 12, color: 'var(--text)', margin: '0 0 4px', fontWeight: 600 }}>
        {event.summary}
      </p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Deletes the item from @{event.username ?? 'this player'}'s inventory and notifies them
        why. A real fix — it won't be reopened by the next scan.
      </p>
      <p style={fieldLabel}>NOTE (OPTIONAL)</p>
      <textarea
        value={note}
        onChange={e => setNote(e.target.value)}
        rows={2}
        placeholder="Defaults to: Item revoked — requirement not met. Player notified."
        style={{ ...inputStyle, resize: 'vertical', marginBottom: 14 }}
      />
      <button
        type="button"
        onClick={(e) => { ripple(e); save() }}
        disabled={saving}
        className="ripple-wrap"
        style={{
          width: '100%', padding: 11, borderRadius: 12, border: 'none',
          background: saving ? 'var(--surface3)' : 'linear-gradient(135deg,var(--red),#ff8a4f)',
          color: saving ? 'var(--text-muted)' : '#fff', fontSize: 13, fontWeight: 800,
          cursor: saving ? 'default' : 'pointer',
        }}
      >
        {saving ? 'Revoking…' : 'Revoke item'}
      </button>
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 10 }}>{error}</p>}
    </Modal>
  )
}

function MarkAsGiftModal({ event, onClose, onMarked }: {
  event: SecurityEvent
  onClose: () => void
  onMarked: (id: string) => void
}) {
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    setSaving(true)
    setError('')
    const { error: err } = await markItemAsGift(event.id, note.trim() || undefined)
    setSaving(false)
    if (err) { setError(err); return }
    onMarked(event.id)
    onClose()
  }

  return (
    <Modal title="Mark as gift" onClose={onClose}>
      <p style={{ fontSize: 12, color: 'var(--text)', margin: '0 0 4px', fontWeight: 600 }}>
        {event.summary}
      </p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Backfills a real gift record from you to @{event.username ?? 'this player'} for the item —
        a genuine fix, so the scan's own "was this a gift?" check passes on its own next time.
      </p>
      <p style={fieldLabel}>NOTE (OPTIONAL)</p>
      <textarea
        value={note}
        onChange={e => setNote(e.target.value)}
        rows={2}
        placeholder="Defaults to: Backfilled as an admin-issued gift."
        style={{ ...inputStyle, resize: 'vertical', marginBottom: 14 }}
      />
      <button
        type="button"
        onClick={(e) => { ripple(e); save() }}
        disabled={saving}
        className="ripple-wrap"
        style={{
          width: '100%', padding: 11, borderRadius: 12, border: 'none',
          background: saving ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
          color: saving ? 'var(--text-muted)' : '#fff', fontSize: 13, fontWeight: 800,
          cursor: saving ? 'default' : 'pointer',
        }}
      >
        {saving ? 'Marking…' : 'Mark as gift'}
      </button>
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 10 }}>{error}</p>}
    </Modal>
  )
}

function OfficialAccountModal({ event, onClose, onExempted }: {
  event: SecurityEvent
  onClose: () => void
  onExempted: (userId: string) => void
}) {
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    if (!event.user_id) return
    setSaving(true)
    setError('')
    const { error: err } = await setOfficialAccount(event.user_id, true, note.trim() || undefined)
    setSaving(false)
    if (err) { setError(err); return }
    onExempted(event.user_id)
    onClose()
  }

  return (
    <Modal title="Mark as official account" onClose={onClose}>
      <p style={{ fontSize: 12, color: 'var(--text)', margin: '0 0 4px', fontWeight: 600 }}>
        @{event.username ?? 'this account'}
      </p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Official and house accounts can legitimately hold anything. This resolves every open
        finding for this account and stops new ones from being raised — the scan itself skips
        exempt accounts going forward, so nothing needs to be dismissed by hand again.
      </p>
      <p style={fieldLabel}>NOTE (OPTIONAL)</p>
      <textarea
        value={note}
        onChange={e => setNote(e.target.value)}
        rows={2}
        placeholder="Defaults to: Official account — exempt from integrity checks."
        style={{ ...inputStyle, resize: 'vertical', marginBottom: 14 }}
      />
      <button
        type="button"
        onClick={(e) => { ripple(e); save() }}
        disabled={saving}
        className="ripple-wrap"
        style={{
          width: '100%', padding: 11, borderRadius: 12, border: 'none',
          background: saving ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
          color: saving ? 'var(--text-muted)' : '#fff', fontSize: 13, fontWeight: 800,
          cursor: saving ? 'default' : 'pointer',
        }}
      >
        {saving ? 'Saving…' : 'Mark official & clear findings'}
      </button>
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 10 }}>{error}</p>}
    </Modal>
  )
}

function EventRow({ event, onResolve, onRevokeItem, onMarkGift, onMarkOfficial }: {
  event: SecurityEvent
  onResolve: (e: SecurityEvent) => void
  onRevokeItem: (e: SecurityEvent) => void
  onMarkGift: (e: SecurityEvent) => void
  onMarkOfficial: (e: SecurityEvent) => void
}) {
  const [open, setOpen] = useState(false)
  const color = SEVERITY_COLOR[event.severity]
  const resolved = event.resolved_at != null

  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border)',
      borderLeft: `3px solid ${resolved ? 'var(--border)' : color}`,
      borderRadius: 12, padding: '11px 13px', marginBottom: 8,
      opacity: resolved ? 0.55 : 1,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 9 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap', marginBottom: 3 }}>
            <span style={{
              padding: '2px 6px', borderRadius: 5, fontSize: 9, fontWeight: 800,
              background: `${color}22`, color, letterSpacing: '0.03em',
            }}>
              {SECURITY_KIND_LABEL[event.kind] ?? event.kind}
            </span>
            {event.username && (
              <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text)' }}>
                @{event.username}
              </span>
            )}
            {resolved && (
              <span style={{ fontSize: 9, fontWeight: 800, color: 'var(--green)' }}>DISMISSED</span>
            )}
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-dim)', margin: 0, lineHeight: 1.45 }}>
            {event.summary}
          </p>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '4px 0 0' }}>
            First seen {timeAgo(event.first_seen)}
            {event.seen_count > 1 && ` · still present after ${event.seen_count} scans`}
          </p>
          {open && (
            <pre style={{
              margin: '9px 0 0', padding: 9, borderRadius: 8, background: 'var(--surface2)',
              fontSize: 10, color: 'var(--text-dim)', overflowX: 'auto', lineHeight: 1.5,
            }}>
              {JSON.stringify(event.detail, null, 2)}
            </pre>
          )}
          {resolved && event.resolution && (
            <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '7px 0 0', fontStyle: 'italic' }}>
              {event.resolution}
            </p>
          )}
        </div>

        <div style={{ display: 'flex', gap: 5, flexShrink: 0 }}>
          <button
            type="button"
            onClick={() => setOpen(o => !o)}
            aria-label="Toggle detail"
            style={{
              width: 26, height: 26, borderRadius: 8, background: 'var(--surface2)',
              border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            {open ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
          {!resolved && hasRevocableItem(event) && (
            <button
              type="button"
              onClick={(e) => { ripple(e); onRevokeItem(event) }}
              aria-label="Revoke item"
              title="Revoke item"
              style={{
                width: 26, height: 26, borderRadius: 8, background: 'var(--surface2)',
                border: '1px solid var(--border)', color: 'var(--red)', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <Trash2 size={12} />
            </button>
          )}
          {!resolved && event.kind === 'unpaid_item' && (
            <button
              type="button"
              onClick={(e) => { ripple(e); onMarkGift(event) }}
              aria-label="Mark as gift"
              title="Mark as gift"
              style={{
                width: 26, height: 26, borderRadius: 8, background: 'var(--surface2)',
                border: '1px solid var(--border)', color: 'var(--accent)', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <Gift size={12} />
            </button>
          )}
          {!resolved && event.user_id && (
            <button
              type="button"
              onClick={(e) => { ripple(e); onMarkOfficial(event) }}
              aria-label="Mark official account"
              title="Mark official account"
              style={{
                width: 26, height: 26, borderRadius: 8, background: 'var(--surface2)',
                border: '1px solid var(--border)', color: 'var(--accent)', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <BadgeCheck size={12} />
            </button>
          )}
          {!resolved && (
            <button
              type="button"
              onClick={(e) => { ripple(e); onResolve(event) }}
              aria-label="Dismiss"
              title="Dismiss"
              style={{
                width: 26, height: 26, borderRadius: 8, background: 'var(--surface2)',
                border: '1px solid var(--border)', color: 'var(--green)', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <Check size={12} />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default function SecurityOpsSection() {
  const [events, setEvents] = useState<SecurityEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [scanning, setScanning] = useState(false)
  const [showResolved, setShowResolved] = useState(false)
  const [error, setError] = useState('')
  const [resolving, setResolving] = useState<SecurityEvent | null>(null)
  const [revokingItem, setRevokingItem] = useState<SecurityEvent | null>(null)
  const [markingGift, setMarkingGift] = useState<SecurityEvent | null>(null)
  const [markingOfficial, setMarkingOfficial] = useState<SecurityEvent | null>(null)
  const [revokingBypassed, setRevokingBypassed] = useState(false)
  const [lastScan, setLastScan] = useState<string | null>(null)

  function load(includeResolved = showResolved) {
    setLoading(true)
    fetchSecurityEvents(includeResolved).then(({ data, error: err }) => {
      setEvents(data)
      setError(err ?? '')
      setLoading(false)
    })
  }

  useEffect(() => { load() // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showResolved])

  async function scan() {
    setScanning(true)
    setError('')
    const { data, error: err } = await runIntegrityScan()
    setScanning(false)
    if (err) { setError(err); return }
    if (data) setLastScan(data.scanned_at)
    load()
  }

  const open = events.filter(e => !e.resolved_at)
  const critical = open.filter(e => e.severity === 'critical').length
  const openBypassed = open.filter(e => e.kind === 'xp_gate_bypassed').length

  return (
    <>
      <SectionTitle>Integrity</SectionTitle>

      <div style={{
        background: 'var(--surface)', border: '1px solid var(--border)',
        borderRadius: 16, padding: 15, marginBottom: 12, boxShadow: 'var(--elev-raise-sm)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
          <div style={{
            width: 38, height: 38, borderRadius: 11, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: critical > 0 ? 'rgba(255,79,79,0.12)' : 'rgba(62,207,142,0.12)',
            color: critical > 0 ? 'var(--red)' : 'var(--green)',
          }}>
            {critical > 0 ? <ShieldAlert size={18} /> : <ShieldCheck size={18} />}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', margin: 0 }}>
              {loading ? 'Checking…'
                : critical > 0 ? `${critical} unresolved issue${critical === 1 ? '' : 's'}`
                : open.length > 0 ? `${open.length} to review`
                : 'Economy looks consistent'}
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0' }}>
              Scans hourly{lastScan && ` · last run ${timeAgo(lastScan)}`}
            </p>
          </div>
          <button
            type="button"
            onClick={(e) => { ripple(e); scan() }}
            disabled={scanning}
            style={{
              width: 34, height: 34, borderRadius: 10, flexShrink: 0,
              background: 'var(--surface2)', border: '1px solid var(--border)',
              color: 'var(--text-dim)', cursor: scanning ? 'default' : 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <RefreshCw size={14} className={scanning ? 'animate-spin' : ''} />
          </button>
        </div>

        <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '11px 0 0', lineHeight: 1.5 }}>
          Checks states the economy should never reach — an item held with no payment
          behind it, an XP gate cleared without the XP, a balance that disagrees with its
          own ledger. Blocked attempts can't be recorded (a rejected write rolls its own
          log away), so this watches for results instead, which also catches holes not yet
          known about.
        </p>
      </div>

      {openBypassed > 0 && (
        <button
          type="button"
          onClick={(e) => { ripple(e); setRevokingBypassed(true) }}
          className="ripple-wrap"
          style={{
            width: '100%', padding: '10px 13px', borderRadius: 12, marginBottom: 12,
            background: 'var(--surface)', border: '1px solid var(--red)', color: 'var(--red)',
            fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
          }}
        >
          <ShieldOff size={13} />
          Revoke all {openBypassed} XP-bypassed item{openBypassed === 1 ? '' : 's'}
        </button>
      )}

      {error && (
        <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '0 0 10px 4px' }}>{error}</p>
      )}

      {!loading && events.length === 0 && (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 12px 4px' }}>
          Nothing flagged.
        </p>
      )}

      {events.map(ev => (
        <EventRow
          key={ev.id}
          event={ev}
          onResolve={setResolving}
          onRevokeItem={setRevokingItem}
          onMarkGift={setMarkingGift}
          onMarkOfficial={setMarkingOfficial}
        />
      ))}

      <button
        type="button"
        onClick={() => setShowResolved(s => !s)}
        style={{
          background: 'none', border: 'none', padding: '2px 4px', cursor: 'pointer',
          color: 'var(--text-dim)', fontSize: 11.5, fontWeight: 700, marginBottom: 8,
        }}
      >
        {showResolved ? 'Hide dismissed' : 'Show dismissed'}
      </button>

      {resolving && (
        <ResolveModal
          event={resolving}
          onClose={() => setResolving(null)}
          onResolved={(id) => setEvents(prev => prev.filter(e => e.id !== id))}
        />
      )}

      {revokingItem && (
        <RevokeItemModal
          event={revokingItem}
          onClose={() => setRevokingItem(null)}
          onRevoked={(id) => setEvents(prev => prev.filter(e => e.id !== id))}
        />
      )}

      {markingGift && (
        <MarkAsGiftModal
          event={markingGift}
          onClose={() => setMarkingGift(null)}
          onMarked={(id) => setEvents(prev => prev.filter(e => e.id !== id))}
        />
      )}

      {markingOfficial && (
        <OfficialAccountModal
          event={markingOfficial}
          onClose={() => setMarkingOfficial(null)}
          onExempted={(userId) => setEvents(prev => prev.filter(e => e.user_id !== userId))}
        />
      )}

      {revokingBypassed && (
        <RevokeBypassedModal
          count={openBypassed}
          onClose={() => setRevokingBypassed(false)}
          onRevoked={() => load()}
        />
      )}
    </>
  )
}
