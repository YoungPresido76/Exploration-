// src/features/admin/adminBroadcast.ts
// Client wrapper for admin_send_broadcast() (migration 0119). Same posture as
// adminOps.ts: the RPC is SECURITY DEFINER + is_admin_role()-gated server-side,
// this just surfaces friendly errors.
//
// A broadcast is not a notification — it lands as a real DM from the sending
// admin to each recipient, so replies come straight back to that admin's
// normal DM list the way a WhatsApp broadcast does.

import { supabase } from '../../shared/lib/supabase'
import { isPending } from './adminRequests'
import { uploadChatImage, validateChatImage, MAX_CHAT_IMAGE_BYTES } from '../chat/chatImages'

export { validateChatImage, MAX_CHAT_IMAGE_BYTES }

function friendlyAdminError(message: string): string {
  if (message.includes('CV_ADMIN_FORBIDDEN')) return "You don't have permission to do that."
  if (message.includes('CV_ADMIN_VALIDATION')) return message.split(': ').slice(1).join(': ') || 'Invalid input.'
  return message
}

/** Broadcast images go in the same bucket as ordinary chat pictures, under the
 *  sending admin's own folder — so the same 2MB ceiling applies to staff too. */
export async function uploadBroadcastImage(adminId: string, file: File): Promise<string> {
  return uploadChatImage(adminId, file)
}

/** `targetUserIds` null/empty = send to everyone. Returns how many recipients
 *  it actually reached. */
export async function sendBroadcast(
  body: string,
  imageUrl: string | null,
  targetUserIds: string[] | null,
): Promise<{ count: number; pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_send_broadcast', {
    p_body: body,
    p_image_url: imageUrl,
    p_target_user_ids: targetUserIds && targetUserIds.length > 0 ? targetUserIds : null,
  })
  if (error) return { count: 0, pending: false, error: friendlyAdminError(error.message) }
  // Since 0160b this returns { status, count } rather than a bare integer.
  if (isPending(data)) return { count: 0, pending: true, error: null }
  return { count: Number((data as { count?: number } | null)?.count ?? 0), pending: false, error: null }
}
