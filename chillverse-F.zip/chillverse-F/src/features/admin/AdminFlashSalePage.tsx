// src/features/admin/AdminFlashSalePage.tsx
//
// Ops console → Sales & Promotions → Flash Sale Schedule.
// Used to be a popover modal (FlashSaleModal) inside AdminOpsPanel.tsx;
// moved to its own routed page so there's room for the image upload field
// below, matching the Settings.tsx sub-page pattern (own back button,
// full-height scroll) rather than a cramped 440px modal.
//
// Edits the two self-repeating schedules from migration 0097 (duration
// model per migration 0114):
//   • weekly_special — recurs every week on a chosen weekday, open for
//     duration_hours starting at start_time (default Friday 18:00, 4h).
//     duration_hours can exceed 24, so the window can cross midnight or
//     span multiple days.
//   • monthly_mega    — recurs automatically on the LAST SATURDAY of every
//     month (no date to maintain), open for duration_hours starting at
//     start_time.
// If both would be live at once, monthly_mega always wins — enforced by
// public.get_active_flash_sale() server-side, not by anything here.
//
// image_url (migration 0107) is new: whatever's uploaded here is what the
// Game Zone flash-sale card/modal shows (GamesZone.tsx), so this is the
// only place that image gets set.
import { useEffect, useRef, useState } from 'react'
import { Plus, Trash2, ImagePlus, X, ShieldAlert } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { ripple } from '../../shared/lib/ripple'
import { useAuth } from '../auth/useAuth'
import { useModRole } from '../moderation/useModRole'
import { fieldLabel, inputStyle } from './adminModal'
import {
  fetchFlashSaleRules, saveFlashSaleRule, uploadFlashSaleImage,
  type FlashSaleRule, type FlashSaleItemDraft,
} from './adminOps'

const DOW_LABELS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

function timeToInputValue(t: string): string {
  return t.slice(0, 5) // "HH:MM:SS" -> "HH:MM" for <input type="time">
}
function inputValueToTime(v: string): string {
  return v.length === 5 ? `${v}:00` : v
}

// duration_hours is stored as a single number (can exceed 24 to span
// multiple days); the UI splits it into whole days + hours for editing.
function hoursToDaysAndHours(totalHours: number): { days: number; hours: number } {
  const days = Math.floor(totalHours / 24)
  const hours = Math.round((totalHours - days * 24) * 100) / 100
  return { days, hours }
}
function daysAndHoursToTotal(days: number, hours: number): number {
  return Math.round((days * 24 + hours) * 100) / 100
}

function FlashSaleItemRow({ item, onChange, onRemove }: {
  item: FlashSaleItemDraft
  onChange: (next: FlashSaleItemDraft) => void
  onRemove: () => void
}) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 64px 28px', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <input
        type="number" min={1} placeholder="Diamonds" value={item.diamonds}
        onChange={e => onChange({ ...item, diamonds: Number(e.target.value) })}
        style={{ ...inputStyle, padding: '7px 8px', fontSize: 12 }}
      />
      <div style={{ position: 'relative' }}>
        <span style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: 'var(--text-muted)', pointerEvents: 'none' }}>₦</span>
        <input
          type="number" min={1} placeholder="Orig. price" value={item.original_price_cents / 100}
          onChange={e => onChange({ ...item, original_price_cents: Math.round(Number(e.target.value) * 100) })}
          style={{ ...inputStyle, padding: '7px 8px 7px 20px', fontSize: 12 }}
        />
      </div>
      <div style={{ position: 'relative' }}>
        <input
          type="number" min={0} max={95} value={item.discount_pct}
          onChange={e => onChange({ ...item, discount_pct: Number(e.target.value) })}
          style={{ ...inputStyle, padding: '7px 16px 7px 8px', fontSize: 12, textAlign: 'right' }}
        />
        <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: 'var(--text-muted)', pointerEvents: 'none' }}>%</span>
      </div>
      <button
        onClick={onRemove} aria-label="Remove item"
        style={{ width: 26, height: 26, borderRadius: 8, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--red)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
      >
        <Trash2 size={12} />
      </button>
    </div>
  )
}

function FlashSaleRuleForm({ rule, onSaved }: { rule: FlashSaleRule; onSaved: (r: FlashSaleRule) => void }) {
  const { user } = useAuth()
  const isWeekly = rule.type === 'weekly_special'
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [enabled, setEnabled] = useState(rule.enabled)
  const [dayOfWeek, setDayOfWeek] = useState<number>(rule.day_of_week ?? 5)
  const [startTime, setStartTime] = useState(timeToInputValue(rule.start_time))
  const initialDaysHours = hoursToDaysAndHours(rule.duration_hours)
  const [durationDays, setDurationDays] = useState(initialDaysHours.days)
  const [durationHoursPart, setDurationHoursPart] = useState(initialDaysHours.hours)
  const [title, setTitle] = useState(rule.title)
  const [subtitle, setSubtitle] = useState(rule.subtitle ?? '')
  const [imageUrl, setImageUrl] = useState<string | null>(rule.image_url)
  const [uploadingImage, setUploadingImage] = useState(false)
  const [items, setItems] = useState<FlashSaleItemDraft[]>(
    rule.items.map(i => ({ diamonds: i.diamonds, original_price_cents: i.original_price_cents, discount_pct: i.discount_pct, sort_order: i.sort_order })),
  )
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  function markDirty() { setSaved(false) }

  function updateItem(i: number, next: FlashSaleItemDraft) {
    setItems(prev => prev.map((it, idx) => (idx === i ? next : it)))
    markDirty()
  }
  function removeItem(i: number) {
    setItems(prev => prev.filter((_, idx) => idx !== i).map((it, idx) => ({ ...it, sort_order: idx })))
    markDirty()
  }
  function addItem() {
    setItems(prev => [...prev, { diamonds: 100, original_price_cents: 100000, discount_pct: 30, sort_order: prev.length }])
    markDirty()
  }

  async function handleImagePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !user) return
    setUploadingImage(true)
    setError('')
    try {
      const url = await uploadFlashSaleImage(file)
      setImageUrl(url)
      markDirty()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image.')
    } finally {
      setUploadingImage(false)
    }
  }

  async function handleSave() {
    const durationHours = daysAndHoursToTotal(durationDays, durationHoursPart)
    if (durationHours <= 0) { setError('Duration must be greater than 0.'); return }
    if (durationHours > 720) { setError('Duration can be at most 30 days.'); return }

    setSaving(true)
    setError('')
    setSaved(false)
    const { error } = await saveFlashSaleRule(
      rule.type,
      enabled,
      isWeekly ? dayOfWeek : null,
      inputValueToTime(startTime),
      durationHours,
      title,
      subtitle.trim() || null,
      items,
      imageUrl,
    )
    setSaving(false)
    if (error) { setError(error); return }
    setSaved(true)
    onSaved({
      ...rule,
      enabled,
      day_of_week: isWeekly ? dayOfWeek : null,
      start_time: inputValueToTime(startTime),
      duration_hours: durationHours,
      title,
      subtitle: subtitle.trim() || null,
      image_url: imageUrl,
      items: items.map((it, idx) => ({ id: rule.items[idx]?.id ?? `${rule.type}-${idx}`, ...it })),
    })
  }

  return (
    <div style={{ padding: 14, borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <span style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>
          {isWeekly ? 'Weekly Special' : 'Monthly Mega Sale'}
        </span>
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
          <span style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 700 }}>{enabled ? 'On' : 'Off'}</span>
          <input
            type="checkbox" checked={enabled}
            onChange={e => { setEnabled(e.target.checked); markDirty() }}
            style={{ width: 16, height: 16, accentColor: 'var(--accent)', cursor: 'pointer' }}
          />
        </label>
      </div>

      <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.5 }}>
        {isWeekly
          ? 'Recurs every week on the day below, open for the time window below.'
          : 'Recurs automatically on the last Saturday of every month — no date to maintain. Overrides Weekly Special that day.'}
      </p>

      <p style={fieldLabel}>Header</p>
      <input value={title} onChange={e => { setTitle(e.target.value); markDirty() }} style={{ ...inputStyle, marginBottom: 10 }} />

      <p style={fieldLabel}>Subtitle</p>
      <input value={subtitle} onChange={e => { setSubtitle(e.target.value); markDirty() }} style={{ ...inputStyle, marginBottom: 10 }} />

      <p style={fieldLabel}>Image (Game Zone card + modal)</p>
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImagePick} style={{ display: 'none' }} />
      {imageUrl ? (
        <div style={{ position: 'relative', marginBottom: 12, borderRadius: 12, overflow: 'hidden', border: '1px solid var(--border)' }}>
          <img src={imageUrl} alt="" style={{ width: '100%', height: 120, objectFit: 'cover', display: 'block' }} />
          <button
            onClick={(e) => { ripple(e); setImageUrl(null); markDirty() }}
            aria-label="Remove image"
            style={{ position: 'absolute', top: 6, right: 6, width: 24, height: 24, borderRadius: '50%', background: 'rgba(0,0,0,0.55)', border: 'none', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <X size={13} />
          </button>
          <button
            onClick={(e) => { ripple(e); fileInputRef.current?.click() }}
            disabled={uploadingImage}
            style={{ position: 'absolute', bottom: 6, right: 6, fontSize: 10.5, fontWeight: 700, padding: '5px 10px', borderRadius: 8, background: 'rgba(0,0,0,0.55)', border: 'none', color: '#fff', cursor: 'pointer' }}
          >
            {uploadingImage ? 'Uploading…' : 'Replace'}
          </button>
        </div>
      ) : (
        <button
          onClick={(e) => { ripple(e); fileInputRef.current?.click() }}
          disabled={uploadingImage}
          className="btn-secondary"
          style={{ width: '100%', padding: '14px 0', fontSize: 11.5, marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, opacity: uploadingImage ? 0.6 : 1 }}
        >
          <ImagePlus size={14} /> {uploadingImage ? 'Uploading…' : 'Upload image'}
        </button>
      )}

      {isWeekly && (
        <>
          <p style={fieldLabel}>Day of week</p>
          <select
            value={dayOfWeek}
            onChange={e => { setDayOfWeek(Number(e.target.value)); markDirty() }}
            style={{ ...inputStyle, marginBottom: 10 }}
          >
            {DOW_LABELS.map((d, i) => (
              <option key={i} value={i}>{d}</option>
            ))}
          </select>
        </>
      )}

      <p style={fieldLabel}>Start time</p>
      <input
        type="time" value={startTime}
        onChange={e => { setStartTime(e.target.value); markDirty() }}
        style={{ ...inputStyle, marginBottom: 10 }}
      />

      <p style={fieldLabel}>Duration — how long it stays open once it starts</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 6 }}>
        <div>
          <input
            type="number" min={0} max={30} value={durationDays}
            onChange={e => { setDurationDays(Math.max(0, Number(e.target.value))); markDirty() }}
            style={inputStyle}
          />
          <p style={{ fontSize: 9.5, color: 'var(--text-muted)', margin: '4px 0 0' }}>Days</p>
        </div>
        <div>
          <input
            type="number" min={0} max={23.99} step={0.25} value={durationHoursPart}
            onChange={e => { setDurationHoursPart(Math.max(0, Number(e.target.value))); markDirty() }}
            style={inputStyle}
          />
          <p style={{ fontSize: 9.5, color: 'var(--text-muted)', margin: '4px 0 0' }}>Hours</p>
        </div>
      </div>
      <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        {isWeekly
          ? `Opens ${DOW_LABELS[dayOfWeek]} at ${startTime || '--:--'} and stays open for ${daysAndHoursToTotal(durationDays, durationHoursPart)}h — it's fine for this to run past midnight or into the next day.`
          : `Opens on the last Saturday of the month at ${startTime || '--:--'} and stays open for ${daysAndHoursToTotal(durationDays, durationHoursPart)}h.`}
      </p>

      <p style={fieldLabel}>Items ({items.length})</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 64px 28px', gap: 6, marginBottom: 4 }}>
        <span style={{ fontSize: 9.5, color: 'var(--text-muted)', fontWeight: 700 }}>Diamonds</span>
        <span style={{ fontSize: 9.5, color: 'var(--text-muted)', fontWeight: 700 }}>Orig. price</span>
        <span style={{ fontSize: 9.5, color: 'var(--text-muted)', fontWeight: 700 }}>Off</span>
        <span />
      </div>
      {items.map((item, i) => (
        <FlashSaleItemRow key={i} item={item} onChange={next => updateItem(i, next)} onRemove={() => removeItem(i)} />
      ))}
      <button
        onClick={addItem} className="btn-secondary"
        style={{ width: '100%', padding: '7px 0', fontSize: 11.5, marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}
      >
        <Plus size={12} /> Add item
      </button>

      {error && <p style={{ fontSize: 11, color: 'var(--red)', marginBottom: 10 }}>{error}</p>}
      {saved && !error && <p style={{ fontSize: 11, color: '#4fd18a', fontWeight: 700, marginBottom: 10 }}>Saved.</p>}

      <button
        onClick={handleSave} disabled={saving || items.length === 0 || uploadingImage}
        className="btn-primary"
        style={{ width: '100%', padding: '10px 0', fontSize: 13, opacity: saving || items.length === 0 || uploadingImage ? 0.6 : 1 }}
      >
        {saving ? 'Saving…' : `Save ${isWeekly ? 'Weekly Special' : 'Monthly Mega Sale'}`}
      </button>
    </div>
  )
}

export default function AdminFlashSalePage() {
  usePageHeader({ title: 'Flash Sale Schedule' })
  const { isAdmin, loading: roleLoading } = useModRole()
  const [rules, setRules] = useState<FlashSaleRule[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (roleLoading) return
    if (!isAdmin) { setLoading(false); return }
    fetchFlashSaleRules().then(({ data, error }) => {
      if (error) { setError(error); setLoading(false); return }
      setRules(data)
      setLoading(false)
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleLoading, isAdmin])

  if (roleLoading) return null

  if (!isAdmin) {
    return (
      <div style={{ maxWidth: 480, margin: '80px auto', textAlign: 'center', padding: 20 }}>
        <ShieldAlert size={32} style={{ color: 'var(--text-dim)', marginBottom: 10 }} />
        <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>Admins only</p>
        <p style={{ fontSize: 12.5, color: 'var(--text-dim)', marginTop: 6 }}>
          This page is restricted to Chillverse admins.
        </p>
      </div>
    )
  }

  function handleSaved(next: FlashSaleRule) {
    setRules(prev => prev.map(r => (r.type === next.type ? next : r)))
  }

  const monthly = rules.find(r => r.type === 'monthly_mega')
  const weekly = rules.find(r => r.type === 'weekly_special')

  return (
    <div style={{ maxWidth: 480, margin: '0 auto', paddingBottom: 48 }}>
      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>Loading…</p>
      ) : error ? (
        <p style={{ fontSize: 12, color: 'var(--red)', textAlign: 'center', padding: 20 }}>{error}</p>
      ) : (
        <>
          {monthly && <FlashSaleRuleForm rule={monthly} onSaved={handleSaved} />}
          {weekly && <FlashSaleRuleForm rule={weekly} onSaved={handleSaved} />}
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
            If both schedules would be live at the same time, Monthly Mega Sale always wins — Weekly Special is suppressed that day. Whichever sale is active shows a card in the Game Zone automatically; nothing shows there when both are closed.
          </p>
        </>
      )}
    </div>
  )
}
