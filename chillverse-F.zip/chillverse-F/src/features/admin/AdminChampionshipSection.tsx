// src/features/admin/AdminChampionshipSection.tsx
//
// Championship control, in the Arena wing alongside Elimination Weekend —
// same rationale: it's a PvP event, not a store or ops concern. Renders
// for anyone who reached this wing (AdminDashboard already gated on
// useModRole().isAdmin) — Championship isn't the single-owner-only kind of
// dial Elimination's reward is, so it doesn't add its own useIsOwner gate.
//
// Phase 1: no cron. "Advance round" is a state-machine tick the admin
// clicks manually — see admin_advance_championship_round. The result
// message below is literally the RPC's own return value, not a guess
// about what it did.
import { useEffect, useState } from 'react'
import { Trophy, Play, ChevronRight } from 'lucide-react'
import { SectionTitle } from '../settings/settingsShared'
import { ripple } from '../../shared/lib/ripple'
import {
  getCurrentSeason, getRegistrationCount, adminOpenChampionshipSeason, adminAdvanceChampionshipRound,
  championshipErrorMessage, type ChampionshipSeason,
} from '../championship/championship'

export default function AdminChampionshipSection() {
  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [regCount, setRegCount] = useState<number | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastResult, setLastResult] = useState<string | null>(null)

  async function load() {
    const s = await getCurrentSeason()
    setSeason(s)
    setRegCount(s ? await getRegistrationCount(s.id) : null)
  }

  useEffect(() => { load() }, [])

  const seasonIsOpenable = !season || season.status === 'completed' || season.status === 'cancelled'

  async function openSeason() {
    if (busy) return
    setBusy(true); setError(null); setLastResult(null)
    try {
      const res = await adminOpenChampionshipSeason()
      setLastResult(`Season ${res.season_number} opened for ${res.series_name}. Registration is live.`)
      await load()
    } catch (err) {
      setError(championshipErrorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  async function advanceRound() {
    if (busy || !season) return
    setBusy(true); setError(null); setLastResult(null)
    try {
      const res = await adminAdvanceChampionshipRound(season.id)
      setLastResult(describeResult(res))
      await load()
    } catch (err) {
      setError(championshipErrorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <SectionTitle>Chillverse Championship</SectionTitle>
      <div className="neu-card" style={{ padding: 16, marginBottom: 18 }}>
        {season ? (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Trophy size={16} color="var(--gold)" />
              </div>
              <div>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>
                  {season.series_name} · Season {season.season_number}
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 1 }}>
                  {season.status === 'registration' && `Registration open · ${regCount ?? 0} registered`}
                  {season.status === 'active' && `Live · Round ${season.current_round} of ${season.round_count}`}
                  {season.status === 'completed' && 'Completed'}
                  {season.status === 'cancelled' && 'Cancelled (under 8 registered)'}
                </div>
              </div>
            </div>

            {(season.status === 'registration' || season.status === 'active') && (
              <button
                onClick={(e) => { ripple(e); advanceRound() }}
                disabled={busy}
                className="ripple-wrap"
                style={{
                  marginTop: 12, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  border: 'none', borderRadius: 10, padding: 11, fontSize: 12.5, fontWeight: 700, color: '#fff',
                  background: 'var(--accent)', cursor: busy ? 'default' : 'pointer', position: 'relative', overflow: 'hidden',
                }}
              >
                <Play size={13} />
                {busy ? 'Working…' : season.status === 'registration' ? 'Close registration & draw bracket' : 'Advance round'}
              </button>
            )}
          </>
        ) : (
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>No season scheduled.</div>
        )}

        {seasonIsOpenable && (
          <button
            onClick={(e) => { ripple(e); openSeason() }}
            disabled={busy}
            className="ripple-wrap"
            style={{
              marginTop: season ? 8 : 0, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              border: '1px solid var(--border-strong)', borderRadius: 10, padding: 11, fontSize: 12.5, fontWeight: 700, color: 'var(--text)',
              background: 'var(--surface2)', cursor: busy ? 'default' : 'pointer', position: 'relative', overflow: 'hidden',
            }}
          >
            <ChevronRight size={13} />
            {busy ? 'Working…' : 'Open next season (72h registration)'}
          </button>
        )}

        {lastResult && <div style={{ marginTop: 10, fontSize: 11, color: 'var(--green, #3ecf8e)', fontWeight: 600 }}>{lastResult}</div>}
        {error && <div style={{ marginTop: 10, fontSize: 11, color: 'var(--danger, #ff4d6d)', fontWeight: 600 }}>{error}</div>}
      </div>
    </>
  )
}

function describeResult(res: Record<string, unknown>): string {
  switch (res.result) {
    case 'bracket_drawn': return `Bracket drawn: ${res.bracket_size} players, ${res.round_count} rounds, ${res.byes} byes.`
    case 'round_started': return `Round ${res.round} started. Loadouts are locked.`
    case 'round_resolved_next_drawn': return `Round ${res.completed_round} resolved. ${res.advancing} players advancing.`
    case 'champion_crowned': return 'Champion crowned. Badges granted.'
    case 'cancelled': return `Season cancelled — only ${res.registered} registered (need 8+).`
    default: return 'Done.'
  }
}
