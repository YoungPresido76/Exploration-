// src/features/admin/AdminConcourse.tsx
//
// The admin home screen — replaces the old horizontal-scrolling wing tab
// strip with a mall-directory grid (leaning into the app's own "wings"
// metaphor), a persistent system-status ribbon, a quick-actions row for
// the handful of things admins reach for most, and a recent-activity feed
// pulled from the real moderation log. Wing content itself is unchanged —
// this component only replaces how you get to it.
//
// Ports the "Concourse" mobile mockup into the live dashboard: every
// number on this screen is real data (AdminDashboardStats, app_config,
// status_components, admin_system_health, moderation_log), not
// placeholder content.
import { useEffect, useState } from 'react'
import type { MouseEvent } from 'react'
import {
  RefreshCcw, Search, Radio, Power, Gift, Download, CheckCircle2, ChevronRight,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { ADMIN_SECTIONS, type AdminSection } from './adminSections'
import type { AdminDashboardStats } from './adminStats'
import { fetchAppConfig, fetchSystemHealth, fetchFeatureFlags, type AppConfig, type SystemHealth, type FeatureFlag } from './adminOps'
import { fetchStatusComponents, type StatusComponent } from '../status/statusApi'
import { fetchModerationLog, type ModerationLogEntry } from '../moderation/moderation'
import { useIsOwner, usePendingRequestCount } from './adminRequests'

type RibbonLevel = 'ok' | 'warn' | 'bad'

interface RibbonState {
  level: RibbonLevel
  title: string
  sub: string
}

const RIBBON_COLOR: Record<RibbonLevel, string> = { ok: 'var(--green)', warn: 'var(--gold)', bad: 'var(--red)' }

function wingMetric(section: AdminSection, stats: AdminDashboardStats, health: SystemHealth | null): string | null {
  switch (section) {
    case 'overview': return `${stats.overview.total_users.toLocaleString()} users`
    case 'economy': return `${stats.economy.diamonds_in_circulation.toLocaleString()} diamonds live`
    case 'games': return `${stats.games.sessions_7d.toLocaleString()} sessions · 7d`
    case 'multiplayer': return `${stats.multiplayer.active_rooms.toLocaleString()} active rooms`
    case 'halo': return `${stats.halo_ai.active_users_7d.toLocaleString()} active · 7d`
    case 'operations': return `${(stats.moderation.open_reports + stats.support.open_tickets).toLocaleString()} open items`
    case 'ops': return health ? `${health.flags.disabled_count} flag${health.flags.disabled_count === 1 ? '' : 's'} off` : null
    // Collabs and Broadcasts don't have a rollup in AdminDashboardStats yet —
    // showing no metric here beats fabricating one.
    case 'collabs': return null
    case 'broadcasts': return null
    // Approvals carries a live pending count instead — filled in at the
    // tile, where usePendingRequestCount() is in scope.
    case 'approvals': return null
  }
}

// Only the Ops console wing has a real per-wing health signal today (the
// same maintenance/error-mode + degraded-components state the ribbon
// reads). Every other wing shows 'ok' rather than a fabricated status —
// there's no incident/degradation concept yet for Mall economy, Arcade,
// etc. individually.
function wingHealthLevel(section: AdminSection, ribbonLevel: RibbonLevel): RibbonLevel {
  return section === 'ops' ? ribbonLevel : 'ok'
}

function QuickAction({
  icon: Icon, label, tint, onClick,
}: { icon: typeof Search; label: string; tint: string; onClick: (e: MouseEvent<HTMLButtonElement>) => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="ripple-wrap"
      style={{
        display: 'flex', alignItems: 'center', gap: 7, flexShrink: 0,
        padding: '9px 13px 9px 10px', borderRadius: 999, cursor: 'pointer', whiteSpace: 'nowrap',
        background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)',
        fontSize: 12, fontWeight: 700,
      }}
    >
      <span style={{
        width: 22, height: 22, borderRadius: 7, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: `${tint}22`, color: tint,
      }}>
        <Icon size={12} />
      </span>
      {label}
    </button>
  )
}

export default function AdminConcourse({
  stats, activeSection, onSelectSection, onOpenUserSearch, onOpenActionSearch, loading, onRefresh,
}: {
  stats: AdminDashboardStats
  activeSection: AdminSection | null
  onSelectSection: (key: AdminSection) => void
  onOpenUserSearch: () => void
  onOpenActionSearch: () => void
  loading: boolean
  onRefresh: () => void
}) {
  const [appConfig, setAppConfig] = useState<AppConfig | null>(null)
  const [components, setComponents] = useState<StatusComponent[]>([])
  const [health, setHealth] = useState<SystemHealth | null>(null)
  const [flags, setFlags] = useState<FeatureFlag[]>([])
  const [activity, setActivity] = useState<ModerationLogEntry[]>([])
  const { isOwner } = useIsOwner()
  const { count: pendingApprovals } = usePendingRequestCount()

  useEffect(() => {
    fetchAppConfig().then(({ data }) => setAppConfig(data))
    fetchStatusComponents().then(({ data }) => setComponents(data))
    fetchSystemHealth().then(({ data }) => setHealth(data))
    fetchFeatureFlags().then(({ data }) => setFlags(data))
    fetchModerationLog().then(({ data }) => setActivity(data.slice(0, 5)))
  }, [])

  const ribbon = ribbonState(appConfig, components)
  const flagsOnCount = flags.filter(f => f.enabled).length
  const servicesUpCount = components.filter(c => c.state === 'operational').length

  return (
    // No master wrapping card here — matches the mockup exactly: body/page
    // background shows through, and the ribbon, hero, quick-action pills,
    // and wing tiles are each their own opaque card. (An earlier pass wrapped
    // all of this in one outer neu-card that the mockup never had — on dark
    // themes it was invisible enough not to notice, but on light themes it
    // visibly conflicted with the individually-carded children.)
    <div style={{ marginTop: 16 }}>
      <div className="flex items-center gap-3" style={{ marginBottom: 14 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 10, color: 'var(--accent)', fontWeight: 900, letterSpacing: '0.08em', textTransform: 'uppercase', margin: 0 }}>The Concourse</p>
          <p style={{ fontSize: 12, color: 'var(--text-dim)', margin: '3px 0 0' }}>
            Updated {new Date(stats.generated_at).toLocaleTimeString()}
          </p>
        </div>
        <button
          type="button"
          onClick={(e) => { ripple(e); onOpenActionSearch() }}
          aria-label="Search every wing and action"
          style={{
            width: 34, height: 34, borderRadius: 10, background: 'var(--surface)',
            border: '1px solid var(--border)', color: 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
          }}
        >
          <Search size={14} />
        </button>
        <button
          type="button"
          onClick={(e) => { ripple(e); onRefresh() }}
          disabled={loading}
          aria-label="Refresh"
          style={{
            width: 34, height: 34, borderRadius: 10, background: 'var(--surface)',
            border: '1px solid var(--border)', color: 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: loading ? 'default' : 'pointer',
            opacity: loading ? 0.5 : 1, flexShrink: 0,
          }}
        >
          <RefreshCcw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Status ribbon — its own opaque card (color-mix blends the status
          tint into var(--surface) itself, rather than laying a low-alpha
          color over whatever's behind it). The previous `${color}14` /
          `${color}40` alpha approach depended on an opaque backing to read
          as a card; without one — and even more so on a pale theme where an
          8%-opacity green tint sits on an already pale-green page — it was
          only barely there. color-mix always produces a fully opaque
          result, so the ribbon reads as a card on every theme. */}
      <button
        type="button"
        onClick={(e) => { ripple(e); onSelectSection('ops') }}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left', cursor: 'pointer',
          padding: '10px 12px', borderRadius: 12, marginBottom: 14,
          background: `color-mix(in srgb, ${RIBBON_COLOR[ribbon.level]} 10%, var(--surface))`,
          border: `1px solid color-mix(in srgb, ${RIBBON_COLOR[ribbon.level]} 35%, var(--border))`,
        }}
      >
        <span style={{ width: 9, height: 9, borderRadius: '50%', background: RIBBON_COLOR[ribbon.level], flexShrink: 0 }} />
        <span style={{ flex: 1, minWidth: 0 }}>
          <span style={{ display: 'block', fontSize: 12.5, fontWeight: 800, color: 'var(--text)' }}>{ribbon.title}</span>
          <span style={{ display: 'block', fontSize: 11, color: 'var(--text-dim)', marginTop: 1 }}>{ribbon.sub}</span>
        </span>
        <ChevronRight size={15} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
      </button>

      {/* Platform pulse — the same numbers a moment's glance at Atrium/Ops
          would give you, surfaced here so the Concourse itself answers
          "is everything OK, and how big is this place" at a glance. */}
      <div
        className="neu-card"
        style={{
          padding: 14, marginBottom: 16, position: 'relative', overflow: 'hidden',
          background: 'linear-gradient(135deg, color-mix(in srgb, var(--accent) 10%, var(--surface)), var(--surface))',
        }}
      >
        <div className="flex items-center gap-1" style={{ marginBottom: 6 }}>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', margin: 0 }}>
            Platform pulse
          </p>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 10, color: 'var(--green)', fontWeight: 700, marginLeft: 'auto' }}>
            <RefreshCcw size={9} /> Live
          </span>
        </div>
        <p style={{ fontSize: 13, color: 'var(--text)', fontWeight: 700, lineHeight: 1.35, margin: '0 0 12px' }}>
          A directory of every wing — tap one to open its dashboard.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          <div>
            <p style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0, fontVariantNumeric: 'tabular-nums' }}>
              {stats.overview.total_users.toLocaleString()}
            </p>
            <p style={{ fontSize: 10.5, color: 'var(--text-dim)', margin: '2px 0 0' }}>Total users</p>
          </div>
          <div>
            <p style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0, fontVariantNumeric: 'tabular-nums' }}>
              {flags.length > 0 ? `${flagsOnCount}/${flags.length}` : '—'}
            </p>
            <p style={{ fontSize: 10.5, color: 'var(--text-dim)', margin: '2px 0 0' }}>Flags on</p>
          </div>
          <div>
            <p style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0, fontVariantNumeric: 'tabular-nums' }}>
              {components.length > 0 ? `${servicesUpCount}/${components.length}` : '—'}
            </p>
            <p style={{ fontSize: 10.5, color: 'var(--text-dim)', margin: '2px 0 0' }}>Services up</p>
          </div>
        </div>
      </div>

      {/* Quick actions — the handful of things admins reach for most, without hunting through a wing. */}
      <div className="admin-tab-scroll" style={{ marginBottom: 16 }}>
        <QuickAction icon={Search} label="Find a user" tint="var(--blue)" onClick={(e) => { ripple(e); onOpenUserSearch() }} />
        <QuickAction icon={Radio} label="Declare incident" tint="var(--accent)" onClick={(e) => { ripple(e); onSelectSection('ops') }} />
        <QuickAction icon={Power} label="Maintenance" tint="var(--red)" onClick={(e) => { ripple(e); onSelectSection('ops') }} />
        <QuickAction icon={Gift} label="Gift diamonds" tint="var(--green)" onClick={(e) => { ripple(e); onSelectSection('economy') }} />
        <QuickAction icon={Download} label="Export users" tint="var(--gold)" onClick={(e) => { ripple(e); onSelectSection('ops') }} />
      </div>

      {/* Wing directory — the Concourse itself. */}
      <p style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 9px' }}>
        Wings
      </p>
      {/* Fixed 3-column grid — NOT auto-fill/minmax. minmax(150px,1fr) needs
          ~310px of track width to fit even 2 columns, but the real content
          width here (card padding + outer page padding) is under 300px on
          every phone, so auto-fill was silently collapsing this to a single
          stacked column. A fixed repeat(3,1fr) always gives the 3×3
          directory the design calls for, letting labels/metrics wrap
          instead of dictating the column count. */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 9, marginBottom: 18 }}>
        {ADMIN_SECTIONS.filter(section => !section.ownerOnly || isOwner).map(section => {
          const Icon = section.icon
          const active = activeSection === section.key
          const metric = section.key === 'approvals'
            ? (pendingApprovals > 0 ? `${pendingApprovals} waiting` : 'Nothing waiting')
            : wingMetric(section.key, stats, health)
          const tileHealth = wingHealthLevel(section.key, ribbon.level)
          return (
            <button
              key={section.key}
              type="button"
              onClick={(e) => { ripple(e); onSelectSection(section.key) }}
              className="ripple-wrap"
              style={{
                textAlign: 'left', cursor: 'pointer', padding: '12px 10px 10px', borderRadius: 13, position: 'relative',
                background: active ? 'var(--surface2)' : 'var(--surface)',
                border: active ? '1px solid color-mix(in srgb, var(--accent) 40%, transparent)' : '1px solid var(--border)',
                display: 'flex', flexDirection: 'column', gap: 8, minHeight: 104, minWidth: 0,
              }}
            >
              <span
                aria-hidden
                title={tileHealth === 'ok' ? 'Healthy' : tileHealth === 'warn' ? 'Degraded' : 'Down'}
                style={{
                  position: 'absolute', top: 11, right: 10, width: 6, height: 6, borderRadius: '50%',
                  background: RIBBON_COLOR[tileHealth],
                }}
              />
              <span style={{
                width: 30, height: 30, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: `${section.tint}22`, color: section.tint, flexShrink: 0,
              }}>
                <Icon size={15} />
              </span>
              <span style={{ minWidth: 0 }}>
                <span style={{ display: 'block', fontSize: 12, fontWeight: 800, color: 'var(--text)', lineHeight: 1.2, wordBreak: 'break-word' }}>{section.label}</span>
                {metric && <span style={{ display: 'block', fontSize: 10, color: 'var(--text-dim)', fontWeight: 600, marginTop: 3, lineHeight: 1.25, wordBreak: 'break-word' }}>{metric}</span>}
              </span>
            </button>
          )
        })}
      </div>

      {/* Recent activity — the real moderation_log, not a mock feed. Wrapped
          in its own card, matching the mockup's `.card` treatment for this
          section (it had been left bare — the one section that genuinely
          was just floating on the page background with no card at all). */}
      {activity.length > 0 && (
        <div>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 9px' }}>
            Recent activity
          </p>
          <div className="neu-card" style={{ padding: '2px 14px' }}>
            {activity.map((entry, i) => (
              <div
                key={entry.id}
                style={{
                  display: 'flex', alignItems: 'center', gap: 9, padding: '9px 2px',
                  borderTop: i === 0 ? undefined : '1px solid var(--border)',
                }}
              >
                <span style={{
                  width: 26, height: 26, borderRadius: 8, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--surface2)', color: 'var(--text-dim)',
                }}>
                  <CheckCircle2 size={13} />
                </span>
                <span style={{ flex: 1, minWidth: 0, fontSize: 12, color: 'var(--text-dim)' }}>
                  <span style={{ color: 'var(--text)', fontWeight: 700 }}>{entry.moderator?.username ?? 'System'}</span>
                  {' — '}{entry.action.replace(/_/g, ' ')} <span style={{ color: 'var(--text-muted)' }}>· {entry.target_type}</span>
                </span>
                <span style={{ fontSize: 10.5, color: 'var(--text-muted)', flexShrink: 0 }}>
                  {new Date(entry.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function ribbonState(config: AppConfig | null, components: StatusComponent[]): RibbonState {
  if (config?.site_status === 'error') {
    return { level: 'bad', title: 'Error mode is on', sub: 'Every visitor is seeing the error screen' }
  }
  if (config?.site_status === 'maintenance' || config?.maintenance_enabled) {
    return { level: 'warn', title: 'Maintenance mode is on', sub: config.maintenance_message || 'Every visitor is seeing the maintenance screen' }
  }
  const degraded = components.filter(c => c.state !== 'operational')
  if (degraded.length > 0) {
    return {
      level: degraded.some(c => c.state === 'major_outage') ? 'bad' : 'warn',
      title: degraded.length === 1 ? `${degraded[0].label} is ${degraded[0].state.replace(/_/g, ' ')}` : `${degraded.length} services degraded`,
      sub: degraded.length === 1 ? (degraded[0].state_message || 'All other services are healthy') : degraded.map(c => c.label).join(', '),
    }
  }
  return { level: 'ok', title: 'All systems operational', sub: 'No open incidents' }
}
