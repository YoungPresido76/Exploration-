// src/features/admin/AdminRedeemCodesPage.tsx
//
// Ops console → Redeem Codes → Redeem Code Manager.
// Create codes (auto-generated CHLVERS_XXXXX or manually written), one
// reward per code — a single currency amount or a single mall item — with
// optional usage cap, scheduled start, and expiry. Lists existing codes
// with status and lets an admin deactivate/reactivate one.
import { useEffect, useState } from 'react'
import {
  ShieldAlert, Ticket, Wand2, Keyboard, Gem, Circle, CreditCard,
  Package, Search, X, Ban, RotateCcw, Users, Clock, Trash2, Copy, Check,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import { useModRole } from '../moderation/useModRole'
import { fieldLabel, inputStyle } from './adminModal'
import {
  adminCreateRedeemCode, adminListRedeemCodes, adminSetRedeemCodeActive, adminDeleteRedeemCode,
  searchRedeemMallItems, type AdminRedeemCode, type RedeemMallItemOption,
} from '../economy/redeemCodes'
import { PENDING_MESSAGE } from './adminRequests'

type RewardType = 'currency' | 'item'
type CurrencyType = 'diamonds' | 'orbs' | 'vouchers'

function statusOf(code: AdminRedeemCode): { label: string; color: string } {
  if (!code.is_active) return { label: 'Deactivated', color: 'var(--text-muted)' }
  const now = Date.now()
  if (code.active_from && new Date(code.active_from).getTime() > now) return { label: 'Scheduled', color: 'var(--blue)' }
  if (code.expires_at && new Date(code.expires_at).getTime() <= now) return { label: 'Expired', color: 'var(--red)' }
  if (code.max_redemptions !== null && code.redemption_count >= code.max_redemptions) return { label: 'Fully claimed', color: 'var(--red)' }
  return { label: 'Active', color: 'var(--green)' }
}

function fromLocalInputValue(v: string): string | null {
  if (!v) return null
  return new Date(v).toISOString()
}

function CreateCodeForm({ onCreated }: { onCreated: () => void }) {
  const [mode, setMode] = useState<'auto' | 'manual'>('auto')
  const [manualCode, setManualCode] = useState('')
  const [codeLength, setCodeLength] = useState(5)
  const [rewardType, setRewardType] = useState<RewardType>('currency')
  const [currencyType, setCurrencyType] = useState<CurrencyType>('diamonds')
  const [currencyAmount, setCurrencyAmount] = useState(100)
  const [itemQuery, setItemQuery] = useState('')
  const [itemResults, setItemResults] = useState<RedeemMallItemOption[]>([])
  const [selectedItem, setSelectedItem] = useState<RedeemMallItemOption | null>(null)
  const [maxRedemptions, setMaxRedemptions] = useState<string>('')
  const [activeFrom, setActiveFrom] = useState('')
  const [expiresAt, setExpiresAt] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [created, setCreated] = useState<{ code: string } | null>(null)
  const [justCopied, setJustCopied] = useState(false)

  useEffect(() => {
    if (rewardType !== 'item' || !itemQuery.trim()) { setItemResults([]); return }
    const t = setTimeout(() => {
      searchRedeemMallItems(itemQuery).then(({ data }) => setItemResults(data))
    }, 250)
    return () => clearTimeout(t)
  }, [itemQuery, rewardType])

  async function handleCreate() {
    setError('')
    if (rewardType === 'item' && !selectedItem) { setError('Search and select a mall item.'); return }
    if (rewardType === 'currency' && (!currencyAmount || currencyAmount <= 0)) { setError('Enter an amount greater than zero.'); return }
    if (mode === 'manual' && manualCode.trim().length < 3) { setError('Enter a code (at least 3 characters).'); return }

    setSaving(true)
    const { data, pending, error: err } = await adminCreateRedeemCode({
      autoGenerate: mode === 'auto',
      code: mode === 'manual' ? manualCode.trim() : undefined,
      codeLength,
      rewardType,
      currencyType: rewardType === 'currency' ? currencyType : undefined,
      currencyAmount: rewardType === 'currency' ? currencyAmount : undefined,
      itemId: rewardType === 'item' ? selectedItem?.id : undefined,
      maxRedemptions: maxRedemptions.trim() ? Number(maxRedemptions) : null,
      activeFrom: fromLocalInputValue(activeFrom),
      expiresAt: fromLocalInputValue(expiresAt),
    })
    setSaving(false)
    if (err) { setError(err); return }
    if (pending) {
      setError(PENDING_MESSAGE)
      setManualCode(''); setSelectedItem(null); setItemQuery('')
      setMaxRedemptions(''); setActiveFrom('')
      return
    }
    if (data) {
      setCreated(data)
      setManualCode('')
      setSelectedItem(null)
      setItemQuery('')
      setMaxRedemptions('')
      setActiveFrom('')
      setExpiresAt('')
      onCreated()
    }
  }

  return (
    <div style={{ padding: 14, borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 20 }}>
      <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: '0 0 12px' }}>Create a code</p>

      {created && (
        <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(62,207,142,0.12)', marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 13, fontWeight: 800, color: 'var(--green)', letterSpacing: 0.5 }}>{created.code}</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <button
              onClick={async (e) => {
                ripple(e)
                try { await navigator.clipboard.writeText(created.code); setJustCopied(true); setTimeout(() => setJustCopied(false), 1500) } catch { /* ignore */ }
              }}
              aria-label="Copy code"
              style={{ width: 26, height: 26, borderRadius: 7, border: 'none', background: 'none', color: justCopied ? 'var(--green)' : 'var(--text-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
            >
              {justCopied ? <Check size={13} /> : <Copy size={13} />}
            </button>
            <button onClick={(e) => { ripple(e); setCreated(null) }} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer' }}><X size={14} /></button>
          </div>
        </div>
      )}

      <p style={fieldLabel}>Code source</p>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <button
          onClick={(e) => { ripple(e); setMode('auto') }}
          style={{
            flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 12, fontWeight: 700, cursor: 'pointer',
            border: `1px solid ${mode === 'auto' ? 'var(--accent)' : 'var(--border)'}`,
            background: mode === 'auto' ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface)',
            color: mode === 'auto' ? 'var(--accent)' : 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}
        >
          <Wand2 size={13} /> Auto-generate
        </button>
        <button
          onClick={(e) => { ripple(e); setMode('manual') }}
          style={{
            flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 12, fontWeight: 700, cursor: 'pointer',
            border: `1px solid ${mode === 'manual' ? 'var(--accent)' : 'var(--border)'}`,
            background: mode === 'manual' ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface)',
            color: mode === 'manual' ? 'var(--accent)' : 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}
        >
          <Keyboard size={13} /> Write manually
        </button>
      </div>

      {mode === 'auto' ? (
        <>
          <p style={fieldLabel}>Format: CHLVERS_ + random characters</p>
          <select value={codeLength} onChange={e => setCodeLength(Number(e.target.value))} style={{ ...inputStyle, marginBottom: 12 }}>
            <option value={5}>5 characters (CHLVERS_XXXXX)</option>
            <option value={6}>6 characters (CHLVERS_XXXXXX)</option>
          </select>
        </>
      ) : (
        <>
          <p style={fieldLabel}>Code</p>
          <input
            value={manualCode}
            onChange={e => setManualCode(e.target.value.toUpperCase())}
            placeholder="e.g. STREAMERNAME2026"
            style={{ ...inputStyle, marginBottom: 12, letterSpacing: 0.5 }}
          />
        </>
      )}

      <p style={fieldLabel}>Reward</p>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <button
          onClick={(e) => { ripple(e); setRewardType('currency') }}
          style={{
            flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 12, fontWeight: 700, cursor: 'pointer',
            border: `1px solid ${rewardType === 'currency' ? 'var(--accent)' : 'var(--border)'}`,
            background: rewardType === 'currency' ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface)',
            color: rewardType === 'currency' ? 'var(--accent)' : 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}
        >
          <CreditCard size={13} /> Currency
        </button>
        <button
          onClick={(e) => { ripple(e); setRewardType('item') }}
          style={{
            flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 12, fontWeight: 700, cursor: 'pointer',
            border: `1px solid ${rewardType === 'item' ? 'var(--accent)' : 'var(--border)'}`,
            background: rewardType === 'item' ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface)',
            color: rewardType === 'item' ? 'var(--accent)' : 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}
        >
          <Package size={13} /> Mall item
        </button>
      </div>

      {rewardType === 'currency' ? (
        <>
          <p style={fieldLabel}>Which currency</p>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            {([
              { key: 'diamonds' as const, icon: <Gem size={13} />, label: 'Diamonds' },
              { key: 'orbs' as const, icon: <Circle size={13} />, label: 'Orbs' },
              { key: 'vouchers' as const, icon: <Ticket size={13} />, label: 'Vouchers' },
            ]).map(c => (
              <button
                key={c.key}
                onClick={(e) => { ripple(e); setCurrencyType(c.key) }}
                style={{
                  flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 11.5, fontWeight: 700, cursor: 'pointer',
                  border: `1px solid ${currencyType === c.key ? 'var(--accent)' : 'var(--border)'}`,
                  background: currencyType === c.key ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface)',
                  color: currencyType === c.key ? 'var(--accent)' : 'var(--text-dim)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
                }}
              >
                {c.icon} {c.label}
              </button>
            ))}
          </div>
          <p style={fieldLabel}>Amount per redemption</p>
          <input
            type="number" min={1} value={currencyAmount}
            onChange={e => setCurrencyAmount(Number(e.target.value))}
            style={{ ...inputStyle, marginBottom: 12 }}
          />
        </>
      ) : (
        <>
          <p style={fieldLabel}>Search the mall</p>
          {selectedItem ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 10, background: 'var(--surface)', border: '1px solid var(--border)', marginBottom: 12 }}>
              {selectedItem.image_url && <img src={selectedItem.image_url} alt="" style={{ width: 30, height: 30, borderRadius: 7, objectFit: 'cover' }} />}
              <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', flex: 1 }}>{selectedItem.name}</span>
              <button onClick={(e) => { ripple(e); setSelectedItem(null) }} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer' }}><X size={14} /></button>
            </div>
          ) : (
            <>
              <div style={{ position: 'relative', marginBottom: 8 }}>
                <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                <input
                  value={itemQuery}
                  onChange={e => setItemQuery(e.target.value)}
                  placeholder="Item name…"
                  style={{ ...inputStyle, paddingLeft: 30 }}
                />
              </div>
              {itemResults.length > 0 && (
                <div style={{ marginBottom: 12, borderRadius: 10, border: '1px solid var(--border)', overflow: 'hidden' }}>
                  {itemResults.map(it => (
                    <button
                      key={it.id}
                      onClick={(e) => { ripple(e); setSelectedItem(it); setItemResults([]) }}
                      style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', background: 'var(--surface)', border: 'none', borderBottom: '1px solid var(--border)', cursor: 'pointer', textAlign: 'left' }}
                    >
                      {it.image_url && <img src={it.image_url} alt="" style={{ width: 26, height: 26, borderRadius: 6, objectFit: 'cover' }} />}
                      <span style={{ fontSize: 12, color: 'var(--text)' }}>{it.name}</span>
                      <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 'auto' }}>{it.category}</span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </>
      )}

      <p style={fieldLabel}>Max redemptions (blank = unlimited)</p>
      <input
        type="number" min={1} value={maxRedemptions}
        onChange={e => setMaxRedemptions(e.target.value)}
        placeholder="e.g. 500"
        style={{ ...inputStyle, marginBottom: 12 }}
      />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 4 }}>
        <div>
          <p style={fieldLabel}>Active from (blank = now)</p>
          <input type="datetime-local" value={activeFrom} onChange={e => setActiveFrom(e.target.value)} style={inputStyle} />
        </div>
        <div>
          <p style={fieldLabel}>Expires (blank = never)</p>
          <input type="datetime-local" value={expiresAt} onChange={e => setExpiresAt(e.target.value)} style={inputStyle} />
        </div>
      </div>

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '10px 0 0' }}>{error}</p>}

      <button
        onClick={(e) => { ripple(e); handleCreate() }}
        disabled={saving}
        className="btn-primary"
        style={{ width: '100%', padding: '11px 0', fontSize: 13, marginTop: 14, opacity: saving ? 0.6 : 1 }}
      >
        {saving ? 'Creating…' : 'Create code'}
      </button>
    </div>
  )
}

function CodeRow({ code, onToggled, onDeleted }: { code: AdminRedeemCode; onToggled: () => void; onDeleted: () => void }) {
  const [busy, setBusy] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deleteError, setDeleteError] = useState('')
  const [copied, setCopied] = useState(false)
  const status = statusOf(code)

  async function copyCode() {
    try {
      await navigator.clipboard.writeText(code.code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // clipboard permission denied — nothing to do
    }
  }

  async function toggle() {
    setBusy(true)
    await adminSetRedeemCodeActive(code.id, !code.is_active)
    setBusy(false)
    onToggled()
  }

  async function handleDelete() {
    setBusy(true)
    const { pending, error } = await adminDeleteRedeemCode(code.id)
    setBusy(false)
    if (error) { setDeleteError(error); setConfirmDelete(false); return }
    if (pending) { setDeleteError(PENDING_MESSAGE); setConfirmDelete(false); return }
    onDeleted()
  }

  return (
    <div style={{ padding: '11px 12px', borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 8 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', letterSpacing: 0.4 }}>{code.code}</span>
          <button
            onClick={(e) => { ripple(e); copyCode() }}
            aria-label="Copy code"
            style={{ width: 22, height: 22, borderRadius: 6, border: 'none', background: 'none', color: copied ? 'var(--green)' : 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}
          >
            {copied ? <Check size={12} /> : <Copy size={12} />}
          </button>
        </div>
        <span style={{ fontSize: 10.5, fontWeight: 700, color: status.color }}>{status.label}</span>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--text-dim)', margin: '0 0 8px' }}>
        {code.reward_type === 'currency'
          ? `${code.currency_amount?.toLocaleString()} ${code.currency_type}`
          : code.item_name ?? 'Mall item'}
        {' · '}
        <Users size={10} style={{ verticalAlign: -1 }} /> {code.redemption_count}{code.max_redemptions !== null ? `/${code.max_redemptions}` : ''}
        {code.expires_at && <> {' · '}<Clock size={10} style={{ verticalAlign: -1 }} /> expires {new Date(code.expires_at).toLocaleDateString()}</>}
      </p>

      {deleteError && <p style={{ fontSize: 10.5, color: 'var(--red)', margin: '0 0 8px' }}>{deleteError}</p>}

      {confirmDelete ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 10.5, color: 'var(--text-muted)', flex: 1 }}>
            {code.redemption_count > 0
              ? `Delete this code for good? Its ${code.redemption_count} redemption${code.redemption_count === 1 ? '' : 's'} will stay on record.`
              : 'Delete this code for good?'}
          </span>
          <button onClick={(e) => { ripple(e); setConfirmDelete(false) }} disabled={busy} className="btn-secondary" style={{ fontSize: 10.5, padding: '5px 10px', flexShrink: 0 }}>Cancel</button>
          <button onClick={(e) => { ripple(e); handleDelete() }} disabled={busy} className="btn-primary" style={{ fontSize: 10.5, padding: '5px 10px', background: 'var(--red)', flexShrink: 0 }}>
            {busy ? '…' : 'Delete'}
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={(e) => { ripple(e); toggle() }}
            disabled={busy}
            style={{
              fontSize: 11, fontWeight: 700, padding: '6px 12px', borderRadius: 8, cursor: 'pointer',
              border: '1px solid var(--border)', background: 'var(--surface)',
              color: code.is_active ? 'var(--red)' : 'var(--green)',
              display: 'inline-flex', alignItems: 'center', gap: 5, opacity: busy ? 0.6 : 1,
            }}
          >
            {code.is_active ? <><Ban size={11} /> Deactivate</> : <><RotateCcw size={11} /> Reactivate</>}
          </button>
          <button
            onClick={(e) => { ripple(e); setConfirmDelete(true) }}
            disabled={busy}
            aria-label="Delete code"
            style={{
              width: 30, height: 30, borderRadius: 8, cursor: 'pointer',
              border: '1px solid var(--border)', background: 'var(--surface)',
              color: 'var(--red)', display: 'flex', alignItems: 'center', justifyContent: 'center',
              opacity: busy ? 0.6 : 1, flexShrink: 0,
            }}
          >
            <Trash2 size={13} />
          </button>
        </div>
      )}
    </div>
  )
}

export default function AdminRedeemCodesPage() {
  usePageHeader({ title: 'Redeem Code Manager' })
  const { isAdmin, loading: roleLoading } = useModRole()
  const [codes, setCodes] = useState<AdminRedeemCode[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState('')

  function refresh() {
    setLoading(true)
    adminListRedeemCodes(query).then(({ data }) => { setCodes(data); setLoading(false) })
  }

  useEffect(() => {
    if (roleLoading || !isAdmin) return
    refresh()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleLoading, isAdmin])

  useEffect(() => {
    if (roleLoading || !isAdmin) return
    const t = setTimeout(refresh, 250)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query])

  if (roleLoading) return null

  if (!isAdmin) {
    return (
      <div style={{ maxWidth: 480, margin: '80px auto', textAlign: 'center', padding: 20 }}>
        <ShieldAlert size={32} style={{ color: 'var(--text-dim)', marginBottom: 10 }} />
        <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>Admins only</p>
        <p style={{ fontSize: 12.5, color: 'var(--text-dim)', marginTop: 6 }}>
          This page is restricted to Chillverse admins.
        </p>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 480, margin: '0 auto', paddingBottom: 48 }}>
      <CreateCodeForm onCreated={refresh} />

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0 }}>Existing codes</p>
      </div>
      <div style={{ position: 'relative', marginBottom: 12 }}>
        <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search codes…"
          style={{ ...inputStyle, paddingLeft: 30 }}
        />
      </div>

      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>Loading…</p>
      ) : codes.length === 0 ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>No codes yet.</p>
      ) : (
        codes.map(c => <CodeRow key={c.id} code={c} onToggled={refresh} onDeleted={refresh} />)
      )}
    </div>
  )
}
