// src/features/admin/adminOps.ts
// Client wrappers for migration 0056: feature flags, maintenance mode,
// broadcast notifications, CSV export, system health. Every RPC here is
// SECURITY DEFINER + is_admin_role()-gated server-side (same posture as
// adminStats.ts) — these wrappers just surface friendly errors on top.
import { supabase } from '../../shared/lib/supabase'
import { isPending } from './adminRequests'

function friendlyAdminError(message: string): string {
  if (message.includes('CV_ADMIN_FORBIDDEN')) return "You don't have permission to do that."
  if (message.includes('CV_ADMIN_NOT_FOUND')) return 'Not found.'
  if (message.includes('CV_ADMIN_VALIDATION')) return message.split(': ').slice(1).join(': ') || 'Invalid input.'
  return message
}

// ── Feature flags ─────────────────────────────────────────────────────
export interface FeatureFlag {
  key: string
  label: string
  description: string | null
  category: 'game' | 'map' | 'system'
  enabled: boolean
  updated_at: string
  /** How a *page* gated by this flag behaves when it's off: 'locked' shows
   *  a full-screen FeatureGateScreen (gate_title/gate_message); 'toast'
   *  lets the page render normally but pops toast_message on top of it.
   *  Only meaningful for flags a page actually checks (system:posts,
   *  system:lab, system:highlights) — harmless no-op default elsewhere. */
  gate_mode: 'locked' | 'toast'
  gate_title: string | null
  gate_message: string | null
  /** Copy for an *action* gated by this flag failing outright (e.g.
   *  tapping "Share your win" while Highlights is off) — shown
   *  regardless of gate_mode, since that's a toast either way. */
  toast_message: string | null
}

/** Publicly readable — any signed-in user can check flag state (that's how
 *  enforcement in Games.tsx / Exploration works), not just staff. */
export async function fetchFeatureFlags(): Promise<{ data: FeatureFlag[]; error: string | null }> {
  const { data, error } = await supabase.from('feature_flags').select('*').order('category').order('label')
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as FeatureFlag[], error: null }
}

export async function setFeatureFlag(key: string, enabled: boolean): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_feature_flag', { p_key: key, p_enabled: enabled })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Edits a flag's gate copy/mode — the "locked vs toast, and what it
 *  says" config for flags that gate a whole page or a post action. */
export async function setFeatureFlagGate(
  key: string,
  gateMode: 'locked' | 'toast',
  gateTitle: string,
  gateMessage: string,
  toastMessage: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_feature_flag_gate', {
    p_key: key,
    p_gate_mode: gateMode,
    p_gate_title: gateTitle,
    p_gate_message: gateMessage,
    p_toast_message: toastMessage,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Site status: live / maintenance / error ───────────────────────────
export interface AppConfig {
  maintenance_enabled: boolean
  maintenance_message: string
  maintenance_scheduled_for: string | null
  site_status: 'live' | 'maintenance' | 'error'
  error_title: string
  error_message: string
  /** Kill switch for the refer-and-earn popup advert (migration 0130).
   *  Off = useReferralPromoAd never shows the modal to anyone. */
  referral_popup_enabled: boolean
}

export async function fetchAppConfig(): Promise<{ data: AppConfig | null; error: string | null }> {
  const { data, error } = await supabase
    .from('app_config')
    .select('maintenance_enabled, maintenance_message, maintenance_scheduled_for, site_status, error_title, error_message, referral_popup_enabled')
    .eq('id', 1)
    .maybeSingle()
  if (error) return { data: null, error: error.message }
  return { data: data as AppConfig | null, error: null }
}

/** Refer-and-earn popup on/off. There is no row to delete for this one —
 *  unlike an announcement, the advert lives in code (useReferralPromoAd),
 *  so "delete it" and "turn it off" are the same switch. */
export async function setReferralPopupEnabled(enabled: boolean): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_referral_popup', { p_enabled: enabled })
  return { error: error ? friendlyAdminError(error.message) : null }
}

export async function setMaintenanceMode(
  enabled: boolean,
  message?: string,
  scheduledFor?: string | null,
): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_set_site_status', {
    p_status: enabled ? 'maintenance' : 'live',
    p_maintenance_message: message ?? null,
    p_scheduled_for: scheduledFor ?? null,
  })
  if (error) return { pending: false, error: friendlyAdminError(error.message) }
  return { pending: isPending(data), error: null }
}

/** Same singleton row, error-mode leg. Turning error mode on/off is
 *  mutually exclusive with maintenance mode — setting one to 'error' or
 *  'maintenance' implicitly clears the other, since site_status is a
 *  single tri-state column, not two independent booleans. */
export async function setErrorMode(
  enabled: boolean,
  title?: string,
  message?: string,
): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_set_site_status', {
    p_status: enabled ? 'error' : 'live',
    p_error_title: title ?? null,
    p_error_message: message ?? null,
  })
  if (error) return { pending: false, error: friendlyAdminError(error.message) }
  return { pending: isPending(data), error: null }
}

// ── Dashboard greeting override ──────────────────────────────────────
// Same singleton app_config row as maintenance mode. 'automatic' leaves
// the Dashboard's own time-of-day greeting pool in charge; 'custom' pins
// a single admin-written line/sub across every player's Dashboard.
export interface DashboardGreetingConfig {
  dashboard_greeting_mode: 'automatic' | 'custom'
  dashboard_greeting_line: string | null
  dashboard_greeting_sub: string | null
}

/** Publicly readable — Dashboard.tsx calls this for every signed-in user. */
export async function fetchDashboardGreeting(): Promise<{ data: DashboardGreetingConfig | null; error: string | null }> {
  const { data, error } = await supabase
    .from('app_config')
    .select('dashboard_greeting_mode, dashboard_greeting_line, dashboard_greeting_sub')
    .eq('id', 1)
    .maybeSingle()
  if (error) return { data: null, error: error.message }
  return { data: data as DashboardGreetingConfig | null, error: null }
}

export async function setDashboardGreeting(
  mode: 'automatic' | 'custom',
  line?: string | null,
  sub?: string | null,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_dashboard_greeting', {
    p_mode: mode,
    p_line: line ?? null,
    p_sub: sub ?? null,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Broadcast notification ───────────────────────────────────────────
export async function broadcastNotification(title: string, body: string, icon = 'megaphone'): Promise<{ count: number; pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_broadcast_notification', { p_title: title, p_body: body, p_icon: icon })
  if (error) return { count: 0, pending: false, error: friendlyAdminError(error.message) }
  // Since 0160b this returns { status, count } rather than a bare integer.
  if (isPending(data)) return { count: 0, pending: true, error: null }
  return { count: Number((data as { count?: number } | null)?.count ?? 0), pending: false, error: null }
}

// ── CSV export ────────────────────────────────────────────────────────
// Exports are queued like every other guarded action, but approving one
// doesn't hand the owner a CSV — it opens a 60-minute window in which the
// requester can run the export themselves (migration 0160b). So a second
// tap on the same button after approval is what actually downloads it.
export async function exportUsersCsv(): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_export_users')
  if (error) return { pending: false, error: friendlyAdminError(error.message) }
  if (isPending(data)) return { pending: true, error: null }
  downloadCsv(data as Record<string, unknown>[], `chillverse-users-${dateStamp()}.csv`)
  return { pending: false, error: null }
}

export async function exportTransactionsCsv(): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_export_transactions')
  if (error) return { pending: false, error: friendlyAdminError(error.message) }
  if (isPending(data)) return { pending: true, error: null }
  downloadCsv(data as Record<string, unknown>[], `chillverse-transactions-${dateStamp()}.csv`)
  return { pending: false, error: null }
}

function dateStamp(): string {
  return new Date().toISOString().slice(0, 10)
}

function downloadCsv(rows: Record<string, unknown>[], filename: string) {
  if (!rows || rows.length === 0) {
    // Still produce a (header-less) file rather than silently doing nothing —
    // an admin exporting an empty category should see an empty file, not
    // wonder if the click registered.
    rows = []
  }
  const headers = rows.length > 0 ? Object.keys(rows[0]) : ['no_data']
  const escape = (v: unknown) => {
    if (v === null || v === undefined) return ''
    const s = typeof v === 'object' ? JSON.stringify(v) : String(v)
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }
  const lines = [headers.join(','), ...rows.map(r => headers.map(h => escape(r[h])).join(','))]
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

// ── System health ────────────────────────────────────────────────────
export interface SystemHealth {
  generated_at: string
  client_errors: {
    errors_24h: number
    errors_7d: number
    top_messages_7d: { message: string; occurrences: number }[]
  }
  moderation_backlog: {
    open_reports: number
    oldest_open_report_age_hours: number | null
    actions_24h: number
  }
  support_backlog: {
    open_tickets: number
    oldest_open_ticket_age_hours: number | null
  }
  flags: {
    disabled_count: number
    maintenance_enabled: boolean
  }
}

export async function fetchSystemHealth(): Promise<{ data: SystemHealth | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_system_health')
  if (error) return { data: null, error: friendlyAdminError(error.message) }
  return { data: data as SystemHealth, error: null }
}

/** A single client_error_logs row (migration 0062) — the detail view
 *  behind admin_system_health's aggregated "top messages" list. */
export interface ClientErrorLogRow {
  id: string
  message: string
  stack: string | null
  path: string | null
  username: string | null
  created_at: string
}

export async function fetchRecentClientErrors(limit = 40): Promise<{ data: ClientErrorLogRow[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_recent_client_errors', { p_limit: limit })
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as ClientErrorLogRow[], error: null }
}

// ── Game Goal Reward Control (Activity Goals) ──────────────────────────
export interface GameGoalMallItem {
  id: string
  name: string
  image_url: string | null
  category: string
}

export interface GameGoalCycle {
  id: string
  status: 'draft' | 'live' | 'ended'
  thresholds: [number, number, number, number]
  xp_rewards: [number, number, number]
  final_reward_item_id: string | null
  final_item: GameGoalMallItem | null
  rolled_out_at: string | null
  ends_at: string | null
  created_at: string
  players_progressed: number
  players_completed: number
}

/** Staff-only — draft/live/ended cycles with final-item + participation stats. */
export async function fetchGameGoalCycles(): Promise<{ data: GameGoalCycle[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_get_game_goal_cycles')
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as GameGoalCycle[], error: null }
}

/** Creates the draft cycle if none exists yet, otherwise updates the pending one. */
export async function saveGameGoalDraft(
  thresholds: [number, number, number, number],
  xpRewards: [number, number, number],
  finalItemId: string | null,
  cycleId?: string,
): Promise<{ data: GameGoalCycle | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_save_game_goal_draft', {
    p_thresholds: thresholds,
    p_xp_rewards: xpRewards,
    p_final_item_id: finalItemId,
    p_cycle_id: cycleId ?? null,
  })
  if (error) return { data: null, error: friendlyAdminError(error.message) }
  return { data: data as GameGoalCycle, error: null }
}

/** Publishes a draft cycle live — ends whatever cycle is currently live. */
export async function rolloutGameGoalCycle(cycleId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_rollout_game_goal_cycle', { p_cycle_id: cycleId })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Deletes a cycle outright — draft, live, or ended. Unlike rolloutGameGoalCycle
 *  (which only ever *ends* the live cycle by replacing it with a new draft),
 *  this removes the row entirely; deleting the live cycle drops players back
 *  to the "Activity goal is being reset" empty state. */
export async function deleteGameGoalCycle(cycleId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_delete_game_goal_cycle', { p_cycle_id: cycleId })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Mall-item name autosuggest for the final-reward picker — active items only. */
export async function searchMallItems(query: string): Promise<{ data: GameGoalMallItem[]; error: string | null }> {
  if (!query.trim()) return { data: [], error: null }
  const { data, error } = await supabase
    .from('mall_items')
    .select('id, name, image_url, category')
    .eq('is_active', true)
    .ilike('name', `%${query.trim()}%`)
    .order('name')
    .limit(8)
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as GameGoalMallItem[], error: null }
}

// ── Popup announcements (migration 0108) ─────────────────────────────────
// A daily popup modal (same shape as the refer-and-earn PromoOverlay) shown
// to every signed-in user once per calendar day until an admin deletes it,
// or until it auto-expires at whatever duration the admin set. Distinct
// from broadcastNotification above, which fires a one-time in-app
// notification rather than a recurring popup.
/** 'daily' pops once per calendar day for as long as it's live. 'whats_new'
 *  is a release note: shown once per user, ever, and it outranks a live
 *  daily popup so a fresh drop is never buried under one (migration 0130). */
export type AnnouncementKind = 'daily' | 'whats_new'

export interface AdminAnnouncement {
  id: string
  title: string
  body: string
  image_url: string | null
  created_by: string | null
  created_at: string
  expires_at: string | null
  kind: AnnouncementKind
}

const ANNOUNCEMENT_IMAGES_BUCKET = 'announcement-images'
const MAX_ANNOUNCEMENT_IMAGE_BYTES = 5 * 1024 * 1024 // 5MB

/** Uploads the popup's banner image to the public `announcement-images`
 *  bucket and returns its public URL to pass as p_image_url to
 *  createAnnouncement. Admin-only write per migration 0108's storage RLS. */
export async function uploadAnnouncementImage(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Only image files can be used for the announcement image.')
  }
  if (file.size > MAX_ANNOUNCEMENT_IMAGE_BYTES) {
    throw new Error('Image is too large — please use a file under 5MB.')
  }

  const path = `${crypto.randomUUID()}.${extensionForImageFile(file)}`
  const { error } = await supabase.storage
    .from(ANNOUNCEMENT_IMAGES_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (error) throw new Error(`Failed to upload image: ${error.message}`)

  const { data } = supabase.storage.from(ANNOUNCEMENT_IMAGES_BUCKET).getPublicUrl(path)
  return data.publicUrl
}

/** Staff-only listing — every currently active (non-expired) announcement,
 *  most recent first. RLS on admin_announcements already scopes this to
 *  active rows, same query shape any signed-in user's client runs to find
 *  the one to show as a popup (see useAdminAnnouncement.ts). */
export async function fetchAnnouncements(): Promise<{ data: AdminAnnouncement[]; error: string | null }> {
  const { data, error } = await supabase
    .from('admin_announcements')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as AdminAnnouncement[], error: null }
}

/** p_duration_hours null = stays up until manually deleted. */
export async function createAnnouncement(
  title: string,
  body: string,
  imageUrl: string | null,
  durationHours: number | null,
  kind: AnnouncementKind = 'daily',
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_create_announcement', {
    p_title: title,
    p_body: body,
    p_image_url: imageUrl,
    p_duration_hours: durationHours,
    p_kind: kind,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

export async function deleteAnnouncement(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_delete_announcement', { p_id: id })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Flash Sale CMS (migration 0097, duration model per migration 0114) ──
// Two self-repeating schedules editable from the Ops console instead of the
// hardcoded FLASH_PACKS array that used to live in BuyDiamonds.tsx:
//   • weekly_special — recurs every week on day_of_week, open for
//     duration_hours starting at start_time. duration_hours can exceed 24,
//     so a sale can run past midnight or span several days.
//   • monthly_mega    — recurs on the last Saturday of every month
//     (computed server-side), open for duration_hours starting at start_time.
// If both would be live, monthly_mega always wins — enforced in
// get_active_flash_sale(), not here.
export interface FlashSaleRuleItem {
  id: string
  diamonds: number
  original_price_cents: number
  discount_pct: number
  sort_order: number
}

export interface FlashSaleRule {
  type: 'weekly_special' | 'monthly_mega'
  enabled: boolean
  day_of_week: number | null // 0=Sunday..6=Saturday — weekly_special only
  start_time: string         // "HH:MM:SS"
  duration_hours: number     // how long the sale stays open from start_time — can exceed 24 to span multiple days
  title: string
  subtitle: string | null
  image_url: string | null   // shown on the Game Zone card/modal (migration 0107)
  updated_at: string
  items: FlashSaleRuleItem[]
}

const FLASH_SALE_IMAGES_BUCKET = 'flash-sale-images'
const MAX_FLASH_SALE_IMAGE_BYTES = 5 * 1024 * 1024 // 5MB

function extensionForImageFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

/** Uploads the Game Zone card/modal image for a flash sale rule to the
 *  public `flash-sale-images` bucket and returns its public URL to pass as
 *  image_url to saveFlashSaleRule. Admin-only write per migration 0107's
 *  storage RLS policy. */
export async function uploadFlashSaleImage(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Only image files can be used for the flash sale image.')
  }
  if (file.size > MAX_FLASH_SALE_IMAGE_BYTES) {
    throw new Error('Image is too large — please use a file under 5MB.')
  }

  const path = `${crypto.randomUUID()}.${extensionForImageFile(file)}`
  const { error } = await supabase.storage
    .from(FLASH_SALE_IMAGES_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (error) throw new Error(`Failed to upload image: ${error.message}`)

  const { data } = supabase.storage.from(FLASH_SALE_IMAGES_BUCKET).getPublicUrl(path)
  return data.publicUrl
}

/** Both schedules + their items in one call, regardless of whether either
 *  is currently live — so admins can edit a sale that isn't open right now. */
export async function fetchFlashSaleRules(): Promise<{ data: FlashSaleRule[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_get_flash_sale_rules')
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as FlashSaleRule[], error: null }
}

export interface FlashSaleItemDraft {
  diamonds: number
  original_price_cents: number
  discount_pct: number
  sort_order: number
}

/** Saves a rule's schedule/copy and fully replaces its item list in one
 *  transaction — mirrors the server-side delete-then-insert in migration 0097. */
export async function saveFlashSaleRule(
  type: 'weekly_special' | 'monthly_mega',
  enabled: boolean,
  dayOfWeek: number | null,
  startTime: string,
  durationHours: number,
  title: string,
  subtitle: string | null,
  items: FlashSaleItemDraft[],
  imageUrl: string | null = null,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_save_flash_sale_rule', {
    p_type: type,
    p_enabled: enabled,
    p_day_of_week: dayOfWeek,
    p_start_time: startTime,
    p_duration_hours: durationHours,
    p_title: title,
    p_subtitle: subtitle,
    p_items: items,
    p_image_url: imageUrl,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Diamond gifting (migration 0109) ────────────────────────────────────
// Search-a-user, write-a-reason, pick-an-amount admin credit. Reuses the
// same user search as the Admin Dashboard drill-down (fetchAdminUserList
// in adminStats.ts) rather than a new picker RPC. Writes go through
// admin_grant_diamonds (SECURITY DEFINER + is_admin_role()-gated), which
// upserts user_wallets.gem_balance and logs a diamond_transactions row
// tagged pack_id='admin_gift' — same ledger every purchase/spend already
// writes to, so it shows up in the player's own transaction history too.

export interface DiamondGiftResult {
  transaction_id: string
  user_id: string
  username: string
  new_balance: number
}

export async function grantDiamonds(
  targetUserId: string,
  amount: number,
  reason: string,
): Promise<{ data: DiamondGiftResult | null; pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_grant_diamonds', {
    p_target_user_id: targetUserId,
    p_amount: amount,
    p_reason: reason.trim(),
  })
  if (error) return { data: null, pending: false, error: friendlyAdminError(error.message) }
  // Anyone who isn't the platform owner gets the gift queued for approval
  // instead of credited (migration 0160b) — no wallet has moved yet.
  if (isPending(data)) return { data: null, pending: true, error: null }
  return { data: data as DiamondGiftResult, pending: false, error: null }
}

export interface DiamondGiftLogRow {
  id: string
  user_id: string
  username: string
  avatar: string | null
  amount: number
  description: string | null
  created_at: string
}

/** Most recent admin-sourced gifts (pack_id = 'admin_gift'), newest first —
 *  the audit trail shown under the gifting form in the panel. */
export async function fetchRecentDiamondGifts(limit = 20): Promise<{ data: DiamondGiftLogRow[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_recent_diamond_gifts', { p_limit: limit })
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as DiamondGiftLogRow[], error: null }
}

// ── Mall Bundles (migrations 0106 + 0108) ───────────────────────────────
// The Mall's featured bundles: each is a banner image, a name, one fixed
// Diamond price, and a hand-picked set of existing Mall items. Tapping a
// banner in the Mall opens a sheet where players buy the whole set at that
// one price. All of it is admin-editable — the artwork can be swapped any
// time (uploaded to the `mall-banners` bucket), and the item list is any
// subset of the live catalog, in any order.
//
// 0108 turned the single bundle into a list. There can be as many as ops
// wants, but exactly one is pinned, and only the pinned one shows its item
// thumbnails on the Mall page — every other published bundle is artwork
// plus a "View bundle" tap into the sheet.
//
// `price_gems` is nullable on purpose: a published bundle with no price is
// display-only (browsable artwork + item row, no buy-all button), which is
// exactly how the 0105 banner behaved.

export type MallBundleStatus = 'draft' | 'published'

export interface MallBundleConfig {
  id: string
  name: string | null
  image_url: string | null
  price_gems: number | null
  item_ids: string[]
  status: MallBundleStatus
  is_pinned: boolean
  sort_order: number
  /** Items still active in the catalog. Lower than item_ids.length means
   *  some picks have since been deactivated and silently dropped out of
   *  what players see. */
  live_item_count: number
  updated_at: string | null
}

/** Admin read — every bundle including unpublished drafts, pinned first,
 *  unlike the public get_mall_bundles() the Mall page itself calls. */
export async function fetchMallBundles(): Promise<{ data: MallBundleConfig[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_list_mall_bundles')
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as MallBundleConfig[], error: null }
}

const MAX_BANNER_BYTES = 5 * 1024 * 1024

function extensionForBannerFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

/** Uploads a new banner image to the `mall-banners` bucket and returns its
 *  public URL. Doesn't save it to the config — call saveMallBundle with the
 *  returned URL to actually store it. */
export async function uploadMallBundleImage(file: File): Promise<{ url: string | null; error: string | null }> {
  if (!file.type.startsWith('image/')) return { url: null, error: 'Please pick an image file.' }
  if (file.size > MAX_BANNER_BYTES) return { url: null, error: 'Image is too large — please use a file under 5MB.' }

  const path = `${crypto.randomUUID()}.${extensionForBannerFile(file)}`
  const { error: uploadError } = await supabase.storage
    .from('mall-banners')
    .upload(path, file, { contentType: file.type, upsert: false })
  if (uploadError) return { url: null, error: `Failed to upload image: ${uploadError.message}` }

  const { data } = supabase.storage.from('mall-banners').getPublicUrl(path)
  return { url: data.publicUrl, error: null }
}

/** Creates a bundle when `id` is null, updates that one otherwise, and
 *  returns the id either way so a freshly created bundle can be selected
 *  straight afterwards.
 *
 *  `status: 'draft'` stores work-in-progress that no player can see and
 *  skips the completeness checks; `status: 'published'` puts it live and
 *  requires artwork, at least one item, and a name if a price is set
 *  (validated server-side, errors surface here). */
export async function saveMallBundle(
  config: {
    id: string | null
    name: string | null
    imageUrl: string | null
    priceGems: number | null
    itemIds: string[]
    status: MallBundleStatus
  },
): Promise<{ id: string | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_save_mall_bundle', {
    p_id: config.id,
    p_name: config.name,
    p_image_url: config.imageUrl,
    p_price_gems: config.priceGems,
    p_item_ids: config.itemIds,
    p_status: config.status,
  })
  if (error) return { id: null, error: friendlyAdminError(error.message) }
  return { id: (data as string | null) ?? null, error: null }
}

/** Pins a bundle — the one whose items show as thumbnails on the Mall
 *  page. Pinning is a move, not a toggle: whatever was pinned before is
 *  unpinned in the same transaction, and "at most one" is enforced by a
 *  unique index rather than trusted to this call. */
export async function setMallBundlePinned(
  id: string,
  pinned: boolean,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_mall_bundle_pinned', {
    p_id: id,
    p_pinned: pinned,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Deletes one bundle outright. Nobody's inventory is touched — items
 *  already bought stay bought. If it was the pinned one, the pin moves to
 *  the newest remaining published bundle. */
export async function deleteMallBundle(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_delete_mall_bundle', { p_id: id })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Mall item price + limited-time timer ────────────────────────────────
// Direct control over rows in mall_items, so changing what something costs
// or putting it on a countdown no longer means opening the Supabase table
// editor. mall_items carries SELECT policies only — there is no UPDATE
// policy for anyone — so every write here goes through a SECURITY DEFINER
// RPC gated on is_admin_role(), same posture as the bundle editor above.

export interface AdminMallItem {
  id: string
  name: string
  description: string
  category: string
  sub_category: string | null
  rarity: string
  image_url: string | null
  animated_url: string | null
  price_gems: number | null
  price_orbs: number | null
  unlock_xp: number | null
  is_active: boolean
  is_consumable: boolean
  /** ISO timestamp, or null for "no timer — always available". Once this
   *  passes, the Mall greys the item out and every purchase path rejects
   *  it server-side. */
  available_until: string | null
  /** Manual lock, independent of the timer above. When true, lock_message
   *  is always non-null — the server rejects a lock with no message. */
  is_locked: boolean
  lock_message: string | null
  /** How many players already own it. Shown as a warning next to the price
   *  field: repricing never touches anyone's inventory, but it's worth
   *  knowing how many people paid the old number. */
  owner_count: number
}

/** Catalog search for the item editor. Unlike searchMallItems() above
 *  (which powers the game-goal reward picker and only returns active
 *  items with three fields), this returns everything editable, includes
 *  inactive items, and sorts items currently on a live timer to the top. */
export async function adminSearchMallItems(
  query: string,
  category?: string | null,
): Promise<{ data: AdminMallItem[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_search_mall_items', {
    p_query: query.trim() || null,
    p_category: category ?? null,
    p_limit: 40,
  })
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as AdminMallItem[], error: null }
}

/** Sets what an item costs. Exactly one of gems/orbs may be non-null —
 *  purchase_mall_item charges Orbs whenever price_orbs is set and only
 *  falls through to Diamonds otherwise, so a row with both would silently
 *  make the Diamond price unreachable. Rejected server-side either way. */
export async function setMallItemPrice(
  itemId: string,
  priceGems: number | null,
  priceOrbs: number | null,
): Promise<{ pending: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_set_mall_item_price', {
    p_item_id: itemId,
    p_price_gems: priceGems,
    p_price_orbs: priceOrbs,
  })
  if (error) return { pending: false, error: friendlyAdminError(error.message) }
  return { pending: isPending(data), error: null }
}

/** Sets (or clears, with null) an item's limited-time deadline. Clearing
 *  it brings an ended item straight back to normal — nothing is destroyed
 *  when a timer lapses, the item just stops being purchasable. */
export async function setMallItemTimer(
  itemId: string,
  availableUntil: string | null,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_mall_item_timer', {
    p_item_id: itemId,
    p_available_until: availableUntil,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Locks (with a required message shown to players) or unlocks an item —
 *  independent of the limited-time timer above. Locking with an empty
 *  message is rejected server-side, since the whole point is that players
 *  see *why* they can't buy it. Unlocking always clears the message. */
export async function setMallItemLock(
  itemId: string,
  locked: boolean,
  message: string | null,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_mall_item_lock', {
    p_item_id: itemId,
    p_locked: locked,
    p_message: message,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Mall item create / edit / retire ────────────────────────────────────
// Full-field create+edit, separate from the price/timer/lock helpers
// above (those stay focused — this is for the rest: name, description,
// category, rarity, art). Existing item art lives in two buckets
// depending on category (checked against what's actually live, not
// guessed): profile_pic/banner/pvp_card in `profile-pics`, avatar_skin in
// `avatar-skins`. Both buckets had public-read but no admin write policy
// until migration 0125, so this used to only be possible by hand in the
// Supabase dashboard.

const MAX_ITEM_IMAGE_BYTES = 8 * 1024 * 1024 // gifs (e.g. animated banners) run bigger than static art
const MAX_ITEM_VIDEO_BYTES = 20 * 1024 * 1024

function itemImageBucket(category: string): string {
  return category === 'avatar_skin' ? 'avatar-skins' : 'profile-pics'
}

function extensionForItemFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

function extensionForItemVideoFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(mp4|webm|gif)$/.test(fromName)) return fromName
  if (file.type.includes('webm')) return 'webm'
  if (file.type.includes('gif')) return 'gif'
  return 'mp4'
}

/** Uploads item art to whichever bucket that category's existing images
 *  live in and returns its public URL. Doesn't touch the row — pass the
 *  URL to saveMallItem to actually store it. */
export async function uploadMallItemImage(
  file: File,
  category: string,
): Promise<{ url: string | null; error: string | null }> {
  if (!file.type.startsWith('image/')) return { url: null, error: 'Please pick an image file.' }
  if (file.size > MAX_ITEM_IMAGE_BYTES) return { url: null, error: 'Image is too large — please use a file under 8MB.' }

  const bucket = itemImageBucket(category)
  const path = `Admin uploads/${crypto.randomUUID()}.${extensionForItemFile(file)}`
  const { error: uploadError } = await supabase.storage
    .from(bucket)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (uploadError) return { url: null, error: `Failed to upload image: ${uploadError.message}` }

  const { data } = supabase.storage.from(bucket).getPublicUrl(path)
  return { url: data.publicUrl, error: null }
}

/** Uploads the animated art (mp4/webm/gif) that goes in animated_url.
 *  Mall.tsx renders it as a real <video> for mp4/webm and as an <img> for
 *  gif, and — for profile_effect specifically — Inventory.tsx equips this
 *  URL directly (equipped_profile_effect_url = item.animated_url), so for
 *  that category it isn't optional decoration, it's the whole item. Same
 *  bucket-by-category routing as the poster image. */
export async function uploadMallItemVideo(
  file: File,
  category: string,
): Promise<{ url: string | null; error: string | null }> {
  const isVideo = file.type.startsWith('video/')
  const isGif = file.type === 'image/gif'
  if (!isVideo && !isGif) return { url: null, error: 'Please pick a video (MP4/WebM) or an animated GIF.' }
  if (file.size > MAX_ITEM_VIDEO_BYTES) return { url: null, error: 'File is too large — please use something under 20MB.' }

  const bucket = itemImageBucket(category)
  const path = `Admin uploads/${crypto.randomUUID()}.${extensionForItemVideoFile(file)}`
  const { error: uploadError } = await supabase.storage
    .from(bucket)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (uploadError) return { url: null, error: `Failed to upload file: ${uploadError.message}` }

  const { data } = supabase.storage.from(bucket).getPublicUrl(path)
  return { url: data.publicUrl, error: null }
}

/* ── Item colour variants ("Customise this item") ──────────────────────
 *  Alternate colours a player can buy for a banner or profile pic they
 *  already own. Only banners and non-effect profile pics may have them —
 *  admin_save_item_variant rejects anything else — and there's a hard cap
 *  of 5 per item enforced by a DB trigger, so the UI's cap is a courtesy
 *  rather than the real gate. */

export interface AdminItemVariant {
  id: string
  item_id: string
  name: string
  image_url: string
  price_gems: number
  sort_order: number
}

export async function fetchItemVariantsAdmin(itemId: string): Promise<{ data: AdminItemVariant[]; error: string | null }> {
  const { data, error } = await supabase
    .from('mall_item_variants')
    .select('id, item_id, name, image_url, price_gems, sort_order')
    .eq('item_id', itemId)
    .order('sort_order', { ascending: true })
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as AdminItemVariant[], error: null }
}

export async function saveItemVariant(input: {
  id: string | null
  itemId: string
  name: string
  imageUrl: string
  priceGems: number
  sortOrder: number
}): Promise<{ id: string | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_save_item_variant', {
    p_id: input.id,
    p_item_id: input.itemId,
    p_name: input.name,
    p_image_url: input.imageUrl,
    p_price_gems: input.priceGems,
    p_sort_order: input.sortOrder,
  })
  if (error) return { id: null, error: friendlyAdminError(error.message) }
  return { id: (data as string | null) ?? null, error: null }
}

/** Refuses server-side once anyone owns the colour — deleting would
 *  cascade it out of every inventory that paid for it. */
export async function deleteItemVariant(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_delete_item_variant', { p_id: id })
  return { error: error ? friendlyAdminError(error.message) : null }
}

export interface MallItemDraft {
  id: string | null
  category: string
  name: string
  description: string
  subCategory: string | null
  rarity: string
  imageUrl: string | null
  animatedUrl: string | null
  priceGems: number | null
  priceOrbs: number | null
  unlockXp: number | null
  isConsumable: boolean
}

/** Creates an item when `draft.id` is null, updates that row otherwise,
 *  and returns the id either way so a freshly created item can be
 *  selected straight afterwards. DB CHECK constraints are the backstop
 *  for category/rarity/price validity — a violation comes back as a
 *  plain error message here. */
export async function saveMallItem(draft: MallItemDraft): Promise<{ id: string | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_save_mall_item', {
    p_id: draft.id,
    p_category: draft.category,
    p_name: draft.name,
    p_description: draft.description,
    p_sub_category: draft.subCategory,
    p_rarity: draft.rarity,
    p_image_url: draft.imageUrl,
    p_animated_url: draft.animatedUrl,
    p_price_gems: draft.priceGems,
    p_price_orbs: draft.priceOrbs,
    p_unlock_xp: draft.unlockXp,
    p_is_consumable: draft.isConsumable,
  })
  if (error) return { id: null, error: friendlyAdminError(error.message) }
  return { id: (data as string | null) ?? null, error: null }
}

/** Pulls an item off the shelf (or restocks it) without deleting the row —
 *  players who already own it keep it either way, same as locking. Unlike
 *  locking there's no message; use this for things that just shouldn't be
 *  for sale anymore rather than a "back soon" state. */
export async function setMallItemActive(itemId: string, active: boolean): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_mall_item_active', {
    p_item_id: itemId,
    p_active: active,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Economy integrity watchdog ──────────────────────────────────────────
// Blocked writes cannot be logged: when RLS rejects an insert the whole
// statement rolls back, and any log row a trigger wrote rolls back with
// it. So instead of trying to catch attempts, the watchdog checks
// economic invariants on a schedule and files anything impossible —
// which also catches successful exploitation of holes nobody has found
// yet. See migration 0117.

export type SecuritySeverity = 'info' | 'warn' | 'critical'

export interface SecurityEvent {
  id: string
  kind: string
  severity: SecuritySeverity
  user_id: string | null
  username: string | null
  summary: string
  detail: Record<string, unknown>
  first_seen: string
  last_seen: string
  /** How many scans have seen this same problem. A rising count on an
   *  unresolved finding means it's still true, not that it recurred. */
  seen_count: number
  resolved_at: string | null
  resolution: string | null
}

/** Human labels for the invariant each finding violates. */
export const SECURITY_KIND_LABEL: Record<string, string> = {
  unpaid_item: 'Item with no payment',
  xp_gate_bypassed: 'XP requirement bypassed',
  expired_item_acquired: 'Acquired after timer ended',
  reward_without_achievement: 'Reward without achievement',
  wallet_ledger_drift: 'Balance/ledger mismatch',
  negative_balance: 'Negative balance',
}

export async function fetchSecurityEvents(
  includeResolved = false,
): Promise<{ data: SecurityEvent[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_get_security_events', {
    p_include_resolved: includeResolved,
    p_limit: 200,
  })
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as SecurityEvent[], error: null }
}

export interface IntegrityScanResult {
  scanned_at: string
  findings_touched: number
  open_critical: number
  open_total: number
}

/** Runs the scan immediately. It also runs hourly on its own via pg_cron,
 *  so this is for when you want an answer right now. */
export async function runIntegrityScan(): Promise<{ data: IntegrityScanResult | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_run_integrity_scan')
  if (error) return { data: null, error: friendlyAdminError(error.message) }
  return { data: data as IntegrityScanResult, error: null }
}

/** Dismisses a finding. If the underlying problem is still true, the next
 *  scan re-opens it — so resolving without fixing doesn't hide anything. */
export async function resolveSecurityEvent(
  id: string,
  resolution: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_resolve_security_event', {
    p_id: id,
    p_resolution: resolution,
  })
  return { error: error ? friendlyAdminError(error.message) : null }
}

// ── Integrity actions (migration 0119) ──────────────────────────────────
// Real fixes, not just dismissals: revoking actually deletes the item and
// notifies the player, marking-as-gift backfills a real `gifts` row so the
// scan's own checks pass on their own, and the official-account allowlist
// stops an account from generating findings at the source going forward.

/** Bulk-revokes every open `xp_gate_bypassed` finding: deletes the item
 *  from each player's inventory, notifies them why, and resolves the
 *  finding. Real fix — it won't be reopened by the next hourly scan. */
export async function revokeBypassedItems(
  note?: string,
): Promise<{ revokedCount: number; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_revoke_bypassed_items', { p_note: note ?? null })
  if (error) return { revokedCount: 0, error: friendlyAdminError(error.message) }
  const result = data as { revoked_count: number } | null
  return { revokedCount: result?.revoked_count ?? 0, error: null }
}

/** Revokes the item behind a single finding, whatever its kind — works
 *  for any finding whose `detail` carries an `item_id` (unpaid_item,
 *  xp_gate_bypassed, expired_item_acquired, reward_without_achievement).
 *  Same delete + notify + resolve as the bulk actions, one row at a time,
 *  so a new finding kind never needs a matching new action. */
export async function revokeItemFinding(
  eventId: string,
  note?: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_revoke_item_finding', { p_event_id: eventId, p_note: note ?? null })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Revokes every open item-carrying finding of a given kind — the
 *  general form `revokeBypassedItems` is built on. Only kinds whose
 *  `detail` carries an `item_id` are accepted; the RPC rejects anything
 *  else (e.g. wallet_ledger_drift, negative_balance), since those are
 *  balance problems, not items to delete. */
export async function bulkRevokeByKind(
  kind: string,
  note?: string,
): Promise<{ revokedCount: number; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_bulk_revoke_by_kind', { p_kind: kind, p_note: note ?? null })
  if (error) return { revokedCount: 0, error: friendlyAdminError(error.message) }
  const result = data as { revoked_count: number } | null
  return { revokedCount: result?.revoked_count ?? 0, error: null }
}

/** For an `unpaid_item` finding, backfills a real `gifts` row for the
 *  owner so the scan's own "was this a gift?" check passes going forward,
 *  and resolves the finding. */
export async function markItemAsGift(
  eventId: string,
  note?: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_mark_item_as_gift', { p_event_id: eventId, p_note: note ?? null })
  return { error: error ? friendlyAdminError(error.message) : null }
}

/** Exempts (or un-exempts) an official/house account from the integrity
 *  scan. Exempting resolves every open finding for that user and stops
 *  new ones from being raised — the allowlist lives on
 *  profiles.integrity_exempt and every scan branch checks it. */
export async function setOfficialAccount(
  userId: string,
  exempt: boolean,
  note?: string,
): Promise<{ findingsResolved: number; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_set_official_account', {
    p_user_id: userId,
    p_exempt: exempt,
    p_note: note ?? null,
  })
  if (error) return { findingsResolved: 0, error: friendlyAdminError(error.message) }
  const result = data as { findings_resolved: number } | null
  return { findingsResolved: result?.findings_resolved ?? 0, error: null }
}

// ── Clubs (0133) ──────────────────────────────────────────────────────
/** One standing club plus who started it. Clubs that were archived or
 *  deleted aren't returned at all — the list is "still standing" by
 *  definition, so an empty row is never an archived club. */
export interface ClubOwnerRow {
  room_id: string
  club_name: string
  slug: string | null
  created_at: string
  creator_id: string | null
  creator_username: string | null
  creator_display_name: string | null
  /** False when the creator handed the club over — the club stands, but
   *  someone else runs it now. */
  still_president: boolean
  member_count: number
  channel_count: number
  join_mode: string | null
  last_message_at: string | null
}

export async function fetchClubOwners(): Promise<{ data: ClubOwnerRow[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_club_owners')
  if (error) return { data: [], error: friendlyAdminError(error.message) }
  return { data: (data ?? []) as ClubOwnerRow[], error: null }
}

// ── Elimination weekend reward ────────────────────────────────────────
//
// The survivor payout lives on app_config.pvp_elimination_reward and is
// OWNER-ONLY (migration 0161a) — not admin, not staff, not the moderator.
// Deliberately not routed through the admin_requests approval queue: that
// queue exists so an admin can ASK the owner for something, and this is a
// dial only the owner may touch at all, so there is nothing to ask for.
//
// Reading it needs no wrapper — it comes back on pvp_elimination_status as
// `survivor_reward`, which is how the Arena board prints it.

export async function setEliminationReward(
  vouchers: number,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_elimination_reward', {
    p_vouchers: Math.round(vouchers),
  })
  if (!error) return { error: null }
  if (error.message.includes('owner_only')) {
    return { error: 'Only the platform owner can change this.' }
  }
  if (error.message.includes('reward_out_of_range')) {
    return { error: 'Pick a number between 0 and 1000.' }
  }
  return { error: friendlyAdminError(error.message) }
}

/**
 * The registration-sheet banner. Owner-only, same as the reward above, and
 * an empty string clears it — the sheet falls back to a flat treatment
 * rather than a placeholder image, so "no banner" is a real state.
 */
export async function setEliminationBanner(
  url: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_elimination_banner', { p_url: url })
  if (!error) return { error: null }
  if (error.message.includes('owner_only')) {
    return { error: 'Only the platform owner can change this.' }
  }
  return { error: friendlyAdminError(error.message) }
}
