// src/features/admin/adminStats.ts
import { supabase } from '../../shared/lib/supabase'
import type { StaffRole } from '../moderation/moderation'

export interface AdminOverviewStats {
  total_users: number
  new_users_7d: number
  new_users_30d: number
  active_today: number
  active_7d: number
  pro_subscribers: number
  pro_orbit: number
  pro_void: number
  staff_count: number
  banned_users: number
}

export interface AdminEconomyStats {
  diamonds_in_circulation: number
  diamonds_credited_30d: number
  purchase_tx_30d: number
  /** Wallets over the 3,000 diamond threshold — added in migration 0034
   *  alongside admin_list_users()/admin_get_user_detail() so a suspicious
   *  cluster is visible without opening the Users drill-down. */
  flagged_balance_count: number
  top_mall_items: { name: string; category: string; owners: number }[]
}

export interface AdminGamesStats {
  total_sessions: number
  sessions_7d: number
  top_games: { game: string; sessions: number }[]
  /** Avg game_sessions.duration_sec over the last 30d, rounded. Null when
   *  there's no session with a recorded duration in that window (rather
   *  than showing a misleading 0). */
  avg_session_sec: number | null
  /** One entry per of the last 7 days (oldest first), zero-filled for days
   *  with no sessions — always exactly 7 entries. */
  sessions_daily_7d: { day: string; sessions: number }[]
}

export interface AdminMultiplayerStats {
  active_rooms: number
  rooms_7d: number
  top_multiplayer_games: { game_id: string; rooms: number }[]
}

export interface AdminHaloAiStats {
  questions_7d: number
  questions_30d: number
  active_users_7d: number
  provider_split_30d: Record<string, number>
  /** One entry per of the last 7 days (oldest first), zero-filled —
   *  summed from halo_ai_usage.question_count, always exactly 7 entries. */
  messages_daily_7d: { day: string; messages: number }[]
  /** Avg halo_ai_logs.response_ms over the last 7d. Null until the
   *  halo-ai-chat edge function has logged at least one exchange since the
   *  response_ms column was added — historical rows never had this
   *  recorded, so they're correctly excluded rather than treated as 0ms. */
  avg_response_ms: number | null
  /** % of logged exchanges (last 7d, response_ms not null) where
   *  success = true. Null for the same reason as avg_response_ms — no
   *  tracked exchanges yet. There's only ever been one provider
   *  (OpenRouter) since Groq was removed, so this is OpenRouter's own
   *  uptime, not a multi-provider split. */
  uptime_pct_7d: number | null
}

export interface AdminModerationStats {
  open_reports: number
  actions_7d: number
  currently_banned: number
}

export interface AdminSupportStats {
  open_tickets: number
  tickets_7d: number
  /** Avg minutes between a ticket's created_at and its first staff reply,
   *  over tickets opened in the last 30d that HAVE a staff reply yet.
   *  Null when there's no such ticket in that window (not 0). */
  avg_first_response_min: number | null
}

export interface AdminDashboardStats {
  generated_at: string
  overview: AdminOverviewStats
  economy: AdminEconomyStats
  games: AdminGamesStats
  multiplayer: AdminMultiplayerStats
  halo_ai: AdminHaloAiStats
  moderation: AdminModerationStats
  support: AdminSupportStats
}

/** Fetches the full admin dashboard payload in one round trip. The RPC
 *  itself re-checks is_admin_role() server-side (see migration 0029) —
 *  this call fails safely for non-admins even if this function were
 *  somehow invoked without the AdminDashboard.tsx self-guard. */
export async function fetchAdminDashboardStats(): Promise<{ data: AdminDashboardStats | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_dashboard_stats')

  if (error) {
    console.error('fetchAdminDashboardStats error:', error)
    if (error.message?.includes('CV_ADMIN_FORBIDDEN')) {
      return { data: null, error: "You don't have permission to view this." }
    }
    return { data: null, error: 'Failed to load dashboard stats. Please try again.' }
  }

  return { data: data as AdminDashboardStats, error: null }
}

// ── User drill-down (list + detail) ──────────────────────────────────
// Backs admin_list_users() / admin_get_user_detail() from migration
// 0030 — both SECURITY DEFINER + is_admin_role()-gated server-side, same
// posture as admin_dashboard_stats() above.

export interface AdminUserRow {
  id: string
  username: string
  display_name: string | null
  email: string
  avatar: string
  gem_balance: number
  balance_flagged: boolean
  is_pro: boolean
  pro_tier: string | null
  staff_role: StaffRole | null
  is_banned: boolean
  created_at: string
  last_seen_at: string | null
}

export interface AdminUserListResult {
  rows: AdminUserRow[]
  total: number
  page: number
  page_size: number
  /** Owner-only. When false every row's gem_balance is zeroed server-side,
   *  so the balance chip must be hidden rather than printed as 0. */
  wallet_visible: boolean
}

/** Category filters mirroring the Overview stat cards — each branch in the
 *  `admin_list_users` RPC (migration 0054) matches the exact predicate
 *  `admin_dashboard_stats` used to produce that same card's number, so a
 *  drill-down list's count always lines up with what's printed on the card. */
export type AdminUserFilter = 'new_7d' | 'new_30d' | 'active_7d' | 'pro' | 'staff' | 'banned' | 'currently_banned'

/** Fetches one page of the admin user list, optionally filtered by a
 *  username / display name / email search term and/or a category filter
 *  (e.g. "banned", "active_7d") — the two combine with AND, so a long
 *  filtered list can still be narrowed by name. `search` is trimmed and
 *  sent as `null` when empty so the RPC's `p_search is null or p_search = ''`
 *  short-circuit returns everyone rather than matching on an empty string. */
export async function fetchAdminUserList(
  page: number,
  pageSize: number,
  search: string,
  filter?: AdminUserFilter | null,
): Promise<{ data: AdminUserListResult | null; error: string | null }> {
  const trimmed = search.trim()
  const { data, error } = await supabase.rpc('admin_list_users', {
    p_page: page,
    p_page_size: pageSize,
    p_search: trimmed === '' ? null : trimmed,
    p_filter: filter ?? null,
  })

  if (error) {
    console.error('fetchAdminUserList error:', error)
    if (error.message?.includes('CV_ADMIN_FORBIDDEN')) {
      return { data: null, error: "You don't have permission to view this." }
    }
    return { data: null, error: 'Failed to load users. Please try again.' }
  }

  return { data: data as AdminUserListResult, error: null }
}

export interface AdminUserWalletBreakdown {
  gem_balance: number
  balance_flagged: boolean
  /** Real-money IAP only — rows whose description starts with "Diamond
   *  pack" (the one reliable signal; pack_id is reused for other things
   *  on other row types, so it can't be used to detect this). */
  total_purchased: number
  /** Everything else credited — admin grants, referrals, missions, Halo
   *  events, etc. */
  total_earned: number
  /** Any debit — gifts sent, Mall spends, version upgrades, etc. */
  total_spent: number
  /** Count of completed diamond-pack purchases (not their total value). */
  purchase_count: number
}

export type AdminUserWalletActivityType =
  | 'purchase' | 'earned' | 'spend' | 'admin_grant' | 'referral' | 'mission'
  | 'mystery_box' | 'daily_challenge' | 'lucky_user' | 'halo_surprise' | 'other'

export interface AdminUserWalletActivity {
  id: string
  type: AdminUserWalletActivityType
  label: string
  /** Raw ledger reference (e.g. "mystery_box:2026-08-14") — shown as a
   *  small audit-trail subtitle so support can trace a row back to the
   *  exact event that generated it. */
  reference: string | null
  amount: number
  created_at: string
}

export interface AdminUserTopGame {
  game: string
  sessions: number
}

export interface AdminUserRecentSession {
  game: string
  score: number
  xp_earned: number
  duration_sec: number
  result: string
  played_at: string
}

export interface AdminUserGamesSummary {
  total_sessions: number
  sessions_7d: number
  total_xp_from_games: number
  top_games: AdminUserTopGame[]
  recent_sessions: AdminUserRecentSession[]
}

export interface AdminUserDetail {
  id: string
  username: string
  display_name: string | null
  email: string
  avatar: string
  country: string | null
  bio: string | null
  xp: number
  level: number
  streak: number
  is_pro: boolean
  pro_tier: string | null
  pro_expires_at: string | null
  staff_role: StaffRole | null
  is_banned: boolean
  banned_until: string | null
  ban_reason: string | null
  public_notice_title: string | null
  public_notice_reason: string | null
  created_at: string
  last_login_at: string | null
  last_seen_at: string | null
  referral_count: number
  wallet: AdminUserWalletBreakdown
  recent_wallet_activity: AdminUserWalletActivity[]
  games: AdminUserGamesSummary
  /** False for every admin who isn't the platform owner. The server zeroes
   *  the wallet block and empties the activity list in that case (migration
   *  0160d) — the numbers never reach the client, so hiding the tab here is
   *  presentation only, not the control. */
  wallet_visible: boolean
}

/** Fetches the full detail record — profile, role/ban status, and a
 *  wallet breakdown (current balance, lifetime purchased/earned/spent,
 *  and the last 30 ledger entries) — for a single user. */
export async function fetchAdminUserDetail(
  userId: string,
): Promise<{ data: AdminUserDetail | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_get_user_detail', { p_user_id: userId })

  if (error) {
    console.error('fetchAdminUserDetail error:', error)
    if (error.message?.includes('CV_ADMIN_FORBIDDEN')) {
      return { data: null, error: "You don't have permission to view this." }
    }
    if (error.message?.includes('CV_USER_NOT_FOUND')) {
      return { data: null, error: 'That user no longer exists.' }
    }
    return { data: null, error: 'Failed to load user detail. Please try again.' }
  }

  return { data: data as AdminUserDetail, error: null }
}
