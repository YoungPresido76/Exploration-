// src/features/admin/AdminStorageCleanupSection.tsx
//
// Finds and removes storage objects nothing points at.
//
// Why this exists: deleting a database row never deletes a storage
// object. Every abandoned draft, replaced hero image and deleted post
// used to leave its file behind, invisible and still counted against the
// project's storage. The uploaders were fixed so new orphans stop
// appearing (see the deferred hero upload in BlogEditorModal and
// deletePost in posts.ts) — this clears what was already there.
//
// The listing is an RPC because it needs to read storage.objects, but the
// DELETE has to go through the Storage API: storage.protect_delete()
// refuses a plain SQL delete. Staff already hold delete policies on all
// three buckets.
import { useCallback, useEffect, useState } from 'react'
import { HardDrive, Trash2, Loader2, Check } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { SectionTitle } from '../settings/settingsShared'
import Toast, { useToast } from '../../shared/components/Toast'

interface OrphanObject {
  bucket_id: string
  name: string
  size_bytes: number
  created_at: string
}

function prettyBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`
  return `${(n / (1024 * 1024)).toFixed(1)} MB`
}

export default function AdminStorageCleanupSection() {
  const [orphans, setOrphans] = useState<OrphanObject[]>([])
  const [loading, setLoading] = useState(true)
  const [working, setWorking] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const { toast, showToast } = useToast()

  const load = useCallback(() => {
    setLoading(true)
    supabase.rpc('admin_list_orphan_media').then(({ data, error }) => {
      if (error) console.error('admin_list_orphan_media error:', error)
      setOrphans((data ?? []) as OrphanObject[])
      setLoading(false)
    })
  }, [])

  useEffect(() => { load() }, [load])

  async function deleteAll() {
    if (working || orphans.length === 0) return
    setWorking(true)

    // Grouped per bucket: remove() takes many paths but only one bucket.
    const byBucket = new Map<string, string[]>()
    for (const o of orphans) {
      byBucket.set(o.bucket_id, [...(byBucket.get(o.bucket_id) ?? []), o.name])
    }

    let removed = 0
    let failed = 0
    for (const [bucket, paths] of byBucket) {
      const { error } = await supabase.storage.from(bucket).remove(paths)
      if (error) {
        console.error(`cleanup ${bucket} error:`, error)
        failed += paths.length
      } else {
        removed += paths.length
      }
    }

    setWorking(false)
    setConfirming(false)
    showToast({
      message: failed
        ? `Removed ${removed}, ${failed} failed`
        : `Removed ${removed} file${removed === 1 ? '' : 's'}`,
      icon: failed ? Trash2 : Check,
      iconColor: failed ? '#ff6b6b' : 'var(--green)',
    })
    load()
  }

  if (loading) {
    return (
      <div style={{ padding: 16, display: 'flex', justifyContent: 'center', color: 'var(--text-dim)' }}>
        <Loader2 size={16} className="spin" />
      </div>
    )
  }

  const totalBytes = orphans.reduce((sum, o) => sum + o.size_bytes, 0)

  return (
    <>
      <SectionTitle>Storage cleanup</SectionTitle>

      <div className="neu-card" style={{ padding: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{
            width: 30, height: 30, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: orphans.length ? 'rgba(255,79,79,0.12)' : 'rgba(62,207,142,0.12)',
            color: orphans.length ? 'var(--red)' : 'var(--green)',
          }}>
            <HardDrive size={15} />
          </span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>
              {orphans.length === 0 ? 'Nothing to clean up' : `${orphans.length} unreferenced files`}
            </p>
            <p style={{ fontSize: 11.5, color: 'var(--text-dim)' }}>
              {orphans.length === 0
                ? 'Every stored file is still in use.'
                : `${prettyBytes(totalBytes)} in blog, support and feed images`}
            </p>
          </div>
        </div>

        {orphans.length > 0 && (
          <>
            <p style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 10, lineHeight: 1.5 }}>
              These belong to no post or article. Anything uploaded in the last 24 hours is
              left alone, since it may belong to a draft that's still open.
            </p>

            <div style={{ marginTop: 10, maxHeight: 160, overflowY: 'auto' }}>
              {orphans.map(o => (
                <div key={`${o.bucket_id}/${o.name}`} style={{ display: 'flex', gap: 8, padding: '4px 0', fontSize: 11, color: 'var(--text-dim)' }}>
                  <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {o.bucket_id}/{o.name.split('/').pop()}
                  </span>
                  <span style={{ flex: 'none' }}>{prettyBytes(o.size_bytes)}</span>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => (confirming ? deleteAll() : setConfirming(true))}
              disabled={working}
              style={{
                width: '100%', marginTop: 12, padding: '10px 0', borderRadius: 10, border: 'none',
                background: confirming ? 'var(--red)' : 'var(--surface2)',
                color: confirming ? '#fff' : 'var(--text-dim)',
                fontSize: 12.5, fontWeight: 800, fontFamily: 'inherit',
                cursor: working ? 'default' : 'pointer',
              }}
            >
              {working
                ? 'Deleting…'
                : confirming
                  ? `Yes, delete ${orphans.length} files — can't be undone`
                  : `Delete ${prettyBytes(totalBytes)} of unused files`}
            </button>
          </>
        )}
      </div>

      <Toast toast={toast} />
    </>
  )
}
