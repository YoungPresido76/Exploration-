// src/features/admin/AdminApprovalsSection.tsx
//
// The Approvals wing. For the platform owner this is the review queue:
// every sensitive action another admin tried to take (gifting diamonds,
// redeem codes, bounties, role changes, exports, site status, broadcasts,
// item pricing) waits here until it's approved or declined.
//
// Any other admin sees the same screen scoped to their own requests, so
// they can watch a request's status and cancel one they no longer want.
// The scoping is done by admin_list_requests server-side, not here.
import { useCallback, useEffect, useState } from 'react'
import { CheckCircle2, Clock, ShieldCheck, X } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { SectionTitle } from '../settings/settingsShared'
import { ripple } from '../../shared/lib/ripple'
import { SegmentedTabs } from './AdminKit'
import {
  approveAdminRequest, cancelAdminRequest, fetchAdminRequests, rejectAdminRequest,
  type AdminRequest, type AdminRequestStatus,
} from './adminRequests'

const STATUS_TINT: Record<AdminRequestStatus, string> = {
  pending:   'var(--gold)',
  approved:  'var(--green)',
  consumed:  'var(--green)',
  rejected:  'var(--red)',
  failed:    'var(--red)',
  expired:   'var(--text-muted)',
  cancelled: 'var(--text-muted)',
}

const STATUS_LABEL: Record<AdminRequestStatus, string> = {
  pending:   'Waiting on you',
  approved:  'Approved',
  consumed:  'Approved · used',
  rejected:  'Declined',
  failed:    'Approved but failed',
  expired:   'Expired',
  cancelled: 'Cancelled',
}

function timeAgo(iso: string): string {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.round(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return `${Math.round(hrs / 24)}d ago`
}

function RequestCard({ req, isOwner, busy, onApprove, onReject, onCancel }: {
  req: AdminRequest
  isOwner: boolean
  busy: boolean
  onApprove: (note: string) => void
  onReject: (note: string) => void
  onCancel: () => void
}) {
  const [note, setNote] = useState('')
  const [noteOpen, setNoteOpen] = useState(false)
  const pending = req.status === 'pending'

  return (
    <div className="neu-card" style={{ padding: 14, marginBottom: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 9 }}>
        <Avatar src={req.requester_avatar} name={req.requester_display_name || req.requester_username} ownerId={req.requested_by} size={30} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {req.requester_display_name || req.requester_username}
          </p>
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '1px 0 0' }}>
            @{req.requester_username} · {timeAgo(req.created_at)}
          </p>
        </div>
        <span style={{
          flexShrink: 0, fontSize: 9.5, fontWeight: 900, letterSpacing: '0.05em', textTransform: 'uppercase',
          padding: '4px 8px', borderRadius: 999, color: STATUS_TINT[req.status],
          background: `color-mix(in srgb, ${STATUS_TINT[req.status]} 14%, transparent)`,
          border: `1px solid color-mix(in srgb, ${STATUS_TINT[req.status]} 35%, transparent)`,
        }}>
          {STATUS_LABEL[req.status]}
        </span>
      </div>

      <p style={{ fontSize: 13, color: 'var(--text)', margin: 0, fontWeight: 600, lineHeight: 1.35 }}>
        Wants to {req.summary}.
      </p>
      {req.reason && (
        <p style={{ fontSize: 11.5, color: 'var(--text-dim)', margin: '6px 0 0', lineHeight: 1.4 }}>
          “{req.reason}”
        </p>
      )}
      {req.error && (
        <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '6px 0 0' }}>{req.error}</p>
      )}
      {req.review_note && !pending && (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '6px 0 0' }}>
          Your note: {req.review_note}
        </p>
      )}

      {pending && isOwner && (
        <>
          {noteOpen && (
            <input
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Add a note (optional)"
              style={{
                width: '100%', marginTop: 10, padding: '9px 11px', borderRadius: 10,
                background: 'var(--surface2)', border: '1px solid var(--border)',
                color: 'var(--text)', fontFamily: 'inherit', fontSize: 12, outline: 'none',
              }}
            />
          )}
          <div style={{ display: 'flex', gap: 8, marginTop: 11 }}>
            <button
              type="button"
              disabled={busy}
              onClick={(e) => { ripple(e); onApprove(note) }}
              style={{
                flex: 1, padding: '10px 12px', borderRadius: 11, border: 'none', cursor: busy ? 'default' : 'pointer',
                background: 'var(--green)', color: '#04240f', fontSize: 12.5, fontWeight: 900, opacity: busy ? 0.5 : 1,
              }}
            >
              Approve
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={(e) => { ripple(e); onReject(note) }}
              style={{
                flex: 1, padding: '10px 12px', borderRadius: 11, cursor: busy ? 'default' : 'pointer',
                background: 'transparent', border: '1px solid color-mix(in srgb, var(--red) 45%, transparent)',
                color: 'var(--red)', fontSize: 12.5, fontWeight: 900, opacity: busy ? 0.5 : 1,
              }}
            >
              Decline
            </button>
            <button
              type="button"
              onClick={(e) => { ripple(e); setNoteOpen(o => !o) }}
              aria-label="Add a note"
              style={{
                flexShrink: 0, width: 40, borderRadius: 11, background: 'var(--surface2)',
                border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: 'pointer', fontSize: 15,
              }}
            >
              …
            </button>
          </div>
        </>
      )}

      {pending && !isOwner && (
        <button
          type="button"
          disabled={busy}
          onClick={(e) => { ripple(e); onCancel() }}
          style={{
            marginTop: 11, padding: '9px 14px', borderRadius: 11, cursor: busy ? 'default' : 'pointer',
            background: 'transparent', border: '1px solid var(--border)',
            color: 'var(--text-dim)', fontSize: 12, fontWeight: 800, opacity: busy ? 0.5 : 1,
          }}
        >
          <X size={11} style={{ verticalAlign: -1, marginRight: 4 }} /> Cancel request
        </button>
      )}
    </div>
  )
}

export default function AdminApprovalsSection({ onReviewed }: { onReviewed?: () => void }) {
  const [tab, setTab] = useState<'pending' | 'reviewed'>('pending')
  const [rows, setRows] = useState<AdminRequest[]>([])
  const [isOwner, setIsOwner] = useState(false)
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [message, setMessage] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    const { rows, isOwner, error } = await fetchAdminRequests(tab)
    setRows(rows)
    setIsOwner(isOwner)
    if (error) setMessage(error)
    setLoading(false)
  }, [tab])

  useEffect(() => { load() }, [load])

  async function review(id: string, action: 'approve' | 'reject' | 'cancel', note: string) {
    setBusyId(id)
    setMessage('')
    const res: { error: string | null; failed?: string } =
      action === 'approve' ? await approveAdminRequest(id, note)
      : action === 'reject' ? await rejectAdminRequest(id, note)
      : await cancelAdminRequest(id)
    setBusyId(null)
    if (res.error) { setMessage(res.error); return }
    // Approved, but the action itself blew up while running — the row is
    // marked 'failed' server-side and the reason comes back here.
    if (res.failed) setMessage(res.failed)
    onReviewed?.()
    load()
  }

  return (
    <>
      <SectionTitle>
        <ShieldCheck size={12} style={{ verticalAlign: -1, marginRight: 5 }} />
        {isOwner ? 'Approval queue' : 'My requests'}
      </SectionTitle>

      <p style={{ fontSize: 11.5, color: 'var(--text-dim)', margin: '0 0 14px', lineHeight: 1.45 }}>
        {isOwner
          ? 'Diamond gifts, redeem codes, bounties, role changes, exports, site status, broadcasts and item pricing all wait here until you approve them. Requests expire after 7 days.'
          : 'These actions go live once the platform owner approves them. Requests expire after 7 days.'}
      </p>

      <SegmentedTabs
        options={[{ key: 'pending', label: 'Pending' }, { key: 'reviewed', label: 'Reviewed' }]}
        value={tab}
        onChange={setTab}
      />

      {message && (
        <p style={{ fontSize: 12, color: 'var(--red)', margin: '0 0 12px' }}>{message}</p>
      )}

      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading…</p>
      ) : rows.length === 0 ? (
        <div className="neu-card" style={{ padding: 22, textAlign: 'center' }}>
          {tab === 'pending' ? <Clock size={20} style={{ color: 'var(--text-muted)' }} /> : <CheckCircle2 size={20} style={{ color: 'var(--text-muted)' }} />}
          <p style={{ fontSize: 12.5, color: 'var(--text-dim)', margin: '8px 0 0' }}>
            {tab === 'pending' ? 'Nothing waiting.' : 'Nothing reviewed yet.'}
          </p>
        </div>
      ) : rows.map(req => (
        <RequestCard
          key={req.id}
          req={req}
          isOwner={isOwner}
          busy={busyId === req.id}
          onApprove={(note) => review(req.id, 'approve', note)}
          onReject={(note) => review(req.id, 'reject', note)}
          onCancel={() => review(req.id, 'cancel', '')}
        />
      ))}
    </>
  )
}
