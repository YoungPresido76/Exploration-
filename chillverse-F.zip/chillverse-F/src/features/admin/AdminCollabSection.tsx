// src/features/admin/AdminCollabSection.tsx
//
// The Collabs wing of the admin dashboard. Two jobs:
//
//  1. Publish collabs — artwork, name, active/ended status. A collab
//     starts as a draft (invisible to players) and only appears in
//     /lab/collab once published, which is also the point at which its
//     name becomes taggable.
//  2. Tag Mall items to a collab. The form takes the collab NAME as typed
//     (that's the requirement), and admin_set_item_collab resolves it
//     case-insensitively against *published* collabs and refuses anything
//     else — so a typo or a draft name fails loudly here instead of
//     quietly storing a tag no player would ever see.
//
// Same visual language as AdminStoreSection: SectionTitle + Row groups,
// forms in a popover Modal.
import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Flag, Plus, Search, Upload, ImagePlus, Trash2, Check, X, Package, Heart, Tag, RefreshCw,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { Row, SectionTitle } from '../settings/settingsShared'
import { Modal, fieldLabel, inputStyle } from './adminModal'
import {
  fetchAdminCollabs, saveCollab, deleteCollab, uploadCollabImage,
  setItemCollab, fetchTaggableItems, collabTitle,
  DEFAULT_COLLAB_TINT,
  type AdminCollab, type CollabStatus,
} from '../collab/collabApi'
import type { MallItem } from '../../shared/types'

const STATUS_OPTIONS: { key: CollabStatus; label: string; hint: string }[] = [
  { key: 'active', label: 'Active', hint: 'Running now — shown first in the list' },
  { key: 'ended',  label: 'Ended',  hint: 'Archived — still browsable, marked as over' },
]

// A handful of quick picks so the common case is one tap, plus a native
// colour input underneath for anything else. Not tied to any particular
// franchise — just a spread that reads well against the dark surface.
const TINT_PRESETS = [
  '#9b6dff', '#4f8ef7', '#3ecf8e', '#f5c542', '#ff4d8b', '#ff7a45', '#42d0e0',
]

// ── Create / edit ───────────────────────────────────────────────────────
function CollabForm({ existing, onClose, onSaved }: {
  existing: AdminCollab | null
  onClose: () => void
  onSaved: () => void
}) {
  const [name, setName] = useState(existing?.name ?? '')
  const [imageUrl, setImageUrl] = useState(existing?.image_url ?? '')
  const [status, setStatus] = useState<CollabStatus>(existing?.status ?? 'active')
  // Defaults to TRUE for a new collab. The old default was false, which
  // meant filling the whole form and hitting "Create collab" produced
  // something no player could see and no item could be tagged to — the
  // button says create, so it should create something real. Editing an
  // existing one keeps whatever it already was.
  const [isPublished, setIsPublished] = useState(existing?.is_published ?? true)
  const [tintColor, setTintColor] = useState(existing?.tint_color ?? DEFAULT_COLLAB_TINT)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function handleFile(file: File | undefined) {
    if (!file) return
    setError('')
    setUploading(true)
    const { url, error: err } = await uploadCollabImage(file)
    setUploading(false)
    if (err || !url) { setError(err ?? 'Upload failed.'); return }
    setImageUrl(url)
  }

  async function handleSave() {
    setError('')
    setSaving(true)
    const { error: err } = await saveCollab({
      id: existing?.id ?? null,
      name,
      imageUrl: imageUrl || null,
      status,
      isPublished,
      tintColor,
    })
    setSaving(false)
    if (err) { setError(err); return }
    onSaved()
    onClose()
  }

  return (
    <Modal title={existing ? 'Edit collab' : 'New collab'} onClose={onClose} width={420}>
      <p style={fieldLabel}>Collab artwork</p>
      <div style={{
        position: 'relative', borderRadius: 14, overflow: 'hidden', marginBottom: 12,
        border: '1px solid var(--border)', background: 'var(--surface2)', aspectRatio: '16 / 10',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {imageUrl ? (
          <img src={imageUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 11.5 }}>
            <ImagePlus size={20} style={{ marginBottom: 6 }} />
            <div>No artwork yet</div>
          </div>
        )}
      </div>

      <label style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
        padding: '10px 12px', borderRadius: 10, marginBottom: 14, cursor: uploading ? 'default' : 'pointer',
        background: 'var(--surface2)', border: '1px solid var(--border)',
        color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700,
      }}>
        <Upload size={13} />
        {uploading ? 'Uploading…' : imageUrl ? 'Replace image' : 'Upload image'}
        <input
          type="file"
          accept="image/*"
          disabled={uploading}
          onChange={e => handleFile(e.target.files?.[0])}
          style={{ display: 'none' }}
        />
      </label>

      <p style={fieldLabel}>Collab name</p>
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="e.g. Fable 5"
        maxLength={60}
        style={{ ...inputStyle, marginBottom: 6 }}
      />
      {/* Shows exactly what players will read, since the "Chillverse × "
          half is generated rather than typed. */}
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 14px' }}>
        Players will see: <span style={{ color: 'var(--text-dim)', fontWeight: 700 }}>{collabTitle(name.trim() || '…')}</span>
      </p>

      <p style={fieldLabel}>Status</p>
      <div style={{ display: 'grid', gap: 7, marginBottom: 14 }}>
        {STATUS_OPTIONS.map(opt => {
          const on = status === opt.key
          return (
            <button
              key={opt.key}
              type="button"
              onClick={(e) => { ripple(e); setStatus(opt.key) }}
              style={{
                display: 'flex', alignItems: 'center', gap: 9, padding: '10px 12px',
                borderRadius: 11, cursor: 'pointer', textAlign: 'left',
                background: on ? 'color-mix(in srgb, var(--accent) 10%, transparent)' : 'var(--surface2)',
                border: `1px solid ${on ? 'color-mix(in srgb, var(--accent) 35%, transparent)' : 'var(--border)'}`,
                color: 'var(--text)',
              }}
            >
              <span style={{
                width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: on ? 'var(--accent)' : 'transparent',
                border: on ? 'none' : '1px solid var(--border-strong)',
                color: '#fff',
              }}>
                {on && <Check size={11} />}
              </span>
              <span style={{ minWidth: 0 }}>
                <span style={{ display: 'block', fontSize: 12.5, fontWeight: 700 }}>{opt.label}</span>
                <span style={{ display: 'block', fontSize: 10.5, color: 'var(--text-muted)' }}>{opt.hint}</span>
              </span>
            </button>
          )
        })}
      </div>

      <p style={fieldLabel}>Particle colour</p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 9px', lineHeight: 1.5 }}>
        Tints the sparks on the collab's card and list row, plus its accent border and glow.
      </p>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
        {TINT_PRESETS.map(hex => {
          const on = hex.toLowerCase() === tintColor.toLowerCase()
          return (
            <button
              key={hex}
              type="button"
              onClick={(e) => { ripple(e); setTintColor(hex) }}
              aria-label={`Use ${hex}`}
              aria-pressed={on}
              style={{
                width: 30, height: 30, borderRadius: '50%', cursor: 'pointer',
                background: hex, flexShrink: 0,
                border: on ? '2px solid var(--text)' : '2px solid transparent',
                boxShadow: on
                  ? `0 0 0 2px var(--surface), 0 0 10px ${hex}`
                  : '0 0 0 1px rgba(255,255,255,0.08)',
              }}
            />
          )
        })}
        {/* Native colour input doubles as "anything else" — its swatch
            face IS the current value, and tapping it opens the OS picker. */}
        <label
          style={{
            width: 30, height: 30, borderRadius: '50%', flexShrink: 0, cursor: 'pointer',
            position: 'relative', overflow: 'hidden',
            border: '2px solid var(--border-strong)',
          }}
          title="Custom colour"
        >
          <input
            type="color"
            value={tintColor}
            onChange={e => setTintColor(e.target.value)}
            style={{
              position: 'absolute', inset: -4, width: 'calc(100% + 8px)', height: 'calc(100% + 8px)',
              border: 'none', padding: 0, cursor: 'pointer',
            }}
          />
        </label>
        <span style={{ fontSize: 11.5, color: 'var(--text-dim)', fontWeight: 700, fontFamily: 'monospace' }}>
          {tintColor}
        </span>
      </div>

      <button
        type="button"
        onClick={(e) => { ripple(e); setIsPublished(p => !p) }}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 9, padding: '11px 12px',
          borderRadius: 11, marginBottom: 6, cursor: 'pointer', textAlign: 'left',
          background: isPublished ? 'rgba(62,207,142,0.08)' : 'var(--surface2)',
          border: `1px solid ${isPublished ? 'rgba(62,207,142,0.28)' : 'var(--border)'}`,
        }}
      >
        <span style={{
          width: 18, height: 18, borderRadius: 5, flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: isPublished ? '#3ecf8e' : 'transparent',
          border: isPublished ? 'none' : '1px solid var(--border-strong)',
          color: '#08120d',
        }}>
          {isPublished && <Check size={12} />}
        </span>
        <span style={{ fontSize: 12.5, fontWeight: 700, color: isPublished ? 'var(--text)' : 'var(--gold)' }}>
          {isPublished ? 'Published — visible to players' : 'Draft — nobody can see this'}
        </span>
      </button>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        A collab has to be published before its name can be used to tag Mall items.
        Unpublishing clears the tag from any item currently under it.
      </p>

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}

      <button
        type="button"
        onClick={(e) => { ripple(e); handleSave() }}
        disabled={saving || uploading}
        style={{
          width: '100%', padding: '12px', borderRadius: 12, border: 'none',
          background: 'var(--accent)', color: '#fff', fontSize: 13.5, fontWeight: 800,
          cursor: saving || uploading ? 'default' : 'pointer', opacity: saving || uploading ? 0.6 : 1,
        }}
      >
        {saving
          ? 'Saving…'
          : isPublished
            ? (existing ? 'Save changes' : 'Create & publish')
            : (existing ? 'Save as draft' : 'Create as draft')}
      </button>
      {!isPublished && (
        <p style={{ fontSize: 11, color: 'var(--gold)', margin: '10px 0 0', lineHeight: 1.5, textAlign: 'center' }}>
          Heads up: as a draft this won't show in the Collab wing and you won't be
          able to tag any Mall items to it.
        </p>
      )}
    </Modal>
  )
}

// ── Tag an item ─────────────────────────────────────────────────────────
function ItemTagForm({ collabs, onClose, onSaved }: {
  collabs: AdminCollab[]
  onClose: () => void
  onSaved: () => void
}) {
  const [items, setItems] = useState<MallItem[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState('')
  const [picked, setPicked] = useState<MallItem | null>(null)
  const [collabName, setCollabName] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [done, setDone] = useState('')

  // 100-odd items: one fetch and filter in memory beats a debounced RPC
  // per keystroke, and it means the current tag is already known for
  // every row without a second lookup.
  useEffect(() => {
    fetchTaggableItems().then(({ data, error: err }) => {
      setItems(data)
      if (err) setError(err)
      setLoading(false)
    })
  }, [])

  const published = useMemo(() => collabs.filter(c => c.is_published), [collabs])
  const collabById = useMemo(
    () => new Map(collabs.map(c => [c.id, c])),
    [collabs],
  )

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    const base = q
      ? items.filter(i => i.name.toLowerCase().includes(q) || (i.sub_category ?? '').toLowerCase().includes(q))
      : items
    return base.slice(0, 40)
  }, [items, query])

  async function handleSave(clear = false) {
    if (!picked) return
    setError('')
    setDone('')
    setSaving(true)
    const { collabName: saved, error: err } = await setItemCollab(picked.id, clear ? null : collabName)
    setSaving(false)
    if (err) { setError(err); return }

    // Reflect the new tag locally so the list under the search box updates
    // without a full refetch.
    const target = published.find(c => c.name.toLowerCase() === (saved ?? '').toLowerCase())
    setItems(prev => prev.map(i => (
      i.id === picked.id ? { ...i, collab_id: clear ? null : (target?.id ?? null) } : i
    )))
    setDone(clear ? `Cleared the collab on ${picked.name}.` : `${picked.name} is now under ${collabTitle(saved ?? collabName)}.`)
    setPicked(null)
    setCollabName('')
    onSaved()
  }

  return (
    <Modal title="Set an item's collab" onClose={onClose} width={420}>
      {published.length === 0 ? (
        <p style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.6 }}>
          No published collabs yet. Create one and publish it first — an item can only be
          tagged to a collab players can actually see.
        </p>
      ) : (
        <>
          <p style={fieldLabel}>Pick a Mall item</p>
          <div style={{ position: 'relative', marginBottom: 10 }}>
            <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search items by name…"
              style={{ ...inputStyle, paddingLeft: 30 }}
            />
          </div>

          <div style={{
            maxHeight: 200, overflowY: 'auto', marginBottom: 14,
            border: '1px solid var(--border)', borderRadius: 12, background: 'var(--surface2)',
          }}>
            {loading ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>Loading catalog…</p>
            ) : results.length === 0 ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>No matching items.</p>
            ) : results.map(item => {
              const on = picked?.id === item.id
              const currentCollab = item.collab_id ? collabById.get(item.collab_id) : null
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={(e) => {
                    ripple(e)
                    setPicked(item)
                    setCollabName(currentCollab?.name ?? '')
                    setDone('')
                    setError('')
                  }}
                  style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: 9,
                    padding: '9px 11px', background: on ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'none',
                    border: 'none', borderBottom: '1px solid var(--border)', cursor: 'pointer', textAlign: 'left',
                  }}
                >
                  <span style={{
                    width: 28, height: 28, borderRadius: 8, flexShrink: 0, overflow: 'hidden',
                    background: 'var(--surface3)', display: 'block',
                  }}>
                    {item.image_url && <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                  </span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {item.name}
                    </span>
                    <span style={{ display: 'block', fontSize: 10.5, color: 'var(--text-muted)' }}>
                      {item.category}{currentCollab ? ` · under ${currentCollab.name}` : ''}
                    </span>
                  </span>
                  {on && <Check size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />}
                </button>
              )
            })}
          </div>

          {picked && (
            <>
              <p style={fieldLabel}>Which collab is “{picked.name}” under?</p>
              <input
                value={collabName}
                onChange={e => { setCollabName(e.target.value); setError('') }}
                placeholder="Type the collab name exactly"
                list="cv-published-collabs"
                style={{ ...inputStyle, marginBottom: 8 }}
              />
              {/* Native datalist: typing is still the input (the name is
                  what gets validated server-side), but the published names
                  are one tap away so nobody has to remember spelling. */}
              <datalist id="cv-published-collabs">
                {published.map(c => <option key={c.id} value={c.name} />)}
              </datalist>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.5 }}>
                Published collabs: {published.map(c => c.name).join(', ')}
              </p>

              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  onClick={(e) => { ripple(e); handleSave(false) }}
                  disabled={saving || !collabName.trim()}
                  style={{
                    flex: 1, padding: '11px', borderRadius: 12, border: 'none',
                    background: 'var(--accent)', color: '#fff', fontSize: 13, fontWeight: 800,
                    cursor: saving || !collabName.trim() ? 'default' : 'pointer',
                    opacity: saving || !collabName.trim() ? 0.6 : 1,
                  }}
                >
                  {saving ? 'Saving…' : 'Set collab'}
                </button>
                {picked.collab_id && (
                  <button
                    type="button"
                    onClick={(e) => { ripple(e); handleSave(true) }}
                    disabled={saving}
                    aria-label="Clear collab"
                    style={{
                      width: 44, borderRadius: 12, background: 'var(--surface2)',
                      border: '1px solid var(--border)', color: 'var(--red)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                    }}
                  >
                    <X size={15} />
                  </button>
                )}
              </div>
            </>
          )}

          {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 12 }}>{error}</p>}
          {done && <p style={{ fontSize: 11.5, color: '#3ecf8e', marginTop: 12, fontWeight: 700 }}>{done}</p>}
        </>
      )}
    </Modal>
  )
}

// ── Section ─────────────────────────────────────────────────────────────
export default function AdminCollabSection() {
  const [collabs, setCollabs] = useState<AdminCollab[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [formFor, setFormFor] = useState<AdminCollab | null | 'new'>(null)
  const [tagOpen, setTagOpen] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState<AdminCollab | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    const { data, error: err } = await fetchAdminCollabs()
    setCollabs(data)
    setError(err ?? '')
    setLoading(false)
  }, [])

  useEffect(() => { load() }, [load])

  async function handleDelete(collab: AdminCollab) {
    const { error: err } = await deleteCollab(collab.id)
    setConfirmDelete(null)
    if (err) { setError(err); return }
    load()
  }

  return (
    <div>
      <SectionTitle>Collabs</SectionTitle>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <button
          type="button"
          onClick={(e) => { ripple(e); setFormFor('new') }}
          style={{
            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            padding: '11px 12px', borderRadius: 12, cursor: 'pointer',
            background: 'var(--accent)', border: 'none', color: '#fff', fontSize: 12.5, fontWeight: 800,
          }}
        >
          <Plus size={14} /> New collab
        </button>
        <button
          type="button"
          onClick={(e) => { ripple(e); setTagOpen(true) }}
          style={{
            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            padding: '11px 12px', borderRadius: 12, cursor: 'pointer',
            background: 'var(--surface)', border: '1px solid var(--border)',
            color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 800,
          }}
        >
          <Tag size={14} /> Tag an item
        </button>
        <button
          type="button"
          onClick={(e) => { ripple(e); load() }}
          disabled={loading}
          aria-label="Refresh collabs"
          style={{
            width: 42, borderRadius: 12, background: 'var(--surface)',
            border: '1px solid var(--border)', color: 'var(--text-dim)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.5 : 1,
          }}
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 10 }}>{error}</p>}

      {loading && collabs.length === 0 ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading collabs…</p>
      ) : collabs.length === 0 ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.6 }}>
          No collabs yet. Create one, upload its artwork, publish it, then tag Mall items to it.
        </p>
      ) : collabs.map(collab => (
        <Row
          key={collab.id}
          icon={<Flag size={14} />}
          iconBg={`color-mix(in srgb, ${collab.tint_color} 14%, transparent)`}
          iconColor={collab.tint_color}
          label={collab.name}
          sub={[
            collab.is_published ? 'Published' : '⚠ Draft — hidden from players',
            collab.status === 'active' ? 'Active' : 'Ended',
          ].join(' · ')}
          onClick={(e) => { ripple(e); setFormFor(collab) }}
          rightEl={
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 11, color: 'var(--text-muted)', fontWeight: 700 }}>
                <Heart size={11} /> {collab.likes_count}
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 11, color: 'var(--text-muted)', fontWeight: 700 }}>
                <Package size={11} /> {collab.item_count}
              </span>
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); ripple(e); setConfirmDelete(collab) }}
                aria-label={`Delete ${collab.name}`}
                style={{
                  width: 28, height: 28, borderRadius: 8, background: 'var(--surface2)',
                  border: '1px solid var(--border)', color: 'var(--red)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                }}
              >
                <Trash2 size={12} />
              </button>
            </div>
          }
        />
      ))}

      {formFor !== null && (
        <CollabForm
          existing={formFor === 'new' ? null : formFor}
          onClose={() => setFormFor(null)}
          onSaved={load}
        />
      )}

      {tagOpen && (
        <ItemTagForm
          collabs={collabs}
          onClose={() => setTagOpen(false)}
          onSaved={load}
        />
      )}

      {confirmDelete && (
        <Modal title="Delete collab" onClose={() => setConfirmDelete(null)} width={360}>
          <p style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.6, marginBottom: 16 }}>
            Delete <strong style={{ color: 'var(--text)' }}>{confirmDelete.name}</strong>? Its likes go with it and
            any item tagged to it goes back to having no collab. The items themselves are untouched, and
            nobody loses anything they bought.
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={(e) => { ripple(e); setConfirmDelete(null) }}
              style={{
                flex: 1, padding: '11px', borderRadius: 12, background: 'var(--surface2)',
                border: '1px solid var(--border)', color: 'var(--text-dim)', fontSize: 13, fontWeight: 700, cursor: 'pointer',
              }}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={(e) => { ripple(e); handleDelete(confirmDelete) }}
              style={{
                flex: 1, padding: '11px', borderRadius: 12, background: 'var(--red)',
                border: 'none', color: '#fff', fontSize: 13, fontWeight: 800, cursor: 'pointer',
              }}
            >
              Delete
            </button>
          </div>
        </Modal>
      )}
    </div>
  )
}
