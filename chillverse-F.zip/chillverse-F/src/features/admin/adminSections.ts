// src/features/admin/adminSections.ts
//
// The 9 admin "wings" — shared between AdminDashboard.tsx (which renders
// the selected wing's content) and AdminConcourse.tsx (which renders the
// wing directory grid on the Concourse home screen). Pulled out of
// AdminDashboard.tsx so neither file has to import the other just to get
// at this list.
import {
  Users, ShoppingBag, Gamepad2, Swords, Sparkles, LifeBuoy, Settings2, Megaphone, Flag, ShieldCheck,
} from 'lucide-react'

export type AdminSection =
  | 'overview' | 'economy' | 'collabs' | 'games' | 'multiplayer' | 'halo' | 'operations' | 'ops' | 'broadcasts'
  | 'approvals'

export interface AdminSectionMeta {
  key: AdminSection
  label: string
  description: string
  icon: typeof Users
  /** Tailwind/CSS-var color token used for the wing's icon chip on the Concourse grid. */
  tint: string
  /** Only the platform owner (is_owner()) sees this wing. Filtered out of
   *  the Concourse grid for everyone else — the RPCs behind it refuse
   *  non-owners regardless, so this is presentation, not the control. */
  ownerOnly?: boolean
}

export const ADMIN_SECTIONS: AdminSectionMeta[] = [
  { key: 'overview', label: 'Atrium', description: 'Platform pulse and account growth', icon: Users, tint: 'var(--blue)' },
  { key: 'economy', label: 'Mall economy', description: 'Stats, bundles, item pricing/locking, sales, and gifting', icon: ShoppingBag, tint: 'var(--gold)' },
  { key: 'collabs', label: 'Collabs', description: 'Publish collabs and tag Mall items to them', icon: Flag, tint: 'var(--brand-violet-soft)' },
  { key: 'games', label: 'Arcade', description: 'Sessions and most-played games', icon: Gamepad2, tint: 'var(--purple)' },
  { key: 'multiplayer', label: 'Arena', description: 'Rooms and multiplayer traffic', icon: Swords, tint: 'var(--blue)' },
  { key: 'halo', label: 'Halo AI', description: 'Assistant usage and providers', icon: Sparkles, tint: 'var(--purple)' },
  { key: 'operations', label: 'Support desk', description: 'Reports, bans, tickets, actions', icon: LifeBuoy, tint: 'var(--red)' },
  { key: 'ops', label: 'Ops console', description: 'Flags, maintenance mode, broadcasts, exports, health', icon: Settings2, tint: 'var(--accent)' },
  { key: 'broadcasts', label: 'Broadcasts', description: 'Message every player or a chosen few, straight to their DMs', icon: Megaphone, tint: 'var(--green)' },
  { key: 'approvals', label: 'Approvals', description: 'Sensitive admin actions waiting on your sign-off', icon: ShieldCheck, tint: 'var(--green)', ownerOnly: true },
]

export const ADMIN_WING_STORAGE_KEY = 'cv_admin_active_wing'
