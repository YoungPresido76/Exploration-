// src/features/admin/AdminWingScreen.tsx
//
// The full-screen wing detail — what the Concourse slides into when you
// tap a wing tile. Header (back/eyebrow/title/search) + a KPI grid built
// from real AdminDashboardStats + the wing's actual content underneath.
// Every number here is either straight off AdminDashboardStats or a
// value honestly computed from it (e.g. "% of base") — nothing is
// fabricated to match the standalone prototype's placeholder figures.
import { useEffect, useState } from 'react'
import {
  Users, UserPlus, Crown, ShieldAlert, ShieldBan, Gem, ShoppingBag, AlertTriangle,
  Gamepad2, Swords, Sparkles, Flag, LifeBuoy, List, Search as SearchIcon, Clock, CheckCircle2, Radio,
} from 'lucide-react'
import { Row, SectionTitle } from '../settings/settingsShared'
import { ripple } from '../../shared/lib/ripple'
import { KpiCard, WingHeader, SegmentedTabs, WingSlideIn, SparkBarCard } from './AdminKit'
import type { AdminSectionMeta } from './adminSections'
import type { AdminDashboardStats, AdminUserFilter } from './adminStats'
import AdminStoreSection, { type AdminStoreGroup } from './AdminStoreSection'
import AdminCollabSection from './AdminCollabSection'
import AdminOpsPanel from './AdminOpsPanel'
import AdminBroadcastSection from './AdminBroadcastSection'
import AdminBountySection from './AdminBountySection'
import AdminEliminationSection from './AdminEliminationSection'
import AdminChampionshipSection from './AdminChampionshipSection'
import AdminFortuneVaultSection from './AdminFortuneVaultSection'
import AdminApprovalsSection from './AdminApprovalsSection'
import AdminVerificationSection from './AdminVerificationSection'
import AdminStorageCleanupSection from './AdminStorageCleanupSection'
import { fetchAdminCollabs, type AdminCollab } from '../collab/collabApi'
import { fetchModerationLog, type ModerationLogEntry } from '../moderation/moderation'
import { fetchFeatureFlags } from './adminOps'

function RankedList({ rows, primaryKey, countKey, secondaryKey }: {
  rows: Record<string, string | number>[]
  primaryKey: string
  countKey: string
  secondaryKey?: string
}) {
  if (rows.length === 0) return <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>No data yet.</p>
  const max = Math.max(...rows.map(r => Number(r[countKey]) || 0), 1)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {rows.map((row, i) => {
        const count = Number(row[countKey]) || 0
        return (
          <div key={i}>
            <div className="flex items-center justify-between" style={{ marginBottom: 3 }}>
              <span style={{ fontSize: 12, color: 'var(--text)', fontWeight: 600 }}>
                {String(row[primaryKey])}
                {secondaryKey && row[secondaryKey] ? <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}> · {String(row[secondaryKey])}</span> : null}
              </span>
              <span style={{ fontSize: 11.5, color: 'var(--text-dim)', fontWeight: 700 }}>{count}</span>
            </div>
            <div style={{ height: 5, borderRadius: 3, background: 'var(--surface2)', overflow: 'hidden' }}>
              <div style={{ width: `${(count / max) * 100}%`, height: '100%', background: 'var(--accent)', borderRadius: 3 }} />
            </div>
          </div>
        )
      })}
    </div>
  )
}

function pctOfBase(part: number, base: number): string {
  if (base <= 0) return '0% of base'
  return `${Math.round((part / base) * 100)}% of base`
}

export default function AdminWingScreen({
  section, stats, myId, onBack, onOpenSearch, onDrillDown,
}: {
  section: AdminSectionMeta
  stats: AdminDashboardStats
  myId: string | null
  onBack: () => void
  onOpenSearch: () => void
  onDrillDown: (args: { filter?: AdminUserFilter; title: string }) => void
}) {
  return (
    <WingSlideIn>
      <div style={{ maxWidth: 960, margin: '0 auto', padding: '16px 20px 56px' }}>
        <WingHeader eyebrow={section.description} title={section.label} onBack={onBack} onSearch={onOpenSearch} />

        {section.key === 'overview' && <OverviewWing stats={stats} onDrillDown={onDrillDown} onOpenSearch={onOpenSearch} />}
        {section.key === 'economy' && <EconomyWing stats={stats} onOpenSearch={onOpenSearch} />}
        {section.key === 'collabs' && <CollabsWing />}
        {section.key === 'games' && <GamesWing stats={stats} />}
        {section.key === 'multiplayer' && <MultiplayerWing stats={stats} />}
        {section.key === 'halo' && <HaloWing stats={stats} />}
        {section.key === 'operations' && <OperationsWing stats={stats} onDrillDown={onDrillDown} />}
        {/* Cleanup sits ABOVE the ops panel on purpose: AdminOpsPanel is a
            long screen (flags, maintenance, broadcasts, exports, health),
            so anything after it is several thumb-scrolls down and never
            gets found. */}
        {section.key === 'ops' && <><AdminStorageCleanupSection /><AdminOpsPanel /></>}
        {section.key === 'broadcasts' && <AdminBroadcastSection myId={myId} />}
        {section.key === 'approvals' && <AdminApprovalsSection />}
      </div>
    </WingSlideIn>
  )
}

// ── Atrium ───────────────────────────────────────────────────────────────
function OverviewWing({
  stats, onDrillDown, onOpenSearch,
}: { stats: AdminDashboardStats; onDrillDown: (a: { filter?: AdminUserFilter; title: string }) => void; onOpenSearch: () => void }) {
  const o = stats.overview
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Users} label="Total users" value={o.total_users.toLocaleString()} trend={`+${o.new_users_7d} this wk`} tint="var(--blue)" />
        <KpiCard icon={UserPlus} label="New · 30d" value={o.new_users_30d} tint="var(--gold)" onClick={(e) => { ripple(e); onDrillDown({ filter: 'new_30d', title: 'New users (30d)' }) }} />
        <KpiCard icon={Users} label="Active · 7d" value={o.active_7d} trend={pctOfBase(o.active_7d, o.total_users)} trendTone="flat" tint="var(--green)" onClick={(e) => { ripple(e); onDrillDown({ filter: 'active_7d', title: 'Active users (7d)' }) }} />
        <KpiCard icon={Crown} label="Pro subscribers" value={o.pro_subscribers} trend={pctOfBase(o.pro_subscribers, o.total_users)} trendTone="flat" tint="var(--purple)" onClick={(e) => { ripple(e); onDrillDown({ filter: 'pro', title: 'Pro subscribers' }) }} />
      </div>

      <SectionTitle>Directory</SectionTitle>
      <Row icon={<List size={15} />} iconBg="rgba(79,142,247,0.12)" iconColor="var(--blue)" label="All users" sub="Browse, filter, and search the full roster" onClick={(e) => { ripple(e); onDrillDown({ title: 'All users' }) }} />
      <Row icon={<SearchIcon size={15} />} iconBg="rgba(79,142,247,0.12)" iconColor="var(--blue)" label="Find a user" sub="Look up by name, handle, or ID" onClick={(e) => { ripple(e); onOpenSearch() }} />
      <Row icon={<Crown size={15} />} iconBg="rgba(155,109,255,0.12)" iconColor="var(--purple)" label="Pro subscribers" sub="Everyone on a paid tier" value={String(o.pro_subscribers)} onClick={(e) => { ripple(e); onDrillDown({ filter: 'pro', title: 'Pro subscribers' }) }} />
      <Row icon={<ShieldAlert size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)" label="Staff members" sub="Admins and moderators" value={String(o.staff_count)} onClick={(e) => { ripple(e); onDrillDown({ filter: 'staff', title: 'Staff members' }) }} />
      <Row icon={<ShieldBan size={15} />} iconBg="rgba(255,79,79,0.12)" iconColor="var(--red)" label="Banned users" sub="Suspended and banned accounts" value={String(o.banned_users)} onClick={(e) => { ripple(e); onDrillDown({ filter: 'banned', title: 'Banned users' }) }} />
    </>
  )
}

// ── Mall economy ─────────────────────────────────────────────────────────
function EconomyWing({ stats, onOpenSearch }: { stats: AdminDashboardStats; onOpenSearch: () => void }) {
  const [group, setGroup] = useState<AdminStoreGroup>('store')
  const e = stats.economy
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Gem} label="Diamonds in circulation" value={e.diamonds_in_circulation.toLocaleString()} tint="var(--blue)" />
        <KpiCard icon={Gem} label="Diamonds credited · 30d" value={e.diamonds_credited_30d.toLocaleString()} tint="var(--gold)" />
        <KpiCard icon={ShoppingBag} label="Purchases · 30d" value={e.purchase_tx_30d} />
        <KpiCard icon={AlertTriangle} label="Flagged balances (>3,000)" value={e.flagged_balance_count} tint="var(--red)" onClick={(e2) => { ripple(e2); onOpenSearch() }} />
      </div>

      <SectionTitle>Top Mall items (by owners)</SectionTitle>
      <div className="neu-card" style={{ padding: 16, marginBottom: 8 }}>
        <RankedList rows={e.top_mall_items} primaryKey="name" countKey="owners" secondaryKey="category" />
      </div>

      <SegmentedTabs
        value={group}
        onChange={setGroup}
        options={[{ key: 'store', label: 'Store' }, { key: 'sales', label: 'Sales' }, { key: 'diamonds', label: 'Diamonds' }]}
      />
      <AdminStoreSection group={group} />
    </>
  )
}

// ── Collabs ──────────────────────────────────────────────────────────────
function CollabsWing() {
  const [collabs, setCollabs] = useState<AdminCollab[] | null>(null)
  useEffect(() => { fetchAdminCollabs().then(({ data }) => setCollabs(data)) }, [])
  const active = collabs?.filter(c => c.status === 'active').length ?? null
  const ended = collabs?.filter(c => c.status === 'ended').length ?? null
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Flag} label="Active collabs" value={active ?? '—'} tint="var(--pink)" />
        <KpiCard icon={Clock} label="Ended collabs" value={ended ?? '—'} tint="var(--text-muted)" />
      </div>
      <AdminCollabSection />
    </>
  )
}

// ── Arcade ───────────────────────────────────────────────────────────────
function GamesWing({ stats }: { stats: AdminDashboardStats }) {
  const g = stats.games
  // "Top game" and "Games live" both come from data already fetched
  // elsewhere in the admin surface (top_games and the 'game' feature-flag
  // category) — real numbers, not the mockup's placeholder figures.
  const [gameFlagsOn, setGameFlagsOn] = useState<number | null>(null)
  const [gameFlagsTotal, setGameFlagsTotal] = useState<number | null>(null)
  useEffect(() => {
    fetchFeatureFlags().then(({ data }) => {
      const gameFlags = data.filter(f => f.category === 'game')
      setGameFlagsTotal(gameFlags.length)
      setGameFlagsOn(gameFlags.filter(f => f.enabled).length)
    })
  }, [])
  const topGame = g.top_games[0]?.game ?? null
  const sessionsToday = g.sessions_daily_7d[g.sessions_daily_7d.length - 1]?.sessions ?? null
  const avgSessionLabel = g.avg_session_sec === null
    ? '—'
    : g.avg_session_sec >= 60
      ? `${Math.floor(g.avg_session_sec / 60)}m ${g.avg_session_sec % 60}s`
      : `${g.avg_session_sec}s`
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Gamepad2} label="Sessions today" value={sessionsToday ?? '—'} tint="var(--purple)" />
        <KpiCard icon={Clock} label="Avg. session" value={avgSessionLabel} />
        <KpiCard icon={Crown} label="Top game" value={topGame ?? '—'} tint="var(--gold)" />
        <KpiCard
          icon={Gamepad2}
          label="Games live"
          value={gameFlagsTotal === null ? '—' : `${gameFlagsOn}/${gameFlagsTotal}`}
          tint="var(--green)"
        />
      </div>
      <SparkBarCard
        title="Sessions"
        data={g.sessions_daily_7d.map(d => ({ day: d.day, value: d.sessions }))}
      />
      <SectionTitle>Most played (30d)</SectionTitle>
      <div className="neu-card" style={{ padding: 16, marginBottom: 18 }}>
        <RankedList rows={g.top_games} primaryKey="game" countKey="sessions" />
      </div>

      {/* Fortune Vault — builds itself out for non-admins. */}
      <AdminFortuneVaultSection />
    </>
  )
}

// ── Arena ────────────────────────────────────────────────────────────────
function MultiplayerWing({ stats }: { stats: AdminDashboardStats }) {
  const m = stats.multiplayer
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Swords} label="Active rooms" value={m.active_rooms} tint="var(--blue)" />
        <KpiCard icon={Swords} label="Rooms created · 7d" value={m.rooms_7d} />
      </div>
      <SectionTitle>Rooms by game (30d)</SectionTitle>
      <div className="neu-card" style={{ padding: 16, marginBottom: 18 }}>
        <RankedList rows={m.top_multiplayer_games} primaryKey="game_id" countKey="rooms" />
      </div>

      {/* Championship leads Arena's admin controls — it's the headline PvP
          event now, same ordering rationale as the Dashboard tile. */}
      <AdminChampionshipSection />

      {/* Bounties live in Arena rather than Broadcasts: placing one is a
          PvP action with an economy cost, not a message. */}
      <AdminBountySection />

      {/* Renders for the platform owner and nobody else — the component
          returns null for everyone, and the RPC behind it refuses them. */}
      <AdminEliminationSection />
    </>
  )
}

// ── Halo AI ──────────────────────────────────────────────────────────────
function HaloWing({ stats }: { stats: AdminDashboardStats }) {
  const h = stats.halo_ai
  const providerRows = Object.entries(h.provider_split_30d).map(([provider, uses]) => ({ provider, uses }))
  const messagesToday = h.messages_daily_7d[h.messages_daily_7d.length - 1]?.messages ?? null
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Sparkles} label="Messages today" value={messagesToday ?? '—'} tint="var(--purple)" />
        <KpiCard icon={Clock} label="Avg. response" value={h.avg_response_ms === null ? '—' : `${(h.avg_response_ms / 1000).toFixed(1)}s`} />
        <KpiCard icon={Users} label="Active users · 7d" value={h.active_users_7d} />
        <KpiCard
          icon={Radio}
          label="Uptime · 7d"
          value={h.uptime_pct_7d === null ? '—' : `${h.uptime_pct_7d}%`}
          tint={h.uptime_pct_7d === null || h.uptime_pct_7d >= 99 ? 'var(--green)' : h.uptime_pct_7d >= 95 ? 'var(--gold)' : 'var(--red)'}
        />
      </div>
      <SparkBarCard
        title="Messages"
        data={h.messages_daily_7d.map(d => ({ day: d.day, value: d.messages }))}
      />
      <SectionTitle>Provider split (30d)</SectionTitle>
      <div className="neu-card" style={{ padding: 16 }}>
        <RankedList rows={providerRows} primaryKey="provider" countKey="uses" />
      </div>
      {/* No Primary/Fallback provider rows here — Groq was deliberately
          removed (see halo-ai-chat/index.ts) and OpenRouter is the only
          provider today. "Uptime · 7d" above is OpenRouter's own uptime,
          computed from response_ms/success now logged on every exchange —
          not a placeholder for a second provider that doesn't exist. */}
    </>
  )
}

// ── Support desk ─────────────────────────────────────────────────────────
function OperationsWing({ stats, onDrillDown }: { stats: AdminDashboardStats; onDrillDown: (a: { filter?: AdminUserFilter; title: string }) => void }) {
  const mod = stats.moderation
  const sup = stats.support
  // Real recent-moderation entries — same fetchModerationLog the Concourse's
  // own "Recent activity" feed uses. There's no dedicated ticket/report
  // queue page yet, so "Open tickets" and "Flagged reports" below are
  // counts only (matching what AdminDashboardStats actually tracks) rather
  // than links into a list that doesn't exist — a "Ban appeals" count isn't
  // tracked anywhere in the backend today, so it's left out rather than
  // shown as 0 and implying it is.
  const [activity, setActivity] = useState<ModerationLogEntry[]>([])
  useEffect(() => { fetchModerationLog().then(({ data }) => setActivity(data.slice(0, 8))) }, [])
  return (
    <>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Flag} label="Open reports" value={mod.open_reports} tint="var(--red)" />
        <KpiCard icon={ShieldAlert} label="Mod actions · 7d" value={mod.actions_7d} />
        <KpiCard icon={ShieldBan} label="Currently banned" value={mod.currently_banned} tint="var(--red)" onClick={(e) => { ripple(e); onDrillDown({ filter: 'currently_banned', title: 'Currently banned' }) }} />
        <KpiCard icon={LifeBuoy} label="Open tickets" value={sup.open_tickets} tint="var(--gold)" />
        <KpiCard icon={LifeBuoy} label="Tickets · 7d" value={sup.tickets_7d} />
        <KpiCard icon={Clock} label="Avg. response" value={sup.avg_first_response_min === null ? '—' : `${sup.avg_first_response_min}m`} />
      </div>

      <AdminVerificationSection />

      <SectionTitle>Queue</SectionTitle>
      <Row icon={<LifeBuoy size={15} />} iconBg="rgba(255,79,79,0.12)" iconColor="var(--red)" label="Open tickets" sub="Waiting on a staff reply" value={String(sup.open_tickets)} />
      <Row icon={<Flag size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)" label="Flagged reports" sub="User & content reports to review" value={String(mod.open_reports)} />

      {activity.length > 0 && (
        <>
          <SectionTitle>Recent moderation</SectionTitle>
          <div className="neu-card" style={{ padding: '2px 14px' }}>
            {activity.map((entry, i) => (
              <div
                key={entry.id}
                style={{
                  display: 'flex', alignItems: 'center', gap: 9, padding: '9px 2px',
                  borderTop: i === 0 ? undefined : '1px solid var(--border)',
                }}
              >
                <span style={{
                  width: 26, height: 26, borderRadius: 8, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--surface2)', color: 'var(--text-dim)',
                }}>
                  <CheckCircle2 size={13} />
                </span>
                <span style={{ flex: 1, minWidth: 0, fontSize: 12, color: 'var(--text-dim)' }}>
                  <span style={{ color: 'var(--text)', fontWeight: 700 }}>{entry.moderator?.username ?? 'System'}</span>
                  {' — '}{entry.action.replace(/_/g, ' ')} <span style={{ color: 'var(--text-muted)' }}>· {entry.target_type}</span>
                </span>
                <span style={{ fontSize: 10.5, color: 'var(--text-muted)', flexShrink: 0 }}>
                  {new Date(entry.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  )
}
