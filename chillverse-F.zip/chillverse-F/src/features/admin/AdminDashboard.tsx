// src/features/admin/AdminDashboard.tsx
//
// The admin shell: fetches the dashboard stats once, then renders either
// the Concourse (home) or a full-screen wing (AdminWingScreen) that slides
// in over it — a real screen swap, not an inline scroll-to-section. This
// mirrors the standalone Concourse prototype's navigation model exactly;
// the only adaptation from the prototype is that "wings" here are backed
// by the app's real data and real feature components instead of mock data.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ShieldAlert } from 'lucide-react'
import { useModRole } from '../moderation/useModRole'
import { usePageHeader } from '../../context/PageHeader'
import { fetchAdminDashboardStats, type AdminDashboardStats, type AdminUserFilter } from './adminStats'
import AdminUserSearch from './AdminUserSearch'
import AdminActionSearch from './AdminActionSearch'
import AdminConcourse from './AdminConcourse'
import AdminWingScreen from './AdminWingScreen'
import { ADMIN_SECTIONS, ADMIN_WING_STORAGE_KEY, type AdminSection } from './adminSections'
import { useAuth } from '../auth/useAuth'

export default function AdminDashboard() {
  const navigate = useNavigate()
  // Preserves the original fixed back destination (/dashboard), not
  // generic browser-back.
  usePageHeader({ title: 'Admin Dashboard', onBack: () => navigate('/dashboard') })
  const { isAdmin, loading: roleLoading } = useModRole()
  const { user } = useAuth()
  const [stats, setStats] = useState<AdminDashboardStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchOpen, setSearchOpen] = useState(false)
  // Separate from `searchOpen` (which opens AdminUserSearch, a *people*
  // lookup) — this opens AdminActionSearch, the Concourse's search-every-
  // wing-and-action overlay.
  const [actionSearchOpen, setActionSearchOpen] = useState(false)
  // Drives the modal drill-down opened by tapping a KPI card or a
  // Directory row (New (7d), Active (7d), Staff members, Banned users,
  // etc.) — separate from `searchOpen`, which is the small anchored
  // type-to-search dropdown.
  const [drillDown, setDrillDown] = useState<{ filter?: AdminUserFilter; title: string } | null>(null)
  // null = the Concourse home screen. Any wing key slides its full-screen
  // detail in over the Concourse. Always starts on the Concourse — the
  // prototype never resumes mid-wing, so neither do we.
  const [activeSection, setActiveSection] = useState<AdminSection | null>(null)

  function selectSection(key: AdminSection) {
    setActiveSection(key)
    sessionStorage.setItem(ADMIN_WING_STORAGE_KEY, key)
  }

  function backToConcourse() {
    setActiveSection(null)
  }

  async function load() {
    setLoading(true)
    setError('')
    const { data, error } = await fetchAdminDashboardStats()
    if (error) setError(error)
    setStats(data)
    setLoading(false)
  }

  useEffect(() => {
    if (roleLoading) return
    if (!isAdmin) { setLoading(false); return }
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleLoading, isAdmin])

  if (roleLoading) return null

  if (!isAdmin) {
    return (
      <div style={{ maxWidth: 480, margin: '80px auto', textAlign: 'center', padding: 20 }}>
        <ShieldAlert size={32} style={{ color: 'var(--text-dim)', marginBottom: 10 }} />
        <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>Admins only</p>
        <p style={{ fontSize: 12.5, color: 'var(--text-dim)', marginTop: 6 }}>
          This dashboard is restricted to Chillverse admins.
        </p>
      </div>
    )
  }

  const activeMeta = activeSection ? ADMIN_SECTIONS.find(s => s.key === activeSection) ?? null : null

  return (
    <div style={{ maxWidth: 960, margin: '0 auto', paddingBottom: 56 }}>
      <div style={{ padding: '0 20px' }}>
        {error && (
          <div className="neu-card" style={{ padding: 16, marginTop: 16, color: 'var(--red)', fontSize: 12.5 }}>{error}</div>
        )}

        {loading && !stats && (
          <div className="neu-card" style={{ padding: 24, marginTop: 16, textAlign: 'center', color: 'var(--text-dim)', fontSize: 12.5 }}>
            Loading dashboard…
          </div>
        )}

        {stats && (
          // Screen stack: the Concourse always stays mounted underneath so
          // "back" is instant, and the wing screen (when one is open)
          // slides in over it, covering it edge-to-edge.
          <div style={{ position: 'relative', minHeight: 480 }}>
            <AdminConcourse
              stats={stats}
              activeSection={activeSection}
              onSelectSection={selectSection}
              onOpenUserSearch={() => setSearchOpen(true)}
              onOpenActionSearch={() => setActionSearchOpen(true)}
              loading={loading}
              onRefresh={load}
            />

            {activeMeta && (
              <AdminWingScreen
                section={activeMeta}
                stats={stats}
                myId={user?.id ?? null}
                onBack={backToConcourse}
                onOpenSearch={() => setSearchOpen(true)}
                onDrillDown={setDrillDown}
              />
            )}

            {searchOpen && (
              <div style={{ position: 'fixed', top: 70, right: 20, zIndex: 260 }}>
                <AdminUserSearch onClose={() => setSearchOpen(false)} />
              </div>
            )}
          </div>
        )}
      </div>

      {drillDown && (
        <AdminUserSearch
          variant="modal"
          filter={drillDown.filter}
          title={drillDown.title}
          onClose={() => setDrillDown(null)}
        />
      )}

      {actionSearchOpen && (
        <AdminActionSearch
          onSelect={selectSection}
          onClose={() => setActionSearchOpen(false)}
        />
      )}
    </div>
  )
}
