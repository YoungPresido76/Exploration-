// src/features/admin/AdminOpsPanel.tsx
//
// The "Ops console" wing of the Admin Dashboard, restyled to match how
// Settings.tsx is put together: a single scrollable page, grouped into
// SectionTitle + .settings-card blocks of compact Row/ToggleRow entries.
// Anything that needs a form (editing the maintenance message, composing
// a broadcast, flipping a whole category of flags) opens in a popover
// modal — the same pattern Settings uses for Log out / Microphone —
// instead of being sprawled inline as its own big card. Simple instant
// actions (a toggle, a CSV download) just happen right on the row, no
// modal needed, same as Settings' "Game sound" toggle or "Support" link.
//
// Mall/economy controls (bundles, item pricing/locking/timers, Flash
// Sale schedule, diamond gifting) live in AdminStoreSection.tsx instead —
// mounted under the "Mall economy" wing in AdminDashboard.tsx, next to
// the stats they act on, so this panel stays focused on general ops.
import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Power, Megaphone, Download, Activity, AlertTriangle,
  Gamepad2, Map as MapIcon, Settings2, Clock, Send, MessageSquare,
  Copy, Check, ChevronDown, ChevronUp, RefreshCw, Target, Zap, Gift, Search,
  ImagePlus, X, Bell, Ticket, Trash2, Gift as GiftIcon, Radio, Sliders,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { Row, ToggleRow, SectionTitle } from '../settings/settingsShared'
import { SegmentedTabs, KpiCard } from './AdminKit'
import { Modal, fieldLabel, inputStyle } from './adminModal'
import {
  fetchAppConfig, setMaintenanceMode, setErrorMode, broadcastNotification,
  fetchFeatureFlags, setFeatureFlag, setFeatureFlagGate, exportUsersCsv, exportTransactionsCsv,
  fetchSystemHealth, fetchRecentClientErrors,
  fetchGameGoalCycles, saveGameGoalDraft, rolloutGameGoalCycle, deleteGameGoalCycle, searchMallItems,
  fetchAnnouncements, createAnnouncement, deleteAnnouncement, uploadAnnouncementImage,
  fetchDashboardGreeting, setDashboardGreeting, setReferralPopupEnabled,
  type FeatureFlag, type SystemHealth, type ClientErrorLogRow, type GameGoalCycle, type GameGoalMallItem,
  type AdminAnnouncement, type AnnouncementKind,
} from './adminOps'
import { PENDING_MESSAGE } from './adminRequests'
import StatusOpsSection from './StatusOpsSection'
import ClubsOpsSection from './ClubsOpsSection'
import SecurityOpsSection from './SecurityOpsSection'
import { fetchStatusComponents, type StatusComponent } from '../status/statusApi'

// ── Shared modal shell (mirrors Settings.tsx's Log out / Microphone popovers) ──

// Modal / fieldLabel / inputStyle now live in ./adminModal.tsx (pulled out
// so StatusOpsSection.tsx and other sub-sections can import them without a
// circular dependency back on this file).

// ── Maintenance ─────────────────────────────────────────────────────

function MaintenanceMessageModal({ message, scheduledFor, onClose, onSaved }: {
  message: string
  scheduledFor: string
  onClose: () => void
  onSaved: (message: string, scheduledFor: string) => void
}) {
  const [text, setText] = useState(message)
  const [when, setWhen] = useState(scheduledFor)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    setSaving(true)
    setError('')
    // Re-sends the current enabled state implicitly — this modal only
    // edits copy/schedule, the ToggleRow on the main page owns on/off.
    const { data } = await fetchAppConfig()
    const { error } = await setMaintenanceMode(data?.maintenance_enabled ?? false, text, when ? new Date(when).toISOString() : null)
    setSaving(false)
    if (error) { setError(error); return }
    onSaved(text, when)
    onClose()
  }

  return (
    <Modal title="Maintenance message" onClose={onClose}>
      <p style={fieldLabel}>Message shown to players</p>
      <textarea value={text} onChange={e => setText(e.target.value)} rows={3} style={{ ...inputStyle, resize: 'vertical', marginBottom: 14 }} />
      <p style={{ ...fieldLabel, display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={10} /> Scheduled for (optional)</p>
      <input type="datetime-local" value={when} onChange={e => setWhen(e.target.value)} style={{ ...inputStyle, marginBottom: 16 }} />
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={onClose} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13 }}>Cancel</button>
        <button onClick={save} disabled={saving} className="btn-primary" style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: saving ? 0.6 : 1 }}>
          {saving ? 'Saving…' : 'Save'}
        </button>
      </div>
    </Modal>
  )
}

// ── Error mode ───────────────────────────────────────────────────────
// A separate sitewide state from Maintenance — same "block everything
// but staff" mechanism, different screen (flat black, no gear animation)
// and different copy, for when something's actually broken rather than
// a planned window. Mutually exclusive with Maintenance under the hood
// (see admin_set_site_status), so this modal re-sends the current
// error-mode on/off state the same way MaintenanceMessageModal does.
function ErrorMessageModal({ title, message, onClose, onSaved }: {
  title: string
  message: string
  onClose: () => void
  onSaved: (title: string, message: string) => void
}) {
  const [titleText, setTitleText] = useState(title)
  const [text, setText] = useState(message)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    if (!titleText.trim()) { setError('A title is required.'); return }
    setSaving(true)
    setError('')
    const { data } = await fetchAppConfig()
    const { error } = await setErrorMode(data?.site_status === 'error', titleText, text)
    setSaving(false)
    if (error) { setError(error); return }
    onSaved(titleText, text)
    onClose()
  }

  return (
    <Modal title="Error mode message" onClose={onClose}>
      <p style={fieldLabel}>Title (shown uppercase)</p>
      <input value={titleText} onChange={e => setTitleText(e.target.value)} maxLength={60} placeholder="CHILLVERSE IS UNAVAILABLE" style={{ ...inputStyle, marginBottom: 14 }} />
      <p style={fieldLabel}>Message shown to players</p>
      <textarea value={text} onChange={e => setText(e.target.value)} rows={3} placeholder="Chillverse is unavailable right now, but our team is on it." style={{ ...inputStyle, resize: 'vertical', marginBottom: 16 }} />
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={onClose} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13 }}>Cancel</button>
        <button onClick={save} disabled={saving} className="btn-primary" style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: saving ? 0.6 : 1 }}>
          {saving ? 'Saving…' : 'Save'}
        </button>
      </div>
    </Modal>
  )
}

// Maintenance mode and Error mode share one underlying `site_status`
// column (mutually exclusive — turning one on implicitly turns the other
// off, see admin_set_site_status). One hook owns the shared fetch so the
// two ToggleRows stay in sync with each other without an extra round trip.
function useSiteStatus() {
  const [status, setStatus] = useState<'live' | 'maintenance' | 'error'>('live')
  const [message, setMessage] = useState('')
  const [scheduledFor, setScheduledFor] = useState('')
  const [errorTitle, setErrorTitle] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [toggling, setToggling] = useState<'maintenance' | 'error' | null>(null)

  useEffect(() => {
    fetchAppConfig().then(({ data }) => {
      if (data) {
        setStatus(data.site_status)
        setMessage(data.maintenance_message)
        setScheduledFor(data.maintenance_scheduled_for ? data.maintenance_scheduled_for.slice(0, 16) : '')
        setErrorTitle(data.error_title)
        setErrorMessage(data.error_message)
      }
      setLoading(false)
    })
  }, [])

  async function toggleMaintenance() {
    setToggling('maintenance')
    const next = status === 'maintenance' ? 'live' : 'maintenance'
    const { pending, error } = await setMaintenanceMode(next === 'maintenance', message, scheduledFor ? new Date(scheduledFor).toISOString() : null)
    setToggling(null)
    if (pending) return PENDING_MESSAGE
    if (!error) setStatus(next)
    return error
  }

  async function toggleError() {
    setToggling('error')
    const next = status === 'error' ? 'live' : 'error'
    const { pending, error } = await setErrorMode(next === 'error', errorTitle, errorMessage)
    setToggling(null)
    if (pending) return PENDING_MESSAGE
    if (!error) setStatus(next)
    return error
  }

  return {
    status, message, scheduledFor, errorTitle, errorMessage, loading, toggling,
    toggleMaintenance, toggleError, setMessage, setScheduledFor, setErrorTitle, setErrorMessage,
  }
}

// ── Dashboard greeting override ────────────────────────────────────────
// Same shape as maintenance: a ToggleRow flips automatic/custom, a Row
// opens a modal to edit the pinned line/sub. Unlike maintenance mode,
// "off" (automatic) has no message to preserve — going back to automatic
// just hands the Dashboard's own greeting pool the wheel again.

function DashboardGreetingModal({ line, sub, onClose, onSaved }: {
  line: string
  sub: string
  onClose: () => void
  onSaved: (line: string, sub: string) => void
}) {
  const [lineText, setLineText] = useState(line)
  const [subText, setSubText] = useState(sub)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    if (!lineText.trim()) { setError('A greeting line is required.'); return }
    setSaving(true)
    setError('')
    const { error } = await setDashboardGreeting('custom', lineText, subText)
    setSaving(false)
    if (error) { setError(error); return }
    onSaved(lineText, subText)
    onClose()
  }

  return (
    <Modal title="Dashboard greeting" onClose={onClose}>
      <p style={fieldLabel}>Headline (shown to every player)</p>
      <input value={lineText} onChange={e => setLineText(e.target.value)} maxLength={80} placeholder="e.g. Happy Independence Day 🇳🇬" style={{ ...inputStyle, marginBottom: 14 }} />
      <p style={fieldLabel}>Subtext (optional)</p>
      <input value={subText} onChange={e => setSubText(e.target.value)} maxLength={100} placeholder="e.g. Double XP is live all weekend." style={{ ...inputStyle, marginBottom: 16 }} />
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={onClose} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13 }}>Cancel</button>
        <button onClick={save} disabled={saving} className="btn-primary" style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: saving ? 0.6 : 1 }}>
          {saving ? 'Saving…' : 'Save & pin it'}
        </button>
      </div>
    </Modal>
  )
}

function useDashboardGreeting() {
  const [mode, setMode] = useState<'automatic' | 'custom'>('automatic')
  const [line, setLine] = useState('')
  const [sub, setSub] = useState('')
  const [loading, setLoading] = useState(true)
  const [toggling, setToggling] = useState(false)

  useEffect(() => {
    fetchDashboardGreeting().then(({ data }) => {
      if (data) {
        setMode(data.dashboard_greeting_mode)
        setLine(data.dashboard_greeting_line || '')
        setSub(data.dashboard_greeting_sub || '')
      }
      setLoading(false)
    })
  }, [])

  /** Toggling on with no line saved yet has nothing to pin, so it opens
   *  the editor instead of silently switching to an empty custom greeting. */
  async function toggle(): Promise<{ error: string | null; needsMessage: boolean }> {
    if (mode === 'automatic') {
      if (!line.trim()) return { error: null, needsMessage: true }
      setToggling(true)
      const { error } = await setDashboardGreeting('custom', line, sub)
      setToggling(false)
      if (!error) setMode('custom')
      return { error, needsMessage: false }
    }
    setToggling(true)
    const { error } = await setDashboardGreeting('automatic')
    setToggling(false)
    if (!error) setMode('automatic')
    return { error, needsMessage: false }
  }

  return { mode, line, sub, loading, toggling, toggle, setLine, setSub, setMode }
}

// ── Broadcast ─────────────────────────────────────────────────────────

function BroadcastModal({ onClose }: { onClose: () => void }) {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [confirming, setConfirming] = useState(false)
  const [sending, setSending] = useState(false)
  const [result, setResult] = useState('')
  const [error, setError] = useState('')

  async function send() {
    setSending(true)
    setError('')
    const { count, pending, error } = await broadcastNotification(title.trim(), body.trim())
    setSending(false)
    setConfirming(false)
    if (error) { setError(error); return }
    setResult(pending ? PENDING_MESSAGE : `Sent to ${count.toLocaleString()} ${count === 1 ? 'user' : 'users'}.`)
    setTitle('')
    setBody('')
  }

  const canSend = title.trim().length > 0 && body.trim().length > 0

  return (
    <Modal title="Broadcast notification" onClose={onClose}>
      <p style={fieldLabel}>Title</p>
      <input value={title} onChange={e => setTitle(e.target.value)} maxLength={80} placeholder="e.g. Scheduled maintenance tonight" style={{ ...inputStyle, marginBottom: 14 }} />
      <p style={fieldLabel}>Message</p>
      <textarea value={body} onChange={e => setBody(e.target.value)} rows={3} maxLength={400} placeholder="What should everyone know?" style={{ ...inputStyle, resize: 'vertical', marginBottom: 16 }} />

      {result && <p style={{ fontSize: 12, color: '#4fd18a', fontWeight: 700, marginBottom: 12 }}>{result}</p>}
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}

      {!confirming ? (
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onClose} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13 }}>Close</button>
          <button
            onClick={() => canSend && setConfirming(true)}
            disabled={!canSend}
            className="btn-primary"
            style={{ flex: 1, padding: '10px 0', fontSize: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, opacity: canSend ? 1 : 0.5 }}
          >
            <Send size={12} /> Send to all
          </button>
        </div>
      ) : (
        <div>
          <p style={{ fontSize: 12.5, color: 'var(--text-dim)', marginBottom: 12, fontWeight: 600 }}>Send this to every user — sure?</p>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={() => setConfirming(false)} disabled={sending} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13 }}>Cancel</button>
            <button onClick={send} disabled={sending} className="btn-primary" style={{ flex: 1, padding: '10px 0', fontSize: 13, background: 'var(--red)', opacity: sending ? 0.6 : 1 }}>
              {sending ? 'Sending…' : 'Confirm send'}
            </button>
          </div>
        </div>
      )}
    </Modal>
  )
}

// ── Popup announcements ────────────────────────────────────────────────
// The refer-and-earn-style popup, not the one-time Broadcast notification
// above. Shows once per calendar day to every signed-in user until an
// admin deletes it below, or until it auto-expires at the chosen duration.

// Popup announcement / What's New limits. These are the ONLY cap on the
// text — admin_announcements.title and .body are plain `text` with no
// length constraint server-side, so raising them here is the whole change.
// Generous rather than unlimited: PromoOverlay scrolls a long message now
// (see its content wrapper), but a popup nobody reads to the end is still
// a popup nobody read.
const ANNOUNCEMENT_TITLE_MAX = 120
const ANNOUNCEMENT_BODY_MAX = 2000

/** Counter next to a field label — greys out until you're near the cap. */
function counterStyle(len: number, max: number) {
  const near = len >= max * 0.9
  return {
    fontSize: 10.5,
    fontWeight: 700,
    color: near ? 'var(--gold)' : 'var(--text-muted)',
    marginBottom: 6,
  } as const
}

const ANNOUNCEMENT_KINDS: { id: AnnouncementKind; label: string; sub: string }[] = [
  { id: 'daily', label: 'Daily popup', sub: 'Once a day, every day' },
  { id: 'whats_new', label: "What's New", sub: 'Once per player, shows first' },
]

const DURATION_OPTIONS: { label: string; hours: number | null }[] = [
  { label: 'Until I delete it', hours: null },
  { label: '1 day', hours: 24 },
  { label: '3 days', hours: 72 },
  { label: '7 days', hours: 24 * 7 },
  { label: '30 days', hours: 24 * 30 },
]

function timeRemaining(expiresAt: string | null): string {
  if (!expiresAt) return 'Stays up until deleted'
  const ms = new Date(expiresAt).getTime() - Date.now()
  if (ms <= 0) return 'Expiring…'
  const hours = Math.round(ms / 36e5)
  if (hours < 24) return `Auto-deletes in ${hours}h`
  return `Auto-deletes in ${Math.round(hours / 24)}d`
}

function NewAnnouncementForm({ onCreated }: { onCreated: () => void }) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [uploadingImage, setUploadingImage] = useState(false)
  const [durationHours, setDurationHours] = useState<number | null>(null)
  const [kind, setKind] = useState<AnnouncementKind>('daily')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function handleImagePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploadingImage(true)
    setError('')
    try {
      const url = await uploadAnnouncementImage(file)
      setImageUrl(url)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image.')
    } finally {
      setUploadingImage(false)
    }
  }

  const canSend = title.trim().length > 0 && body.trim().length > 0

  async function send() {
    setSaving(true)
    setError('')
    const { error } = await createAnnouncement(title.trim(), body.trim(), imageUrl, durationHours, kind)
    setSaving(false)
    if (error) { setError(error); return }
    setTitle('')
    setBody('')
    setImageUrl(null)
    setDurationHours(null)
    setKind('daily')
    onCreated()
  }

  return (
    <div style={{ padding: 14, borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 16 }}>
      <p style={fieldLabel}>Type</p>
      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
        {ANNOUNCEMENT_KINDS.map(k => {
          const active = kind === k.id
          return (
            <button
              key={k.id}
              onClick={(e) => { ripple(e); setKind(k.id) }}
              style={{
                flex: 1, padding: '9px 6px', borderRadius: 10, cursor: 'pointer', textAlign: 'left',
                border: active ? '1px solid var(--accent)' : '1px solid var(--border)',
                background: active ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'var(--surface)',
                color: active ? 'var(--accent)' : 'var(--text-dim)',
              }}
            >
              <span style={{ display: 'block', fontSize: 12, fontWeight: 800 }}>{k.label}</span>
              <span style={{ display: 'block', fontSize: 10, color: 'var(--text-muted)', marginTop: 2, lineHeight: 1.35 }}>{k.sub}</span>
            </button>
          )
        })}
      </div>

      <p style={fieldLabel}>Image</p>
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImagePick} style={{ display: 'none' }} />
      {imageUrl ? (
        <div style={{ position: 'relative', marginBottom: 12, borderRadius: 12, overflow: 'hidden', border: '1px solid var(--border)' }}>
          <img src={imageUrl} alt="" style={{ width: '100%', height: 110, objectFit: 'cover', display: 'block' }} />
          <button
            onClick={(e) => { ripple(e); setImageUrl(null) }}
            aria-label="Remove image"
            style={{ position: 'absolute', top: 6, right: 6, width: 24, height: 24, borderRadius: '50%', background: 'rgba(0,0,0,0.55)', border: 'none', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <X size={13} />
          </button>
          <button
            onClick={(e) => { ripple(e); fileInputRef.current?.click() }}
            disabled={uploadingImage}
            style={{ position: 'absolute', bottom: 6, right: 6, fontSize: 10.5, fontWeight: 700, padding: '5px 10px', borderRadius: 8, background: 'rgba(0,0,0,0.55)', border: 'none', color: '#fff', cursor: 'pointer' }}
          >
            {uploadingImage ? 'Uploading…' : 'Replace'}
          </button>
        </div>
      ) : (
        <button
          onClick={(e) => { ripple(e); fileInputRef.current?.click() }}
          disabled={uploadingImage}
          className="btn-secondary"
          style={{ width: '100%', padding: '14px 0', fontSize: 11.5, marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, opacity: uploadingImage ? 0.6 : 1 }}
        >
          <ImagePlus size={14} /> {uploadingImage ? 'Uploading…' : 'Upload image'}
        </button>
      )}

      <div className="flex items-center justify-between">
        <p style={fieldLabel}>Title</p>
        <span style={counterStyle(title.length, ANNOUNCEMENT_TITLE_MAX)}>{title.length}/{ANNOUNCEMENT_TITLE_MAX}</span>
      </div>
      <input value={title} onChange={e => setTitle(e.target.value)} maxLength={ANNOUNCEMENT_TITLE_MAX} placeholder="e.g. New PvP season is live" style={{ ...inputStyle, marginBottom: 12 }} />

      <div className="flex items-center justify-between">
        <p style={fieldLabel}>Message</p>
        <span style={counterStyle(body.length, ANNOUNCEMENT_BODY_MAX)}>{body.length}/{ANNOUNCEMENT_BODY_MAX}</span>
      </div>
      {/* rows={8}: a What's New release note is usually a list of changes,
          and a 3-row box made anything past a sentence feel like it didn't
          fit. Still resizable. */}
      <textarea value={body} onChange={e => setBody(e.target.value)} rows={8} maxLength={ANNOUNCEMENT_BODY_MAX} placeholder="What should everyone know?" style={{ ...inputStyle, resize: 'vertical', marginBottom: 12, lineHeight: 1.5 }} />

      <p style={fieldLabel}>Auto-delete</p>
      <select
        value={durationHours === null ? 'never' : String(durationHours)}
        onChange={e => setDurationHours(e.target.value === 'never' ? null : Number(e.target.value))}
        style={{ ...inputStyle, marginBottom: 14 }}
      >
        {DURATION_OPTIONS.map(o => (
          <option key={o.label} value={o.hours === null ? 'never' : o.hours}>{o.label}</option>
        ))}
      </select>

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}

      <button
        onClick={send}
        disabled={!canSend || saving}
        className="btn-primary"
        style={{ width: '100%', padding: '10px 0', fontSize: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, opacity: (canSend && !saving) ? 1 : 0.5 }}
      >
        <Send size={12} /> {saving ? 'Publishing…' : kind === 'whats_new' ? "Publish What's New" : 'Show as daily popup'}
      </button>
    </div>
  )
}

function AnnouncementRow({ item, onDeleted }: { item: AdminAnnouncement; onDeleted: (id: string) => void }) {
  const [confirming, setConfirming] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [error, setError] = useState('')

  async function handleDelete() {
    setDeleting(true)
    setError('')
    const { error } = await deleteAnnouncement(item.id)
    setDeleting(false)
    if (error) { setError(error); return }
    onDeleted(item.id)
  }

  return (
    <div style={{ borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px' }}>
        {item.image_url ? (
          <img src={item.image_url} alt="" style={{ width: 36, height: 36, borderRadius: 8, objectFit: 'cover', flexShrink: 0 }} />
        ) : (
          <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--surface)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Bell size={14} style={{ color: 'var(--text-muted)' }} />
          </div>
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.title}</p>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '2px 0 0', display: 'flex', alignItems: 'center', gap: 5 }}>
            <span style={{
              fontSize: 9, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.4,
              padding: '1px 5px', borderRadius: 5, flexShrink: 0,
              color: item.kind === 'whats_new' ? 'var(--accent)' : 'var(--text-dim)',
              background: item.kind === 'whats_new' ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface)',
            }}>
              {item.kind === 'whats_new' ? "What's New" : 'Daily'}
            </span>
            {timeRemaining(item.expires_at)}
          </p>
        </div>
        {!confirming ? (
          <button
            onClick={(e) => { ripple(e); setConfirming(true) }}
            aria-label="Delete announcement"
            style={{ flexShrink: 0, width: 26, height: 26, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: 'pointer' }}
          >
            <Trash2 size={12} />
          </button>
        ) : (
          <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
            <button onClick={() => setConfirming(false)} disabled={deleting} className="btn-secondary" style={{ fontSize: 10.5, padding: '5px 8px' }}>Cancel</button>
            <button onClick={handleDelete} disabled={deleting} className="btn-primary" style={{ fontSize: 10.5, padding: '5px 8px', background: 'var(--red)' }}>
              {deleting ? '…' : 'Delete'}
            </button>
          </div>
        )}
      </div>
      {error && <p style={{ fontSize: 10.5, color: 'var(--red)', margin: '0 10px 8px' }}>{error}</p>}
    </div>
  )
}

// ── Refer-and-earn popup kill switch (migration 0130) ──────────────────
// The one popup with no row behind it — the advert is hardcoded in
// useReferralPromoAd, so there's nothing to delete, only a switch. Off
// means it stops rendering for everyone, mid-session included (the hook
// re-checks on its own 15-minute interval).
function useReferralPopup() {
  const [enabled, setEnabled] = useState(true)
  const [loading, setLoading] = useState(true)
  const [toggling, setToggling] = useState(false)

  useEffect(() => {
    fetchAppConfig().then(({ data }) => {
      if (data) setEnabled(data.referral_popup_enabled)
      setLoading(false)
    })
  }, [])

  async function toggle() {
    setToggling(true)
    const next = !enabled
    const { error } = await setReferralPopupEnabled(next)
    setToggling(false)
    if (!error) setEnabled(next)
    return error
  }

  return { enabled, loading, toggling, toggle }
}

function AnnouncementModal({ onClose }: { onClose: () => void }) {
  const [items, setItems] = useState<AdminAnnouncement[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  function load() {
    setLoading(true)
    setError('')
    fetchAnnouncements().then(({ data, error }) => {
      if (error) setError(error)
      setItems(data)
      setLoading(false)
    })
  }

  useEffect(() => { load() }, [])

  return (
    <Modal title="Popup announcement" onClose={onClose} width={440}>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Shows as a popup (same style as the refer-a-friend modal) to every signed-in user, until you delete it or it hits its auto-delete time.
        A <strong style={{ color: 'var(--text-dim)' }}>Daily popup</strong> reappears once every day; a <strong style={{ color: 'var(--text-dim)' }}>What's New</strong> shows once per player and jumps the queue ahead of the daily one.
      </p>

      <NewAnnouncementForm onCreated={load} />

      <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 8px' }}>Live now</p>
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 10 }}>{error}</p>}
      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 14 }}>Loading…</p>
      ) : items.length === 0 ? (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '4px 0' }}>Nothing live right now.</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {items.map(item => (
            <AnnouncementRow key={item.id} item={item} onDeleted={(id) => setItems(prev => prev.filter(i => i.id !== id))} />
          ))}
        </div>
      )}
    </Modal>
  )
}

// ── Feature flags ─────────────────────────────────────────────────────

const CATEGORY_META: Record<string, { label: string; icon: typeof Gamepad2; sub: string }> = {
  game: { label: 'Games', icon: Gamepad2, sub: 'Disabled games stop being newly playable for everyone.' },
  map: { label: 'Exploration maps', icon: MapIcon, sub: 'Disabled maps stop being newly enterable for everyone.' },
  system: { label: 'Systems', icon: Settings2, sub: 'Broad kill-switches for whole app areas.' },
}

function FlagCategoryModal({ category, flags, onClose, onChange }: {
  category: string
  flags: FeatureFlag[]
  onClose: () => void
  onChange: (key: string, enabled: boolean) => void
}) {
  const [busyKey, setBusyKey] = useState<string | null>(null)
  const [error, setError] = useState('')
  const [gateEditKey, setGateEditKey] = useState<string | null>(null)
  const meta = CATEGORY_META[category] ?? { label: category, icon: Settings2, sub: '' }

  async function toggle(f: FeatureFlag) {
    setBusyKey(f.key)
    setError('')
    const next = !f.enabled
    const { error } = await setFeatureFlag(f.key, next)
    setBusyKey(null)
    if (error) { setError(error); return }
    onChange(f.key, next)
  }

  const gateEditFlag = flags.find(f => f.key === gateEditKey) ?? null

  return (
    <Modal title={meta.label} onClose={onClose} width={420}>
      {meta.sub && <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 14px' }}>{meta.sub}</p>}
      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 10 }}>{error}</p>}
      <div className="settings-card" style={{ marginBottom: 0 }}>
        {flags.map(f => (
          <div key={f.key} style={{ display: 'flex', alignItems: 'stretch' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <ToggleRow
                label={f.label}
                on={f.enabled}
                onToggle={() => toggle(f)}
                disabled={busyKey === f.key}
              />
            </div>
            {/* Only the page-level flags (Posts / Lab / Highlights) carry gate
               copy — DB seeds gate_title for those three and leaves it null
               everywhere else, so that's the signal for whether this button
               shows. */}
            {f.gate_title !== null && (
              <button
                type="button"
                onClick={(e) => { ripple(e); setGateEditKey(f.key) }}
                aria-label={`Configure ${f.label} error behavior`}
                title="Configure locked/toast behavior"
                style={{
                  width: 44, flexShrink: 0, border: 'none', borderLeft: '1px solid var(--border)',
                  background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}
              >
                <Settings2 size={14} />
              </button>
            )}
          </div>
        ))}
      </div>

      {gateEditFlag && (
        <FlagGateModal
          flag={gateEditFlag}
          onClose={() => setGateEditKey(null)}
          onSaved={(patch) => {
            gateEditFlag.gate_mode = patch.gate_mode
            gateEditFlag.gate_title = patch.gate_title
            gateEditFlag.gate_message = patch.gate_message
            gateEditFlag.toast_message = patch.toast_message
          }}
        />
      )}
    </Modal>
  )
}

// Edits how a page-level flag (Posts / Lab / Highlights) presents itself
// when it's off: a full-screen lock (custom title + message) or the page
// rendering normally with an error toast on top — plus the toast copy
// used both for that "toast" gate_mode and for the *action*-level failure
// (e.g. "Share your win" while Highlights is off), which fires regardless
// of gate_mode.
function FlagGateModal({ flag, onClose, onSaved }: {
  flag: FeatureFlag
  onClose: () => void
  onSaved: (patch: { gate_mode: 'locked' | 'toast'; gate_title: string | null; gate_message: string | null; toast_message: string | null }) => void
}) {
  const [gateMode, setGateMode] = useState<'locked' | 'toast'>(flag.gate_mode)
  const [gateTitle, setGateTitle] = useState(flag.gate_title ?? '')
  const [gateMessage, setGateMessage] = useState(flag.gate_message ?? '')
  const [toastMessage, setToastMessage] = useState(flag.toast_message ?? '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    if (gateMode === 'locked' && !gateTitle.trim()) { setError('A title is required for Locked mode.'); return }
    setSaving(true)
    setError('')
    const { error } = await setFeatureFlagGate(flag.key, gateMode, gateTitle, gateMessage, toastMessage)
    setSaving(false)
    if (error) { setError(error); return }
    onSaved({ gate_mode: gateMode, gate_title: gateTitle || null, gate_message: gateMessage || null, toast_message: toastMessage || null })
    onClose()
  }

  return (
    <Modal title={`${flag.label} — error behavior`} onClose={onClose} width={420}>
      <p style={fieldLabel}>When this is turned off</p>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {(['locked', 'toast'] as const).map(m => (
          <button
            key={m}
            type="button"
            onClick={(e) => { ripple(e); setGateMode(m) }}
            style={{
              flex: 1, padding: '10px 0', borderRadius: 10, fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
              border: `1px solid ${gateMode === m ? 'var(--accent)' : 'var(--border)'}`,
              background: gateMode === m ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
              color: gateMode === m ? 'var(--accent)' : 'var(--text)',
            }}
          >
            {m === 'locked' ? 'Locked (black screen)' : 'Toast (page still shows)'}
          </button>
        ))}
      </div>

      {gateMode === 'locked' && (
        <>
          <p style={fieldLabel}>Locked-screen title (shown uppercase)</p>
          <input value={gateTitle} onChange={e => setGateTitle(e.target.value)} maxLength={60} placeholder="THIS PAGE IS TEMPORARILY UNAVAILABLE" style={{ ...inputStyle, marginBottom: 14 }} />
          <p style={fieldLabel}>Locked-screen message</p>
          <textarea value={gateMessage} onChange={e => setGateMessage(e.target.value)} rows={2} placeholder="An error occurred while loading this page." style={{ ...inputStyle, resize: 'vertical', marginBottom: 16 }} />
        </>
      )}

      <p style={fieldLabel}>Error toast text</p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 6px' }}>
        Shown for any post/share attempt blocked by this flag, and — in Toast mode — on the page itself.
      </p>
      <input value={toastMessage} onChange={e => setToastMessage(e.target.value)} maxLength={80} placeholder="Failed to post. Try again later." style={{ ...inputStyle, marginBottom: 16 }} />

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={onClose} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13 }}>Cancel</button>
        <button onClick={save} disabled={saving} className="btn-primary" style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: saving ? 0.6 : 1 }}>
          {saving ? 'Saving…' : 'Save'}
        </button>
      </div>
    </Modal>
  )
}

// ── System health ────────────────────────────────────────────────────

function HealthStat({ label, value, warn }: { label: string; value: string | number; warn?: boolean }) {
  return (
    <div style={{ padding: '10px 12px', borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
      <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 3px' }}>{label}</p>
      <p style={{ fontSize: 16, fontWeight: 800, color: warn ? 'var(--red)' : 'var(--text)', margin: 0 }}>{value}</p>
    </div>
  )
}

/** Best-effort clipboard copy — Clipboard API can throw in insecure or
 *  permission-denied contexts, so callers get a boolean back instead of
 *  a thrown error, and can decide what (if anything) to show. */
async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    return false
  }
}

function formatTimestamp(iso: string): string {
  return new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
}

function formatErrorRow(e: ClientErrorLogRow): string {
  const lines = [
    `[${formatTimestamp(e.created_at)}] ${e.message}`,
    `User: ${e.username ?? 'anonymous'}`,
    `Path: ${e.path ?? '—'}`,
  ]
  if (e.stack) lines.push('Stack:', e.stack)
  return lines.join('\n')
}

function formatHealthReport(health: SystemHealth, errors: ClientErrorLogRow[]): string {
  const lines = [
    `Chillverse system health — generated ${new Date(health.generated_at).toLocaleString()}`,
    '',
    `Client errors (24h): ${health.client_errors.errors_24h}`,
    `Client errors (7d): ${health.client_errors.errors_7d}`,
    `Open reports: ${health.moderation_backlog.open_reports}`,
    `Oldest open report: ${health.moderation_backlog.oldest_open_report_age_hours != null ? `${health.moderation_backlog.oldest_open_report_age_hours}h` : '—'}`,
    `Mod actions (24h): ${health.moderation_backlog.actions_24h}`,
    `Open support tickets: ${health.support_backlog.open_tickets}`,
    `Oldest open ticket: ${health.support_backlog.oldest_open_ticket_age_hours != null ? `${health.support_backlog.oldest_open_ticket_age_hours}h` : '—'}`,
    `Disabled flags: ${health.flags.disabled_count}`,
    `Maintenance mode: ${health.flags.maintenance_enabled ? 'ON' : 'off'}`,
  ]

  if (health.client_errors.top_messages_7d.length > 0) {
    lines.push('', 'Most common errors (7d):')
    for (const m of health.client_errors.top_messages_7d) lines.push(`  ${m.occurrences}× — ${m.message}`)
  }

  if (errors.length > 0) {
    lines.push('', `Recent errors (${errors.length}):`, '')
    errors.forEach((e, i) => { lines.push(formatErrorRow(e)); if (i < errors.length - 1) lines.push('') })
  }

  return lines.join('\n')
}

function ErrorLogRow({ err, copiedId, onCopy }: {
  err: ClientErrorLogRow
  copiedId: string | null
  onCopy: (id: string, text: string) => void
}) {
  const [open, setOpen] = useState(false)
  const hasDetail = !!(err.stack || err.path)

  return (
    <div style={{ borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)', overflow: 'hidden' }}>
      <div
        onClick={() => hasDetail && setOpen(o => !o)}
        style={{ display: 'flex', alignItems: 'flex-start', gap: 8, padding: '8px 10px', cursor: hasDetail ? 'pointer' : 'default' }}
      >
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 11.5, color: 'var(--text)', margin: 0, wordBreak: 'break-word' }}>{err.message}</p>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '3px 0 0' }}>
            {formatTimestamp(err.created_at)} · {err.username ?? 'anonymous'}{err.path ? ` · ${err.path}` : ''}
          </p>
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onCopy(err.id, formatErrorRow(err)) }}
          aria-label="Copy error"
          style={{ flexShrink: 0, width: 24, height: 24, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--surface)', border: '1px solid var(--border)', color: copiedId === err.id ? '#4fd18a' : 'var(--text-dim)', cursor: 'pointer' }}
        >
          {copiedId === err.id ? <Check size={11} /> : <Copy size={11} />}
        </button>
        {hasDetail && (
          <div style={{ flexShrink: 0, width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
            {open ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
          </div>
        )}
      </div>
      {open && hasDetail && (
        <div style={{ padding: '0 10px 10px', borderTop: '1px solid var(--border)' }}>
          {err.path && (
            <p style={{ fontSize: 10.5, color: 'var(--text-dim)', margin: '8px 0 0' }}>
              <span style={{ color: 'var(--text-muted)' }}>Path:</span> {err.path}
            </p>
          )}
          {err.stack && (
            <pre
              className="font-mono"
              style={{
                fontSize: 10, lineHeight: 1.5, color: 'var(--text-dim)', margin: '8px 0 0',
                padding: 8, borderRadius: 8, background: 'var(--surface)', border: '1px solid var(--border)',
                overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
              }}
            >
              {err.stack}
            </pre>
          )}
        </div>
      )}
    </div>
  )
}

function SystemHealthModal({ onClose }: { onClose: () => void }) {
  const [health, setHealth] = useState<SystemHealth | null>(null)
  const [errors, setErrors] = useState<ClientErrorLogRow[]>([])
  const [loading, setLoading] = useState(true)
  const [errorsLoading, setErrorsLoading] = useState(true)
  const [error, setError] = useState('')
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [copiedReport, setCopiedReport] = useState(false)

  const load = () => {
    setLoading(true)
    setErrorsLoading(true)
    setError('')
    fetchSystemHealth().then(({ data, error }) => {
      if (error) setError(error)
      setHealth(data)
      setLoading(false)
    })
    fetchRecentClientErrors(40).then(({ data }) => {
      setErrors(data)
      setErrorsLoading(false)
    })
  }

  useEffect(() => { load() }, [])

  function handleCopyRow(id: string, text: string) {
    copyText(text).then(ok => {
      if (!ok) return
      setCopiedId(id)
      setTimeout(() => setCopiedId(prev => (prev === id ? null : prev)), 1600)
    })
  }

  function handleCopyReport() {
    if (!health) return
    copyText(formatHealthReport(health, errors)).then(ok => {
      if (!ok) return
      setCopiedReport(true)
      setTimeout(() => setCopiedReport(false), 1600)
    })
  }

  return (
    <Modal title="System health" onClose={onClose} width={480}>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 12px' }}>
        Real signals only — client error volume and report/ticket backlog. No platform-level logs are available to this client.
      </p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        <button
          onClick={handleCopyReport}
          disabled={!health}
          className="btn-secondary"
          style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '8px 0', fontSize: 12, opacity: health ? 1 : 0.5 }}
        >
          {copiedReport ? <Check size={12} /> : <Copy size={12} />} {copiedReport ? 'Copied' : 'Copy full report'}
        </button>
        <button
          onClick={load}
          className="btn-secondary"
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '8px 14px', fontSize: 12 }}
        >
          <RefreshCw size={12} /> Refresh
        </button>
      </div>

      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>Loading…</p>
      ) : error ? (
        <p style={{ fontSize: 11.5, color: 'var(--red)' }}>{error}</p>
      ) : health && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 8, marginBottom: 14 }}>
            <HealthStat label="Client errors (24h)" value={health.client_errors.errors_24h} warn={health.client_errors.errors_24h > 0} />
            <HealthStat label="Client errors (7d)" value={health.client_errors.errors_7d} />
            <HealthStat label="Open reports" value={health.moderation_backlog.open_reports} warn={health.moderation_backlog.open_reports > 5} />
            <HealthStat
              label="Oldest open report"
              value={health.moderation_backlog.oldest_open_report_age_hours != null ? `${health.moderation_backlog.oldest_open_report_age_hours}h` : '—'}
            />
            <HealthStat label="Mod actions (24h)" value={health.moderation_backlog.actions_24h} />
            <HealthStat label="Open tickets" value={health.support_backlog.open_tickets} />
            <HealthStat
              label="Oldest open ticket"
              value={health.support_backlog.oldest_open_ticket_age_hours != null ? `${health.support_backlog.oldest_open_ticket_age_hours}h` : '—'}
            />
            <HealthStat label="Disabled flags" value={health.flags.disabled_count} warn={health.flags.disabled_count > 0} />
          </div>

          {health.flags.maintenance_enabled && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 10px', borderRadius: 10, background: 'rgba(255,79,79,0.1)', border: '1px solid rgba(255,79,79,0.3)', marginBottom: 14 }}>
              <AlertTriangle size={12} style={{ color: 'var(--red)', flexShrink: 0 }} />
              <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--red)' }}>Maintenance mode is currently ON.</span>
            </div>
          )}

          {health.client_errors.top_messages_7d.length > 0 && (
            <>
              <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 6px' }}>Most common errors (7d)</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 16 }}>
                {health.client_errors.top_messages_7d.map((m, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontSize: 11, padding: '6px 8px', borderRadius: 8, background: 'var(--surface2)' }}>
                    <span style={{ color: 'var(--text-dim)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.message}</span>
                    <span style={{ color: 'var(--text-muted)', flexShrink: 0, fontWeight: 700 }}>{m.occurrences}×</span>
                  </div>
                ))}
              </div>
            </>
          )}

          <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 6px' }}>
            Recent errors {errors.length > 0 ? `(${errors.length})` : ''}
          </p>
          {errorsLoading ? (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '8px 0' }}>Loading…</p>
          ) : errors.length === 0 ? (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '8px 0' }}>No client errors logged recently.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {errors.map(e => (
                <ErrorLogRow key={e.id} err={e} copiedId={copiedId} onCopy={handleCopyRow} />
              ))}
            </div>
          )}
        </>
      )}
    </Modal>
  )
}

// ── Game Goal Reward Control (Activity Goals) ──────────────────────────

function timeLeft(endsAt: string | null): string {
  if (!endsAt) return '—'
  const ms = new Date(endsAt).getTime() - Date.now()
  if (ms <= 0) return 'ended'
  const days = Math.floor(ms / 86_400_000)
  const hours = Math.floor((ms % 86_400_000) / 3_600_000)
  return `${days}d ${hours}h left`
}

function MallItemAutosuggest({ value, onChange }: {
  value: GameGoalMallItem | null
  onChange: (item: GameGoalMallItem | null) => void
}) {
  const [query, setQuery] = useState(value?.name ?? '')
  const [results, setResults] = useState<GameGoalMallItem[]>([])
  const [open, setOpen] = useState(false)
  const [searching, setSearching] = useState(false)

  useEffect(() => {
    if (value) { setQuery(value.name); return }
  }, [value])

  useEffect(() => {
    if (!open) return
    if (query.trim().length < 2) { setResults([]); return }
    setSearching(true)
    const t = setTimeout(() => {
      searchMallItems(query).then(({ data }) => { setResults(data); setSearching(false) })
    }, 220)
    return () => clearTimeout(t)
  }, [query, open])

  return (
    <div style={{ position: 'relative' }}>
      <div style={{ position: 'relative' }}>
        <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true); if (value) onChange(null) }}
          onFocus={() => setOpen(true)}
          placeholder="Type a Mall item name…"
          style={{ ...inputStyle, paddingLeft: 30 }}
        />
      </div>
      {open && query.trim().length >= 2 && (
        <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 4, zIndex: 5, background: 'var(--popover)', border: '1px solid var(--border)', borderRadius: 12, boxShadow: 'var(--elev-popover)', maxHeight: 220, overflowY: 'auto' }}>
          {searching ? (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>Searching…</p>
          ) : results.length === 0 ? (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>No matching Mall items.</p>
          ) : results.map(item => (
            <div
              key={item.id}
              onClick={() => { onChange(item); setQuery(item.name); setOpen(false) }}
              style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', cursor: 'pointer' }}
            >
              <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {item.image_url ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Gift size={13} style={{ color: 'var(--text-muted)' }} />}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 12, color: 'var(--text)', margin: 0, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</p>
                <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: 0, textTransform: 'capitalize' }}>{item.category.replace('_', ' ')}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function GameGoalModal({ onClose }: { onClose: () => void }) {
  const [cycles, setCycles] = useState<GameGoalCycle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [rollingOut, setRollingOut] = useState(false)
  const [confirmRollout, setConfirmRollout] = useState(false)
  const [saved, setSaved] = useState(false)

  const [thresholds, setThresholds] = useState<[number, number, number, number]>([15, 30, 45, 60])
  const [xpRewards, setXpRewards] = useState<[number, number, number]>([50, 250, 350])
  const [finalItem, setFinalItem] = useState<GameGoalMallItem | null>(null)
  const [deletingLive, setDeletingLive] = useState(false)
  const [confirmDeleteLive, setConfirmDeleteLive] = useState(false)

  const live = cycles.find(c => c.status === 'live') ?? null
  const draft = cycles.find(c => c.status === 'draft') ?? null
  const history = cycles.filter(c => c.status === 'ended').slice(0, 5)
  const liveExpired = live && (!live.ends_at || new Date(live.ends_at).getTime() <= Date.now())

  function load() {
    setLoading(true)
    setError('')
    fetchGameGoalCycles().then(({ data, error }) => {
      if (error) { setError(error); setLoading(false); return }
      setCycles(data)
      const d = data.find(c => c.status === 'draft')
      if (d) {
        setThresholds(d.thresholds)
        setXpRewards(d.xp_rewards)
        setFinalItem(d.final_item)
      }
      setLoading(false)
    })
  }

  useEffect(() => { load() }, [])

  function setThreshold(i: number, v: number) {
    setThresholds(prev => { const next = [...prev] as typeof prev; next[i] = v; return next })
  }
  function setXp(i: number, v: number) {
    setXpRewards(prev => { const next = [...prev] as typeof prev; next[i] = v; return next })
  }

  async function handleSave() {
    setSaving(true)
    setError('')
    setSaved(false)
    const { error } = await saveGameGoalDraft(thresholds, xpRewards, finalItem?.id ?? null, draft?.id)
    setSaving(false)
    if (error) { setError(error); return }
    setSaved(true)
    load()
  }

  async function handleRollout() {
    if (!draft) return
    setRollingOut(true)
    setError('')
    const { error } = await rolloutGameGoalCycle(draft.id)
    setRollingOut(false)
    setConfirmRollout(false)
    if (error) { setError(error); return }
    load()
  }

  async function handleDeleteLive() {
    if (!live) return
    setDeletingLive(true)
    setError('')
    const { error } = await deleteGameGoalCycle(live.id)
    setDeletingLive(false)
    setConfirmDeleteLive(false)
    if (error) { setError(error); return }
    load()
  }

  return (
    <Modal title="Game Goal Reward Control" onClose={onClose} width={440}>
      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>Loading…</p>
      ) : (
        <>
          <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 8px' }}>Live cycle</p>
          {!live || liveExpired ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 12px', borderRadius: 10, background: 'rgba(255,79,79,0.08)', border: '1px solid rgba(255,79,79,0.25)', marginBottom: 18 }}>
              <AlertTriangle size={13} style={{ color: 'var(--red)', flexShrink: 0 }} />
              <span style={{ fontSize: 11.5, color: 'var(--red)', fontWeight: 600 }}>
                No live cycle — players see "Activity goal is being reset". Roll out the draft below to publish one.
              </span>
            </div>
          ) : (
            <div style={{ padding: 12, borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)' }}>Thresholds {live.thresholds.join(' / ')}</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{timeLeft(live.ends_at)}</span>
              </div>
              <p style={{ fontSize: 11, color: 'var(--text-dim)', margin: '0 0 4px' }}>XP: {live.xp_rewards.join(', ')} · Final: {live.final_item?.name ?? '—'}</p>
              <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '0 0 10px' }}>{live.players_progressed} playing · {live.players_completed} completed</p>
              {!confirmDeleteLive ? (
                <button
                  onClick={(e) => { ripple(e); setConfirmDeleteLive(true) }}
                  style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10.5, fontWeight: 700, padding: '6px 10px', borderRadius: 8, background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--red)', cursor: 'pointer' }}
                >
                  <Trash2 size={11} /> Delete rolled-out cycle
                </button>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>Deletes it for everyone right now — sure?</span>
                  <button onClick={() => setConfirmDeleteLive(false)} disabled={deletingLive} className="btn-secondary" style={{ fontSize: 10.5, padding: '5px 10px', flexShrink: 0 }}>Cancel</button>
                  <button onClick={handleDeleteLive} disabled={deletingLive} className="btn-primary" style={{ fontSize: 10.5, padding: '5px 10px', background: 'var(--red)', flexShrink: 0 }}>
                    {deletingLive ? '…' : 'Delete'}
                  </button>
                </div>
              )}
            </div>
          )}

          <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 8px' }}>Draft (next cycle)</p>

          <p style={fieldLabel}>Games-played thresholds</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 14 }}>
            {thresholds.map((t, i) => (
              <input key={i} type="number" min={1} value={t} onChange={e => setThreshold(i, Number(e.target.value))} style={{ ...inputStyle, padding: '8px 8px', textAlign: 'center' }} />
            ))}
          </div>

          <p style={fieldLabel}>XP rewards (milestones 1–3)</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6, marginBottom: 14 }}>
            {xpRewards.map((x, i) => (
              <div key={i} style={{ position: 'relative' }}>
                <Zap size={11} style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', color: 'var(--gold)' }} />
                <input type="number" min={0} value={x} onChange={e => setXp(i, Number(e.target.value))} style={{ ...inputStyle, padding: '8px 8px 8px 24px', textAlign: 'center' }} />
              </div>
            ))}
          </div>

          <p style={fieldLabel}>Final reward (milestone 4) — Mall item</p>
          <div style={{ marginBottom: 16 }}>
            <MallItemAutosuggest value={finalItem} onChange={setFinalItem} />
          </div>

          {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
          {saved && !error && <p style={{ fontSize: 11.5, color: '#4fd18a', fontWeight: 700, marginBottom: 12 }}>Draft saved.</p>}

          <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
            <button onClick={handleSave} disabled={saving} className="btn-secondary" style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: saving ? 0.6 : 1 }}>
              {saving ? 'Saving…' : 'Save draft'}
            </button>
            {!confirmRollout ? (
              <button
                onClick={() => finalItem && setConfirmRollout(true)}
                disabled={!draft || !finalItem}
                className="btn-primary"
                style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: (draft && finalItem) ? 1 : 0.5 }}
              >
                Roll out
              </button>
            ) : (
              <button onClick={handleRollout} disabled={rollingOut} className="btn-primary" style={{ flex: 1, padding: '10px 0', fontSize: 13, background: 'var(--gold)', opacity: rollingOut ? 0.6 : 1 }}>
                {rollingOut ? 'Rolling out…' : 'Confirm roll out'}
              </button>
            )}
          </div>
          {confirmRollout && (
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '-10px 0 16px' }}>
              This publishes the draft live to every player{live ? ' and ends the current cycle' : ''} immediately.
              {' '}<span onClick={() => setConfirmRollout(false)} style={{ color: 'var(--accent)', cursor: 'pointer', fontWeight: 700 }}>Cancel</span>
            </p>
          )}

          {history.length > 0 && (
            <>
              <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 6px' }}>Past cycles</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {history.map(c => (
                  <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, padding: '6px 8px', borderRadius: 8, background: 'var(--surface2)' }}>
                    <span style={{ color: 'var(--text-dim)' }}>{c.final_item?.name ?? '—'}</span>
                    <span style={{ color: 'var(--text-muted)' }}>{c.players_completed} completed</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </Modal>
  )
}

type ModalKind = 'maintenance-message' | 'error-message' | 'dashboard-greeting' | 'broadcast' | 'announcement' | 'health' | 'game-goal' | { category: string } | null

export default function AdminOpsPanel() {
  const navigate = useNavigate()
  const site = useSiteStatus()
  const dashGreeting = useDashboardGreeting()
  const referralPopup = useReferralPopup()
  const [flags, setFlags] = useState<FeatureFlag[]>([])
  const [flagsLoading, setFlagsLoading] = useState(true)
  const [components, setComponents] = useState<StatusComponent[]>([])
  const [modal, setModal] = useState<ModalKind>(null)
  const [exportBusy, setExportBusy] = useState<'users' | 'transactions' | null>(null)
  const [pageError, setPageError] = useState('')
  // Six groups, matching the mockup's actual Ops console grouping
  // (Availability/Popups/Flags/Rewards/Export/Status) — an earlier pass
  // invented its own 4-group split (Availability/Content/Flags &
  // access/Data) that doesn't match the source design. Clubs and
  // Integrity have no equivalent group in the mockup (they're real
  // features that prototype doesn't cover), so they live under Flags,
  // the closest thematic fit, rather than inventing a 7th group.
  const [opsGroup, setOpsGroup] = useState<'availability' | 'popups' | 'flags' | 'rewards' | 'export' | 'status'>('availability')

  useEffect(() => {
    fetchFeatureFlags().then(({ data }) => { setFlags(data); setFlagsLoading(false) })
    fetchStatusComponents().then(({ data }) => setComponents(data))
  }, [])

  function updateFlag(key: string, enabled: boolean) {
    setFlags(prev => prev.map(f => (f.key === key ? { ...f, enabled } : f)))
  }

  async function runExport(kind: 'users' | 'transactions') {
    setExportBusy(kind)
    setPageError('')
    const { pending, error } = kind === 'users' ? await exportUsersCsv() : await exportTransactionsCsv()
    setExportBusy(null)
    if (error) setPageError(error)
    // Approval only opens the 60-minute window; the download happens on the
    // next tap, once the owner has said yes.
    else if (pending) setPageError(PENDING_MESSAGE)
  }

  const categories = ['game', 'map', 'system']
  const flagsByCategory = (cat: string) => flags.filter(f => f.category === cat)
  const flagSummary = (cat: string) => {
    const cf = flagsByCategory(cat)
    const enabled = cf.filter(f => f.enabled).length
    return `${enabled}/${cf.length} on`
  }

  const maintenanceSub = site.loading
    ? undefined
    : site.status === 'maintenance'
      ? 'Blocking the app for everyone except staff'
      : 'App is live for everyone'
  const errorSub = site.loading
    ? undefined
    : site.status === 'error'
      ? 'Blocking the app for everyone except staff'
      : 'App is live for everyone'

  const flagsOnCount = flags.filter(f => f.enabled).length
  const servicesUpCount = components.filter(c => c.state === 'operational').length
  const appStatusLabel = site.loading ? '—' : site.status === 'live' ? 'Live' : site.status === 'maintenance' ? 'Maintenance' : 'Error'

  return (
    <div>
      <style>{`
        .settings-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 16px;
          overflow: hidden;
          box-shadow: var(--elev-raise-sm);
          margin-bottom: 20px;
        }
        .settings-card > * {
          border-radius: 0 !important;
          box-shadow: none !important;
          margin: 0 !important;
          border: none !important;
          border-bottom: 1px solid var(--border) !important;
        }
        .settings-card > *:last-child { border-bottom: none !important; }
      `}</style>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginBottom: 18 }}>
        <KpiCard icon={Power} label="App status" value={appStatusLabel} tint={site.status === 'live' ? 'var(--green)' : 'var(--red)'} />
        <KpiCard icon={Sliders} label="Flags on" value={flagsLoading ? '—' : `${flagsOnCount}/${flags.length}`} tint="var(--gold)" />
        <KpiCard icon={Radio} label="Services up" value={components.length === 0 ? '—' : `${servicesUpCount}/${components.length}`} tint="var(--green)" />
      </div>

      <SegmentedTabs
        value={opsGroup}
        onChange={setOpsGroup}
        options={[
          { key: 'availability', label: 'Availability' },
          { key: 'popups', label: 'Popups' },
          { key: 'flags', label: 'Flags' },
          { key: 'rewards', label: 'Rewards' },
          { key: 'export', label: 'Export' },
          { key: 'status', label: 'Status' },
        ]}
      />
      {pageError && <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '-10px 0 16px 4px' }}>{pageError}</p>}

      {opsGroup === 'availability' && (
      <>
      <SectionTitle>Availability</SectionTitle>
      <div className="settings-card">
        <ToggleRow
          icon={<Power size={15} />} iconBg="rgba(255,79,79,0.12)" iconColor="var(--red)"
          label="Maintenance mode" sub={maintenanceSub}
          on={site.status === 'maintenance'}
          onToggle={async () => { const err = await site.toggleMaintenance(); if (err) setPageError(err) }}
          disabled={site.loading || !!site.toggling}
        />
        <Row
          icon={<MessageSquare size={15} />} iconBg="rgba(155,109,255,0.12)" iconColor="var(--purple)"
          label="Maintenance message" value={site.loading ? undefined : (site.message.length > 24 ? site.message.slice(0, 24) + '…' : site.message)}
          onClick={(e) => { ripple(e); setModal('maintenance-message') }}
        />
        <ToggleRow
          icon={<AlertTriangle size={15} />} iconBg="rgba(255,79,79,0.12)" iconColor="var(--red)"
          label="Error mode" sub={errorSub}
          on={site.status === 'error'}
          onToggle={async () => { const err = await site.toggleError(); if (err) setPageError(err) }}
          disabled={site.loading || !!site.toggling}
        />
        <Row
          icon={<MessageSquare size={15} />} iconBg="rgba(155,109,255,0.12)" iconColor="var(--purple)"
          label="Error message" value={site.loading ? undefined : (site.errorMessage.length > 24 ? site.errorMessage.slice(0, 24) + '…' : site.errorMessage)}
          onClick={(e) => { ripple(e); setModal('error-message') }}
        />
      </div>
      </>
      )}

      {opsGroup === 'popups' && (
      <>
      <SectionTitle>Dashboard</SectionTitle>
      <div className="settings-card">
        <ToggleRow
          icon={<MessageSquare size={15} />} iconBg="color-mix(in srgb, var(--accent) 12%, transparent)" iconColor="var(--accent)"
          label="Custom greeting"
          sub={dashGreeting.loading ? undefined : (dashGreeting.mode === 'custom' ? 'Pinned for every player' : 'Automatic — rotating by time of day')}
          on={dashGreeting.mode === 'custom'}
          onToggle={async () => {
            const { error, needsMessage } = await dashGreeting.toggle()
            if (needsMessage) { setModal('dashboard-greeting'); return }
            if (error) setPageError(error)
          }}
          disabled={dashGreeting.loading || dashGreeting.toggling}
        />
        <Row
          icon={<Settings2 size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)"
          label="Edit greeting text"
          value={dashGreeting.loading ? undefined : (dashGreeting.line ? (dashGreeting.line.length > 24 ? dashGreeting.line.slice(0, 24) + '…' : dashGreeting.line) : 'Not set')}
          onClick={(e) => { ripple(e); setModal('dashboard-greeting') }}
        />
      </div>

      <SectionTitle>Announcements</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Megaphone size={15} />} iconBg="color-mix(in srgb, var(--accent) 12%, transparent)" iconColor="var(--accent)"
          label="Broadcast notification" sub="Notify every user in-app"
          onClick={(e) => { ripple(e); setModal('broadcast') }}
        />
        <Row
          icon={<Bell size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)"
          label="Popup announcement" sub="Daily popup or What's New, until deleted or expires"
          onClick={(e) => { ripple(e); setModal('announcement') }}
        />
        <ToggleRow
          icon={<GiftIcon size={15} />} iconBg="rgba(62,207,142,0.12)" iconColor="var(--green)"
          label="Refer & earn popup"
          sub={referralPopup.loading
            ? undefined
            : referralPopup.enabled
              ? 'Running every 4h for players who never opened Invite'
              : 'Off — nobody sees this modal'}
          on={referralPopup.enabled}
          onToggle={async () => {
            const error = await referralPopup.toggle()
            if (error) setPageError(error)
          }}
          disabled={referralPopup.loading || referralPopup.toggling}
        />
      </div>
      </>
      )}

      {opsGroup === 'flags' && (
      <>
      <SectionTitle>Feature flags</SectionTitle>
      <div className="settings-card">
        {categories.map(cat => {
          const meta = CATEGORY_META[cat]
          const Icon = meta.icon
          return (
            <Row
              key={cat}
              icon={<Icon size={15} />} iconBg="rgba(79,142,247,0.12)" iconColor="var(--blue)"
              label={meta.label} value={flagsLoading ? undefined : flagSummary(cat)}
              onClick={(e) => { ripple(e); setModal({ category: cat }) }}
            />
          )
        })}
      </div>
      <ClubsOpsSection />
      <SecurityOpsSection />
      </>
      )}

      {opsGroup === 'rewards' && (
      <>
      <SectionTitle>Games Zone</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Target size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)"
          label="Game Goal Reward Control" sub="Activity Goals cycle — thresholds, XP, final reward"
          onClick={(e) => { ripple(e); setModal('game-goal') }}
        />
      </div>

      <SectionTitle>Redeem Codes</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Ticket size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)"
          label="Redeem Code Manager" sub="Generate or write codes, set limits & expiry, review redemptions"
          onClick={(e) => { ripple(e); navigate('/admin/redeem-codes') }}
        />
      </div>
      </>
      )}

      {opsGroup === 'export' && (
      <>
      <SectionTitle>Data export</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Download size={15} />} iconBg="rgba(62,207,142,0.12)" iconColor="var(--green)"
          label={exportBusy === 'users' ? 'Exporting…' : 'Export users'} value="CSV"
          onClick={(e) => { if (!exportBusy) { ripple(e); runExport('users') } }}
        />
        <Row
          icon={<Download size={15} />} iconBg="rgba(62,207,142,0.12)" iconColor="var(--green)"
          label={exportBusy === 'transactions' ? 'Exporting…' : 'Export diamond transactions'} value="CSV"
          onClick={(e) => { if (!exportBusy) { ripple(e); runExport('transactions') } }}
        />
      </div>
      </>
      )}

      {opsGroup === 'status' && (
      <>
      <SectionTitle>System health</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Activity size={15} />} iconBg="rgba(245,197,66,0.12)" iconColor="var(--gold)"
          label="View system health" sub="Client errors, report & ticket backlog"
          onClick={(e) => { ripple(e); setModal('health') }}
        />
      </div>
      <StatusOpsSection />
      </>
      )}

      {modal === 'maintenance-message' && (
        <MaintenanceMessageModal
          message={site.message}
          scheduledFor={site.scheduledFor}
          onClose={() => setModal(null)}
          onSaved={(msg, sched) => { site.setMessage(msg); site.setScheduledFor(sched) }}
        />
      )}
      {modal === 'error-message' && (
        <ErrorMessageModal
          title={site.errorTitle}
          message={site.errorMessage}
          onClose={() => setModal(null)}
          onSaved={(title, msg) => { site.setErrorTitle(title); site.setErrorMessage(msg) }}
        />
      )}
      {modal === 'dashboard-greeting' && (
        <DashboardGreetingModal
          line={dashGreeting.line}
          sub={dashGreeting.sub}
          onClose={() => setModal(null)}
          onSaved={(line, sub) => { dashGreeting.setLine(line); dashGreeting.setSub(sub); dashGreeting.setMode('custom') }}
        />
      )}
      {modal === 'broadcast' && <BroadcastModal onClose={() => setModal(null)} />}
      {modal === 'announcement' && <AnnouncementModal onClose={() => setModal(null)} />}
      {modal === 'health' && <SystemHealthModal onClose={() => setModal(null)} />}
      {modal === 'game-goal' && <GameGoalModal onClose={() => setModal(null)} />}
      {modal && typeof modal === 'object' && (
        <FlagCategoryModal
          category={modal.category}
          flags={flagsByCategory(modal.category)}
          onClose={() => setModal(null)}
          onChange={updateFlag}
        />
      )}
    </div>
  )
}
