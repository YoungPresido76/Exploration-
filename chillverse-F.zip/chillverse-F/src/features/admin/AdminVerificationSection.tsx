// src/features/admin/AdminVerificationSection.tsx
//
// The review queue for verified-badge applications (migration 0182b).
// Lives in the Support desk wing next to reports and tickets, since it's
// the same job: a human looking at an account and making a call.
//
// The numbers shown are the ones the thresholds are about — a farmed
// account tends to have followers and nothing else, so "days played"
// sitting at 10 while followers sit at 15 is the tell.
import { useCallback, useEffect, useState } from 'react'
import { BadgeCheck, Check, X, Loader2 } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import Toast, { useToast } from '../../shared/components/Toast'
import {
  fetchVerificationApplications, decideVerification,
  type VerificationApplication,
} from '../verification/verification'

export default function AdminVerificationSection() {
  const [apps, setApps] = useState<VerificationApplication[]>([])
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [noteFor, setNoteFor] = useState<string | null>(null)
  const [note, setNote] = useState('')
  const { toast, showToast } = useToast()

  const load = useCallback(() => {
    setLoading(true)
    fetchVerificationApplications('pending').then(rows => {
      setApps(rows)
      setLoading(false)
    })
  }, [])

  useEffect(() => { load() }, [load])

  async function decide(app: VerificationApplication, approve: boolean) {
    setBusyId(app.id)
    const { error } = await decideVerification(app.id, approve, approve ? '' : note)
    setBusyId(null)
    if (error) {
      showToast({ message: error, icon: X, iconColor: '#ff6b6b' })
      return
    }
    setApps(list => list.filter(a => a.id !== app.id))
    setNoteFor(null)
    setNote('')
    showToast({
      message: approve ? `@${app.username} verified` : 'Application rejected',
      icon: approve ? BadgeCheck : X,
      iconColor: approve ? 'var(--blue)' : 'var(--text-dim)',
    })
  }

  if (loading) {
    return (
      <div style={{ padding: 16, display: 'flex', justifyContent: 'center', color: 'var(--text-dim)' }}>
        <Loader2 size={16} className="spin" />
      </div>
    )
  }

  if (apps.length === 0) return null

  return (
    <>
      <p style={{ fontSize: 11, fontWeight: 800, color: 'var(--text-dim)', letterSpacing: 0.4, margin: '18px 0 8px' }}>
        VERIFICATION · {apps.length} WAITING
      </p>

      {apps.map(app => (
        <div key={app.id} className="neu-card" style={{ padding: 14, marginBottom: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar src={app.avatar} name={app.display_name || app.username} userId={app.user_id} size={34} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {app.display_name || app.username}
              </p>
              <p style={{ fontSize: 11.5, color: 'var(--text-dim)' }}>@{app.username}</p>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 14, marginTop: 10, fontSize: 11.5, color: 'var(--text-dim)' }}>
            <span><strong style={{ color: 'var(--text)' }}>{app.followers}</strong> followers</span>
            <span><strong style={{ color: 'var(--text)' }}>{app.account_age_days}</strong> days old</span>
            <span><strong style={{ color: 'var(--text)' }}>{app.active_days}</strong> days played</span>
          </div>

          {app.reason && (
            <p style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 10, lineHeight: 1.5, fontStyle: 'italic' }}>
              “{app.reason}”
            </p>
          )}

          {noteFor === app.id && (
            <textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Why not? They'll see this. Required to reject."
              maxLength={200}
              rows={2}
              style={{
                width: '100%', marginTop: 10, background: 'var(--surface2)', border: 'none',
                borderRadius: 10, padding: 10, fontSize: 12.5, color: 'var(--text)',
                outline: 'none', resize: 'none', fontFamily: 'inherit',
              }}
            />
          )}

          <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
            <button
              type="button"
              disabled={busyId === app.id}
              onClick={() => decide(app, true)}
              style={{
                flex: 1, padding: '9px 0', borderRadius: 10, border: 'none', background: 'var(--blue)',
                color: '#fff', fontSize: 12.5, fontWeight: 800, fontFamily: 'inherit', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}
            >
              <Check size={14} /> Verify
            </button>
            <button
              type="button"
              disabled={busyId === app.id || (noteFor === app.id && note.trim().length === 0)}
              onClick={() => (noteFor === app.id ? decide(app, false) : (setNoteFor(app.id), setNote('')))}
              style={{
                flex: 1, padding: '9px 0', borderRadius: 10, border: '1px solid var(--border)',
                background: 'transparent',
                color: (noteFor === app.id && note.trim().length === 0) ? 'var(--surface3)' : 'var(--text-dim)',
                fontSize: 12.5, fontWeight: 800,
                fontFamily: 'inherit',
                cursor: (noteFor === app.id && note.trim().length === 0) ? 'default' : 'pointer',
              }}
            >
              {noteFor === app.id ? 'Confirm reject' : 'Reject'}
            </button>
          </div>
        </div>
      ))}

      <Toast toast={toast} />
    </>
  )
}
