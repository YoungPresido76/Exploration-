// src/features/admin/ClubsOpsSection.tsx
//
// "Who made a club that's still standing." Rendered inside AdminOpsPanel.tsx
// alongside the other ops sub-sections.
//
// Archived and deleted clubs never appear — admin_club_owners filters them
// server-side — so every row here is a live club with a real owner. The
// creator isn't necessarily the current president: they can hand a club over
// and walk away, so the row says so rather than implying they still run it.
//
// Tapping a row opens the creator in the existing admin user drilldown.

import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Users2, RefreshCw } from 'lucide-react'
import { SectionTitle } from '../settings/settingsShared'
import { Modal } from './adminModal'
import { fetchClubOwners, type ClubOwnerRow } from './adminOps'

function relativeDate(iso: string | null): string {
  if (!iso) return 'never'
  const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000)
  if (days <= 0) return 'today'
  if (days === 1) return 'yesterday'
  if (days < 30) return `${days}d ago`
  if (days < 365) return `${Math.floor(days / 30)}mo ago`
  return `${Math.floor(days / 365)}y ago`
}

export default function ClubsOpsSection() {
  const [open, setOpen] = useState(false)

  return (
    <>
      <SectionTitle>Clubs</SectionTitle>
      <div className="settings-card">
        <div
          onClick={() => setOpen(true)}
          className="ripple-wrap"
          style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, marginBottom: 9, cursor: 'pointer', boxShadow: 'var(--elev-raise-sm)' }}
        >
          <div style={{ width: 30, height: 30, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(79,142,247,0.12)', color: '#4f8ef7', flexShrink: 0 }}>
            <Users2 size={15} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--text)' }}>Club owners</div>
            <div style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 2 }}>
              Who created a club that's still standing
            </div>
          </div>
        </div>
      </div>

      {open && <ClubOwnersModal onClose={() => setOpen(false)} />}
    </>
  )
}

function ClubOwnersModal({ onClose }: { onClose: () => void }) {
  const navigate = useNavigate()
  const [rows, setRows] = useState<ClubOwnerRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    const { data, error } = await fetchClubOwners()
    setRows(data)
    setError(error)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  return (
    <Modal title="Club owners" onClose={onClose} width={460}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <span style={{ fontSize: 11.5, color: 'var(--text-dim)', flex: 1 }}>
          {loading ? 'Loading…' : `${rows.length} standing club${rows.length === 1 ? '' : 's'}`}
        </span>
        <button
          onClick={load}
          disabled={loading}
          aria-label="Refresh"
          style={{ width: 28, height: 28, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: loading ? 'not-allowed' : 'pointer' }}
        >
          <RefreshCw size={13} />
        </button>
      </div>

      {error && <p style={{ fontSize: 12, color: 'var(--red)', marginBottom: 10 }}>{error}</p>}

      {!loading && !error && rows.length === 0 && (
        <p style={{ fontSize: 12.5, color: 'var(--text-dim)', textAlign: 'center', padding: '20px 0' }}>
          No clubs are currently standing.
        </p>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {rows.map(row => (
          <div
            key={row.room_id}
            onClick={() => { if (row.creator_id) navigate(`/admin/users/${row.creator_id}`) }}
            style={{
              padding: '11px 13px', background: 'var(--surface)', border: '1px solid var(--border)',
              borderRadius: 14, cursor: row.creator_id ? 'pointer' : 'default',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {row.club_name}
              </span>
              <span style={{ fontSize: 11, color: 'var(--text-dim)', flexShrink: 0 }}>
                {row.member_count} member{row.member_count === 1 ? '' : 's'}
              </span>
            </div>

            <div style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 4 }}>
              by{' '}
              <span style={{ color: 'var(--text)', fontWeight: 600 }}>
                {row.creator_display_name || row.creator_username || 'deleted account'}
              </span>
              {!row.still_president && (
                <span style={{ color: 'var(--gold)' }}> · handed over</span>
              )}
            </div>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', fontSize: 10.5, color: 'var(--text-muted)', marginTop: 5 }}>
              <span>{row.channel_count} channel{row.channel_count === 1 ? '' : 's'}</span>
              <span>{row.join_mode ?? 'invite'}</span>
              <span>made {relativeDate(row.created_at)}</span>
              <span>last msg {relativeDate(row.last_message_at)}</span>
            </div>
          </div>
        ))}
      </div>
    </Modal>
  )
}
