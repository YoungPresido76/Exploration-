// src/features/admin/AdminEliminationSection.tsx
//
// The elimination-weekend survivor payout, in the Arena wing.
//
// Owner-only, and in the strictest sense the app has: not the moderator, not
// staff, not another admin. It renders for nobody else — and the guard that
// actually matters is server-side, in admin_set_elimination_reward, which
// checks is_owner() and refuses everyone else regardless of what the client
// chose to draw (migration 0161a).
//
// Deliberately NOT wired into the admin_requests approval queue. That queue
// exists so an admin can ask the owner to do something on their behalf; a
// dial only the owner may touch has nothing to queue.
//
// The number is read back off pvp_elimination_status rather than through its
// own admin RPC, because that is the same call the Arena board makes — so
// what the owner sees here is literally what players are being promised, and
// pvp_elimination_close reads the same config row at payout time.
import { useEffect, useState } from 'react'
import { Image as ImageIcon, Ticket, Users } from 'lucide-react'
import { SectionTitle } from '../settings/settingsShared'
import { setEliminationBanner, setEliminationReward } from './adminOps'
import { getEliminationStatus } from '../pvp/pvp'
import { refreshElimination } from '../pvp/useElimination'
import { useIsOwner } from './adminRequests'

const MAX_REWARD = 1000
const ALIVE = '#3ecf8e'

export default function AdminEliminationSection() {
  const { isOwner, loading: ownerLoading } = useIsOwner()
  const [current, setCurrent] = useState<number | null>(null)
  const [value, setValue] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState<string | null>(null)

  const [bannerCurrent, setBannerCurrent] = useState<string>('')
  const [banner, setBanner] = useState('')
  const [bannerBusy, setBannerBusy] = useState(false)
  const [bannerError, setBannerError] = useState<string | null>(null)
  const [bannerDone, setBannerDone] = useState<string | null>(null)
  const [registered, setRegistered] = useState<number | null>(null)

  useEffect(() => {
    if (!isOwner) return
    let alive = true
    getEliminationStatus()
      .then(s => {
        if (!alive || !s) return
        setCurrent(s.survivor_reward)
        setValue(String(s.survivor_reward))
        setBannerCurrent(s.banner_url ?? '')
        setBanner(s.banner_url ?? '')
        setRegistered(s.registered_count)
      })
      .catch(() => { /* the card still works; the field just starts empty */ })
    return () => { alive = false }
  }, [isOwner])

  if (ownerLoading || !isOwner) return null

  const num = Number(value)
  const valid = value.trim() !== '' && Number.isInteger(num) && num >= 0 && num <= MAX_REWARD
  const changed = valid && num !== current

  async function save() {
    if (!changed || busy) return
    setBusy(true); setError(null); setDone(null)
    const { error: err } = await setEliminationReward(num)
    if (err) {
      setError(err)
    } else {
      setCurrent(num)
      setDone(`Survivors now take ${num} Voucher${num === 1 ? '' : 's'}.`)
      // The Arena board reads this off the same status call, so drop the
      // cached copy rather than leaving the old promise on screen.
      refreshElimination()
    }
    setBusy(false)
  }

  async function saveBanner() {
    if (bannerBusy) return
    setBannerBusy(true); setBannerError(null); setBannerDone(null)
    const url = banner.trim()
    const { error: err } = await setEliminationBanner(url)
    if (err) {
      setBannerError(err)
    } else {
      setBannerCurrent(url)
      setBannerDone(url === '' ? 'Banner cleared.' : 'Banner updated.')
      refreshElimination()
    }
    setBannerBusy(false)
  }

  return (
    <>
      <SectionTitle>Elimination weekend</SectionTitle>

      <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
          <span style={{
            width: 30, height: 30, borderRadius: 10, flexShrink: 0,
            display: 'grid', placeItems: 'center',
            background: `${ALIVE}1f`, border: `1px solid ${ALIVE}44`,
          }}>
            <Ticket size={15} color={ALIVE} />
          </span>
          <div style={{ minWidth: 0 }}>
            <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
              Survivor reward
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0' }}>
              Owner only — admins and staff can't change this
            </p>
          </div>
        </div>

        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.55 }}>
          Vouchers paid to everyone still standing when the round closes on Monday.
          Flat, and the same for a survivor who never threw a punch. A change takes
          effect from the next close — a round that has already paid out isn't
          re-paid.
        </p>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="number"
            inputMode="numeric"
            min={0}
            max={MAX_REWARD}
            value={value}
            onChange={e => { setValue(e.target.value); setDone(null); setError(null) }}
            style={{
              flex: 1, minWidth: 0, padding: '10px 12px', borderRadius: 12,
              background: 'var(--surface2)', border: '1px solid var(--border)',
              outline: 'none', fontFamily: 'inherit', fontSize: 13.5,
              fontWeight: 700, color: 'var(--text)',
            }}
          />
          <button
            type="button"
            disabled={!changed || busy}
            onClick={save}
            style={{
              flexShrink: 0, padding: '10px 18px', borderRadius: 12, border: 'none',
              fontFamily: 'inherit', fontSize: 13, fontWeight: 800,
              cursor: !changed || busy ? 'not-allowed' : 'pointer',
              color: !changed || busy ? 'var(--text-muted)' : '#0d0d10',
              background: !changed || busy ? 'var(--surface3)' : ALIVE,
            }}
          >
            {busy ? 'Saving…' : 'Save'}
          </button>
        </div>

        {value.trim() !== '' && !valid && (
          <p style={{ fontSize: 11.5, color: '#ff8095', margin: '9px 0 0' }}>
            Whole number between 0 and {MAX_REWARD}.
          </p>
        )}
        {error && <p style={{ fontSize: 11.5, color: '#ff8095', margin: '9px 0 0' }}>{error}</p>}
        {done && <p style={{ fontSize: 11.5, color: ALIVE, margin: '9px 0 0' }}>{done}</p>}
      </div>

      {/* ── Banner ─────────────────────────────────────────────────── */}
      <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
          <span style={{
            width: 30, height: 30, borderRadius: 10, flexShrink: 0,
            display: 'grid', placeItems: 'center',
            background: 'rgba(255,77,109,0.12)', border: '1px solid rgba(255,77,109,0.3)',
          }}>
            <ImageIcon size={15} color="#ff4d6d" />
          </span>
          <div style={{ minWidth: 0 }}>
            <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
              Registration banner
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0' }}>
              Owner only — changeable at any time
            </p>
          </div>
        </div>

        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.55 }}>
          Sits at the top of the sign-up sheet. Paste a public Supabase storage URL.
          Leave it empty and the sheet uses a flat treatment instead — that's a
          deliberate state, not a broken one, so there's no placeholder to worry about.
        </p>

        {banner.trim() !== '' && (
          <div style={{
            height: 92, borderRadius: 12, marginBottom: 10,
            border: '1px solid var(--border)',
            background: `center/cover no-repeat url(${banner.trim()})`,
          }} />
        )}

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="url"
            inputMode="url"
            placeholder="https://…/Adverts/…/Elimination.png"
            value={banner}
            onChange={e => { setBanner(e.target.value); setBannerDone(null); setBannerError(null) }}
            style={{
              flex: 1, minWidth: 0, padding: '10px 12px', borderRadius: 12,
              background: 'var(--surface2)', border: '1px solid var(--border)',
              outline: 'none', fontFamily: 'inherit', fontSize: 12,
              color: 'var(--text)',
            }}
          />
          <button
            type="button"
            disabled={bannerBusy || banner.trim() === bannerCurrent.trim()}
            onClick={saveBanner}
            style={{
              flexShrink: 0, padding: '10px 18px', borderRadius: 12, border: 'none',
              fontFamily: 'inherit', fontSize: 13, fontWeight: 800,
              cursor: bannerBusy || banner.trim() === bannerCurrent.trim() ? 'not-allowed' : 'pointer',
              color: bannerBusy || banner.trim() === bannerCurrent.trim() ? 'var(--text-muted)' : '#0d0d10',
              background: bannerBusy || banner.trim() === bannerCurrent.trim() ? 'var(--surface3)' : ALIVE,
            }}
          >
            {bannerBusy ? 'Saving…' : 'Save'}
          </button>
        </div>

        {bannerError && <p style={{ fontSize: 11.5, color: '#ff8095', margin: '9px 0 0' }}>{bannerError}</p>}
        {bannerDone && <p style={{ fontSize: 11.5, color: ALIVE, margin: '9px 0 0' }}>{bannerDone}</p>}

        {registered !== null && (
          <p style={{
            display: 'flex', alignItems: 'center', gap: 6,
            fontSize: 11.5, color: 'var(--text-muted)', margin: '12px 0 0',
          }}>
            <Users size={12} /> {registered} registered for the upcoming round
          </p>
        )}
      </div>
    </>
  )
}
