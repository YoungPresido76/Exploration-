// src/features/admin/adminRequests.ts
//
// Client wrapper for the owner-approval queue (migrations 0160a-0160c).
//
// Sensitive admin RPCs (gifting diamonds, redeem codes, bounties, role
// changes, exports, site status, broadcasts, item pricing) no longer act
// immediately for ordinary admins — they park a row in admin_requests and
// return { status: 'pending' }. The platform owner approves or rejects it
// from the Approvals wing, and only then does the real work run.
//
// Everything here is server-enforced: is_owner() is checked inside every
// RPC, so hiding a button is a courtesy, never the control.
import { useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'

export type AdminRequestKind =
  | 'grant_diamonds' | 'create_redeem_code' | 'set_redeem_code_active' | 'delete_redeem_code'
  | 'place_bounty' | 'set_role' | 'export_users' | 'export_transactions'
  | 'set_site_status' | 'set_maintenance' | 'send_broadcast' | 'broadcast_notification'
  | 'set_mall_item_price'

export type AdminRequestStatus =
  | 'pending' | 'approved' | 'rejected' | 'expired' | 'failed' | 'cancelled' | 'consumed'

export interface AdminRequest {
  id: string
  kind: AdminRequestKind
  /** Human sentence built server-side, e.g. "gift 500 diamonds to @Lucifer". */
  summary: string
  reason: string | null
  payload: Record<string, unknown>
  status: AdminRequestStatus
  created_at: string
  expires_at: string
  reviewed_at: string | null
  review_note: string | null
  result: Record<string, unknown> | null
  error: string | null
  requested_by: string
  requester_username: string
  requester_display_name: string | null
  requester_avatar: string | null
  reviewer_username: string | null
}

/** Shape every guarded admin RPC now returns. 'applied' means it ran (you're
 *  the owner); 'pending' means it was queued for approval instead. */
export interface AdminActionOutcome {
  status?: 'applied' | 'pending'
  request_id?: string
  summary?: string
}

/** True when an RPC result means "queued, not done". Call sites use this to
 *  swap their success toast for a "sent for approval" one. */
export function isPending(result: unknown): result is AdminActionOutcome {
  return !!result && typeof result === 'object' && !Array.isArray(result)
    && (result as AdminActionOutcome).status === 'pending'
}

export const PENDING_MESSAGE = 'Sent to the owner for approval — it goes live once approved.'

function friendlyRequestError(message: string): string {
  if (message.includes('CV_OWNER_ONLY')) return 'Only the platform owner can do that.'
  if (message.includes('CV_REQUEST_NOT_FOUND')) return 'That request no longer exists.'
  if (message.includes('CV_REQUEST_NOT_PENDING')) return 'That request has already been reviewed.'
  if (message.includes('CV_REQUEST_EXPIRED')) return 'That request expired before it was reviewed.'
  if (message.includes('CV_ADMIN_FORBIDDEN')) return "You don't have permission to do that."
  return message
}

export async function fetchAdminRequests(
  scope: 'pending' | 'reviewed' | 'all' = 'pending',
): Promise<{ rows: AdminRequest[]; isOwner: boolean; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_list_requests', { p_scope: scope, p_limit: 100 })
  if (error) return { rows: [], isOwner: false, error: friendlyRequestError(error.message) }
  const payload = data as { rows: AdminRequest[]; is_owner: boolean } | null
  return { rows: payload?.rows ?? [], isOwner: payload?.is_owner ?? false, error: null }
}

export async function approveAdminRequest(id: string, note?: string): Promise<{ error: string | null; failed?: string }> {
  const { data, error } = await supabase.rpc('admin_approve_request', { p_id: id, p_note: note ?? null })
  if (error) return { error: friendlyRequestError(error.message) }
  const outcome = data as { status?: string; error?: string } | null
  // The action was approved but blew up while running (a deleted item, a
  // code that now clashes…). The row is marked 'failed' server-side.
  if (outcome?.status === 'failed') return { error: null, failed: outcome.error ?? 'The action could not be carried out.' }
  return { error: null }
}

export async function rejectAdminRequest(id: string, note?: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_reject_request', { p_id: id, p_note: note ?? null })
  return { error: error ? friendlyRequestError(error.message) : null }
}

export async function cancelAdminRequest(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_cancel_request', { p_id: id })
  return { error: error ? friendlyRequestError(error.message) : null }
}

/** Am I the platform owner? Backed by am_i_owner() (SECURITY DEFINER over
 *  platform_owners, which is RLS-closed to everyone). Defaults to false
 *  while loading, so nothing owner-only ever flashes on screen first. */
export function useIsOwner(): { isOwner: boolean; loading: boolean } {
  const [isOwner, setIsOwner] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    supabase.rpc('am_i_owner').then(({ data }) => {
      if (active) { setIsOwner(data === true); setLoading(false) }
    })
    return () => { active = false }
  }, [])

  return { isOwner, loading }
}

/** Pending-approval count for the Concourse tile. Returns 0 for anyone who
 *  isn't the owner — the RPC itself decides, not the caller. */
export function usePendingRequestCount(): { count: number; refresh: () => void } {
  const [count, setCount] = useState(0)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    let active = true
    supabase.rpc('admin_pending_request_count').then(({ data }) => {
      if (active) setCount(Number(data) || 0)
    })
    return () => { active = false }
  }, [tick])

  return { count, refresh: () => setTick(t => t + 1) }
}
