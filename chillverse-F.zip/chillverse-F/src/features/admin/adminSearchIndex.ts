// src/features/admin/adminSearchIndex.ts
//
// The searchable index behind AdminActionSearch — the Concourse's
// "search every wing & action" overlay (ports the mockup's
// allSearchables() model). Unlike the mockup, the real wings aren't built
// from a declarative { sections: [{ items }] } data structure — they're
// React components with hardcoded JSX — so there's no runtime list to walk.
// This file is the equivalent hand-maintained index: one entry per real,
// currently-reachable action or section, transcribed from the actual Row/
// SectionTitle labels in AdminWingScreen.tsx, AdminStoreSection.tsx,
// AdminCollabSection.tsx, AdminOpsPanel.tsx, ClubsOpsSection.tsx,
// SecurityOpsSection.tsx, StatusOpsSection.tsx, and AdminBroadcastSection.tsx.
//
// Scope note: a result jumps to the right WING, same as the Concourse's
// existing quick actions (e.g. "Declare incident" → onSelectSection('ops')).
// It does not also deep-link into a specific segmented-tab group or open a
// modal — EconomyWing's Store/Sales/Diamonds tab and AdminOpsPanel's
// Availability/Content/Flags/Data tab are local state to those components.
// Wiring a deep link through would mean threading an "initial tab" prop
// across AdminDashboard → AdminWingScreen → EconomyWing/AdminOpsPanel,
// which is a real (if small) API change to components outside this file —
// flagging it rather than making that call silently. Landing on the wing
// gets an admin within one more tap of anything in this index.
import type { AdminSection } from './adminSections'

export interface AdminSearchEntry {
  wing: AdminSection
  title: string
  sub: string
}

export const ADMIN_SEARCH_INDEX: AdminSearchEntry[] = [
  // ── Atrium ──────────────────────────────────────────────────────────
  { wing: 'overview', title: 'All users', sub: 'Browse, filter, and search the full roster' },
  { wing: 'overview', title: 'Find a user', sub: 'Look up by name, handle, or ID' },
  { wing: 'overview', title: 'Pro subscribers', sub: 'Everyone on a paid tier' },
  { wing: 'overview', title: 'Staff members', sub: 'Admins and moderators' },
  { wing: 'overview', title: 'Banned users', sub: 'Suspended and banned accounts' },

  // ── Mall economy ────────────────────────────────────────────────────
  { wing: 'economy', title: 'Mall Bundles', sub: 'Artwork, price and contents — and which one is pinned' },
  { wing: 'economy', title: 'Create or edit item', sub: 'Name, art, category, rarity, description, price' },
  { wing: 'economy', title: 'Item price, lock & timer', sub: 'Reprice any item, lock it with a message, or put it on a countdown' },
  { wing: 'economy', title: 'Flash Sale Schedule', sub: 'Weekly Special + Monthly Mega Sale — items, discounts, timing, image' },
  { wing: 'economy', title: 'Gift diamonds', sub: 'Search a user, credit their balance, log why' },
  { wing: 'economy', title: 'Top Mall items', sub: 'Ranked by owners' },

  // ── Collabs ─────────────────────────────────────────────────────────
  { wing: 'collabs', title: 'New collab', sub: 'Name, artwork, dates, and which Mall items are tagged to it' },
  { wing: 'collabs', title: 'Manage collabs', sub: 'Edit, publish, or delete an existing collab' },

  // ── Arcade ──────────────────────────────────────────────────────────
  { wing: 'games', title: 'Most played (30d)', sub: 'Sessions ranked by game' },

  // ── Arena ───────────────────────────────────────────────────────────
  { wing: 'multiplayer', title: 'Rooms by game (30d)', sub: 'Active and created multiplayer rooms' },

  // ── Halo AI ─────────────────────────────────────────────────────────
  { wing: 'halo', title: 'Provider split (30d)', sub: 'Which AI provider is answering questions' },

  // ── Support desk ────────────────────────────────────────────────────
  { wing: 'operations', title: 'Currently banned', sub: 'Users banned right now' },
  { wing: 'operations', title: 'Open reports', sub: 'Unresolved content reports' },
  { wing: 'operations', title: 'Open tickets', sub: 'Unresolved support tickets' },

  // ── Ops console — Availability ─────────────────────────────────────
  { wing: 'ops', title: 'Maintenance mode', sub: 'Blocks the app for everyone except staff' },
  { wing: 'ops', title: 'Maintenance message', sub: 'What players see while maintenance mode is on' },
  { wing: 'ops', title: 'Error mode', sub: 'Blocks the app for everyone except staff' },
  { wing: 'ops', title: 'Error message', sub: 'What players see while error mode is on' },
  { wing: 'ops', title: 'View system health', sub: 'Client errors, report & ticket backlog' },
  { wing: 'ops', title: 'Declare incident', sub: 'Posts to chillverse.com.ng/status with a live timeline' },
  { wing: 'ops', title: 'Status page components', sub: 'Set a service to operational, degraded, or outage' },

  // ── Ops console — Content ──────────────────────────────────────────
  { wing: 'ops', title: 'Custom greeting', sub: 'Pin one dashboard greeting for every player' },
  { wing: 'ops', title: 'Broadcast notification', sub: 'Notify every user in-app' },
  { wing: 'ops', title: 'Popup announcement', sub: "Daily popup or What's New, until deleted or expires" },
  { wing: 'multiplayer', title: 'Bounties', sub: 'Place a wanted poster on a player, paid to whoever takes them down' },
  { wing: 'ops', title: 'Refer & earn popup', sub: 'Toggle the invite-nudge modal on or off' },
  { wing: 'ops', title: 'Game Goal Reward Control', sub: 'Activity Goals cycle — thresholds, XP, final reward' },
  { wing: 'ops', title: 'Redeem Code Manager', sub: 'Generate or write codes, set limits & expiry, review redemptions' },

  // ── Ops console — Flags & access ───────────────────────────────────
  { wing: 'ops', title: 'Feature flags', sub: 'Game, map, and system flags — on/off per category' },
  { wing: 'ops', title: 'Clubs', sub: 'Every live club and its current owner' },
  { wing: 'ops', title: 'Integrity', sub: 'Economy invariant scans — violated states, not blocked attempts' },

  // ── Ops console — Data ──────────────────────────────────────────────
  { wing: 'ops', title: 'Export users', sub: 'CSV' },
  { wing: 'ops', title: 'Export diamond transactions', sub: 'CSV' },

  // ── Broadcasts ──────────────────────────────────────────────────────
  { wing: 'broadcasts', title: 'Compose broadcast', sub: 'Message every player or a chosen few, straight to their DMs' },
]
