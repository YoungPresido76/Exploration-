// src/features/admin/AdminActionSearch.tsx
//
// The Concourse's "search every wing & action" overlay — ports the mockup's
// search-everything panel (search()/allSearchables() in the standalone
// prototype) onto real, indexed content (ADMIN_SEARCH_INDEX). Distinct from
// AdminUserSearch, which searches *users*; this searches the admin surface
// itself — every action/section a wing exposes — and jumps you to the wing
// that has it. See adminSearchIndex.ts for what a result can and can't do
// (jumps to the wing; doesn't also deep-link a sub-tab or open a modal).
import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, Search, ChevronRight } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { ADMIN_SECTIONS, type AdminSection } from './adminSections'
import { ADMIN_SEARCH_INDEX } from './adminSearchIndex'

const SECTION_BY_KEY = new Map(ADMIN_SECTIONS.map(s => [s.key, s]))

export default function AdminActionSearch({
  onSelect, onClose,
}: {
  onSelect: (wing: AdminSection) => void
  onClose: () => void
}) {
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [onClose])

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase()
    const matches = ADMIN_SEARCH_INDEX.filter(entry => {
      if (!q) return true
      const wingLabel = SECTION_BY_KEY.get(entry.wing)?.label ?? ''
      return (
        entry.title.toLowerCase().includes(q)
        || entry.sub.toLowerCase().includes(q)
        || wingLabel.toLowerCase().includes(q)
      )
    })
    const byWing = new Map<AdminSection, typeof matches>()
    for (const entry of matches) {
      const list = byWing.get(entry.wing) ?? []
      list.push(entry)
      byWing.set(entry.wing, list)
    }
    // Preserve the Concourse's own wing order rather than first-match order.
    return ADMIN_SECTIONS
      .map(section => ({ section, entries: byWing.get(section.key) ?? [] }))
      .filter(group => group.entries.length > 0)
  }, [query])

  const totalMatches = grouped.reduce((sum, g) => sum + g.entries.length, 0)

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 300, background: 'var(--bg)',
        display: 'flex', flexDirection: 'column',
      }}
    >
      <div style={{ padding: '16px 16px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={(e) => { ripple(e); onClose() }}
            aria-label="Close search"
            style={{
              width: 36, height: 36, borderRadius: 11, flexShrink: 0, background: 'var(--surface)',
              border: '1px solid var(--border)', color: 'var(--text-dim)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
            }}
          >
            <ArrowLeft size={16} />
          </button>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search every wing & action…"
              style={{
                width: '100%', background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 11,
                padding: '10px 12px 10px 34px', fontSize: 13, color: 'var(--text)', outline: 'none',
              }}
              onFocus={e => { e.currentTarget.style.borderColor = 'color-mix(in srgb, var(--accent) 45%, transparent)' }}
              onBlur={e => { e.currentTarget.style.borderColor = 'var(--border)' }}
            />
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', WebkitOverflowScrolling: 'touch', padding: '14px 16px 40px' }}>
        {totalMatches === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px 16px', color: 'var(--text-muted)' }}>
            <Search size={24} style={{ marginBottom: 8, opacity: 0.6 }} />
            <p style={{ fontSize: 12.5, margin: 0 }}>No matches for "{query}"</p>
          </div>
        ) : (
          grouped.map(({ section, entries }) => (
            <div key={section.key} style={{ marginBottom: 18 }}>
              <p style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 8px' }}>
                {section.label}
              </p>
              <div className="neu-card" style={{ padding: 4 }}>
                {entries.map((entry, i) => (
                  <button
                    key={`${entry.wing}-${entry.title}`}
                    type="button"
                    onClick={(e) => { ripple(e); onClose(); onSelect(entry.wing) }}
                    className="ripple-wrap"
                    style={{
                      width: '100%', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left', cursor: 'pointer',
                      padding: '10px 8px', borderRadius: 10, background: 'transparent', border: 'none',
                      borderTop: i === 0 ? undefined : '1px solid var(--border)',
                    }}
                  >
                    <span style={{
                      width: 28, height: 28, borderRadius: 9, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: `${section.tint}22`, color: section.tint,
                    }}>
                      <section.icon size={14} />
                    </span>
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>{entry.title}</span>
                      <span style={{ display: 'block', fontSize: 11, color: 'var(--text-dim)', marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{entry.sub}</span>
                    </span>
                    <ChevronRight size={14} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
                  </button>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
