// src/features/admin/AdminFortuneVaultSection.tsx
//
// Fortune Vault ops, in the Arcade wing beside the games KPIs.
//
// Build-as-draft then roll out, mirroring AdminFlashSalePage's flow — a board
// is never half-published, and the eight slots are validated server-side
// before rollout will touch it.
//
// Everything here is a courtesy layer. The real guard is is_admin_role() inside
// admin_save_fortune_vault_draft / _rollout / _end / _delete, which refuses
// regardless of what this screen chose to draw.
import { useEffect, useRef, useState } from 'react'
import { Search, Gift, Sparkles, Trash2, Rocket, Square, ImagePlus, X, Check, Pencil } from 'lucide-react'
import { SectionTitle } from '../settings/settingsShared'
import { fieldLabel, inputStyle } from './adminModal'
import { ripple } from '../../shared/lib/ripple'
import { useModRole } from '../moderation/useModRole'
import {
  fetchAdminVaults, saveVaultDraft, rolloutVault, endVault, deleteVaultDraft,
  uploadVaultImage, searchVaultItems, setVaultPresentation, VAULT_FALLBACK, CURRENCY_LABEL,
  type AdminVault, type AdminVaultPrize, type PrizeKind, type VaultMallItem,
  type VaultCurrency, type VaultMode, type VaultOnClear,
} from '../fortune/fortuneVault'

const ACCENT = '#f5c542'

/** Mirrors fortune_cosmetic_categories() in 0172a. Display only — the server
 *  is still the one that decides what leaves a player's pool. */
const COSMETIC_CATEGORIES = ['avatar_skin', 'profile_pic', 'banner', 'profile_effect', 'chat_theme']

const miniLabel: React.CSSProperties = {
  fontSize: 9.5, fontWeight: 700, color: 'var(--text-muted)',
  letterSpacing: 0.2, textTransform: 'uppercase', display: 'block',
}

/** A fresh board: six repeatable prizes and two cosmetic slots to fill in.
 *  Currency/XP by default so the very first save can't trip the "a repeating
 *  board needs something winnable twice" rule before the admin has picked
 *  a single item. */
function blankPrizes(): AdminVaultPrize[] {
  return Array.from({ length: 8 }, (_, slot) => ({
    slot,
    kind: 'currency' as PrizeKind,
    item_id: null,
    currency: 'gem' as VaultCurrency,
    amount: 50,
    weight: 100,
    is_grand: false,
  }))
}

export default function AdminFortuneVaultSection() {
  const { isAdmin, loading: roleLoading } = useModRole()
  const [vaults, setVaults] = useState<AdminVault[]>([])
  const [loading, setLoading] = useState(true)

  const [draftId, setDraftId] = useState<string | null>(null)
  const [mode, setMode] = useState<VaultMode>('clear')
  const [onClear, setOnClear] = useState<VaultOnClear>('refill')
  const [currency, setCurrency] = useState<VaultCurrency>('gem')
  const [priceOne, setPriceOne] = useState(100)
  const [priceFive, setPriceFive] = useState(450)
  const [bannerUrl, setBannerUrl] = useState('')
  const [tag, setTag] = useState('')
  const [title, setTitle] = useState('')
  const [subtitle, setSubtitle] = useState('')
  const [endsAt, setEndsAt] = useState('')
  const [prizes, setPrizes] = useState<AdminVaultPrize[]>(blankPrizes())

  const [saving, setSaving] = useState(false)
  const [busy, setBusy] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState('')

  async function load() {
    const { data } = await fetchAdminVaults()
    setVaults(data)
    const draft = data.find(v => v.status === 'draft')
    if (draft) {
      setDraftId(draft.id)
      setMode(draft.mode)
      setOnClear(draft.on_clear)
      setCurrency(draft.currency)
      setPriceOne(draft.price_one)
      setPriceFive(draft.price_five)
      setBannerUrl(draft.banner_url ?? '')
      setTag(draft.tag ?? '')
      setTitle(draft.title ?? '')
      setSubtitle(draft.subtitle ?? '')
      setEndsAt(draft.ends_at ? draft.ends_at.slice(0, 16) : '')
      if (draft.prizes.length === 8) setPrizes(draft.prizes)
    }
    setLoading(false)
  }

  useEffect(() => {
    if (roleLoading) return
    if (!isAdmin) { setLoading(false); return }
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleLoading, isAdmin])

  if (roleLoading || !isAdmin) return null

  const live = vaults.find(v => v.status === 'live') ?? null

  async function pickImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    // Cleared straight away so picking the SAME file twice still fires
    // onChange — otherwise a failed upload can't be retried without
    // choosing a different image first.
    e.target.value = ''
    if (!file) return
    setUploading(true); setError(''); setSaved('')
    try {
      setBannerUrl(await uploadVaultImage(file))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image.')
    } finally {
      setUploading(false)
    }
  }

  // Full-board total. A player's own odds are computed server-side against
  // their remaining pool and are only ever equal to or better than these.
  const totalWeight = prizes.reduce((sum, p) => sum + (p.weight || 0), 0)

  function updatePrize(slot: number, next: Partial<AdminVaultPrize>) {
    setPrizes(list => list.map(p => (p.slot === slot ? { ...p, ...next } : p)))
    setSaved(''); setError('')
  }

  /** Returns the draft's id so publish() can roll out a board that was only
   *  just created — setDraftId won't have landed in state by then. */
  async function save(): Promise<string | null> {
    setSaving(true); setError(''); setSaved('')
    const { data, error: err } = await saveVaultDraft({
      vaultId: draftId,
      mode, onClear, currency,
      priceOne, priceFive,
      bannerUrl, tag, title, subtitle,
      // datetime-local has no zone; treat what the admin typed as their own
      // clock, which is what every other schedule field in the console does.
      endsAt: endsAt ? new Date(endsAt).toISOString() : null,
      prizes,
    })
    setSaving(false)
    if (err) { setError(err); return null }
    const id = data?.id ?? draftId
    if (id) setDraftId(id)
    setSaved('Draft saved.')
    load()
    return id
  }

  async function publish() {
    if (busy || saving || uploading) return
    setError(''); setSaved('')

    // Roll out used to sit disabled until Save draft had been pressed, which
    // reads as "the button is broken" rather than "there is nothing saved to
    // roll out". Save it first instead — the server validates the same way
    // either path, so a bad board still fails with a real reason.
    let id = draftId
    if (!id) {
      id = await save()
      if (!id) return // save() has already put its error on screen
    }

    setBusy(true)
    const { error: err } = await rolloutVault(id)
    setBusy(false)
    if (err) { setError(err); return }
    setDraftId(null)
    setPrizes(blankPrizes())
    setTag(''); setTitle(''); setSubtitle('')
    setSaved('The Vault is live.')
    load()
  }

  async function stop(id: string) {
    setBusy(true); setError(''); setSaved('')
    const { error: err } = await endVault(id)
    setBusy(false)
    if (err) { setError(err); return }
    setSaved('Vault ended.')
    load()
  }

  async function discard() {
    if (!draftId || busy) return
    setBusy(true); setError(''); setSaved('')
    const { error: err } = await deleteVaultDraft(draftId)
    setBusy(false)
    if (err) { setError(err); return }
    setDraftId(null)
    setPrizes(blankPrizes())
    setSaved('Draft deleted.')
    load()
  }

  return (
    <>
      <SectionTitle>Fortune Vault</SectionTitle>

      {/* ── What's running ────────────────────────────────────────────── */}
      {loading ? (
        <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>Loading…</p>
        </div>
      ) : live ? (
        <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
            <span style={{
              width: 30, height: 30, borderRadius: 10, flexShrink: 0, display: 'grid', placeItems: 'center',
              background: `${ACCENT}1f`, border: `1px solid ${ACCENT}44`,
            }}>
              <Sparkles size={15} color={ACCENT} />
            </span>
            <div style={{ minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
                {live.title || VAULT_FALLBACK.title}
                <span style={{ fontSize: 10, fontWeight: 700, color: ACCENT, marginLeft: 6 }}>LIVE</span>
              </p>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0' }}>
                {live.mode === 'clear' ? `Clear the board · ${live.on_clear === 'refill' ? 'refills' : 'stops'}` : 'Repeat'}
                {' · '}{live.price_one}/{live.price_five} {CURRENCY_LABEL[live.currency]}
              </p>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 12 }}>
            <Stat label="Players" value={live.players} />
            <Stat label="Spins" value={live.spins} />
            <Stat label="Prizes out" value={live.wins} />
          </div>

          {live.ends_at && (
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 12px' }}>
              Closes {new Date(live.ends_at).toLocaleString()} — it stops paying out on its own, no action needed.
            </p>
          )}

          <LivePresentation vault={live} onSaved={load} />

          <button
            type="button" disabled={busy}
            onClick={(e) => { ripple(e); stop(live.id) }}
            className="btn-secondary"
            style={{ width: '100%', padding: '9px 0', fontSize: 12.5, marginTop: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
          >
            <Square size={12} /> End it now
          </button>
        </div>
      ) : (
        <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0, lineHeight: 1.55 }}>
            No vault is live. Build the board below and roll it out — the Game Zone slide appears
            the moment it goes live and disappears when it ends.
          </p>
        </div>
      )}

      {/* ── The draft ─────────────────────────────────────────────────── */}
      <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
        <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: '0 0 12px' }}>
          {draftId ? 'Draft board' : 'New board'}
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
          <div>
            <p style={fieldLabel}>Mode</p>
            <select value={mode} onChange={e => { setMode(e.target.value as VaultMode); setSaved('') }} style={inputStyle}>
              <option value="clear">Clear the board</option>
              <option value="repeat">Repeat</option>
            </select>
          </div>
          <div>
            <p style={fieldLabel}>When it clears</p>
            <select
              value={onClear} disabled={mode === 'repeat'}
              onChange={e => { setOnClear(e.target.value as VaultOnClear); setSaved('') }}
              style={{ ...inputStyle, opacity: mode === 'repeat' ? 0.5 : 1 }}
            >
              <option value="refill">Refill it</option>
              <option value="stop">Stop there</option>
            </select>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 10 }}>
          <div>
            <p style={fieldLabel}>Currency</p>
            <select value={currency} onChange={e => { setCurrency(e.target.value as VaultCurrency); setSaved('') }} style={inputStyle}>
              <option value="gem">Diamonds</option>
              <option value="orb">Orbs</option>
              <option value="voucher">Vouchers</option>
            </select>
          </div>
          <div>
            <p style={fieldLabel}>Price ×1</p>
            <NumberField
              value={priceOne}
              onCommit={n => { setPriceOne(n); setSaved('') }}
              style={inputStyle}
            />
          </div>
          <div>
            <p style={fieldLabel}>Price ×5</p>
            <NumberField
              value={priceFive}
              onCommit={n => { setPriceFive(n); setSaved('') }}
              style={inputStyle}
            />
          </div>
        </div>

        <p style={fieldLabel}>Banner — the Game Zone slide and the top of the board</p>
        <input ref={fileRef} type="file" accept="image/*" onChange={pickImage} style={{ display: 'none' }} />
        {bannerUrl ? (
          <div style={{ position: 'relative', marginBottom: 8, borderRadius: 12, overflow: 'hidden', border: '1px solid var(--border)' }}>
            <img src={bannerUrl} alt="" style={{ width: '100%', height: 120, objectFit: 'cover', display: 'block' }} />
            <button
              type="button" aria-label="Remove image"
              onClick={(e) => { ripple(e); setBannerUrl(''); setSaved('') }}
              style={{
                position: 'absolute', top: 6, right: 6, width: 24, height: 24, borderRadius: '50%',
                background: 'rgba(0,0,0,0.55)', border: 'none', color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              }}
            >
              <X size={13} />
            </button>
            <button
              type="button" disabled={uploading}
              onClick={(e) => { ripple(e); fileRef.current?.click() }}
              style={{
                position: 'absolute', bottom: 6, right: 6, fontSize: 10.5, fontWeight: 700,
                padding: '5px 10px', borderRadius: 8, background: 'rgba(0,0,0,0.55)',
                border: 'none', color: '#fff', cursor: 'pointer',
              }}
            >
              {uploading ? 'Uploading…' : 'Replace'}
            </button>
          </div>
        ) : (
          <button
            type="button" disabled={uploading}
            onClick={(e) => { ripple(e); fileRef.current?.click() }}
            className="btn-secondary"
            style={{
              width: '100%', padding: '14px 0', fontSize: 11.5, marginBottom: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              opacity: uploading ? 0.6 : 1,
            }}
          >
            <ImagePlus size={14} /> {uploading ? 'Uploading…' : 'Upload banner'}
          </button>
        )}
        {/* Kept alongside the uploader so existing art under Adverts/ can be
            reused without re-uploading it into storage. */}
        <input
          type="url" placeholder="…or paste an image URL"
          value={bannerUrl}
          onChange={e => { setBannerUrl(e.target.value); setSaved('') }}
          style={{ ...inputStyle, fontSize: 11.5, marginBottom: 10 }}
        />
        <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '-6px 0 12px', lineHeight: 1.5 }}>
          Leave it empty and the slide falls back to the stock Game Zone art. This is set on the
          draft — a board that's already live keeps the banner it rolled out with.
        </p>

        <p style={fieldLabel}>Event tag — the pill on the Game Zone slide</p>
        <input
          value={tag} maxLength={24}
          placeholder={VAULT_FALLBACK.tag}
          onChange={e => { setTag(e.target.value); setSaved('') }}
          style={{ ...inputStyle, marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 800 }}
        />

        <p style={fieldLabel}>Headline</p>
        <input
          value={title} maxLength={40}
          placeholder={VAULT_FALLBACK.title}
          onChange={e => { setTitle(e.target.value); setSaved('') }}
          style={{ ...inputStyle, marginBottom: 10 }}
        />

        <p style={fieldLabel}>Slide text</p>
        <textarea
          value={subtitle} maxLength={160} rows={3}
          placeholder={VAULT_FALLBACK.subtitle}
          onChange={e => { setSubtitle(e.target.value); setSaved('') }}
          style={{ ...inputStyle, marginBottom: 6, resize: 'vertical', lineHeight: 1.5 }}
        />
        <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.5 }}>
          All three fall back to the stock Fortune Vault copy if you leave them empty. Tie them to
          whatever event is running — “ECLIPSE EVENT” / “Eclipse Vault” — and stock the eight tiles
          with that event's items.
        </p>

        <p style={fieldLabel}>Ends at (leave empty for 14 days from rollout)</p>
        <input
          type="datetime-local" value={endsAt}
          onChange={e => { setEndsAt(e.target.value); setSaved('') }}
          style={{ ...inputStyle, marginBottom: 14 }}
        />

        <p style={fieldLabel}>The eight tiles</p>

        <div style={{
          padding: 11, borderRadius: 12, marginBottom: 12,
          background: `${ACCENT}12`, border: `1px solid ${ACCENT}33`,
        }}>
          <p style={{ fontSize: 11, fontWeight: 800, color: 'var(--text)', margin: '0 0 6px' }}>
            What weight means
          </p>
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.6 }}>
            Weight is rarity. It is not a percentage — only the ratio between tiles matters, so all
            eight at 100 is the same board as all eight at 50. Each tile's real chance is its weight
            divided by the total, which is the % shown on its header as you type.
            <br /><br />
            <strong style={{ color: 'var(--text)' }}>To make one prize hard to get:</strong> leave the
            other seven at 100 and set that one low. 20 gives it 2.8%, 10 gives 1.4%, 5 gives 0.7%
            (about 1 spin in 140).
            <br /><br />
            The <strong style={{ color: 'var(--text)' }}>Grand prize</strong> tick is only the gold
            badge — it changes nothing about the odds.
            {mode === 'clear' && (
              <>
                {' '}And note Clear mode empties a player's pool as they win, so whoever clears the
                other seven wins the rare one on their next spin no matter how low you set it. Use
                Repeat mode if you want long odds to stay long odds.
              </>
            )}
          </p>
        </div>

        {prizes.map(p => (
          <PrizeRow
            key={p.slot}
            prize={p}
            sharePct={totalWeight > 0 ? Math.round((p.weight / totalWeight) * 1000) / 10 : 0}
            onChange={next => updatePrize(p.slot, next)}
          />
        ))}

        {error && <p style={{ fontSize: 11, color: 'var(--red)', margin: '10px 0 0', lineHeight: 1.5 }}>{error}</p>}
        {saved && !error && <p style={{ fontSize: 11, color: '#4fd18a', fontWeight: 700, margin: '10px 0 0' }}>{saved}</p>}

        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button
            type="button" disabled={saving || uploading}
            onClick={(e) => { ripple(e); save() }}
            className="btn-secondary"
            style={{ flex: 1, padding: '10px 0', fontSize: 12.5 }}
          >
            {saving ? 'Saving…' : uploading ? 'Uploading…' : 'Save draft'}
          </button>
          <button
            type="button" disabled={busy || saving || uploading}
            onClick={(e) => { ripple(e); publish() }}
            className="btn-primary"
            style={{
              flex: 1, padding: '10px 0', fontSize: 12.5,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              opacity: busy || saving || uploading ? 0.55 : 1,
            }}
          >
            <Rocket size={12} /> {busy ? 'Rolling out…' : 'Roll out'}
          </button>
        </div>

        <p style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'center', margin: '8px 0 0', lineHeight: 1.5 }}>
          Roll out saves the board first, then puts it live and ends whatever was running before.
        </p>

        {draftId && (
          <button
            type="button" disabled={busy}
            onClick={(e) => { ripple(e); discard() }}
            style={{
              width: '100%', marginTop: 8, padding: '8px 0', borderRadius: 10,
              background: 'none', border: '1px solid var(--border)', cursor: 'pointer',
              fontFamily: 'inherit', fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
            }}
          >
            <Trash2 size={11} /> Delete draft
          </button>
        )}
      </div>
    </>
  )
}

/** Re-dress a board that is already running.
 *
 *  Its own little form with its own state rather than reusing the draft
 *  fields above: those belong to the NEXT board, and typing a new event name
 *  into them while a vault is live should not silently rename the live one. */
function LivePresentation({ vault, onSaved }: { vault: AdminVault; onSaved: () => void }) {
  const [open, setOpen] = useState(false)
  const [tag, setTag] = useState(vault.tag ?? '')
  const [title, setTitle] = useState(vault.title ?? '')
  const [subtitle, setSubtitle] = useState(vault.subtitle ?? '')
  const [bannerUrl, setBannerUrl] = useState(vault.banner_url ?? '')
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)

  async function pick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true); setErr(''); setMsg('')
    try {
      setBannerUrl(await uploadVaultImage(file))
    } catch (error) {
      setErr(error instanceof Error ? error.message : 'Failed to upload image.')
    } finally {
      setUploading(false)
    }
  }

  async function save() {
    setSaving(true); setErr(''); setMsg('')
    const { error } = await setVaultPresentation({ vaultId: vault.id, tag, title, subtitle, bannerUrl })
    setSaving(false)
    if (error) { setErr(error); return }
    setMsg('Updated — players see it on their next load.')
    onSaved()
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={(e) => { ripple(e); setOpen(true) }}
        className="btn-secondary"
        style={{ width: '100%', padding: '9px 0', fontSize: 12.5, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
      >
        <Pencil size={12} /> Edit the name and banner
      </button>
    )
  }

  return (
    <div style={{ padding: 12, borderRadius: 12, background: 'var(--surface2)', border: `1px solid ${ACCENT}33` }}>
      <p style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text)', margin: '0 0 3px' }}>
        Live board dressing
      </p>
      <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 10px', lineHeight: 1.5 }}>
        Name, text and art only. Prizes, weights and prices are locked while a board is live —
        changing those under someone mid-spin isn't safe, so they need a new board.
      </p>

      <p style={fieldLabel}>Event tag</p>
      <input
        value={tag} maxLength={24} placeholder={VAULT_FALLBACK.tag}
        onChange={e => { setTag(e.target.value); setMsg('') }}
        style={{ ...inputStyle, fontSize: 12, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 800 }}
      />

      <p style={fieldLabel}>Headline</p>
      <input
        value={title} maxLength={40} placeholder={VAULT_FALLBACK.title}
        onChange={e => { setTitle(e.target.value); setMsg('') }}
        style={{ ...inputStyle, fontSize: 12, marginBottom: 8 }}
      />

      <p style={fieldLabel}>Slide text</p>
      <textarea
        value={subtitle} maxLength={160} rows={3} placeholder={VAULT_FALLBACK.subtitle}
        onChange={e => { setSubtitle(e.target.value); setMsg('') }}
        style={{ ...inputStyle, fontSize: 12, marginBottom: 8, resize: 'vertical', lineHeight: 1.5 }}
      />

      <p style={fieldLabel}>Banner</p>
      <input ref={fileRef} type="file" accept="image/*" onChange={pick} style={{ display: 'none' }} />
      {bannerUrl && (
        <img src={bannerUrl} alt="" style={{ width: '100%', height: 90, objectFit: 'cover', borderRadius: 10, display: 'block', marginBottom: 6, border: '1px solid var(--border)' }} />
      )}
      <button
        type="button" disabled={uploading}
        onClick={(e) => { ripple(e); fileRef.current?.click() }}
        className="btn-secondary"
        style={{ width: '100%', padding: '9px 0', fontSize: 11.5, marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
      >
        <ImagePlus size={13} /> {uploading ? 'Uploading…' : bannerUrl ? 'Replace banner' : 'Upload banner'}
      </button>

      {err && <p style={{ fontSize: 10.5, color: 'var(--red)', margin: '0 0 8px', lineHeight: 1.5 }}>{err}</p>}
      {msg && !err && <p style={{ fontSize: 10.5, color: '#4fd18a', fontWeight: 700, margin: '0 0 8px' }}>{msg}</p>}

      <div style={{ display: 'flex', gap: 8 }}>
        <button
          type="button"
          onClick={(e) => { ripple(e); setOpen(false) }}
          className="btn-secondary"
          style={{ flex: 1, padding: '9px 0', fontSize: 12 }}
        >
          Close
        </button>
        <button
          type="button" disabled={saving || uploading}
          onClick={(e) => { ripple(e); save() }}
          className="btn-primary"
          style={{ flex: 1, padding: '9px 0', fontSize: 12, opacity: saving || uploading ? 0.6 : 1 }}
        >
          {saving ? 'Saving…' : 'Apply'}
        </button>
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div style={{ padding: '8px 10px', borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
      <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', margin: 0 }}>{value.toLocaleString()}</p>
      <p style={{ fontSize: 9.5, color: 'var(--text-muted)', margin: '2px 0 0', fontWeight: 700 }}>{label}</p>
    </div>
  )
}

/** A number box you can actually empty.
 *
 *  The obvious `Math.max(1, Number(e.target.value))` is a trap: clearing the
 *  field makes value '', Number('') is 0, and the clamp rewrites it to 1 on
 *  the very same keystroke — so the box refills itself and there is no way to
 *  type a different first digit. Holding the raw STRING while the field has
 *  focus and clamping on blur is what makes "select all, type 5" work. */
function NumberField({ value, min = 1, onCommit, style }: {
  value: number
  min?: number
  onCommit: (n: number) => void
  style?: React.CSSProperties
}) {
  const [draft, setDraft] = useState(String(value))
  const [editing, setEditing] = useState(false)

  // Follow the prop when it changes from elsewhere (loading a saved draft),
  // but never yank the text out from under someone mid-type.
  useEffect(() => { if (!editing) setDraft(String(value)) }, [value, editing])

  return (
    <input
      type="number"
      inputMode="numeric"
      min={min}
      value={draft}
      onFocus={() => setEditing(true)}
      onChange={e => {
        setDraft(e.target.value)
        const n = Number(e.target.value)
        if (e.target.value !== '' && Number.isFinite(n) && n >= min) onCommit(n)
      }}
      onBlur={() => {
        setEditing(false)
        const n = Number(draft)
        const safe = draft === '' || !Number.isFinite(n) || n < min ? min : Math.floor(n)
        setDraft(String(safe))
        onCommit(safe)
      }}
      style={style}
    />
  )
}

function PrizeRow({ prize, onChange, sharePct }: {
  prize: AdminVaultPrize
  onChange: (next: Partial<AdminVaultPrize>) => void
  sharePct: number
}) {
  return (
    <div style={{
      padding: 10, borderRadius: 12, marginBottom: 8,
      background: 'var(--surface2)',
      border: prize.is_grand ? `1px solid ${ACCENT}55` : '1px solid var(--border)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ display: 'flex', alignItems: 'baseline', gap: 7 }}>
          <span style={{ fontSize: 11, fontWeight: 800, color: 'var(--text-dim)' }}>Slot {prize.slot + 1}</span>
          {/* The full-board odds, recalculated as you type. A player's real
              odds are this or better, never worse, since tiles only ever
              leave their pool. */}
          <span style={{ fontSize: 11, fontWeight: 800, color: ACCENT }}>{sharePct}%</span>
        </span>
        <label style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10.5, color: 'var(--text-muted)', cursor: 'pointer' }}>
          <input
            type="checkbox" checked={prize.is_grand}
            onChange={e => onChange({ is_grand: e.target.checked })}
          />
          Grand prize
        </label>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 2 }}>
        <span style={miniLabel}>Prize type</span>
        <span style={miniLabel}>Weight — lower is rarer</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 8 }}>
        <select
          value={prize.kind}
          onChange={e => {
            const kind = e.target.value as PrizeKind
            onChange({
              kind,
              item_id: kind === 'item' ? prize.item_id : null,
              currency: kind === 'currency' ? (prize.currency ?? 'gem') : null,
              amount: kind === 'item' ? null : (prize.amount ?? 50),
            })
          }}
          style={{ ...inputStyle, fontSize: 12 }}
        >
          <option value="item">Mall item</option>
          <option value="currency">Currency</option>
          <option value="xp">XP</option>
        </select>

        <NumberField
          value={prize.weight}
          onCommit={n => onChange({ weight: n })}
          style={{ ...inputStyle, fontSize: 12 }}
        />
      </div>

      {prize.kind === 'item' ? (
        <ItemPicker
          value={prize.item_name ?? null}
          image={prize.item_image_url ?? null}
          onPick={item => onChange({ item_id: item.id, item_name: item.name, item_image_url: item.image_url, item_category: item.category })}
        />
      ) : (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: prize.kind === 'currency' ? '1fr 1fr' : '1fr', gap: 6, marginBottom: 2 }}>
            {prize.kind === 'currency' && <span style={miniLabel}>Which currency</span>}
            <span style={miniLabel}>How many they win</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: prize.kind === 'currency' ? '1fr 1fr' : '1fr', gap: 6 }}>
            {prize.kind === 'currency' && (
              <select
                value={prize.currency ?? 'gem'}
                onChange={e => onChange({ currency: e.target.value as VaultCurrency })}
                style={{ ...inputStyle, fontSize: 12 }}
              >
                <option value="gem">Diamonds</option>
                <option value="orb">Orbs</option>
                <option value="voucher">Vouchers</option>
              </select>
            )}
            <NumberField
              value={prize.amount ?? 1}
              onCommit={n => onChange({ amount: n })}
              style={{ ...inputStyle, fontSize: 12 }}
            />
          </div>
        </>
      )}
    </div>
  )
}

/** Slot item picker.
 *
 *  Inline, not a floating overlay. The previous version positioned the result
 *  list `absolute` inside the prize card, which any ancestor with
 *  overflow:hidden silently clips — and on a phone an overlay that long is
 *  awkward regardless. Pushing the page down instead cannot be clipped by
 *  anything.
 *
 *  It also loads the Mall on focus rather than waiting for two typed
 *  characters, so the picker has something in it the moment you open it. */
function ItemPicker({ value, image, onPick }: {
  value: string | null
  image: string | null
  onPick: (item: VaultMallItem) => void
}) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<VaultMallItem[]>([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!open) return
    let live = true
    setLoading(true)
    // Debounced, but an empty query still fires — that's the browse list.
    const t = setTimeout(() => {
      searchVaultItems(query).then(({ data }) => {
        if (!live) return
        setResults(data)
        setLoading(false)
      })
    }, query.trim() ? 220 : 0)
    return () => { live = false; clearTimeout(t) }
  }, [query, open])

  // Collapsed: show what's chosen.
  if (value && !open) {
    return (
      <button
        type="button"
        onClick={(e) => { ripple(e); setOpen(true) }}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 9, padding: '8px 10px',
          borderRadius: 10, background: 'var(--surface)', border: '1px solid var(--border)',
          cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
        }}
      >
        <span style={{ width: 28, height: 28, borderRadius: 8, overflow: 'hidden', background: 'var(--surface3)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
          {image
            ? <img src={image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : <Gift size={13} style={{ color: 'var(--text-muted)' }} />}
        </span>
        <span style={{ flex: 1, minWidth: 0, fontSize: 12, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {value}
        </span>
        <span style={{ fontSize: 10.5, fontWeight: 700, color: ACCENT, flexShrink: 0 }}>Change</span>
      </button>
    )
  }

  return (
    <div>
      <div style={{ position: 'relative', marginBottom: 6 }}>
        <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          value={query}
          autoFocus={open && !!value}
          onFocus={() => setOpen(true)}
          onChange={e => { setQuery(e.target.value); setOpen(true) }}
          placeholder="Search the Mall, or just pick below"
          style={{ ...inputStyle, fontSize: 12, paddingLeft: 30 }}
        />
      </div>

      {!open ? (
        <button
          type="button"
          onClick={(e) => { ripple(e); setOpen(true) }}
          className="btn-secondary"
          style={{ width: '100%', padding: '9px 0', fontSize: 11.5 }}
        >
          Browse Mall items
        </button>
      ) : (
        <div style={{
          borderRadius: 11, border: '1px solid var(--border)', background: 'var(--surface)',
          maxHeight: 230, overflowY: 'auto',
        }}>
          {loading && results.length === 0 ? (
            <p style={{ fontSize: 11, color: 'var(--text-muted)', padding: '14px 10px', margin: 0, textAlign: 'center' }}>
              Loading…
            </p>
          ) : results.length === 0 ? (
            <p style={{ fontSize: 11, color: 'var(--text-muted)', padding: '14px 10px', margin: 0, textAlign: 'center' }}>
              Nothing in the Mall matches “{query.trim()}”.
            </p>
          ) : (
            results.map(item => {
              const picked = item.name === value
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={(e) => { ripple(e); onPick(item); setOpen(false); setQuery('') }}
                  style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: 9,
                    padding: '8px 10px', border: 'none', cursor: 'pointer',
                    background: picked ? `${ACCENT}1a` : 'transparent',
                    fontFamily: 'inherit', textAlign: 'left',
                    borderBottom: '1px solid var(--border)',
                  }}
                >
                  <span style={{ width: 30, height: 30, borderRadius: 8, overflow: 'hidden', background: 'var(--surface2)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                    {item.image_url
                      ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : <Gift size={13} style={{ color: 'var(--text-muted)' }} />}
                  </span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {item.name}
                    </span>
                    <span style={{ display: 'block', fontSize: 9.5, color: 'var(--text-muted)', textTransform: 'capitalize' }}>
                      {item.category.replace(/_/g, ' ')}
                      {/* Cosmetics behave differently in the Vault, so say so
                          where the choice is actually made. */}
                      {COSMETIC_CATEGORIES.includes(item.category) ? ' · one per player' : ' · can repeat'}
                    </span>
                  </span>
                  {picked && <Check size={13} color={ACCENT} style={{ flexShrink: 0 }} />}
                </button>
              )
            })
          )}
        </div>
      )}
    </div>
  )
}
