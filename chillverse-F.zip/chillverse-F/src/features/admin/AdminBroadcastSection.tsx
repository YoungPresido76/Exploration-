// src/features/admin/AdminBroadcastSection.tsx
//
// The "Broadcasts" wing of the Admin Dashboard — compose one message and push
// it out as a real DM to everyone, or to a hand-picked set of players.
// Recipients can reply, and their replies land in the sending admin's normal
// DM list, exactly like a WhatsApp broadcast.
//
// The editor writes the same lite-markdown the blog editor uses
// (applyMarkdownAction from shared/lib/markdownLite), so **bold**, *italic*
// and [label](url) links all work, and the link renders blue in the chat
// bubble via features/chat/messageContent. Images upload to the shared
// `chat-images` bucket and ride on the message as image_url.

import { useEffect, useRef, useState } from 'react'
import {
  Send, Bold, Italic, Link2, ImagePlus, X, Users, UserCheck,
  Search, Check, Eye, Loader2, AlertTriangle,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { SectionTitle } from '../settings/settingsShared'
import { fieldLabel, inputStyle } from './adminModal'
import { applyMarkdownAction, type MarkdownAction } from '../../shared/lib/markdownLite'
import { renderMessageContent } from '../chat/messageContent'
import { sendBroadcast, uploadBroadcastImage, validateChatImage } from './adminBroadcast'
import { PENDING_MESSAGE } from './adminRequests'
import { fetchAdminUserList, type AdminUserRow } from './adminStats'
import Avatar from '../../shared/components/Avatar'

const MAX_BODY = 4000
const PICKER_PAGE_SIZE = 20

type Audience = 'everyone' | 'selected'

// ── Recipient picker ──────────────────────────────────────────────────

function RecipientPicker({ selected, onToggle, onClear }: {
  selected: Map<string, AdminUserRow>
  onToggle: (user: AdminUserRow) => void
  onClear: () => void
}) {
  const [query, setQuery] = useState('')
  const [rows, setRows] = useState<AdminUserRow[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(async () => {
      setLoading(true)
      const { data, error: err } = await fetchAdminUserList(1, PICKER_PAGE_SIZE, query, null)
      setError(err ?? '')
      setRows(data?.rows ?? [])
      setLoading(false)
    }, 280)
    return () => { if (timer.current) clearTimeout(timer.current) }
  }, [query])

  return (
    <div style={{ marginTop: 12 }}>
      <div style={{ position: 'relative', marginBottom: 10 }}>
        <Search size={14} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search players by name or username…"
          style={{ ...inputStyle, paddingLeft: 32 }}
        />
      </div>

      {selected.size > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
          {[...selected.values()].map(u => (
            <button
              key={u.id}
              type="button"
              onClick={() => onToggle(u)}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 700,
                color: 'var(--accent)', background: 'color-mix(in srgb, var(--accent) 12%, transparent)',
                border: '1px solid color-mix(in srgb, var(--accent) 32%, transparent)',
                borderRadius: 8, padding: '3px 7px', cursor: 'pointer',
              }}
            >
              {u.display_name || u.username} <X size={10} />
            </button>
          ))}
          <button
            type="button"
            onClick={onClear}
            style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', background: 'none', border: 'none', cursor: 'pointer', padding: '3px 4px' }}
          >
            Clear all
          </button>
        </div>
      )}

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '0 0 8px' }}>{error}</p>}

      <div style={{ maxHeight: 240, overflowY: 'auto', border: '1px solid var(--border)', borderRadius: 10, background: 'var(--surface2)' }}>
        {loading ? (
          <p style={{ fontSize: 12, color: 'var(--text-muted)', padding: 12, margin: 0 }}>Loading…</p>
        ) : rows.length === 0 ? (
          <p style={{ fontSize: 12, color: 'var(--text-muted)', padding: 12, margin: 0 }}>No players found.</p>
        ) : rows.map(u => {
          const isOn = selected.has(u.id)
          return (
            <button
              key={u.id}
              type="button"
              onClick={() => onToggle(u)}
              style={{
                display: 'flex', alignItems: 'center', gap: 9, width: '100%', textAlign: 'left',
                padding: '8px 10px', cursor: 'pointer', border: 'none',
                background: isOn ? 'color-mix(in srgb, var(--accent) 10%, transparent)' : 'transparent',
              }}
            >
              <Avatar src={u.avatar} name={u.display_name || u.username} size={28} />
              <div style={{ minWidth: 0, flex: 1 }}>
                <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {u.display_name || u.username}
                </p>
                <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: 0 }}>@{u.username}</p>
              </div>
              {isOn && <Check size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />}
            </button>
          )
        })}
      </div>
    </div>
  )
}

// ── Main section ──────────────────────────────────────────────────────

export default function AdminBroadcastSection({ myId }: { myId: string | null }) {
  const [body, setBody] = useState('')
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [audience, setAudience] = useState<Audience>('everyone')
  const [selected, setSelected] = useState<Map<string, AdminUserRow>>(new Map())
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState('')
  const [confirming, setConfirming] = useState(false)

  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const canSend = (body.trim().length > 0 || imageUrl !== null)
    && (audience === 'everyone' || selected.size > 0)
    && !sending && !uploading

  /** Applies a toolbar action at the cursor, then restores focus/selection so
   *  typing continues where the inserted syntax expects it. */
  function applyAction(action: MarkdownAction, promptValue?: string | null) {
    const el = textareaRef.current
    if (!el) return
    const next = applyMarkdownAction(body, el.selectionStart, el.selectionEnd, action, promptValue)
    setBody(next.value)
    requestAnimationFrame(() => {
      el.focus()
      el.setSelectionRange(next.selectionStart, next.selectionEnd)
    })
  }

  async function handleFile(file: File) {
    if (!myId) { setError('Could not identify your admin account. Try reloading.'); return }
    const invalid = validateChatImage(file)
    if (invalid) { setError(invalid); return }
    setError(''); setUploading(true)
    try {
      setImageUrl(await uploadBroadcastImage(myId, file))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Image upload failed.')
    } finally {
      setUploading(false)
    }
  }

  function toggleRecipient(user: AdminUserRow) {
    setSelected(prev => {
      const next = new Map(prev)
      if (next.has(user.id)) next.delete(user.id)
      else next.set(user.id, user)
      return next
    })
  }

  async function doSend() {
    setSending(true); setError(''); setResult(''); setConfirming(false)
    const targets = audience === 'selected' ? [...selected.keys()] : null
    const { count, pending, error: err } = await sendBroadcast(body.trim(), imageUrl, targets)
    if (err) {
      setError(err)
    } else {
      setResult(pending ? PENDING_MESSAGE : `Sent to ${count} ${count === 1 ? 'player' : 'players'}. Replies will appear in your DMs.`)
      setBody(''); setImageUrl(null); setSelected(new Map()); setAudience('everyone')
    }
    setSending(false)
  }

  const toolbarButtons: { action: MarkdownAction; icon: typeof Bold; title: string }[] = [
    { action: 'bold', icon: Bold, title: 'Bold' },
    { action: 'italic', icon: Italic, title: 'Italic' },
    { action: 'link', icon: Link2, title: 'Insert link' },
  ]

  const recipientLabel = audience === 'everyone'
    ? 'every player on Chillverse'
    : `${selected.size} selected ${selected.size === 1 ? 'player' : 'players'}`

  return (
    <>
      <SectionTitle>Compose</SectionTitle>

      <div className="settings-card" style={{ padding: 16 }}>
        <p style={{ ...fieldLabel }}>Message</p>

        {/* Formatting toolbar */}
        <div style={{ display: 'flex', gap: 5, marginBottom: 8, flexWrap: 'wrap' }}>
          {toolbarButtons.map(({ action, icon: Icon, title }) => (
            <button
              key={action}
              type="button"
              title={title}
              onClick={e => { ripple(e); applyAction(action) }}
              style={{
                width: 32, height: 32, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: 'pointer',
              }}
            >
              <Icon size={14} />
            </button>
          ))}
          <button
            type="button"
            title="Attach an image (under 2MB)"
            onClick={e => { ripple(e); fileRef.current?.click() }}
            disabled={uploading}
            style={{
              width: 32, height: 32, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'var(--surface2)', border: '1px solid var(--border)',
              color: uploading ? 'var(--text-muted)' : 'var(--text-dim)', cursor: uploading ? 'wait' : 'pointer',
            }}
          >
            {uploading ? <Loader2 size={14} className="animate-spin" /> : <ImagePlus size={14} />}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            style={{ display: 'none' }}
            onChange={e => {
              const file = e.target.files?.[0]
              e.target.value = ''
              if (file) handleFile(file)
            }}
          />
        </div>

        <textarea
          ref={textareaRef}
          value={body}
          onChange={e => setBody(e.target.value.slice(0, MAX_BODY))}
          rows={6}
          placeholder={'Write your announcement…\n\nUse **bold**, *italic*, or [tap here](https://chillverse.com.ng/support) for a blue link.'}
          style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.5, fontFamily: 'inherit' }}
        />
        <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '4px 0 0', textAlign: 'right' }}>
          {body.length} / {MAX_BODY}
        </p>

        {imageUrl && (
          <div style={{ position: 'relative', marginTop: 10, width: 'fit-content' }}>
            <img src={imageUrl} alt="" style={{ maxWidth: 200, maxHeight: 160, borderRadius: 10, display: 'block' }} />
            <button
              type="button"
              onClick={() => setImageUrl(null)}
              aria-label="Remove image"
              style={{
                position: 'absolute', top: -7, right: -7, width: 24, height: 24, borderRadius: '50%',
                background: 'var(--red)', color: '#fff', border: 'none', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <X size={12} />
            </button>
          </div>
        )}
      </div>

      <SectionTitle>Audience</SectionTitle>

      <div className="settings-card" style={{ padding: 16 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {([
            { key: 'everyone' as Audience, label: 'Everyone', icon: Users },
            { key: 'selected' as Audience, label: 'Pick players', icon: UserCheck },
          ]).map(({ key, label, icon: Icon }) => {
            const active = audience === key
            return (
              <button
                key={key}
                type="button"
                onClick={e => { ripple(e); setAudience(key) }}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  padding: '10px 12px', borderRadius: 11, cursor: 'pointer', fontSize: 12.5, fontWeight: 800,
                  background: active ? 'var(--surface2)' : 'transparent',
                  border: active ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                  color: active ? 'var(--accent)' : 'var(--text-dim)',
                }}
              >
                <Icon size={13} /> {label}
              </button>
            )
          })}
        </div>

        {audience === 'selected' && (
          <RecipientPicker
            selected={selected}
            onToggle={toggleRecipient}
            onClear={() => setSelected(new Map())}
          />
        )}
      </div>

      <SectionTitle>Preview</SectionTitle>

      <div className="settings-card" style={{ padding: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10, color: 'var(--text-muted)', fontSize: 11 }}>
          <Eye size={12} /> How it lands in their DMs
        </div>
        <div style={{
          position: 'relative', display: 'inline-block', width: 'fit-content', maxWidth: '100%',
          padding: '7px 10px', borderRadius: 8, background: 'var(--surface)',
          boxShadow: '3px 3px 7px rgba(10,10,12,0.45), -2px -2px 5px rgba(38,38,48,0.35)',
        }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 4,
            fontSize: 9, fontWeight: 800, letterSpacing: '0.05em', textTransform: 'uppercase',
            color: 'var(--accent)', background: 'color-mix(in srgb, var(--accent) 14%, transparent)',
            border: '1px solid color-mix(in srgb, var(--accent) 32%, transparent)',
            borderRadius: 6, padding: '1px 6px',
          }}>
            Official
          </div>
          {imageUrl && (
            <img src={imageUrl} alt="" style={{ display: 'block', maxWidth: 200, maxHeight: 200, borderRadius: 7, marginBottom: 4 }} />
          )}
          <div style={{ fontSize: 12.5, lineHeight: 1.4, color: 'var(--text)', wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}>
            {body.trim() ? renderMessageContent(body) : <span style={{ color: 'var(--text-muted)' }}>Your message will appear here…</span>}
          </div>
        </div>
      </div>

      {error && (
        <div className="settings-card" style={{ padding: 12, marginTop: 12, display: 'flex', alignItems: 'flex-start', gap: 8 }}>
          <AlertTriangle size={14} style={{ color: 'var(--red)', flexShrink: 0, marginTop: 1 }} />
          <span style={{ fontSize: 12, color: 'var(--red)' }}>{error}</span>
        </div>
      )}

      {result && (
        <div className="settings-card" style={{ padding: 12, marginTop: 12, display: 'flex', alignItems: 'flex-start', gap: 8 }}>
          <Check size={14} style={{ color: 'var(--green)', flexShrink: 0, marginTop: 1 }} />
          <span style={{ fontSize: 12, color: 'var(--text)' }}>{result}</span>
        </div>
      )}

      {/* Two-step send — a broadcast can't be recalled, so the count is
          restated before it actually goes out. */}
      {confirming ? (
        <div className="settings-card" style={{ padding: 16, marginTop: 14 }}>
          <p style={{ fontSize: 12.5, color: 'var(--text)', margin: '0 0 12px' }}>
            Send this to <strong>{recipientLabel}</strong>? This can't be undone.
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={e => { ripple(e); setConfirming(false) }}
              style={{
                flex: 1, padding: '11px 14px', borderRadius: 11, fontSize: 13, fontWeight: 800, cursor: 'pointer',
                background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text-dim)',
              }}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={e => { ripple(e); doSend() }}
              disabled={sending}
              style={{
                flex: 1, padding: '11px 14px', borderRadius: 11, fontSize: 13, fontWeight: 800,
                cursor: sending ? 'wait' : 'pointer', border: 'none', color: '#fff',
                background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}
            >
              {sending ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
              {sending ? 'Sending…' : 'Yes, send it'}
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={e => { ripple(e); setError(''); setResult(''); setConfirming(true) }}
          disabled={!canSend}
          style={{
            width: '100%', marginTop: 14, padding: '13px 16px', borderRadius: 12,
            fontSize: 13.5, fontWeight: 800, border: 'none', color: '#fff',
            background: canSend ? 'linear-gradient(135deg,var(--accent),var(--accent2))' : 'var(--surface2)',
            cursor: canSend ? 'pointer' : 'not-allowed', opacity: canSend ? 1 : 0.55,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
          }}
        >
          <Send size={15} /> Send to {recipientLabel}
        </button>
      )}

      <p style={{ fontSize: 11, color: 'var(--text-muted)', lineHeight: 1.5, margin: '10px 2px 0' }}>
        Broadcasts arrive as a normal DM from your account, badged Official. Players can reply,
        and their replies land in your Chat inbox.
      </p>
    </>
  )
}
