// src/features/admin/AdminBountySection.tsx
//
// Place and cancel contracts, in the Arena wing.
//
// This is the only way a bounty ever exists — there is no player-facing
// path, by design. It carries its own compact user picker rather than
// reusing AdminUserSearch, because that component's job is to NAVIGATE to
// a user detail page; it has no "hand the id back to my caller" mode, and
// bending it into one would have changed behaviour at its three existing
// call sites for this one new use.
import { useEffect, useState } from 'react'
import { Clock, Gem, Search, Swords, X } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { SectionTitle } from '../settings/settingsShared'
import { fetchAdminUserList, type AdminUserRow } from './adminStats'
import { cancelBounty, placeBounty, bountyErrorMessage, type Bounty } from '../pvp/bounties'
import { useBounties, refreshBounties } from '../pvp/useBounties'
import { PENDING_MESSAGE } from './adminRequests'

const PARCHMENT = '#c9a86a'
/** Mirrors the server-side ceiling in admin_place_bounty. */
const MAX_REWARD = 10000

function TargetPicker({ onPick }: { onPick: (u: AdminUserRow) => void }) {
  const [search, setSearch] = useState('')
  const [debounced, setDebounced] = useState('')
  const [rows, setRows] = useState<AdminUserRow[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 300)
    return () => clearTimeout(t)
  }, [search])

  useEffect(() => {
    if (debounced.trim().length < 2) { setRows([]); return }
    let active = true
    setLoading(true)
    fetchAdminUserList(1, 8, debounced)
      .then(({ data }) => { if (active) setRows(data?.rows ?? []) })
      .catch(() => { if (active) setRows([]) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [debounced])

  return (
    <div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px',
        borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)',
      }}>
        <Search size={14} color="var(--text-dim)" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search a player by name or email"
          style={{
            flex: 1, background: 'none', border: 'none', outline: 'none',
            fontFamily: 'inherit', fontSize: 12.5, color: 'var(--text)',
          }}
        />
        {loading && <span style={{ fontSize: 10, color: 'var(--text-dim)' }}>…</span>}
      </div>

      {rows.length > 0 && (
        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 2 }}>
          {rows.map(u => (
            <button
              key={u.id}
              type="button"
              onClick={() => onPick(u)}
              style={{
                display: 'flex', alignItems: 'center', gap: 9, width: '100%',
                textAlign: 'left', padding: '7px 8px', borderRadius: 10,
                background: 'transparent', border: 'none', cursor: 'pointer',
                fontFamily: 'inherit',
              }}
            >
              <Avatar src={u.avatar} name={u.display_name || u.username} size={28} />
              <span style={{
                flex: 1, minWidth: 0, fontSize: 12, fontWeight: 700, color: 'var(--text)',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>
                {u.display_name || u.username}
              </span>
              <span style={{ fontSize: 10.5, color: 'var(--text-dim)' }}>@{u.username}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function LiveBountyRow({ bounty, onCancel, busy }: {
  bounty: Bounty; onCancel: (id: string) => void; busy: boolean
}) {
  const name = bounty.display_name || bounty.username
  const hours = Math.max(0, Math.floor((new Date(bounty.expires_at).getTime() - Date.now()) / 3_600_000))

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
      borderRadius: 12, background: 'var(--surface2)',
      border: `1px solid ${PARCHMENT}3d`,
    }}>
      <Avatar src={bounty.avatar} name={name} size={32} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontSize: 12.5, fontWeight: 700, color: 'var(--text)', margin: 0,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {name}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
          <Clock size={10} color="var(--text-dim)" />
          <span style={{ fontSize: 10, color: 'var(--text-dim)' }}>{hours}h left</span>
        </div>
      </div>
      <span style={{ fontSize: 13, fontWeight: 800, color: PARCHMENT, flexShrink: 0 }}>
        {bounty.reward_gems.toLocaleString()}
      </span>
      <button
        type="button"
        disabled={busy}
        onClick={() => onCancel(bounty.id)}
        aria-label={`Cancel bounty on ${name}`}
        style={{
          flexShrink: 0, width: 26, height: 26, borderRadius: 8, cursor: busy ? 'wait' : 'pointer',
          display: 'grid', placeItems: 'center',
          background: 'var(--surface3)', border: '1px solid var(--border)',
          color: 'var(--red)', opacity: busy ? 0.5 : 1,
        }}
      >
        <X size={13} />
      </button>
    </div>
  )
}

export default function AdminBountySection() {
  const { bounties } = useBounties()
  const [target, setTarget] = useState<AdminUserRow | null>(null)
  const [reward, setReward] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState<string | null>(null)

  const rewardNum = Number(reward)
  const rewardValid = Number.isInteger(rewardNum) && rewardNum > 0 && rewardNum <= MAX_REWARD

  async function submit() {
    if (!target || !rewardValid || busy) return
    setBusy(true); setError(null); setDone(null)
    try {
      const { pending } = await placeBounty(target.id, rewardNum, note)
      setDone(pending ? PENDING_MESSAGE : `Bounty placed on ${target.display_name || target.username}.`)
      setTarget(null); setReward(''); setNote('')
      refreshBounties()
    } catch (e) {
      setError(bountyErrorMessage(e))
    } finally {
      setBusy(false)
    }
  }

  async function remove(id: string) {
    setBusy(true); setError(null); setDone(null)
    try {
      await cancelBounty(id)
      refreshBounties()
    } catch (e) {
      setError(bountyErrorMessage(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <SectionTitle>Bounties</SectionTitle>

      <div className="neu-card" style={{ padding: 16, marginBottom: 14 }}>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.55 }}>
          Placing a contract slams a wanted poster onto every player's screen and pays
          the Diamonds to whoever lands the killing blow. Unclaimed contracts expire
          quietly after 72 hours.
        </p>

        {target ? (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 9, padding: '9px 11px',
            borderRadius: 12, background: 'var(--surface2)',
            border: `1px solid ${PARCHMENT}4d`, marginBottom: 10,
          }}>
            <Avatar src={target.avatar} name={target.display_name || target.username} size={30} />
            <span style={{ flex: 1, fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>
              {target.display_name || target.username}
            </span>
            <button
              type="button" onClick={() => setTarget(null)} aria-label="Clear target"
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}
            >
              <X size={15} />
            </button>
          </div>
        ) : (
          <div style={{ marginBottom: 10 }}>
            <TargetPicker onPick={setTarget} />
          </div>
        )}

        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px',
          borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)',
          marginBottom: 10,
        }}>
          <Gem size={14} color={PARCHMENT} />
          <input
            value={reward}
            onChange={e => setReward(e.target.value.replace(/[^0-9]/g, ''))}
            inputMode="numeric"
            placeholder={`Reward in Diamonds (max ${MAX_REWARD.toLocaleString()})`}
            style={{
              flex: 1, background: 'none', border: 'none', outline: 'none',
              fontFamily: 'inherit', fontSize: 12.5, color: 'var(--text)',
            }}
          />
        </div>

        <input
          value={note}
          onChange={e => setNote(e.target.value.slice(0, 90))}
          placeholder="Optional line on the poster"
          style={{
            width: '100%', padding: '9px 12px', borderRadius: 12, marginBottom: 12,
            background: 'var(--surface2)', border: '1px solid var(--border)',
            outline: 'none', fontFamily: 'inherit', fontSize: 12.5, color: 'var(--text)',
          }}
        />

        {error && (
          <p style={{
            fontSize: 11.5, color: 'var(--red)', margin: '0 0 10px',
            padding: '8px 11px', borderRadius: 10,
            background: 'color-mix(in srgb, var(--red) 10%, transparent)',
          }}>
            {error}
          </p>
        )}
        {done && (
          <p style={{ fontSize: 11.5, color: 'var(--green)', margin: '0 0 10px' }}>{done}</p>
        )}

        <button
          type="button"
          disabled={!target || !rewardValid || busy}
          onClick={submit}
          style={{
            width: '100%', padding: 12, borderRadius: 13, border: 'none',
            cursor: !target || !rewardValid || busy ? 'not-allowed' : 'pointer',
            fontFamily: 'inherit', fontSize: 13, fontWeight: 800, color: '#2a1a08',
            background: `linear-gradient(135deg, ${PARCHMENT}, #e0c184)`,
            opacity: !target || !rewardValid || busy ? 0.45 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}
        >
          <Swords size={15} /> {busy ? 'Working…' : 'Place the bounty'}
        </button>
      </div>

      {bounties.length > 0 && (
        <>
          <SectionTitle>Live contracts</SectionTitle>
          <div className="neu-card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {bounties.map(b => (
              <LiveBountyRow key={b.id} bounty={b} onCancel={remove} busy={busy} />
            ))}
          </div>
        </>
      )}
    </>
  )
}
