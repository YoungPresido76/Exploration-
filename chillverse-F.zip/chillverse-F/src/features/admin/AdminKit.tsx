// src/features/admin/AdminKit.tsx
//
// Shared building blocks for the admin wing screens: the KPI card (icon
// chip + optional trend pill + big number + label), the wing header (back
// + eyebrow + title + search), and a small segmented-tab control for wings
// dense enough to need grouping (Mall economy's Store/Sales/Diamonds).
// Pulled into their own file so AdminWingScreen.tsx and AdminConcourse.tsx
// can both use them without one importing the other.
import type { MouseEvent, ReactNode } from 'react'
import { ArrowLeft, Search } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'

export function KpiCard({
  icon: Icon, label, value, trend, trendTone = 'up', tint = 'var(--accent)', onClick,
}: {
  icon: typeof Search
  label: string
  value: string | number
  /** Real, computed deltas only — e.g. "+8 this wk" or "12% of base". Omit rather than fabricate one. */
  trend?: string
  trendTone?: 'up' | 'flat'
  tint?: string
  onClick?: (e: MouseEvent<HTMLDivElement>) => void
}) {
  return (
    <div
      className="neu-card"
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={onClick ? (e) => { if (e.key === 'Enter' || e.key === ' ') e.currentTarget.click() } : undefined}
      style={{
        padding: 13, display: 'flex', flexDirection: 'column', gap: 9, minWidth: 0, minHeight: 82, justifyContent: 'space-between',
        cursor: onClick ? 'pointer' : 'default',
        border: onClick ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' : undefined,
      }}
    >
      <div className="flex items-center justify-between">
        <div style={{
          width: 26, height: 26, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: `${tint}22`, color: tint, flexShrink: 0,
        }}>
          <Icon size={14} />
        </div>
        {trend && (
          <span style={{
            fontSize: 10, fontWeight: 800, padding: '2px 6px', borderRadius: 999,
            color: trendTone === 'up' ? 'var(--green)' : 'var(--text-muted)',
            background: trendTone === 'up' ? 'rgba(62,207,142,0.14)' : 'var(--surface3)',
          }}>
            {trend}
          </span>
        )}
      </div>
      <div>
        <div style={{ fontSize: 21, fontWeight: 800, letterSpacing: '-0.01em', color: 'var(--text)', fontVariantNumeric: 'tabular-nums' }}>{value}</div>
        <div style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 600, marginTop: 1 }}>{label}</div>
      </div>
    </div>
  )
}

export function WingHeader({
  eyebrow, title, onBack, onSearch,
}: { eyebrow: string; title: string; onBack: () => void; onSearch: () => void }) {
  return (
    <div className="flex items-center gap-3" style={{ marginBottom: 14 }}>
      <button
        type="button"
        onClick={(e) => { ripple(e); onBack() }}
        aria-label="Back to the Concourse"
        style={{
          width: 36, height: 36, borderRadius: 11, flexShrink: 0, background: 'var(--surface)',
          border: '1px solid var(--border)', color: 'var(--text-dim)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}
      >
        <ArrowLeft size={16} />
      </button>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {eyebrow}
        </p>
        <h1 style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-0.01em', color: 'var(--text)', margin: '2px 0 0' }}>{title}</h1>
      </div>
      <button
        type="button"
        onClick={(e) => { ripple(e); onSearch() }}
        aria-label="Search users"
        style={{
          width: 36, height: 36, borderRadius: 11, flexShrink: 0, background: 'var(--surface)',
          border: '1px solid var(--border)', color: 'var(--text-dim)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}
      >
        <Search size={15} />
      </button>
    </div>
  )
}

export function SegmentedTabs<T extends string>({
  options, value, onChange,
}: { options: { key: T; label: string }[]; value: T; onChange: (key: T) => void }) {
  return (
    <div style={{ display: 'inline-flex', gap: 4, background: 'var(--surface)', border: '1px solid var(--border)', padding: 4, borderRadius: 999, marginBottom: 18 }}>
      {options.map(opt => (
        <button
          key={opt.key}
          type="button"
          onClick={(e) => { ripple(e); onChange(opt.key) }}
          style={{
            border: 'none', padding: '7px 14px', borderRadius: 999, fontSize: 12, fontWeight: 800, cursor: 'pointer',
            background: value === opt.key ? 'var(--accent)' : 'transparent',
            color: value === opt.key ? '#1a0a00' : 'var(--text-dim)',
          }}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}

/** 7-bar spark chart card — ports the mockup's sparkHTML (title + delta
 *  badge + 7 vertical bars, last bar full-opacity, the rest dimmed).
 *  `data` must be exactly 7 points, oldest first. `deltaPct` is optional —
 *  omit it rather than compute a fake trend when the caller doesn't have
 *  one (e.g. too few historical points to compare against). */
export function SparkBarCard({
  title, data, deltaPct, formatValue,
}: {
  title: string
  data: { day: string; value: number }[]
  deltaPct?: number | null
  formatValue?: (v: number) => string
}) {
  const max = Math.max(1, ...data.map(d => d.value))
  return (
    <div className="neu-card" style={{ padding: 14, marginBottom: 18 }}>
      <div className="flex items-center gap-2" style={{ marginBottom: 10 }}>
        <span style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)' }}>{title}</span>
        {deltaPct !== undefined && deltaPct !== null && (
          <span style={{
            marginLeft: 'auto', fontSize: 10.5, fontWeight: 700,
            color: deltaPct > 0 ? 'var(--green)' : deltaPct < 0 ? 'var(--red)' : 'var(--text-muted)',
          }}>
            {deltaPct > 0 ? '↑' : deltaPct < 0 ? '↓' : ''} {Math.abs(deltaPct)}% · 7d
          </span>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 64 }}>
        {data.map((d, i) => (
          <div
            key={d.day}
            title={`${d.day}: ${formatValue ? formatValue(d.value) : d.value}`}
            style={{
              flex: 1, borderRadius: 4, minHeight: 3,
              height: `${Math.max(4, (d.value / max) * 64)}px`,
              background: 'var(--gold)',
              opacity: i === data.length - 1 ? 1 : 0.55,
            }}
          />
        ))}
      </div>
    </div>
  )
}

/** Full-bleed wing screen shell — takes over the viewport below the app's
 *  fixed topbar (60px) and slides in from the right. `position: fixed`
 *  rather than `absolute`-within-parent on purpose: the Concourse card
 *  above it doesn't reliably have enough natural height to host a nested
 *  scroll region for every wing (Ops console in particular), so this
 *  scrolls the page itself instead of clipping to the parent's height. */
export function WingSlideIn({ children }: { children: ReactNode }) {
  return (
    <div
      style={{
        position: 'fixed', top: 60, left: 0, right: 0, bottom: 0, zIndex: 250,
        background: 'var(--bg)', overflowY: 'auto', WebkitOverflowScrolling: 'touch',
        animation: 'wingSlideIn 0.3s var(--ease-out) both',
      }}
    >
      <style>{`
        @keyframes wingSlideIn { from { transform: translateX(28px); opacity: 0 } to { transform: translateX(0); opacity: 1 } }
      `}</style>
      {children}
    </div>
  )
}
