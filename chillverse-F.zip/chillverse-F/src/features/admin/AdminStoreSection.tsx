// src/features/admin/AdminStoreSection.tsx
//
// The Mall/economy control surface, split out of the old AdminOpsPanel so
// the person running the game isn't stuck checking one giant "Ops console"
// for everything. This section lives under the "Mall economy" wing in
// AdminDashboard.tsx, right alongside the read-only economy stats it's
// the acting counterpart to — bundles, item pricing/locking/timers, the
// Flash Sale schedule, and diamond gifting all change what's actually in
// the shop, so they sit here rather than under general ops (maintenance,
// flags, broadcasts, exports, health).
//
// Same visual language as AdminOpsPanel.tsx: SectionTitle + .settings-card
// groups of Row entries, anything with a form opens in a popover Modal.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Search, Check, Gift, X, Pin, PinOff, Plus, ArrowLeft,
  ImagePlus, Upload, Trash2, Timer, Hourglass, Lock, Unlock, Zap, Video, Palette,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { supabase } from '../../shared/lib/supabase'
import { Row, SectionTitle } from '../settings/settingsShared'
import { Modal, fieldLabel, inputStyle } from './adminModal'
import {
  searchMallItems,
  fetchMallBundles, uploadMallBundleImage, saveMallBundle, deleteMallBundle, setMallBundlePinned,
  adminSearchMallItems, setMallItemPrice, setMallItemTimer, setMallItemLock,
  uploadMallItemImage, uploadMallItemVideo, saveMallItem, setMallItemActive,
  fetchItemVariantsAdmin, saveItemVariant, deleteItemVariant, type AdminItemVariant,
  grantDiamonds, fetchRecentDiamondGifts,
  type GameGoalMallItem, type AdminMallItem, type MallItemDraft,
  type MallBundleStatus, type MallBundleConfig, type DiamondGiftLogRow,
} from './adminOps'
import { fetchAdminUserList, type AdminUserRow } from './adminStats'
import { PENDING_MESSAGE } from './adminRequests'

// ── Mall Bundle (migration 0106) ─────────────────────────────────────────
// Search-to-add picker for the bundle's contents. Reuses the same
// searchMallItems RPC as the Game Goal final-item picker, but keeps an
// ordered list of selections instead of a single value — search adds an
// item, the row's X removes it. "Select and deselect any item that exists
// in Mall" per the ops requirement, without loading the entire catalog
// into the modal.
function MallItemMultiSelect({ selected, onChange }: {
  selected: GameGoalMallItem[]
  onChange: (items: GameGoalMallItem[]) => void
}) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<GameGoalMallItem[]>([])
  const [open, setOpen] = useState(false)
  const [searching, setSearching] = useState(false)

  useEffect(() => {
    if (!open) return
    if (query.trim().length < 2) { setResults([]); return }
    setSearching(true)
    const t = setTimeout(() => {
      searchMallItems(query).then(({ data }) => { setResults(data); setSearching(false) })
    }, 220)
    return () => clearTimeout(t)
  }, [query, open])

  function add(item: GameGoalMallItem) {
    if (selected.some(s => s.id === item.id)) return
    onChange([...selected, item])
    setQuery('')
    setOpen(false)
  }

  function remove(id: string) {
    onChange(selected.filter(s => s.id !== id))
  }

  const selectedIds = new Set(selected.map(s => s.id))

  return (
    <div>
      <div style={{ position: 'relative' }}>
        <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true) }}
          onFocus={() => setOpen(true)}
          placeholder="Search Mall items to add…"
          style={{ ...inputStyle, paddingLeft: 30 }}
        />
        {open && query.trim().length >= 2 && (
          <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 4, zIndex: 5, background: 'var(--popover)', border: '1px solid var(--border)', borderRadius: 12, boxShadow: 'var(--elev-popover)', maxHeight: 220, overflowY: 'auto' }}>
            {searching ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>Searching…</p>
            ) : results.length === 0 ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>No matching Mall items.</p>
            ) : results.map(item => {
              const already = selectedIds.has(item.id)
              return (
                <div
                  key={item.id}
                  onClick={() => add(item)}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', cursor: already ? 'default' : 'pointer', opacity: already ? 0.45 : 1 }}
                >
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {item.image_url ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Gift size={13} style={{ color: 'var(--text-muted)' }} />}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 12, color: 'var(--text)', margin: 0, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</p>
                    <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: 0, textTransform: 'capitalize' }}>{item.category.replace('_', ' ')}</p>
                  </div>
                  {already && <Check size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />}
                </div>
              )
            })}
          </div>
        )}
      </div>

      <p style={{ ...fieldLabel, marginTop: 14 }}>Selected — shown in this order ({selected.length})</p>
      {selected.length === 0 ? (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 0' }}>No items selected yet. Search above to add some.</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {selected.map(item => (
            <div key={item.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px', borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
              <div style={{ width: 26, height: 26, borderRadius: 7, background: 'var(--surface)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {item.image_url ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Gift size={12} style={{ color: 'var(--text-muted)' }} />}
              </div>
              <span style={{ flex: 1, minWidth: 0, fontSize: 12, color: 'var(--text)', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</span>
              <button
                onClick={() => remove(item.id)}
                aria-label={`Remove ${item.name}`}
                style={{ width: 22, height: 22, borderRadius: 7, border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
              >
                <X size={13} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// The bundle CMS. Everything about the Mall's featured bundle lives here:
// artwork, name, the one fixed price, its contents, and whether players can
// see it at all.
//
// Three exits, deliberately distinct:
//   • Save draft   — stores whatever's filled in so far, invisible to
//                    players. No completeness rules; come back later.
//   • Publish      — puts it live. Server enforces artwork + at least one
//                    item, and a name if a price is set.
//   • Delete       — takes it down and wipes the config. Two taps, because
//                    it's not undoable.
//
// Leaving the price empty is a supported state, not an incomplete one: the
// section then renders as plain artwork + a browsable item row with no
// buy-all button, which is what this slot did before it became a bundle.
// ── Mall Bundles (migrations 0106 + 0108) ────────────────────────────────
// 0106 had one bundle, so this modal was one form. 0108 made it a list, so
// it's now two views behind the same modal: the roster, and the editor for
// whichever bundle you tapped (or a blank one for "New bundle").
//
// The pin is the thing worth understanding here. Exactly one bundle is
// pinned, and only the pinned bundle's items show as thumbnails on the
// Mall page — everything else published is banner-only, tapped into. So
// pinning isn't decoration, it's choosing which bundle gets the shop-front
// treatment, and it's a move rather than a toggle: pinning one unpins
// whatever held it before.

function BundleStatusChip({ status, pinned }: { status: MallBundleStatus; pinned: boolean }) {
  const live = status === 'published'
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{
        fontSize: 9.5, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase',
        padding: '3px 7px', borderRadius: 20,
        background: live ? 'rgba(62,207,142,0.14)' : 'rgba(136,136,153,0.14)',
        color: live ? '#4fd18a' : 'var(--text-muted)',
      }}>
        {live ? 'Live' : 'Draft'}
      </span>
      {pinned && (
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 3,
          fontSize: 9.5, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase',
          padding: '3px 7px', borderRadius: 20,
          background: 'color-mix(in srgb, var(--accent) 16%, transparent)', color: 'var(--accent)',
        }}>
          <Pin size={9} /> Pinned
        </span>
      )}
    </div>
  )
}

function MallBundleList({ bundles, busyId, onEdit, onNew, onTogglePin }: {
  bundles: MallBundleConfig[]
  busyId: string | null
  onEdit: (bundle: MallBundleConfig) => void
  onNew: () => void
  onTogglePin: (bundle: MallBundleConfig) => void
}) {
  return (
    <>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.55 }}>
        Every published bundle gets a banner in the Mall. Only the pinned
        one also shows its items underneath — for the rest, players tap the
        banner to see what's inside.
      </p>

      {bundles.length === 0 ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: '18px 0' }}>
          No bundles yet.
        </p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 14 }}>
          {bundles.map(b => (
            <div
              key={b.id}
              style={{
                display: 'flex', alignItems: 'center', gap: 11, padding: 10, borderRadius: 12,
                background: 'var(--surface2)', border: '1px solid var(--border)',
              }}
            >
              <div
                onClick={() => onEdit(b)}
                style={{
                  width: 64, height: 34, borderRadius: 8, flexShrink: 0, cursor: 'pointer',
                  background: b.image_url
                    ? `var(--surface) url(${b.image_url}) center/cover`
                    : 'var(--surface)',
                  border: '1px solid var(--border)',
                }}
              />
              <div onClick={() => onEdit(b)} style={{ flex: 1, minWidth: 0, cursor: 'pointer' }}>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {b.name ?? 'Untitled bundle'}
                </div>
                <div style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 4px' }}>
                  {b.live_item_count} item{b.live_item_count === 1 ? '' : 's'}
                  {b.price_gems != null ? ` · 💎 ${b.price_gems.toLocaleString()}` : ' · no price'}
                  {/* Picks that were deactivated in the catalog silently
                      vanish from what players see, so surface the gap here
                      rather than letting a "4 item" bundle quietly ship 2. */}
                  {b.live_item_count < b.item_ids.length && (
                    <span style={{ color: 'var(--red)' }}>
                      {' '}· {b.item_ids.length - b.live_item_count} inactive
                    </span>
                  )}
                </div>
                <BundleStatusChip status={b.status} pinned={b.is_pinned} />
              </div>
              <button
                onClick={() => onTogglePin(b)}
                disabled={busyId !== null}
                title={b.is_pinned ? 'Unpin' : 'Pin — show this bundle\u2019s items on the Mall page'}
                aria-label={b.is_pinned ? 'Unpin bundle' : 'Pin bundle'}
                style={{
                  width: 32, height: 32, borderRadius: 9, flexShrink: 0, cursor: busyId ? 'default' : 'pointer',
                  border: '1px solid var(--border)', fontFamily: 'inherit',
                  background: b.is_pinned ? 'color-mix(in srgb, var(--accent) 16%, transparent)' : 'var(--surface)',
                  color: b.is_pinned ? 'var(--accent)' : 'var(--text-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  opacity: busyId !== null ? 0.6 : 1,
                }}
              >
                {b.is_pinned ? <PinOff size={13} /> : <Pin size={13} />}
              </button>
            </div>
          ))}
        </div>
      )}

      <button
        onClick={onNew}
        className="btn-primary"
        style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '10px 0', fontSize: 13 }}
      >
        <Plus size={14} /> New bundle
      </button>
    </>
  )
}

function MallBundleModal({ onClose }: { onClose: () => void }) {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState<'draft' | 'publish' | 'delete' | null>(null)
  const [pinBusyId, setPinBusyId] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [notice, setNotice] = useState('')
  const [confirmingDelete, setConfirmingDelete] = useState(false)

  const [bundles, setBundles] = useState<MallBundleConfig[]>([])
  // null = the list; a bundle = editing it; 'new' = editing a blank one.
  const [editing, setEditing] = useState<MallBundleConfig | 'new' | null>(null)

  const [editId, setEditId] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [price, setPrice] = useState('')
  const [status, setStatus] = useState<MallBundleStatus>('draft')
  const [isPinned, setIsPinned] = useState(false)
  const [selectedItems, setSelectedItems] = useState<GameGoalMallItem[]>([])

  async function load() {
    const { data, error } = await fetchMallBundles()
    if (error) { setError(error); setLoading(false); return }
    setBundles(data)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  // Resolve saved ids back to name/image for display — searchMallItems only
  // matches by name, so pull the exact rows by id instead.
  async function openEditor(bundle: MallBundleConfig | 'new') {
    setError(''); setNotice(''); setConfirmingDelete(false)
    if (bundle === 'new') {
      setEditId(null); setName(''); setImageUrl(null); setPrice('')
      setStatus('draft'); setIsPinned(false); setSelectedItems([])
      setEditing('new')
      return
    }
    setEditId(bundle.id)
    setName(bundle.name ?? '')
    setImageUrl(bundle.image_url)
    setPrice(bundle.price_gems != null ? String(bundle.price_gems) : '')
    setStatus(bundle.status)
    setIsPinned(bundle.is_pinned)
    setSelectedItems([])
    setEditing(bundle)
    if (bundle.item_ids.length) {
      const { data: rows } = await supabase.from('mall_items').select('id, name, image_url, category').in('id', bundle.item_ids)
      const byId = new Map((rows ?? []).map((r: GameGoalMallItem) => [r.id, r]))
      setSelectedItems(bundle.item_ids.map(id => byId.get(id)).filter((r): r is GameGoalMallItem => !!r))
    }
  }

  function backToList() {
    setEditing(null)
    setError(''); setNotice(''); setConfirmingDelete(false)
  }

  async function handleFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError('')
    const { url, error } = await uploadMallBundleImage(file)
    setUploading(false)
    if (error) { setError(error); return }
    setImageUrl(url)
  }

  // Empty price is meaningful (display-only bundle), so it maps to null
  // rather than 0 — and anything non-numeric is rejected here instead of
  // silently becoming NaN on the way to the RPC.
  function parsedPrice(): { value: number | null; error: string | null } {
    const raw = price.trim()
    if (!raw) return { value: null, error: null }
    if (!/^\d+$/.test(raw)) return { value: null, error: 'Price must be a whole number of Diamonds.' }
    const n = Number(raw)
    if (n <= 0) return { value: null, error: 'Price must be at least 1 Diamond.' }
    return { value: n, error: null }
  }

  async function save(nextStatus: MallBundleStatus) {
    const { value: priceGems, error: priceError } = parsedPrice()
    if (priceError) { setError(priceError); setNotice(''); return }

    setBusy(nextStatus === 'published' ? 'publish' : 'draft')
    setError('')
    setNotice('')
    const { id, error } = await saveMallBundle({
      id: editId,
      name: name.trim() || null,
      imageUrl,
      priceGems,
      itemIds: selectedItems.map(i => i.id),
      status: nextStatus,
    })
    setBusy(null)
    if (error) { setError(error); return }
    if (id) setEditId(id)
    setStatus(nextStatus)
    await load()
    setNotice(nextStatus === 'published'
      ? (priceGems == null
          ? 'Live — but with no price set, players can only browse the items, not buy the bundle.'
          : 'Live — every player can buy this bundle now.')
      : 'Draft saved. Nothing is visible to players yet.')
  }

  async function togglePin(bundle: MallBundleConfig) {
    setPinBusyId(bundle.id)
    setError(''); setNotice('')
    const { error } = await setMallBundlePinned(bundle.id, !bundle.is_pinned)
    setPinBusyId(null)
    if (error) { setError(error); return }
    await load()
    setNotice(bundle.is_pinned
      ? 'Unpinned. Its items no longer show on the Mall page — players tap the banner instead.'
      : `“${bundle.name ?? 'Untitled bundle'}” is pinned — its items now show on the Mall page.`)
  }

  async function handleDelete() {
    if (!editId) { setConfirmingDelete(false); return }
    setBusy('delete')
    setError('')
    setNotice('')
    const { error } = await deleteMallBundle(editId)
    setBusy(null)
    setConfirmingDelete(false)
    if (error) { setError(error); return }
    await load()
    setEditing(null)
    setNotice('Bundle deleted. Players who already bought it keep their items.')
  }

  const isLive = status === 'published'
  const anyBusy = busy !== null || uploading

  return (
    <Modal title="Mall Bundles" onClose={onClose} width={440}>
      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>Loading…</p>
      ) : editing === null ? (
        <>
          {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
          {notice && !error && <p style={{ fontSize: 11.5, color: '#4fd18a', fontWeight: 700, marginBottom: 12, lineHeight: 1.5 }}>{notice}</p>}
          <MallBundleList
            bundles={bundles}
            busyId={pinBusyId}
            onEdit={openEditor}
            onNew={() => openEditor('new')}
            onTogglePin={togglePin}
          />
        </>
      ) : (
        <>
          <button
            onClick={backToList}
            style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', padding: 0, marginBottom: 14, fontSize: 12, fontWeight: 700, color: 'var(--text-dim)', cursor: 'pointer', fontFamily: 'inherit' }}
          >
            <ArrowLeft size={13} /> All bundles
          </button>

          {/* Live/draft state, up top — the first thing worth knowing when
              you open this, and the thing most likely to be misremembered. */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
            <BundleStatusChip status={editId ? status : 'draft'} pinned={isPinned} />
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
              {!editId ? 'Not created yet'
                : isLive ? 'Showing in the Mall right now'
                : 'Not visible to players'}
            </span>
          </div>

          {isLive && !isPinned && (
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '-6px 0 16px', lineHeight: 1.55 }}>
              Not pinned, so the Mall shows this as banner-only — players tap
              it to see the items. Pin it from the list to give it the item
              strip instead.
            </p>
          )}

          <p style={fieldLabel}>Bundle name</p>
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g. The Demon Era"
            maxLength={60}
            style={{ ...inputStyle, marginBottom: 16 }}
          />

          <p style={fieldLabel}>Banner image</p>
          <div style={{ marginBottom: 16 }}>
            <div style={{ width: '100%', aspectRatio: '2/1', borderRadius: 12, overflow: 'hidden', background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {imageUrl ? (
                <img src={imageUrl} alt="Bundle banner" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
              ) : (
                <ImagePlus size={22} style={{ color: 'var(--text-muted)' }} />
              )}
            </div>
            <label
              className="btn-secondary"
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '9px 0', fontSize: 12.5, cursor: uploading ? 'default' : 'pointer', opacity: uploading ? 0.6 : 1 }}
            >
              <Upload size={13} />
              {uploading ? 'Uploading…' : imageUrl ? 'Replace image' : 'Upload image'}
              <input type="file" accept="image/*" onChange={handleFilePick} disabled={uploading} style={{ display: 'none' }} />
            </label>
            {/* The Mall no longer prints the bundle's name or price above
                the artwork — the banner is the whole ad — so whatever the
                name is needs to be legible in the image itself. */}
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '8px 0 0', lineHeight: 1.5 }}>
              This artwork is all players see on the Mall page, so put the
              bundle's title in the image. The name and price below only
              appear inside the bundle sheet.
            </p>
          </div>

          <p style={fieldLabel}>Bundle price — Diamonds</p>
          <input
            value={price}
            onChange={e => setPrice(e.target.value)}
            inputMode="numeric"
            placeholder="e.g. 1200"
            style={{ ...inputStyle, marginBottom: 6 }}
          />
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 16, lineHeight: 1.5 }}>
            One price for everything below, however many items you add. Leave
            it empty to show the artwork and items without a buy-all button.
          </p>

          <p style={fieldLabel}>Items in this bundle</p>
          <div style={{ marginBottom: 16 }}>
            <MallItemMultiSelect selected={selectedItems} onChange={setSelectedItems} />
          </div>

          {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
          {notice && !error && <p style={{ fontSize: 11.5, color: '#4fd18a', fontWeight: 700, marginBottom: 12, lineHeight: 1.5 }}>{notice}</p>}

          <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
            <button
              onClick={() => save('draft')}
              disabled={anyBusy}
              className="btn-secondary"
              style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: anyBusy ? 0.6 : 1 }}
            >
              {busy === 'draft' ? 'Saving…' : 'Save draft'}
            </button>
            <button
              onClick={() => save('published')}
              disabled={anyBusy}
              className="btn-primary"
              style={{ flex: 1, padding: '10px 0', fontSize: 13, opacity: anyBusy ? 0.6 : 1 }}
            >
              {busy === 'publish' ? 'Publishing…' : isLive ? 'Update live' : 'Publish'}
            </button>
          </div>

          {/* Destructive, so it sits apart from the save row and asks once.
              Nothing to delete until the bundle exists server-side. */}
          {editId && (confirmingDelete ? (
            <div style={{ padding: 12, borderRadius: 12, background: 'rgba(255,77,110,0.08)', border: '1px solid rgba(255,77,110,0.25)' }}>
              <p style={{ fontSize: 11.5, color: 'var(--text)', margin: '0 0 10px', lineHeight: 1.5 }}>
                Delete this bundle? It disappears from the Mall immediately
                and its name, artwork, price and item list are gone. Players
                keep anything they already bought.
                {isPinned && ' The pin moves to the newest remaining published bundle.'}
              </p>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setConfirmingDelete(false)} disabled={anyBusy} className="btn-secondary" style={{ flex: 1, padding: '8px 0', fontSize: 12 }}>Cancel</button>
                <button
                  onClick={handleDelete}
                  disabled={anyBusy}
                  style={{ flex: 1, padding: '8px 0', fontSize: 12, fontWeight: 700, borderRadius: 10, border: 'none', cursor: 'pointer', fontFamily: 'inherit', background: 'var(--red)', color: '#fff', opacity: anyBusy ? 0.6 : 1 }}
                >
                  {busy === 'delete' ? 'Deleting…' : 'Delete bundle'}
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setConfirmingDelete(true)}
              disabled={anyBusy}
              style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '9px 0', fontSize: 12.5, fontWeight: 600, borderRadius: 10, border: '1px solid rgba(255,77,110,0.25)', background: 'transparent', color: 'var(--red)', cursor: 'pointer', fontFamily: 'inherit', opacity: anyBusy ? 0.6 : 1 }}
            >
              <Trash2 size={13} /> Delete bundle
            </button>
          ))}
        </>
      )}
    </Modal>
  )
}

// ── Mall item price + timer editor ──────────────────────────────────────

const ITEM_CATEGORIES: { value: string; label: string }[] = [
  { value: 'avatar_skin', label: 'Avatars' },
  { value: 'profile_pic', label: 'Profile pics' },
  { value: 'banner', label: 'Banners' },
  { value: 'chat_theme', label: 'Chat themes' },
  { value: 'profile_effect', label: 'Profile effects' },
  { value: 'pvp_card', label: 'Battle cards' },
  { value: 'xp_booster', label: 'XP boosters' },
  { value: 'rank_shield', label: 'Rank shields' },
  { value: 'streak_freeze', label: 'Streak freezes' },
]

/** Profile card effects are NOT stored under the 'profile_effect'
 *  category, despite that value existing in mall_items_category_check.
 *  Every live one is a profile_pic row tagged with this sub_category, and
 *  that tag is what the rest of the app actually keys off:
 *    - Mall.tsx's effects sub-tab filters
 *      `category === 'profile_pic' && sub_category === 'Profile card effect'`
 *    - Mall.tsx's `isCardEffect` (poster-only art + the full-screen Preview)
 *    - Inventory.tsx's `equipSlot` / the equip path that writes
 *      profiles.equipped_profile_effect_url
 *  A row saved as category 'profile_effect' with a null sub_category
 *  matches none of those, so it's invisible in the Mall and unequippable.
 *  The picker keeps "Profile effects" as its own entry because that's how
 *  an admin thinks about it; the translation to the real storage shape
 *  happens on save (and back again on edit), same as banners forcing
 *  sub_category 'album'. */
const CARD_EFFECT_SUB_CATEGORY = 'Profile card effect'

/** Category filter that understands the storage shape above: picking
 *  "Profile effects" searches profile_pic rows and keeps only the tagged
 *  ones, and picking "Profile pics" excludes them so effects don't show
 *  up in both lists. Everything else passes straight through. */
async function searchItemsForCategory(query: string, category: string | null) {
  if (category !== 'profile_effect' && category !== 'profile_pic') {
    return adminSearchMallItems(query, category)
  }
  const wantEffects = category === 'profile_effect'
  const { data, error } = await adminSearchMallItems(query, 'profile_pic')
  return {
    data: data.filter(i => (i.sub_category === CARD_EFFECT_SUB_CATEGORY) === wantEffects),
    error,
  }
}

/** Matches the mall_items_rarity_check DB constraint exactly — the RPC
 *  will reject anything else, so the picker only offers valid values. */
const RARITIES = ['Common', 'Rare', 'Epic', 'Mythic'] as const

/** Same colors as RARITY_META in Mall.tsx, copied rather than imported
 *  so the preview card matches what players actually see without
 *  reaching across features for a display-only constant. */
const PREVIEW_RARITY_META: Record<string, { color: string; bg: string }> = {
  Common: { color: '#888899', bg: 'rgba(136,136,153,0.14)' },
  Rare:   { color: '#4f8ef7', bg: 'rgba(79,142,247,0.14)' },
  Epic:   { color: '#9b6dff', bg: 'rgba(155,109,255,0.14)' },
  Mythic: { color: 'var(--accent)', bg: 'linear-gradient(135deg,color-mix(in srgb, var(--accent) 18%, transparent),rgba(245,197,66,0.14))' },
}

/** Quick presets for the common case — "put this on a 24 hour timer" —
 *  measured from the moment Apply is tapped, not from midnight. The custom
 *  field below is there for anything that needs an exact wall-clock end. */
const TIMER_PRESETS: { label: string; hours: number }[] = [
  { label: '1 hour', hours: 1 },
  { label: '6 hours', hours: 6 },
  { label: '24 hours', hours: 24 },
  { label: '3 days', hours: 72 },
  { label: '7 days', hours: 168 },
  { label: '30 days', hours: 720 },
]

/** ISO → the `YYYY-MM-DDTHH:mm` shape datetime-local needs, in the admin's
 *  own timezone. Going through toISOString() here would silently shift the
 *  displayed time by the UTC offset. */
function isoToLocalInput(iso: string | null): string {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function describeTimer(availableUntil: string | null): { text: string; tone: 'none' | 'live' | 'ended' } {
  if (!availableUntil) return { text: 'No timer', tone: 'none' }
  const ms = new Date(availableUntil).getTime() - Date.now()
  if (ms <= 0) return { text: 'Ended', tone: 'ended' }
  const mins = Math.floor(ms / 60_000)
  const days = Math.floor(mins / 1440)
  const hours = Math.floor((mins % 1440) / 60)
  if (days > 0) return { text: `${days}d ${hours}h left`, tone: 'live' }
  if (hours > 0) return { text: `${hours}h ${mins % 60}m left`, tone: 'live' }
  return { text: `${Math.max(1, mins)}m left`, tone: 'live' }
}

function TimerChip({ availableUntil }: { availableUntil: string | null }) {
  const { text, tone } = describeTimer(availableUntil)
  if (tone === 'none') return null
  const color = tone === 'ended' ? 'var(--red)' : 'var(--accent)'
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 3,
      padding: '2px 6px', borderRadius: 20, flexShrink: 0,
      background: `color-mix(in srgb, ${color} 12%, transparent)`,
      border: `1px solid color-mix(in srgb, ${color} 30%, transparent)`,
      color, fontSize: 9, fontWeight: 800,
    }}>
      {tone === 'ended' ? <Hourglass size={9} /> : <Timer size={9} />} {text}
    </span>
  )
}

/** Badge for a manual admin lock — separate from TimerChip, since an item
 *  can be locked with or without a countdown running. */
function LockChip({ locked }: { locked: boolean }) {
  if (!locked) return null
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 3,
      padding: '2px 6px', borderRadius: 20, flexShrink: 0,
      background: 'rgba(255,79,79,0.12)',
      border: '1px solid rgba(255,79,79,0.3)',
      color: 'var(--red)', fontSize: 9, fontWeight: 800,
    }}>
      <Lock size={9} /> Locked
    </span>
  )
}

function MallItemEditorModal({ onClose }: { onClose: () => void }) {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<string | null>(null)
  const [results, setResults] = useState<AdminMallItem[]>([])
  const [searching, setSearching] = useState(true)
  const [selected, setSelected] = useState<AdminMallItem | null>(null)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState('')

  // Draft state for the selected item
  const [currency, setCurrency] = useState<'gems' | 'orbs'>('gems')
  const [priceText, setPriceText] = useState('')
  const [untilLocal, setUntilLocal] = useState('')
  const [savingPrice, setSavingPrice] = useState(false)
  const [savingTimer, setSavingTimer] = useState(false)
  const [lockMessage, setLockMessage] = useState('')
  const [savingLock, setSavingLock] = useState(false)

  function runSearch() {
    setSearching(true)
    searchItemsForCategory(query, category).then(({ data, error: err }) => {
      setResults(data)
      if (err) setError(err)
      setSearching(false)
    })
  }

  useEffect(() => {
    const t = setTimeout(runSearch, query ? 250 : 0)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, category])

  function pick(item: AdminMallItem) {
    setSelected(item)
    setError('')
    setSaved('')
    setCurrency(item.price_orbs != null ? 'orbs' : 'gems')
    setPriceText(String(item.price_orbs ?? item.price_gems ?? ''))
    setUntilLocal(isoToLocalInput(item.available_until))
    setLockMessage(item.lock_message ?? '')
  }

  /** Refreshes the list *and* the open editor from the server after a
   *  write, so the row and the form can't drift from what was stored. */
  function refreshAfterSave(itemId: string) {
    searchItemsForCategory(query, category).then(({ data }) => {
      setResults(data)
      const fresh = data.find(i => i.id === itemId)
      if (fresh) setSelected(fresh)
    })
  }

  async function savePrice() {
    if (!selected) return
    const trimmed = priceText.trim()
    const parsed = trimmed === '' ? null : Number(trimmed)
    if (parsed != null && (!Number.isFinite(parsed) || !Number.isInteger(parsed) || parsed < 0)) {
      setError('Price must be a whole number, 0 or more.')
      return
    }
    setSavingPrice(true)
    setError('')
    setSaved('')
    const { pending, error: err } = await setMallItemPrice(
      selected.id,
      currency === 'gems' ? parsed : null,
      currency === 'orbs' ? parsed : null,
    )
    setSavingPrice(false)
    if (err) { setError(err); return }
    if (pending) { setSaved(PENDING_MESSAGE); return }
    setSaved('Price updated — live in the Mall now.')
    refreshAfterSave(selected.id)
  }

  async function saveTimer(iso: string | null) {
    if (!selected) return
    setSavingTimer(true)
    setError('')
    setSaved('')
    const { error: err } = await setMallItemTimer(selected.id, iso)
    setSavingTimer(false)
    if (err) { setError(err); return }
    setSaved(iso ? 'Timer set — the item locks itself when it runs out.' : 'Timer removed — the item is available again.')
    setUntilLocal(isoToLocalInput(iso))
    refreshAfterSave(selected.id)
  }

  /** Locks the item with the current draft message. Unlike the timer,
   *  locking requires a non-empty message — the point is players see why. */
  async function lockItem() {
    if (!selected) return
    if (!lockMessage.trim()) { setError('Write something for players to see, e.g. "Limited time item".'); return }
    setSavingLock(true)
    setError('')
    setSaved('')
    const { error: err } = await setMallItemLock(selected.id, true, lockMessage.trim())
    setSavingLock(false)
    if (err) { setError(err); return }
    setSaved('Locked — the purchase button is disabled in the Mall now.')
    refreshAfterSave(selected.id)
  }

  async function unlockItem() {
    if (!selected) return
    setSavingLock(true)
    setError('')
    setSaved('')
    const { error: err } = await setMallItemLock(selected.id, false, null)
    setSavingLock(false)
    if (err) { setError(err); return }
    setSaved('Open — players can buy it again.')
    setLockMessage('')
    refreshAfterSave(selected.id)
  }

  function applyPreset(hours: number) {
    saveTimer(new Date(Date.now() + hours * 3_600_000).toISOString())
  }

  function applyCustom() {
    if (!untilLocal) { setError('Pick a date and time first.'); return }
    const d = new Date(untilLocal)
    if (Number.isNaN(d.getTime())) { setError('That date could not be read.'); return }
    saveTimer(d.toISOString())
  }

  const priceLabel = currency === 'gems' ? 'Diamonds' : 'Orbs'

  return (
    <Modal title="Item price, lock & timer" onClose={onClose} width={460}>
      {!selected ? (
        <>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.5 }}>
            Pick an item to change what it costs, lock it with a message of your own, or put it on a countdown.
            Neither locking nor an expired countdown deletes the item — both leave it disabled with an explanation,
            and you can lift them any time.
          </p>

          <div style={{ position: 'relative', marginBottom: 10 }}>
            <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search item name…"
              style={{ ...inputStyle, paddingLeft: 30 }}
            />
          </div>

          <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 8, marginBottom: 10 }}>
            {[{ value: null, label: 'All' }, ...ITEM_CATEGORIES].map(c => {
              const active = category === c.value
              return (
                <button
                  key={c.label}
                  type="button"
                  onClick={() => setCategory(c.value)}
                  style={{
                    flexShrink: 0, padding: '5px 10px', borderRadius: 20, cursor: 'pointer',
                    background: active ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
                    border: active ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                    color: active ? 'var(--accent)' : 'var(--text-dim)',
                    fontSize: 11, fontWeight: 700, whiteSpace: 'nowrap',
                  }}
                >
                  {c.label}
                </button>
              )
            })}
          </div>

          <div style={{ maxHeight: 320, overflowY: 'auto', margin: '0 -4px' }}>
            {searching ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '12px 4px' }}>Loading…</p>
            ) : results.length === 0 ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '12px 4px' }}>No items match that.</p>
            ) : results.map(item => (
              <div
                key={item.id}
                onClick={(e) => { ripple(e); pick(item) }}
                className="ripple-wrap"
                style={{
                  display: 'flex', alignItems: 'center', gap: 10, padding: '9px 8px',
                  borderRadius: 12, cursor: 'pointer', marginBottom: 2,
                  opacity: item.is_active ? 1 : 0.5,
                }}
              >
                <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {item.image_url
                    ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : <ImagePlus size={13} style={{ color: 'var(--text-muted)' }} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <p style={{ fontSize: 12.5, color: 'var(--text)', margin: 0, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</p>
                    <LockChip locked={item.is_locked} />
                    <TimerChip availableUntil={item.available_until} />
                  </div>
                  <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: 0 }}>
                    {item.category.replace(/_/g, ' ')}
                    {!item.is_active && ' · inactive'}
                  </p>
                </div>
                <div style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text-dim)', flexShrink: 0 }}>
                  {item.price_gems != null ? `💎 ${item.price_gems.toLocaleString()}`
                    : item.price_orbs != null ? `◍ ${item.price_orbs.toLocaleString()}`
                    : item.unlock_xp != null ? `${item.unlock_xp.toLocaleString()} XP`
                    : '—'}
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <button
            type="button"
            onClick={(e) => { ripple(e); setSelected(null); setError(''); setSaved('') }}
            style={{
              display: 'flex', alignItems: 'center', gap: 5, marginBottom: 14,
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              color: 'var(--text-dim)', fontSize: 11.5, fontWeight: 700,
            }}
          >
            <ArrowLeft size={13} /> All items
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 18 }}>
            <div style={{ width: 48, height: 48, borderRadius: 12, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {selected.image_url
                ? <img src={selected.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <ImagePlus size={16} style={{ color: 'var(--text-muted)' }} />}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', margin: 0 }}>{selected.name}</p>
                <LockChip locked={selected.is_locked} />
                <TimerChip availableUntil={selected.available_until} />
              </div>
              <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 0' }}>
                {selected.rarity} · {selected.category.replace(/_/g, ' ')} · owned by {selected.owner_count.toLocaleString()}
              </p>
            </div>
          </div>

          {/* ── Price ─────────────────────────────────────────────── */}
          <p style={fieldLabel}>PRICE</p>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            {(['gems', 'orbs'] as const).map(c => (
              <button
                key={c}
                type="button"
                onClick={() => setCurrency(c)}
                style={{
                  flex: 1, padding: '7px 10px', borderRadius: 10, cursor: 'pointer',
                  background: currency === c ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
                  border: currency === c ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                  color: currency === c ? 'var(--accent)' : 'var(--text-dim)',
                  fontSize: 12, fontWeight: 700,
                }}
              >
                {c === 'gems' ? '💎 Diamonds' : '◍ Orbs'}
              </button>
            ))}
          </div>
          <input
            value={priceText}
            onChange={e => setPriceText(e.target.value.replace(/[^0-9]/g, ''))}
            inputMode="numeric"
            placeholder={`Price in ${priceLabel} — blank for no price`}
            style={{ ...inputStyle, marginBottom: 8 }}
          />
          {selected.owner_count > 0 && (
            <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '0 0 8px', lineHeight: 1.45 }}>
              {selected.owner_count.toLocaleString()} {selected.owner_count === 1 ? 'player has' : 'players have'} already bought
              this. Changing the price only affects future purchases — nobody is charged again or refunded.
            </p>
          )}
          <button
            type="button"
            onClick={(e) => { ripple(e); savePrice() }}
            disabled={savingPrice}
            className="ripple-wrap"
            style={{
              width: '100%', padding: 11, borderRadius: 12, border: 'none', marginBottom: 20,
              background: savingPrice ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
              color: savingPrice ? 'var(--text-muted)' : '#fff',
              fontSize: 13, fontWeight: 800, cursor: savingPrice ? 'default' : 'pointer',
            }}
          >
            {savingPrice ? 'Saving…' : 'Save price'}
          </button>

          {/* ── Lock ──────────────────────────────────────────────── */}
          <p style={fieldLabel}>LOCK</p>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 10px', lineHeight: 1.5 }}>
            {selected.is_locked
              ? 'Locked — the purchase button is disabled in the Mall, showing the message below.'
              : 'Open — players can buy it normally. Locking is separate from the countdown below; use it for an instant on/off with your own message.'}
          </p>
          <input
            value={lockMessage}
            onChange={e => setLockMessage(e.target.value)}
            maxLength={80}
            placeholder='e.g. "Limited time item"'
            style={{ ...inputStyle, marginBottom: 10 }}
          />
          <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
            {selected.is_locked ? (
              <button
                type="button"
                onClick={(e) => { ripple(e); unlockItem() }}
                disabled={savingLock}
                className="ripple-wrap"
                style={{
                  flex: 1, padding: 11, borderRadius: 12, border: 'none',
                  background: savingLock ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
                  color: savingLock ? 'var(--text-muted)' : '#fff',
                  fontSize: 13, fontWeight: 800, cursor: savingLock ? 'default' : 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                }}
              >
                <Unlock size={13} /> {savingLock ? 'Saving…' : 'Open'}
              </button>
            ) : (
              <button
                type="button"
                onClick={(e) => { ripple(e); lockItem() }}
                disabled={savingLock}
                className="ripple-wrap"
                style={{
                  flex: 1, padding: 11, borderRadius: 12, border: 'none',
                  background: savingLock ? 'var(--surface3)' : 'var(--red)',
                  color: savingLock ? 'var(--text-muted)' : '#fff',
                  fontSize: 13, fontWeight: 800, cursor: savingLock ? 'default' : 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                }}
              >
                <Lock size={13} /> {savingLock ? 'Saving…' : 'Lock'}
              </button>
            )}
          </div>

          {/* ── Timer ─────────────────────────────────────────────── */}
          <p style={fieldLabel}>LIMITED TIME</p>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 10px', lineHeight: 1.5 }}>
            {selected.available_until
              ? describeTimer(selected.available_until).tone === 'ended'
                ? `Ended ${new Date(selected.available_until).toLocaleString()}. It's greyed out in the Mall right now.`
                : `Ends ${new Date(selected.available_until).toLocaleString()}.`
              : 'No timer — this item is always available.'}
          </p>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
            {TIMER_PRESETS.map(p => (
              <button
                key={p.label}
                type="button"
                onClick={(e) => { ripple(e); applyPreset(p.hours) }}
                disabled={savingTimer}
                style={{
                  padding: '6px 11px', borderRadius: 20, cursor: savingTimer ? 'default' : 'pointer',
                  background: 'var(--surface2)', border: '1px solid var(--border)',
                  color: 'var(--text-dim)', fontSize: 11, fontWeight: 700,
                }}
              >
                {p.label}
              </button>
            ))}
          </div>

          <p style={{ ...fieldLabel, marginTop: 4 }}>OR AN EXACT END TIME</p>
          <input
            type="datetime-local"
            value={untilLocal}
            onChange={e => setUntilLocal(e.target.value)}
            style={{ ...inputStyle, marginBottom: 8 }}
          />
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={(e) => { ripple(e); applyCustom() }}
              disabled={savingTimer}
              className="ripple-wrap"
              style={{
                flex: 1, padding: 11, borderRadius: 12, border: 'none',
                background: savingTimer ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
                color: savingTimer ? 'var(--text-muted)' : '#fff',
                fontSize: 13, fontWeight: 800, cursor: savingTimer ? 'default' : 'pointer',
              }}
            >
              {savingTimer ? 'Saving…' : 'Set timer'}
            </button>
            {selected.available_until && (
              <button
                type="button"
                onClick={(e) => { ripple(e); saveTimer(null) }}
                disabled={savingTimer}
                style={{
                  padding: '11px 14px', borderRadius: 12, cursor: savingTimer ? 'default' : 'pointer',
                  background: 'var(--surface2)', border: '1px solid var(--border)',
                  color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, flexShrink: 0,
                }}
              >
                Remove
              </button>
            )}
          </div>
        </>
      )}

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 12 }}>{error}</p>}
      {saved && <p style={{ fontSize: 11.5, color: 'var(--green)', marginTop: 12 }}>{saved}</p>}
    </Modal>
  )
}

const emptyDraft: MallItemDraft = {
  id: null, category: 'profile_pic', name: '', description: '', subCategory: null,
  rarity: 'Common', imageUrl: null, animatedUrl: null,
  priceGems: null, priceOrbs: null, unlockXp: null, isConsumable: false,
}

/** Create-or-edit for everything price/lock/timer above doesn't touch —
 *  name, description, category, rarity, art. Opens straight into a blank
 *  draft for "new item"; picking an existing item from the search list
 *  loads it into the same form. Uploaded art goes to whichever bucket
 *  that category's existing images actually live in (see
 *  uploadMallItemImage) rather than one bucket for everything. */
/** A rough approximation of the item's Mall tile — same rarity colors,
 *  same "poster wins, video is only the fallback" rule CardThumb in
 *  Mall.tsx uses — so admins can see roughly how something will look
 *  before it goes live, without leaving the editor. Not pixel-identical
 *  to the real Mall grid, just enough to catch a wrong image, a missing
 *  price, or a name that's too long before saving. */
function MallItemPreviewCard({ draft, priceLabel, priceText }: {
  draft: MallItemDraft
  priceLabel: string
  priceText: string
}) {
  const meta = PREVIEW_RARITY_META[draft.rarity] ?? PREVIEW_RARITY_META.Common
  // Mall tiles never animate: CardThumb uses image_url whenever there is
  // one, and only when there's no poster at all does it fall back to the
  // video element with no autoplay, so the browser just paints frame 1.
  // Preferring animatedUrl here (as this preview used to) made an item
  // with a perfectly good poster look like a playing video in the editor,
  // which is not what the Mall grid ever shows.
  const isVideoFile = !draft.imageUrl && !!draft.animatedUrl && /\.(mp4|webm)$/i.test(draft.animatedUrl)
  const mediaSrc = draft.imageUrl || draft.animatedUrl

  return (
    <div style={{ marginBottom: 18 }}>
      <p style={fieldLabel}>PREVIEW</p>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12, padding: 12, borderRadius: 14,
        background: 'var(--surface2)', border: '1px solid var(--border)',
      }}>
        <div style={{ width: 52, height: 52, borderRadius: 12, background: 'var(--surface3)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {mediaSrc ? (
            isVideoFile
              ? <video src={mediaSrc} muted playsInline preload="metadata" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              : <img src={mediaSrc} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : <ImagePlus size={16} style={{ color: 'var(--text-muted)' }} />}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {draft.name.trim() || 'Untitled item'}
            </p>
            <span style={{ fontSize: 9.5, fontWeight: 700, padding: '2px 7px', borderRadius: 8, background: meta.bg, color: meta.color, whiteSpace: 'nowrap' }}>
              {draft.rarity}
            </span>
          </div>
          {draft.description.trim() && (
            <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {draft.description.trim()}
            </p>
          )}
        </div>
        <div style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text-dim)', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4 }}>
          {priceText.trim()
            ? (priceLabel === 'XP to unlock'
                ? <><Zap size={12} color="#f5c542" /> {Number(priceText).toLocaleString()} XP</>
                : `${priceLabel === 'Diamonds' ? '💎' : '◍'} ${Number(priceText).toLocaleString()}`)
            : '—'}
        </div>
      </div>
      {draft.category === 'profile_effect' && (!draft.imageUrl || !draft.animatedUrl) && (
        <p style={{ fontSize: 10.5, color: 'var(--red)', margin: '6px 0 0', lineHeight: 1.4 }}>
          Profile effects need both a poster image and a video/GIF — this one is missing {!draft.imageUrl && !draft.animatedUrl ? 'both' : !draft.imageUrl ? 'the poster' : 'the video/GIF'}.
        </p>
      )}
    </div>
  )
}

/** Colour variants for a saved banner / profile pic. Only rendered for an
 *  item that already exists — a variant row needs an item_id to hang off,
 *  so there's nothing to attach to until the item itself has been saved.
 *  Card effects are excluded here and again in admin_save_item_variant:
 *  they're .mp4, and a "colour" of a video means five more video uploads. */
function ItemVariantsEditor({ itemId, category, subCategory }: {
  itemId: string
  category: string
  subCategory: string | null
}) {
  const [variants, setVariants] = useState<AdminItemVariant[]>([])
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [error, setError] = useState('')
  // A colour being added: image first (so the admin sees what they picked),
  // then a name and price before it can be saved.
  const [pendingImage, setPendingImage] = useState<string | null>(null)
  const [pendingName, setPendingName] = useState('')
  const [pendingPrice, setPendingPrice] = useState('')
  const [saving, setSaving] = useState(false)

  const eligible = (category === 'banner' || category === 'profile_pic')
    && subCategory !== CARD_EFFECT_SUB_CATEGORY

  function reload() {
    fetchItemVariantsAdmin(itemId).then(({ data, error: err }) => {
      setVariants(data)
      if (err) setError(err)
      setLoading(false)
    })
  }

  useEffect(() => {
    if (!eligible) { setLoading(false); return }
    reload()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemId, eligible])

  if (!eligible) return null

  async function handleVariantImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError('')
    const { url, error: err } = await uploadMallItemImage(file, category)
    setUploading(false)
    if (err) { setError(err); return }
    setPendingImage(url)
  }

  async function addVariant() {
    const price = Number(pendingPrice.trim())
    if (!pendingImage) { setError('Upload the image for this colour first.'); return }
    if (!pendingName.trim()) { setError('Give the colour a name.'); return }
    if (!Number.isInteger(price) || price < 0) { setError('Colour price must be a whole number, 0 or more.'); return }
    setSaving(true)
    setError('')
    const { error: err } = await saveItemVariant({
      id: null, itemId, name: pendingName.trim(), imageUrl: pendingImage,
      priceGems: price, sortOrder: variants.length,
    })
    setSaving(false)
    if (err) { setError(err); return }
    setPendingImage(null); setPendingName(''); setPendingPrice('')
    reload()
  }

  async function removeVariant(id: string) {
    setBusyId(id)
    setError('')
    const { error: err } = await deleteItemVariant(id)
    setBusyId(null)
    if (err) { setError(err); return }
    reload()
  }

  const atCap = variants.length >= 5

  return (
    <div style={{ marginBottom: 18, padding: 14, borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 4 }}>
        <Palette size={14} style={{ color: 'var(--accent)' }} />
        <p style={{ ...fieldLabel, margin: 0 }}>COLOURS ({variants.length}/5)</p>
      </div>
      <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 12px', lineHeight: 1.45 }}>
        Extra colours a player can buy for this item — Diamonds only, and only once they already own the item itself. The original colour stays theirs either way.
      </p>

      {loading ? (
        <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0 }}>Loading…</p>
      ) : (
        <>
          {variants.map(v => (
            <div key={v.id} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, overflow: 'hidden', background: 'var(--surface3)', flexShrink: 0 }}>
                <img src={v.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 12, fontWeight: 800, color: 'var(--text)', margin: 0 }}>{v.name}</p>
                <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: 0 }}>💎 {v.price_gems.toLocaleString()}</p>
              </div>
              <button
                type="button"
                disabled={busyId === v.id}
                onClick={(e) => { ripple(e); removeVariant(v.id) }}
                aria-label={`Delete ${v.name}`}
                style={{
                  width: 32, height: 32, borderRadius: 9, flexShrink: 0, cursor: 'pointer',
                  background: 'var(--surface3)', border: '1px solid var(--border)', color: 'var(--red)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}

          {atCap ? (
            <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '8px 0 0' }}>
              That's the cap of 5. Delete one to add another.
            </p>
          ) : (
            <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, overflow: 'hidden', background: 'var(--surface3)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {pendingImage
                    ? <img src={pendingImage} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : <ImagePlus size={15} style={{ color: 'var(--text-muted)' }} />}
                </div>
                <label
                  className="ripple-wrap"
                  style={{
                    flex: 1, padding: '9px 12px', borderRadius: 11, cursor: uploading ? 'default' : 'pointer',
                    background: 'var(--surface3)', border: '1px solid var(--border)',
                    color: 'var(--text-dim)', fontSize: 11.5, fontWeight: 700,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  }}
                >
                  <Upload size={12} /> {uploading ? 'Uploading…' : pendingImage ? 'Replace colour image' : 'Upload colour image'}
                  <input type="file" accept="image/*" onChange={handleVariantImage} disabled={uploading} style={{ display: 'none' }} />
                </label>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  value={pendingName}
                  onChange={e => setPendingName(e.target.value)}
                  maxLength={30}
                  placeholder="Colour name"
                  style={{ ...inputStyle, flex: 1, marginBottom: 8 }}
                />
                <input
                  value={pendingPrice}
                  onChange={e => setPendingPrice(e.target.value.replace(/[^0-9]/g, ''))}
                  inputMode="numeric"
                  placeholder="💎"
                  style={{ ...inputStyle, width: 90, marginBottom: 8 }}
                />
              </div>
              <button
                type="button"
                disabled={saving}
                onClick={(e) => { ripple(e); addVariant() }}
                className="ripple-wrap"
                style={{
                  width: '100%', padding: 10, borderRadius: 11, border: 'none', cursor: saving ? 'default' : 'pointer',
                  background: 'var(--surface3)', color: 'var(--text)', fontSize: 12, fontWeight: 800,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                }}
              >
                <Plus size={13} /> {saving ? 'Adding…' : 'Add colour'}
              </button>
            </div>
          )}
        </>
      )}

      {error && <p style={{ fontSize: 10.5, color: 'var(--red)', margin: '8px 0 0', lineHeight: 1.4 }}>{error}</p>}
    </div>
  )
}

function MallItemCreateModal({ onClose }: { onClose: () => void }) {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<string | null>(null)
  const [results, setResults] = useState<AdminMallItem[]>([])
  const [searching, setSearching] = useState(true)
  const [mode, setMode] = useState<'list' | 'form'>('list')

  const [draft, setDraft] = useState<MallItemDraft>(emptyDraft)
  const [priceText, setPriceText] = useState('')
  const [currency, setCurrency] = useState<'gems' | 'orbs' | 'xp'>('gems')
  const [uploading, setUploading] = useState(false)
  const [videoUploading, setVideoUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [togglingActive, setTogglingActive] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState('')

  function runSearch() {
    setSearching(true)
    searchItemsForCategory(query, category).then(({ data, error: err }) => {
      setResults(data)
      if (err) setError(err)
      setSearching(false)
    })
  }

  useEffect(() => {
    const t = setTimeout(runSearch, query ? 250 : 0)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, category])

  function startNew() {
    setDraft({ ...emptyDraft, category: category ?? 'profile_pic' })
    setPriceText('')
    setCurrency('gems')
    setError(''); setSaved('')
    setMode('form')
  }

  function editExisting(item: AdminMallItem) {
    setDraft({
      id: item.id,
      // Existing effects are stored as profile_pic + the effect
      // sub_category (see CARD_EFFECT_SUB_CATEGORY) — show them under
      // "Profile effects" in the picker so editing one doesn't silently
      // demote it to a normal profile pic on the next save.
      category: item.sub_category === CARD_EFFECT_SUB_CATEGORY ? 'profile_effect' : item.category,
      name: item.name,
      description: item.description,
      subCategory: item.sub_category,
      rarity: item.rarity,
      imageUrl: item.image_url,
      animatedUrl: item.animated_url,
      priceGems: item.price_gems,
      priceOrbs: item.price_orbs,
      unlockXp: item.unlock_xp,
      isConsumable: item.is_consumable,
    })
    setCurrency(item.unlock_xp != null ? 'xp' : item.price_orbs != null ? 'orbs' : 'gems')
    setPriceText(String(item.unlock_xp ?? item.price_orbs ?? item.price_gems ?? ''))
    setError(''); setSaved('')
    setMode('form')
  }

  function backToList() {
    setMode('list')
    setError(''); setSaved('')
    runSearch()
  }

  async function handleFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError('')
    const { url, error: err } = await uploadMallItemImage(file, draft.category)
    setUploading(false)
    if (err) { setError(err); return }
    setDraft(d => ({ ...d, imageUrl: url }))
  }

  async function handleVideoFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setVideoUploading(true)
    setError('')
    const { url, error: err } = await uploadMallItemVideo(file, draft.category)
    setVideoUploading(false)
    if (err) { setError(err); return }
    setDraft(d => ({ ...d, animatedUrl: url }))
  }

  async function save() {
    if (!draft.name.trim()) { setError('Give the item a name.'); return }
    if (draft.category === 'profile_effect' && (!draft.imageUrl || !draft.animatedUrl)) {
      setError('Profile effects need both a poster image and a video/GIF — equipping reads the video directly.')
      return
    }
    const trimmedPrice = priceText.trim()
    const parsedPrice = trimmedPrice === '' ? null : Number(trimmedPrice)
    if (parsedPrice != null && (!Number.isFinite(parsedPrice) || !Number.isInteger(parsedPrice) || parsedPrice < 0)) {
      setError(currency === 'xp' ? 'XP required must be a whole number, 0 or more.' : 'Price must be a whole number, 0 or more.')
      return
    }
    setSaving(true)
    setError(''); setSaved('')
    // Equipping a banner writes profiles.banner_url only when sub_category
    // is 'album' — there's no form field for this, so it must be forced
    // here or new banners save with sub_category null and silently fail
    // to equip (is_equipped flips true but the banner never shows).
    //
    // Profile effects need the same forcing for a bigger reason: the app
    // has no concept of a 'profile_effect' category at all (see
    // CARD_EFFECT_SUB_CATEGORY). Saving one under that category produced a
    // row the Mall never lists and Inventory can never equip.
    const isCardEffect = draft.category === 'profile_effect'
    const category = isCardEffect ? 'profile_pic' : draft.category
    const subCategory = isCardEffect
      ? CARD_EFFECT_SUB_CATEGORY
      : draft.category === 'banner' ? 'album' : draft.subCategory
    const { id, error: err } = await saveMallItem({
      ...draft,
      category,
      subCategory,
      priceGems: currency === 'gems' ? parsedPrice : null,
      priceOrbs: currency === 'orbs' ? parsedPrice : null,
      unlockXp: currency === 'xp' ? parsedPrice : null,
    })
    setSaving(false)
    if (err) { setError(err); return }
    setSaved(draft.id ? 'Saved — changes are live in the Mall now.' : 'Created — it\'s live in the Mall now.')
    if (id) setDraft(d => ({ ...d, id }))
  }

  async function toggleActive() {
    if (!draft.id) return
    setTogglingActive(true)
    setError(''); setSaved('')
    const nextActive = false // this button only shows for active items — see render below
    const { error: err } = await setMallItemActive(draft.id, nextActive)
    setTogglingActive(false)
    if (err) { setError(err); return }
    setSaved('Pulled off the shelf — still owned by anyone who already bought it, just not buyable anymore.')
    runSearch()
  }

  async function restoreActive() {
    if (!draft.id) return
    setTogglingActive(true)
    setError(''); setSaved('')
    const { error: err } = await setMallItemActive(draft.id, true)
    setTogglingActive(false)
    if (err) { setError(err); return }
    setSaved('Back on the shelf — players can buy it again.')
    runSearch()
  }

  const priceLabel = currency === 'gems' ? 'Diamonds' : currency === 'orbs' ? 'Orbs' : 'XP to unlock'
  // We only know an item's current is_active from the search list, not
  // the draft — refresh from the last search results when present.
  const liveRow = draft.id ? results.find(r => r.id === draft.id) : undefined

  return (
    <Modal title={mode === 'list' ? 'Create or edit item' : (draft.id ? 'Edit item' : 'New item')} onClose={onClose} width={460}>
      {mode === 'list' ? (
        <>
          <button
            type="button"
            onClick={(e) => { ripple(e); startNew() }}
            className="ripple-wrap"
            style={{
              width: '100%', padding: 11, borderRadius: 12, border: 'none', marginBottom: 14,
              background: 'linear-gradient(135deg,var(--accent),var(--accent2))', color: '#fff',
              fontSize: 13, fontWeight: 800, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            }}
          >
            <Plus size={14} /> New item
          </button>

          <div style={{ position: 'relative', marginBottom: 10 }}>
            <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search item name to edit…"
              style={{ ...inputStyle, paddingLeft: 30 }}
            />
          </div>

          <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 8, marginBottom: 10 }}>
            {[{ value: null, label: 'All' }, ...ITEM_CATEGORIES].map(c => {
              const active = category === c.value
              return (
                <button
                  key={c.label}
                  type="button"
                  onClick={() => setCategory(c.value)}
                  style={{
                    flexShrink: 0, padding: '5px 10px', borderRadius: 20, cursor: 'pointer',
                    background: active ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
                    border: active ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                    color: active ? 'var(--accent)' : 'var(--text-dim)',
                    fontSize: 11, fontWeight: 700, whiteSpace: 'nowrap',
                  }}
                >
                  {c.label}
                </button>
              )
            })}
          </div>

          <div style={{ maxHeight: 300, overflowY: 'auto', margin: '0 -4px' }}>
            {searching ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '12px 4px' }}>Loading…</p>
            ) : results.length === 0 ? (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '12px 4px' }}>No items match that.</p>
            ) : results.map(item => (
              <div
                key={item.id}
                onClick={(e) => { ripple(e); editExisting(item) }}
                className="ripple-wrap"
                style={{
                  display: 'flex', alignItems: 'center', gap: 10, padding: '9px 8px',
                  borderRadius: 12, cursor: 'pointer', marginBottom: 2,
                  opacity: item.is_active ? 1 : 0.5,
                }}
              >
                <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {item.image_url
                    ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : <ImagePlus size={13} style={{ color: 'var(--text-muted)' }} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 12.5, color: 'var(--text)', margin: 0, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</p>
                  <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: 0 }}>
                    {item.rarity} · {item.category.replace(/_/g, ' ')}
                    {!item.is_active && ' · inactive'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <button
            type="button"
            onClick={(e) => { ripple(e); backToList() }}
            style={{
              display: 'flex', alignItems: 'center', gap: 5, marginBottom: 14,
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              color: 'var(--text-dim)', fontSize: 11.5, fontWeight: 700,
            }}
          >
            <ArrowLeft size={13} /> {draft.id ? 'All items' : 'Cancel'}
          </button>

          {/* ── Art ───────────────────────────────────────────────── */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
            <div style={{ width: 56, height: 56, borderRadius: 14, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {draft.imageUrl
                ? <img src={draft.imageUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <ImagePlus size={18} style={{ color: 'var(--text-muted)' }} />}
            </div>
            <label
              className="ripple-wrap"
              style={{
                flex: 1, padding: '10px 12px', borderRadius: 12, cursor: uploading ? 'default' : 'pointer',
                background: 'var(--surface2)', border: '1px solid var(--border)',
                color: 'var(--text-dim)', fontSize: 12, fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}
            >
              <Upload size={13} /> {uploading ? 'Uploading…' : draft.imageUrl ? 'Replace poster' : 'Upload poster image'}
              <input type="file" accept="image/*" onChange={handleFilePick} disabled={uploading} style={{ display: 'none' }} />
            </label>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
            <div style={{ width: 56, height: 56, borderRadius: 14, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {draft.animatedUrl
                ? (/\.(mp4|webm)$/i.test(draft.animatedUrl)
                    ? <video src={draft.animatedUrl} muted playsInline loop autoPlay preload="metadata" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : <img src={draft.animatedUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />)
                : <Video size={18} style={{ color: 'var(--text-muted)' }} />}
            </div>
            <label
              className="ripple-wrap"
              style={{
                flex: 1, padding: '10px 12px', borderRadius: 12, cursor: videoUploading ? 'default' : 'pointer',
                background: 'var(--surface2)', border: '1px solid var(--border)',
                color: 'var(--text-dim)', fontSize: 12, fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}
            >
              <Video size={13} />
              {videoUploading ? 'Uploading…' : draft.animatedUrl ? 'Replace video/GIF' : draft.category === 'profile_effect' ? 'Upload video/GIF (required)' : 'Upload video/GIF (optional)'}
              <input type="file" accept="video/mp4,video/webm,image/gif" onChange={handleVideoFilePick} disabled={videoUploading} style={{ display: 'none' }} />
            </label>
          </div>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 18px', lineHeight: 1.45 }}>
            {draft.category === 'profile_effect'
              ? 'Profile effects equip the video/GIF directly — a poster alone won\'t work when a player wears it.'
              : 'MP4/WebM plays as a real video; a GIF just animates. Leave blank for a static item.'}
          </p>

          {/* ── Basics ────────────────────────────────────────────── */}
          <p style={fieldLabel}>NAME</p>
          <input
            value={draft.name}
            onChange={e => setDraft(d => ({ ...d, name: e.target.value }))}
            maxLength={60}
            placeholder="e.g. Sukuna's Gaze"
            style={{ ...inputStyle, marginBottom: 10 }}
          />

          <p style={fieldLabel}>DESCRIPTION</p>
          <input
            value={draft.description}
            onChange={e => setDraft(d => ({ ...d, description: e.target.value }))}
            maxLength={140}
            placeholder="e.g. One look is enough"
            style={{ ...inputStyle, marginBottom: 10 }}
          />

          <p style={fieldLabel}>CATEGORY</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
            {ITEM_CATEGORIES.map(c => (
              <button
                key={c.value}
                type="button"
                onClick={() => setDraft(d => ({ ...d, category: c.value }))}
                style={{
                  padding: '6px 11px', borderRadius: 20, cursor: 'pointer',
                  background: draft.category === c.value ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
                  border: draft.category === c.value ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                  color: draft.category === c.value ? 'var(--accent)' : 'var(--text-dim)',
                  fontSize: 11, fontWeight: 700,
                }}
              >
                {c.label}
              </button>
            ))}
          </div>

          <p style={fieldLabel}>RARITY</p>
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            {RARITIES.map(r => (
              <button
                key={r}
                type="button"
                onClick={() => setDraft(d => ({ ...d, rarity: r }))}
                style={{
                  flex: 1, padding: '7px 8px', borderRadius: 10, cursor: 'pointer',
                  background: draft.rarity === r ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
                  border: draft.rarity === r ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                  color: draft.rarity === r ? 'var(--accent)' : 'var(--text-dim)',
                  fontSize: 11.5, fontWeight: 700,
                }}
              >
                {r}
              </button>
            ))}
          </div>

          {/* ── Unlock method ─────────────────────────────────────── */}
          <p style={fieldLabel}>UNLOCK METHOD</p>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            {(['gems', 'orbs', 'xp'] as const).map(c => (
              <button
                key={c}
                type="button"
                onClick={() => setCurrency(c)}
                style={{
                  flex: 1, padding: '7px 8px', borderRadius: 10, cursor: 'pointer',
                  background: currency === c ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'var(--surface2)',
                  border: currency === c ? '1px solid color-mix(in srgb, var(--accent) 35%, transparent)' : '1px solid var(--border)',
                  color: currency === c ? 'var(--accent)' : 'var(--text-dim)',
                  fontSize: 11.5, fontWeight: 700,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
                }}
              >
                {c === 'gems' ? <>💎 Diamonds</> : c === 'orbs' ? <>◍ Orbs</> : <><Zap size={12} /> XP</>}
              </button>
            ))}
          </div>
          <input
            value={priceText}
            onChange={e => setPriceText(e.target.value.replace(/[^0-9]/g, ''))}
            inputMode="numeric"
            placeholder={currency === 'xp' ? 'XP required — e.g. 5000' : `Price in ${priceLabel} — blank for no price`}
            style={{ ...inputStyle, marginBottom: 8 }}
          />
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 20px', lineHeight: 1.45 }}>
            {currency === 'xp'
              ? 'Free to claim once a player\'s XP reaches this number — no Diamonds or Orbs are charged.'
              : 'Leave blank for no price (e.g. an XP-unlocked or free item).'}
          </p>

          <MallItemPreviewCard draft={draft} priceLabel={priceLabel} priceText={priceText} />

          {/* Colours hang off a saved item's id, so this only appears once
              the item exists. On a brand-new item it shows up straight
              after the first save, since save() sets draft.id. */}
          {draft.id && (
            <ItemVariantsEditor
              itemId={draft.id}
              category={draft.category === 'profile_effect' ? 'profile_pic' : draft.category}
              subCategory={draft.category === 'profile_effect' ? CARD_EFFECT_SUB_CATEGORY : draft.subCategory}
            />
          )}

          <button
            type="button"
            onClick={(e) => { ripple(e); save() }}
            disabled={saving}
            className="ripple-wrap"
            style={{
              width: '100%', padding: 11, borderRadius: 12, border: 'none', marginBottom: draft.id ? 10 : 0,
              background: saving ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
              color: saving ? 'var(--text-muted)' : '#fff',
              fontSize: 13, fontWeight: 800, cursor: saving ? 'default' : 'pointer',
            }}
          >
            {saving ? 'Saving…' : draft.id ? 'Save changes' : 'Create item'}
          </button>

          {draft.id && (
            (liveRow ? liveRow.is_active : true) ? (
              <button
                type="button"
                onClick={(e) => { ripple(e); toggleActive() }}
                disabled={togglingActive}
                className="ripple-wrap"
                style={{
                  width: '100%', padding: 11, borderRadius: 12, cursor: togglingActive ? 'default' : 'pointer',
                  background: 'var(--surface2)', border: '1px solid var(--border)',
                  color: 'var(--red)', fontSize: 12.5, fontWeight: 700,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                }}
              >
                <Trash2 size={13} /> {togglingActive ? 'Saving…' : 'Pull off the shelf'}
              </button>
            ) : (
              <button
                type="button"
                onClick={(e) => { ripple(e); restoreActive() }}
                disabled={togglingActive}
                className="ripple-wrap"
                style={{
                  width: '100%', padding: 11, borderRadius: 12, cursor: togglingActive ? 'default' : 'pointer',
                  background: 'var(--surface2)', border: '1px solid var(--border)',
                  color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                }}
              >
                {togglingActive ? 'Saving…' : 'Restore to shelf'}
              </button>
            )
          )}
        </>
      )}

      {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 12 }}>{error}</p>}
      {saved && <p style={{ fontSize: 11.5, color: 'var(--green)', marginTop: 12 }}>{saved}</p>}
    </Modal>
  )
}

function GiftUserAutosuggest({ value, onChange }: {
  value: AdminUserRow | null
  onChange: (user: AdminUserRow | null) => void
}) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<AdminUserRow[]>([])
  const [open, setOpen] = useState(false)
  const [searching, setSearching] = useState(false)

  useEffect(() => {
    if (!open) return
    if (query.trim().length < 2) { setResults([]); return }
    setSearching(true)
    const t = setTimeout(() => {
      fetchAdminUserList(1, 8, query, null).then(({ data }) => { setResults(data?.rows ?? []); setSearching(false) })
    }, 220)
    return () => clearTimeout(t)
  }, [query, open])

  if (value) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
        <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--surface)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {value.avatar ? <img src={value.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Search size={12} style={{ color: 'var(--text-muted)' }} />}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{value.username}</p>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: 0 }}>{value.email}</p>
        </div>
        <button
          onClick={(e) => { ripple(e); onChange(null); setQuery('') }}
          aria-label="Clear selected user"
          style={{ flexShrink: 0, width: 22, height: 22, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: 'pointer' }}
        >
          <X size={11} />
        </button>
      </div>
    )
  }

  return (
    <div style={{ position: 'relative' }}>
      <div style={{ position: 'relative' }}>
        <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true) }}
          onFocus={() => setOpen(true)}
          placeholder="Search by username, name, or email…"
          style={{ ...inputStyle, paddingLeft: 30 }}
        />
      </div>
      {open && query.trim().length >= 2 && (
        <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 4, zIndex: 5, background: 'var(--popover)', border: '1px solid var(--border)', borderRadius: 12, boxShadow: 'var(--elev-popover)', maxHeight: 220, overflowY: 'auto' }}>
          {searching ? (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>Searching…</p>
          ) : results.length === 0 ? (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '10px 12px' }}>No matching users.</p>
          ) : results.map(u => (
            <div
              key={u.id}
              onClick={() => { onChange(u); setOpen(false) }}
              style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', cursor: 'pointer' }}
            >
              <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {u.avatar ? <img src={u.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Search size={12} style={{ color: 'var(--text-muted)' }} />}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 12, color: 'var(--text)', margin: 0, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.username}</p>
                <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: 0 }}>{u.email}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

const GIFT_AMOUNT_PRESETS = [100, 400, 1000, 2500]

function DiamondGiftRow({ item }: { item: DiamondGiftLogRow }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderRadius: 10, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
      <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--surface)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {item.avatar ? <img src={item.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Gift size={13} style={{ color: 'var(--text-muted)' }} />}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.username}</p>
        <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.description || 'Admin gift'}</p>
      </div>
      <p style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--green)', margin: 0, flexShrink: 0 }}>+{item.amount.toLocaleString()}</p>
    </div>
  )
}

function GiftDiamondsModal({ onClose }: { onClose: () => void }) {
  const [user, setUser] = useState<AdminUserRow | null>(null)
  const [amount, setAmount] = useState<number | ''>(400)
  const [reason, setReason] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [sentFor, setSentFor] = useState<{ username: string; amount: number; balance: number } | null>(null)
  const [history, setHistory] = useState<DiamondGiftLogRow[]>([])
  const [historyLoading, setHistoryLoading] = useState(true)

  function loadHistory() {
    setHistoryLoading(true)
    fetchRecentDiamondGifts(20).then(({ data, error }) => {
      if (error) setError(error)
      setHistory(data)
      setHistoryLoading(false)
    })
  }

  useEffect(() => { loadHistory() }, [])

  const canSend = user !== null && typeof amount === 'number' && amount !== 0 && reason.trim().length > 0 && !sending

  async function send() {
    if (!user || typeof amount !== 'number') return
    setSending(true)
    setError('')
    setSentFor(null)
    const { data, pending, error } = await grantDiamonds(user.id, amount, reason)
    setSending(false)
    if (error) { setError(error); return }
    if (pending) {
      setError(PENDING_MESSAGE)
      setUser(null); setAmount(400); setReason('')
      return
    }
    if (data) {
      setSentFor({ username: data.username, amount, balance: data.new_balance })
      setUser(null)
      setAmount(400)
      setReason('')
      loadHistory()
    }
  }

  return (
    <Modal title="Gift diamonds" onClose={onClose} width={440}>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '0 0 14px', lineHeight: 1.5 }}>
        Credits a user's diamond balance directly. Logged to their transaction history as an admin gift, same ledger as purchases and spends.
      </p>

      <div style={{ padding: 14, borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)', marginBottom: 16 }}>
        <p style={fieldLabel}>User</p>
        <div style={{ marginBottom: 12 }}>
          <GiftUserAutosuggest value={user} onChange={setUser} />
        </div>

        <p style={fieldLabel}>Amount</p>
        <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
          {GIFT_AMOUNT_PRESETS.map(p => (
            <button
              key={p}
              onClick={(e) => { ripple(e); setAmount(p) }}
              className={amount === p ? 'btn-primary' : 'btn-secondary'}
              style={{ flex: 1, padding: '7px 0', fontSize: 11.5 }}
            >
              {p.toLocaleString()}
            </button>
          ))}
        </div>
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
          placeholder="Custom amount"
          style={{ ...inputStyle, marginBottom: 12 }}
        />

        <p style={fieldLabel}>What's this gift about?</p>
        <input
          value={reason}
          onChange={e => setReason(e.target.value)}
          maxLength={140}
          placeholder="e.g. Bug bounty reward, event prize, support goodwill"
          style={{ ...inputStyle, marginBottom: 14 }}
        />

        {error && <p style={{ fontSize: 11.5, color: 'var(--red)', marginBottom: 12 }}>{error}</p>}
        {sentFor && (
          <p style={{ fontSize: 11.5, color: 'var(--green)', marginBottom: 12 }}>
            Gifted {sentFor.amount.toLocaleString()} to {sentFor.username} — new balance {sentFor.balance.toLocaleString()}.
          </p>
        )}

        <button
          onClick={send}
          disabled={!canSend}
          className="btn-primary"
          style={{ width: '100%', padding: '10px 0', fontSize: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, opacity: canSend ? 1 : 0.5 }}
        >
          <Gift size={12} /> {sending ? 'Sending…' : 'Send gift'}
        </button>
      </div>

      <p style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-dim)', margin: '0 0 8px' }}>Recent admin gifts</p>
      {historyLoading ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 14 }}>Loading…</p>
      ) : history.length === 0 ? (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', padding: '4px 0' }}>No admin gifts yet.</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {history.map(item => <DiamondGiftRow key={item.id} item={item} />)}
        </div>
      )}
    </Modal>
  )
}

// ── Root ────────────────────────────────────────────────────────────────

type StoreModalKind = 'mall-bundle' | 'mall-item' | 'mall-item-create' | 'gift-diamonds' | null

export type AdminStoreGroup = 'store' | 'sales' | 'diamonds'

export default function AdminStoreSection({ group = 'store' }: { group?: AdminStoreGroup }) {
  const navigate = useNavigate()
  const [modal, setModal] = useState<StoreModalKind>(null)

  return (
    <div>
      <style>{`
        .settings-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 16px;
          overflow: hidden;
          box-shadow: var(--elev-raise-sm);
          margin-bottom: 20px;
        }
        .settings-card > * {
          border-radius: 0 !important;
          box-shadow: none !important;
          margin: 0 !important;
          border: none !important;
          border-bottom: 1px solid var(--border) !important;
        }
        .settings-card > *:last-child { border-bottom: none !important; }
      `}</style>

      {group === 'store' && <>
      <SectionTitle>Mall</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<ImagePlus size={15} />} iconBg="rgba(79,142,247,0.12)" iconColor="var(--blue)"
          label="Mall Bundles" sub="Artwork, price and contents — and which one is pinned"
          onClick={(e) => { ripple(e); setModal('mall-bundle') }}
        />
        <Row
          icon={<Plus size={15} />} iconBg="rgba(62,207,142,0.12)" iconColor="var(--green)"
          label="Create or edit item" sub="Name, art, category, rarity, description, price — add new items or edit existing ones"
          onClick={(e) => { ripple(e); setModal('mall-item-create') }}
        />
        <Row
          icon={<Timer size={15} />} iconBg="color-mix(in srgb, var(--accent) 12%, transparent)" iconColor="var(--accent)"
          label="Item price, lock & timer" sub="Reprice any item, lock it with a message, or put it on a countdown"
          onClick={(e) => { ripple(e); setModal('mall-item') }}
        />
      </div>
      </>}

      {group === 'sales' && <>
      <SectionTitle>Sales & Promotions</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Zap size={15} />} iconBg="color-mix(in srgb, var(--accent) 12%, transparent)" iconColor="var(--accent)"
          label="Flash Sale Schedule" sub="Weekly Special + Monthly Mega Sale — items, discounts, timing, image"
          onClick={(e) => { ripple(e); navigate('/admin/flash-sales') }}
        />
      </div>
      </>}

      {group === 'diamonds' && <>
      <SectionTitle>Users</SectionTitle>
      <div className="settings-card">
        <Row
          icon={<Gift size={15} />} iconBg="rgba(62,207,142,0.12)" iconColor="var(--green)"
          label="Gift diamonds" sub="Search a user, credit their balance, log why"
          onClick={(e) => { ripple(e); setModal('gift-diamonds') }}
        />
      </div>
      </>}

      {modal === 'mall-bundle' && <MallBundleModal onClose={() => setModal(null)} />}
      {modal === 'mall-item-create' && <MallItemCreateModal onClose={() => setModal(null)} />}
      {modal === 'mall-item' && <MallItemEditorModal onClose={() => setModal(null)} />}
      {modal === 'gift-diamonds' && <GiftDiamondsModal onClose={() => setModal(null)} />}
    </div>
  )
}
