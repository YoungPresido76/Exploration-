// src/features/profile/Usage.tsx
//
// Reached from You → Progress → Usage (also a quick-access sub-page off
// the You dock tab). Shows session usage as a percentage — see
// usageTier.ts for the color ramp — instead of a raw count, since the
// raw ceiling moves per Pro tier (15/19/25) while percentage doesn't.
import { useState, useEffect } from 'react'
import { Zap, Clock } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { useProfile } from './useProfile'
import { usePageHeader } from '../../context/PageHeader'
import { getSessionLimits } from '../../shared/lib/proPlans'
import { getGlobalSessionInfo, type GlobalSessionInfo } from '../games/gameSession'
import { usageTierColor, formatResetClock } from '../../shared/lib/usageTier'
import UsageBar from '../../shared/components/UsageBar'

export default function Usage() {
  usePageHeader({ title: 'Usage' })

  const { session } = useAuth()
  const userId = session?.user?.id ?? ''
  const { profile } = useProfile()
  const sessionLimit = getSessionLimits(profile).limit

  const [info, setInfo] = useState<GlobalSessionInfo | null>(null)

  useEffect(() => {
    if (!userId) return
    const refresh = () => { getGlobalSessionInfo(userId, sessionLimit).then(setInfo) }
    refresh()
    const iv = setInterval(refresh, 15000)
    return () => clearInterval(iv)
  }, [userId, sessionLimit])

  const count = info?.count ?? 0
  const limitReached = info?.limitReached ?? false
  const pct = limitReached ? 100 : (sessionLimit > 0 ? Math.min(100, Math.round((count / sessionLimit) * 100)) : 0)
  const color = usageTierColor(pct)
  const resetLabel = info?.resetAt ? formatResetClock(info.resetAt) : null

  return (
    <div style={{ maxWidth: 600, margin: '0 auto' }}>
      <div className="neu-card" style={{ padding: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <Zap size={16} style={{ color }} />
          <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>Session limit</span>
        </div>

        <UsageBar pct={pct} height={8} />

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 9 }}>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            {limitReached ? 'Limit reached' : `${count}/${sessionLimit} sessions used`}
          </span>
          <span style={{ fontSize: 12, fontWeight: 800, color }}>{pct}%</span>
        </div>

        {limitReached && resetLabel && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
            <Clock size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
            <span style={{ fontSize: 12.5, color: 'var(--text-dim)' }}>Till {resetLabel}</span>
          </div>
        )}
      </div>
    </div>
  )
}
