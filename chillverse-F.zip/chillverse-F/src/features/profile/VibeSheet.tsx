// src/features/profile/VibeSheet.tsx
//
// The vibe editor — text, an optional emoji, how long it lasts, and a
// row of presets. Opened by tapping your own bubble on the profile
// preview sheet, and from the Vibe row in Edit Profile.
//
// A preset FILLS the input rather than submitting: the wording stays
// editable, which is the whole point of a 30-character line.
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Smile, Check, Trash2 } from 'lucide-react'
import {
  VIBE_MAX_LENGTH, VIBE_DURATIONS, VIBE_PRESETS, DEFAULT_VIBE_DURATION,
  resolveVibeExpiry, setVibe, clearVibe, type Vibe,
} from './vibe'

const WIDE_BREAKPOINT = 640
const EMOJI_CHOICES = ['🟢', '⏰', '🎮', '⚔️', '😹', '✈️', '🔥', '🔕', '😴', '💭', '🎧', '📚', '🍜', '💀', '👀', '🫡']

interface Props {
  current: Vibe | null
  onClose: () => void
  /** Fired with the saved vibe (or null when cleared) so the caller can
   *  update its own copy without refetching the profile. */
  onSaved: (vibe: Vibe | null) => void
}

export default function VibeSheet({ current, onClose, onSaved }: Props) {
  const [visible, setVisible] = useState(false)
  const [isWide, setIsWide] = useState(() => typeof window !== 'undefined' && window.innerWidth >= WIDE_BREAKPOINT)
  const [text, setText] = useState(current?.text ?? '')
  const [emoji, setEmoji] = useState<string | null>(current?.emoji ?? null)
  const [duration, setDuration] = useState(DEFAULT_VIBE_DURATION)
  const [emojiOpen, setEmojiOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const id = requestAnimationFrame(() => setVisible(true))
    return () => cancelAnimationFrame(id)
  }, [])

  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= WIDE_BREAKPOINT) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  function close() {
    setVisible(false)
    setTimeout(onClose, 220)
  }

  async function handleSave() {
    const trimmed = text.trim()
    if (!trimmed) {
      setError('Write something first')
      inputRef.current?.focus()
      return
    }
    setSaving(true)
    setError(null)
    try {
      const expiresAt = resolveVibeExpiry(duration)
      await setVibe(trimmed, emoji, expiresAt)
      onSaved({ text: trimmed, emoji, expiresAt })
      close()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  async function handleClear() {
    setSaving(true)
    setError(null)
    try {
      await clearVibe()
      onSaved(null)
      close()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  const remaining = VIBE_MAX_LENGTH - text.length

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050,
        background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: isWide ? 'center' : 'flex-end', justifyContent: 'center',
        opacity: visible ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: isWide ? 'min(420px, calc(100vw - 32px))' : '100%',
          maxHeight: '85vh',
          background: 'var(--bg)',
          border: '1px solid var(--border)',
          borderRadius: isWide ? 20 : '20px 20px 0 0',
          boxShadow: '0 -12px 40px -12px var(--sh)',
          transform: visible ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 0.28s cubic-bezier(0.32,0.72,0,1)',
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
        }}
      >
        <div style={{ padding: '10px 0 6px', display: 'flex', justifyContent: 'center', flexShrink: 0 }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--border-strong)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '2px 18px 14px', flexShrink: 0 }}>
          <p style={{ flex: 1, fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>Your vibe</p>
          {current && (
            <button
              type="button" onClick={handleClear} disabled={saving}
              style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: '#ff6b6b', fontSize: 12, fontWeight: 700 }}
            >
              <Trash2 size={13} /> Clear
            </button>
          )}
          <button type="button" onClick={close} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        <div style={{ overflowY: 'auto', overscrollBehavior: 'contain', padding: '0 18px 20px' }}>
          {/* Input + emoji + counter */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 9,
            background: 'var(--surface)', border: '1px solid var(--border-strong)',
            borderRadius: 14, padding: '8px 12px',
          }}>
            <button
              type="button"
              onClick={() => setEmojiOpen(o => !o)}
              style={{
                width: 30, height: 30, borderRadius: 10, flexShrink: 0,
                background: 'var(--surface2)', border: 'none', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, color: 'var(--text-dim)',
              }}
            >
              {emoji ?? <Smile size={15} />}
            </button>
            <input
              ref={inputRef}
              autoFocus
              value={text}
              maxLength={VIBE_MAX_LENGTH}
              onChange={e => { setText(e.target.value.slice(0, VIBE_MAX_LENGTH)); setError(null) }}
              onKeyDown={e => { if (e.key === 'Enter') handleSave() }}
              placeholder="What's the vibe?"
              style={{
                flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none',
                fontSize: 13.5, fontWeight: 600, fontStyle: 'italic', color: 'var(--text)',
              }}
            />
            <span style={{ fontSize: 11, fontWeight: 700, color: remaining <= 5 ? 'var(--accent)' : 'var(--text-muted)', flexShrink: 0 }}>
              {remaining}
            </span>
          </div>

          {emoji && (
            <button
              type="button"
              onClick={() => setEmoji(null)}
              style={{ marginTop: 7, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: 11, fontWeight: 600 }}
            >
              Remove emoji
            </button>
          )}

          {emojiOpen && (
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 4,
              background: 'var(--surface)', border: '1px solid var(--border)',
              borderRadius: 13, padding: 8, marginTop: 9,
            }}>
              {EMOJI_CHOICES.map(e => (
                <button
                  key={e}
                  type="button"
                  onClick={() => { setEmoji(e); setEmojiOpen(false) }}
                  style={{
                    aspectRatio: '1', borderRadius: 9, border: 'none', cursor: 'pointer',
                    background: emoji === e ? 'var(--surface3)' : 'none', fontSize: 17,
                  }}
                >
                  {e}
                </button>
              ))}
            </div>
          )}

          {error && (
            <p style={{ fontSize: 11.5, color: '#ff6b6b', fontWeight: 600, marginTop: 9 }}>{error}</p>
          )}

          {/* Duration */}
          <p style={{ fontSize: 11, fontWeight: 800, color: 'var(--text-muted)', letterSpacing: 0.5, textTransform: 'uppercase', margin: '20px 0 9px' }}>
            Clear it after
          </p>
          <div style={{ display: 'flex', gap: 6 }}>
            {VIBE_DURATIONS.map(d => (
              <button
                key={d.id}
                type="button"
                onClick={() => setDuration(d.id)}
                style={{
                  flex: 1, padding: '9px 0', borderRadius: 11,
                  border: duration === d.id ? '1px solid var(--accent)' : '1px solid var(--border)',
                  background: duration === d.id ? 'rgba(255,255,255,0.04)' : 'none',
                  color: duration === d.id ? 'var(--accent)' : 'var(--text-dim)',
                  fontSize: 11.5, fontWeight: 700, cursor: 'pointer',
                }}
              >
                {d.label}
              </button>
            ))}
          </div>

          {/* Presets */}
          <p style={{ fontSize: 11, fontWeight: 800, color: 'var(--text-muted)', letterSpacing: 0.5, textTransform: 'uppercase', margin: '20px 0 9px' }}>
            Or pick one
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {VIBE_PRESETS.map(p => (
              <button
                key={p.text}
                type="button"
                onClick={() => { setText(p.text); setEmoji(p.emoji); setError(null) }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '8px 12px', borderRadius: 20,
                  border: '1px solid var(--border)', background: 'var(--surface)',
                  color: 'var(--text-dim)', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                }}
              >
                <span style={{ fontSize: 13 }}>{p.emoji}</span> {p.text}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            style={{
              width: '100%', marginTop: 22, padding: '13px 0', borderRadius: 14,
              border: 'none', background: 'var(--accent)', color: '#fff',
              fontWeight: 800, fontSize: 13.5, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              opacity: saving ? 0.7 : 1,
            }}
          >
            <Check size={15} /> {saving ? 'Saving…' : 'Set vibe'}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  )
}
