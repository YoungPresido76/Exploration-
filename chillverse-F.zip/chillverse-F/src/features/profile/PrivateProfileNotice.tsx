// src/features/profile/PrivateProfileNotice.tsx
//
// What a non-follower sees where a "Followers only" profile's hidden
// sections would have been.
//
// The whole reason this exists: hiding a section leaves a hole, and a
// viewer cannot tell a private profile from an empty one. Someone who
// reads it as empty just leaves; someone who reads it as private has a
// reason to tap Follow. So the notice always carries the action, not
// just the explanation.
//
// Two sizes because it lands in two very different holes — a slim strip
// where the follower counts sat, and a whole tab body where the stats
// table was.
import { Lock, UserPlus, EyeOff } from 'lucide-react'

interface PrivateProfileNoticeProps {
  username: string
  /** 'row' for the follower-count strip, 'panel' for a whole tab body. */
  variant?: 'row' | 'panel'
  /** Omit to render without a button — e.g. when you're already following. */
  onFollow?: () => void
  busy?: boolean
}

export default function PrivateProfileNotice({
  username, variant = 'panel', onFollow, busy,
}: PrivateProfileNoticeProps) {
  const panel = variant === 'panel'

  return (
    <div
      style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        gap: panel ? 10 : 7,
        padding: panel ? '26px 20px' : '14px 16px',
        borderRadius: panel ? 16 : 13,
        background: 'var(--surface)',
        border: '1px dashed var(--border-strong)',
        textAlign: 'center',
      }}
    >
      <div style={{
        width: panel ? 40 : 30, height: panel ? 40 : 30, borderRadius: '50%',
        display: 'grid', placeItems: 'center',
        background: 'var(--surface2)', border: '1px solid var(--border)',
      }}>
        <Lock size={panel ? 17 : 13} style={{ color: 'var(--text-muted)' }} />
      </div>

      <p style={{
        fontSize: panel ? 13 : 12,
        color: 'var(--text-dim)',
        lineHeight: 1.5,
        maxWidth: 260,
      }}>
        Looks like <strong style={{ color: 'var(--text)' }}>@{username}</strong> made their
        profile private. Follow to see the full profile.
      </p>

      {onFollow && (
        <button
          type="button"
          className="pv-btn"
          disabled={busy}
          onClick={onFollow}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            padding: panel ? '9px 18px' : '7px 15px',
            borderRadius: 999, border: 'none', font: 'inherit',
            fontSize: panel ? 12.5 : 11.5, fontWeight: 800, color: '#fff',
            background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
            cursor: busy ? 'not-allowed' : 'pointer',
            opacity: busy ? 0.65 : 1,
          }}
        >
          <UserPlus size={panel ? 14 : 12} /> Follow
        </button>
      )}
    </div>
  )
}

/* ── Follow counts switched off ─────────────────────────────────────
   A different setting from the one above, and a different message.
   "Followers only" is something a viewer can resolve by following;
   this one they cannot resolve at all, so there is no button — offering
   an action that wouldn't work is worse than offering none.

   This replaces the pair of boxes reading "—", which looked like two
   numbers that had failed to load rather than a decision the owner
   made. */

export function FollowCountsHiddenNotice({ username }: { username: string }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '12px 14px', borderRadius: 13,
      background: 'var(--surface2)', border: '1px solid var(--border)',
    }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
        display: 'grid', placeItems: 'center',
        background: 'var(--surface)', border: '1px solid var(--border)',
      }}>
        <EyeOff size={13} style={{ color: 'var(--text-muted)' }} />
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', lineHeight: 1.45 }}>
        Only <strong style={{ color: 'var(--text-dim)' }}>@{username}</strong> can see their
        followers and following.
      </p>
    </div>
  )
}
