// src/features/profile/ProfilePreviewModal.tsx
//
// The profile popup — this IS the profile now, there's no separate full
// page anymore. Mirrors Discord's profile popover: tap any avatar
// anywhere in the app (feed, chat, search, comments, sidebar) and this
// slides up with everything — Main / Wishlist / Stats tabs, and (when
// it's your own profile) Edit Profile + Refer & Earn instead of the
// follow/message/call row.
//
// A Discord-style bottom sheet at every screen size — phone AND tablet.
// It slides up and stays pinned to the bottom of the viewport until you
// tap the dimmed backdrop, hit Escape, or tap the close button; it never
// floats as a centered popover. It has a tall minimum height so it rises
// well up the screen even for a sparse profile, and only grows past that
// (up to a max, then scrolls internally) when there's a lot of content.
// On wider viewports the sheet narrows into a centered card shape, but
// stays bottom-anchored the whole time. Locks page scroll while open.
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import {
  X, MoreVertical, UserPlus, UserCheck, MessageCircle, ShieldOff, Copy, Flag, Check, Phone, Users,
  Image as ImageIcon, Edit3, Gift, Zap, Trophy, Star, Sparkles, Package,
  Heart, UserRound, Sunrise, Moon as MoonIcon, EyeOff, Ban,
} from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { nameStyleFor } from '../../shared/lib/displayNameStyle'
import { profileSkinBackground, profileSkinAttr } from '../../shared/lib/profileSkins'
import ProfileSkinStyles from './ProfileSkinStyles'
import { useAuth } from '../auth/useAuth'
import { ripple } from '../../shared/lib/ripple'
import { useRealViewportHeight, useSheetDrag } from '../../shared/hooks/useBottomSheet'
import Avatar from '../../shared/components/Avatar'
import VerifiedBadge from '../../shared/components/VerifiedBadge'
import RankBadge from '../../shared/components/RankBadge'
import { getUserRankTier } from './ranks'
import { canSeeLiveActivity } from './liveActivityAccess'
import PvpProfilePanel from '../pvp/PvpProfilePanel'
import AttackSheet from '../pvp/AttackSheet'
import '../holo/holo-skin.css'
import { usePvpState } from '../pvp/usePvpState'
import { usePlayerBadges } from '../badges/usePlayerBadges'
import { BadgeIcon } from '../badges/badgeIcons'
import { BADGE_RARITY_COLOR, BADGE_RARITY_RANK, badgeDisplayTitle, championshipTrophyBadges, isChampionshipBadge, type BadgeDef } from '../badges/badges'
import BadgeToast from '../badges/BadgeToast'
import ClubInvitePicker from '../clubs/ClubInvitePicker'
import VibeBubble from './VibeBubble'
import SuspensionNotice from './SuspensionNotice'
import VibeSheet from './VibeSheet'
import { vibeFrom, type Vibe } from './vibe'
import { trackWeeklyUniqueValue } from '../missions/weeklyMissions'
import ProBadge, { proBadgeSrc, subscriberBadgeTier } from '../badges/ProBadge'
import { championshipBadgeSrc } from '../badges/ChampionshipBadge'
import ChampionshipBadgeModal from '../badges/ChampionshipBadgeModal'
import { getSeasonPlacements } from '../championship/championship'
import BadgesModal from '../badges/BadgesModal'
import PrivateProfileNotice from './PrivateProfileNotice'
import FirstBloodMarker from '../pvp/FirstBloodMarker'
import BadgeQuickSheet from '../badges/BadgeQuickSheet'
import { DrippedPortrait } from '../drip/DripLayer'
import { isDripKey, type DripKey } from '../drip/drip'
import { ProfileEffectLayer, useProfileEffectPlayback } from './profileEffect'
import { AchIcon, RARITY_COLOR as ACH_RARITY_COLOR } from '../achievements/Achievements'
import AchievementMiniToast from '../achievements/AchievementMiniToast'
import { getGameById, getGameMeta, MINO_GAME_ID, MINO_GAME_NAME, MINO_ICON_URL } from '../games/games'
import { getAllPlayerRanks } from '../games/gameSession'
import ReportModal from '../safety/ReportModal'
import DuoSection from '../duo/DuoSection'
import ProfileClubsSection from '../clubs/ProfileClubsSection'
import { useCall } from '../chat/calling/CallContext'
import SendGiftModal, { giftResultMessage, type GiftSendResult } from '../economy/SendGiftModal'
import { fetchUngiftableItemIds, GIFT_UNAVAILABLE_MESSAGE } from '../economy/giftAvailability'
import { MOD_AVATAR_URL } from '../moderation/modShowcase'
import EditProfileModal from './EditProfileModal'
import FollowListSheet from './FollowListSheet'
import AvatarQuickSheet from './AvatarQuickSheet'
import ArtifactQuickSheet, { type ArtifactTileData } from './ArtifactQuickSheet'
import type { Profile } from '../../shared/types'
import { isProActive } from '../../shared/lib/proPlans'

const GAME_RANK_STARS: Record<string, number> = {
  beginner: 1, intermediate: 3, advanced: 4, master: 5,
}

// ── Sheet height — its own dedicated setting ────────────────────────────
// This is the ONE number that controls how tall the profile preview sheet
// is, on every device. It's a percentage of the screen, so it always
// looks the same proportionally whether someone's zoomed in or out — it's
// not reacting to zoom as a side effect, it's just deliberately set here.
// Turn this number up or down to make the sheet taller or shorter; nothing
// else in this file needs to change.
//
// This percentage is applied against the REAL visible viewport
// (useRealViewportHeight), not a raw CSS vh unit — raw vh is always a bit
// taller than what's actually visible because it includes the area behind
// the browser's address bar/toolbar. 92 (not 85) compensates for that gap
// so the sheet reads the same height it did back when it was sized off raw
// vh, without bringing back the old bug where the top of the sheet (drag
// handle, Follow/Message row) could render above the real top edge of the
// screen.
const SHEET_HEIGHT_VH = 92

// 'suspended' is not a real profiles.presence value — get_public_profile
// substitutes it for a suspended account so the dot, the greyed portrait and
// the notice below all key off one field instead of three.
type Presence = 'online' | 'idle' | 'offline' | 'invisible' | 'suspended'
const PRESENCE_COLORS: Record<Presence, string> = {
  online: '#3ecf8e', idle: '#f5c542', offline: '#888899', invisible: '#555566',
  suspended: '#ff4d4d',
}

interface PreviewProfile {
  id: string
  username: string
  display_name: string | null
  avatar: string
  bio: string | null
  xp: number
  active_rank_xp: number
  created_at: string
  presence: Presence | null
  is_pro: boolean
  pro_tier: 'orbit' | 'void' | null
  pro_badge_color: string | null
  pro_first_subscribed_at: string | null
  original_username: string
  staff_member_since: string | null
  banner_url: string | null
  favorite_game: string | null
  grid_cards: string[] | null
  featured_badge_ids: string[] | null
  equipped_avatar: string | null
  gender: string | null
  play_time: 'morning' | 'night' | null
  info_tags: string[] | null
  show_follow_counts: boolean
  display_name_font: string | null
  display_name_color: string | null
  profile_theme_color: string | null
  profile_ui_skin: string | null
  pro_expires_at: string | null
  equipped_profile_effect_url: string | null
  /** The earned effect this profile is wearing — re-derived server-side,
      so it is already null if they've been passed on the board. */
  drip: DripKey | null
  country: string | null
  /** Owner's Dynamic Profile switch — re-derived live against their Void
   *  subscription by get_public_profile, so a lapsed member reports false. */
  holo_profile_enabled: boolean
  /**
   * False when the owner set "Followers only" and this viewer isn't one.
   * The stats-tab fields above arrive nulled in that case, so this is what
   * separates "hidden" from "they just haven't set one".
   */
  full_profile_visible: boolean
  /**
   * The vibe — a short expiring line rendered as a thought bubble beside
   * the avatar. get_public_profile nulls all three once vibe_expires_at
   * has passed, so an expired vibe simply arrives as "no vibe" and there
   * is nothing to clean up. See migration 0175c.
   */
  vibe_text: string | null
  vibe_emoji: string | null
  vibe_expires_at: string | null
  /**
   * True when this VIEWER is being shown a suspended account. Never true for
   * the account's own owner or for staff — get_public_profile hands both of
   * those the real profile, so a mod can still do their job and nobody is
   * shown a stranger's view of themselves. When it's true every other field
   * above has already arrived nulled or zeroed from the server, so there is
   * nothing here to accidentally leak.
   */
  is_suspended: boolean
  /** Written by a mod. NOT ban_reason, which stays internal. */
  suspension_title: string | null
  suspension_reason: string | null
}

const GENDER_LABELS: Record<string, string> = { male: 'MALE', female: 'FEMALE', other: 'OTHER' }

// Total icon slots in the badge row, RANK INCLUDED — the rank tier now
// renders as one of these icons instead of its own separate pill, so
// this is "5 total", not "5 real badges plus a rank on top".
const BADGE_PREVIEW_COUNT = 5

// Lower is better — rarest achievements shown first, mirrors the same
// pattern used for badges and on the full profile page.
const ACH_RARITY_RANK: Record<string, number> = { legendary: 0, epic: 1, rare: 2, common: 3 }
const BEST_ACHIEVEMENTS_COUNT = 19

const WISHLIST_MAX = 10

// PvP achievements read red on the profile whatever their rarity — a kill
// is a kill, and the point of the chip is that you can spot the fighters
// at a glance. Rarity still colours every other category, and the full
// Achievements screen is untouched.
const PVP_ACH_COLOR = '#ff3b3b'


// mm:ss (or h:mm:ss past an hour) elapsed-time readout for the live
// "Playing X" activity card, matching Discord's own ticking timer.
function formatElapsed(ms: number): string {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000))
  const h = Math.floor(totalSeconds / 3600)
  const m = Math.floor((totalSeconds % 3600) / 60)
  const s = totalSeconds % 60
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  return `${m}:${String(s).padStart(2, '0')}`
}

interface PreviewAchievement {
  id: string
  title: string
  icon: string
  rarity: string
  /** Drives the chip colour for PvP — see PVP_ACH_COLOR. */
  category: string
}

interface PreviewWishlistItem {
  id: string
  item_id: string | null
  item_name: string
  item_image: string | null
}

interface LiveActivity {
  movie: boolean
  game: string | null
  gameSince: number | null
  exploring: boolean
}

type PreviewTab = 'main' | 'wishlist' | 'stats' | 'battle'

export default function ProfilePreviewModal({
  userId, onClose, isPreview = false, openAttack = false, onOpenOtherProfile,
}: {
  userId: string
  onClose: () => void
  isPreview?: boolean
  /**
   * Open with the attack sheet already up. Set by the bounty poster's
   * "Accept the contract" button, via the ProfilePreview context.
   */
  openAttack?: boolean
  /**
   * Swap this popup over to somebody else's profile — the club owner row,
   * the duo partner row. Supplied by ProfilePreviewProvider, which owns
   * the target and can change it in one setState.
   *
   * A PROP rather than useProfilePreview() on purpose: this file is
   * imported BY the provider, so calling into the context from here would
   * make the two modules import each other. Falls back to the
   * /profile/:id route when absent (ProfileEffectPreview renders this
   * modal directly, outside the provider).
   */
  onOpenOtherProfile?: (userId: string) => void
}) {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [profile, setProfile] = useState<PreviewProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [followStatus, setFollowStatus] = useState<'none' | 'following' | 'blocked'>('none')
  const [busy, setBusy] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [reportOpen, setReportOpen] = useState(false)
  const [usernameCopied, setUsernameCopied] = useState(false)
  const [callStarting, setCallStarting] = useState(false)
  const { startCall, phase } = useCall()
  // This no longer decides "sheet vs popover" — it ONLY decides how wide/
  // narrow the sheet is. Every width is a bottom sheet, same as Discord's
  // phone AND tablet apps; on a wide viewport the sheet is just narrower
  // and card-shaped, it doesn't jump to floating in the vertical center.
  const [isWide, setIsWide] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 640)
  const [closing, setClosing] = useState(false)
  const [entered, setEntered] = useState(false)
  // Real visible height instead of raw `vh` — on phones the browser's
  // address-bar chrome makes `vh` taller than what's actually on screen,
  // which pushed this sheet's top (drag handle, close/menu buttons) off
  // the top edge with no way to scroll it back into view. See
  // useBottomSheet.ts.
  const realVh = useRealViewportHeight()
  const sheetHeightPx = Math.round(realVh * (SHEET_HEIGHT_VH / 100))
  const { dragY, dragging, dragHandleProps, sheetProps } = useSheetDrag(close)
  const [isModerator, setIsModerator] = useState(false)
  // The shared Chillverse brand account — even more stripped back than a
  // moderator: no like, no call, no following count, no tabs, no badges.
  const [isOfficial, setIsOfficial] = useState(false)
  const [badgeToast, setBadgeToast] = useState<BadgeDef | null>(null)
  const [showBadgesModal, setShowBadgesModal] = useState(false)
  const [championshipPreview, setChampionshipPreview] = useState<BadgeDef | null>(null)
  const [showBadgeQuickSheet, setShowBadgeQuickSheet] = useState(false)
  const [bestAchievements, setBestAchievements] = useState<PreviewAchievement[]>([])
  const [achToast, setAchToast] = useState<PreviewAchievement | null>(null)
  const [activity, setActivity] = useState<LiveActivity>({ movie: false, game: null, gameSince: null, exploring: false })
  const [nowTick, setNowTick] = useState(() => Date.now())
  // Void-exclusive-profile-customization + Mall upsell card shown to non-Pro
  // users on their own profile popup. Dismissing it (X) hides it for 24h,
  // per-user, via localStorage — not a server round trip, just a soft nag.
  const UPGRADE_PROMO_COOLDOWN_MS = 24 * 60 * 60 * 1000
  const [upgradePromoDismissed, setUpgradePromoDismissed] = useState(() => {
    try {
      const raw = localStorage.getItem(`cv_upgrade_promo_dismissed_${userId}`)
      if (!raw) return false
      return Date.now() - Number(raw) < UPGRADE_PROMO_COOLDOWN_MS
    } catch { return false }
  })
  function dismissUpgradePromo() {
    try { localStorage.setItem(`cv_upgrade_promo_dismissed_${userId}`, String(Date.now())) } catch { /* ignore */ }
    setUpgradePromoDismissed(true)
  }
  const [followers, setFollowers] = useState(0)
  const [following, setFollowing] = useState(0)
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(0)
  const [liking, setLiking] = useState(false)
  const [showRankToast, setShowRankToast] = useState(false)
  const [activeTab, setActiveTab] = useState<PreviewTab>('main')
  // Seeded from the prop rather than synced by an effect: the popup is
  // remounted for each userId, so the initial value is always the right
  // one and an effect would only risk re-opening the sheet after the
  // player closed it.
  const [attackOpen, setAttackOpen] = useState(openAttack && userId !== user?.id)
  // Bumped after a landed attack so the Battle tab's HP bar (which reads
  // this player's PvP state) refetches immediately instead of showing
  // stale HP until the profile is closed and reopened.
  const [pvpRefreshSignal, setPvpRefreshSignal] = useState(0)
  const [wishlist, setWishlist] = useState<PreviewWishlistItem[]>([])
  const [wishlistLoading, setWishlistLoading] = useState(true)
  const [giftTarget, setGiftTarget] = useState<{ itemId: string | null; itemName: string; itemImage: string | null } | null>(null)
  const [giftToast, setGiftToast] = useState<string | null>(null)
  // Shown when a non-follower taps into the followers/following list on a
  // profile that has counts switched off — the counts themselves stay
  // visible, only the list is blocked.
  const [followCountsToast, setFollowCountsToast] = useState<string | null>(null)
  // "Invite to your club" from the three-dot menu. The picker is a
  // separate sheet rather than a nested dropdown because a person can be
  // in more than a handful of clubs and the dropdown is anchored inside
  // the banner's corner.
  const [invitePickerOpen, setInvitePickerOpen] = useState(false)
  const [noticeToast, setNoticeToast] = useState<string | null>(null)
  // The vibe is held in its own state so the sheet can update the bubble
  // without a profile refetch. Seeded from the fetch below.
  const [vibe, setVibe] = useState<Vibe | null>(null)
  const [vibeSheetOpen, setVibeSheetOpen] = useState(false)
  // Wishlist rows that can no longer be gifted (ended / locked / pulled).
  // Resolved with the list so a tap can toast immediately instead of
  // opening the gift page only for it to dead-end there.
  const [ungiftable, setUngiftable] = useState<Set<string>>(new Set())
  const [lbPosition, setLbPosition] = useState<number | null>(null)
  const [equippedArtifact, setEquippedArtifact] = useState<string | null>(null)
  const [equippedArtifactImage, setEquippedArtifactImage] = useState<string | null>(null)
  const [equippedArtifactTier, setEquippedArtifactTier] = useState<string | null>(null)
  const [showcasedArtifacts, setShowcasedArtifacts] = useState<ArtifactTileData[]>([])
  const [favoriteGameRank, setFavoriteGameRank] = useState<string | null>(null)
  const [showEdit, setShowEdit] = useState(false)
  // Followers/Following list — which mode is open, or null when closed.
  const [followSheetMode, setFollowSheetMode] = useState<'followers' | 'following' | null>(null)
  const [showAvatarQuickSheet, setShowAvatarQuickSheet] = useState(false)
  const [showArtifactQuickSheet, setShowArtifactQuickSheet] = useState(false)
  // ClubQuickSheet renders itself from inside ProfileClubsSection, but this
  // sheet still has to know it's up: it drops down out of the way while the
  // club sheet draws up, and Escape has to back out of the club first.
  const [clubSheetOpen, setClubSheetOpen] = useState(false)
  // (editAlbumPics state removed along with the banner-picker fetch above)
  const menuRef = useRef<HTMLDivElement>(null)
  const justSavedRef = useRef(false)

  const isMe = user?.id === userId

  // The owner chose "Followers only" and this viewer isn't one. What stays
  // visible is deliberate: bio, badges, achievements, the battle panel and
  // member-since are who someone IS. The stats table and follower counts
  // are what they've accumulated, and those are what the setting is
  // actually protecting.
  const restricted = !!profile && !isMe && !profile.full_profile_visible

  // The viewer's OWN jail status — separate from whatever PvpProfilePanel
  // fetches for the profile being viewed. Only needed when looking at
  // someone else, since the Attack button is hidden on your own profile.
  const { state: viewerPvpState } = usePvpState(isMe ? null : user?.id)

  useEffect(() => {
    const raf = requestAnimationFrame(() => setEntered(true))
    return () => cancelAnimationFrame(raf)
  }, [])

  // Track viewport so the exact same modal switches between a bottom
  // sheet (mobile) and a centered card (desktop) without a page reload.
  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= 640) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // Lock the page behind the modal — Discord's popover never lets the
  // page scroll while it's open, only the modal's own content scrolls.
  // Also hides the portaled dock (cv-sheet-open, see index.css) — this
  // sheet already visually covers the dock via its higher z-index, but
  // the class additionally kills its pointer-events/geometry, matching
  // every other sheet in the app rather than relying on stacking alone.
  useEffect(() => {
    const prevOverflow = document.body.style.overflow
    const prevPaddingRight = document.body.style.paddingRight
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth
    document.body.style.overflow = 'hidden'
    if (scrollbarWidth > 0) document.body.style.paddingRight = `${scrollbarWidth}px`
    // `cv-sheet-open` is a plain boolean class that ~15 sheets add and
    // remove independently, so a nested overlay's cleanup used to strip it
    // while the sheet UNDERNEATH was still open — the dock sprang back over
    // that sheet's own controls. This profile card is the one overlay that
    // can open from inside anything (every avatar in the app opens it), so
    // it saves the flag's prior state and only clears what it set itself.
    const dockWasHidden = document.body.classList.contains('cv-sheet-open')
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = prevOverflow
      document.body.style.paddingRight = prevPaddingRight
      if (!dockWasHidden) document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  // Escape closes it, same as Discord — but only when nothing spawned
  // from this profile (gift, report, badge sheets, follow list, etc.) is
  // currently open on top of it. Those are separate full-screen/portal
  // overlays, not nested inside this one, so without this guard Escape
  // (or any other route to close() while one's open) closed both at once
  // instead of just backing out of the child first.
  const hasOpenChildOverlay = reportOpen || giftTarget !== null || showBadgesModal || showBadgeQuickSheet
    || followSheetMode !== null || showAvatarQuickSheet || showArtifactQuickSheet || attackOpen || showEdit
    || clubSheetOpen
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape' && !hasOpenChildOverlay) close()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [hasOpenChildOverlay])

  useEffect(() => {
    let active = true
    setLoading(true)
    supabase.rpc('get_public_profile', { p_user_id: userId }).single().then(({ data }) => {
      if (!active) return
      const p = (data as PreviewProfile | null) ?? null
      setProfile(p)
      setVibe(vibeFrom(p))
      setLoading(false)
    })
    supabase.from('user_moderation').select('role').eq('user_id', userId).maybeSingle().then(({ data }) => {
      if (active) setIsModerator(data?.role === 'moderator')
    })
    supabase.from('profiles').select('is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official').eq('id', userId).maybeSingle().then(({ data }) => {
      if (active) setIsOfficial(!!data?.is_official || !!data?.is_halo_ai || !!data?.is_groove_official || !!data?.is_pvp_official || !!data?.is_warden_official)
    })
    return () => { active = false }
  }, [userId])

  useEffect(() => {
    if (!user || isMe) return
    let active = true
    Promise.all([
      supabase.from('follows').select('follower_id').eq('follower_id', user.id).eq('following_id', userId).maybeSingle(),
      supabase.from('blocks').select('id').eq('blocker_id', user.id).eq('blocked_id', userId).maybeSingle(),
    ]).then(([followRes, blockRes]) => {
      if (!active) return
      if (blockRes.data) setFollowStatus('blocked')
      else if (followRes.data) setFollowStatus('following')
      else setFollowStatus('none')
    })
    return () => { active = false }
  }, [user, userId, isMe])

  // Five seconds on open, then it stops until the sheet is opened again.
  // The old 30-minute localStorage lock is gone with the forever-loop that
  // needed it — see profileEffect.tsx.
  const { playing: effectPlaying } = useProfileEffectPlayback(
    profile?.equipped_profile_effect_url, userId,
  )

  const { badges, defs } = usePlayerBadges(userId)

  // The badge is the source of truth for the orbit, not the Kill Board
  // numbers — if the refresh cron hasn't caught up, the flourish is where
  // the skull actually is.
  const isBoss = badges.some(b => b.badge_id === 'pvp_boss')

  // Best 3 achievements (rarest first, mirrors PlayerProfile.tsx) — the
  // preview only has room to show a highlight reel, not the full case.
  useEffect(() => {
    let active = true
    supabase.from('player_achievements').select('achievement_id, unlocked_at, achievements(title, icon, rarity, category)')
      .eq('user_id', userId)
      .then(({ data }) => {
        if (!active) return
        const rows = (data ?? []) as unknown as { achievement_id: string; unlocked_at: string; achievements: { title: string; icon: string; rarity: string; category: string } | null }[]
        const best = [...rows]
          .sort((a, b) => {
            const rA = ACH_RARITY_RANK[a.achievements?.rarity ?? 'common'] ?? 3
            const rB = ACH_RARITY_RANK[b.achievements?.rarity ?? 'common'] ?? 3
            if (rA !== rB) return rA - rB
            return new Date(b.unlocked_at).getTime() - new Date(a.unlocked_at).getTime()
          })
          .slice(0, BEST_ACHIEVEMENTS_COUNT)
        setBestAchievements(best.map(r => ({
          id: r.achievement_id,
          title: r.achievements?.title ?? 'Achievement',
          icon: r.achievements?.icon ?? 'trophy',
          rarity: r.achievements?.rarity ?? 'common',
          category: r.achievements?.category ?? '',
        })))
      })
    return () => { active = false }
  }, [userId])

  // Wishlist — same source as the full profile's read-only wishlist
  // view: the `wishlist` table, newest-added first, capped at 10.
  useEffect(() => {
    let active = true
    setWishlistLoading(true)
    supabase.from('wishlist').select('id, item_id, item_name, item_image').eq('user_id', userId)
      .order('added_at', { ascending: false }).limit(WISHLIST_MAX)
      .then(({ data }) => {
        if (!active) return
        setWishlist((data ?? []) as PreviewWishlistItem[])
        fetchUngiftableItemIds((data ?? []).map(r => r.item_id)).then(ids => { if (active) setUngiftable(ids) })
        setWishlistLoading(false)
      })
    return () => { active = false }
  }, [userId])

  // Live activity ticker — subscribes to the viewed user's presence
  // channel so "watching a movie" / "playing a game" / "exploring"
  // shows up (and disappears) instantly, same as PlayerProfile.tsx.
  useEffect(() => {
    let cancelled = false
    let channel: ReturnType<typeof supabase.channel> | null = null

    canSeeLiveActivity(user?.id ?? null, userId).then(allowed => {
      if (cancelled || !allowed) return

      channel = supabase.channel(`user-activity:${userId}`, {
        config: { presence: { key: userId } },
      })

      function syncActivity() {
        const state = channel!.presenceState<{ activity: string; game?: string; since?: number }>()
        const entries = Object.values(state).flat()
        const movieEntry = entries.find(e => e.activity === 'watching_movie')
        const gameEntry = entries.find(e => e.activity === 'playing' && e.game)
        const exploreEntry = entries.find(e => e.activity === 'exploring')
        setActivity({ movie: !!movieEntry, game: gameEntry?.game ?? null, gameSince: gameEntry?.since ?? null, exploring: !!exploreEntry })
      }

      channel
        .on('presence', { event: 'sync' }, syncActivity)
        .on('presence', { event: 'join' }, syncActivity)
        .on('presence', { event: 'leave' }, syncActivity)
        .subscribe()
    })

    return () => {
      cancelled = true
      if (channel) supabase.removeChannel(channel)
    }
  }, [userId, user?.id])

  // Live ticker — re-renders once a second while a game session is active
  // so the elapsed-time readout (e.g. "5:51") counts up in real time,
  // matching Discord's own "Playing X" activity card.
  useEffect(() => {
    if (!activity.game || !activity.gameSince) return
    const interval = setInterval(() => setNowTick(Date.now()), 1000)
    return () => clearInterval(interval)
  }, [activity.game, activity.gameSince])

  // Followers / following counts. Always fetched — whether they're shown
  // is decided at render time by show_follow_counts and by whether this
  // is your own profile, since "only me" has to actually mean you.
  useEffect(() => {
    let active = true
    supabase.from('profile_follow_counts').select('followers_count, following_count').eq('id', userId).single()
      .then(({ data }) => {
        if (!active || !data) return
        setFollowers(Number(data.followers_count))
        setFollowing(Number(data.following_count))
      })
    return () => { active = false }
  }, [userId])

  // Like count + whether I've already liked this profile.
  useEffect(() => {
    let active = true
    supabase.from('profile_likes').select('liker_id', { count: 'exact', head: true }).eq('profile_id', userId)
      .then(({ count }) => { if (active) setLikeCount(count ?? 0) })
    if (user) {
      supabase.from('profile_likes').select('liker_id').eq('profile_id', userId).eq('liker_id', user.id).maybeSingle()
        .then(({ data }) => { if (active) setLiked(!!data) })
    }
    return () => { active = false }
  }, [userId, user])

  // Leaderboard position — only worth fetching (all-profiles scan) if the
  // player actually opted into showing it via their grid card picks.
  useEffect(() => {
    if (!profile?.grid_cards?.includes('leaderboard')) { setLbPosition(null); return }
    let active = true
    supabase.from('profiles').select('id, active_rank_xp').order('active_rank_xp', { ascending: false })
      .then(({ data }) => {
        if (!active) return
        const pos = (data ?? []).findIndex((p: { id: string }) => p.id === userId)
        setLbPosition(pos >= 0 ? pos + 1 : null)
      })
    return () => { active = false }
  }, [userId, profile?.grid_cards])

  // Equipped + showcased artifacts — the equipped one shown alongside
  // equipped avatar in the Stats tab, both surfaced together in
  // ArtifactQuickSheet. See migration 0096 for is_equipped/is_showcased.
  useEffect(() => {
    let active = true
    supabase.rpc('get_player_artifact_showcase', { p_user_id: userId }).then(({ data }) => {
      if (!active) return
      const rows = (data ?? []) as Array<{
        artifact_id: string; is_equipped: boolean; is_showcased: boolean
        name: string; media_url: string | null; tier: string
      }>
      const equipped = rows.find(r => r.is_equipped)
      setEquippedArtifact(equipped?.name ?? null)
      setEquippedArtifactImage(equipped?.media_url ?? null)
      setEquippedArtifactTier(equipped?.tier ?? null)
      setShowcasedArtifacts(
        rows.filter(r => r.is_showcased).slice(0, 3).map(r => ({
          id: r.artifact_id,
          name: r.name,
          mediaUrl: r.media_url,
          tier: r.tier,
        }))
      )
    })
    return () => { active = false }
  }, [userId])

  // Star rating for the favorite-game card.
  useEffect(() => {
    if (!profile?.favorite_game) { setFavoriteGameRank(null); return }
    let active = true
    getAllPlayerRanks(userId).then(ranks => {
      if (!active) return
      const row = ranks[profile.favorite_game as keyof typeof ranks]
      setFavoriteGameRank(row?.rank ?? null)
    })
    return () => { active = false }
  }, [userId, profile?.favorite_game])

  // Album pics fetch removed — it only existed to feed Edit Profile's banner
  // picker, which was removed (banners are equipped via Inventory instead).

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false)
    }
    if (menuOpen) document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [menuOpen])

  function close() {
    setClosing(true)
    setTimeout(onClose, 200)
  }

  /**
   * Hop from this profile to someone else's — the club owner row, the duo
   * partner row, etc.
   *
   * Deliberately does NOT call close() first. The provider swaps the
   * target in one setState and the new sheet animates in on its own; a
   * close() here would only queue a timer that fights the profile that
   * just opened (see ProfilePreview.tsx for the full story). Falls back
   * to the /profile/:id route if this ever renders outside the provider.
   */
  function openOtherProfile(id: string) {
    if (onOpenOtherProfile) onOpenOtherProfile(id)
    else { close(); navigate(`/profile/${id}`) }
  }

  async function handleFollow() {
    if (!user || busy || followStatus === 'blocked') return
    setBusy(true)
    if (followStatus === 'following') {
      await supabase.from('follows').delete().eq('follower_id', user.id).eq('following_id', userId)
      setFollowStatus('none')
      setFollowers(f => Math.max(0, f - 1))
    } else {
      await supabase.from('follows').insert({ follower_id: user.id, following_id: userId })
      trackWeeklyUniqueValue(user.id, 'users_followed', userId).catch(console.error)
      setFollowStatus('following')
      setFollowers(f => f + 1)
      // Following a private profile is the one action that changes what the
      // server will hand back, so re-read it. Without this the viewer taps
      // Follow, the button flips, and the sections they followed FOR stay
      // locked until they close and reopen the sheet.
      const { data: unlocked } = await supabase
        .rpc('get_public_profile', { p_user_id: userId }).single()
      if (unlocked) {
        setProfile(unlocked as PreviewProfile)
        setVibe(vibeFrom(unlocked as PreviewProfile))
      }
    }
    setBusy(false)
  }

  async function handleLike() {
    if (!user || liking) return
    setLiking(true)
    if (liked) {
      const { error } = await supabase.from('profile_likes').delete().eq('profile_id', userId).eq('liker_id', user.id)
      if (!error) { setLiked(false); setLikeCount(c => Math.max(0, c - 1)) }
    } else {
      const { error } = await supabase.from('profile_likes').insert({ profile_id: userId, liker_id: user.id })
      if (!error) { setLiked(true); setLikeCount(c => c + 1) }
    }
    setLiking(false)
  }

  async function handleBlock() {
    if (!user || busy) return
    setBusy(true)
    if (followStatus === 'blocked') {
      await supabase.from('blocks').delete().eq('blocker_id', user.id).eq('blocked_id', userId)
      setFollowStatus('none')
    } else {
      await supabase.from('blocks').insert({ blocker_id: user.id, blocked_id: userId })
      setFollowStatus('blocked')
    }
    setBusy(false)
    setMenuOpen(false)
  }

  function handleCopyUsername() {
    if (!profile) return
    navigator.clipboard.writeText(`@${profile.username}`).then(() => {
      setUsernameCopied(true)
      setTimeout(() => { setUsernameCopied(false); setMenuOpen(false) }, 1000)
    }).catch(() => setMenuOpen(false))
  }

  function goToChat() {
    close()
    navigate('/chat', { state: { openDmWith: userId } })
  }

  async function handleCall() {
    if (!profile || callStarting || phase !== 'idle') return
    setCallStarting(true)
    try {
      const { data: roomId, error } = await supabase.rpc('get_or_create_dm_room', { p_other_user_id: userId })
      if (error || !roomId) { setCallStarting(false); return }
      await startCall(roomId as string, {
        id: profile.id, username: profile.username, display_name: profile.display_name, avatar: profile.avatar,
      }, 'audio')
      close()
    } finally {
      setCallStarting(false)
    }
  }

  const displayName = profile?.display_name || profile?.username || '…'
  const rank = profile ? getUserRankTier(profile.active_rank_xp ?? profile.xp) : null
  const presence: Presence = (profile?.presence as Presence) || 'offline'
  // Server-side truth: everything this viewer would otherwise see has already
  // been withheld by get_public_profile, so this only decides what to render
  // in its place.
  const suspended = !!profile?.is_suspended
  const memberSince = profile
    ? new Date(((isModerator || isOfficial) ? profile.staff_member_since : null) ?? profile.created_at)
      .toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
    : ''

  // Badge row composition: the rank tier now takes the first slot (it
  // renders as one of these icons, not its own separate pill), then real
  // badges fill the rest by rarity — except the legacy-username badge,
  // which is pinned and can never be bumped out no matter how the rest
  // sorts. Total row length, rank included, never exceeds BADGE_PREVIEW_COUNT.
  const allOwnedDefs = [...badges]
    .map(b => defs.find(d => d.id === b.badge_id))
    .filter((d): d is NonNullable<typeof d> => !!d)

  const legacyBadge = allOwnedDefs.find(d => d.is_dynamic_username)
  const rankedBadges = allOwnedDefs
    .filter(d => !d.is_dynamic_username && !isChampionshipBadge(d.id))
    .sort((a, b) => (BADGE_RARITY_RANK[a.rarity] ?? 9) - (BADGE_RARITY_RANK[b.rarity] ?? 9))

  const rankSlot = rank ? 1 : 0
  const legacySlot = legacyBadge ? 1 : 0
  const remainingSlots = Math.max(0, BADGE_PREVIEW_COUNT - rankSlot - legacySlot)

  const ownedBadges = [
    ...rankedBadges.slice(0, remainingSlots),
    ...(legacyBadge ? [legacyBadge] : []),
  ]

  const proInfo = profile
    ? { isPro: !!profile.is_pro, tier: profile.pro_tier ?? null, color: profile.pro_badge_color ?? null, memberSince: profile.pro_first_subscribed_at ?? null }
    : null

  // "Below About Me" trophy case — Championship results ONLY (Champion /
  // Runner-up / 3rd Place). Deliberately separate from the compact badge
  // strip above (which is auto-composed, rank-slotted, and still shows any
  // badge type). Not the player's featured_badge_ids pick, not a
  // rarest-owned fallback — see championshipTrophyBadges' header comment.
  // Renders nothing when the profile holds none of the three.
  const featuredDefs = championshipTrophyBadges(
    new Set(allOwnedDefs.map(d => d.id)),
    allOwnedDefs,
  )

  // Which season each trophy-case badge was earned in — see the matching
  // effect/comment in Profile.tsx (own-profile version of this same panel).
  const [championshipSeasonByBadge, setChampionshipSeasonByBadge] = useState<Map<string, number>>(new Map())
  useEffect(() => {
    if (featuredDefs.length === 0 || !profile?.id) return
    let cancelled = false
    ;(async () => {
      const seasons = await getSeasonPlacements().catch(() => [])
      if (cancelled) return
      const map = new Map<string, number>()
      for (const season of seasons) {
        if (season.champion_user_id === profile.id && !map.has('championship_champion')) map.set('championship_champion', season.season_number)
        if (season.runner_up_user_id === profile.id && !map.has('championship_runnerup')) map.set('championship_runnerup', season.season_number)
        if (season.third_place_user_id === profile.id && !map.has('championship_third_place')) map.set('championship_third_place', season.season_number)
      }
      setChampionshipSeasonByBadge(map)
    })()
    return () => { cancelled = true }
  }, [featuredDefs.length, profile?.id])

  // ALWAYS a bottom sheet — phone and tablet alike, no separate centered
  // "desktop popover" mode. It slides up from the bottom and stays pinned
  // there until dismissed.
  //
  // Height: minHeight keeps it rising well up the screen even for a
  // sparse profile (this is what was missing before — it was hugging
  // short content and sitting low). maxHeight is the only thing content
  // can push past, and only then does the body start scrolling.
  //
  // Width: full-bleed edge-to-edge on phones; on wider viewports (tablet
  // and up) it narrows into a centered card shape, but it's still bottom-
  // anchored the whole time — it never jumps to floating in the middle.
  // A FIXED height per breakpoint now, not a min/max range — this is the
  // one thing that was still wrong. However stacked a profile is, the
  // sheet stops at this exact point and its own body scrolls past it;
  // it never grows taller, and it never sits shorter for a sparse profile.
  const sheetBase: React.CSSProperties = {
    width: isWide ? 'min(92vw, 460px)' : '100%',
    height: sheetHeightPx,
    maxHeight: sheetHeightPx,
    borderRadius: '28px 28px 0 0',
    marginTop: 'auto',
    transform: entered && !closing && !showBadgesModal && !showBadgeQuickSheet && !followSheetMode && !showAvatarQuickSheet && !showArtifactQuickSheet && !clubSheetOpen
      ? `translateY(${dragY}px)`
      : 'translateY(100%)',
    transition: dragging ? 'none' : 'transform 0.32s cubic-bezier(0.32,0.72,0,1)',
  }

  return createPortal(
    <div
      onClick={close}
      className="pv-backdrop"
      data-cv-holo={profile?.holo_profile_enabled ? '1' : undefined}
      style={{
        position: 'fixed', inset: 0, zIndex: 20000,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        opacity: entered && !closing ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      <div
        // sheetProps gives the sheet drag-to-dismiss from ANYWHERE inside
        // it, not just the banner — it engages only when the content under
        // your finger is already scrolled to the top, so the body still
        // scrolls normally. See useBottomSheet.ts.
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        data-cv-skin={profileSkinAttr(profile?.profile_ui_skin)}
        // The Dynamic Profile is a version, so it sits ABOVE a UI skin —
        // holo-skin.css wins with !important where the two overlap.
        data-cv-holo={profile?.holo_profile_enabled ? '1' : undefined}
        style={{
          ...sheetBase,
          ...profileSkinBackground(profile?.profile_ui_skin, profile?.profile_theme_color ?? 'var(--bg)'),
          overflowY: isPreview ? 'hidden' : 'auto', overscrollBehavior: 'contain', position: 'relative',
          boxShadow: '0 -12px 40px -12px var(--sh)',
        }}
      >
        {profile?.profile_ui_skin && <ProfileSkinStyles />}
        {/* Drag-to-dismiss zone widened to the whole banner strip, not just
            the thin 4px pill — a lot easier to grab with a thumb, and the
            banner has no other gesture competing for it. Close/menu buttons
            below are siblings positioned outside this box, so they stay
            independently tappable regardless of what this captures. */}
        <div {...dragHandleProps} style={{ ...dragHandleProps.style, display: 'block' }}>
          <div style={{ padding: '10px 0 8px', display: 'flex', justifyContent: 'center' }}>
            <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
          </div>

          {/* Banner — kept generously tall even with the default gradient
              (no banner equipped), so it doesn't read as a thin strip. */}
          <div style={{ position: 'relative', height: 130, background: profile?.banner_url ? 'transparent' : 'linear-gradient(120deg, var(--accent), var(--accent2))', overflow: 'hidden' }}>
            {profile?.banner_url && (
              <img src={profile.banner_url} alt="banner" style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center' }} />
            )}
          </div>
        </div>

        {/* The vibe bubble — a SIBLING of the drag zone above, for two
            reasons, both load-bearing. It sits level with the avatar's
            upper half, so it crosses the banner's bottom edge and would
            be sliced in half by the banner's overflow:hidden; and the
            whole banner strip carries dragHandleProps, so anything nested
            inside it has its taps swallowed by the drag gesture. The
            close/menu buttons below are outside for the same reason.

            Offsets are measured against this sheet's own stack: 22px of
            drag-pill row + a 130px banner puts the avatar's top edge at
            118, and the 68px avatar's right edge at 86. */}
        {(vibe || isMe) && !isPreview && (
          <VibeBubble
            vibe={vibe}
            isMe={isMe}
            onEdit={isMe ? () => setVibeSheetOpen(true) : undefined}
            top={126}
            left={98}
          />
        )}

        {/* Close + menu buttons live outside the banner's overflow:hidden
            box now, so the dropdown floats over the card instead of being
            clipped/"sunk" into the banner. */}
        <button
          type="button" onClick={close}
          className="pv-btn"
          style={{ position: 'absolute', top: 10, right: 46, width: 30, height: 30, borderRadius: 9, background: 'rgba(0,0,0,0.28)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', zIndex: 2 }}
        >
          <X size={15} color="#fff" />
        </button>
        <div ref={menuRef} style={{ position: 'absolute', top: 10, right: 10, zIndex: 2 }}>
          <button
            type="button" onClick={() => setMenuOpen(v => !v)}
            className="pv-btn"
            style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(0,0,0,0.28)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <MoreVertical size={15} color="#fff" />
          </button>
          {menuOpen && (
            <div style={{
              position: 'absolute', top: 36, right: 0, minWidth: 190, background: 'var(--surface2)',
              border: '1px solid var(--border)', borderRadius: 14, padding: 6,
              boxShadow: 'var(--elev-raise)', zIndex: 1,
            }}>
              <MenuItem icon={usernameCopied ? <Check size={14} /> : <Copy size={14} />} label={usernameCopied ? 'Copied!' : 'Copy username'} onClick={handleCopyUsername} />
              {!isMe && (
                <MenuItem
                  icon={<ShieldOff size={14} />}
                  label={followStatus === 'blocked' ? 'Unblock user' : 'Block user'}
                  danger
                  onClick={handleBlock}
                />
              )}
              {!isMe && followStatus !== 'blocked' && (
                <MenuItem
                  icon={<Users size={14} />}
                  label="Invite to your club"
                  onClick={() => { setMenuOpen(false); setInvitePickerOpen(true) }}
                />
              )}
              {!isMe && (
                <MenuItem icon={<Flag size={14} />} label="Report" danger onClick={() => { setMenuOpen(false); setReportOpen(true) }} />
              )}
            </div>
          )}
        </div>

        {isPreview && (
          <div
            onClick={e => e.stopPropagation()}
            style={{ position: 'absolute', inset: 0, top: 130, zIndex: 1, cursor: 'default' }}
          />
        )}

        <div style={{ padding: '0 18px 20px' }}>
          {/* Avatar overlapping the banner */}
          <div style={{ marginTop: -34, marginBottom: 8 }}>
            <div style={{ position: 'relative', width: 68, height: 68 }}>
              {/* The boss's orbit and the worn drip, and only ever on an
                  opened profile — see BossOrbit for why this isn't an
                  Avatar decoration. DrippedPortrait owns the stacking:
                  jelly deforms the picture, ice covers it, the orbit rides
                  over both. Choosing what to wear lives in Edit Profile —
                  a tappable portrait looks like nothing and nobody found
                  it. */}
              <DrippedPortrait
                drip={isDripKey(profile?.drip) ? profile.drip : null}
                size={68}
                boss={isBoss}
              >
                <Avatar
                  src={isModerator ? MOD_AVATAR_URL : profile?.avatar} name={displayName} size={68} radius={20}
                  ownerId={userId}
                  ring="var(--bg)" disabled
                  style={suspended ? { filter: 'grayscale(1)', opacity: 0.65 } : undefined}
                />
              </DrippedPortrait>
              {/* A suspended account gets a 🚫 badge where the green/amber
                  presence dot would sit — the same slot, so it reads as "this
                  is their status" rather than as decoration. The badge is
                  wider than the dot because a glyph needs the room. */}
              {suspended ? (
                <div style={{
                  position: 'absolute', bottom: -4, right: -4, width: 24, height: 24, borderRadius: '50%',
                  background: '#ff4d4d', border: '3px solid var(--bg)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Ban size={12} color="#fff" strokeWidth={2.6} />
                </div>
              ) : (
                <div style={{
                  position: 'absolute', bottom: -2, right: -2, width: 16, height: 16, borderRadius: '50%',
                  background: PRESENCE_COLORS[presence], border: '3px solid var(--bg)',
                }} />
              )}
            </div>
          </div>

          {loading ? (
            <div style={{ paddingTop: 2 }}>
              <div className="pv-skel" style={{ height: 19, width: '52%', borderRadius: 6, marginBottom: 8 }} />
              <div className="pv-skel" style={{ height: 12, width: '32%', borderRadius: 5, marginBottom: 16 }} />
              <div className="pv-skel" style={{ height: 64, width: '100%', borderRadius: 12 }} />
            </div>
          ) : !profile ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-dim)', padding: '20px 0' }}>This profile couldn't be loaded.</p>
          ) : suspended ? (
            /* Everything below this branch — the follow/message/call row, the
               stats table, followers, Battle, wishlist, clubs, badges, the
               tab strip — is skipped wholesale rather than hidden piece by
               piece. One branch can't drift out of sync the way eight
               separate `&& !suspended` guards would. */
            <>
              <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)', margin: 0 }}>{displayName}</p>
              <p style={{ fontSize: 12.5, color: 'var(--text-dim)', marginTop: 4 }}>@{profile.username}</p>
              <SuspensionNotice title={profile.suspension_title} reason={profile.suspension_reason} />
            </>
          ) : (
            <>
              {/* Name row — display name on the left, like count pinned to
                  the far right (this is the position marked on the
                  reference screenshot: level with the name, right edge). */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: 6, minWidth: 0, ...nameStyleFor(profile) }}>
                  {displayName}
                  {isOfficial && <VerifiedBadge size={15} />}
                </p>
                {!isOfficial && <button
                  type="button" onClick={(e) => { ripple(e); handleLike() }} disabled={!user || liking}
                  className="ripple-wrap pv-btn"
                  style={{
                    flexShrink: 0, display: 'flex', alignItems: 'center', gap: 5, padding: '5px 10px', borderRadius: 10,
                    border: `1px solid ${liked ? 'rgba(255,77,139,0.4)' : 'rgba(255,255,255,0.1)'}`,
                    background: liked ? 'rgba(255,77,139,0.14)' : 'var(--surface2)',
                    cursor: (!user || liking) ? 'default' : 'pointer',
                  }}
                >
                  <Heart size={12} color={liked ? '#ff4d8b' : 'var(--text-muted)'} style={{ fill: liked ? '#ff4d8b' : 'none' }} />
                  <span style={{ fontSize: 11.5, fontWeight: 700, color: liked ? '#ff4d8b' : 'var(--text-dim)' }}>{likeCount}</span>
                </button>}
              </div>

              {/* Handle row — @username on the left; gender pill (sitting
                  where Discord shows a role/pronoun tag) and the badge
                  strip on the right, all on one straight line, never
                  wrapping into a grid. */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginTop: 4 }}>
                <p style={{ fontSize: 12.5, color: 'var(--text-dim)', flexShrink: 0 }}>@{profile.username}</p>

                <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0, overflowX: 'auto' }}>
                  {!isModerator && !isOfficial && profile.info_tags?.includes('gender') && profile.gender && (
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 9px', borderRadius: 8, background: 'var(--surface2)', border: '1px solid var(--border-strong)', flexShrink: 0 }}>
                      <UserRound size={12} style={{ color: 'var(--text-muted)' }} />
                      <span style={{ fontSize: 10, fontWeight: 800, color: 'var(--text-dim)', letterSpacing: 0.3 }}>
                        {GENDER_LABELS[profile.gender] ?? profile.gender.toUpperCase()}
                      </span>
                    </div>
                  )}

                  {/* Badge strip — rank tier is the first icon, then real
                      badges by rarity, one straight horizontal line inside
                      a single bordered box (never a wrapping grid). */}
                  {!isModerator && !isOfficial && (profile.is_pro || rank || ownedBadges.length > 0) && (
                    <div style={{ display: 'flex', flexWrap: 'nowrap', alignItems: 'center', gap: 4, padding: 4, borderRadius: 8, background: 'var(--surface2)', border: '1px solid var(--border-strong)', flexShrink: 0 }}>
                      {profile.is_pro && profile.pro_tier && (
                        <ProBadge
                          tier={profile.pro_tier}
                          color={profile.pro_badge_color}
                          memberSince={profile.pro_first_subscribed_at}
                          size={20}
                        />
                      )}
                      {rank && (
                        <button
                          type="button"
                          className="pv-btn"
                          onClick={() => setShowRankToast(true)}
                          title={rank.name}
                          style={{ width: 20, height: 20, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', background: rank.color + '1c', border: `1px solid ${rank.color}44`, cursor: 'pointer', padding: 0, flexShrink: 0 }}
                        >
                          <RankBadge tier={rank} size={14} />
                        </button>
                      )}
                      {ownedBadges.map(def => {
                        const color = BADGE_RARITY_COLOR[def.rarity] ?? '#888899'
                        const championshipSrc = championshipBadgeSrc(def.id)
                        const isSubscriberBadge = !!subscriberBadgeTier(def.id)
                        return (
                          <button
                            key={def.id}
                            type="button"
                            className="pv-btn"
                            onClick={() => setBadgeToast(def)}
                            title={badgeDisplayTitle(def, profile.original_username)}
                            style={{ width: 20, height: 20, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', background: color + '1c', border: `1px solid ${color}33`, cursor: 'pointer', padding: 0, flexShrink: 0 }}
                          >
                            {championshipSrc
                              ? <img src={championshipSrc} alt={def.title} width={14} height={14} style={{ display: 'block' }} />
                              : isSubscriberBadge
                                ? <img src={proBadgeSrc(proInfo?.color)} alt={def.title} width={12} height={12} style={{ display: 'block' }} />
                                : <BadgeIcon iconKey={def.icon} size={10} color={color} />}
                          </button>
                        )
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* Moderators are followable now. The whole action row used
                  to be hidden on a mod's profile, which took Follow out
                  with it — there was no way to follow staff at all.
                  Message and Call stay hidden for mods on purpose: a
                  public "call this moderator" button is an invitation to
                  get spammed, and support already has its own channel.
                  Follow is one-way and passive, so it's safe to expose. */}
              {!isMe && !isPreview && (
                <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                  <button
                    type="button" onClick={(e) => { ripple(e); handleFollow() }} disabled={busy || followStatus === 'blocked'}
                    className="ripple-wrap pv-btn"
                    style={{
                      flex: 1, padding: '11px 8px', borderRadius: 13, fontSize: 12.5, fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, border: 'none',
                      cursor: followStatus === 'blocked' ? 'not-allowed' : 'pointer',
                      background: followStatus === 'following' ? 'rgba(62,207,142,0.15)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
                      color: followStatus === 'following' ? '#3ecf8e' : '#fff',
                      opacity: followStatus === 'blocked' ? 0.4 : 1,
                    }}
                  >
                    {followStatus === 'following' ? <UserCheck size={14} /> : <UserPlus size={14} />}
                    {/* "Add Friend" reads oddly for staff — you're
                        subscribing to a moderator, not befriending one. */}
                    {followStatus === 'following' ? 'Following' : (isModerator || isOfficial) ? 'Follow' : 'Add Friend'}
                  </button>
                  {!isModerator && (
                    <>
                      <button
                        type="button" onClick={(e) => { ripple(e); goToChat() }}
                        className="ripple-wrap pv-btn"
                        style={{ padding: '11px 14px', borderRadius: 13, border: 'none', background: 'var(--surface2)', color: 'var(--text)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                      >
                        <MessageCircle size={16} />
                      </button>
                      {!isOfficial && <button
                        type="button" onClick={(e) => { ripple(e); handleCall() }} disabled={callStarting || phase !== 'idle'}
                        className="ripple-wrap pv-btn"
                        title={phase !== 'idle' ? 'Already on a call' : `Call ${displayName}`}
                        style={{ padding: '11px 14px', borderRadius: 13, border: 'none', background: 'var(--surface2)', color: (callStarting || phase !== 'idle') ? 'var(--text-muted)' : 'var(--text)', cursor: (callStarting || phase !== 'idle') ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: (callStarting || phase !== 'idle') ? 0.5 : 1 }}
                      >
                        <Phone size={16} />
                      </button>}
                    </>
                  )}
                </div>
              )}

              {!isModerator && isMe && !isPreview && (
                <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                  <button
                    type="button" onClick={(e) => { ripple(e); setShowEdit(true) }}
                    className="ripple-wrap pv-btn btn-primary"
                    style={{
                      flex: 1, padding: '11px 8px', borderRadius: 13, fontSize: 12.5, fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, border: 'none', cursor: 'pointer',
                    }}
                  >
                    <Edit3 size={14} /> Edit Profile
                  </button>
                  <button
                    type="button" onClick={(e) => { ripple(e); close(); navigate('/referral') }}
                    className="ripple-wrap pv-btn"
                    style={{
                      flex: 1, padding: '11px 8px', borderRadius: 13, fontSize: 12.5, fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, border: 'none',
                      background: 'var(--surface2)', color: 'var(--text)', cursor: 'pointer',
                    }}
                  >
                    <Gift size={14} /> Refer & Earn
                  </button>
                </div>
              )}

              {!isModerator && isMe && !isPreview && profile && !isProActive(profile) && !upgradePromoDismissed && (
                <>
                  <style>{`
                    @keyframes cvUpgradePromoGlow {
                      0%, 100% { box-shadow: 0 0 10px rgba(155,109,255,0.18), inset 0 0 20px rgba(155,109,255,0.05); }
                      50%      { box-shadow: 0 0 18px rgba(155,109,255,0.32), inset 0 0 20px rgba(155,109,255,0.08); }
                    }
                  `}</style>
                  <div style={{
                    position: 'relative', marginTop: 14, padding: '14px 16px', borderRadius: 16,
                    background: 'linear-gradient(135deg, rgba(155,109,255,0.10), rgba(79,142,247,0.08))',
                    border: '1px solid rgba(155,109,255,0.35)',
                    animation: 'cvUpgradePromoGlow 2.8s ease-in-out infinite',
                  }}>
                  <button
                    type="button" onClick={(e) => { ripple(e); dismissUpgradePromo() }}
                    aria-label="Dismiss"
                    style={{ position: 'absolute', top: 10, right: 10, width: 22, height: 22, borderRadius: '50%', border: 'none', background: 'rgba(255,255,255,0.08)', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                  >
                    <X size={12} />
                  </button>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10, paddingRight: 22 }}>
                    <Sparkles size={15} style={{ color: '#9b6dff', flexShrink: 0 }} />
                    <span style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--text)' }}>Unlock Profile Upgrades</span>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button
                      type="button" onClick={(e) => { ripple(e); close(); navigate('/pro') }}
                      className="ripple-wrap"
                      style={{ flex: 1, padding: '9px 8px', borderRadius: 12, fontSize: 12, fontWeight: 700, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, background: '#9b6dff', color: '#fff' }}
                    >
                      <Sparkles size={13} /> Explore Pro
                    </button>
                    <button
                      type="button" onClick={(e) => { ripple(e); close(); navigate('/mall') }}
                      className="ripple-wrap"
                      style={{ flex: 1, padding: '9px 8px', borderRadius: 12, fontSize: 12, fontWeight: 700, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, background: 'rgba(255,255,255,0.08)', color: 'var(--text)' }}
                    >
                      <Package size={13} /> Mall
                    </button>
                  </div>
                </div>
                </>
              )}

              {activity.movie && (
                <div style={{ marginTop: 10, padding: '8px 12px', borderRadius: 12, background: 'color-mix(in srgb, var(--accent) 10%, transparent)', border: '1px solid color-mix(in srgb, var(--accent) 28%, transparent)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 8px var(--accent)', animation: 'pulse 1.5s ease-in-out infinite', flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: 'var(--text)', fontWeight: 600 }}>🎬 Watching movies</span>
                </div>
              )}

              {activity.game && (() => {
                const isMino = activity.game === MINO_GAME_ID
                const gameMeta = getGameById(activity.game as string)
                const GameIcon = gameMeta?.icon
                const elapsed = activity.gameSince ? formatElapsed(nowTick - activity.gameSince) : null
                const boxSize = isMino ? 40 : 34
                return (
                  <div style={{ marginTop: 10, padding: isMino ? '12px 14px' : '10px 12px', borderRadius: isMino ? 14 : 12, background: 'rgba(79,142,247,0.1)', border: '1px solid rgba(79,142,247,0.25)', display: 'flex', alignItems: 'center', gap: isMino ? 12 : 10 }}>
                    <div style={{ width: boxSize, height: boxSize, borderRadius: isMino ? 11 : 9, background: 'rgba(79,142,247,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
                      {isMino
                        ? <img src={MINO_ICON_URL} alt={MINO_GAME_NAME} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        : GameIcon ? <GameIcon size={16} style={{ color: '#4f8ef7' }} /> : <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#4f8ef7' }} />}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: isMino ? 14 : 12, color: 'var(--text)', fontWeight: 700 }}>
                        Playing <strong style={{ color: '#4f8ef7' }}>{isMino ? MINO_GAME_NAME : (gameMeta?.name ?? activity.game)}</strong>
                      </div>
                      {elapsed && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
                          <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#4f8ef7', boxShadow: '0 0 6px #4f8ef7', animation: 'pulse 1.5s ease-in-out infinite', flexShrink: 0 }} />
                          <span style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{elapsed}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })()}

              {activity.exploring && (
                <div style={{ marginTop: 10, padding: '8px 12px', borderRadius: 12, background: 'rgba(62,207,142,0.1)', border: '1px solid rgba(62,207,142,0.28)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#3ecf8e', boxShadow: '0 0 8px #3ecf8e', animation: 'pulse 1.5s ease-in-out infinite', flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: 'var(--text)', fontWeight: 600 }}>⛵️ Exploring</span>
                </div>
              )}

              {/* Main / Wishlist / Stats tabs — wishlist can't be hidden, so
                  the tab is always shown even for a profile with nothing in it. */}
              {!isOfficial && <div style={{ display: 'flex', marginTop: 16, borderBottom: '1px solid var(--border)' }}>
                {(['main', 'wishlist', 'stats', 'battle'] as const).map(tab => (
                  <button
                    key={tab}
                    type="button"
                    className="pv-btn"
                    onClick={() => setActiveTab(tab)}
                    style={{
                      flex: 1, padding: '9px 4px', background: 'none', border: 'none', cursor: 'pointer',
                      fontSize: 12.5, fontWeight: 700, textTransform: 'capitalize',
                      color: activeTab === tab ? 'var(--text)' : 'var(--text-muted)',
                      borderBottom: activeTab === tab ? '2px solid var(--accent)' : '2px solid transparent',
                      marginBottom: -1,
                    }}
                  >
                    {tab}
                  </button>
                ))}
              </div>}

              {activeTab === 'main' ? (
                <div className="pv-panel" style={{ marginTop: 12, background: 'var(--surface)', borderRadius: 12, padding: '2px 12px' }}>
                  {/* Follower counts, or the reason they're missing. The
                      notice has to carry the Follow button itself — an
                      explanation with no action just tells someone they
                      can't have something. */}
                  {restricted ? (
                    <div className="pv-section">
                      <PrivateProfileNotice
                        username={profile.username}
                        variant="row"
                        onFollow={handleFollow}
                        busy={busy}
                      />
                    </div>
                  ) : (
                  <div className="pv-section" style={{ display: 'flex', gap: 8 }}>
                    <button
                      type="button"
                      className="pv-btn"
                      onClick={() => {
                        if (!profile.show_follow_counts && !isMe) {
                          setFollowCountsToast(`Only @${profile.username} can see their followers and following`)
                        } else {
                          setFollowSheetMode('followers')
                        }
                      }}
                      style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, padding: '10px 8px', borderRadius: 13, background: 'var(--surface2)', border: '1px solid var(--border)', cursor: 'pointer', fontFamily: 'inherit' }}
                    >
                      <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>{followers.toLocaleString()}</span>
                      <span style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.3 }}>Followers</span>
                    </button>
                    <button
                      type="button"
                      className="pv-btn"
                      onClick={() => {
                        if (!profile.show_follow_counts && !isMe) {
                          setFollowCountsToast(`Only @${profile.username} can see their followers and following`)
                        } else {
                          setFollowSheetMode('following')
                        }
                      }}
                      style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, padding: '10px 8px', borderRadius: 13, background: 'var(--surface2)', border: '1px solid var(--border)', cursor: 'pointer', fontFamily: 'inherit' }}
                    >
                      <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>{following.toLocaleString()}</span>
                      <span style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.3 }}>Following</span>
                    </button>
                  </div>
                  )}

                  {/* First Blood — directly under the followers row, for
                      whoever took the day's first kill app-wide. Sits
                      OUTSIDE the restricted ternary above deliberately: a
                      followers-only profile still shows badges, the PvP
                      panel and achievements, so hiding a kill that happened
                      in public would be the odd one out. Renders nothing
                      for everyone else, which is almost everyone. */}
                  <FirstBloodMarker userId={userId} isMe={isMe} variant="panel" />

                  {profile.bio && (
                    <div className="pv-section">
                      <p style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 6 }}>About Me</p>
                      <p style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.5, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{profile.bio}</p>
                    </div>
                  )}

                  {/* Championship trophy case — Champion / Runner-up / 3rd
                      Place only. Large, medal-case presentation matching
                      the redesign in Profile.tsx (own-profile view) — the
                      real shield artwork has fine detail that was
                      previously illegible at 28px. Separate from the
                      compact strip next to the display name above: that
                      one is auto-composed and rank-slotted, this one is a
                      deliberate showcase. */}
                  {featuredDefs.length > 0 && (
                    <div className="pv-section">
                      <p style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 10 }}>
                        🏆 Championship
                      </p>
                      <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 2 }}>
                        {featuredDefs.map(def => {
                          const championshipSrc = championshipBadgeSrc(def.id)
                          return (
                            <button
                              key={def.id}
                              type="button"
                              className="pv-btn"
                              onClick={() => setChampionshipPreview(def)}
                              style={{
                                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, flexShrink: 0,
                                width: 128, padding: '8px', cursor: 'pointer', background: 'none', border: 'none',
                              }}
                            >
                              <div style={{ width: 128, height: 88, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                                {championshipSrc
                                  ? <img src={championshipSrc} alt={def.title} width={128} height={88} style={{ display: 'block', objectFit: 'contain' }} />
                                  : <BadgeIcon iconKey={def.icon} size={56} color={BADGE_RARITY_COLOR[def.rarity] ?? '#888899'} />}
                              </div>
                              <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--text)', textAlign: 'center', lineHeight: 1.25 }}>
                                {badgeDisplayTitle(def, profile.original_username)}
                              </span>
                              {championshipSeasonByBadge.has(def.id) && (
                                <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-dim)' }}>
                                  Season {championshipSeasonByBadge.get(def.id)}
                                </span>
                              )}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  <div className="pv-section">
                    <p style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 6 }}>Member Since</p>
                    <p style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>{memberSince}</p>
                  </div>

                  {/* Club — sits directly under Member Since, above Dynamic
                      Duo. Same exclusion as Duo: official accounts aren't
                      players and don't join clubs. */}
                  {!isOfficial && !isPreview && (
                    <ProfileClubsSection
                      userId={userId}
                      isMe={isMe}
                      onSheetToggle={setClubSheetOpen}
                      onOpenClub={id => { close(); navigate(`/clubs/${id}`) }}
                      onOpenProfile={openOtherProfile}
                    />
                  )}

                  {/* Dynamic Duo — sits directly under Member Since. Hidden only
                      on official accounts (Chillverse etc), which aren't players.
                      Staff and moderators play the daily loop like anyone else. */}
                  {!isOfficial && !isPreview && (
                    <DuoSection
                      userId={userId}
                      isMe={isMe}
                      onOpenProfile={openOtherProfile}
                    />
                  )}

                  {!isModerator && !isPreview && bestAchievements.length > 0 && (
                    <div className="pv-section">
                      <p style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Achievements</p>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                        {bestAchievements.map(a => {
                          const color = a.category === 'pvp'
                            ? PVP_ACH_COLOR
                            : (ACH_RARITY_COLOR[a.rarity] ?? '#888899')
                          return (
                            <button
                              key={a.id}
                              type="button"
                              className="pv-btn"
                              onClick={() => setAchToast(a)}
                              style={{
                                display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px 3px 6px', borderRadius: 20,
                                background: color + '18', border: `1px solid ${color}44`, cursor: 'pointer',
                              }}
                            >
                              <AchIcon iconKey={a.icon} size={10} color={color} />
                              <span style={{ fontSize: 10.5, fontWeight: 700, color }}>{a.title}</span>
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}
                </div>
              ) : activeTab === 'wishlist' ? (
                <div style={{ marginTop: 12 }}>
                  {wishlistLoading ? (
                    <div className="pv-skel" style={{ height: 44, width: '100%', borderRadius: 12 }} />
                  ) : wishlist.length === 0 ? (
                    <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '16px 0' }}>Wishlist is empty</p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      {!isMe && (
                        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 2 }}>Tap an item to send it as a gift</p>
                      )}
                      {wishlist.map(item => (
                        <button
                          key={item.id}
                          type="button"
                          className="pv-btn"
                          disabled={isMe}
                          onClick={() => {
                            if (isMe) return
                            if (item.item_id && ungiftable.has(item.item_id)) { setGiftToast(GIFT_UNAVAILABLE_MESSAGE); return }
                            setGiftTarget({ itemId: item.item_id, itemName: item.item_name, itemImage: item.item_image })
                          }}
                          style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 12, background: 'var(--surface)', border: '1px solid var(--border)', width: '100%', textAlign: 'left', cursor: isMe ? 'default' : 'pointer', fontFamily: 'inherit' }}>
                          <div style={{ width: 36, height: 36, borderRadius: 9, background: 'var(--surface2)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            {item.item_image ? <img src={item.item_image} alt={item.item_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <ImageIcon size={14} style={{ color: 'var(--text-muted)' }} />}
                          </div>
                          <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', flex: 1 }}>{item.item_name}</span>
                          {!isMe && <Gift size={14} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : activeTab === 'battle' ? (
                /* Combat view. Attack lives here rather than on the full
                   profile page because this sheet is where players
                   actually look each other up. */
                <div style={{ marginTop: 12 }}>
                  <PvpProfilePanel
                    userId={userId}
                    isOwn={isMe}
                    onAttack={() => setAttackOpen(true)}
                    viewerJailedUntil={viewerPvpState?.jailed_until ?? null}
                    refreshSignal={pvpRefreshSignal}
                  />
                </div>
              ) : restricted ? (
                /* Stats tab, locked. The tab itself stays in the strip on
                   purpose — removing it would leave the viewer with no
                   evidence anything was withheld, which is exactly the
                   "empty vs private" confusion this is here to fix. */
                <div style={{ marginTop: 12 }}>
                  <PrivateProfileNotice
                    username={profile.username}
                    variant="panel"
                    onFollow={handleFollow}
                    busy={busy}
                  />
                </div>
              ) : (
                <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {/* XP — always shown */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                      <Zap size={14} style={{ color: '#f5c542' }} />
                      <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>Current XP</span>
                    </div>
                    <span style={{ fontSize: 12.5, fontWeight: 800, color: rank?.color ?? 'var(--text)' }}>{profile.xp.toLocaleString()}</span>
                  </div>

                  {/* View badges — opens the quick sheet (best 3 + unlock
                      teasers); the preview sheet falls away while it's open. */}
                  {!isModerator && defs.length > 0 && (
                    <button
                      type="button" className="pv-btn"
                      onClick={() => setShowBadgeQuickSheet(true)}
                      style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)', cursor: 'pointer' }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                        <Sparkles size={14} style={{ color: '#c9a7ff' }} />
                        <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>Badges</span>
                      </div>
                      <span style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text-dim)' }}>{badges.length}/{defs.length}</span>
                    </button>
                  )}

                  {/* Leaderboard — only if the player opted in via grid cards */}
                  {profile.grid_cards?.includes('leaderboard') && (
                    <button
                      type="button" className="pv-btn"
                      onClick={() => { close(); navigate('/ranks') }}
                      style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)', cursor: 'pointer' }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                        <Trophy size={14} style={{ color: '#4f8ef7' }} />
                        <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>Leaderboard</span>
                      </div>
                      <span style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text-dim)' }}>{lbPosition ? `#${lbPosition}` : '—'}</span>
                    </button>
                  )}

                  {/* Active mornings/nights — owner's chosen play-time tag */}
                  {profile.info_tags?.includes('play_time') && profile.play_time && (
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                        {profile.play_time === 'morning'
                          ? <Sunrise size={14} style={{ color: '#f5c542' }} />
                          : <MoonIcon size={14} style={{ color: '#9b6dff' }} />}
                        <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>Usually active</span>
                      </div>
                      <span style={{ fontSize: 12.5, fontWeight: 800, color: profile.play_time === 'morning' ? '#f5c542' : '#9b6dff' }}>
                        {profile.play_time === 'morning' ? 'Mornings' : 'Nights'}
                      </span>
                    </div>
                  )}

                  {/* Favorite game, with star score */}
                  {profile.favorite_game && (() => {
                    const meta = getGameMeta(profile.favorite_game)
                    if (!meta) return null
                    const stars = GAME_RANK_STARS[favoriteGameRank ?? ''] ?? 0
                    return (
                      <div>
                        <p style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 6, marginLeft: 2 }}>
                          @{profile.username} likes playing
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 14px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)' }}>
                          <div style={{ width: 34, height: 34, borderRadius: 9, background: `${meta.accent}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                            <meta.icon size={16} style={{ color: meta.accent }} />
                          </div>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)', marginBottom: 2 }}>{meta.name}</div>
                            <div style={{ display: 'flex', gap: 2 }}>
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star key={i} size={10} style={{ color: i < stars ? '#f5c542' : 'var(--surface3)' }} fill={i < stars ? '#f5c542' : 'none'} />
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })()}

                  {/* Equipped avatar + artifact — tap either to open its quick sheet */}
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <button
                      type="button"
                      className="pv-btn"
                      onClick={() => setShowAvatarQuickSheet(true)}
                      style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, padding: '12px 8px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)', cursor: 'pointer', fontFamily: 'inherit' }}
                    >
                      <div style={{ width: 44, height: 44, borderRadius: 11, background: profile.equipped_avatar ? `${rank?.color ?? '#888899'}18` : 'var(--surface2)', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', border: profile.equipped_avatar ? `1px solid ${rank?.color ?? '#888899'}33` : '1px solid rgba(255,255,255,0.06)' }}>
                        {profile.equipped_avatar && profile.equipped_avatar.startsWith('http')
                          ? <img src={profile.equipped_avatar} alt="avatar" style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center top' }} onError={e => { (e.target as HTMLImageElement).style.display = 'none' }} />
                          : <Sparkles size={14} style={{ color: profile.equipped_avatar ? (rank?.color ?? 'var(--text)') : 'var(--text-muted)' }} />
                        }
                      </div>
                      <span style={{ fontSize: 10, fontWeight: 700, color: profile.equipped_avatar ? 'var(--text)' : 'var(--text-muted)', textAlign: 'center' }}>
                        {profile.equipped_avatar ? 'Avatar' : 'No avatar'}
                      </span>
                    </button>
                    <button
                      type="button"
                      className="pv-btn"
                      onClick={() => setShowArtifactQuickSheet(true)}
                      style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, padding: '12px 8px', borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)', cursor: 'pointer', fontFamily: 'inherit' }}
                    >
                      <div style={{ width: 44, height: 44, borderRadius: 11, background: equippedArtifact ? `${rank?.color ?? '#888899'}18` : 'var(--surface2)', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', border: equippedArtifact ? `1px solid ${rank?.color ?? '#888899'}33` : '1px solid rgba(255,255,255,0.06)' }}>
                        {equippedArtifactImage && equippedArtifactImage.startsWith('http')
                          ? <img src={equippedArtifactImage} alt="artifact" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          : <Package size={14} style={{ color: equippedArtifact ? (rank?.color ?? 'var(--text)') : 'var(--text-muted)' }} />
                        }
                      </div>
                      <span style={{ fontSize: 10, fontWeight: 700, color: equippedArtifact ? 'var(--text)' : 'var(--text-muted)', textAlign: 'center' }}>
                        {equippedArtifact || 'No artifact'}
                      </span>
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Profile card effect — a sibling of the sheet, framed to the
          sheet's own box so it plays over the CARD and nothing else. The
          same width and height the sheet gets, so the two can't drift;
          nested inside the sheet instead it would scroll with the body.
          Playback (the two-beat, then stop) lives in profileEffect.tsx,
          shared with the Mall's preview. */}
      <ProfileEffectLayer
        url={profile?.equipped_profile_effect_url}
        playing={effectPlaying}
        style={{ opacity: entered && !closing ? 1 : 0, transition: 'opacity 0.2s ease-out' }}
        frame={{ width: sheetBase.width, height: sheetHeightPx }}
      />

      {showEdit && profile && isMe && (
        <EditProfileModal
          profile={profile as unknown as Profile}
          bannerUrl={profile.banner_url}
          presence={presence}
          onClose={() => {
            setShowEdit(false)
            // Only bounce to the dashboard when the edit page closed because
            // changes were saved — cancelling/discarding should just drop
            // back to this profile popup, not leave it.
            if (justSavedRef.current) {
              justSavedRef.current = false
              onClose()
              navigate('/dashboard')
            }
          }}
          onSaved={(updates) => {
            setProfile(prev => (prev ? { ...prev, ...updates } as PreviewProfile : prev))
            justSavedRef.current = true
          }}
          onToast={() => {}}
          // Drip saves through its own RPC the moment a tile is tapped, so
          // it reports up separately. It must NOT go through onSaved:
          // that sets justSavedRef, and a "saved" close bounces the player
          // to the dashboard — wrong for changing a hat.
          onDripSaved={next => setProfile(prev => (prev ? { ...prev, drip: next } : prev))}
        />
      )}

      {reportOpen && user && profile && (
        <ReportModal
          reporterId={user.id}
          targetType="user"
          targetId={profile.id}
          targetLabel={displayName}
          onClose={() => setReportOpen(false)}
        />
      )}

      {badgeToast && profile && (
        <BadgeToast
          title={badgeDisplayTitle(badgeToast, profile.original_username)}
          icon={badgeToast.icon}
          rarity={badgeToast.rarity}
          customIcon={
            subscriberBadgeTier(badgeToast.id)
              ? <img src={proBadgeSrc(proInfo?.color)} alt={badgeToast.title} width={16} height={16} />
              : championshipBadgeSrc(badgeToast.id)
                ? <img src={championshipBadgeSrc(badgeToast.id)!} alt={badgeToast.title} width={18} height={18} />
                : undefined
          }
          onDone={() => setBadgeToast(null)}
        />
      )}

      {showRankToast && rank && (
        <BadgeToast
          title={`Player in ${rank.name}`}
          icon="" rarity=""
          colorOverride={rank.color}
          customIcon={<RankBadge tier={rank} size={16} />}
          onDone={() => setShowRankToast(false)}
        />
      )}

      {showBadgeQuickSheet && profile && (
        <div onClick={e => e.stopPropagation()}>
          <BadgeQuickSheet
            badges={badges}
            allDefs={defs}
            originalUsername={profile.original_username ?? profile.username}
            avatarUrl={profile.avatar}
            displayName={displayName}
            isOwnProfile={isMe}
            pro={proInfo}
            onOpenAll={() => { setShowBadgeQuickSheet(false); setShowBadgesModal(true) }}
            onViewYourBadges={() => { setShowBadgeQuickSheet(false); close(); navigate('/profile') }}
            onClose={() => setShowBadgeQuickSheet(false)}
          />
        </div>
      )}

      {showBadgesModal && profile && (
        <div onClick={e => e.stopPropagation()}>
          <BadgesModal
            badges={badges}
            allDefs={defs}
            originalUsername={profile.original_username ?? profile.username}
            pro={proInfo}
            onClose={() => setShowBadgesModal(false)}
          />
        </div>
      )}

      {championshipPreview && profile && (
        <div onClick={e => e.stopPropagation()}>
          <ChampionshipBadgeModal
            def={championshipPreview}
            unlockedAt={badges.find(b => b.badge_id === championshipPreview.id)?.unlocked_at ?? null}
            seasonNumber={championshipSeasonByBadge.get(championshipPreview.id) ?? null}
            originalUsername={profile.original_username ?? profile.username}
            onClose={() => setChampionshipPreview(null)}
          />
        </div>
      )}

      {followSheetMode && profile && (
        <div onClick={e => e.stopPropagation()}>
          <FollowListSheet
            profileId={profile.id}
            myId={user?.id ?? profile.id}
            mode={followSheetMode}
            onClose={() => setFollowSheetMode(null)}
            zIndex={20100}
            onOpenProfile={openOtherProfile}
            totalCount={followSheetMode === 'followers' ? followers : following}
          />
        </div>
      )}

      {showAvatarQuickSheet && profile && (
        <div onClick={e => e.stopPropagation()}>
          <AvatarQuickSheet
            displayName={displayName}
            profileAvatarUrl={profile.avatar}
            equippedAvatarUrl={profile.equipped_avatar}
            rankColor={rank?.color}
            onClose={() => setShowAvatarQuickSheet(false)}
          />
        </div>
      )}

      {showArtifactQuickSheet && profile && (
        <div onClick={e => e.stopPropagation()}>
          <ArtifactQuickSheet
            displayName={displayName}
            isOwnProfile={isMe}
            equipped={equippedArtifact ? {
              id: 'equipped',
              name: equippedArtifact,
              mediaUrl: equippedArtifactImage,
              tier: equippedArtifactTier ?? 'common',
            } : null}
            showcased={showcasedArtifacts}
            onClose={() => setShowArtifactQuickSheet(false)}
            onManage={isMe ? () => { setShowArtifactQuickSheet(false); setShowEdit(true) } : undefined}
          />
        </div>
      )}

      {achToast && (
        <AchievementMiniToast
          title={achToast.title}
          icon={achToast.icon}
          rarity={achToast.rarity}
          color={achToast.category === 'pvp' ? PVP_ACH_COLOR : undefined}
          onDone={() => setAchToast(null)}
        />
      )}

      {giftTarget && profile && (
        <SendGiftModal
          recipientId={profile.id}
          recipientName={displayName}
          recipientAvatar={profile.avatar}
          target={giftTarget}
          onClose={() => setGiftTarget(null)}
          onSent={(result: GiftSendResult, name: string) => setGiftToast(giftResultMessage(result, name))}
        />
      )}

      {giftToast && (
        <BadgeToast
          title={giftToast}
          icon="" rarity=""
          colorOverride="var(--accent)"
          customIcon={<Gift size={14} />}
          onDone={() => setGiftToast(null)}
        />
      )}

      {followCountsToast && (
        <BadgeToast
          title={followCountsToast}
          icon="" rarity=""
          colorOverride="var(--text-muted)"
          customIcon={<EyeOff size={14} />}
          onDone={() => setFollowCountsToast(null)}
        />
      )}

      {noticeToast && (
        <BadgeToast
          title={noticeToast}
          icon="" rarity=""
          colorOverride="var(--accent)"
          customIcon={<Users size={14} />}
          onDone={() => setNoticeToast(null)}
        />
      )}

      {invitePickerOpen && profile && (
        <ClubInvitePicker
          targetUserId={userId}
          targetName={displayName}
          onClose={() => setInvitePickerOpen(false)}
          onSent={clubName => setNoticeToast(`Invite sent to ${clubName}`)}
          onError={message => setNoticeToast(message)}
        />
      )}

      {vibeSheetOpen && (
        <VibeSheet
          current={vibe}
          onClose={() => setVibeSheetOpen(false)}
          onSaved={setVibe}
        />
      )}

      <style>{`
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }

        /* Sections stack naturally inside one panel, separated by a
           hairline instead of each being its own floating card. */
        .pv-panel .pv-section { padding: 12px 0; }
        .pv-panel .pv-section:first-child { padding-top: 10px; }
        .pv-panel .pv-section:last-child { padding-bottom: 10px; }
        .pv-panel .pv-section + .pv-section { border-top: 1px solid rgba(255,255,255,0.06); }

        /* Subtle hover/press feedback on every interactive element. */
        .pv-btn { transition: transform 0.12s ease, filter 0.12s ease, opacity 0.12s ease; }
        .pv-btn:hover:not(:disabled) { filter: brightness(1.1); }
        .pv-btn:active:not(:disabled) { transform: scale(0.96); }

        @keyframes pvShimmer { 0% { background-position: 100% 50%; } 100% { background-position: 0 50%; } }
        .pv-skel { background: linear-gradient(90deg, var(--surface) 25%, var(--surface2) 37%, var(--surface) 63%); background-size: 400% 100%; animation: pvShimmer 1.4s ease infinite; }
      `}</style>

      {/* Mounted at the sheet root, not inside the tab branch, so it
          survives a tab change and layers above the sheet rather than
          being clipped by its scroll container. */}
      {attackOpen && user?.id && (
        <AttackSheet
          open={attackOpen}
          myUserId={user.id}
          targetId={userId}
          targetName={profile?.username ?? 'this player'}
          onClose={() => setAttackOpen(false)}
          onResolved={() => {
            setAttackOpen(false)
            setPvpRefreshSignal(s => s + 1)
          }}
        />
      )}
    </div>,
    document.body,
  )
}

function MenuItem({ icon, label, onClick, danger }: { icon: React.ReactNode; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button
      type="button" onClick={onClick}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 9, padding: '9px 10px', borderRadius: 9,
        background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
        fontSize: 12.5, fontWeight: 600, color: danger ? '#ff6b6b' : 'var(--text)',
      }}
      onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface3)')}
      onMouseLeave={e => (e.currentTarget.style.background = 'none')}
    >
      {icon}
      {label}
    </button>
  )
}
