// src/features/profile/OfficialProfile.tsx
//
// Shown instead of PlayerProfile when profiles.is_official is set (the one
// shared "Chillverse" identity that broadcasts come from), when
// profiles.is_halo_ai is set (the Halo AI account), or when
// profiles.is_groove_official is set (the groove account) — each its own
// flag since is_official is limited to a single row, profiles_single_official.
//
// Deliberately bare, and narrower than even ModeratorProfile: banner, locked
// avatar, name + Official badge, bio, follower/following counts, Follow, and
// a fixed member-since date. No XP, level, streak, rank, badges,
// achievements, inventory, game or battle stats, no profile likes — a brand
// account has no business showing any of that.
//
// The Official badge sits right beside the display name as a small inline
// checkmark (VerifiedBadge — same one PostCard/CommentSheet use), the way
// X/TikTok mark a verified handle, rather than as its own pill.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, Share2, Check, Users } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import Avatar from '../../shared/components/Avatar'
import FollowButton from '../posts/FollowButton'
import VerifiedBadge from '../../shared/components/VerifiedBadge'
import FollowListSheet from './FollowListSheet'

interface OfficialProfileData {
  id: string
  username: string
  display_name: string | null
  bio: string | null
  avatar: string | null
  banner_url: string | null
  staff_member_since: string | null
  created_at: string
}

export default function OfficialProfile({ userId }: { userId: string }) {
  const navigate = useNavigate()
  const { session } = useAuth()
  const myId = session?.user?.id ?? null

  const [profile, setProfile] = useState<OfficialProfileData | null>(null)
  const [loading, setLoading] = useState(true)
  const [followers, setFollowers] = useState(0)
  const [following, setFollowing] = useState(0)
  const [followListOpen, setFollowListOpen] = useState<'followers' | 'following' | null>(null)
  const [shared, setShared] = useState(false)

  useEffect(() => {
    setLoading(true)
    supabase.from('profiles')
      .select('id, username, display_name, bio, avatar, banner_url, staff_member_since, created_at')
      .eq('id', userId).maybeSingle()
      .then(({ data }) => { setProfile(data as OfficialProfileData | null); setLoading(false) })
  }, [userId])

  // Followers + following counts.
  useEffect(() => {
    supabase.from('profile_follow_counts').select('followers_count, following_count').eq('id', userId).single()
      .then(({ data }) => {
        if (data) { setFollowers(Number(data.followers_count)); setFollowing(Number(data.following_count)) }
      })
  }, [userId])

  async function handleShare() {
    const url = `${window.location.origin}/profile/${userId}`
    const name = profile?.display_name || profile?.username || 'Chillverse'
    if (navigator.share) {
      try { await navigator.share({ title: `${name} on Chillverse`, url }) } catch { /* cancelled */ }
      return
    }
    try {
      await navigator.clipboard.writeText(url)
      setShared(true)
      setTimeout(() => setShared(false), 1800)
    } catch (e) {
      console.error('share link copy error:', e)
    }
  }

  if (loading || !profile) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
        <span style={{ display: 'block', width: 36, height: 36, borderRadius: '50%', border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', animation: 'spin 0.8s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    )
  }

  const displayName = profile.display_name || profile.username
  const memberSince = new Date(profile.staff_member_since ?? profile.created_at)
    .toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
  const isSelf = myId === userId

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', paddingBottom: 60 }}>

      {/* ── Banner ── */}
      <div style={{
        position: 'relative', zIndex: 1, width: '100%', height: 130,
        background: profile.banner_url
          ? `url(${profile.banner_url}) center/cover no-repeat`
          : 'linear-gradient(135deg, var(--accent), var(--accent2))',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.35), rgba(0,0,0,0.05))' }} />
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 20px' }}>
          <button type="button" onClick={() => navigate(-1)} aria-label="Back"
            style={{ width: 34, height: 34, borderRadius: 9, background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-strong)', backdropFilter: 'blur(8px)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <ArrowLeft size={14} />
          </button>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#fff', textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>Official Account</span>
          <button type="button" onClick={handleShare} aria-label="Share"
            style={{ width: 34, height: 34, borderRadius: 9, background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-strong)', backdropFilter: 'blur(8px)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            {shared ? <Check size={14} /> : <Share2 size={14} />}
          </button>
        </div>
      </div>

      {/* ── Avatar + name ── */}
      <div style={{ padding: '0 20px', marginTop: -44, marginBottom: 10, position: 'relative', zIndex: 2 }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14 }}>
          <div style={{ width: 80, height: 80, borderRadius: 20, padding: 3, background: 'linear-gradient(135deg, var(--accent), var(--accent2))', boxShadow: '0 0 20px color-mix(in srgb, var(--accent) 40%, transparent)', border: '3px solid var(--bg)' }}>
            <Avatar src={profile.avatar} name={displayName} size={74} radius={16} disabled />
          </div>
          <div style={{ flex: 1, minWidth: 0, paddingBottom: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap', marginBottom: 4 }}>
              <span style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)', letterSpacing: '-0.4px' }}>{displayName}</span>
              <VerifiedBadge size={17} />
            </div>
            <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>@{profile.username}</span>
          </div>
        </div>
      </div>

      {/* ── Bio ── */}
      {profile.bio && (
        <div style={{ padding: '0 20px', marginBottom: 14 }}>
          <p style={{ fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-dim)', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{profile.bio}</p>
        </div>
      )}

      {/* ── Followers / Following + Follow ── */}
      <div style={{ padding: '0 20px', marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <button type="button" onClick={() => setFollowListOpen('followers')}
            style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '13px 16px', borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--border)', boxShadow: 'var(--elev-raise-sm)', cursor: 'pointer', textAlign: 'left' }}>
            <Users size={15} style={{ color: '#4f8ef7', flexShrink: 0 }} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>{followers.toLocaleString()}</div>
              <div style={{ fontSize: 9.5, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Followers</div>
            </div>
          </button>
          <button type="button" onClick={() => setFollowListOpen('following')}
            style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '13px 16px', borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--border)', boxShadow: 'var(--elev-raise-sm)', cursor: 'pointer', textAlign: 'left' }}>
            <Users size={15} style={{ color: '#9b6dff', flexShrink: 0 }} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>{following.toLocaleString()}</div>
              <div style={{ fontSize: 9.5, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Following</div>
            </div>
          </button>
        </div>
        {!isSelf && myId && (
          <FollowButton myId={myId} authorId={userId} />
        )}
      </div>

      {followListOpen && myId && (
        <FollowListSheet
          profileId={userId}
          myId={myId}
          mode={followListOpen}
          onClose={() => setFollowListOpen(null)}
          totalCount={followListOpen === 'followers' ? followers : following}
        />
      )}

      {/* ── Member since ── */}
      <div style={{ padding: '0 20px' }}>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>
          Member since {memberSince}
        </p>
      </div>
    </div>
  )
}
