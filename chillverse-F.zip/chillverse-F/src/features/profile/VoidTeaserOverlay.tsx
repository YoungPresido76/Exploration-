// src/features/profile/VoidTeaserOverlay.tsx
//
// What a free account sees when it taps the locked "Void UI changer 👽"
// row in Edit Profile. Previously that tap produced a toast, which named
// the paywall without ever showing what sits behind it.
//
// The sequence, in order:
//   1. the alien rises out of the void on a beam and settles above
//   2. VOID writes itself letter by letter, a caret trailing the strokes
//   3. the word — and the whole screen with it — turns into each skin in
//      turn: Glacier, Storybook, Modern Tech, Cyberpunk, Comic
//   4. the ask slides up while the skins keep cycling behind it
//
// The backdrops, labels, blurbs and fonts are read straight out of
// PROFILE_SKINS, so this can never drift from what VoidUiChangerSheet
// actually applies. Only the per-material type treatment lives here,
// because a skin token has no opinion about a 60px display word.
import { useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { Sparkles, X } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { PROFILE_SKINS, type ProfileSkinId } from '../../shared/lib/profileSkins'

// Cold → deep → warm → divine → clear → neon → loud. Deliberately not the
// array order in profileSkins.ts: this reads as an escalation rather than
// a list. Aqua follows Ice because the jump from frozen surface to open
// water is the clearest way to show they aren't the same idea twice.
const ORDER: ProfileSkinId[] = ['ice', 'aqua', 'storybook', 'celestial', 'modern', 'cyberpunk', 'comic']

const TIMING = {
  alienMs:         1500,
  writeDelay:      1000,
  letterStagger:    280,
  letterMs:         620,
  firstMorphDelay:  650,
  holdMs:          1300,
  morphMs:          620,
  /** Ask appears once this many skins have been shown; the rest keep cycling. */
  ctaAfterSkins:      3,
}

const LETTERS = ['V', 'O', 'I', 'D']

/**
 * Halo + caption colours per skin, pulled from that skin's own tokens.
 *
 * The caption reads on the skin's own backdrop, so light-backdrop skins
 * take --text (their ink) and dark-backdrop skins take --accent (their
 * light). Using --accent everywhere would put Storybook's brick red on
 * cream paper at 14px, which fails contrast.
 */
const INK_ON_LIGHT: ProfileSkinId[] = ['storybook', 'ice']

function skinAccents(id: ProfileSkinId) {
  const s = PROFILE_SKINS.find(x => x.id === id)!
  const glow = s.vars['--glow']
  return {
    def:    s,
    halo:   glow && glow !== 'transparent' ? glow : s.vars['--accent'],
    cap:    INK_ON_LIGHT.includes(id) ? s.vars['--text'] : s.vars['--accent'],
    capDim: s.vars['--text-secondary'],
  }
}

export default function VoidTeaserOverlay({ onClose }: { onClose: () => void }) {
  const navigate = useNavigate()
  const [on, setOn]           = useState(false)
  const [skin, setSkin]       = useState<ProfileSkinId | null>(null)
  const [written, setWritten] = useState(0)      // how many letters have landed
  const [morphing, setMorph]  = useState(false)
  const [caretX, setCaretX]   = useState<number | null>(null)
  const [ctaOpen, setCtaOpen] = useState(false)
  const [settled, setSettled] = useState(false)  // alien has finished rising

  const wordRef  = useRef<HTMLDivElement>(null)
  const letterRefs = useRef<(HTMLSpanElement | null)[]>([])
  const timers   = useRef<ReturnType<typeof setTimeout>[]>([])
  const step     = useRef(0)

  const reduced = useMemo(
    () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches,
    [],
  )
  const active = skin ? skinAccents(skin) : null

  const wait = (fn: () => void, ms: number) => { timers.current.push(setTimeout(fn, ms)) }

  // Edit Profile is a scrollable full-screen sheet underneath. Without
  // this, dragging on the overlay scrolls that sheet behind it.
  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close() }
    window.addEventListener('keydown', onKey)
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', onKey) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    requestAnimationFrame(() => setOn(true))

    if (reduced) {
      // No theatre: land on the last frame of the story immediately.
      setWritten(LETTERS.length); setSettled(true); setSkin('ice'); setCtaOpen(true)
      return () => { timers.current.forEach(clearTimeout) }
    }

    wait(() => setSettled(true), TIMING.alienMs + 300)

    wait(() => {
      LETTERS.forEach((_, i) => wait(() => {
        setWritten(i + 1)
        const el = letterRefs.current[i], w = wordRef.current
        if (el && w) setCaretX(el.getBoundingClientRect().right - w.getBoundingClientRect().left - 4)
      }, i * TIMING.letterStagger))

      const writeEnd = (LETTERS.length - 1) * TIMING.letterStagger + TIMING.letterMs
      wait(() => setCaretX(null), writeEnd - 60)
      wait(cycle, writeEnd + TIMING.firstMorphDelay)
    }, TIMING.writeDelay)

    return () => { timers.current.forEach(clearTimeout) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function cycle() {
    const next = ORDER[step.current % ORDER.length]
    setMorph(true)
    wait(() => { setSkin(next); setMorph(false) }, TIMING.morphMs * 0.45)
    step.current += 1
    if (step.current === TIMING.ctaAfterSkins) wait(() => setCtaOpen(true), TIMING.holdMs * 0.55)
    wait(cycle, TIMING.holdMs)
  }

  function close() {
    timers.current.forEach(clearTimeout)
    setOn(false)
    setTimeout(onClose, 300)
  }

  const stars = useMemo(
    () => Array.from({ length: 46 }, () => ({
      left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%`,
      delay: `${(Math.random() * 3.6).toFixed(2)}s`,
    })), [],
  )

  return createPortal(
    <div
      className={`cv-vt${on ? ' on' : ''}${ctaOpen ? ' cta-open' : ''}`}
      data-skin={skin ?? 'void'}
      onClick={() => { if (!ctaOpen) setCtaOpen(true) }}   // tap anywhere skips to the ask
      style={{ '--halo': active?.halo ?? 'rgba(155,109,255,.55)' } as CSSProperties}
    >
      <style>{CSS}</style>

      {/* stage */}
      <div className="cv-vt-bg void" />
      <div className="cv-vt-bg skin" style={{ background: active?.def.backdrop ?? 'none' }} />
      <div className="cv-vt-stars">
        {stars.map((s, i) => <i key={i} style={{ left: s.left, top: s.top, animationDelay: s.delay }} />)}
      </div>
      <div className="cv-vt-fx scan" /><div className="cv-vt-fx frost" />
      <div className="cv-vt-fx paper" /><div className="cv-vt-fx half" /><div className="cv-vt-fx mesh" />
      <div className="cv-vt-vig" />

      <button type="button" className="cv-vt-x" aria-label="Close" onClick={e => { e.stopPropagation(); close() }}>
        <X size={16} />
      </button>

      {/* centrepiece */}
      <div className="cv-vt-core">
        <div className="cv-vt-alien-wrap">
          <div className="cv-vt-halo" />
          <div className="cv-vt-beam" />
          <div className={`cv-vt-alien${settled ? ' settled' : ''}`} aria-hidden>👽</div>
        </div>

        <div className="cv-vt-tilt">
          <div className="cv-vt-slab" />
          <div className={`cv-vt-word${morphing ? ' morph' : ''}`} ref={wordRef} aria-label="Void">
            {caretX !== null && <div className="cv-vt-caret" style={{ left: caretX }} />}
            {morphing && <div className="cv-vt-sweep" />}
            {LETTERS.map((c, i) => (
              <span
                key={c + i}
                ref={el => { letterRefs.current[i] = el }}
                className={`cv-vt-ch${i < written ? ' in' : ''}`}
                aria-hidden
              >{c}</span>
            ))}
          </div>
        </div>

        <div className="cv-vt-cap" key={skin ?? 'void'}
             style={{ '--cap': active?.cap ?? '#c9b6ff',
                      '--cap-dim': active?.capDim ?? 'rgba(255,255,255,.55)' } as CSSProperties}>
          {active && <><div className="name">{active.def.label}</div>
                       <div className="blurb">{active.def.blurb}</div></>}
        </div>
      </div>

      {/* the ask */}
      <div className="cv-vt-cta" onClick={e => e.stopPropagation()}>
        <div className="cv-vt-pips">
          {ORDER.map(id => <b key={id} className={id === skin ? 'on' : ''} />)}
        </div>
        <p>
          Void reskins your <b>whole profile page</b> — background, cards, borders and fonts.
          <br />Everyone who opens your page sees it your way.
        </p>
        <button type="button" className="go"
          onClick={e => { ripple(e); close(); navigate('/pro') }}>
          <Sparkles size={15} /> Subscribe to Void
        </button>
        <button type="button" className="later" onClick={close}>Maybe later</button>
      </div>
    </div>,
    document.body,
  )
}

/* ── Scoped styles. Everything is under .cv-vt so nothing leaks. ────── */
const CSS = `
.cv-vt{position:fixed;inset:0;z-index:20050;opacity:0;pointer-events:none;
  transition:opacity 380ms cubic-bezier(.16,1,.3,1);overflow:hidden;background:#05030c}
.cv-vt.on{opacity:1;pointer-events:auto}

.cv-vt-bg{position:absolute;inset:0;transition:opacity 560ms cubic-bezier(.16,1,.3,1)}
.cv-vt-bg.void{background:
  radial-gradient(ellipse at 50% 22%, rgba(155,109,255,.30), transparent 58%),
  radial-gradient(ellipse at 84% 88%, rgba(84,60,190,.22), transparent 55%),
  radial-gradient(ellipse at 10% 78%, rgba(40,180,220,.10), transparent 52%),#05030c}
.cv-vt-bg.skin{opacity:0}
.cv-vt:not([data-skin="void"]) .cv-vt-bg.void{opacity:.12}
.cv-vt:not([data-skin="void"]) .cv-vt-bg.skin{opacity:1}
.cv-vt-vig{position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(ellipse at 50% 42%, transparent 46%, rgba(0,0,0,.55))}

.cv-vt-stars{position:absolute;inset:0;pointer-events:none;transition:opacity 700ms ease}
.cv-vt-stars i{position:absolute;width:2px;height:2px;border-radius:50%;background:#fff;opacity:.2;
  animation:cvVtTwinkle 3.6s ease-in-out infinite}
@keyframes cvVtTwinkle{0%,100%{opacity:.15;transform:scale(.7)}50%{opacity:.9;transform:scale(1)}}
.cv-vt:not([data-skin="void"]) .cv-vt-stars{opacity:.18}

.cv-vt-fx{position:absolute;inset:0;pointer-events:none;opacity:0;transition:opacity 560ms ease}
.cv-vt[data-skin="cyberpunk"] .cv-vt-fx.scan{opacity:1}
.cv-vt-fx.scan{background:repeating-linear-gradient(0deg,rgba(57,255,110,.07) 0 1px,transparent 1px 3px);
  animation:cvVtScan 7s linear infinite}
@keyframes cvVtScan{to{background-position:0 44px}}
.cv-vt[data-skin="ice"] .cv-vt-fx.frost{opacity:1}
.cv-vt-fx.frost{background:radial-gradient(rgba(255,255,255,.5) 0 1px,transparent 1.4px) 0 0/34px 34px,
  radial-gradient(rgba(255,255,255,.35) 0 1px,transparent 1.4px) 17px 12px/48px 48px}
.cv-vt[data-skin="storybook"] .cv-vt-fx.paper{opacity:1}
.cv-vt-fx.paper{background:repeating-linear-gradient(0deg,rgba(84,58,32,.05) 0 1px,transparent 1px 3px);mix-blend-mode:multiply}
.cv-vt[data-skin="comic"] .cv-vt-fx.half{opacity:1}
.cv-vt-fx.half{background:radial-gradient(rgba(0,0,0,.22) 0 1.3px,transparent 1.4px) 0 0/5px 5px}
.cv-vt[data-skin="modern"] .cv-vt-fx.mesh{opacity:1}
.cv-vt-fx.mesh{background:radial-gradient(ellipse at 50% 40%,transparent 58%,rgba(12,30,90,.28))}

.cv-vt-x{position:absolute;top:calc(14px + env(safe-area-inset-top));right:14px;width:34px;height:34px;
  border-radius:50%;border:0;cursor:pointer;background:rgba(255,255,255,.1);color:#fff;z-index:3;
  display:grid;place-items:center;opacity:0;transition:opacity 400ms ease}
.cv-vt.on .cv-vt-x{opacity:.7;transition-delay:900ms}

.cv-vt-core{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;
  padding:0 26px;transform:translateY(-6vh);transition:transform 640ms cubic-bezier(.16,1,.3,1)}
.cv-vt.cta-open .cv-vt-core{transform:translateY(-16vh)}

.cv-vt-alien-wrap{position:relative;height:74px;display:grid;place-items:center;margin-bottom:6px}
.cv-vt-alien{font-size:44px;line-height:1;opacity:0;transform:translateY(58px) scale(.7);filter:blur(6px)}
.cv-vt.on .cv-vt-alien{animation:cvVtRise 1500ms cubic-bezier(.16,1,.3,1) 260ms forwards}
@keyframes cvVtRise{0%{opacity:0;transform:translateY(58px) scale(.7);filter:blur(6px)}
  60%{opacity:1;filter:blur(0)}100%{opacity:1;transform:translateY(0) scale(1);filter:blur(0)}}
.cv-vt-alien.settled{animation:cvVtFloat 4.2s ease-in-out infinite}
@keyframes cvVtFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
.cv-vt-halo{position:absolute;width:120px;height:120px;border-radius:50%;pointer-events:none;opacity:0;filter:blur(6px);
  background:radial-gradient(circle,var(--halo),transparent 66%);transition:background 560ms ease,opacity 900ms ease}
.cv-vt.on .cv-vt-halo{opacity:1;transition-delay:600ms}
.cv-vt-beam{position:absolute;bottom:-6px;width:2px;height:0;border-radius:2px;opacity:0;
  background:linear-gradient(to top,transparent,var(--halo))}
.cv-vt.on .cv-vt-beam{animation:cvVtBeam 1400ms cubic-bezier(.16,1,.3,1) 200ms forwards}
@keyframes cvVtBeam{0%{height:0;opacity:0}35%{opacity:.9}100%{height:120px;opacity:0}}

.cv-vt-tilt{position:relative;transition:transform 560ms cubic-bezier(.34,1.56,.64,1)}
.cv-vt-word{display:flex;gap:.02em;position:relative}
.cv-vt-ch{opacity:0;filter:blur(14px);transform:translateY(14px) scale(1.14);
  font:800 clamp(44px,15vw,62px)/1 Poppins,Inter,sans-serif;letter-spacing:.16em;color:#f4f0ff}
.cv-vt-ch.in{animation:cvVtScribe 620ms cubic-bezier(.16,1,.3,1) forwards}
@keyframes cvVtScribe{0%{opacity:0;filter:blur(14px);transform:translateY(14px) scale(1.14)}
  100%{opacity:1;filter:blur(0);transform:translateY(0) scale(1)}}
.cv-vt-caret{position:absolute;top:8%;height:84%;width:2.5px;border-radius:3px;background:#fff;
  box-shadow:0 0 14px 3px rgba(155,109,255,.9);
  transition:left 240ms cubic-bezier(.16,1,.3,1);animation:cvVtBlink .9s steps(2,end) infinite}
@keyframes cvVtBlink{50%{opacity:.25}}
.cv-vt-word.morph{animation:cvVtMorph 620ms cubic-bezier(.65,0,.35,1)}
@keyframes cvVtMorph{0%{filter:blur(0) saturate(1);opacity:1;transform:scale(1)}
  45%{filter:blur(13px) saturate(1.5);opacity:.3;transform:scale(1.07)}
  100%{filter:blur(0) saturate(1);opacity:1;transform:scale(1)}}
.cv-vt-sweep{position:absolute;top:-14%;left:-40%;width:34%;height:128%;pointer-events:none;filter:blur(2px);
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.85),transparent);
  animation:cvVtSweep 620ms cubic-bezier(.65,0,.35,1)}
@keyframes cvVtSweep{0%{left:-40%;opacity:0}30%{opacity:.9}100%{left:106%;opacity:0}}

.cv-vt-slab{position:absolute;inset:-16px -22px;border-radius:26px;opacity:0;transition:opacity 500ms ease;
  background:linear-gradient(155deg,rgba(255,255,255,.34),rgba(255,255,255,.12) 46%,rgba(255,255,255,.2));
  border:1px solid rgba(255,255,255,.42);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  box-shadow:0 18px 50px rgba(12,30,90,.35),inset 0 1px 0 rgba(255,255,255,.65)}
.cv-vt[data-skin="modern"] .cv-vt-slab{opacity:1}

/* ── the five materials ───────────────────────────────────────────── */
.cv-vt[data-skin="ice"] .cv-vt-ch{
  font-family:Cinzel,'Playfair Display',Georgia,serif;font-weight:700;letter-spacing:.12em;color:transparent;
  background:linear-gradient(160deg,#fff,#dcecfb 42%,#a8cbe9);-webkit-background-clip:text;background-clip:text;
  filter:drop-shadow(0 2px 0 rgba(255,255,255,.75)) drop-shadow(0 0 22px rgba(160,220,255,.85))}
.cv-vt[data-skin="storybook"] .cv-vt-ch{
  font-family:'IM Fell English',Georgia,serif;font-weight:400;letter-spacing:.06em;color:#2f2114;
  text-shadow:0 1px 0 rgba(255,250,232,.7),0 -1px 0 rgba(84,58,32,.35),0 3px 6px rgba(84,58,32,.28)}
.cv-vt[data-skin="modern"] .cv-vt-ch{
  font-family:Poppins,Inter,sans-serif;font-weight:700;letter-spacing:.14em;color:rgba(255,255,255,.96);
  text-shadow:0 2px 18px rgba(12,30,90,.45)}
.cv-vt[data-skin="cyberpunk"] .cv-vt-ch{
  font-family:'Chakra Petch',ui-monospace,monospace;font-weight:700;letter-spacing:.2em;color:#d8ffe6;
  text-shadow:0 0 4px #39ff6e,0 0 24px rgba(57,255,110,.75),2px 0 0 rgba(0,229,255,.5),-2px 0 0 rgba(255,46,136,.35);
  animation:cvVtGlitch 2.6s steps(1,end) infinite}
@keyframes cvVtGlitch{0%,92%,100%{transform:translate(0)}94%{transform:translate(-2px,1px)}96%{transform:translate(2px,-1px)}}
.cv-vt[data-skin="comic"] .cv-vt-tilt{transform:rotate(-4.5deg)}
.cv-vt[data-skin="comic"] .cv-vt-ch{
  font-family:Bangers,Impact,sans-serif;font-weight:400;letter-spacing:.06em;color:#fff;
  -webkit-text-stroke:3px #0c0620;paint-order:stroke fill;
  text-shadow:4px 4px 0 #ff2e88,7px 7px 0 rgba(12,6,32,.5)}

.cv-vt-cap{margin-top:20px;text-align:center;min-height:44px;max-width:280px}
.cv-vt-cap .name{font:800 14px Inter,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:var(--cap);
  opacity:0;transform:translateY(6px);animation:cvVtCapIn 460ms cubic-bezier(.16,1,.3,1) forwards}
.cv-vt-cap .blurb{font:400 11.5px/1.5 Inter,sans-serif;color:var(--cap-dim);margin-top:5px;
  opacity:0;transform:translateY(6px);animation:cvVtCapIn 460ms cubic-bezier(.16,1,.3,1) 70ms forwards}
@keyframes cvVtCapIn{to{opacity:1;transform:translateY(0)}}

.cv-vt-pips{display:flex;justify-content:center;gap:6px;margin-bottom:16px}
.cv-vt-pips b{width:5px;height:5px;border-radius:50%;background:rgba(255,255,255,.28);transition:all 300ms ease}
.cv-vt-pips b.on{background:#fff;width:16px;border-radius:3px}

.cv-vt-cta{position:absolute;left:0;right:0;bottom:0;padding:22px 20px calc(22px + env(safe-area-inset-bottom));
  transform:translateY(112%);transition:transform 620ms cubic-bezier(.16,1,.3,1);
  background:linear-gradient(to top,rgba(5,3,12,.96) 62%,rgba(5,3,12,0))}
.cv-vt.cta-open .cv-vt-cta{transform:translateY(0)}
.cv-vt-cta p{margin:0 0 16px;font:400 13px/1.6 Inter,sans-serif;color:rgba(255,255,255,.72);text-align:center}
.cv-vt-cta p b{color:#fff;font-weight:700}
.cv-vt-cta .go{position:relative;overflow:hidden;width:100%;padding:15px;border-radius:15px;border:0;cursor:pointer;
  font:800 14.5px Inter,sans-serif;color:#fff;display:flex;align-items:center;justify-content:center;gap:8px;
  background:linear-gradient(120deg,#9b6dff,#6f4bd8 55%,#b98cff);animation:cvVtGlow 2.4s ease-in-out infinite}
@keyframes cvVtGlow{0%,100%{box-shadow:0 10px 30px rgba(155,109,255,.34)}50%{box-shadow:0 10px 42px rgba(155,109,255,.62)}}
.cv-vt-cta .later{width:100%;margin-top:10px;padding:12px;border:0;background:none;cursor:pointer;
  font:600 12.5px Inter,sans-serif;color:rgba(255,255,255,.45)}

@media (prefers-reduced-motion:reduce){
  .cv-vt *,.cv-vt *::before{animation-duration:1ms!important;animation-delay:0ms!important;transition-duration:120ms!important}
}
`
