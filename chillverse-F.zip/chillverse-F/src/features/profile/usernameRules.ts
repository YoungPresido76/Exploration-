// src/features/profile/usernameRules.ts
//
// Single source of truth for username validation + the change-cooldown
// math. Originally lived only inside AccountSettings.tsx; pulled out so
// other surfaces that can change a username on the player's behalf (the
// Halo AI DM action system) apply the exact same rules instead of a
// second, driftable copy. AccountSettings.tsx now imports from here.

export const RESERVED_WORDS = [
  'admin', 'administrator', 'moderator', 'mod', 'staff', 'support',
  'chillverse', 'official', 'system', 'bot', 'null', 'undefined',
  'help', 'info', 'contact', 'abuse', 'root', 'superuser',
]
export const BANNED_PATTERNS = [/nigger/i, /faggot/i, /retard/i, /spastic/i]

export function validateUsername(name: string): string | null {
  const trimmed = name.trim()
  if (trimmed.length < 3) return 'Username must be at least 3 characters.'
  if (trimmed.length > 20) return 'Username must be 20 characters or fewer.'
  if (!/^[a-zA-Z0-9_-]+$/.test(trimmed)) return 'Only letters, numbers, underscores and hyphens allowed.'
  if (/^[_-]|[_-]$/.test(trimmed)) return 'Username can\'t start or end with _ or -.'
  if (RESERVED_WORDS.includes(trimmed.toLowerCase())) return 'That username is reserved.'
  if (BANNED_PATTERNS.some(p => p.test(trimmed))) return 'That username isn\'t allowed.'
  return null
}

export function generateUsernameSuggestions(base: string): string[] {
  const clean = base.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || 'user'
  const short = clean.slice(0, 14)
  return [0, 1, 2].map(() => `${short}${Math.floor(Math.random() * 900 + 100)}`)
}

export const USERNAME_COOLDOWN_MS = 30 * 24 * 60 * 60 * 1000

/** Null while no cooldown is in effect (either never changed, or the 30
 *  days have already elapsed). Otherwise the number of days left. */
export function getDaysUntilUsernameChange(lastChangedAt: string | null | undefined): number | null {
  if (!lastChangedAt) return null
  const remaining = USERNAME_COOLDOWN_MS - (Date.now() - new Date(lastChangedAt).getTime())
  return remaining <= 0 ? 0 : Math.ceil(remaining / (24 * 60 * 60 * 1000))
}
