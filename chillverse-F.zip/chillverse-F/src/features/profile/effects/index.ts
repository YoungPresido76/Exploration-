// src/features/profile/effects/index.ts
//
// The registry of drawn effects. An item stores "css:<key>" in its
// animated_url instead of a storage URL; this is what that key means.
//
// Adding another one is a file here, a line in EFFECTS, and a mall_items
// row — no migration, no upload, nothing against the egress cap.
import { burnThrough, signalLost, snowGlobe } from './cardBound'
import { matrixRain } from './matrixRain'
import { shadowStrike } from './shadowStrike'

/**
 * 'two-beat' — the shared envelope: plays, fades out, returns for a
 *   shorter second beat, stops. About 11.5s.
 * 'solo' — the effect scripts its own beats and just needs a fade in and
 *   out around them. About 9s.
 */
export type Envelope = 'two-beat' | 'solo'

export interface DrawnEffect {
  /** Shown in the Mall and inventory. */
  label: string
  envelope: Envelope
  /** Mounts into `host` and returns its own teardown. */
  run: (host: HTMLElement) => () => void
}

export const EFFECTS: Record<string, DrawnEffect> = {
  gold_shower:   { label: 'Gold Shower',   envelope: 'two-beat', run: goldShower },
  matrix_rain:   { label: 'Matrix Rain',   envelope: 'two-beat', run: matrixRain },
  shadow_strike: { label: 'Shadow Strike', envelope: 'solo',     run: shadowStrike },
  signal_lost:   { label: 'Signal Lost',   envelope: 'two-beat', run: signalLost },
  burn_through:  { label: 'Burn Through',  envelope: 'two-beat', run: burnThrough },
  snow_globe:    { label: 'Snow Globe',    envelope: 'two-beat', run: snowGlobe },
}

/**
 * Gold Shower is pure CSS — coins are six DOM nodes on a keyframe, which
 * is cheaper than a canvas and looks identical. It only lives here so
 * every effect is reached the same way.
 */
function goldShower(host: HTMLElement): () => void {
  const wrap = document.createElement('div')
  wrap.className = 'cvfx-gold'
  const pool = document.createElement('span')
  pool.className = 'cvfx-pool'
  wrap.appendChild(pool)
  for (let i = 0; i < 6; i++) {
    const coin = document.createElement('i')
    coin.style.left = `${6 + i * 16}%`
    coin.style.animationDelay = `${((i * 0.37) % 2.2).toFixed(2)}s`
    wrap.appendChild(coin)
  }
  host.appendChild(wrap)
  return () => wrap.remove()
}
