// src/features/profile/effects/shadowStrike.ts
import {
  drawSprite, fitCanvas, loop, mountCanvas, SOLO_MS,
  NINJA_IDLE, NINJA_PALETTE, NINJA_RUN_A, NINJA_RUN_B, NINJA_SLASH,
} from './canvas'

interface Mote { x: number; y: number; vx: number; vy: number; size: number }

/**
 * Shadow strike.
 *
 * He dashes in from the right trailing afterimages, plants, and the slash
 * arc crosses the whole card on the exact frame his blade is up — the
 * pose and the arc are one beat, which is what stops it reading as two
 * effects stacked. Then he leaves as a scatter of individual pixels that
 * fall under gravity.
 *
 * This one scripts its own two beats, so it takes the plain SOLO
 * envelope rather than the shared fade-out-fade-in one; putting both on
 * it would blank him mid-dash.
 */
export function shadowStrike(host: HTMLElement): () => void {
  const canvas = mountCanvas(host)
  const surface = fitCanvas(canvas)
  if (!surface) return () => {}
  const { ctx, w, h } = surface

  const px = Math.max(3, Math.round(w / 78))
  const spriteW = 12 * px
  const groundY = h - 16 * px - 14
  const motes: Mote[] = []

  return loop(SOLO_MS, (t) => {
    ctx.clearRect(0, 0, w, h)

    if (t < 1250) {
      const progress = t / 1250
      const x = w + spriteW - (w * 0.5 + spriteW) * progress
      const frame = Math.floor(t / 95) % 2 ? NINJA_RUN_A : NINJA_RUN_B
      // Afterimages behind him, dimmest first.
      for (let i = 3; i >= 1; i--) {
        drawSprite(ctx, frame, NINJA_PALETTE, x + i * 13, groundY, px, 0.1 * i, '#7d86c8')
      }
      drawSprite(ctx, frame, NINJA_PALETTE, x, groundY, px)
    } else if (t < 2050) {
      const x = w * 0.5 - spriteW / 2
      drawSprite(ctx, NINJA_SLASH, NINJA_PALETTE, x, groundY, px)

      const st = (t - 1250) / 560
      if (st < 1) {
        ctx.save()
        ctx.translate(w * 0.5, h * 0.5)
        ctx.rotate(-0.62)
        const span = Math.max(w, h) * 1.5
        const travel = -span / 2 + span * st
        const g = ctx.createLinearGradient(travel - 90, 0, travel + 90, 0)
        g.addColorStop(0, 'rgba(255,255,255,0)')
        g.addColorStop(0.5, `rgba(255,255,255,${0.95 * (1 - st * 0.4)})`)
        g.addColorStop(1, 'rgba(255,255,255,0)')
        ctx.fillStyle = g
        ctx.fillRect(-span / 2, -3, span, 6)
        // Wider, dimmer band behind the core — the flare is what makes it land.
        ctx.fillStyle = `rgba(180,220,255,${0.3 * (1 - st)})`
        ctx.fillRect(-span / 2, -14, span, 28)
        ctx.restore()
      }
    } else if (t < 2350) {
      const x = w * 0.5 - spriteW / 2
      drawSprite(ctx, NINJA_IDLE, NINJA_PALETTE, x, groundY, px, 1 - (t - 2050) / 300)
      if (!motes.length) {
        for (let k = 0; k < 16; k++) {
          motes.push({
            x: x + spriteW / 2, y: groundY + 8 * px,
            vx: (Math.random() - 0.5) * 150,
            vy: -40 - Math.random() * 130,
            size: px * (1 + Math.round(Math.random())),
          })
        }
      }
    }

    if (t > 2050 && motes.length) {
      const e = Math.min(1, (t - 2050) / 900)
      ctx.fillStyle = '#8b90c4'
      for (const m of motes) {
        ctx.globalAlpha = Math.max(0, 1 - e)
        ctx.fillRect(Math.round(m.x + m.vx * e), Math.round(m.y + m.vy * e + 240 * e * e), m.size, m.size)
      }
      ctx.globalAlpha = 1
    }

    // Second beat: flickers back in on the left, bows, gone.
    if (t > 4600 && t < 7200) {
      const bt = t - 4600
      const x = w * 0.16
      if (bt < 180) {
        if (Math.floor(bt / 45) % 2 === 0) {
          drawSprite(ctx, NINJA_IDLE, NINJA_PALETTE, x, groundY, px, 0.6, '#aeb4ea')
        }
      } else if (bt < 2100) {
        const bow = bt > 700 && bt < 1400 ? Math.round(px * 1.2) : 0
        drawSprite(ctx, NINJA_IDLE, NINJA_PALETTE, x, groundY + bow, px)
      } else {
        const fade = 1 - (bt - 2100) / 500
        if (fade > 0) drawSprite(ctx, NINJA_IDLE, NINJA_PALETTE, x, groundY, px, fade)
      }
    }
  }, () => ctx.clearRect(0, 0, w, h))
}
