// src/features/profile/effects/cardBound.ts
//
// The three effects that reach INTO the card rather than sitting over it.
// Signal lost and Burn through both work by filtering what is behind
// them, so the real avatar, name and badges are what gets inverted and
// scorched — not a picture of it. Snow globe is the one that accumulates:
// the drift is still there at the end.
import { fitCanvas, loop, mountCanvas, TWO_BEAT_MS } from './canvas'

/**
 * Signal lost.
 *
 * Bursts of tearing with clean gaps between them. Constant glitching
 * reads as a broken screen; bursts read as interference, which is the
 * thing being imitated.
 *
 * The bands carry no colour of their own — backdrop-filter mangles the
 * card behind each one in place.
 *
 * NOTE: the preview also jittered the whole card. That is deliberately
 * dropped here. This layer is a SIBLING of the profile sheet, so it
 * cannot shake the card without reaching up into it, and a profile that
 * physically jumps while you are trying to tap Follow is worse than one
 * that only tears.
 */
export function signalLost(host: HTMLElement): () => void {
  const fringe = document.createElement('div')
  fringe.style.cssText =
    'position:absolute;inset:0;mix-blend-mode:screen;opacity:0;transition:opacity .09s linear'
  const scan = document.createElement('div')
  scan.className = 'cvfx-scan'
  host.append(fringe, scan)

  const timers: number[] = []
  const live: HTMLElement[] = []

  function burst(durationMs: number) {
    const count = 3 + ((Math.random() * 4) | 0)
    const nodes: HTMLElement[] = []
    for (let i = 0; i < count; i++) {
      const band = document.createElement('i')
      const roll = Math.random()
      band.className = `cvfx-band${roll < 0.33 ? ' soft' : roll < 0.66 ? ' shift' : ''}`
      band.style.top = `${Math.random() * 88}%`
      band.style.height = `${4 + Math.random() * 22}px`
      band.style.transform = `translateX(${((Math.random() - 0.5) * 22).toFixed(1)}px)`
      host.appendChild(band)
      nodes.push(band)
      live.push(band)
    }
    fringe.style.background =
      'linear-gradient(90deg,rgba(255,0,60,.30),transparent 30%,transparent 70%,rgba(0,180,255,.30))'
    fringe.style.opacity = '1'
    timers.push(window.setTimeout(() => {
      nodes.forEach(n => n.remove())
      fringe.style.opacity = '0'
    }, durationMs))
  }

  const schedule = [0, 420, 700, 1500, 2300, 2600, 4200, 5100, 5400, 7000, 8300, 8600, 9400]
  schedule.forEach(at => {
    timers.push(window.setTimeout(() => burst(90 + Math.random() * 220), at))
  })

  return () => {
    timers.forEach(t => window.clearTimeout(t))
    live.forEach(n => n.remove())
    fringe.remove()
    scan.remove()
  }
}

/**
 * Burn through.
 *
 * An ember line climbs the card and everything below it is genuinely
 * scorched — darkened and desaturated in place — while the part above is
 * untouched. Then it cools and drains back down, leaving the card clean.
 */
export function burnThrough(host: HTMLElement): () => void {
  const char = document.createElement('div')
  char.className = 'cvfx-char'
  const line = document.createElement('div')
  line.className = 'cvfx-burnline'
  host.append(char, line)

  const h = host.clientHeight || 1
  const w = host.clientWidth || 1
  const embers: { el: HTMLElement; x: number; off: number; speed: number; sway: number }[] = []
  for (let i = 0; i < 22; i++) {
    const el = document.createElement('i')
    el.className = 'cvfx-ember'
    host.appendChild(el)
    embers.push({
      el,
      x: Math.random() * w,
      off: Math.random() * 40,
      speed: 14 + Math.random() * 40,
      sway: Math.random() * Math.PI * 2,
    })
  }

  const stop = loop(TWO_BEAT_MS, (elapsed) => {
    const t = elapsed / 1000
    let height: number
    if (t < 3.4) height = h * (t / 3.4)
    else if (t < 7.6) height = h
    else height = h * Math.max(0, 1 - (t - 7.6) / 2.6)

    char.style.height = `${height}px`
    line.style.bottom = `${height - 8}px`
    line.style.opacity = String(t < 7.6 ? 1 : Math.max(0, 1 - (t - 7.6) / 1.2))

    for (const m of embers) {
      const y = h - height - m.off + Math.sin(t * 1.6 + m.sway) * 6 - m.speed * Math.max(0, t - 0.2) * 0.35
      m.el.style.left = `${m.x + Math.sin(t * 1.1 + m.sway) * 10}px`
      m.el.style.top = `${y}px`
      m.el.style.opacity = String(t < 7.6 ? Math.max(0, 1 - (h - height - y) / 220) : 0)
    }
  })

  return () => {
    stop()
    char.remove()
    line.remove()
    embers.forEach(m => m.el.remove())
  }
}

/**
 * Snow globe.
 *
 * The one that leaves a trace: flakes land and STAY, building a drift
 * along the bottom over the full run, so the card is not the same at the
 * end as at the start.
 *
 * The pile is a height map, one column every few pixels, and a landing
 * flake also nudges its neighbours — without that it grows as a wall
 * instead of slumping the way snow does.
 */
export function snowGlobe(host: HTMLElement): () => void {
  const dome = document.createElement('div')
  dome.className = 'cvfx-dome'
  host.appendChild(dome)

  const canvas = mountCanvas(host)
  const surface = fitCanvas(canvas)
  if (!surface) return () => { dome.remove() }
  const { ctx, w, h } = surface

  const COL_W = 4
  const pile = new Array(Math.ceil(w / COL_W)).fill(0)
  const flakes = Array.from({ length: 70 }, () => ({
    x: Math.random() * w,
    y: Math.random() * h,
    r: 1 + Math.random() * 2.2,
    speed: 16 + Math.random() * 34,
    sway: Math.random() * 6,
  }))

  const stop = loop(TWO_BEAT_MS, (elapsed, dt) => {
    ctx.clearRect(0, 0, w, h)

    for (const f of flakes) {
      f.y += f.speed * dt
      f.x += Math.sin(elapsed / 900 + f.sway) * 0.35
      const col = Math.max(0, Math.min(pile.length - 1, (f.x / COL_W) | 0))
      if (f.y >= h - pile[col] - f.r) {
        pile[col] += f.r * 0.55
        if (col > 0) pile[col - 1] += f.r * 0.2
        if (col < pile.length - 1) pile[col + 1] += f.r * 0.2
        f.y = -4
        f.x = Math.random() * w
      }
      ctx.beginPath()
      ctx.fillStyle = 'rgba(255,255,255,.9)'
      ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2)
      ctx.fill()
    }

    ctx.beginPath()
    ctx.moveTo(0, h)
    for (let p = 0; p < pile.length; p++) ctx.lineTo(p * COL_W, h - pile[p])
    ctx.lineTo(w, h)
    ctx.closePath()
    ctx.fillStyle = 'rgba(244,250,255,.94)'
    ctx.fill()
  }, () => ctx.clearRect(0, 0, w, h))

  return () => { stop(); dome.remove() }
}
