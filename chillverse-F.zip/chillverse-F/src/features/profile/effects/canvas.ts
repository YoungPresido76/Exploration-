// src/features/profile/effects/canvas.ts
//
// Shared plumbing for the drawn card effects.
//
// Every effect here is generated on the device — no image, no video, no
// storage request. That is the whole point of the "css:" item family: a
// profile effect that costs nothing against the egress cap, which the
// video effects very much do.

/** How long a two-beat effect lives, matching the cvfx-life keyframe. */
export const TWO_BEAT_MS = 11_500
/** For effects that script their own beats (Shadow strike). */
export const SOLO_MS = 9_000

export interface Surface {
  ctx: CanvasRenderingContext2D
  w: number
  h: number
}

/**
 * Size a canvas to its box in real device pixels.
 *
 * DPR is capped at 2 deliberately: a 3x phone would triple the fill cost
 * for no visible gain on effects made of blurs, glyphs and 3px squares.
 */
export function fitCanvas(canvas: HTMLCanvasElement): Surface | null {
  const rect = canvas.getBoundingClientRect()
  if (rect.width < 2 || rect.height < 2) return null
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  canvas.width = Math.round(rect.width * dpr)
  canvas.height = Math.round(rect.height * dpr)
  const ctx = canvas.getContext('2d')
  if (!ctx) return null
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  return { ctx, w: rect.width, h: rect.height }
}

/** Mounts a full-bleed canvas inside the effect host. */
export function mountCanvas(host: HTMLElement): HTMLCanvasElement {
  const canvas = document.createElement('canvas')
  canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block'
  host.appendChild(canvas)
  return canvas
}

/**
 * requestAnimationFrame loop with a hard stop and a single cancel handle.
 * Every effect returns this cleanup so React can kill the loop the moment
 * the profile closes — an effect still drawing behind a closed sheet is a
 * battery leak nobody would ever notice in testing.
 */
export function loop(
  durationMs: number,
  frame: (elapsedMs: number, dtSec: number) => void,
  onStop?: () => void,
): () => void {
  let raf = 0
  let last = performance.now()
  const started = last

  function tick(now: number) {
    const dt = Math.min(0.05, (now - last) / 1000)
    last = now
    const elapsed = now - started
    frame(elapsed, dt)
    if (elapsed < durationMs) raf = requestAnimationFrame(tick)
    else onStop?.()
  }
  raf = requestAnimationFrame(tick)

  return () => {
    if (raf) cancelAnimationFrame(raf)
    onStop?.()
  }
}

// ── Pixel sprites ──────────────────────────────────────────────────────
// Rows of characters, one per pixel, keyed to a palette. Drawn as filled
// rects rather than scaled images so they stay hard-edged at any size.
//
// The 'O' rim light is not decoration: the first pass of this sprite used
// a near-black suit, and against a dark profile card the legs vanished
// entirely and the run frames were indistinguishable from standing still.

export const NINJA_PALETTE: Record<string, string | null> = {
  '.': null,
  K: '#181826', D: '#343450', O: '#606490',
  R: '#ce2e4a', r: '#961c32',
  S: '#f0cea8', W: '#fafaff',
  B: '#a8bedc', b: '#6e82a5',
}

export const NINJA_IDLE = [
  '....OOOO....', '...OKKKKO...', '..RRRRRRRRr.', '..OSSWWSSO.r',
  '..OKSSSSKO..', '...OKKKKO...', '..RODDDDOR..', '.rROKDDKOO..',
  '...OKDDKO...', '...OKKKKO...', '...OK..KO...', '...OK..KO...',
  '...OK..KO...', '..OKK..KKO..', '..OOO..OOO..', '............',
]

export const NINJA_RUN_A = [
  '............', '....OOOO....', '...OKKKKO...', '..RRRRRRRRr.',
  '..OSSWWSSO.r', '..OKSSSSKO..', '.ROKDDDDKO..', 'rROKDDDDKO..',
  '...OKDDKO...', '...OKKKKO...', '..OKKO.OKO..', '.OKKO...OKO.',
  '.OKO.....OKO', 'OOO.......OO', '............', '............',
]

export const NINJA_RUN_B = [
  '............', '............', '....OOOO....', '...OKKKKO...',
  '..RRRRRRRRr.', '..OSSWWSSO.r', '..OKSSSSKO..', '..ROKDDKOR..',
  '.rROKDDKOO..', '...OKKKKO...', '...OKKKKO...', '...OKOOKO...',
  '..OKKO.OKO..', '..OOO..OOO..', '............', '............',
]

export const NINJA_SLASH = [
  '.........BB.', '....OOOO.Bb.', '...OKKKKBb..', '..RRRRRRBb..',
  '..OSSWWSBb..', '..OKSSSSBO..', '..ROKDDKbO..', '.rROKDDKOO..',
  '...OKDDKO...', '...OKKKKO...', '..OKKO.OKKO.', '..OKO...OKO.',
  '.OKKO...OKKO', '.OOO.....OOO', '............', '............',
]

export function drawSprite(
  ctx: CanvasRenderingContext2D,
  frame: string[],
  palette: Record<string, string | null>,
  ox: number, oy: number, px: number,
  alpha = 1,
  tint?: string,
) {
  ctx.globalAlpha = alpha
  for (let y = 0; y < frame.length; y++) {
    const row = frame[y]
    for (let x = 0; x < row.length; x++) {
      const colour = palette[row[x]]
      if (!colour) continue
      ctx.fillStyle = tint ?? colour
      ctx.fillRect(Math.round(ox + x * px), Math.round(oy + y * px), px, px)
    }
  }
  ctx.globalAlpha = 1
}
