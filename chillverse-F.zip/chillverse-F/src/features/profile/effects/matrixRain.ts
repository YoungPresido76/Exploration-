// src/features/profile/effects/matrixRain.ts
import { fitCanvas, loop, mountCanvas, TWO_BEAT_MS } from './canvas'

const GLYPHS =
  'アカサタナハマヤラワイキシチニヒミリヲウクスツヌフムユルンエケセテネヘメレオコソトノホモヨロ0123456789'

interface Column {
  y: number
  speed: number
  len: number
  chars: string[]
  lit: boolean
}

/**
 * Matrix rain.
 *
 * Three things separate this from text sliding down a screen:
 *   · the leading glyph is near-white with a glow and the tail dims behind
 *     it, so a column has a direction
 *   · glyphs MUTATE mid-fall — a column is not a fixed word, and that
 *     flicker is most of what makes it read as the real thing
 *   · every column carries its own speed, length and respawn, so they
 *     never march in step
 *
 * The trail is made by ERASING a little of each previous frame
 * (destination-out) rather than painting black over it. The canonical
 * version paints black, which here would black out the profile card
 * underneath.
 */
export function matrixRain(host: HTMLElement): () => void {
  const canvas = mountCanvas(host)
  const surface = fitCanvas(canvas)
  if (!surface) return () => {}
  const { ctx, w, h } = surface

  const size = 13
  const cols = Math.max(6, Math.floor(w / size))
  const columns: Column[] = []
  for (let i = 0; i < cols; i++) {
    const len = 7 + Math.floor(Math.random() * 12)
    const chars: string[] = []
    for (let k = 0; k < len; k++) chars.push(GLYPHS[(Math.random() * GLYPHS.length) | 0])
    columns.push({
      y: -Math.random() * h,
      speed: 26 + Math.random() * 46,
      len, chars,
      lit: Math.random() < 0.75,
    })
  }

  ctx.font = `${size}px ui-monospace, Menlo, monospace`
  ctx.textBaseline = 'top'

  return loop(TWO_BEAT_MS, (_elapsed, dt) => {
    ctx.globalCompositeOperation = 'destination-out'
    ctx.fillStyle = 'rgba(0,0,0,0.16)'
    ctx.fillRect(0, 0, w, h)
    ctx.globalCompositeOperation = 'source-over'

    for (let i = 0; i < cols; i++) {
      const c = columns[i]
      if (!c.lit) continue
      c.y += c.speed * dt
      if (Math.random() < 0.35) {
        c.chars[(Math.random() * c.len) | 0] = GLYPHS[(Math.random() * GLYPHS.length) | 0]
      }
      for (let k = 0; k < c.len; k++) {
        const y = c.y - k * size
        if (y < -size || y > h) continue
        const head = k === 0
        const fade = 1 - k / c.len
        ctx.shadowBlur = head ? 10 : 0
        ctx.shadowColor = 'rgba(70,255,150,0.9)'
        ctx.fillStyle = head
          ? 'rgba(215,255,232,0.98)'
          : `rgba(47,220,114,${(fade * 0.85).toFixed(3)})`
        ctx.fillText(c.chars[k], i * size, y)
      }
      ctx.shadowBlur = 0
      if (c.y - c.len * size > h) {
        c.y = -Math.random() * 60
        c.speed = 26 + Math.random() * 46
        c.lit = Math.random() < 0.85
      }
    }
  }, () => ctx.clearRect(0, 0, w, h))
}
