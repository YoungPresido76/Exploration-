// src/features/profile/profileEffect.tsx
//
// One place for the profile card effect. Before this there were three
// near-copies — ProfilePreviewModal, Profile and PlayerProfile each had
// their own cooldown helper, their own <video>, and their own hardcoded
// filter string — which is the same duplication trap as Chat.tsx's
// private Avatar and the two ICON_MAPs.
//
// WHAT CHANGED, and why:
//
//   - It used to loop forever while the sheet was open. It now plays for
//     five seconds and stops, Discord-style: fade in, play, fade out,
//     unmount. The <video> is removed at the end rather than paused, so
//     nothing keeps decoding behind the card.
//
//   - The localStorage cooldown is GONE (it was 3 minutes on your own
//     profile, 30 on someone else's). It existed because a forever-loop
//     needed muting; an effect that stops on its own doesn't. "It plays
//     again when you reopen the profile" and a 30-minute lock could not
//     both be true. A short same-profile debounce is kept so a double-tap
//     doesn't restart it mid-play.
//
//   - The orange glow is gone. The old filter carried two fire-coloured
//     drop-shadows baked in for one item, which tinted every effect
//     orange — a blue clip came out looking wrong.
//
// An effect whose url starts with "css:" is drawn, not downloaded — see
// profile-effect.css. Those cost no bandwidth at all, which matters with
// the storage egress cap.
import { useEffect, useRef, useState } from 'react'
import { EFFECTS, type DrawnEffect } from './effects'
import './profile-effect.css'

// Five seconds and gone read as abrupt. Every effect now plays, fades
// out, comes back for a shorter second beat and stops — the return is
// what makes it feel deliberate rather than cut off. Effects that script
// their own beats (Shadow strike) take the shorter solo envelope.
const TWO_BEAT_MS = 11_500
const SOLO_MS     = 9_000
const ENTER_DELAY_MS = 300
/** Long enough to swallow a double-tap, short enough to feel like "again". */
const REPLAY_DEBOUNCE_MS = 10_000

export const CSS_EFFECT_PREFIX = 'css:'

/** Everything drawn rather than downloaded lives in ./effects. */
export function drawnEffectFor(url: string | null | undefined): DrawnEffect | undefined {
  return isCssEffect(url) ? EFFECTS[cssEffectKey(url!)] : undefined
}

export function isCssEffect(url: string | null | undefined): boolean {
  return !!url && url.startsWith(CSS_EFFECT_PREFIX)
}

function cssEffectKey(url: string): string {
  return url.slice(CSS_EFFECT_PREFIX.length)
}

type Phase = 'idle' | 'playing'

/**
 * Drives one play of the effect for a given profile.
 *
 * `replay()` is exposed so a tap on the card can run it again, the way
 * Discord replays on click.
 */
export function useProfileEffectPlayback(url: string | null | undefined, profileId: string) {
  const [phase, setPhase] = useState<Phase>('idle')
  const lastPlayed = useRef<number>(0)
  const timers = useRef<number[]>([])

  function clear() {
    timers.current.forEach(t => window.clearTimeout(t))
    timers.current = []
  }

  function start() {
    if (!url) return
    const now = Date.now()
    if (now - lastPlayed.current < REPLAY_DEBOUNCE_MS) return
    lastPlayed.current = now
    clear()
    setPhase('playing')
    // One timer for the whole life. The CSS keyframe owns the fade in and
    // out; this only decides when the element leaves the tree.
    const drawn = drawnEffectFor(url)
    const life = drawn?.envelope === 'solo' ? SOLO_MS : TWO_BEAT_MS
    timers.current.push(window.setTimeout(() => setPhase('idle'), ENTER_DELAY_MS + life))
  }

  // Reopening the sheet remounts this hook, so a fresh open always plays.
  // Keyed on the profile too: opening a different profile plays its own.
  useEffect(() => {
    if (!url) return
    const reduced = typeof window !== 'undefined'
      && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (reduced) return
    start()
    return clear
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, profileId])

  return { playing: phase === 'playing', replay: start }
}

/**
 * The drawn effects' markup on its own, with no lifecycle attached.
 *
 * Split out because there are FOUR surfaces that render an effect, not
 * three: the preview sheet, both profile pages, and the Mall's "how
 * others see it" preview — and that last one runs its own long
 * play/rest cycle rather than the five-second one. It passes its own
 * wrapper class instead of cvfx-run, which is the only difference.
 */
export function CssEffect({ url, className }: { url: string; className?: string }) {
  const host = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = host.current
    const drawn = drawnEffectFor(url)
    if (!el || !drawn) return

    let stop: (() => void) | null = null
    let raf = 0
    let ranAt = { w: 0, h: 0 }
    let finished = false

    // WHY the wait: every canvas effect measures its box ONCE, at the
    // moment it starts, and sizes its whole world off that — Matrix
    // rain's column count, Snow globe's drift line, Shadow strike's
    // ground. Starting at mount measured the sheet mid-transition, so
    // the canvas came out short and every column reset against a height
    // the card doesn't have. This waits for a box that is actually
    // there before handing the host over.
    function start() {
      if (finished || !el || !drawn) return
      const rect = el.getBoundingClientRect()
      if (rect.width < 2 || rect.height < 2) {
        raf = requestAnimationFrame(start)
        return
      }
      stop?.()
      ranAt = { w: Math.round(rect.width), h: Math.round(rect.height) }
      stop = drawn.run(el)
    }
    raf = requestAnimationFrame(start)

    // Rotation, or the address bar collapsing, changes the sheet's real
    // height under a running effect. Restarting is the honest fix: the
    // runners have no re-measure hook, and half of them accumulate state
    // (Snow globe's pile) that a resized canvas would leave floating.
    const observer = new ResizeObserver(() => {
      if (finished || !el) return
      const rect = el.getBoundingClientRect()
      const settled = Math.abs(Math.round(rect.width) - ranAt.w) < 3
        && Math.abs(Math.round(rect.height) - ranAt.h) < 3
      if (settled) return
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(start)
    })
    observer.observe(el)

    // Every runner returns its own teardown: an effect still drawing
    // behind a closed profile is a battery leak nobody would ever notice
    // in testing.
    return () => {
      finished = true
      cancelAnimationFrame(raf)
      observer.disconnect()
      stop?.()
    }
  }, [url])

  const drawn = drawnEffectFor(url)
  if (!drawn) return null

  return (
    <div
      ref={host}
      className={`cvfx-host ${drawn.envelope === 'solo' ? 'cvfx-solo' : ''} ${className ?? ''}`.trim()}
    />
  )
}

/**
 * The effect over one profile card.
 *
 * A SIBLING of the sheet, never a child: the sheet scrolls, and an
 * absolutely-positioned child of a scroll container travels with the
 * content. The layer positions, the frame clips, and pointerEvents stays
 * none the whole way down — this is the real profile, so every button and
 * tab underneath has to stay live while it plays.
 */
export function ProfileEffectLayer({
  url, playing, style, frame,
}: {
  url: string | null | undefined
  playing: boolean
  /** Fade/transition applied to the positioning layer, not the card. */
  style?: React.CSSProperties

  /**
   * The card's own box — width, height, and its top corner radius.
   *
   * This is required in spirit even though it is optional in type: an
   * effect with no frame falls back to the layer's full box, which is
   * the viewport, which is the bug this prop exists to close. Callers
   * pass the same numbers they give the sheet itself.
   */
  frame?: React.CSSProperties
}) {
  if (!url || !playing) return null

  // Gold shower's coins fall a distance, and that distance is the card's
  // height. Handing it down as a variable keeps the number in one place
  // instead of a hardcoded viewport unit in the stylesheet.
  const fall = typeof frame?.height === 'number' ? `${frame.height}px` : undefined
  const frameStyle = {
    ...frame,
    ...(fall ? { ['--cvfx-fall' as string]: fall } : null),
  } as React.CSSProperties

  return (
    <div className="cvfx-layer" style={style} aria-hidden="true">
      <div className="cvfx-frame" style={frameStyle}>
        {isCssEffect(url) ? (
          <CssEffect url={url} className="cvfx-run" />
        ) : (
          /* The envelope goes on a WRAPPER, never on the <video> itself.
             Both used to sit on the same element, and a CSS animation
             outranks a normal declaration — so cvfx-life's `opacity: 1`
             overrode the video's own `opacity: .55` outright. These clips
             are shot on black; that opacity is the only reason the card
             shows through at all, so losing it painted the whole card
             solid black for the length of the effect. Nested, the two
             multiply: the envelope fades the wrapper 0 -> 1, the video
             stays at .55 throughout. */
          <div className="cvfx-run">
            <video
              className="cvfx-video"
              src={url}
              autoPlay
              loop
              muted
              playsInline
            />
          </div>
        )}
      </div>
    </div>
  )
}
