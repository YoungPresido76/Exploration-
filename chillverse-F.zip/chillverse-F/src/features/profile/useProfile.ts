// src/features/profile/useProfile.ts
import { useEffect, useState } from 'react'
import type { PostgrestError } from '@supabase/supabase-js'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import type { Profile } from '../../shared/types'

interface UseProfileState {
  profile: Profile | null
  loading: boolean
  error: PostgrestError | null
  refetch: () => void
}

// ── Why there's a store here now ─────────────────────────────────────
//
// 33 components call useProfile(). Each one used to own its own state
// and fire its own get_own_profile round trip on mount, so a single
// navigation could easily cost three or four identical requests —
// AppLayout is always mounted and asks, the page asks, a section inside
// the page asks. Every one of them rendered a skeleton/empty state
// until its own request came back, which is a large part of why the app
// felt slow and flickery even on a good connection.
//
// This is a module-level store, same shape as plunderCrown.ts: ONE copy
// of the profile, ONE in-flight request no matter how many components
// ask at once, and a subscriber list so a refetch() from anywhere
// updates all of them together. Mounting a component that already has a
// fresh value renders it immediately with no request and no skeleton.
//
// TTL is deliberately short. This row carries diamonds, orbs, XP and
// streak — things that change constantly — so the cache exists to
// collapse the burst of identical calls around a navigation, not to
// hold data for minutes. Anything that MUTATES the profile (a purchase,
// an edit, a game payout) should keep calling refetch() exactly as
// before; that clears the cache and re-broadcasts to everyone.
const TTL_MS = 15_000

interface Snapshot {
  profile: Profile | null
  loading: boolean
  error: PostgrestError | null
}

let snapshot: Snapshot = { profile: null, loading: true, error: null }
let fetchedAt = 0
let fetchedFor: string | null = null
let inFlight: Promise<void> | null = null
const listeners = new Set<() => void>()

function emit() { listeners.forEach(l => l()) }

function setSnapshot(next: Snapshot) {
  snapshot = next
  emit()
}

function load(userId: string, force: boolean): Promise<void> {
  const fresh = fetchedFor === userId && Date.now() - fetchedAt < TTL_MS
  if (!force && fresh && !snapshot.loading) return Promise.resolve()
  // Someone else already asked and hasn't come back yet — ride along on
  // their request instead of opening a second one.
  if (inFlight && !force) return inFlight

  if (!snapshot.profile || fetchedFor !== userId) {
    setSnapshot({ profile: fetchedFor === userId ? snapshot.profile : null, loading: true, error: null })
  }

  // Wrapped in a real Promise: supabase's builder is a PromiseLike, so it
  // has .then() but no .catch()/.finally() to hang the cleanup off.
  const request: Promise<void> = (async () => {
    try {
      const { data, error } = await supabase.rpc('get_own_profile').single()
      setSnapshot({
        profile: (data as Profile | null) ?? null,
        loading: false,
        error: (error as PostgrestError | null) ?? null,
      })
    } catch {
      // Network failure: keep whatever we already had on screen rather
      // than blanking every consumer at once.
      setSnapshot({ profile: snapshot.profile, loading: false, error: snapshot.error })
    } finally {
      fetchedAt = Date.now()
      fetchedFor = userId
      inFlight = null
    }
  })()

  inFlight = request
  return request
}

/** Drop the cached profile — called on sign-out and whenever the user changes. */
export function resetProfileCache() {
  fetchedAt = 0
  fetchedFor = null
  inFlight = null
  setSnapshot({ profile: null, loading: false, error: null })
}

/**
 * Force every mounted useProfile() to refetch. Exported so non-component
 * code (payout handlers, purchase flows) can invalidate the cache without
 * having to hold a hook instance.
 */
export function refreshProfile() {
  if (fetchedFor) void load(fetchedFor, true)
}

/**
 * Fetches the signed-in user's row from `profiles`, keyed off the session
 * exposed by useAuth(). Re-fetches whenever the underlying user changes
 * (e.g. login/logout). Shared across every caller — see the note above.
 */
export function useProfile(): UseProfileState {
  const { user } = useAuth()
  const [, forceRender] = useState(0)

  useEffect(() => {
    const listener = () => forceRender(n => n + 1)
    listeners.add(listener)
    return () => { listeners.delete(listener) }
  }, [])

  useEffect(() => {
    if (!user) {
      if (fetchedFor !== null || snapshot.profile || snapshot.loading) resetProfileCache()
      return
    }
    if (fetchedFor && fetchedFor !== user.id) resetProfileCache()
    void load(user.id, false)
  }, [user])

  return {
    profile: snapshot.profile,
    // No session yet is not "loading" — that's the signed-out resting state.
    loading: user ? snapshot.loading : false,
    error: snapshot.error,
    refetch: refreshProfile,
  }
}
