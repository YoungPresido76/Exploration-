// src/features/profile/SuspensionNotice.tsx
//
// The card another player sees in place of a suspended account's profile.
// Used by both surfaces so the wording and treatment can't drift: the full
// page (PlayerProfile's BannedProfileView) and the preview sheet
// (ProfilePreviewModal).
//
// The text is written by a mod through mod_set_public_notice and stored in
// user_moderation.public_notice_title / public_notice_reason. It is NOT
// ban_reason — that column is internal, written by mods for mods, and must
// never reach another player's screen.
import { Ban } from 'lucide-react'

interface SuspensionNoticeProps {
  /** The headline, e.g. "This account has been suspended". Falls back to a
   *  neutral line if a mod banned someone without writing one. */
  title: string | null
  /** The public explanation, e.g. "Suspected to be part of a fraud
   *  activity". Optional — plenty of suspensions don't need one. */
  reason: string | null
}

export default function SuspensionNotice({ title, reason }: SuspensionNoticeProps) {
  return (
    <div
      style={{
        marginTop: 16,
        padding: '16px 16px 18px',
        borderRadius: 14,
        background: 'color-mix(in srgb, #ff4d4d 10%, transparent)',
        border: '1px solid color-mix(in srgb, #ff4d4d 34%, transparent)',
        textAlign: 'center',
      }}
    >
      <div
        style={{
          width: 34, height: 34, borderRadius: '50%', margin: '0 auto 10px',
          background: 'color-mix(in srgb, #ff4d4d 18%, transparent)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        <Ban size={17} color="#ff4d4d" strokeWidth={2.5} />
      </div>

      <p style={{ margin: 0, fontSize: 13.5, fontWeight: 800, color: 'var(--text)', lineHeight: 1.4 }}>
        {title || 'This account has been suspended'}
      </p>

      {reason && (
        <p style={{ margin: '10px 0 0', fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.6 }}>
          <span style={{ fontWeight: 700, color: 'var(--text-muted)' }}>Reason: </span>
          {reason}
        </p>
      )}
    </div>
  )
}
