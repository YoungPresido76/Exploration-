// src/features/profile/VibeBubble.tsx
//
// The thought bubble beside the avatar on the profile preview sheet.
//
// TWO THINGS ABOUT ITS PLACEMENT, both load-bearing:
//
// 1. It is absolutely positioned against the SHEET, not the banner. The
//    bubble sits level with the avatar's upper half, which means it
//    crosses the banner's bottom edge — and the banner block is
//    overflow:hidden, so a bubble rendered inside it gets sliced in half.
//
// 2. It must be a SIBLING of the banner's drag zone. The whole banner
//    strip carries dragHandleProps (drag-to-dismiss), so anything nested
//    inside it has its taps swallowed by the gesture. The close and menu
//    buttons already sit outside for exactly this reason.
//
// Colours are CSS variables throughout, so the holo skin and all eight
// profile skins repaint the bubble, the dot and the border together
// without this file knowing they exist.
import { Plus } from 'lucide-react'
import type { Vibe } from './vibe'

interface Props {
  vibe: Vibe | null
  /** Your own profile gets the + affordance and a tap that opens the
   *  editor. On someone else's the bubble is plain text and inert. */
  isMe?: boolean
  onEdit?: () => void
  /**
   * Distance from the sheet's top edge to the bubble, in px. The default
   * matches the preview sheet's stack: 22px of drag-pill row + a 130px
   * banner puts the avatar's top edge at 152, and the bubble sits just
   * above the middle of it.
   */
  top?: number
  /** Left offset — clears the 62px avatar plus its 16px gutter. */
  left?: number
}

export default function VibeBubble({ vibe, isMe = false, onEdit, top = 126, left = 92 }: Props) {
  // No vibe, no bubble, no reserved space. An empty state here would be a
  // permanent grey pill on every profile that never set one.
  if (!vibe && !isMe) return null
  if (!vibe && (!isMe || !onEdit)) return null

  const interactive = isMe && !!onEdit

  return (
    <>
      {/* The single tail dot, at roughly 1 o'clock off the avatar's corner.
          Rendered before the bubble so it streams in underneath it. */}
      <div
        aria-hidden
        style={{
          position: 'absolute', left: left - 14, top: top - 10,
          width: 8, height: 8, borderRadius: '50%',
          background: 'var(--surface2)', border: '1px solid var(--border)',
          zIndex: 3, pointerEvents: 'none',
        }}
      />

      <button
        type="button"
        onClick={interactive ? (e) => { e.stopPropagation(); onEdit!() } : undefined}
        disabled={!interactive}
        aria-label={vibe ? `Vibe: ${vibe.text}` : 'Set a vibe'}
        style={{
          position: 'absolute', left, top, zIndex: 3,
          maxWidth: 210,
          display: 'flex', alignItems: 'center', gap: 7,
          background: 'var(--surface2)',
          border: '1px solid var(--border)',
          borderRadius: 16,
          padding: isMe ? '6px 12px 6px 7px' : '6px 12px',
          cursor: interactive ? 'pointer' : 'default',
          textAlign: 'left',
          boxShadow: 'var(--elev-raise)',
        }}
      >
        {isMe && (
          <span style={{
            width: 19, height: 19, borderRadius: '50%', flexShrink: 0,
            background: 'var(--surface3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'var(--text-dim)',
          }}>
            <Plus size={12} />
          </span>
        )}
        <span style={{
          fontSize: 12.5, fontStyle: 'italic', fontWeight: 600,
          color: vibe ? 'var(--text)' : 'var(--text-muted)',
          // One line, always. A wrapped bubble breaks the tail geometry —
          // the dot is positioned against the bubble's top edge.
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>
          {vibe
            ? `${vibe.emoji ? `${vibe.emoji} ` : ''}${vibe.text}`
            : "What's the vibe?"}
        </span>
      </button>
    </>
  )
}
