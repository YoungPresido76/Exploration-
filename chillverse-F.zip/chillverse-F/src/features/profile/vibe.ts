// src/features/profile/vibe.ts
//
// The "vibe" — a short expiring line that renders as a thought bubble
// beside the avatar on a profile.
//
// Expiry is evaluated at READ time by get_public_profile, so an expired
// vibe simply stops coming back. There is no cron and nothing to clean
// up; the row keeps its last value until it's overwritten.
//
// Writes go through set_profile_vibe() because `authenticated` has a
// column-level UPDATE allow-list on profiles and these columns aren't on
// it — the same position profile_ui_skin and holo_profile_enabled are in.
// See migration 0175c.
import { supabase } from '../../shared/lib/supabase'

/** Matches the CHECK constraint on profiles.vibe_text. Enforced in both
 *  places on purpose: the input stops you typing past it, the constraint
 *  stops a direct RPC call. */
export const VIBE_MAX_LENGTH = 30

export interface VibeDuration {
  id: string
  label: string
  /** null = never expires. */
  hours: number | null
  /** Expiry clamps to the end of the local day rather than adding hours. */
  endOfDay?: boolean
}

export const VIBE_DURATIONS: VibeDuration[] = [
  { id: '1h',    label: '1 hour',   hours: 1 },
  { id: '4h',    label: '4 hours',  hours: 4 },
  { id: 'today', label: 'Today',    hours: null, endOfDay: true },
  { id: 'never', label: 'Never',    hours: null },
]

export const DEFAULT_VIBE_DURATION = '4h'

/** Resolves a duration id to the timestamp the server should store.
 *  Returns null for "Never" — the column being null IS "no expiry". */
export function resolveVibeExpiry(durationId: string, from: Date = new Date()): string | null {
  const duration = VIBE_DURATIONS.find(d => d.id === durationId)
  if (!duration) return null
  if (duration.endOfDay) {
    const end = new Date(from)
    end.setHours(23, 59, 59, 999)
    // Setting a "Today" vibe at 23:59 would otherwise expire in seconds.
    if (end.getTime() - from.getTime() < 60_000) return null
    return end.toISOString()
  }
  if (duration.hours == null) return null
  return new Date(from.getTime() + duration.hours * 3600_000).toISOString()
}

export interface VibePreset {
  emoji: string
  text: string
}

/** Tapping a preset fills the input — it doesn't submit. The text stays
 *  editable, which is how someone lands on "Gaming right now (badly)". */
export const VIBE_PRESETS: VibePreset[] = [
  { emoji: '🟢', text: 'Free to chat' },
  { emoji: '⏰', text: 'Slow to respond' },
  { emoji: '🎮', text: 'Gaming right now' },
  { emoji: '⚔️', text: 'In a match' },
  { emoji: '😹', text: 'Hanging with friends' },
  { emoji: '✈️', text: 'Traveling' },
  { emoji: '🔥', text: 'Excited!' },
  { emoji: '🔕', text: 'Do not disturb' },
]

export interface Vibe {
  text: string
  emoji: string | null
  expiresAt: string | null
}

/** Reads a vibe off anything shaped like a profile row. Returns null when
 *  there's no live vibe, which is what tells the bubble not to render —
 *  there is no empty state and no reserved space. */
export function vibeFrom(
  p: { vibe_text?: string | null; vibe_emoji?: string | null; vibe_expires_at?: string | null } | null | undefined,
): Vibe | null {
  if (!p?.vibe_text) return null
  // get_public_profile already nulls an expired vibe, but a profile read
  // straight off the table (your own, in Edit Profile) hasn't been through
  // it — so check here too rather than trusting the source.
  if (p.vibe_expires_at && new Date(p.vibe_expires_at).getTime() <= Date.now()) return null
  return { text: p.vibe_text, emoji: p.vibe_emoji ?? null, expiresAt: p.vibe_expires_at ?? null }
}

export async function setVibe(text: string, emoji: string | null, expiresAt: string | null): Promise<void> {
  const { error } = await supabase.rpc('set_profile_vibe', {
    p_text: text, p_emoji: emoji, p_expires_at: expiresAt,
  })
  if (error) {
    if (error.message.includes('CV_VIBE_TOO_LONG')) throw new Error(`Keep it under ${VIBE_MAX_LENGTH} characters`)
    if (error.message.includes('CV_VIBE_BAD_EXPIRY')) throw new Error('Pick a time in the future')
    throw new Error(error.message)
  }
}

/** Clearing is the same call with no text — the RPC nulls all four
 *  columns, so there's no separate delete path to keep in sync. */
export async function clearVibe(): Promise<void> {
  const { error } = await supabase.rpc('set_profile_vibe', {
    p_text: null, p_emoji: null, p_expires_at: null,
  })
  if (error) throw new Error(error.message)
}

/** "4h left" / "until 8:30 PM" for the editor. */
export function vibeExpiryLabel(expiresAt: string | null): string {
  if (!expiresAt) return "Doesn't expire"
  const ms = new Date(expiresAt).getTime() - Date.now()
  if (ms <= 0) return 'Expired'
  if (ms < 3600_000) return `${Math.max(1, Math.round(ms / 60_000))} min left`
  const d = new Date(expiresAt)
  return `Until ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
}
