// src/features/profile/You.tsx
//
// The dock's fifth tab, and the home for everything the sidebar used to
// hold: ranks, achievements, inventory, wallet, settings, staff tools. The
// header is a live summary (avatar, level, XP, streak) that opens the real
// profile popup on tap — /profile itself is a popup route, not a page (see
// ProfileRedirect.tsx), so this is the page that stands in for it.
import { useCallback, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Trophy, Award, Package, Wallet, Settings, Sparkles, Gift, Layers,
  ShieldCheck, LayoutDashboard, Crown, LifeBuoy, Bell, Flame, Swords, Activity,
} from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import Seo from '../../shared/components/Seo'
import { useProfile } from './useProfile'
import { useProfilePreview } from '../../context/ProfilePreview'
import { useModRole } from '../moderation/useModRole'
import { getLevelFromXp, getXpProgress } from '../../shared/lib/level'
import { ripple } from '../../shared/lib/ripple'

interface LinkRow {
  label: string
  sub: string
  to: string
  icon: typeof Trophy
}

const PROGRESS: LinkRow[] = [
  { label: 'Usage',        sub: 'Session limit & reset time', to: '/usage',        icon: Activity },
  { label: 'Achievements', sub: 'Everything you have earned', to: '/achievements', icon: Award },
  { label: 'Battle Deck',  sub: 'Your cards and consumables', to: '/skill-tree',   icon: Swords },
  { label: 'Streak',       sub: 'Keep the fire alive',        to: '/streak',       icon: Flame },
]

const STUFF: LinkRow[] = [
  { label: 'Inventory', sub: 'Items and consumables',   to: '/inventory', icon: Package },
  { label: 'Wallet',    sub: 'Orbs, diamonds, history', to: '/wallet',    icon: Wallet },
  { label: 'Artifacts', sub: 'Relics you have collected', to: '/artifacts', icon: Sparkles },
]

const APP: LinkRow[] = [
  { label: 'Settings',      sub: 'Account, privacy, theme',  to: '/settings',      icon: Settings },
  { label: 'Notifications', sub: 'Everything you missed',    to: '/notifications', icon: Bell },
  { label: 'Chillverse Pro', sub: 'Perks and higher limits', to: '/pro',           icon: Crown },
  { label: 'Invite a friend', sub: 'Earn rewards together',  to: '/referral',      icon: Gift },
  { label: 'Support',       sub: 'Help, tickets, feedback',  to: '/support',       icon: LifeBuoy },
  { label: 'Version',       sub: 'What changed recently',    to: '/version',       icon: Layers },
]

// ── Section ───────────────────────────────────────────────────────────
// DECLARED AT MODULE LEVEL ON PURPOSE. This used to live inside You(),
// which meant every single render of You created a BRAND NEW component
// type — React can't know it's "the same" Section, so it unmounted and
// remounted every row underneath it. The `youRowIn` fade-up animation
// restarts on mount, so each re-render of the page replayed the whole
// stagger: useProfile() and useModRole() both resolve async and each
// pushes its own state update, which is why the page visibly blinked
// two or three times before settling. Defining it out here makes the
// type stable, so re-renders just update the existing rows.
//
// `startIndex` replaces the old closure-over-`stagger` counter — the
// stagger has to stay continuous across sections, and a module-level
// component can't read a variable from inside You().
function Section({ title, rows, startIndex, onNavigate }: {
  title: string
  rows: LinkRow[]
  startIndex: number
  onNavigate: (to: string) => void
}) {
  if (!rows.length) return null
  return (
    <>
      <div className="t-label" style={{ marginTop: 26, marginBottom: 12 }}>{title}</div>
      {rows.map((row, i) => {
        const Icon = row.icon
        const delay = (startIndex + i) * 26
        return (
          <button
            key={row.to}
            type="button"
            className="ripple-wrap you-row"
            style={{ animationDelay: `${delay}ms` }}
            onClick={(e) => { ripple(e); onNavigate(row.to) }}
          >
            <span className="you-row-icon"><Icon size={15} /></span>
            <span style={{ flex: 1, minWidth: 0, textAlign: 'left' }}>
              <span style={{ display: 'block', fontSize: 13.5, fontWeight: 600, color: 'var(--text)' }}>{row.label}</span>
              <span style={{ display: 'block', fontSize: 11, color: 'var(--text-dim)', marginTop: 1 }}>{row.sub}</span>
            </span>
            <span style={{ color: 'var(--text-muted)', fontSize: 16, lineHeight: 1 }}>›</span>
          </button>
        )
      })}
    </>
  )
}

export default function You() {
  const navigate = useNavigate()
  const { profile } = useProfile()
  const { openProfilePreview } = useProfilePreview()
  const { isStaff, isAdmin } = useModRole()

  const xpTotal = profile?.xp ?? 0
  const level = getLevelFromXp(xpTotal)
  const { current, max } = getXpProgress(xpTotal)
  const pct = Math.min(100, Math.round((current / max) * 100))
  const name = profile?.display_name || profile?.username || 'You'

  // Memoised so the array identity is stable across renders — without it
  // the Staff section's props change on every render even when nothing
  // about the role did.
  const staff: LinkRow[] = useMemo(() => [
    ...(isStaff ? [{ label: 'Moderation', sub: 'Reports and tickets', to: '/moderation', icon: ShieldCheck }] : []),
    ...(isAdmin ? [{ label: 'Admin', sub: 'Dashboard and ops', to: '/admin', icon: LayoutDashboard }] : []),
  ], [isStaff, isAdmin])

  const go = useCallback((to: string) => navigate(to), [navigate])

  return (
    <div style={{ maxWidth: 600, margin: '0 auto' }}>
      <Seo title="You" description="Your ranks, achievements, items and settings." path="/you" noindex />
      <style>{`
        .you-row {
          display: flex; align-items: center; gap: 12px; width: 100%;
          padding: 13px 15px; margin-bottom: 9px;
          background: var(--surface); border: 1px solid var(--border);
          border-radius: 16px; cursor: pointer; box-shadow: var(--elev-raise-sm);
          font-family: inherit;
          animation: youRowIn 0.4s var(--ease-out) both;
          transition: background-color 0.18s var(--ease-out);
        }
        .you-row:hover { background: var(--surface2); }
        .you-row-icon {
          width: 32px; height: 32px; border-radius: 10px; flex-shrink: 0;
          display: flex; align-items: center; justify-content: center;
          background: var(--surface2); border: 1px solid var(--border);
          color: var(--text-dim);
        }
        .you-hero { animation: youRowIn 0.42s var(--ease-out) both; }
        @keyframes youRowIn {
          from { opacity: 0; transform: translateY(12px) }
          to   { opacity: 1; transform: translateY(0) }
        }
        @media (prefers-reduced-motion: reduce) {
          .you-row, .you-hero { animation: none; }
        }
      `}</style>

      {/* Header — tap opens the full profile popup */}
      <button
        type="button"
        className="ripple-wrap you-hero"
        onClick={(e) => { ripple(e); if (profile?.id) openProfilePreview(profile.id) }}
        style={{
          display: 'flex', alignItems: 'center', gap: 14, width: '100%', textAlign: 'left',
          padding: 16, borderRadius: 20, cursor: 'pointer', fontFamily: 'inherit',
          background: 'var(--surface)', border: '1px solid var(--border)',
          boxShadow: 'var(--elev-raise-sm)',
        }}
      >
        <Avatar src={profile?.avatar} name={name} size={56} ownerId={profile?.id} disabled />
        <span style={{ flex: 1, minWidth: 0 }}>
          <span style={{ display: 'block', fontSize: 17, fontWeight: 800, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {name}
          </span>
          <span style={{ display: 'block', fontSize: 11.5, color: 'var(--text-muted)', marginBottom: 8 }}>
            Level {level} · {current.toLocaleString()} / {max.toLocaleString()} XP
          </span>
          <span className="xp-track" style={{ display: 'block' }}>
            <span className="xp-fill" style={{ display: 'block', width: `${pct}%` }} />
          </span>
        </span>
      </button>

      {/* Stagger indices are handed down explicitly so the fade-up stays
          continuous across sections now that Section lives outside You(). */}
      <Section title="Progress"   rows={PROGRESS} startIndex={0} onNavigate={go} />
      <Section title="Your stuff" rows={STUFF}    startIndex={PROGRESS.length} onNavigate={go} />
      <Section title="App"        rows={APP}      startIndex={PROGRESS.length + STUFF.length} onNavigate={go} />
      <Section title="Staff"      rows={staff}    startIndex={PROGRESS.length + STUFF.length + APP.length} onNavigate={go} />
    </div>
  )
}
