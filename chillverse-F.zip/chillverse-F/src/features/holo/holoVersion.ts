// src/features/holo/holoVersion.ts
//
// The Dynamic Profile switch.
//
// There is no separate 3D screen. The Dynamic Profile is a SKIN on the
// profile sheet everyone already uses — see holo-skin.css. That way
// Dynamic Duo, Clubs, achievements, the jail star, the wishlist and the
// attack sheet all inherit the treatment instead of having to be rebuilt
// inside a second profile, which is what the first attempt did wrong.
//
// Open to every account (0168b). The switch is keyed to the profile
// BEING VIEWED, not the viewer: you turn it on for yourself and from
// then on everyone who opens your profile sees it that way. Someone who
// hasn't turned it on renders exactly as before.
import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'

/**
 * Warning shown at switch-on time when a profile card effect is
 * equipped. The skin turns every surface translucent, and a looping
 * video underneath frosted glass reads as noise rather than as the
 * effect they paid for.
 */
export const HOLO_EFFECT_NOTICE =
  "Heads up — your profile card effect sits behind frosted glass while the Dynamic Profile is on, so it'll read much softer than usual."

export function useHoloToggle(initial: boolean) {
  const [on, setOn] = useState(initial)
  const [busy, setBusy] = useState(false)
  const dirty = useRef(false)

  /**
   * `initial` arrives late — the profile it comes from is fetched async,
   * so the first render always sees `false`. useState only reads its
   * argument once, which meant the switch drew as OFF regardless of the
   * stored value, and the first tap computed `!false` and turned the
   * feature ON for someone trying to turn it off.
   *
   * `dirty` stops this from fighting the user: once they've flipped it
   * themselves, a late or stale `initial` can never drag it back.
   */
  useEffect(() => {
    if (dirty.current) return
    setOn(initial)
  }, [initial])

  /** Optimistic, then corrected — the switch snaps home if the write fails. */
  const set = useCallback(async (next: boolean): Promise<{ ok: boolean; error?: string }> => {
    const before = on
    dirty.current = true
    setOn(next)
    setBusy(true)
    const { error } = await supabase.rpc('set_holo_profile', { p_on: next })
    setBusy(false)
    if (error) {
      setOn(before)
      return { ok: false, error: error.message }
    }
    return { ok: true }
  }, [on])

  return { on, busy, set }
}
