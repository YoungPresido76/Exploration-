// src/pages/Notifications.tsx
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Bell, Trophy, Flame, TrendingUp, MessageCircle,
  UserPlus, Zap, Star, Shield, Sparkles, Target, Award, Crown,
  CheckCircle, Sword, Rocket, Gem, Users, Heart, Mail, Sprout,
  User, Moon, Calendar, Activity, Flag, Plus, ArrowRight, Grid,
  Search, Gamepad2, Home, Lock, BarChart2, Layers, Brain, Eye,
  Trash2, Spade, Image, Wifi, CirclePlay, Camera, Compass,
  Megaphone, Gift, PhoneMissed, Repeat2, Share2, Check,
  Droplet, ShieldCheck, BookOpen, PartyPopper, Skull, Medal, Clock, BadgeCheck } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { getNotifications, markNotificationsRead, notifyFollow } from '../achievements/achievements'
import { getNotificationRoute } from './notificationRoutes'
import { trackWeeklyUniqueValue } from '../missions/weeklyMissions'
import { createHighlight } from '../highlights/highlights'
import { usePageHeader } from '../../context/PageHeader'
import type React from 'react'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type LucideIcon = React.ComponentType<any>

const ICON_MAP: Record<string, LucideIcon> = {
  'bell': Bell, 'trophy': Trophy, 'flame': Flame, 'trending-up': TrendingUp,
  'message-circle': MessageCircle, 'user-plus': UserPlus, 'zap': Zap,
  'star': Star, 'shield': Shield, 'sparkles': Sparkles, 'target': Target,
  'award': Award, 'crown': Crown, 'check-circle': CheckCircle, 'sword': Sword,
  'rocket': Rocket, 'gem': Gem, 'diamond': Gem, 'users': Users,
  'heart': Heart, 'mail': Mail, 'sprout': Sprout, 'user': User,
  'moon': Moon, 'calendar': Calendar, 'activity': Activity, 'flag': Flag,
  'plus': Plus, 'arrow-right': ArrowRight, 'grid': Grid, 'search': Search,
  'gamepad-2': Gamepad2, 'home': Home, 'lock': Lock, 'bar-chart': BarChart2,
  'layers': Layers, 'brain': Brain, 'eye': Eye, 'settings': Sparkles,
  'spade': Spade, 'image': Image, 'wifi': Wifi, 'circle-play': CirclePlay, 'camera': Camera,
  'compass': Compass, 'megaphone': Megaphone, 'gift': Gift, 'phone-missed': PhoneMissed,
  'repeat': Repeat2,
  'droplet': Droplet, 'book-open': BookOpen, 'party-popper': PartyPopper,
  'shield-check': ShieldCheck,
  'badge-check': BadgeCheck,
  'users-round': Users, 'mail-question': Mail,
  'skull': Skull,
  // The Championship's Runner-up notification. Same species of miss as
  // 'sword'/'skull' above — this map and the toast map are separate.
  'medal': Medal,
  'clock': Clock,
}

function NotifIcon({ iconKey, size = 16 }: { iconKey: string; size?: number }) {
  const Icon = ICON_MAP[iconKey] ?? Bell
  return <Icon size={size} />
}

interface Notification {
  id: string
  type: string
  title: string
  body: string
  icon: string
  read: boolean
  created_at: string
  meta: Record<string, unknown>
}

const TYPE_COLOR: Record<string, string> = {
  club_invite: '#9b6dff',
  dm_request:  '#4f8ef7',
  achievement: '#f5c542',
  follow:      '#3ecf8e',
  message:     '#4f8ef7',
  level_up:    '#9b6dff',
  rank_up:     'var(--accent)',
  streak:      '#ff4d8b',
  session_reset: '#4f8ef7',
  movies_open:   'var(--accent2)',
  come_back:     '#9b6dff',
  streak_warning: '#ff4d8b',
  exploration_complete: '#3ecf8e',
  club_added:            '#3ecf8e',
  club_invite_pending:   '#f5c542',
  club_invite_accepted:  '#3ecf8e',
  club_grace_warning:    '#ff4d8b',
  halo:                  'var(--accent)',
  mission:               '#3ecf8e',
  game_goal:             '#4f8ef7',
  rank_tag:              'var(--accent)',
  rank_down:             '#ff4d8b',
  gift:                  '#ff4d8b',
  missed_call:           '#4f8ef7',
  profile_view:          '#9b6dff',
  profile_like:          '#ff4d8b',
  follower_online:       '#3ecf8e',
  followed_map_completed: '#3ecf8e',
  referral_milestone:    '#f5c542',
  referral_completed:    '#f5c542',
  followed_rank_up:      'var(--accent)',
  new_post:              '#4f8ef7',
  post_tag:              '#4f8ef7',
  post_like:             '#ff4d8b',
  post_comment:          '#4f8ef7',
  comment_reply:         '#4f8ef7',
  comment_like:          '#ff4d6d',
  verification_result:   '#4f8ef7',
  post_repost:           '#3ecf8e',
  post_poll_vote:        '#4f8ef7',
  highlight_posted:      '#ff4d8b',
  announcement:          'var(--accent2)',
  version_coming_soon:   '#9b6dff',
  mention:               '#4f8ef7',
  most_wanted_update:    '#ff4d6d',
  item_revoked:          '#ff4f4f',
  pvp_attacked:          '#ff4d6d',
  pvp_elimination:       '#3ecf8e',
  pvp_bounty:            '#c9a86a',
  pvp_boss:              '#e6e1da',
  // Medusa's stone breaking. Red rather than the attack pink so it reads
  // as the same event the screen veil was counting down to.
  pvp_shatter:           '#ff3b30',
  pvp_revive:            '#7fe3bd',
  // Championship
  championship_match_live:   '#f5c542',
  championship_round_result: '#f5c542',
  championship_eliminated:   '#8a7fac',
  championship_bracket_advanced: '#f5c542',
  championship_kickoff_announced: '#f5c542',
  championship_kickoff_reminder:  '#f5c542',
}

const TYPE_ICON: Record<string, string> = {
  achievement: 'trophy',
  follow:      'user-plus',
  message:     'message-circle',
  level_up:    'trending-up',
  rank_up:     'zap',
  streak:      'flame',
  session_reset: 'wifi',
  movies_open:   'circle-play',
  come_back:     'sparkles',
  streak_warning: 'flame',
  exploration_complete: 'compass',
  club_added:            'users',
  club_invite_pending:   'flag',
  club_invite_accepted:  'users',
  club_grace_warning:    'flag',
  halo:                  'sparkles',
  mission:               'target',
  game_goal:             'target',
  rank_tag:              'megaphone',
  rank_down:             'crown',
  gift:                  'gift',
  missed_call:           'phone-missed',
  profile_view:          'eye',
  profile_like:          'heart',
  follower_online:       'wifi',
  followed_map_completed: 'compass',
  referral_milestone:    'gem',
  referral_completed:    'gem',
  followed_rank_up:      'crown',
  new_post:              'image',
  post_tag:              'image',
  post_like:             'heart',
  post_comment:          'message-circle',
  comment_reply:         'message-circle',
  comment_like:          'heart',
  verification_result:   'badge-check',
  post_repost:           'repeat',
  post_poll_vote:        'bar-chart',
  highlight_posted:      'star',
  announcement:          'megaphone',
  version_coming_soon:   'sparkles',
  mention:               'message-circle',
  most_wanted_update:    'flame',
  item_revoked:          'shield',
  pvp_attacked:          'sword',
  // 'shield' is already in ICON_MAP above; the toast map is separate and
  // needed its own entry.
  pvp_elimination:       'shield',
  pvp_bounty:            'gem',
  admin_request:         'shield-check',
  // Both reuse glyphs already present in BOTH icon maps — the recurring
  // trap here is adding an icon to this file and not to
  // NotificationToastRenderer, where it silently falls back to a bell.
  pvp_shatter:           'sword',
  pvp_revive:            'heart',
  // The PvP Boss belt changing hands. 'skull' had to go into THREE maps:
  // this one, NotificationToastRenderer's, and the badge icon map.
  pvp_boss:              'skull',
  championship_match_live:   'sword',
  championship_round_result: 'trophy',
  championship_eliminated:   'skull',
  championship_bracket_advanced: 'megaphone',
  championship_kickoff_announced: 'calendar',
  championship_kickoff_reminder:  'clock',
}

const TYPE_LABEL: Record<string, string> = {
  achievement: 'Achievement',
  follow:      'Social',
  message:     'Message',
  level_up:    'Level Up',
  rank_up:     'Rank',
  streak:      'Streak',
  session_reset: 'Session',
  movies_open:   'Movies',
  come_back:     'Chillverse',
  streak_warning: 'Streak',
  exploration_complete: 'Exploration',
  club_added:            'Club',
  club_invite_pending:   'Club',
  club_invite_accepted:  'Club',
  club_grace_warning:    'Club',
  halo:                  'Halo',
  mission:               'Mission',
  game_goal:             'Game Goal',
  rank_tag:              'Rank Tag',
  rank_down:             'Rank',
  gift:                  'Gift',
  missed_call:           'Message',
  profile_view:          'Social',
  profile_like:          'Social',
  follower_online:       'Social',
  followed_map_completed: 'Exploration',
  referral_milestone:    'Referral',
  referral_completed:    'Referral',
  followed_rank_up:      'Rank',
  new_post:              'Post',
  post_tag:              'Post',
  post_like:             'Post',
  post_comment:          'Post',
  comment_reply:         'Comment',
  comment_like:          'Comment',
  verification_result:   'Verification',
  post_repost:           'Post',
  post_poll_vote:        'Poll',
  highlight_posted:      'Highlight',
  announcement:          'Announcement',
  version_coming_soon:   'Chillverse',
  mention:               'Mention',
  most_wanted_update:    'Most Wanted',
  item_revoked:          'Moderation',
  pvp_attacked:          'Battle',
  pvp_elimination:       'Battle',
  pvp_bounty:            'Bounty',
  pvp_boss:              'Battle',
  pvp_shatter:           'Battle',
  pvp_revive:            'Battle',
  championship_match_live:   'Championship',
  championship_round_result: 'Championship',
  championship_eliminated:   'Championship',
  championship_bracket_advanced: 'Championship',
  championship_kickoff_announced: 'Championship',
  championship_kickoff_reminder:  'Championship',
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 60000)    return 'just now'
  if (diff < 3600000)  return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`
  return new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short' })
}

/** Inline "Follow back" action shown on a 'follow' notification, when the
 *  follow isn't already mutual. Hides itself once you already follow them
 *  (nothing to do) or once you've just followed back (optimistic). */
function FollowBackButton({ myId, followerId }: { myId: string; followerId: string }) {
  const [state, setState] = useState<'checking' | 'show' | 'hidden' | 'busy'>('checking')

  useEffect(() => {
    let active = true
    supabase.from('follows').select('follower_id')
      .eq('follower_id', myId).eq('following_id', followerId).maybeSingle()
      .then(({ data }) => { if (active) setState(data ? 'hidden' : 'show') })
    return () => { active = false }
  }, [myId, followerId])

  if (state === 'checking' || state === 'hidden') return null

  async function handleClick(e: React.MouseEvent) {
    e.stopPropagation()
    setState('busy')
    await supabase.from('follows').insert({ follower_id: myId, following_id: followerId })
    await notifyFollow(followerId)
    trackWeeklyUniqueValue(myId, 'users_followed', followerId).catch(console.error)
    setState('hidden')
  }

  return (
    <button type="button" onClick={handleClick} disabled={state === 'busy'}
      style={{
        marginTop: 8, padding: '6px 14px', borderRadius: 10, border: 'none',
        background: 'var(--accent)', color: '#fff', fontSize: 11.5, fontWeight: 700,
        cursor: state === 'busy' ? 'default' : 'pointer', opacity: state === 'busy' ? 0.6 : 1,
      }}>
      {state === 'busy' ? 'Following…' : 'Follow back'}
    </button>
  )
}

/** "+15 orbs" / "+1 voucher" / "+25 XP" — matches the wording claim_random_surprise()
 *  already put in the notification body, just reused for the highlight caption. */
function surpriseRewardText(rewardType: string, rewardAmount: number): string {
  if (rewardType === 'orbs') return `+${rewardAmount} orbs`
  if (rewardType === 'vouchers') return `+${rewardAmount} voucher${rewardAmount === 1 ? '' : 's'}`
  if (rewardType === 'xp') return `+${rewardAmount} XP`
  return ''
}

/** Inline "Share" action on a Random Surprise notification (meta.source ===
 *  'random_surprise', set by claim_random_surprise() — migration 0122). Only
 *  a real win (not the 19.4% "nothing" roll) has anything worth sharing.
 *  Posts a 'random_surprise' highlight, same client-side createHighlight()
 *  flow as any other highlight — dedup_key keyed to the claim date so
 *  re-opening this notification can't post it twice. */
function ShareSurpriseButton({
  userId, rewardType, rewardAmount, createdAt,
}: { userId: string; rewardType: string; rewardAmount: number; createdAt: string }) {
  const [shared, setShared] = useState(false)
  const [busy, setBusy] = useState(false)

  const rewardText = surpriseRewardText(rewardType, rewardAmount)
  if (!rewardText) return null

  async function handleClick(e: React.MouseEvent) {
    e.stopPropagation()
    if (busy || shared) return
    setBusy(true)
    const claimDate = createdAt.slice(0, 10) // UTC-day, matches random_surprise_claims.claim_date
    const { error } = await createHighlight({
      authorId: userId,
      kind: 'random_surprise',
      gameKey: null,
      body: `I got a random surprise of ${rewardText}!`,
      dedupKey: `random_surprise:${userId}:${claimDate}`,
    })
    setBusy(false)
    if (!error) setShared(true)
  }

  return (
    <button type="button" onClick={handleClick} disabled={busy || shared}
      style={{
        marginTop: 8, display: 'flex', alignItems: 'center', gap: 5, padding: '6px 14px',
        borderRadius: 10, border: 'none', background: shared ? 'rgba(62,207,142,0.14)' : 'var(--accent)',
        color: shared ? '#3ecf8e' : '#fff', fontSize: 11.5, fontWeight: 700,
        cursor: busy || shared ? 'default' : 'pointer', opacity: busy ? 0.6 : 1,
      }}>
      {shared ? <Check size={12} /> : <Share2 size={12} />}
      {shared ? 'Shared to Highlights' : busy ? 'Sharing…' : 'Share to Highlights'}
    </button>
  )
}

const FILTERS = ['All', 'Achievement', 'Social', 'Message', 'Level Up', 'Rank', 'Streak']

export default function Notifications() {
  usePageHeader({ title: 'Notifications' })
  const { session } = useAuth()
  const userId = session?.user?.id ?? null
  const navigate = useNavigate()

  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [activeFilter, setActiveFilter] = useState('All')
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    if (!userId) return
    setLoading(true)
    getNotifications(userId).then(data => {
      const notifs = data as Notification[]
      setNotifications(notifs)
      setUnreadCount(notifs.filter(n => !n.read).length)
      setLoading(false)
      // Mark all read
      markNotificationsRead(userId)
    })
  }, [userId])

  // Real-time new notifications
  useEffect(() => {
    if (!userId) return
    const sub = supabase
      .channel(`notif-page:${userId}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'notifications',
        filter: `user_id=eq.${userId}`
      }, (payload) => {
        setNotifications(prev => [payload.new as Notification, ...prev])
      })
      .subscribe()
    return () => { supabase.removeChannel(sub) }
  }, [userId])

  async function clearAll() {
    if (!userId) return
    await supabase.from('notifications').delete().eq('user_id', userId)
    setNotifications([])
  }

  async function deleteOne(id: string) {
    await supabase.from('notifications').delete().eq('id', id)
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  const filtered = activeFilter === 'All'
    ? notifications
    : notifications.filter(n => (TYPE_LABEL[n.type] ?? n.type) === activeFilter)

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', paddingBottom: 80 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', borderBottom: '1px solid var(--border)' }}>
        <div>
          {unreadCount > 0 && <div style={{ fontSize: 11, color: 'var(--accent)' }}>{unreadCount} unread</div>}
        </div>
        {notifications.length > 0 && (
          <button type="button" onClick={clearAll}
            style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 10, background: 'rgba(255,107,107,0.08)', border: '1px solid rgba(255,107,107,0.2)', color: '#ff6b6b', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
            <Trash2 size={12} /> Clear all
          </button>
        )}
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '14px 20px 0', scrollbarWidth: 'none' }}>
        {FILTERS.map(f => (
          <button key={f} type="button" onClick={() => setActiveFilter(f)}
            style={{ padding: '6px 14px', borderRadius: 20, border: 'none', flexShrink: 0, cursor: 'pointer', fontSize: 12, fontWeight: 600, background: activeFilter === f ? 'var(--accent)' : 'var(--surface)', color: activeFilter === f ? '#fff' : 'var(--text-dim)', boxShadow: activeFilter === f ? '0 4px 12px color-mix(in srgb, var(--accent) 30%, transparent)' : '2px 2px 6px var(--neu-dark)', transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out), opacity var(--dur-fast) var(--ease-out)' }}>
            {f}
          </button>
        ))}
      </div>

      {/* List */}
      <div style={{ padding: '14px 16px 0', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
            <span style={{ width: 30, height: 30, borderRadius: '50%', border: '2px solid var(--surface3)', borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite' }} />
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '60px 20px', gap: 12 }}>
            <Bell size={40} style={{ color: 'var(--text-muted)' }} />
            <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-dim)' }}>No notifications here</p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>Play games, follow players, and level up to earn notifications.</p>
          </div>
        ) : (
          filtered.map(n => {
            const color = TYPE_COLOR[n.type] ?? '#888899'
            const iconKey = n.icon && n.icon !== 'bell' ? n.icon : (TYPE_ICON[n.type] ?? 'bell')
            const label = TYPE_LABEL[n.type] ?? n.type
            const target = getNotificationRoute(n.type, n.meta)
            return (
              <div key={n.id}
                onClick={() => { if (target) navigate(target) }}
                style={{ display: 'flex', gap: 12, padding: '14px 16px', background: !n.read ? `${color}08` : 'var(--surface)', border: !n.read ? `1px solid ${color}22` : '1px solid rgba(255,255,255,0.04)', borderRadius: 16, boxShadow: 'var(--elev-raise-sm)', transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out), opacity var(--dur-fast) var(--ease-out)', position: 'relative', cursor: target ? 'pointer' : 'default' }}>

                {/* Icon */}
                <div style={{ width: 42, height: 42, borderRadius: 13, background: `${color}18`, border: `1px solid ${color}33`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color }}>
                  <NotifIcon iconKey={iconKey} size={18} />
                </div>

                {/* Content */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                    <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{n.title}</span>
                    <span style={{ fontSize: 9, fontWeight: 700, padding: '2px 6px', borderRadius: 6, background: `${color}20`, color, textTransform: 'uppercase', letterSpacing: '0.04em', flexShrink: 0 }}>{label}</span>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.4, marginBottom: 4 }}>{n.body}</div>
                  <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{timeAgo(n.created_at)}</div>
                  {n.type === 'follow' && userId && typeof n.meta.follower_id === 'string' && (
                    <FollowBackButton myId={userId} followerId={n.meta.follower_id} />
                  )}
                  {n.type === 'halo' && userId && n.meta.source === 'random_surprise'
                    && typeof n.meta.reward_type === 'string' && typeof n.meta.reward_amount === 'number' && (
                    <ShareSurpriseButton
                      userId={userId}
                      rewardType={n.meta.reward_type}
                      rewardAmount={n.meta.reward_amount}
                      createdAt={n.created_at}
                    />
                  )}
                </div>

                {/* Unread dot */}
                {!n.read && (
                  <div style={{ width: 7, height: 7, borderRadius: '50%', background: color, flexShrink: 0, alignSelf: 'center' }} />
                )}

                {/* Delete */}
                <button type="button" onClick={(e) => { e.stopPropagation(); deleteOne(n.id) }}
                  style={{ position: 'absolute', top: 10, right: 10, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', opacity: 0.5, padding: 4 }}
                  onMouseEnter={e => { e.currentTarget.style.opacity = '1'; e.currentTarget.style.color = '#ff6b6b' }}
                  onMouseLeave={e => { e.currentTarget.style.opacity = '0.5'; e.currentTarget.style.color = 'var(--text-muted)' }}>
                  <Trash2 size={12} />
                </button>
              </div>
            )
          })
        )}
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
