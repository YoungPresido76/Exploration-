// src/features/notifications/notificationRoutes.ts
//
// Single source of truth for "where does tapping this notification go".
// Used by both the Notifications page and the in-app toast so the two
// stay consistent. `meta` shapes here match whatever each notify*()
// helper (achievements.ts / posts.ts / highlights.ts / haloMoments.ts /
// liveNotifications.ts) actually writes into notifications.meta.
//
// Returns null when there's nowhere sensible to send the user (unknown
// type, or a known type missing the id it needs) — callers should just
// no-op the tap in that case rather than navigating somewhere wrong.

type Meta = Record<string, unknown> | null | undefined

function str(v: unknown): string | null {
  return typeof v === 'string' && v.length > 0 ? v : null
}

export function getNotificationRoute(type: string, meta: Meta): string | null {
  const m = meta ?? {}

  switch (type) {
    // ── Social — take you to the other person's profile ──────────
    case 'follow':       return str(m.follower_id) && `/profile/${str(m.follower_id)}`
    case 'profile_view': return str(m.viewer_id)   && `/profile/${str(m.viewer_id)}`
    case 'profile_like': return str(m.liker_id)     && `/profile/${str(m.liker_id)}`
    case 'followed_rank_up': return str(m.user_id) ? `/profile/${str(m.user_id)}` : '/ranks'
    case 'streak':           return str(m.user_id) ? `/profile/${str(m.user_id)}` : '/streak'

    // ── Your own progress ──────────────────────────────────────
    case 'rank_up':         return '/ranks'
    case 'achievement':     return '/achievements'
    case 'artifact':        return '/artifacts'
    case 'level_up':        return '/dashboard'
    case 'streak_warning':  return '/streak'
    case 'come_back':       return '/dashboard'
    case 'version_coming_soon': return '/version'
    case 'verification_result': return '/verification'
    case 'halo_coming_soon':    return '/halo'

    // ── Content ────────────────────────────────────────────────
    case 'highlight_posted': return '/feed/highlights'
    case 'new_post':
    case 'post_tag':
    case 'post_like':
    case 'post_comment':
    case 'post_repost':
    case 'post_poll_vote':   return str(m.post_id) ? `/feed/${str(m.post_id)}` : '/feed'

    // These two carry a comment_id, which opens the post AND drops
    // straight into that comment inside the sheet — see SinglePostPage's
    // `comment` query param.
    case 'comment_reply':
    case 'comment_like': {
      const postId = str(m.post_id)
      if (!postId) return '/feed'
      const commentId = str(m.comment_id)
      return commentId ? `/feed/${postId}?comment=${commentId}` : `/feed/${postId}`
    }

    // ── Messaging ──────────────────────────────────────────────
    case 'message':
    case 'missed_call':
    case 'rank_tag':          return '/chat?tab=chats'

    // Deep-links straight to the tagged message — Chat.tsx reads `room`/`msg`
    // off the query string, opens that room, and scrolls to + highlights the
    // message. Falls back to just opening the room if the message itself has
    // since fallen out of Global Chat's 100-message cap (or was deleted).
    case 'mention': {
      const roomId = str(m.room_id)
      const msgId = str(m.message_id)
      if (!roomId) return '/chat?tab=chats'
      return msgId ? `/chat?tab=chats&room=${roomId}&msg=${msgId}` : `/chat?tab=chats&room=${roomId}`
    }

    // ── Clubs ──────────────────────────────────────────────────
    // A club invite can't deep-link into the club — you're not a member
    // yet, and chat_rooms is gated on is_room_member(), so the room would
    // 404 for the very person being invited. The Clubs tab is where the
    // invites banner lives; ClubInvitesSheet reads the invite itself.
    case 'club_invite': return '/chat?tab=clubs'

    // A pending DM request opens the chat list. Not the room directly:
    // the accept/decline bar is what the person needs to see, and the
    // list is where the Request pill explains why it looks different.
    case 'dm_request': {
      const roomId = str(m.room_id)
      return roomId ? `/chat?tab=chats&room=${roomId}` : '/chat?tab=chats'
    }

    // Pending invites can't open the room yet (not a member) — send them
    // to the Clubs tab, where the "waiting list" banner already shows.
    case 'club_invite_pending': return '/chat?tab=clubs'
    case 'club_added':
    case 'club_invite_accepted': return str(m.room_id) ? `/clubs/${str(m.room_id)}` : '/chat?tab=clubs'

    // ── Live / system ──────────────────────────────────────────
    case 'session_reset':         return '/games'
    case 'movies_open':           return '/watch'
    case 'exploration_complete':  return '/exploration'
    case 'halo':                  return '/halo'

    // ── Mall (forward-compatible for when a mall-drop notifier ships) ──
    case 'mall_item':
    case 'mall_drop':             return '/mall'

    // ── PvP ───────────────────────────────────────────────────────
    case 'most_wanted_update':    return '/most-wanted'
    // Straight to whoever hit you — from their profile the Battle tab is
    // one tap away, which is the whole point of telling you.
    case 'pvp_attacked':          return str(m.attacker_id) ? `/profile/${str(m.attacker_id)}` : '/most-wanted'
    // Your own profile, because that's where the marker they just earned
    // is shown — sending them to the board would show them everyone else.
    case 'pvp_first_blood':       return str(m.user_id) ? `/profile/${str(m.user_id)}` : '/most-wanted'
    // Arena keeps one route; the board is picked by ?tab=.
    case 'pvp_elimination':       return '/most-wanted?tab=elimination'
    // A cheer belongs next to the round it was sent about.
    case 'pvp_cheer':             return '/most-wanted?tab=elimination'
    // Contracts live on the Most Wanted tab, which is Arena's default.
    case 'pvp_bounty':            return '/most-wanted'
    case 'pvp_boss':              return '/kill-board'
    // The shatter is the second half of an attack, so it lands where an
    // attack lands: on whoever cast it. Both sides of a shatter carry
    // attacker_id, so the caster's own copy routes to their own profile —
    // which is right, because that's where their Battle panel is.
    case 'pvp_shatter':           return str(m.attacker_id) ? `/profile/${str(m.attacker_id)}` : '/most-wanted'
    // Straight to whoever picked you up.
    case 'pvp_revive':            return str(m.giver_id) ? `/profile/${str(m.giver_id)}` : '/most-wanted'
    // Route stays /skill-tree — the dock, You, Dashboard and the Inventory
    // menu all point at it, same reason /most-wanted survived becoming Arena.
    case 'card_mastery':          return '/skill-tree'
    case 'admin_request':         return '/admin'
    case 'item_revoked':          return '/inventory'

    // ── Championship ─────────────────────────────────────────────
    // Live now — send them straight to the fight.
    case 'championship_match_live':   return '/championship/my-match'
    // Advanced, but the next round may not have started yet — Overview
    // shows the current state either way rather than guessing.
    case 'championship_round_result': return '/championship'
    case 'championship_eliminated':   return '/championship'
    // Broadcast to everyone still alive in the bracket — the bracket is
    // what changed, so that's where the tap should land, not "my match"
    // (which may not exist yet for whoever's watching this go out).
    case 'championship_bracket_advanced': return '/championship/bracket'
    // Both about "my upcoming match" — same destination as match_live,
    // since ChampionshipMatchSheet already handles the pending/scheduled
    // state and shows the kickoff time itself.
    case 'championship_kickoff_announced':
    case 'championship_kickoff_reminder':  return '/championship/my-match'

    default: return null
  }
}
