// src/features/notifications/useAdminAnnouncement.ts
//
// Pops the most recent active admin announcement (Ops console -> Popup
// announcement) as a PromoOverlay. Two kinds, with different cadences and
// different priority (migration 0130):
//
//   • 'whats_new' — a release note. Shown ONCE per user, ever, per
//     announcement id. Outranks everything else, so a fresh drop is never
//     buried under a daily popup that's already running.
//   • 'daily' — the original behaviour: once per calendar day per user,
//     for as long as it stays active (until an admin deletes it, or it
//     auto-expires at whatever duration the admin set).
//
// Both reset/track per-device in localStorage. The seen-key for daily
// stores the calendar day; for what's-new it just stores a marker, since
// "seen once" is the whole rule.
import { useEffect, useState } from 'react'
import { fetchAnnouncements } from '../admin/adminOps'
import type { PromoNotification } from './PromoOverlay'

const SEEN_KEY_PREFIX = 'cv_announcement_seen_'

function todayKey(): string {
  return new Date().toDateString()
}

function seenKey(userId: string, announcementId: string): string {
  return `${SEEN_KEY_PREFIX}${userId}_${announcementId}`
}

function markSeen(userId: string, announcementId: string, kind: 'daily' | 'whats_new') {
  localStorage.setItem(seenKey(userId, announcementId), kind === 'whats_new' ? 'seen' : todayKey())
}

export function useAdminAnnouncement(userId: string | null) {
  // Kept as two separate slots rather than one "winner", so AppLayout can
  // slot the referral advert between them in its own priority order.
  const [whatsNew, setWhatsNew] = useState<PromoNotification | null>(null)
  const [daily, setDaily] = useState<PromoNotification | null>(null)

  useEffect(() => {
    if (!userId) return
    const uid: string = userId
    let cancelled = false

    async function check() {
      const { data } = await fetchAnnouncements()
      if (cancelled || data.length === 0) return

      // fetchAnnouncements is already newest-first, so the first match of
      // each kind is the most recent live one of that kind.
      const latestWhatsNew = data.find(a => a.kind === 'whats_new')
      const latestDaily = data.find(a => a.kind !== 'whats_new')

      if (latestWhatsNew && !localStorage.getItem(seenKey(uid, latestWhatsNew.id))) {
        setWhatsNew({
          id: latestWhatsNew.id,
          imageUrl: latestWhatsNew.image_url ?? undefined,
          title: latestWhatsNew.title,
          bodyBefore: latestWhatsNew.body,
          bodyHighlight: '',
          bodyAfter: '',
          badgeText: "WHAT'S NEW",
          ctaLabel: 'Nice',
          dismissLabel: 'Close',
          socialFollow: true,
        })
      }

      if (latestDaily && localStorage.getItem(seenKey(uid, latestDaily.id)) !== todayKey()) {
        setDaily({
          id: latestDaily.id,
          imageUrl: latestDaily.image_url ?? undefined,
          title: latestDaily.title,
          bodyBefore: latestDaily.body,
          bodyHighlight: '',
          bodyAfter: '',
          badgeText: 'ANNOUNCEMENT',
          ctaLabel: 'Got it',
          dismissLabel: 'Dismiss',
        })
      }
    }

    check()
    const t = setInterval(check, 15 * 60_000) // re-check every 15 min so a new announcement or a fresh day is picked up mid-session
    return () => { cancelled = true; clearInterval(t) }
  }, [userId])

  function dismissWhatsNew() {
    if (whatsNew && userId) markSeen(userId, whatsNew.id, 'whats_new')
    setWhatsNew(null)
  }

  function dismissDaily() {
    if (daily && userId) markSeen(userId, daily.id, 'daily')
    setDaily(null)
  }

  return { whatsNew, daily, dismissWhatsNew, dismissDaily }
}
