// src/components/NotificationBell.tsx
import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Bell } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { getUnreadCount } from '../achievements/achievements'
import { useBadgeSeen } from '../../shared/lib/badgeBus'

export default function NotificationBell() {
  const { session } = useAuth()
  const userId = session?.user?.id ?? null
  const navigate = useNavigate()

  const [unread, setUnread] = useState(0)

  const refresh = useCallback(() => {
    if (!userId) { setUnread(0); return }
    getUnreadCount(userId).then(setUnread)
  }, [userId])

  useEffect(() => { refresh() }, [refresh])

  useBadgeSeen('notifications', () => setUnread(0))

  useEffect(() => {
    if (!userId) return
    const sub = supabase
      .channel(`notif:${userId}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'notifications',
        filter: `user_id=eq.${userId}`
      }, () => {
        setUnread(c => c + 1)
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'notifications',
        filter: `user_id=eq.${userId}`
      }, refresh)
      .subscribe()
    return () => { supabase.removeChannel(sub) }
  }, [userId, refresh])

  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') refresh() }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [refresh])

  /* ── Badging API: mirror unread count on the app icon ── */
  useEffect(() => {
    if (unread > 0) {
      navigator.setAppBadge?.(unread)?.catch(() => {})
    } else {
      navigator.clearAppBadge?.()?.catch(() => {})
    }
  }, [unread])

  const handleClick = () => {
    navigator.clearAppBadge?.()?.catch(() => {})
    navigate('/notifications')
  }

  return (
    <button type="button" onClick={handleClick} title="Notifications"
      aria-label={unread > 0 ? `Notifications, ${unread} unread` : 'Notifications'}
      style={{ width: 38, height: 38, borderRadius: 11, background: 'var(--surface)', boxShadow: 'var(--elev-raise-sm)', border: '1px solid var(--border)', color: 'var(--text-dim)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
      <Bell size={16} />
      {unread > 0 && (
        <span
          key={unread}
          className="cv-count-badge"
          style={{ position: 'absolute', top: -4, right: -4 }}
        >
          {unread > 9 ? '9+' : unread}
        </span>
      )}
    </button>
  )
}
