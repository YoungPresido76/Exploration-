// src/features/chat/dmRequests.ts
//
// A first-time DM arrives as a request. The recipient sees the one
// message the sender was allowed to write, then picks accept, decline or
// block before a conversation exists.
//
// State lives on chat_rooms (dm_initiator_id + dm_accepted_at) because a
// DM room already has exactly two members — a separate table would carry
// nothing extra. See migration 0175b.
//
// The one-message cap and the recipient's silence are enforced by a
// BEFORE INSERT trigger on messages, not here: hiding the composer stops
// the UI, it doesn't stop a direct insert.
import { supabase } from '../../shared/lib/supabase'

/** What this viewer is looking at when a DM room is pending.
 *  'none' covers both an accepted room and a non-DM one. */
export type DmRequestState = 'none' | 'incoming' | 'outgoing'

export interface DmRequestInfo {
  state: DmRequestState
  initiatorId: string | null
}

/** Reads request state off a chat_rooms row the caller already has.
 *  Kept as a pure function so the room list can label every row without
 *  a request-per-room round trip. */
export function dmRequestStateOf(
  room: { type?: string | null; dm_initiator_id?: string | null; dm_accepted_at?: string | null },
  myId: string | null,
): DmRequestState {
  if (room.type !== 'dm') return 'none'
  if (room.dm_accepted_at) return 'none'
  if (!room.dm_initiator_id || !myId) return 'none'
  return room.dm_initiator_id === myId ? 'outgoing' : 'incoming'
}

/** Fallback read for a room opened directly (deep link, notification tap)
 *  before the list has loaded it. */
export async function fetchDmRequestInfo(roomId: string, myId: string): Promise<DmRequestInfo> {
  const { data, error } = await supabase
    .from('chat_rooms')
    .select('type, dm_initiator_id, dm_accepted_at')
    .eq('id', roomId)
    .maybeSingle()
  if (error || !data) return { state: 'none', initiatorId: null }
  return {
    state: dmRequestStateOf(data as any, myId),
    initiatorId: (data as any).dm_initiator_id ?? null,
  }
}

export async function acceptDmRequest(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('dm_accept_request', { p_room_id: roomId })
  if (error) throw friendlyDmError(error.message)
}

/** Declining deletes the room, its members and its messages for BOTH
 *  sides — the sender's copy vanishes too. Passing block also writes the
 *  blocks row. Either way a dm_declines row stops a fresh request for a
 *  week, since the room itself is gone and can't carry that fact. */
export async function declineDmRequest(roomId: string, block = false): Promise<void> {
  const { error } = await supabase.rpc('dm_decline_request', { p_room_id: roomId, p_block: block })
  if (error) throw friendlyDmError(error.message)
}

const DM_ERRORS: Record<string, string> = {
  CV_DM_REQUEST_PENDING:        "You can't reply until they accept",
  CV_DM_REQUEST_AWAITING_REPLY: 'Wait for them to accept before sending another',
  CV_DM_DECLINED_RECENTLY:      "You can't message this person right now",
  CV_NOT_YOUR_REQUEST:          'That request isn\'t yours to answer',
  CV_ALREADY_ACCEPTED:          'This chat is already open',
}

export function friendlyDmError(message: string): Error {
  for (const [code, text] of Object.entries(DM_ERRORS)) {
    if (message.includes(code)) return new Error(text)
  }
  return new Error(message)
}

/** True when the message the composer just tried to send was refused by
 *  the request guard rather than failing for an ordinary reason — the
 *  caller uses this to swap in the "waiting on them" banner instead of
 *  showing a generic send error. */
export function isDmRequestRejection(message: string): boolean {
  return message.includes('CV_DM_REQUEST_PENDING')
      || message.includes('CV_DM_REQUEST_AWAITING_REPLY')
}
