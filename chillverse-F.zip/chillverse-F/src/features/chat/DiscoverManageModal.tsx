// src/features/chat/DiscoverManageModal.tsx
// The single obvious place staff go to manage Discover, instead of relying
// only on the long-press context menu inside Global Chat (which still
// works too — this is an additional, more discoverable path to the same
// actions). Opened from the gear icon next to the "Discover" header.

import { useEffect, useState } from 'react'
import { X, Flame, PieChart, Sparkles, Trash2, MessageSquare, Plus } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import QotdManageModal from './QotdManageModal'
import PollComposerModal from './PollComposerModal'

interface TrendMessageItem { id: string; kind: 'global_message'; message_id: string; content: string; sender_name: string | null; reaction_count: number }
interface TrendQotdItem { id: string; kind: 'qotd'; qotd_daily_id: string; question: string; reply_count: number; participant_count: number }
type TrendItem = TrendMessageItem | TrendQotdItem

interface RecentMessage { id: string; content: string; sender_name: string | null; created_at: string }
interface RecentPoll { poll_id: string; question: string; created_at: string; total_votes: number }

type Tab = 'trending' | 'poll' | 'bank'

export default function DiscoverManageModal({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('trending')
  const [trends, setTrends] = useState<TrendItem[] | null>(null)
  const [recentMsgs, setRecentMsgs] = useState<RecentMessage[] | null>(null)
  const [recentPolls, setRecentPolls] = useState<RecentPoll[] | null>(null)
  const [featuredPollId, setFeaturedPollId] = useState<string | null>(null)
  const [globalRoomId, setGlobalRoomId] = useState<string | null>(null)
  // 'main' | 'bank' | 'poll-composer' — mutually exclusive, swapped in
  // instead of stacked on top, so there's never a second full-screen
  // overlay/backdrop mounted underneath this one (both QotdManageModal and
  // PollComposerModal are their own fixed-position sheets at the same
  // z-index as this one; layering them would double the dim backdrop and,
  // for the composer specifically, put it visually behind this modal).
  const [view, setView] = useState<'main' | 'bank' | 'poll-composer'>('main')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function loadTrending() {
    supabase.rpc('trending_list').then(({ data }) => setTrends((data as TrendItem[]) || []))
  }
  function loadPollTab() {
    supabase.rpc('featured_poll_get').then(({ data }) => setFeaturedPollId((data as { poll_id: string } | null)?.poll_id ?? null))
    supabase.rpc('recent_global_polls', { p_limit: 15 }).then(({ data }) => setRecentPolls((data as RecentPoll[]) || []))
  }
  function loadRecentMessages() {
    supabase
      .from('chat_rooms').select('id').eq('type', 'global').maybeSingle()
      .then(async ({ data: room }) => {
        if (!room) { setRecentMsgs([]); return }
        setGlobalRoomId(room.id)
        const { data: msgs } = await supabase
          .from('messages')
          .select('id, content, created_at, sender_id')
          .eq('room_id', room.id).eq('type', 'text').eq('deleted', false)
          .order('created_at', { ascending: false }).limit(20)
        if (!msgs) { setRecentMsgs([]); return }
        const senderIds = [...new Set(msgs.map(m => m.sender_id))]
        const { data: profiles } = await supabase.from('profiles').select('id, display_name, username').in('id', senderIds)
        const nameById = new Map((profiles || []).map(p => [p.id, p.display_name || p.username]))
        setRecentMsgs(msgs.map(m => ({ id: m.id, content: m.content, created_at: m.created_at, sender_name: nameById.get(m.sender_id) || null })))
      })
  }

  useEffect(() => {
    loadTrending()
    loadPollTab()
    loadRecentMessages()
  }, [])

  async function removeTrend(id: string) {
    setBusy(true)
    await supabase.rpc('trend_remove', { p_id: id })
    setBusy(false)
    loadTrending()
  }

  async function addMessageTrend(messageId: string) {
    setBusy(true)
    setError(null)
    const { error: err } = await supabase.rpc('trend_add_message', { p_message_id: messageId })
    setBusy(false)
    if (err) {
      setError(err.message?.includes('trend_limit_reached') ? 'Trending is full (max 3) — remove one first.' : err.message?.includes('already_trending') ? 'That message is already trending.' : 'Could not add.')
      return
    }
    loadTrending()
  }

  async function addQotdTrend() {
    setBusy(true)
    setError(null)
    const { error: err } = await supabase.rpc('trend_add_qotd')
    setBusy(false)
    if (err) {
      setError(err.message?.includes('trend_limit_reached') ? 'Trending is full (max 3) — remove one first.' : err.message?.includes('already_trending') ? "Today's question is already trending." : 'Could not add.')
      return
    }
    loadTrending()
  }

  async function setFeaturedPoll(pollId: string | null) {
    setBusy(true)
    setError(null)
    const { error: err } = pollId
      ? await supabase.rpc('feature_poll', { p_poll_id: pollId })
      : await supabase.rpc('unfeature_poll')
    setBusy(false)
    if (err) { setError('Could not update Quick Poll.'); return }
    loadPollTab()
  }

  const hasQotdTrend = (trends || []).some(t => t.kind === 'qotd')
  const trendCount = trends?.length ?? 0

  if (view === 'bank') {
    return <QotdManageModal onClose={() => setView('main')} />
  }

  if (view === 'poll-composer') {
    return (
      <PollComposerModal
        open={true}
        onClose={() => setView('main')}
        roomId={globalRoomId || ''}
        maxDurationHours={168}
        onCreated={() => { loadPollTab() }}
      />
    )
  }

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)' }} />
      <div style={{ position: 'relative', width: '100%', maxWidth: 480, maxHeight: '86vh', background: 'var(--surface2)', borderRadius: '22px 22px 0 0', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <div>
            <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)' }}>Manage Discover</p>
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2 }}>Staff, Moderator & Admin</p>
          </div>
          <button onClick={onClose} style={{ width: 30, height: 30, borderRadius: 9, background: 'var(--surface)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={15} />
          </button>
        </div>

        <div style={{ display: 'flex', gap: 6, padding: '12px 18px', flexShrink: 0, borderBottom: '1px solid var(--border)' }}>
          {[
            { id: 'trending' as Tab, label: `Trending (${trendCount}/3)`, icon: <Flame size={13} /> },
            { id: 'poll' as Tab, label: 'Quick Poll', icon: <PieChart size={13} /> },
            { id: 'bank' as Tab, label: 'Question Bank', icon: <Sparkles size={13} /> },
          ].map(t => (
            <button key={t.id} onClick={() => t.id === 'bank' ? setView('bank') : setTab(t.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 18, border: 'none',
                background: tab === t.id ? 'var(--accent)' : 'var(--surface)', color: tab === t.id ? '#fff' : 'var(--text-muted)',
                fontSize: 11.5, fontWeight: 700, cursor: 'pointer', flexShrink: 0,
              }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {error && <div style={{ margin: '10px 18px 0', padding: '7px 12px', borderRadius: 10, background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.25)', fontSize: 12, color: '#ff6b6b' }}>{error}</div>}

        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 18px 20px' }}>

          {tab === 'trending' && (
            <>
              <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Currently trending</p>
              {trends === null ? (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)', padding: '10px 0' }}>Loading…</p>
              ) : trends.length === 0 ? (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)', padding: '10px 0' }}>Nothing trending yet.</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 18 }}>
                  {trends.map(t => (
                    <div key={t.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 12, background: 'var(--surface)' }}>
                      <p style={{ flex: 1, fontSize: 12.5, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {t.kind === 'qotd' ? `📌 ${t.question}` : t.content}
                      </p>
                      <button onClick={() => removeTrend(t.id)} disabled={busy}
                        style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--surface2)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ff6b6b', cursor: 'pointer', flexShrink: 0 }}>
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {!hasQotdTrend && (
                <button onClick={addQotdTrend} disabled={busy || trendCount >= 3}
                  style={{ width: '100%', marginBottom: 14, padding: '9px 12px', borderRadius: 12, border: '1px dashed var(--accent)', background: 'transparent', color: 'var(--accent)', fontSize: 12, fontWeight: 700, cursor: 'pointer', opacity: trendCount >= 3 ? 0.5 : 1 }}>
                  + Add today's Question of the Day
                </button>
              )}

              <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Recent Global Chat messages</p>
              {recentMsgs === null ? (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Loading…</p>
              ) : recentMsgs.length === 0 ? (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>No recent messages.</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {recentMsgs.map(m => {
                    const already = trends?.some(t => t.kind === 'global_message' && t.message_id === m.id)
                    return (
                      <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 12, background: 'var(--surface)' }}>
                        <MessageSquare size={13} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.content}</p>
                          {m.sender_name && <p style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 1 }}>{m.sender_name}</p>}
                        </div>
                        <button onClick={() => addMessageTrend(m.id)} disabled={busy || already || trendCount >= 3}
                          style={{
                            padding: '5px 11px', borderRadius: 14, border: 'none', fontSize: 10.5, fontWeight: 700, flexShrink: 0,
                            background: already ? 'var(--surface2)' : 'var(--accent)', color: already ? 'var(--text-muted)' : '#fff',
                            cursor: already || trendCount >= 3 ? 'default' : 'pointer', opacity: trendCount >= 3 && !already ? 0.5 : 1,
                          }}>
                          {already ? 'Added' : 'Add'}
                        </button>
                      </div>
                    )
                  })}
                </div>
              )}
            </>
          )}

          {tab === 'poll' && (
            <>
              <button
                onClick={() => setView('poll-composer')}
                disabled={!globalRoomId}
                style={{
                  width: '100%', marginBottom: 16, padding: '11px 12px', borderRadius: 12, border: 'none',
                  background: 'linear-gradient(135deg,var(--accent),var(--accent2))', color: '#fff',
                  fontSize: 12.5, fontWeight: 700, cursor: globalRoomId ? 'pointer' : 'default',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  opacity: globalRoomId ? 1 : 0.6,
                }}
              >
                <Plus size={14} /> Create a new poll
              </button>

              <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Featured poll</p>
              {featuredPollId ? (
                <button onClick={() => setFeaturedPoll(null)} disabled={busy}
                  style={{ width: '100%', marginBottom: 18, padding: '9px 12px', borderRadius: 12, border: 'none', background: 'var(--surface)', color: '#ff6b6b', fontSize: 12, fontWeight: 700, cursor: 'pointer', textAlign: 'left' }}>
                  Clear current Quick Poll
                </button>
              ) : (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 18 }}>No poll is featured right now.</p>
              )}

              <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Recent polls in Global Chat</p>
              {recentPolls === null ? (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Loading…</p>
              ) : recentPolls.length === 0 ? (
                <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>No polls posted in Global Chat yet — post one, then come back here to feature it.</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {recentPolls.map(p => (
                    <div key={p.poll_id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 12, background: 'var(--surface)' }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.question}</p>
                        <p style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 1 }}>{p.total_votes} votes</p>
                      </div>
                      <button onClick={() => setFeaturedPoll(p.poll_id)} disabled={busy || featuredPollId === p.poll_id}
                        style={{
                          padding: '5px 11px', borderRadius: 14, border: 'none', fontSize: 10.5, fontWeight: 700, flexShrink: 0,
                          background: featuredPollId === p.poll_id ? 'var(--surface2)' : 'var(--accent)', color: featuredPollId === p.poll_id ? 'var(--text-muted)' : '#fff',
                          cursor: featuredPollId === p.poll_id ? 'default' : 'pointer',
                        }}>
                        {featuredPollId === p.poll_id ? 'Featured' : 'Feature'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
