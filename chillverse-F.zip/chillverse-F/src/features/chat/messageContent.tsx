// src/features/chat/messageContent.tsx
// One renderer for chat message text, shared by Global Chat / DMs (Chat.tsx)
// and Clubs (MessageBubble.tsx) so a link looks the same everywhere.
//
// Three things happen to a message body here:
//   • @username tokens matching an actual room member render in accent colour
//     (this is the behaviour that used to live in Chat.tsx's renderWithMentions)
//   • links render blue + underlined and open in a new tab, instead of sitting
//     there as plain unclickable text
//   • **bold** / *italic* markers (the same subset composers advertise, e.g.
//     the admin broadcast composer's placeholder text) render as real
//     <strong>/<em>, instead of printing the literal asterisks
//
// The link detection deliberately mirrors extract_link_hosts() in migration
// 0119. That trigger is the actual enforcement — this file only decides what
// gets painted blue and lets the composer warn before a send that the server
// would strip anyway. Keep the TLD list here and the one in SQL in step.

import { useState } from 'react'
import type { ReactNode } from 'react'

/** The only host members are allowed to link to. Staff can link anywhere. */
export const CHILLVERSE_HOST = 'chillverse.com.ng'

const TLDS = [
  'com', 'net', 'org', 'io', 'ng', 'gg', 'xyz', 'app', 'co', 'me', 'tv', 'link',
  'site', 'online', 'shop', 'info', 'biz', 'ru', 'cn', 'to', 'ly', 'dev', 'ai',
  'store', 'live', 'club', 'top', 'vip', 'win', 'bet', 'cc', 'pw', 'su', 'tk',
  'ml', 'ga', 'cf', 'uk', 'us', 'ca', 'de', 'fr', 'es', 'it', 'nl', 'br', 'in', 'za',
].join('|')

const MARKDOWN_LINK = String.raw`\[[^\]\n]+\]\([^)\s]+\)`
const SCHEME_URL = String.raw`https?:\/\/[^\s<>()]+`
const WWW_URL = String.raw`www\.[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s<>()]*)?`
const BARE_URL = String.raw`[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9-]+)*\.(?:${TLDS})(?:\/[^\s<>()]*)?`
const BOLD = String.raw`\*\*[^\n*]+?\*\*`
const ITALIC = String.raw`\*[^\n*]+?\*`
const SPOILER = String.raw`\|\|[^\n|]+?\|\|`

/** Splitter token — order matters: markdown links before raw URLs, scheme'd
 *  URLs before bare ones (so `https://x.com` isn't chopped at the scheme),
 *  and bold before italic (so `**x**` isn't read as italic-italic).
 *  Spoilers lead, so `||chillverse.com.ng||` stays a single covered blob
 *  rather than being eaten by the bare-URL branch first. */
const LINK_TOKEN = new RegExp(`(${SPOILER}|${MARKDOWN_LINK}|${SCHEME_URL}|${WWW_URL}|${BARE_URL}|${BOLD}|${ITALIC})`, 'g')

/** A bare `word.com` inside an email address is not a link — this catches the
 *  `@` immediately before a match so `bob@gmail.com` stays plain text. */
function isEmailTail(full: string, index: number): boolean {
  return index > 0 && full[index - 1] === '@'
}

/** Trailing sentence punctuation shouldn't get swallowed into the href. */
function trimTrailingPunctuation(url: string): { url: string; trailing: string } {
  const match = /[.,!?;:]+$/.exec(url)
  if (!match) return { url, trailing: '' }
  return { url: url.slice(0, -match[0].length), trailing: match[0] }
}

function hostOf(url: string): string | null {
  try {
    const withScheme = /^https?:\/\//i.test(url) ? url : `https://${url}`
    return new URL(withScheme).hostname.toLowerCase()
  } catch {
    return null
  }
}

export function isChillverseHost(host: string | null): boolean {
  if (!host) return false
  const h = host.toLowerCase().replace(/^www\./, '')
  return h === CHILLVERSE_HOST || h.endsWith(`.${CHILLVERSE_HOST}`)
}

/** The first host in `content` that members aren't allowed to link to, or null
 *  when the text is clean. Used by the composer to warn up front rather than
 *  letting the server silently redact the message. */
export function firstExternalHost(content: string): string | null {
  LINK_TOKEN.lastIndex = 0
  let match: RegExpExecArray | null
  while ((match = LINK_TOKEN.exec(content)) !== null) {
    const raw = match[0]
    if (/^\*/.test(raw)) continue // bold/italic token, not a link
    if (isEmailTail(content, match.index)) continue
    const markdown = /^\[[^\]]+\]\(([^)\s]+)\)$/.exec(raw)
    const target = markdown ? markdown[1] : trimTrailingPunctuation(raw).url
    const host = hostOf(target)
    if (host && !isChillverseHost(host)) return host
  }
  return null
}

const LINK_STYLE: React.CSSProperties = {
  color: '#4f8ef7',
  textDecoration: 'underline',
  wordBreak: 'break-all',
}

function Anchor({ href, label, keyName }: { href: string; label: string; keyName: string }) {
  return (
    <a
      key={keyName}
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      onClick={e => e.stopPropagation()}
      style={LINK_STYLE}
    >
      {label}
    </a>
  )
}

export interface MentionMember {
  user_id: string
  profile: { username: string }
}

/** Splits a non-link run on @username tokens that match a real room member. */
function renderMentions(text: string, usernames: Set<string>, keyPrefix: string): ReactNode {
  if (usernames.size === 0 || !text.includes('@')) return text
  const parts = text.split(/(@[a-zA-Z0-9_]{2,32})/g)
  if (parts.length === 1) return text
  return parts.map((part, i) =>
    part.startsWith('@') && usernames.has(part.slice(1).toLowerCase())
      ? <span key={`${keyPrefix}-m${i}`} style={{ color: 'var(--accent)', fontWeight: 700 }}>{part}</span>
      : part
  )
}

/** `||covered||` — a solid block until tapped, then plain text for good.
 *  Local state only: re-collapsing on rerender would re-hide something the
 *  reader is mid-way through, and nothing needs to survive a reload. */
function Spoiler({ text }: { text: ReactNode }) {
  const [revealed, setRevealed] = useState(false)
  return (
    <span
      role="button"
      tabIndex={revealed ? -1 : 0}
      aria-label={revealed ? undefined : 'Hidden text, activate to reveal'}
      onClick={e => { if (!revealed) { e.stopPropagation(); setRevealed(true) } }}
      onKeyDown={e => { if (!revealed && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); setRevealed(true) } }}
      style={{
        borderRadius: 4,
        padding: revealed ? 0 : '0 3px',
        background: revealed ? 'transparent' : 'var(--surface2)',
        color: revealed ? 'inherit' : 'transparent',
        cursor: revealed ? 'inherit' : 'pointer',
        // Keeps the covered text unselectable/uncopyable while hidden, so a
        // long-press-to-copy doesn't leak what the block is covering.
        userSelect: revealed ? 'text' : 'none',
        transition: 'background 120ms ease, color 120ms ease',
      }}
    >
      {text}
    </span>
  )
}

/** Message body as React nodes: member @mentions in accent colour, links in
 *  blue. `members` may be empty — links still render. */
export function renderMessageContent(content: string, members: MentionMember[] = []): ReactNode {
  const usernames = new Set(members.map(mb => mb.profile.username.toLowerCase()))
  const out: ReactNode[] = []
  let cursor = 0
  let i = 0

  LINK_TOKEN.lastIndex = 0
  let match: RegExpExecArray | null
  while ((match = LINK_TOKEN.exec(content)) !== null) {
    const raw = match[0]

    if (/^\|\|/.test(raw)) {
      if (match.index > cursor) {
        out.push(renderMentions(content.slice(cursor, match.index), usernames, `t${i}`))
      }
      out.push(<Spoiler key={`s${i}`} text={renderMentions(raw.slice(2, -2), usernames, `s${i}`)} />)
      cursor = match.index + raw.length
      i += 1
      continue
    }

    if (/^\*/.test(raw)) {
      // Bold/italic token — not a link, so email-tail skipping doesn't apply.
      if (match.index > cursor) {
        out.push(renderMentions(content.slice(cursor, match.index), usernames, `t${i}`))
      }
      const boldMatch = /^\*\*([^\n*]+)\*\*$/.exec(raw)
      if (boldMatch) {
        out.push(<strong key={`b${i}`}>{renderMentions(boldMatch[1], usernames, `b${i}`)}</strong>)
      } else {
        const italicMatch = /^\*([^\n*]+)\*$/.exec(raw)
        out.push(<em key={`e${i}`}>{renderMentions(italicMatch ? italicMatch[1] : raw, usernames, `e${i}`)}</em>)
      }
      cursor = match.index + raw.length
      i += 1
      continue
    }

    if (isEmailTail(content, match.index)) continue

    if (match.index > cursor) {
      out.push(renderMentions(content.slice(cursor, match.index), usernames, `t${i}`))
    }

    const markdown = /^\[([^\]]+)\]\(([^)\s]+)\)$/.exec(raw)

    if (markdown) {
      const [, label, target] = markdown
      const host = hostOf(target)
      out.push(<Anchor key={`l${i}`} keyName={`l${i}`} href={host ? (/^https?:\/\//i.test(target) ? target : `https://${target}`) : '#'} label={label} />)
    } else {
      const { url, trailing } = trimTrailingPunctuation(raw)
      const href = /^https?:\/\//i.test(url) ? url : `https://${url}`
      out.push(<Anchor key={`l${i}`} keyName={`l${i}`} href={href} label={url} />)
      if (trailing) out.push(trailing)
    }

    cursor = match.index + raw.length
    i += 1
  }

  if (cursor === 0) return renderMentions(content, usernames, 't0')
  if (cursor < content.length) out.push(renderMentions(content.slice(cursor), usernames, `t${i}`))
  return out
}
