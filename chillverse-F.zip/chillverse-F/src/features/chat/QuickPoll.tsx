// src/features/chat/QuickPoll.tsx
// Not a separate poll system — this is the exact same polls/poll_options/
// poll_votes tables and vote_poll() RPC your Global Chat polls already use
// (see PollMessage.tsx). featured_poll just marks which one gets surfaced
// here. Staff sets it via long-press → "Feature as Quick Poll" on a poll
// message in Global Chat.
//
// FIX: vote_poll() requires the caller to be a member of the poll's room
// (is_room_member) — and Quick Poll always points at a Global Chat poll.
// A viewer who isn't a Global Chat member yet gets rejected server-side
// with CV_MOD_FORBIDDEN. The previous version discarded that error, so a
// rejected vote looked like the button did nothing. This version surfaces
// it inline so it's diagnosable and the user isn't left guessing.

import { useEffect, useState } from 'react'
import { PieChart } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'

interface PollOption { id: string; label: string; votes: number }
interface FeaturedPoll {
  poll_id: string
  question: string
  options: PollOption[]
  total_votes: number
  my_option_id: string | null
}

const BAR_COLORS = ['#ff6b00', '#4f8ef7', '#3ecf8e', '#9b6dff', '#f5c542']

function friendlyVoteError(message: string | undefined): string {
  const msg = message || ''
  if (msg.includes('CV_MOD_FORBIDDEN')) return "Join Global Chat to vote on this poll."
  if (msg.includes('CV_MOD_NOT_FOUND')) return 'This poll is no longer available.'
  if (msg.includes('CV_MOD_BAD_ROLE')) return msg.split('CV_MOD_BAD_ROLE:')[1]?.trim() || 'This poll has closed.'
  return 'Could not register your vote. Please try again.'
}

export default function QuickPoll() {
  const [poll, setPoll] = useState<FeaturedPoll | null | undefined>(undefined) // undefined = loading
  const [voting, setVoting] = useState(false)
  const [voteError, setVoteError] = useState<string | null>(null)

  function reload() {
    supabase.rpc('featured_poll_get').then(({ data }) => setPoll((data as FeaturedPoll) || null))
  }
  useEffect(() => {
    reload()
    const channel = supabase
      .channel('featured-poll')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'poll_votes' }, reload)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'featured_poll' }, reload)
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [])

  async function vote(optionId: string) {
    if (voting || !poll || poll.my_option_id) return
    setVoting(true)
    setVoteError(null)
    const { error } = await supabase.rpc('vote_poll', { p_poll_id: poll.poll_id, p_option_ids: [optionId] })
    setVoting(false)
    if (error) {
      setVoteError(friendlyVoteError(error.message))
      return
    }
    reload()
  }

  if (poll === undefined || poll === null) return null

  return (
    <div style={{ padding: '2px 0 4px' }}>
      <p style={{
        fontSize: 10.5, fontWeight: 800, letterSpacing: 0.08, textTransform: 'uppercase',
        color: 'var(--text-muted)', padding: '14px 4px 8px', display: 'flex', alignItems: 'center', gap: 5,
      }}>
        <PieChart size={12} style={{ color: '#4f8ef7' }} /> Quick Poll
      </p>

      <div style={{ padding: '14px', borderRadius: 16, background: 'var(--surface)', border: '1px solid rgba(255,255,255,0.05)' }}>
        <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>{poll.question}</p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {poll.options.map((opt, i) => {
            const pct = poll.total_votes > 0 ? Math.round((opt.votes / poll.total_votes) * 100) : 0
            const mine = poll.my_option_id === opt.id
            const canVote = !poll.my_option_id && !voting
            return (
              <div
                key={opt.id}
                role={canVote ? 'button' : undefined} tabIndex={canVote ? 0 : undefined}
                onClick={() => canVote && vote(opt.id)}
                style={{
                  position: 'relative', overflow: 'hidden', borderRadius: 10, height: 32,
                  background: '#232529', cursor: canVote ? 'pointer' : 'default',
                  border: mine ? `1px solid ${BAR_COLORS[i % BAR_COLORS.length]}` : '1px solid transparent',
                  opacity: voting ? 0.7 : 1,
                }}
              >
                {poll.my_option_id && (
                  <div style={{
                    position: 'absolute', inset: 0, width: `${pct}%`, borderRadius: 10,
                    background: `color-mix(in srgb, ${BAR_COLORS[i % BAR_COLORS.length]} 30%, transparent)`,
                    transition: 'width .3s ease',
                  }} />
                )}
                <div style={{ position: 'relative', height: '100%', padding: '0 11px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)' }}>
                    {opt.label}{mine ? ' ✓' : ''}
                  </span>
                  {poll.my_option_id && (
                    <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)' }}>{pct}%</span>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {voteError && (
          <p style={{ fontSize: 11, color: '#ff6b6b', fontWeight: 600, marginTop: 8 }}>
            {voteError}
          </p>
        )}

        <p style={{ fontSize: 10.5, color: 'var(--text-muted)', fontWeight: 600, marginTop: 8 }}>
          {poll.total_votes} {poll.total_votes === 1 ? 'vote' : 'votes'}
        </p>
      </div>
    </div>
  )
}
