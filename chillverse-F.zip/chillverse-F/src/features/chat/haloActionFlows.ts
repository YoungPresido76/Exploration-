// src/features/chat/haloActionFlows.ts
//
// The "does something" half of Halo's DM brain, as opposed to
// haloDynamicReplies.ts (which only ever *reads* and narrates). Every flow
// here follows the same shape: resolve intent -> fetch real state -> show a
// visual preview -> wait for a Confirm tap -> run one small, typed,
// server-validated mutation -> report the result back onto the same card.
//
// Nothing in this file writes to the database on its own read/preview step.
// The only functions that mutate anything are changeUsernameAction and
// registerForEliminationAction and buyMallItemAction, and every one of them
// is a thin wrapper around either a Supabase RPC (server does the real
// validation) or the same profiles.update the existing Account Settings
// screen already uses — see usernameRules.ts for why that's reused rather
// than re-implemented.
//
// Multi-turn state: only the username flow needs to remember "I already
// asked, the next message is the answer" — every other flow resolves out of
// the single message that triggered it. That's PendingHaloAction, held by
// Chat.tsx (one per open DM) and threaded into matchHaloActionFlow.

import { supabase } from '../../shared/lib/supabase'
import { validateUsername, getDaysUntilUsernameChange } from '../profile/usernameRules'
import { getEliminationStatus, registerForElimination } from '../pvp/pvp'
import { localWindowLabel } from '../../shared/lib/localTime'
import type { MallItem, UserWallet } from '../../shared/types'
import type { HaloWidget } from './haloDynamicReplies'

export interface HaloActionContext {
  myId: string | null
  myUsername: string | null
  myUsernameChangedAt: string | null
}

/** Held per open DM so "NovaX" on its own is understood as the answer to
 *  Halo's previous "what would you like your new username to be?" rather
 *  than a new, unrelated message. */
export type PendingHaloAction = { type: 'change_username' } | null

/** What a tap on one of Halo's action-card buttons reports back to
 *  Chat.tsx's handleHaloWidgetAction. One new variant per typed backend
 *  action — see section 6 of the spec for the full target list this can
 *  grow into (bio, event cancel, follow/duo, etc). */
export type HaloAction =
  | { type: 'confirm_username_change'; newUsername: string }
  | { type: 'cancel_username_change' }
  | { type: 'register_elimination' }
  | { type: 'buy_mall_item'; itemId: string; itemName: string }

export interface HaloActionFlowResult {
  text: string
  widget?: HaloWidget
  /** Set when this flow consumed the pending-answer state (or wants to ask
   *  a follow-up question and start one). Chat.tsx applies this to its
   *  per-room pending state after posting the reply. */
  nextPending?: PendingHaloAction
}

export interface HaloActionFlow {
  /** Shown immediately while run() is in flight — omitted for flows that
   *  need no request (e.g. asking the follow-up username question). */
  checking?: string
  run: () => Promise<HaloActionFlowResult>
}

const FALLBACK = "Couldn't do that right now — try again in a bit?"

// ── Username change ─────────────────────────────────────────────────────

const CHANGE_USERNAME_INTENT = /\b(change|update|edit)\s+my\s+username\b|\bchange\s+(my\s+)?username\b/i

async function checkUsernameAvailable(candidate: string, myId: string): Promise<boolean> {
  const { data } = await supabase
    .from('profiles')
    .select('id')
    .ilike('username', candidate)
    .neq('id', myId)
    .maybeSingle()
  return !data
}

async function startUsernameChange(): Promise<HaloActionFlowResult> {
  return {
    text: 'Sure! What would you like your new username to be?',
    nextPending: { type: 'change_username' },
  }
}

/** Called when a pending 'change_username' answer arrives — the raw next
 *  message is taken as the candidate username. */
async function resolveUsernameCandidate(candidate: string, ctx: HaloActionContext): Promise<HaloActionFlowResult> {
  const trimmed = candidate.trim()
  const myId = ctx.myId
  if (!myId || !ctx.myUsername) return { text: FALLBACK, nextPending: null }

  const daysLeft = getDaysUntilUsernameChange(ctx.myUsernameChangedAt)
  if (daysLeft !== null && daysLeft > 0) {
    return {
      text: `You can change your username again in ${daysLeft} day${daysLeft === 1 ? '' : 's'}.`,
      nextPending: null,
    }
  }

  const validationError = validateUsername(trimmed)
  if (validationError) {
    return { text: `${validationError} What would you like to try instead?`, nextPending: { type: 'change_username' } }
  }

  const available = await checkUsernameAvailable(trimmed, myId)
  return {
    text: available
      ? `${trimmed} is available! Want me to make the switch?`
      : `${trimmed} is already taken — want to try a different one?`,
    widget: {
      type: 'username_change',
      currentUsername: ctx.myUsername,
      newUsername: trimmed,
      usernameAvailable: available,
      unavailableReason: available ? null : 'That username is already taken.',
      status: 'pending',
    },
    // Still waiting on the player either way — if it's taken, the next
    // message should be read as another attempt rather than falling
    // through to the static vibe replies.
    nextPending: { type: 'change_username' },
  }
}

/** Runs the actual mutation once Confirm is tapped. Re-validates everything
 *  server-side-adjacent (cooldown, format, availability) rather than
 *  trusting the state baked into the card, since time may have passed since
 *  the card was shown. */
export async function changeUsernameAction(
  newUsername: string,
  ctx: HaloActionContext,
): Promise<{ success: boolean; error?: string }> {
  const myId = ctx.myId
  if (!myId) return { success: false, error: 'Not signed in.' }

  const daysLeft = getDaysUntilUsernameChange(ctx.myUsernameChangedAt)
  if (daysLeft !== null && daysLeft > 0) {
    return { success: false, error: `You can change your username again in ${daysLeft} day${daysLeft === 1 ? '' : 's'}.` }
  }
  const validationError = validateUsername(newUsername)
  if (validationError) return { success: false, error: validationError }

  const { error } = await supabase
    .from('profiles')
    .update({ username: newUsername.trim(), username_changed_at: new Date().toISOString() })
    .eq('id', myId)

  if (error) {
    if (error.code === '23505') return { success: false, error: 'That username is already taken.' }
    return { success: false, error: 'Failed to update username.' }
  }
  return { success: true }
}

// ── Elimination Weekend (event registration) ───────────────────────────

const ELIMINATION_EVENT_INTENT =
  /\b(register|sign up|signup|join)\b.*\b(elimination weekend|elimination)\b|\belimination weekend\b.*\b(register|sign up|join)\b/i

async function resolveEliminationPreview(): Promise<HaloActionFlowResult> {
  const status = await getEliminationStatus().catch(() => null)
  if (!status) return { text: FALLBACK }

  const windowLabel = localWindowLabel(status.registration_opens_at, status.registration_closes_at)
  const eventStatus: 'eligible' | 'registered' | 'closed' = status.me_registered
    ? 'registered'
    : status.registration_open
      ? 'eligible'
      : 'closed'

  const text = status.me_registered
    ? "You're already signed up for Elimination Weekend — I'll be around when it kicks off."
    : status.registration_open
      ? "Here's Elimination Weekend — want me to register you?"
      : "Registration for Elimination Weekend isn't open right now."

  return {
    text,
    widget: {
      type: 'event_preview',
      eventId: 'elimination_weekend',
      title: 'Elimination Weekend',
      bannerUrl: status.banner_url,
      windowLabel,
      registeredCount: status.registered_count,
      status: eventStatus,
    },
  }
}

export async function registerForEliminationAction(): Promise<{ success: boolean; error?: string; registeredCount?: number }> {
  try {
    const res = await registerForElimination()
    return { success: true, registeredCount: res.registered_count }
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Could not register.' }
  }
}

// ── Mall preview ─────────────────────────────────────────────────────────

const MALL_QUERY_INTENT =
  /\bwhat (can|could) i buy\b|\bwhat.*afford\b|\bmall recommendation\b|\brecommend.*mall\b|\bshow me the mall\b|\bwhat'?s (good |new )?in the mall\b/i

/** Optional "with 500 gems" / "with 200 orbs" budget capture — if present,
 *  items are filtered/sorted around that budget; if absent, the player's
 *  actual wallet balance is used instead. */
const MALL_BUDGET_HINT = /\b(\d{2,6})\s*(gems?|diamonds?|orbs?)\b/i

async function resolveMallPreview(userText: string, myId: string): Promise<HaloActionFlowResult> {
  const budgetMatch = userText.match(MALL_BUDGET_HINT)
  const budgetAmount = budgetMatch ? parseInt(budgetMatch[1], 10) : null
  const budgetCurrency: 'gems' | 'orbs' = budgetMatch && /orb/i.test(budgetMatch[2]) ? 'orbs' : 'gems'

  const [{ data: items }, { data: wallet }] = await Promise.all([
    supabase
      .from('mall_items')
      .select('id, name, image_url, price_gems, price_orbs, is_active, available_until, is_locked')
      .eq('is_active', true)
      .order('rarity', { ascending: true })
      .limit(40),
    supabase.from('user_wallets').select('gem_balance, orb_balance').eq('user_id', myId).maybeSingle(),
  ])
  if (!items || items.length === 0) return { text: FALLBACK }

  const gemBalance = budgetAmount != null && budgetCurrency === 'gems' ? budgetAmount : (wallet?.gem_balance ?? 0)
  const orbBalance = budgetAmount != null && budgetCurrency === 'orbs' ? budgetAmount : (wallet?.orb_balance ?? 0)

  const now = Date.now()
  const usable = (items as Pick<MallItem, 'id' | 'name' | 'image_url' | 'price_gems' | 'price_orbs' | 'is_active' | 'available_until' | 'is_locked'>[])
    .filter(it => !it.is_locked && (!it.available_until || new Date(it.available_until).getTime() > now))
    .map(it => ({
      id: it.id,
      name: it.name,
      imageUrl: it.image_url,
      priceGems: it.price_gems,
      priceOrbs: it.price_orbs,
      affordable: (it.price_gems != null && gemBalance >= it.price_gems) || (it.price_orbs != null && orbBalance >= it.price_orbs),
      owned: false,
    }))
    .filter(it => it.priceGems != null || it.priceOrbs != null)

  const affordableFirst = [...usable].sort((a, b) => Number(b.affordable) - Number(a.affordable))
  const shown = affordableFirst.slice(0, 6)
  if (shown.length === 0) return { text: FALLBACK }

  const affordableCount = shown.filter(it => it.affordable).length
  const text = budgetAmount != null
    ? `Here's what you could get with ${budgetAmount} ${budgetCurrency}:`
    : affordableCount > 0
      ? "Here's some stuff from the Mall you can grab right now:"
      : "Here's what's in the Mall — a few of these are just out of reach at your current balance:"

  return {
    text,
    widget: { type: 'mall_preview', items: shown },
  }
}

export async function buyMallItemAction(itemId: string, myId: string): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase.rpc('purchase_mall_item', { p_user_id: myId, p_item_id: itemId })
  if (error) {
    if (error.message === 'insufficient_funds') return { success: false, error: 'Not enough Diamonds/Orbs for that.' }
    if (error.message.includes('item_expired')) return { success: false, error: 'That item just expired.' }
    if (error.message.includes('item_locked')) return { success: false, error: 'That item is locked right now.' }
    return { success: false, error: 'Purchase failed.' }
  }
  return { success: true }
}

// ── Wallet preview ───────────────────────────────────────────────────────

const WALLET_QUERY_INTENT = /\bcheck my wallet\b|\bmy wallet\b|\bmy balance\b|\bhow many (gems|diamonds|orbs)\b/i

async function resolveWalletPreview(myId: string): Promise<HaloActionFlowResult> {
  const { data, error } = await supabase
    .from('user_wallets')
    .select('gem_balance, orb_balance, voucher_balance')
    .eq('user_id', myId)
    .maybeSingle()
  if (error) return { text: FALLBACK }
  const wallet = (data as Pick<UserWallet, 'gem_balance' | 'orb_balance' | 'voucher_balance'> | null) ?? {
    gem_balance: 0,
    orb_balance: 0,
    voucher_balance: 0,
  }
  return {
    text: `You've got ${wallet.gem_balance} Diamonds and ${wallet.orb_balance} Orbs.`,
    widget: {
      type: 'wallet_preview',
      gemBalance: wallet.gem_balance,
      orbBalance: wallet.orb_balance,
      voucherBalance: wallet.voucher_balance,
    },
  }
}

// ── Dispatcher ───────────────────────────────────────────────────────────

/**
 * Tries the action-system flows in order. Returns null if nothing here
 * applies, so the caller falls through to matchDynamicHaloFlow next and
 * pickHaloStaticReply after that. `pending` takes priority over everything
 * else — an outstanding question from Halo always claims the next message.
 */
export function matchHaloActionFlow(
  userText: string,
  ctx: HaloActionContext,
  pending: PendingHaloAction,
): HaloActionFlow | null {
  if (pending?.type === 'change_username') {
    return { checking: 'Checking availability...', run: () => resolveUsernameCandidate(userText, ctx) }
  }

  const lower = userText.toLowerCase()

  if (CHANGE_USERNAME_INTENT.test(lower)) {
    // No request needed — just asks the follow-up question.
    return { run: () => startUsernameChange() }
  }

  if (!ctx.myId) return null
  const myId = ctx.myId

  if (ELIMINATION_EVENT_INTENT.test(lower)) {
    return { checking: 'Checking Elimination Weekend...', run: () => resolveEliminationPreview() }
  }

  if (MALL_QUERY_INTENT.test(lower)) {
    return { checking: 'Checking the Mall...', run: () => resolveMallPreview(userText, myId) }
  }

  if (WALLET_QUERY_INTENT.test(lower)) {
    return { checking: 'Checking your wallet...', run: () => resolveWalletPreview(myId) }
  }

  return null
}
