// src/features/chat/haloStaticReplies.ts
//
// Halo AI now has a real profile people can DM like anyone else, but there's
// no live backend behind THOSE messages yet (unlike the dedicated Halo AI
// page, which calls the halo-ai-chat edge function). Until that's wired up,
// a DM to Halo AI gets a locally-generated canned reply instead of silence.
//
// This is deliberately client-side only — see the call site in Chat.tsx —
// so it needs no new edge function, API key, or DB migration to turn on.
// Swap `pickHaloStaticReply` for a real API call whenever that's ready.
//
// Beyond the original greeting/thanks/question/default buckets, this also
// does a light keyword read for game talk (by name or by category), rank
// and mission talk, win/loss vibes, post mentions, and all-caps/emoji-only
// energy — pulling real names/taglines from the GAMES catalog and real
// tier names from RANK_TIERS so it sounds like it knows the app instead of
// just stalling. Still 100% pattern-matching over the raw text — no model
// call, no network request.
//
// `roomId` is optional and only used to avoid repeating the same game
// suggestion twice in a row in the same DM — pass `room.id` from the call
// site when you have it. Omit it (or pass a fresh id each time) and it
// just always picks fresh, no state needed.

import { GAMES, type GameMeta } from '../games/games'
import { RANK_TIERS } from '../profile/ranks'

const GREETING_REPLIES = [
  "Hey! Good to see you. What's on your mind?",
  "Hi there 👋 What can I help you with?",
  "Hello! Ask me anything about Chillverse.",
]

const THANKS_REPLIES = [
  "Anytime! 🎮",
  "You got it — good luck out there.",
  "Happy to help!",
]

const QUESTION_REPLIES = [
  "Good question! I'm still getting my full brain wired up for DMs — for a real answer right now, try the Halo AI page instead.",
  "I'm not fully online in chat just yet. Head to the dedicated Halo AI page in the meantime for the real thing!",
  "I hear you — I just can't dig into that from here yet. The Halo AI page can help with this one for now.",
]

const DEFAULT_REPLIES = [
  "Got it! I'm running on placeholder replies in chat for now, but the real thing is coming soon.",
  "Noted 👍 Still warming up in DMs — thanks for bearing with me.",
  "Thanks for the message! I'm not fully wired up here yet, but I'm listening.",
]

// ─── Game talk ───────────────────────────────────────────────────

const NAMED_GAME_REPLY_TEMPLATES = [
  (g: GameMeta) => `Oh, ${g.name}? Good taste — "${g.tagline}" pretty much sums it up. Go run it.`,
  (g: GameMeta) => `${g.name} is a solid pick, ${g.category ? `love a good ${g.category.toLowerCase()} session` : 'always worth a round'}. ${g.tagline}`,
  (g: GameMeta) => `Heck yeah, ${g.name}. That one lives rent-free on my leaderboard brain.`,
  (g: GameMeta) => `${g.name}! "${g.tagline}" — you picked a good one to grind today.`,
]

const SUGGEST_GAME_REPLY_TEMPLATES = [
  (g: GameMeta) => `Bored? Go run ${g.name} — "${g.tagline}" It's a quick one.`,
  (g: GameMeta) => `If you want a suggestion: ${g.name}. ${g.tagline}`,
  (g: GameMeta) => `Try ${g.name} next — ${g.category ? `it's one of the better ${g.category.toLowerCase()} picks on here.` : "it's underrated."}`,
  (g: GameMeta) => `Honestly? ${g.name}. "${g.tagline}" Report back with your score.`,
]

// Words that signal "please pick something for me" rather than "here's
// what I'm already playing" — used to route to a suggestion instead of
// trying to match a named game out of the sentence.
const SUGGESTION_REQUEST_HINT = /\b(bored|recommend|suggest|suggestion|what should i play|any good games?|something to play)\b/i

// Loose category keywords → the `category` string they map to in GAMES,
// plus a couple of boolean-flag categories (board/strategy) that aren't
// stored as a plain `category` string. Checked as whole words so e.g.
// "sword" doesn't accidentally match "word".
const CATEGORY_KEYWORD_MATCHERS: { pattern: RegExp; matches: (g: GameMeta) => boolean }[] = [
  { pattern: /\btrivia\b/i, matches: g => g.category === 'Trivia' },
  { pattern: /\bpuzzles?\b/i, matches: g => g.category === 'Puzzle' },
  { pattern: /\bcards?\b/i, matches: g => g.category === 'Card Game' },
  { pattern: /\bwords?\b/i, matches: g => g.category === 'Word Game' },
  { pattern: /\barcade\b/i, matches: g => g.category === 'Arcade' },
  { pattern: /\bstrategy\b/i, matches: g => g.category === 'Strategy' || !!g.isStrategyGame },
  { pattern: /\bboard\b/i, matches: g => !!g.isBoardGame },
]

/** Narrows the pool to a mentioned category (e.g. "something with cards")
 *  if the text names one; otherwise returns the full catalog. Games
 *  requiring Pro are left in — Halo isn't gatekeeping suggestions here. */
function poolForCategory(lower: string): GameMeta[] {
  const matcher = CATEGORY_KEYWORD_MATCHERS.find(({ pattern }) => pattern.test(lower))
  if (!matcher) return GAMES
  const filtered = GAMES.filter(matcher.matches)
  return filtered.length > 0 ? filtered : GAMES
}

// ─── Per-room "don't repeat yourself" memory ─────────────────────
// Purely in-memory, resets on reload — this is a vibe nicety, not state
// worth persisting. Keyed by roomId; each room remembers its last few
// suggested game ids so a second "bored" in a row doesn't get the same
// answer back.
const RECENT_SUGGESTIONS_PER_ROOM = new Map<string, string[]>()
const RECENT_SUGGESTIONS_HISTORY = 3

function pickFreshGame(pool: GameMeta[], roomId?: string): GameMeta {
  const recent = roomId ? RECENT_SUGGESTIONS_PER_ROOM.get(roomId) ?? [] : []
  const fresh = pool.filter(g => !recent.includes(g.id))
  const chosen = pickRandom(fresh.length > 0 ? fresh : pool)

  if (roomId) {
    const updated = [...recent, chosen.id].slice(-RECENT_SUGGESTIONS_HISTORY)
    RECENT_SUGGESTIONS_PER_ROOM.set(roomId, updated)
  }
  return chosen
}

const WIN_VIBE_HINT = /\b(won|win|beat (it|him|her|them)|high score|new streak|streak['’]?s? going|nailed it|first place|top of the leaderboard|clutch|gg\b.*me)\b/i
const WIN_VIBE_REPLIES = [
  "LET'S GO 🔥 that's the energy.",
  "Okay that's actually clutch, nice.",
  "See, this is why I like DMing you — certified winner behavior.",
  "Streaks like that don't happen by accident. Keep riding it.",
]

const LOSS_VIBE_HINT = /\b(lost|lose|losing|rip\b|that sucked|so bad|blew it|choked|streak (broke|ended|died)|last place)\b/i
const LOSS_VIBE_REPLIES = [
  "Ouch. Shake it off, the next round doesn't know about this one.",
  "Rough one. Everybody's got an L in the rotation somewhere.",
  "That happens to the best of us — go get it back.",
  "Ah, painful. Run it back, you'll flip it.",
]

// ─── Rank & mission talk ──────────────────────────────────────────
// RANK_TIERS is the same static catalog Ranks.tsx reads from, so a
// mentioned tier name is guaranteed to be real. Matched longest-name-first
// for the same reason as game aliases: "Gold I" shouldn't get shadowed by
// a bare "gold" check landing first when both are present.
// Exported so haloDynamicReplies.ts can reuse the same flavor lines for
// the real "how do I rank up" reply instead of keeping a second copy.
export const RANK_GROUP_FLAVOR: Record<string, string> = {
  rookie: "everyone starts there, don't sweat it",
  bronze: 'solid foundation — keep stacking XP',
  silver: "you're climbing for real now",
  gold: 'okay, rewards territory, look at you',
  platinum: 'that\u2019s a legitimately good rank',
  diamond: "that's elite tier, congrats",
  legend: 'LEGEND. as in the actual rank. incredible',
  og: 'Chillverse OG?! top of the mountain, nothing left to prove',
}

function findNamedRankTier(lower: string) {
  return [...RANK_TIERS]
    .sort((a, b) => b.name.length - a.name.length)
    .find(r => new RegExp(`\\b${r.name.toLowerCase()}\\b`).test(lower))
}

function rankReply(tierName: string, group: string): string {
  const flavor = RANK_GROUP_FLAVOR[group] ?? 'nice climb'
  return `${tierName}? ${flavor}. ${'\u{1F3C6}'}`
}

const MISSION_MENTION_HINT = /\b(mission|missions|weekly mission)\b/i
const MISSION_REPLIES = [
  "Weekly missions reset every Monday, so if you're close, don't sit on it.",
  "Missions are a good XP shortcut if you haven't cleared this week's yet.",
  "How's the mission board looking? Worth clearing before Monday's reset.",
]

const POST_MENTION_HINT = /\b(my post|posted|check my post|see my post|the feed|my feed|just posted)\b/i
const POST_MENTION_REPLIES = [
  "Saw it come through — nice one. Keep 'em coming.",
  "That's going in the feed rotation, love that for you.",
  "Good post energy today. What tag are you slapping on the next one?",
  "I see you out here posting. Respect.",
]

// ─── Caps / emoji-only energy ─────────────────────────────────────
// For messages that are pure vibe with no real content to key off —
// "LMAOOOO", "🔥🔥🔥" — a flat DEFAULT_REPLIES line reads dead next to
// that energy, so these get their own bucket. Checked against the raw
// (non-lowercased) text since case is exactly the signal here.
const EMOJI_ONLY_PATTERN = /^[\p{Extended_Pictographic}\u200d\uFE0F\s]+$/u
const CAPS_HYPE_PATTERN = /^[^a-z]*[A-Z]{2}[^a-z]*$/ // has letters, none lowercase, at least 2 caps in a row somewhere

const EMOJI_ONLY_REPLIES = [
  "Say less.",
  "That's a whole mood.",
  "I feel that, no notes.",
  "Same energy, honestly.",
]

const CAPS_HYPE_REPLIES = [
  "Okay I felt that through the screen.",
  "That's a lot of caps and I'm here for it.",
  "Screaming with you, no notes.",
  "Love the enthusiasm.",
]

// ─── Policy lines ───────────────────────────────────────────────────
// Fixed answers Halo should always give the same way, regardless of
// phrasing — not vibe-reads, not data lookups, just guardrails.

const WHO_MADE_HINT = /\bwho (made|creat(ed|es)|built|built|coded|programmed|trained) you\b/i
const WHO_MADE_REPLIES = [
  "Uhmm, that's confidential 😊",
  "Can't say — trade secret 😅",
  "That's classified intel, sorry 😊",
]

// "Who is <name>" / "who's <name>" — a lookup on another player. Doesn't
// try to verify the name is a real account (that would mean a query just
// to decide how to refuse, which leaks more than it protects) — any name
// that isn't obviously self-referential gets the same privacy line.
const WHO_IS_HINT = /\bwho(?:'s| is)\s+@?([a-z][a-z0-9_. ]{1,24}?)\??$/i
const SELF_REFERENTIAL_NAME = /\b(halo|chillverse|you|u|me|i)\b/i
const OTHER_PLAYER_LOOKUP_REPLIES = [
  "Sorry, I can't reveal personal info about other players.",
  "Can't share details about another player — that's between them and their profile.",
  "Not something I can hand out about someone else, sorry.",
]

function isOtherPlayerLookup(trimmedText: string): boolean {
  const match = WHO_IS_HINT.exec(trimmedText)
  if (!match) return false
  return !SELF_REFERENTIAL_NAME.test(match[1].trim())
}

// Common non-Chillverse question shapes — weather, general trivia, "solve
// this for me" asks, coding help, etc. Necessarily a heuristic like
// everything else in this file: it only catches the clearer cases, and an
// unmatched off-topic question just falls through to QUESTION_REPLIES
// below, which is a safe (if generic) default either way.
const OFF_TOPIC_HINT = /\b(weather|forecast|stock price|capital of|who is the president|current time in|news today|solve (this )?math|my homework|translate (this|the)|recipe for|write (me )?(a|an) essay|what year is it|define \w+)\b/i
const OFF_TOPIC_REPLIES = [
  'I only answer Chillverse-related stuff 🎮',
  "That's outside my lane — I'm all Chillverse, all the time.",
  'Can\u2019t help with that one — ask me something about the app instead!',
]

// ─── Inactivity relate ───────────────────────────────────────────────
const INACTIVITY_HINT = /\b(haven'?t been active|been slacking|been away|haven'?t played in a (while|bit|minute)|miss(ed)? (a lot|so much)|fell off)\b/i
const INACTIVITY_REPLIES = [
  "Life happens — the app'll still be here whenever you're ready.",
  "No worries, everyone goes quiet sometimes. Ease back in, no rush.",
  "Happens to the best of us. Jump back in when you can, it's all still here.",
]

function pickRandom<T>(list: T[]): T {
  return list[Math.floor(Math.random() * list.length)]
}

/** Aliases a game can be recognized by beyond its display name — mainly
 *  for cases like "Chillverse_Uno", where nobody actually types the
 *  branding and just says "uno". Falls back to `id`/`dbKey` with their
 *  separators turned into spaces so those count as whole-word matches too. */
function gameAliases(g: GameMeta): string[] {
  const clean = (s: string) => s.toLowerCase().replace(/[_-]/g, ' ').trim()
  return [...new Set([clean(g.name), clean(g.id), clean(g.dbKey)])].filter(Boolean)
}

/** Finds the first GAMES catalog entry named in the text, if any. Longer,
 *  more specific aliases are checked first so a multi-word title (or a
 *  full display name) doesn't get shadowed by a shorter, looser one — and
 *  single-word aliases are matched on word boundaries so they don't fire
 *  on unrelated substrings. */
function findNamedGame(lower: string): GameMeta | undefined {
  const candidates = GAMES
    .flatMap(g => gameAliases(g).map(alias => ({ game: g, alias })))
    .sort((a, b) => b.alias.length - a.alias.length)

  return candidates.find(({ alias }) => {
    if (alias.includes(' ')) return lower.includes(alias)
    return new RegExp(`\\b${alias}\\b`).test(lower)
  })?.game
}

/** Picks a canned Halo AI reply based on a light read of what was sent.
 *  `roomId` is optional — pass it to keep game suggestions from repeating
 *  within the same DM. Returns the matched `game` alongside the text
 *  whenever the reply is actually about one (named-game or suggestion
 *  branches) so the caller can show a game card with a Play button under
 *  it — every other branch omits `game`. */
export function pickHaloStaticReply(userText: string, roomId?: string): { text: string; game?: GameMeta } {
  const lower = userText.toLowerCase()

  if (/\b(hi|hey|hello|yo|sup)\b/.test(lower)) return { text: pickRandom(GREETING_REPLIES) }
  if (/\b(thanks|thank you|thx|ty)\b/.test(lower)) return { text: pickRandom(THANKS_REPLIES) }

  // Policy lines take priority over everything else here — a name that
  // happens to also look like a game alias shouldn't get treated as game
  // talk instead of the privacy line it actually needs.
  if (WHO_MADE_HINT.test(lower)) return { text: pickRandom(WHO_MADE_REPLIES) }
  if (isOtherPlayerLookup(userText.trim())) return { text: pickRandom(OTHER_PLAYER_LOOKUP_REPLIES) }

  if (INACTIVITY_HINT.test(lower)) return { text: pickRandom(INACTIVITY_REPLIES) }

  // A named game beats everything else — if they said "Plunder", react to
  // Plunder specifically rather than a generic win/loss or category line.
  const namedGame = findNamedGame(lower)
  if (namedGame) {
    return { text: pickRandom(NAMED_GAME_REPLY_TEMPLATES)(namedGame), game: namedGame }
  }

  if (SUGGESTION_REQUEST_HINT.test(lower)) {
    const pool = poolForCategory(lower)
    const game = pickFreshGame(pool, roomId)
    return { text: pickRandom(SUGGEST_GAME_REPLY_TEMPLATES)(game), game }
  }

  const namedRank = findNamedRankTier(lower)
  if (namedRank) return { text: rankReply(namedRank.name, namedRank.group) }
  if (MISSION_MENTION_HINT.test(lower)) return { text: pickRandom(MISSION_REPLIES) }

  if (WIN_VIBE_HINT.test(lower)) return { text: pickRandom(WIN_VIBE_REPLIES) }
  if (LOSS_VIBE_HINT.test(lower)) return { text: pickRandom(LOSS_VIBE_REPLIES) }
  if (POST_MENTION_HINT.test(lower)) return { text: pickRandom(POST_MENTION_REPLIES) }

  const trimmed = userText.trim()
  if (trimmed.length > 0 && EMOJI_ONLY_PATTERN.test(trimmed)) return { text: pickRandom(EMOJI_ONLY_REPLIES) }
  if (trimmed.length >= 3 && CAPS_HYPE_PATTERN.test(trimmed)) return { text: pickRandom(CAPS_HYPE_REPLIES) }

  if (OFF_TOPIC_HINT.test(lower)) return { text: pickRandom(OFF_TOPIC_REPLIES) }
  if (lower.includes('?')) return { text: pickRandom(QUESTION_REPLIES) }
  return { text: pickRandom(DEFAULT_REPLIES) }
}
