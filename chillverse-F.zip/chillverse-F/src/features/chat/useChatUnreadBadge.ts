// src/features/chat/useChatUnreadBadge.ts
//
// Powers the persistent dot on the Chat icon in Topbar.tsx — shown on
// every page (Topbar is mounted app-wide in AppLayout), not just the
// per-room unread counts inside the Chat hub itself (see
// src/shared/lib/unread.ts / IconRail.tsx / ChatHub.tsx for those).
//
// Backed by profiles.chat_last_seen_at (migration 0110): a single
// timestamp bumped the moment the user opens the Chat hub at all, so the
// badge clears on "entered chat", not "read every unread room". The
// has_unread_chat_messages() RPC does the actual comparison server-side
// against every room the user belongs to.
import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { emitBadgeSeen, useBadgeSeen } from '../../shared/lib/badgeBus'

export function useChatUnreadBadge(): boolean {
  const { user } = useAuth()
  const [hasUnread, setHasUnread] = useState(false)

  const recheck = useCallback(() => {
    if (!user) { setHasUnread(false); return }
    supabase.rpc('has_unread_chat_messages').then(({ data, error }) => {
      if (!error) setHasUnread(!!data)
    })
  }, [user])

  useEffect(() => { recheck() }, [recheck])

  // Opening the hub clears the badge on the spot rather than waiting for the
  // profiles UPDATE to echo back through realtime — that echo is the slow
  // path at best and, if realtime drops the row, never arrives at all, which
  // is what left the dot burning after the user had plainly read everything.
  useBadgeSeen('chat', () => setHasUnread(false))

  // Coming back to a backgrounded tab is the other moment the answer can be
  // stale, since realtime events that arrived while hidden may have been missed.
  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') recheck() }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [recheck])

  useEffect(() => {
    if (!user) return
    // Two things can flip the answer: a new message anywhere (cheap
    // catch-all-then-refetch, same pattern as IconRail/ChatHub badges —
    // this RPC is a single EXISTS query, so re-running it per insert is
    // fine at this app's scale), or this user's own chat_last_seen_at
    // getting bumped by ChatHub mounting (in another tab, or just now).
    const ch = supabase
      .channel('global-chat-badge')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, recheck)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${user.id}` }, recheck)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [user, recheck])

  // Mirrors the same boolean onto the installed PWA's home-screen icon via
  // the Badging API — this is the actual OS-level badge (Android/desktop
  // launcher icon), separate from the in-app dot on the Topbar chat icon
  // above, but driven by the exact same "any unread anywhere" signal so
  // the two can never disagree. setAppBadge/clearAppBadge only exist on
  // browsers that support the Badging API (installed PWAs on Chromium,
  // mainly) — silently a no-op everywhere else, including this app
  // running as a normal browser tab.
  useEffect(() => {
    if (hasUnread) {
      navigator.setAppBadge?.(1).catch(() => {})
    } else {
      navigator.clearAppBadge?.().catch(() => {})
    }
  }, [hasUnread])

  return hasUnread
}

/** Called once when the Chat hub mounts — marks "entered chat" so the
 *  Topbar dot clears immediately, everywhere, via the realtime profiles
 *  subscription above. Not gated on which tab/room was actually opened,
 *  by design (see migration 0110's header comment).
 *
 *  The clear above is optimistic — emitted before the write below is even
 *  sent — so if that write silently fails (RLS hiccup, dropped request,
 *  anything), the dot was cleared locally but chat_last_seen_at was never
 *  actually bumped server-side. A later reload's has_unread_chat_messages()
 *  check then reads the real, unchanged row and correctly reports "still
 *  unread" — which looks to the user like the dot coming back for no
 *  reason, when really it never should have cleared in the first place.
 *  Surfacing the error (instead of swallowing it via a bare `await`) at
 *  least makes that failure visible instead of silent. */
export async function markChatSeen(userId: string): Promise<void> {
  emitBadgeSeen('chat')
  const { error } = await supabase
    .from('profiles')
    .update({ chat_last_seen_at: new Date().toISOString() })
    .eq('id', userId)
  if (error) {
    console.error('Failed to mark chat as seen — chat_last_seen_at was not updated, the Topbar dot may reappear on next check:', error.message)
  }
}
