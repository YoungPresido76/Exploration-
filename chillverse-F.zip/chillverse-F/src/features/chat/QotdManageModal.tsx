// src/features/chat/QotdManageModal.tsx
// Staff/Moderator/Admin only (server-enforced via is_staff() inside every
// qotd_bank_* RPC — this modal just won't render for anyone else). Lets
// staff add new questions to the rotation, retire ones they don't want
// asked again (is_active = false, keeps history/times_used intact rather
// than deleting), or hard-delete a question that was never used.

import { useEffect, useState } from 'react'
import { X, Plus, Trash2, EyeOff, Eye } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'

interface BankRow {
  id: string
  question: string
  is_active: boolean
  times_used: number
  created_at: string
}

export default function QotdManageModal({ onClose }: { onClose: () => void }) {
  const [rows, setRows] = useState<BankRow[] | null>(null)
  const [draft, setDraft] = useState('')
  const [adding, setAdding] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function reload() {
    supabase.rpc('qotd_bank_list').then(({ data, error: err }) => {
      if (err) { setError('Could not load — staff access required.'); return }
      setRows((data as BankRow[]) || [])
    })
  }
  useEffect(reload, [])

  async function addQuestion() {
    const q = draft.trim()
    if (!q || adding) return
    setAdding(true)
    setError(null)
    const { error: err } = await supabase.rpc('qotd_bank_add', { p_question: q })
    setAdding(false)
    if (err) { setError('Could not add question.'); return }
    setDraft('')
    reload()
  }

  async function toggleActive(row: BankRow) {
    await supabase.rpc('qotd_bank_update', { p_id: row.id, p_is_active: !row.is_active })
    reload()
  }

  async function removeQuestion(row: BankRow) {
    const { error: err } = await supabase.rpc('qotd_bank_delete', { p_id: row.id })
    if (err) {
      setError(err.message?.includes('question_in_use') ? "Can't delete today's active question." : 'Could not delete.')
      return
    }
    reload()
  }

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)' }} />
      <div style={{
        position: 'relative', width: '100%', maxWidth: 480, maxHeight: '82vh',
        background: 'var(--surface2)', borderRadius: '22px 22px 0 0',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <div>
            <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)' }}>Manage Question Bank</p>
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2 }}>Staff, Moderator & Admin</p>
          </div>
          <button onClick={onClose} style={{ width: 30, height: 30, borderRadius: 9, background: 'var(--surface)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={15} />
          </button>
        </div>

        <div style={{ padding: '12px 18px', display: 'flex', gap: 8, flexShrink: 0, borderBottom: '1px solid var(--border)' }}>
          <input
            value={draft} onChange={e => setDraft(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') addQuestion() }}
            placeholder="Add a new question…" maxLength={300}
            style={{ flex: 1, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: '9px 13px', fontSize: 13, color: 'var(--text)', outline: 'none' }}
          />
          <button onClick={addQuestion} disabled={!draft.trim() || adding} style={{
            width: 38, height: 38, borderRadius: 12, border: 'none', flexShrink: 0,
            background: draft.trim() ? 'var(--accent)' : 'var(--surface)', color: draft.trim() ? '#fff' : 'var(--text-muted)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: draft.trim() ? 'pointer' : 'default',
          }}>
            <Plus size={16} />
          </button>
        </div>

        {error && <div style={{ margin: '10px 18px 0', padding: '7px 12px', borderRadius: 10, background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.25)', fontSize: 12, color: '#ff6b6b' }}>{error}</div>}

        <div style={{ flex: 1, overflowY: 'auto', padding: '10px 18px 18px' }}>
          {!rows ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: 24 }}>Loading…</p>
          ) : rows.length === 0 ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: 24 }}>No questions yet — add one above.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {rows.map(row => (
                <div key={row.id} style={{
                  display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 13,
                  background: 'var(--surface)', border: '1px solid rgba(255,255,255,0.05)',
                  opacity: row.is_active ? 1 : 0.5,
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)', lineHeight: 1.4 }}>{row.question}</p>
                    <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 3 }}>
                      Used {row.times_used}× {!row.is_active && '· Retired'}
                    </p>
                  </div>
                  <button onClick={() => toggleActive(row)} title={row.is_active ? 'Retire' : 'Reactivate'}
                    style={{ width: 30, height: 30, borderRadius: 9, background: 'var(--surface2)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', cursor: 'pointer', flexShrink: 0 }}>
                    {row.is_active ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                  <button onClick={() => removeQuestion(row)} title="Delete"
                    style={{ width: 30, height: 30, borderRadius: 9, background: 'var(--surface2)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ff6b6b', cursor: 'pointer', flexShrink: 0 }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
