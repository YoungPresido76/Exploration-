// src/features/chat/chatImages.ts
// Uploads a picture to the public `chat-images` bucket (migration 0119) and
// returns its URL, ready to store on messages.image_url.
//
// Pictures are a Void-tier perk and personal DMs only — enforced server-side
// by enforce_chat_image_gate() (migrations 0121/0123), which staff bypass so
// admin broadcasts can carry an image. Free users are allowed pictures in one
// place only: their DM with the official Chillverse account, capped at 2MB.
//
// The 3MB rule is deliberately EXCLUSIVE: a file of exactly 3 * 1024 * 1024
// bytes is rejected, not just one over. The bucket itself is capped at
// 3145727 bytes server-side, so this check is the friendly-error path — a
// client that skips it still can't get a 3MB file past storage.

import { supabase } from '../../shared/lib/supabase'

export const MAX_CHAT_IMAGE_BYTES = 3 * 1024 * 1024 // 3MB — Void tier
export const MAX_FREE_CHAT_IMAGE_BYTES = 2 * 1024 * 1024 // 2MB — free tier, official DM only
// Both ceilings are EXCLUSIVE: a file of exactly the limit is refused.

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
const BUCKET = 'chat-images'

/** Human-readable size for error copy, e.g. "2.4MB". */
function formatBytes(bytes: number): string {
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`
}

function extensionFor(file: File): string {
  switch (file.type) {
    case 'image/png': return 'png'
    case 'image/webp': return 'webp'
    case 'image/gif': return 'gif'
    default: return 'jpg'
  }
}

/** Returns an error string when the file can't be sent, or null when it's fine.
 *  `limitBytes` lets the caller apply the free-tier 2MB ceiling instead of the
 *  Void 3MB one; the server re-checks either way (migration 0123). */
export function validateChatImage(file: File, limitBytes: number = MAX_CHAT_IMAGE_BYTES): string | null {
  if (!ALLOWED_TYPES.includes(file.type)) {
    return 'That file type is not supported. Use a JPG, PNG, WebP, or GIF.'
  }
  if (file.size >= limitBytes) {
    const limitLabel = `${Math.round(limitBytes / (1024 * 1024))}MB`
    return `Image is ${formatBytes(file.size)} — must be under ${limitLabel}.`
  }
  return null
}

/** Uploads to `{userId}/{uuid}.{ext}` — the folder prefix is what the bucket's
 *  RLS policy checks, so a user can only ever write into their own space. */
export async function uploadChatImage(userId: string, file: File, limitBytes: number = MAX_CHAT_IMAGE_BYTES): Promise<string> {
  const invalid = validateChatImage(file, limitBytes)
  if (invalid) throw new Error(invalid)

  const path = `${userId}/${crypto.randomUUID()}.${extensionFor(file)}`
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })

  if (error) {
    // Storage returns a size error of its own if the client-side check was
    // somehow bypassed — translate it rather than leaking the raw message.
    if (/exceeded|too large|maximum size/i.test(error.message)) {
      throw new Error('Images must be under 3MB.')
    }
    throw new Error(`Failed to upload image: ${error.message}`)
  }

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path)
  return data.publicUrl
}
