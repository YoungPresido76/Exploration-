// src/pages/Chat.tsx
import { useState, useRef, useEffect, useLayoutEffect, useCallback, useMemo, memo, Fragment } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import {
  ArrowLeft, Search, MoreVertical,
  Smile, Send, X, Trash2, Reply, Flag, Lock,
  MessageCircle, UserPlus, ShieldOff,
  Check, CheckCheck, Pin, PinOff, Phone,
  Megaphone, BarChart3, Zap, Eye, EyeOff, Star, Paperclip, ChevronDown, Link2, Globe, ImagePlus,
  AlertTriangle, Copy, Forward, AtSign, CircleDot, Sparkles, VenetianMask, Settings, PieChart,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { supabase } from '../../shared/lib/supabase'
import { nameStyleFor } from '../../shared/lib/displayNameStyle'
import { updateMissionProgress, trackWeeklyUniqueValue } from '../missions/weeklyMissions'
import { pickHaloStaticReply } from './haloStaticReplies'
import { matchDynamicHaloFlow, type HaloWidget } from './haloDynamicReplies'
import { matchHaloActionFlow, changeUsernameAction, registerForEliminationAction, buyMallItemAction, type PendingHaloAction, type HaloActionContext, type HaloAction } from './haloActionFlows'
import RankCardWidget from './haloWidgets/RankCardWidget'
import OnlineActivityWidget from './haloWidgets/OnlineActivityWidget'
import GameCardWidget from './haloWidgets/GameCardWidget'
import HaloUsernameConfirmCard from './haloWidgets/HaloUsernameConfirmCard'
import HaloEventCard from './haloWidgets/HaloEventCard'
import HaloMallCard from './haloWidgets/HaloMallCard'
import HaloWalletCard from './haloWidgets/HaloWalletCard'
import { notifyMessage, notifyRankTag, notifyMention } from '../achievements/achievements'
import { useAuth } from '../auth/useAuth'
import PageOnboarding from '../onboarding/PageOnboarding'
import StartCallButton from './calling/StartCallButton'
import VoiceNoteRecorderButton from './voiceNotes/VoiceNoteRecorderButton'
import VoiceNotePlayer from './voiceNotes/VoiceNotePlayer'
import { uploadVoiceNote } from './voiceNotes/voiceNoteStorage'
import type { VoiceRecorderResult } from './voiceNotes/useVoiceRecorder'
import ReportModal from '../safety/ReportModal'
import { containsProfanity, PROFANITY_BLOCKED_MESSAGE } from '../../shared/lib/profanityFilter'
import { isProActive } from '../../shared/lib/proPlans'
import HiddenContentNotice from '../moderation/HiddenContentNotice'
import { useModRole } from '../moderation/useModRole'
import { useOnlineUserIds } from '../../context/OnlinePresence'
import { RANK_GROUPS, type RankGroupId } from '../profile/ranks'
import QotdCard from './QotdCard'
import QuickPoll from './QuickPoll'
import DiscoverManageModal from './DiscoverManageModal'
import DuoRow from '../duo/DuoRow'
import DuoRequestCard from '../duo/DuoRequestCard'
import { useDuo } from '../duo/useDuo'
import TrendingNow from './TrendingNow'
import PollMessage from './PollMessage'
import PollComposerModal from './PollComposerModal'
import StarredMessagesPanel from './StarredMessagesPanel'
import { starMessage, unstarMessage, fetchMyStarredMessageIds } from './starredMessages'
import DmRequestBar from './DmRequestBar'
import { dmRequestStateOf, isDmRequestRejection } from './dmRequests'
import { useProfilePreview } from '../../context/ProfilePreview'
import { useFeatureFlags } from '../../shared/lib/featureFlags'
import FeatureGateScreen from '../../shared/components/FeatureGateScreen'
import GlobalInviteModal from '../clubs/GlobalInviteModal'
import { joinGlobal } from '../clubs/invites'
import { renderMessageContent, firstExternalHost } from './messageContent'
import { ReactionRow, type MessageReaction } from './MessageBubble'
import ReactorsSheet from './ReactorsSheet'
import { uploadChatImage, validateChatImage, MAX_CHAT_IMAGE_BYTES, MAX_FREE_CHAT_IMAGE_BYTES } from './chatImages'
import Toast, { useToast } from '../../shared/components/Toast'
import VerifiedBadge from '../../shared/components/VerifiedBadge'

// ─── Types ──────────────────────────────────────────────────
interface RoomMember {
  user_id: string
  profile: { username: string; display_name: string | null; avatar: string; display_name_font?: string | null; display_name_color?: string | null; is_official?: boolean | null; is_halo_ai?: boolean | null; is_groove_official?: boolean | null; is_pvp_official?: boolean | null; is_warden_official?: boolean | null }
}
interface ChatRoom {
  id: string
  type: string
  name: string | null
  members: RoomMember[]
  lastMsg: string
  lastMsgId: string | null // the message currently shown as lastMsg — lets a later deletion of that exact message swap in "Message deleted" instead of a stale preview
  lastMsgSenderId: string | null
  lastMsgTime: string
  lastMsgAt: string | null // raw ISO timestamp, used for recency sort (lastMsgTime is pre-formatted for display only)
  unread: number
  pinned: boolean
  clearedAt: string | null // messages at/before this timestamp are hidden for me (soft clear)
  pinnedMessageId: string | null // room-wide pinned message, visible to all members
  spotlightMessageId: string | null // temporary pin (Staff/Mod/Admin, Global Chat only) — see migration 0040
  spotlightExpiresAt: string | null
  // A first-time DM lands as a request: the recipient sees the one message
  // the sender was allowed to write, then accepts / declines / blocks.
  // null dmAcceptedAt on a 'dm' room IS the pending state. See 0175b.
  dmInitiatorId: string | null
  dmAcceptedAt: string | null
}
interface Message {
  id: string
  sender_id: string | null
  content: string
  created_at: string
  deleted: boolean
  hidden: boolean
  hidden_reason: string | null
  reply_to_id: string | null
  replyPreview?: string
  /** Display name of whoever sent the message being replied to — shown stacked
   *  above the reply, since names are otherwise hidden outside of reply context. */
  replyPreviewName?: string
  senderName?: string
  senderNameFont?: string | null
  senderNameColor?: string | null
  senderUsername?: string
  /** 'text' (default) | 'voice_note' | 'call_log' | 'rank_tag' | 'poll' — see migrations 0009, 0038, 0039. */
  type: MessageType
  audio_path: string | null
  audio_duration_seconds: number | null
  call_id: string | null
  /** Set only when type === 'rank_tag' — one of the 8 RANK_GROUP_IDS. */
  rank_tag_group: string | null
  /** Set only when type === 'poll'. */
  poll_id: string | null
  /** Public `chat-images` URL when the message carries a picture (migration
   *  0119). Independent of `type`, so an admin broadcast can be text + image. */
  image_url: string | null
  /** Client-side only — never in the DB, never selected off the wire. Set
   *  only on local-only Halo DM replies (see maybeQueueHaloAutoReply) to
   *  show a rank/activity card under the text. Ordinary messages never
   *  have this. */
  haloWidget?: HaloWidget
}
type MessageType = 'text' | 'voice_note' | 'call_log' | 'rank_tag' | 'poll' | 'broadcast' | 'duo_request'
/** Shape of a message row straight off the wire, before openRoom/loadOlderMessages/
 *  jumpToMessage enrich it with sender name, reply preview, etc. */
type RawMessageRow = Omit<Message, 'replyPreview' | 'replyPreviewName' | 'senderName' | 'senderNameFont' | 'senderNameColor' | 'senderUsername'>
interface SearchedProfile {
  id: string
  username: string
  display_name: string | null
  avatar: string
}

/** Read-receipt state for one of MY OWN messages: 'sent' = persisted but not yet
 *  confirmed read by the other DM member, 'read' = their last_read_at has passed
 *  this message's created_at. Only computed for DMs — global chat has too many
 *  members for a single "read" state to mean anything. */
type ReadReceipt = 'sent' | 'read' | null

/** Result of checking the `blocks` table for the two members of an open DM. */
type DmBlockState = 'none' | 'blockedByMe' | 'blockedMe'

/** Pre-processed render-ready message with consecutive-group metadata. */
interface GroupedMessage extends Message {
  isGroupFirst: boolean
  isGroupLast: boolean
}

const GROUP_GAP_MS = 5 * 60 * 1000 // 5 min — new burst starts after this gap
const MESSAGE_PAGE_SIZE = 30 // most-recent-page size for initial load + each "load older" fetch
const MAX_MESSAGE_LENGTH = 2000 // must match the `messages.content` check constraint in the DB
const COMPOSER_MAX_HEIGHT = 120 // px — cap for the auto-growing composer before it scrolls internally
const TYPING_IDLE_MS = 3000 // stop broadcasting "typing" after this long without a keystroke
const NEAR_BOTTOM_PX = 150 // how close to the bottom counts as "already reading the latest"
const MARK_READ_THROTTLE_MS = 2000 // minimum gap between last_read_at writes

/** Splits a flat message list into consecutive-sender "bursts" for compact rendering. */
function groupMessages(messages: Message[]): GroupedMessage[] {
  return messages.map((m, i) => {
    const prev = messages[i - 1]
    const next = messages[i + 1]
    const isStandalone = (t: MessageType) => t === 'rank_tag' || t === 'poll' || t === 'duo_request'
    const isGroupFirst = !prev || prev.sender_id !== m.sender_id || isStandalone(prev.type) || isStandalone(m.type) ||
      (new Date(m.created_at).getTime() - new Date(prev.created_at).getTime()) > GROUP_GAP_MS
    const isGroupLast = !next || next.sender_id !== m.sender_id || isStandalone(next.type) || isStandalone(m.type) ||
      (new Date(next.created_at).getTime() - new Date(m.created_at).getTime()) > GROUP_GAP_MS
    return { ...m, isGroupFirst, isGroupLast }
  })
}

const EMOJIS = ['😂','🔥','💀','👑','😍','🎮','💯','🙌','😅','🤯','❤️','👀','🫡','💪','🏆']

/** Resolves @username tokens in a just-sent message against the room's current
 *  membership, so we know who to notify. Deliberately client-side "best effort"
 *  only — notify_mention() re-verifies every id is actually a room member (and
 *  drops the sender) server-side before sending anything, so a stale or
 *  spoofed id here is a no-op, not a way to reach someone who shouldn't be
 *  notified. */
function extractMentionedUserIds(content: string, members: RoomMember[], myId: string | null): string[] {
  const matches = content.match(/@([a-zA-Z0-9_]{2,32})/g)
  if (!matches) return []
  const usernames = new Set(matches.map(m => m.slice(1).toLowerCase()))
  const ids = new Set<string>()
  for (const mb of members) {
    if (mb.user_id !== myId && usernames.has(mb.profile.username.toLowerCase())) ids.add(mb.user_id)
  }
  return [...ids]
}

/** Message body rendering (member @mentions in accent colour, links in blue)
 *  now lives in ./messageContent so Clubs renders identically. */

function IBtn({ onClick, children, style, title }: {
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void
  children: React.ReactNode
  style?: React.CSSProperties
  title?: string
}) {
  return (
    <button type="button" onClick={onClick} title={title} className="neu-icon"
      style={{ width:36, height:36, border:'none', color:'var(--text-dim)', cursor:'pointer', flexShrink:0, transition:'color 0.15s', ...style }}
      onMouseEnter={e => { e.currentTarget.style.color = 'var(--text)' }}
      onMouseLeave={e => { e.currentTarget.style.color = 'var(--text-dim)' }}>
      {children}
    </button>
  )
}

function Avatar({ name, avatarUrl, size = 40, radius = 13 }: { name: string; avatarUrl?: string | null; size?: number; radius?: number }) {
  const [broken, setBroken] = useState(false)
  // Reset the "broken" flag whenever the source changes (e.g. after an upload).
  useEffect(() => { setBroken(false) }, [avatarUrl])

  const colors = ['#ff6b6b','#4f8ef7','#9b6dff','#3ecf8e','#f5c542','#ff4d8b','var(--accent2)','#00e5ff']
  const color = colors[(name.charCodeAt(0) || 0) % colors.length]
  // 'rocket' is the DB default for profiles.avatar (set on signup) — it
  // means "no avatar equipped", not a literal picture to load. Anyone with
  // no avatar, an empty avatar, or 'rocket' falls back to their initial —
  // same as anyone whose equipped picture fails to load.
  const hasNoAvatar = !avatarUrl || avatarUrl === 'rocket'
  const showImage = !hasNoAvatar && !broken

  if (showImage) {
    return (
      <img
        src={avatarUrl as string}
        alt={name}
        style={{ width:size, height:size, borderRadius:radius, objectFit:'cover', flexShrink:0, display:'block' }}
        onError={() => setBroken(true)}
      />
    )
  }
  return (
    <div style={{ width:size, height:size, borderRadius:radius, background:color, color:'#fff', fontWeight:700, fontSize:size*0.35, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
      {(name || '?').charAt(0).toUpperCase()}
    </div>
  )
}

/** Small green presence dot, absolutely positioned over the bottom-right corner
 *  of whatever avatar it's rendered alongside. Caller wraps both in a `position:
 *  relative` container. */
function OnlineDot({ size = 10 }: { size?: number }) {
  return (
    <span style={{
      position:'absolute', right:-1, bottom:-1, width:size, height:size, borderRadius:'50%',
      background:'#3ecf8e', border:'2px solid var(--surface)', boxShadow:'0 0 0 1px rgba(0,0,0,0.15)',
    }} />
  )
}

function SkeletonBubbles() {
  const widths = [62, 38, 71, 48]
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:12, padding:'4px 0' }}>
      {widths.map((w, i) => (
        <div key={i} style={{ display:'flex', flexDirection: i % 2 ? 'row-reverse' : 'row', gap:8 }}>
          <div style={{ width:30, height:30, borderRadius:10, background:'var(--surface2)', flexShrink:0, animation:'skeletonPulse 1.4s ease-in-out infinite' }} />
          <div style={{ width:`${w}%`, maxWidth:260, height:44, borderRadius:16, background:'var(--surface2)', animation:'skeletonPulse 1.4s ease-in-out infinite' }} />
        </div>
      ))}
    </div>
  )
}

function SkeletonRoomList() {
  return (
    <div style={{ display:'flex', flexDirection:'column' }}>
      {[0, 1, 2, 3, 4].map(i => (
        <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 16px' }}>
          <div style={{ width:44, height:44, borderRadius:13, flexShrink:0, background:'var(--surface2)', animation:'skeletonPulse 1.4s ease-in-out infinite' }} />
          <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:6 }}>
            <div style={{ width: i % 2 ? '55%' : '40%', height:13, borderRadius:4, background:'var(--surface2)', animation:'skeletonPulse 1.4s ease-in-out infinite' }} />
            <div style={{ width: i % 2 ? '75%' : '60%', height:11, borderRadius:4, background:'var(--surface2)', animation:'skeletonPulse 1.4s ease-in-out infinite' }} />
          </div>
        </div>
      ))}
    </div>
  )
}

/** One row of message_reactions. The table's primary key is
 *  (message_id, user_id, emoji), which is also exactly what a realtime DELETE
 *  payload carries — so these three fields are all the client ever needs. */
interface ReactionRowData {
  message_id: string
  user_id: string
  emoji: string
}

/** The row of one-tap reactions at the top of the message action sheet.
 *  Same six Discord leads with, and the same set Clubs uses. */
const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥']

interface MessageLineProps {
  msg: GroupedMessage
  isMine: boolean
  onContextMenu: (msg: Message, x: number, y: number) => void
  onDoubleClick: (msg: Message) => void
  formatTime: (iso: string) => string
  readReceipt: ReadReceipt
  /** Whether the viewer has starred this message — DMs only, shows a small badge. */
  isStarred: boolean
  /** Whether this is a Global Chat thread (as opposed to a DM) — used to decide
   *  whether a received bubble's leading corner should defer to the name row
   *  shown above the first message of a group. */
  isGroupChat: boolean
  /** Tapping the reply-quote header on a message jumps back to (and briefly
   *  flashes) the original message it replied to. Fires with reply_to_id;
   *  no-op if the message isn't a reply. */
  onJumpToReply: (replyToId: string) => void
  /** True for the ~1.6s right after a jump-to-message lands on this bubble —
   *  drives the brief highlight flash so the reader can find it. */
  isHighlighted: boolean
  /** Registers/unregisters this message's DOM node so jump-to-message can
   *  scrollIntoView it without a full re-query of the list. */
  registerRef: (id: string, el: HTMLDivElement | null) => void
  /** Current room membership — used only to recognize which @tokens in this
   *  message's content are real mentions worth highlighting. */
  members: RoomMember[]
  /** Emoji reactions on this message, already tallied. */
  reactions: MessageReaction[]
  onOpenReactors: (msg: Message, emoji: string) => void
  /** Fires when a Halo action-card button (Confirm, Register Me, Buy, ...)
   *  is tapped. Only ever relevant for messages with a haloWidget. */
  onHaloAction: (msg: Message, action: HaloAction) => void
  /** Which action-card button (if any) is mid-request right now — see
   *  haloActionBusyKey in the parent for the key format. */
  haloActionBusyKey: string | null
}

/** Small diagonal corner-bracket accent, absolutely positioned over one corner
 *  of a bubble. Two of these (an opposite diagonal pair) frame each message:
 *  top-left + bottom-right for received bubbles, top-right + bottom-left for
 *  sent ones — matching the app's accent color instead of a flat border. */
function BracketCorner({ position, color = 'var(--accent)' }: {
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'
  color?: string
}) {
  const size = 10
  const thickness = 1.5
  const base: React.CSSProperties = { position:'absolute', width:size, height:size, pointerEvents:'none' }
  const placement: Record<string, React.CSSProperties> = {
    'top-left':     { top:-1, left:-1, borderTop:`${thickness}px solid ${color}`, borderLeft:`${thickness}px solid ${color}`, borderTopLeftRadius:3 },
    'top-right':    { top:-1, right:-1, borderTop:`${thickness}px solid ${color}`, borderRight:`${thickness}px solid ${color}`, borderTopRightRadius:3 },
    'bottom-left':  { bottom:-1, left:-1, borderBottom:`${thickness}px solid ${color}`, borderLeft:`${thickness}px solid ${color}`, borderBottomLeftRadius:3 },
    'bottom-right': { bottom:-1, right:-1, borderBottom:`${thickness}px solid ${color}`, borderRight:`${thickness}px solid ${color}`, borderBottomRightRadius:3 },
  }
  return <span style={{ ...base, ...placement[position] }} />
}

/** One message, rendered as a neomorphic "soft" bubble framed by a diagonal
 *  pair of accent corner-brackets — sized to that message's own content,
 *  never to a sibling's. Consecutive messages from the same sender stack by
 *  simply rendering several of these one after another; each one keeps (and
 *  is pushed down by) its own bubble instead of one shared shape stretching
 *  to fit whatever's widest in the stack. On a received bubble that opens a
 *  Global Chat group, the leading (top-left) corner is skipped — the name
 *  row rendered above the burst already marks that edge, so the bracket
 *  would otherwise double up right next to it. */
const MessageLine = memo(function MessageLine({
  msg, isMine, onContextMenu, onDoubleClick, formatTime, readReceipt, isStarred, isGroupChat,
  onJumpToReply, isHighlighted, registerRef, members, reactions, onOpenReactors,
  onHaloAction, haloActionBusyKey,
}: MessageLineProps) {
  const showLeadingCorner = !(isGroupChat && !isMine && msg.isGroupFirst)
  return (
    <>
    <div
      ref={el => registerRef(msg.id, el)}
      className="msg-bubble-col"
      onContextMenu={e => { if (!msg.deleted) { e.preventDefault(); onContextMenu(msg, e.clientX, e.clientY) } }}
      onDoubleClick={() => onDoubleClick(msg)}
      style={{
        position:'relative', cursor:'context-menu', userSelect:'none',
        // `width: fit-content` (rather than plain `inline-block`, which falls
        // back to filling all available space once the text needs to wrap)
        // is what keeps this bubble sized to whatever the longest actual
        // rendered line is, instead of stretching out to the full bubble
        // column width for any message that happens to wrap onto more than
        // one line.
        display:'inline-block', width:'fit-content', maxWidth:'100%',
        marginBottom:4,
        padding:'5px 9px',
        borderRadius:8,
        background: isHighlighted ? 'color-mix(in srgb, var(--accent) 22%, var(--surface))' : 'var(--surface)',
        boxShadow: isHighlighted
          ? '0 0 0 1.5px var(--accent), 3px 3px 7px rgba(10,10,12,0.45), -2px -2px 5px rgba(38,38,48,0.35)'
          : '3px 3px 7px rgba(10,10,12,0.45), -2px -2px 5px rgba(38,38,48,0.35)',
        transition: 'background-color 0.4s ease, box-shadow 0.4s ease',
      }}>

      {!isMine && showLeadingCorner && <BracketCorner position="top-left" />}
      {!isMine && <BracketCorner position="bottom-right" />}
      {isMine && <BracketCorner position="top-right" />}
      {isMine && <BracketCorner position="bottom-left" />}

      {/* Reply quote — a distinct tinted, left-accented pill (not just stacked
          text) so it reads as a quoted reference rather than part of the
          message itself. Tapping it jumps back to (and briefly highlights)
          the original message; this is the ONLY place a name appears on a
          received message — own messages never show a name at all. */}
      {msg.replyPreview && !msg.deleted && (
        <div
          onClick={e => { e.stopPropagation(); if (msg.reply_to_id) onJumpToReply(msg.reply_to_id) }}
          style={{
            marginBottom:4, padding:'4px 8px', borderRadius:7,
            display:'flex', flexDirection:'column', alignItems:'flex-start',
            maxWidth:220,
            background:'color-mix(in srgb, var(--accent) 12%, transparent)',
            borderLeft:'2.5px solid var(--accent)',
            cursor: msg.reply_to_id ? 'pointer' : 'default',
          }}>
          <span style={{ fontSize:10, fontWeight:700, color:'var(--accent)' }}>{msg.replyPreviewName || 'Unknown'}</span>
          <span style={{ fontSize:10.5, color:'var(--text-dim)', maxWidth:200, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {msg.replyPreview.length > 60 ? `${msg.replyPreview.slice(0, 60)}…` : msg.replyPreview}
          </span>
        </div>
      )}

      {/* Message content, with the timestamp/ticks flowing inline right after the
          text — plain inline flow (no flex-shrink) so short text like "hey" can
          never get squeezed into a one-letter-per-line collapse. Text wraps at
          word boundaries the normal way only once it's actually too long. */}
      {/* Official badge — an admin broadcast is a real DM, so without this it
          would be indistinguishable from that admin typing to you personally. */}
      {msg.type === 'broadcast' && !msg.deleted && !msg.hidden && (
        <div style={{
          display:'inline-flex', alignItems:'center', gap:4, marginBottom:4,
          fontSize:9, fontWeight:800, letterSpacing:'0.05em', textTransform:'uppercase',
          color:'var(--accent)', background:'color-mix(in srgb, var(--accent) 14%, transparent)',
          border:'1px solid color-mix(in srgb, var(--accent) 32%, transparent)',
          borderRadius:6, padding:'1px 6px',
        }}>
          <Megaphone size={9} /> Official
        </div>
      )}

      {/* Picture, when the message carries one. Sits above the text so a
          broadcast can be caption-style: image first, then the body. */}
      {msg.image_url && !msg.deleted && !msg.hidden && (
        <img
          src={msg.image_url}
          alt=""
          loading="lazy"
          onClick={e => { e.stopPropagation(); window.open(msg.image_url!, '_blank', 'noopener,noreferrer') }}
          style={{
            display:'block', maxWidth:'min(240px, 100%)', maxHeight:280,
            width:'auto', height:'auto', borderRadius:7, marginBottom:4,
            objectFit:'cover', cursor:'zoom-in', background:'var(--surface2)',
          }}
        />
      )}

      <span style={{ fontSize:12.5, lineHeight:1.4, color:'var(--text)', fontStyle: msg.deleted ? 'italic' : 'normal', opacity: msg.deleted ? 0.6 : 1, wordBreak:'break-word', whiteSpace:'pre-wrap' }}>
        {msg.hidden ? (
          <HiddenContentNotice reason={msg.hidden_reason} isOwner={isMine} inline />
        ) : msg.deleted ? 'Message deleted' : msg.type === 'voice_note' ? (
          msg.audio_path ? (
            <VoiceNotePlayer audioPath={msg.audio_path} durationSeconds={msg.audio_duration_seconds ?? 0} />
          ) : (
            <span style={{ fontStyle:'italic', opacity:0.75 }}>Uploading voice note…</span>
          )
        ) : msg.type === 'call_log' ? (
          <span style={{ display:'inline-flex', alignItems:'center', gap:6 }}>
            <Phone size={13} />
            {msg.content}
            {msg.audio_duration_seconds ? ` · ${Math.floor(msg.audio_duration_seconds / 60)}:${String(msg.audio_duration_seconds % 60).padStart(2, '0')}` : ''}
          </span>
        ) : msg.image_url && msg.content === '📷 Photo' ? null : renderMessageContent(msg.content, members)}
        {' '}
        <span style={{ display:'inline-flex', alignItems:'center', gap:2, whiteSpace:'nowrap' }}>
          {isStarred && <Star size={9} fill="#ffc107" style={{ color:'#ffc107' }} />}
          <span style={{ fontSize:9.5, color:'var(--text-muted)' }}>{formatTime(msg.created_at)}</span>
          {isMine && !msg.deleted && readReceipt === 'read' && <CheckCheck size={11} style={{ color:'var(--accent)' }} />}
          {isMine && !msg.deleted && readReceipt === 'sent' && <Check size={11} style={{ color:'var(--text-muted)' }} />}
        </span>
      </span>

      {/* Halo rich card — rank badge, activity chart, or one of the
          action-system cards (username change, event registration, Mall,
          wallet). Client-side only, never persisted (see Message.haloWidget). */}
      {msg.haloWidget && !msg.deleted && !msg.hidden && (
        msg.haloWidget.type === 'rank' ? (
          <RankCardWidget widget={msg.haloWidget} />
        ) : msg.haloWidget.type === 'online_activity' ? (
          <OnlineActivityWidget widget={msg.haloWidget} />
        ) : msg.haloWidget.type === 'username_change' ? (
          <HaloUsernameConfirmCard
            widget={msg.haloWidget}
            busy={haloActionBusyKey === msg.id}
            onConfirm={() => {
              const w = msg.haloWidget
              onHaloAction(msg, { type: 'confirm_username_change', newUsername: w && w.type === 'username_change' ? w.newUsername : '' })
            }}
            onCancel={() => onHaloAction(msg, { type: 'cancel_username_change' })}
          />
        ) : msg.haloWidget.type === 'event_preview' ? (
          <HaloEventCard
            widget={msg.haloWidget}
            busy={haloActionBusyKey === msg.id}
            onRegister={() => onHaloAction(msg, { type: 'register_elimination' })}
          />
        ) : msg.haloWidget.type === 'mall_preview' ? (
          <HaloMallCard
            widget={msg.haloWidget}
            busyItemId={haloActionBusyKey?.startsWith(`${msg.id}:`) ? haloActionBusyKey.slice(msg.id.length + 1) : null}
            boughtIds={new Set(msg.haloWidget.items.filter(it => it.owned).map(it => it.id))}
            onBuy={(itemId, itemName) => onHaloAction(msg, { type: 'buy_mall_item', itemId, itemName })}
          />
        ) : msg.haloWidget.type === 'game' ? (
          <GameCardWidget widget={msg.haloWidget} />
        ) : (
          <HaloWalletCard widget={msg.haloWidget} />
        )
      )}
    </div>
    {reactions.length > 0 && (
      <ReactionRow reactions={reactions} isMine={isMine} onOpenReactors={emoji => onOpenReactors(msg, emoji)} />
    )}
    </>
  )
})

/** Distinct full-width "official" card for a Staff/Moderator/Admin rank tag —
 *  deliberately not styled like MessageLine's bracket-cornered chat bubbles,
 *  so it reads as an announcement rather than a regular message. Global Chat
 *  only. */
const RankTagAnnouncement = memo(function RankTagAnnouncement({
  msg, senderLabel, formatTime, myId,
}: {
  msg: Message
  senderLabel: string
  formatTime: (iso: string) => string
  myId: string | null
}) {
  const group = RANK_GROUPS.find(g => g.id === msg.rank_tag_group)
  const color = group?.color ?? '#f5c542'
  return (
    <div style={{ margin: '10px 0', padding: '10px 14px', borderRadius: 14, background: `${color}14`, border: `1px solid ${color}55` }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
        <Megaphone size={13} style={{ color, flexShrink: 0 }} />
        <span style={{ fontSize: 11, fontWeight: 800, color, textTransform: 'uppercase', letterSpacing: 0.3 }}>
          @{group?.label ?? 'Rank'} tagged — by {senderLabel}
        </span>
        <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 'auto', flexShrink: 0 }}>{formatTime(msg.created_at)}</span>
      </div>
      <div style={{ fontSize: 13.5, lineHeight: 1.45, color: 'var(--text)', fontStyle: msg.deleted ? 'italic' : 'normal', opacity: msg.deleted ? 0.6 : 1 }}>
        {msg.hidden ? (
          <HiddenContentNotice reason={msg.hidden_reason} isOwner={msg.sender_id === myId} />
        ) : msg.deleted ? 'Message deleted' : msg.content}
      </div>
    </div>
  )
})

interface MessageBurstProps {
  burst: GroupedMessage[]
  isMine: boolean
  senderLabel: string
  senderNameFont?: string | null
  senderNameColor?: string | null
  avatarUrl: string | null
  onOpenProfile: (msg: Message) => void
  onContextMenu: (msg: Message, x: number, y: number) => void
  onDoubleClick: (msg: Message) => void
  formatTime: (iso: string) => string
  readReceiptFor: (msg: Message) => ReadReceipt
  /** Message ids the viewer has starred — used to show the badge (DMs only). */
  starredIds: Set<string>
  /** Avatars only make sense where more than two people share the thread (Global
   *  Chat) — a DM never shows one, since which side of the screen a message sits
   *  on already identifies the sender. Even in Global Chat this only ever renders
   *  for other people's messages (see the `!isMine` check below); your own
   *  avatar is never shown, for the same reason a DM never shows one for you. */
  isGroupChat: boolean
  onJumpToReply: (replyToId: string) => void
  highlightedMsgId: string | null
  registerRef: (id: string, el: HTMLDivElement | null) => void
  members: RoomMember[]
  reactionsFor: (msg: Message) => MessageReaction[]
  onOpenReactors: (msg: Message, emoji: string) => void
  onHaloAction: (msg: Message, action: HaloAction) => void
  haloActionBusyKey: string | null
}

/** A consecutive run of messages from one sender. The avatar (Global Chat only,
 *  and only for other senders — never your own) appears once per burst, aligned
 *  to the bottom line. Each message underneath keeps rendering its own
 *  independent chat-line — replying, or just sending another message, always
 *  starts a new line of its own width, simply pushed further down the stack
 *  rather than widening anything above it. */
const MessageBurst = memo(function MessageBurst({
  burst, isMine, senderLabel, senderNameFont, senderNameColor, avatarUrl,
  onOpenProfile, onContextMenu, onDoubleClick, formatTime, readReceiptFor, starredIds, isGroupChat,
  onJumpToReply, highlightedMsgId, registerRef, members, reactionsFor, onOpenReactors,
  onHaloAction, haloActionBusyKey,
}: MessageBurstProps) {
  const first = burst[0]

  // Duo request — a live accept/reject card, not a chat bubble. This lives
  // here because Chat.tsx renders its own MessageBurst; the copy in
  // MessageBubble.tsx is only used by ClubChat, so patching that one alone
  // left the card invisible in DMs (which is where duo requests land).
  if (first.type === 'duo_request') {
    return (
      <DuoRequestCard
        senderId={first.sender_id ?? ''}
        content={first.content}
        isMine={isMine}
      />
    )
  }

  return (
    <div style={{ display:'flex', flexDirection: isMine ? 'row-reverse' : 'row', alignItems:'flex-start', gap:6, marginBottom:4 }}>
      {isGroupChat && !isMine && (
        <button
          type="button"
          onClick={() => onOpenProfile(first)}
          style={{ background:'none', border:'none', padding:0, cursor:'pointer', flexShrink:0 }}
          title={senderLabel}>
          <Avatar name={senderLabel} avatarUrl={avatarUrl} size={30} radius={10} />
        </button>
      )}

      <div style={{ display:'flex', flexDirection:'column', alignItems: isMine ? 'flex-end' : 'flex-start', maxWidth:'78%' }}>
        {/* Sender name — Global Chat only, and only for other players' messages;
            your own messages never get one, since you already know who sent them. */}
        {isGroupChat && !isMine && (() => {
          const senderProfile = members.find(mb => mb.user_id === first.sender_id)?.profile
          const senderIsBadged = senderProfile?.is_official === true || senderProfile?.is_halo_ai === true || senderProfile?.is_groove_official === true || senderProfile?.is_pvp_official === true || senderProfile?.is_warden_official === true
          return (
            <span style={{ display:'inline-flex', alignItems:'center', gap:4, marginBottom:3, marginLeft:2 }}>
              <span style={{ fontSize:11.5, fontWeight:700, color:'#4f8ef7', ...nameStyleFor({ display_name_font: senderNameFont, display_name_color: senderNameColor }) }}>
                {senderLabel}
              </span>
              {senderIsBadged && <VerifiedBadge size={12} />}
            </span>
          )
        })()}
        {burst.map(msg => (
          <MessageLine
            key={msg.id}
            msg={msg}
            isMine={isMine}
            onContextMenu={onContextMenu}
            onDoubleClick={onDoubleClick}
            formatTime={formatTime}
            readReceipt={readReceiptFor(msg)}
            isStarred={starredIds.has(msg.id)}
            isGroupChat={isGroupChat}
            onJumpToReply={onJumpToReply}
            isHighlighted={msg.id === highlightedMsgId}
            registerRef={registerRef}
            members={members}
            reactions={reactionsFor(msg)}
            onOpenReactors={onOpenReactors}
            onHaloAction={onHaloAction}
            haloActionBusyKey={haloActionBusyKey}
          />
        ))}
        {/* Automated-account disclaimer, shown once under a run of messages
            from the official Chillverse account — the same idea as the
            "AI can make mistakes" line under an assistant reply. Rendered
            per burst rather than per message so a multi-line announcement
            doesn't repeat it on every bubble. */}
        {!isMine && (() => {
          const sender = members.find(mb => mb.user_id === first.sender_id)?.profile
          if (!sender || (!sender.is_official && !sender.is_halo_ai && !sender.is_groove_official && !sender.is_pvp_official && !sender.is_warden_official)) return null
          return (
            <span style={{
              fontSize: 9.5, lineHeight: 1.4, color: 'var(--text-muted)', fontStyle: 'italic',
              marginTop: 2, marginLeft: 2, maxWidth: 260, display: 'block',
            }}>
              {sender.display_name || sender.username} is an automated account, mistakes can be made, please double check responses.
            </span>
          )
        })()}
      </div>
    </div>
  )
})




interface ChatProps {
  /** Restricts which rooms this instance shows and swaps in the matching
   *  header UI — used by ChatHub to power the separate Global/Chats tabs.
   *  Omitted (undefined) keeps the original unified behavior. */
  roomFilter?: 'global' | 'dms'
  /** Fires whenever this instance switches between showing the room list
   *  and showing a full conversation with no list beside it. ChatHub uses
   *  this on mobile to hide the persistent icon rail while a conversation
   *  is open, so the chat gets the whole screen — matching how Discord's
   *  server rail disappears once you're inside a DM on mobile, instead of
   *  staying pinned and eating into the chat's width. */
  onFullScreenChatChange?: (fullScreen: boolean) => void
}

export default function Chat({ roomFilter, onFullScreenChatChange }: ChatProps = {}) {
  const { session } = useAuth()
  const { openProfilePreview } = useProfilePreview()
  const myId = session?.user?.id ?? null
  const { isStaff, canCreatePoll: canCreatePollByRole } = useModRole()
  const { isEnabled: isChatFlagEnabled, loading: chatFlagLoading } = useFeatureFlags()
  const navigate = useNavigate()
  const location = useLocation()

  // Staff-only Discover management sheet (gear next to the Discover header).
  const [discoverManageOpen, setDiscoverManageOpen] = useState(false)

  // Drives the Dynamic Duo section above the DM list. Live, because the
  // pair can end (or be blocked away) from another surface entirely.
  const { state: duoState } = useDuo(null, !!myId)

  const [rooms, setRooms] = useState<ChatRoom[]>([])
  const [roomsLoading, setRoomsLoading] = useState(true)
  const [activeRoom, setActiveRoom] = useState<ChatRoom | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [msgsLoading, setMsgsLoading] = useState(false)
  const [hasMoreOlder, setHasMoreOlder] = useState(false)
  const [loadingOlder, setLoadingOlder] = useState(false)
  const roomMembersRef = useRef<RoomMember[]>([])
  // ── Jump-to-message (reply taps + @mention notifications) ────
  // DOM nodes for every currently-mounted message bubble, keyed by id — lets
  // jumpToMessage scrollIntoView + flash a bubble without re-querying the list.
  const msgElRefs = useRef<Map<string, HTMLDivElement>>(new Map())
  const registerMsgRef = useCallback((id: string, el: HTMLDivElement | null) => {
    if (el) msgElRefs.current.set(id, el)
    else msgElRefs.current.delete(id)
  }, [])
  const [highlightedMsgId, setHighlightedMsgId] = useState<string | null>(null)
  const [jumpNotice, setJumpNotice] = useState<string | null>(null)
  const [jumpLoading, setJumpLoading] = useState(false)
  const creatingDmWithRef = useRef<Set<string>>(new Set()) // guards startDmWith against double-taps/slow-network races
  const [startingDmId, setStartingDmId] = useState<string | null>(null)
  const [dmStartError, setDmStartError] = useState<string | null>(null)
  // Both former always-visible search bars now live behind a header icon —
  // "Search chats" for the Chats tab, "Find players by username" for Global.
  const [roomSearchOpen, setRoomSearchOpen] = useState(false)
  const [playerSearchOpen, setPlayerSearchOpen] = useState(false)
  const [globalInviteOpen, setGlobalInviteOpen] = useState(false)
  useEffect(() => {
    if (!dmStartError) return
    const t = setTimeout(() => setDmStartError(null), 5000)
    return () => clearTimeout(t)
  }, [dmStartError])

  // Own profile (avatar, display_name, pro status) — loaded once on mount
  const [myProfile, setMyProfile] = useState<{ username: string; display_name: string | null; avatar: string | null; is_pro: boolean | null; pro_tier: string | null; pro_expires_at: string | null; username_changed_at: string | null } | null>(null)

  useEffect(() => {
    if (!myId) return
    let cancelled = false
    supabase.from('profiles').select('username, display_name, avatar, is_pro, pro_tier, pro_expires_at, username_changed_at').eq('id', myId).single()
      .then(({ data }) => { if (!cancelled && data) setMyProfile(data) })
    return () => { cancelled = true }
  }, [myId])
  const myIsPro = isProActive(myProfile)

  // Halo DM action system — see haloActionFlows.ts. Keyed per room id so a
  // "what would you like your new username to be?" outstanding in one DM
  // never leaks into another. A ref (not state) because updating it should
  // never itself trigger a re-render — it's only ever read right before the
  // next Halo reply is computed.
  const pendingHaloActionRef = useRef<Map<string, PendingHaloAction>>(new Map())
  // Tracks which single Halo action-card button is mid-request, so a second
  // tap on the same button (or a different one) is disabled while it runs.
  // Keyed by `${messageId}` for single-button cards, `${messageId}:${itemId}`
  // for the Mall card's per-item Buy buttons.
  const [haloActionBusyKey, setHaloActionBusyKey] = useState<string | null>(null)
  // Polls: Staff/Moderator/Admin and Verified always had this; Orbit and
  // Void plans now unlock it too (see proPlans.ts).
  const canCreatePoll = canCreatePollByRole || myIsPro
  // Pictures and voice notes are both advertised as Void-tier perks (see
  // Pro.tsx's compare table). Pictures are additionally personal-DM only —
  // Global Chat and Clubs stay text. Staff are exempt from the picture gate
  // so official/broadcast images still work.
  const myIsVoid = myIsPro && myProfile?.pro_tier === 'void'
  // Free users get one exception: the DM with the official Chillverse
  // account, so they can reply to a broadcast with a screenshot. Capped
  // lower (2MB) than the Void allowance, and re-checked server-side.
  const isOfficialDm = activeRoom?.type === 'dm'
    && activeRoom.members.some(mb => mb.user_id !== myId && (mb.profile.is_official === true || mb.profile.is_halo_ai === true || mb.profile.is_groove_official === true || mb.profile.is_pvp_official === true || mb.profile.is_warden_official === true))
  const canSendImages = activeRoom?.type === 'dm' && (myIsVoid || isStaff || isOfficialDm)
  const myImageLimitBytes = (myIsVoid || isStaff) ? MAX_CHAT_IMAGE_BYTES : MAX_FREE_CHAT_IMAGE_BYTES

  // Users I've blocked — used to hide their content everywhere in this view (most
  // importantly Global Chat, where the server can't reject their messages the way
  // it does for DMs, since they're still a legitimate member of that shared room).
  const [myBlockedIds, setMyBlockedIds] = useState<Set<string>>(new Set())
  useEffect(() => {
    if (!myId) return
    let cancelled = false
    supabase.from('blocks').select('blocked_id').eq('blocker_id', myId)
      .then(({ data }) => { if (!cancelled && data) setMyBlockedIds(new Set(data.map(b => b.blocked_id))) })
    return () => { cancelled = true }
  }, [myId])
  const handleBlockChange = useCallback((userId: string, blocked: boolean) => {
    setMyBlockedIds(prev => {
      const next = new Set(prev)
      if (blocked) next.add(userId); else next.delete(userId)
      return next
    })
  }, [])

  const [showConv, setShowConv] = useState(false)
  const [text, setText] = useState('')
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const { toast, showToast } = useToast()

  // Auto-grow the composer with its content. The textarea's `rows` attribute
  // never changes — without this, typing past one line just scrolled the
  // box's own single-line viewport (earlier words sliding up out of view)
  // instead of the box visibly getting taller like everywhere else. Runs on
  // every `text` change however it happened (typing, emoji insert, mention
  // insert, clearing after send) so it never falls out of sync with one path
  // and not another.
  useLayoutEffect(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, COMPOSER_MAX_HEIGHT)}px`
  }, [text])
  // @mention autocomplete — non-null mentionQuery means the caret currently sits
  // right after an "@partial-username" token; mentionStartIndex is where that
  // "@" sits in `text`, used to splice the picked username back in.
  const [mentionQuery, setMentionQuery] = useState<string | null>(null)
  const [mentionStartIndex, setMentionStartIndex] = useState<number | null>(null)
  const [sending, setSending] = useState(false)
  const [isRecordingVoiceNote, setIsRecordingVoiceNote] = useState(false)
  const [micError, setMicError] = useState<string | null>(null)
  useEffect(() => {
    if (!micError) return
    const t = setTimeout(() => setMicError(null), 4000)
    return () => clearTimeout(t)
  }, [micError])
  const [composerError, setComposerError] = useState<string | null>(null)
  useEffect(() => {
    if (!composerError) return
    const t = setTimeout(() => setComposerError(null), 4000)
    return () => clearTimeout(t)
  }, [composerError])
  const [reportTarget, setReportTarget] = useState<{ id: string; senderName: string } | null>(null)
  const [reactions, setReactions] = useState<ReactionRowData[]>([])

  // Search state — split: room search vs player search
  const [roomSearch, setRoomSearch] = useState('')
  const [playerSearch, setPlayerSearch] = useState('')
  const [playerResults, setPlayerResults] = useState<SearchedProfile[]>([])
  const [playerSearching, setPlayerSearching] = useState(false)

  const [emojiOpen, setEmojiOpen] = useState(false)
  // Composer action drawer — collapses emoji/rank-tag/poll icons behind a single
  // paperclip button, same retractable pattern as the conversation header drawer.
  const [composerDrawerOpen, setComposerDrawerOpen] = useState(false)
  const [ctxMsg, setCtxMsg] = useState<Message | null>(null)
  const [replyTo, setReplyTo] = useState<Message | null>(null)
  // Ghost Read (DMs only) — per-visit toggle, resets each time a room is opened
  // (see openRoom below). While active, markRoomAsRead is a no-op so the other
  // person's read receipt never flips for this visit.
  const [ghostReadActive, setGhostReadActive] = useState(false)
  // Rank Tag (Staff/Moderator/Admin, Global Chat only) — a pending tag attaches
  // to the next message sent, same pattern as replyTo above.
  const [rankTagPickerOpen, setRankTagPickerOpen] = useState(false)
  const [pendingRankTag, setPendingRankTag] = useState<RankGroupId | null>(null)
  // Polls (Staff/Moderator/Admin + Verified, Global Chat only)
  const [pollModalOpen, setPollModalOpen] = useState(false)
  const [pollRefreshToken, setPollRefreshToken] = useState(0)
  // Starred messages — private per-user bookmarks (see migration 0041)
  const [starredPanelOpen, setStarredPanelOpen] = useState(false)
  const [myStarredIds, setMyStarredIds] = useState<Set<string>>(new Set())

  // DM header options (tap avatar/name in DM to delete chat)
  const [dmOptionsOpen, setDmOptionsOpen] = useState(false)
  // Conversation-level 3-dot menu (top-right inside an open chat: clear chat, pin/unpin, block)
  const [convMenuOpen, setConvMenuOpen] = useState(false)
  // Pinned message banner content — fetched separately since ChatRoom only stores the id
  const [pinnedMsgPreview, setPinnedMsgPreview] = useState<{ id: string; content: string; senderName: string } | null>(null)
  const [spotlightMsgPreview, setSpotlightMsgPreview] = useState<{ id: string; content: string; senderName: string } | null>(null)
  // Spotlight — which message's context menu currently has its duration submenu open.
  const [spotlightPickerFor, setSpotlightPickerFor] = useState<Message | null>(null)
  const [spotlightCustomMinutes, setSpotlightCustomMinutes] = useState('')
  // Trending — set of Global Chat message ids currently promoted to
  // Trending Now, kept live so the context menu shows "Remove from
  // Trending" instead of "Send to Trending" once a message is already in.
  const [trendingMessageIds, setTrendingMessageIds] = useState<Set<string>>(new Set())
  // Forward — which message's context menu currently has its room-picker submenu open.
  const [forwardPickerFor, setForwardPickerFor] = useState<Message | null>(null)
  // Slide the bottom dock nav away while the message context menu (or one of
  // its submenus) is open, then bring it back when all of them close.
  useEffect(() => {
    const open = ctxMsg !== null || spotlightPickerFor !== null || forwardPickerFor !== null || discoverManageOpen
    document.body.classList.toggle('cv-popover-open', open)
    return () => { document.body.classList.remove('cv-popover-open') }
  }, [ctxMsg, spotlightPickerFor, forwardPickerFor, discoverManageOpen])
  // Per-room row menu in the room list (pin/delete), keyed by room id, null = closed
  const [roomMenuOpenFor, setRoomMenuOpenFor] = useState<string | null>(null)
  const [roomMenuPos, setRoomMenuPos] = useState({ x: 0, y: 0 })
  const [convMenuPos, setConvMenuPos] = useState({ x: 0, y: 0 })
  // Retractable action drawer in the conversation header — collapsed by default,
  // slides open horizontally to reveal call/search/menu icons, slides back in on toggle.
  const [headerDrawerOpen, setHeaderDrawerOpen] = useState(false)
  // In-conversation message search, opened from the header drawer's search icon.
  const [msgSearchOpen, setMsgSearchOpen] = useState(false)
  const [msgSearchQuery, setMsgSearchQuery] = useState('')

  const msgEnd = useRef<HTMLDivElement>(null)
  const subRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const playerSearchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ── Read receipts (DM only) — the other member's last_read_at, kept live via
  //    the room's realtime channel so ticks flip from sent → read without a reload.
  const [otherLastReadAt, setOtherLastReadAt] = useState<string | null>(null)
  // Keyed per room, not a single shared timestamp — a single shared ref meant
  // that opening room A then quickly switching to room B within the throttle
  // window silently dropped B's write entirely (not delayed it, DROPPED it),
  // leaving room B's last_read_at stale and its unread badge stuck even
  // though the user had genuinely read everything in it.
  const lastMarkReadAtRef = useRef<Map<string, number>>(new Map())

  // ── Block enforcement for the currently open DM ──────────────
  const [dmBlockState, setDmBlockState] = useState<DmBlockState>('none')
  // Derived, not stored: the room row already carries dm_initiator_id and
  // dm_accepted_at, so there is nothing to keep in sync. 'none' covers an
  // accepted DM and every non-DM room.
  const dmRequestState = activeRoom ? dmRequestStateOf(
    { type: activeRoom.type, dm_initiator_id: activeRoom.dmInitiatorId, dm_accepted_at: activeRoom.dmAcceptedAt },
    myId,
  ) : 'none'
  // The state above is 'outgoing' from the instant the room is created —
  // but the initiator is ALLOWED one message, so swapping the composer out
  // on that alone would lock them out before they'd written anything. The
  // notice only replaces the composer once that one message exists, which
  // is also exactly when the server-side trigger starts refusing.
  const dmRequestBlocking =
    dmRequestState === 'incoming' ||
    (dmRequestState === 'outgoing' && messages.some(m => m.sender_id === myId))

  // ── Presence: who's online app-wide, who's typing in THIS room ──
  const onlineUserIds = useOnlineUserIds()
  const [typingUserIds, setTypingUserIds] = useState<Set<string>>(new Set())
  const presenceChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  // Tracks whether we've already told the channel "typing: true" so
  // handleTextChange only sends one presence update per typing burst
  // instead of one per keystroke (see handleTextChange below).
  const isTypingRef = useRef(false)

  // ── Scroll behavior: 'bottom' snaps to the newest message, 'preserve' keeps
  //    the reading position stable after older history is prepended above it.
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const scrollModeRef = useRef<'none' | 'bottom' | 'preserve'>('none')
  const preserveScrollInfoRef = useRef<{ scrollHeight: number; scrollTop: number } | null>(null)
  const isNearBottomRef = useRef(true)
  // "New messages" divider — the id of the first unread message as of the
  // moment the room was opened (Discord-style). Fixed for the duration of
  // this viewing session; doesn't move as more messages arrive or get read.
  const [newMessagesBeforeId, setNewMessagesBeforeId] = useState<string | null>(null)
  // Jump-to-bottom pill — shown once the reader has scrolled away from the
  // latest message; the count badges how many new messages arrived while away.
  const [showJumpToBottom, setShowJumpToBottom] = useState(false)
  const [jumpToBottomCount, setJumpToBottomCount] = useState(0)

  const [isMobile, setIsMobile] = useState(window.innerWidth < 768)
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', handler)
    return () => window.removeEventListener('resize', handler)
  }, [])

  // ── App-wide online presence is now tracked once at the app root (see
  //    OnlinePresenceProvider in AppLayout) and read here via context —
  //    this used to open its own 'chat-online-presence' channel just for
  //    this screen, which meant presence only reflected "has Chat open",
  //    not "is anywhere in the app". See src/context/OnlinePresence.tsx.

  // ── Per-room typing presence — separate channel scoped to the open conversation ──
  useEffect(() => {
    if (!activeRoom || !myId) { setTypingUserIds(new Set()); return }
    const channel = supabase.channel(`chat-typing:${activeRoom.id}`, { config: { presence: { key: myId } } })
    presenceChannelRef.current = channel
    channel
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState<{ typing: boolean }>()
        const typing = new Set<string>()
        for (const [userId, metas] of Object.entries(state)) {
          if (userId === myId) continue
          if (metas.some(m => m.typing)) typing.add(userId)
        }
        setTypingUserIds(typing)
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') await channel.track({ typing: false })
      })

    // Backstop for the "stuck typing…" bug: the idle timeout in
    // handleTextChange is a plain setTimeout, which mobile browsers throttle
    // or pause entirely once a tab is backgrounded (switching apps, locking
    // the screen, swapping tabs). If someone was mid-typing when that
    // happened, the timeout that would've sent track({typing:false}) never
    // fires — the websocket itself stays connected in the background, so
    // presence doesn't time out either, and the indicator is stuck on the
    // other end until they come back and type again (or reload). Clearing
    // on visibilitychange catches the "left without finishing" case
    // immediately instead of relying on that timer.
    const clearTypingIfHidden = () => {
      if (document.visibilityState !== 'hidden') return
      if (typingTimeoutRef.current) { clearTimeout(typingTimeoutRef.current); typingTimeoutRef.current = null }
      if (isTypingRef.current) {
        isTypingRef.current = false
        channel.track({ typing: false })
      }
    }
    document.addEventListener('visibilitychange', clearTypingIfHidden)

    return () => {
      document.removeEventListener('visibilitychange', clearTypingIfHidden)
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
      isTypingRef.current = false
      // Same fix as the online-presence effect above: remove synchronously
      // so a fast room switch can't collide with a stale, still-subscribed
      // channel for the same topic.
      channel.untrack()
      supabase.removeChannel(channel)
      if (presenceChannelRef.current === channel) presenceChannelRef.current = null
    }
  }, [activeRoom?.id, myId])

  /** Room members matching the in-progress @mention token, self excluded,
   *  capped to a short list for the autocomplete dropdown. Shared between
   *  the dropdown's render and handleKey's Enter-to-select shortcut. */
  function mentionSuggestions(): RoomMember[] {
    if (mentionQuery === null || !activeRoom) return []
    const q = mentionQuery.toLowerCase()
    return activeRoom.members
      .filter(mb => mb.user_id !== myId)
      .filter(mb => mb.profile.username.toLowerCase().startsWith(q) || (mb.profile.display_name ?? '').toLowerCase().startsWith(q))
      .slice(0, 6)
  }

  /** Splices `@username ` in at the token the dropdown was triggered from,
   *  replacing whatever partial text the user had already typed. */
  function applyMention(member: RoomMember) {
    if (mentionStartIndex === null) return
    const cursor = textareaRef.current?.selectionStart ?? text.length
    const before = text.slice(0, mentionStartIndex)
    const after = text.slice(cursor)
    const insertion = `@${member.profile.username} `
    setText(before + insertion + after)
    setMentionQuery(null)
    setMentionStartIndex(null)
    requestAnimationFrame(() => {
      const el = textareaRef.current
      if (!el) return
      const pos = before.length + insertion.length
      el.focus()
      el.setSelectionRange(pos, pos)
    })
  }

  function handleTextChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    const value = e.target.value
    setText(value)

    // Detect an in-progress "@partial" token right at the caret — the same
    // pattern autocomplete uses everywhere: only opens when the "@" is at
    // the very start of the message or right after whitespace, so emails
    // and the like don't accidentally trigger it.
    const cursor = e.target.selectionStart ?? value.length
    const uptoCursor = value.slice(0, cursor)
    const match = uptoCursor.match(/(?:^|\s)@([a-zA-Z0-9_]{0,32})$/)
    if (match) {
      setMentionQuery(match[1])
      setMentionStartIndex(cursor - match[1].length - 1)
    } else {
      setMentionQuery(null)
      setMentionStartIndex(null)
    }

    const channel = presenceChannelRef.current
    if (!channel) return
    // Only send a presence update on the leading edge of a typing burst —
    // sending channel.track() on every keystroke was blowing through
    // Realtime's per-socket presence rate limit ("ClientPresenceRateLimitReached"
    // in the project logs) on fast typers. Because postgres_changes and
    // presence share one multiplexed websocket, getting rate-limited here
    // was silently starving the message INSERT feed for the rest of the
    // session — new messages stopped arriving in every open chat until a
    // full page reload re-established the socket.
    if (!isTypingRef.current) {
      isTypingRef.current = true
      channel.track({ typing: true })
    }
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    typingTimeoutRef.current = setTimeout(() => {
      isTypingRef.current = false
      channel.track({ typing: false })
    }, TYPING_IDLE_MS)
  }

  /** Clears typing presence the moment the composer loses focus, instead of
   *  waiting on the idle timeout — covers stepping away from the keyboard
   *  without waiting the full 3s (tapping elsewhere, switching apps). */
  function handleTextBlur() {
    if (typingTimeoutRef.current) { clearTimeout(typingTimeoutRef.current); typingTimeoutRef.current = null }
    if (isTypingRef.current) {
      isTypingRef.current = false
      presenceChannelRef.current?.track({ typing: false })
    }
  }

  /** Persists my read position for the active room, throttled so scrolling
   *  doesn't fire a write on every frame. Other member's UI updates via realtime. */
  const markRoomAsRead = useCallback((roomId: string) => {
    if (!myId || ghostReadActive) return
    const now = Date.now()
    const lastForRoom = lastMarkReadAtRef.current.get(roomId) ?? 0
    if (now - lastForRoom < MARK_READ_THROTTLE_MS) return
    lastMarkReadAtRef.current.set(roomId, now)
    supabase.from('room_members').update({ last_read_at: new Date().toISOString() })
      .eq('room_id', roomId).eq('user_id', myId)
      .then(({ error }) => { if (error) console.error('Failed to mark room as read:', error.message) })
  }, [myId, ghostReadActive])

  /** Rewinds my last-read position for a room to just before its most recent
   *  message, so it shows unread again in the room list. Reuses the same
   *  `room_members.last_read_at` column markRoomAsRead writes to — no new
   *  migration needed. */
  async function markRoomUnread(roomId: string) {
    if (!myId) return
    const room = rooms.find(r => r.id === roomId)
    const before = room?.lastMsgAt
      ? new Date(new Date(room.lastMsgAt).getTime() - 1000).toISOString()
      : new Date(0).toISOString()
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, unread: Math.max(r.unread, 1) } : r))
    const { error } = await supabase.from('room_members')
      .update({ last_read_at: before }).eq('room_id', roomId).eq('user_id', myId)
    if (error) console.error('Failed to mark room as unread:', error.message)
  }

  /** Copies a message's content into another room. Kept deliberately simple —
   *  doesn't duplicate sendMsg's mission-tracking/notification side effects;
   *  realtime subscriptions already pick up the insert for whichever room is
   *  currently open. */
  async function forwardMessage(targetRoomId: string, msg: Message) {
    if (!myId) return
    const { error } = await supabase.from('messages')
      .insert({ room_id: targetRoomId, sender_id: myId, content: msg.content })
    if (error) { showToast({ message: 'Forward failed. Please try again.', icon: AlertTriangle, iconColor: 'var(--red)' }); return }
    showToast({ message: 'Message forwarded', icon: Check })
  }

  // ── Ensure global chat room exists (Phase 2: no longer auto-joins) ─
  // Global Chat is invite-link-only now, same as clubs. This used to also
  // silently insert a room_members row for ANY logged-in user with no
  // gate at all — that's gone. Users who already had a room_members row
  // before this change keep it (grandfathered); new users only get in via
  // joinGlobal(code) / joinGlobalDirect() from the join screen, or the
  // `?code=` link-landing handled in loadRooms below.
  async function ensureGlobalRoom(): Promise<string | null> {
    if (!myId) return null

    const { data: globalRooms } = await supabase
      .from('chat_rooms')
      .select('id')
      .eq('type', 'global')
      .limit(1)

    if (globalRooms && globalRooms.length > 0) return globalRooms[0].id

    // Room doesn't exist yet at all (fresh environment) — create it, no membership insert.
    const { data: created, error: createErr } = await supabase
      .from('chat_rooms')
      .insert({ type: 'global', name: 'Global Chat' })
      .select('id')
      .single()

    if (createErr || !created) {
      // Another request may have created it simultaneously — retry fetch
      const { data: retry } = await supabase
        .from('chat_rooms').select('id').eq('type', 'global').limit(1)
      return retry?.length ? retry[0].id : null
    }
    return created.id
  }

  // ── Load rooms ──────────────────────────────────────────────
  useEffect(() => { if (myId) loadRooms() }, [myId])

  // Landing on a real Global Chat invite link (?code=XXX from buildGlobalInviteLink).
  // Runs once per myId — join, drop the param so it doesn't re-fire on refresh, reload.
  useEffect(() => {
    if (!myId) return
    const code = new URLSearchParams(location.search).get('code')
    if (!code) return
    joinGlobal(code)
      .catch(err => console.error('Failed to join Global Chat via invite link:', err.message))
      .finally(() => {
        const params = new URLSearchParams(location.search)
        params.delete('code')
        navigate({ pathname: location.pathname, search: params.toString() }, { replace: true })
        loadRooms()
      })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myId])
  useEffect(() => { if (myId) fetchMyStarredMessageIds(myId).then(setMyStarredIds) }, [myId])

  // Room-list-wide realtime: keeps "recent chats move to top" live even for rooms
  // that aren't currently open (the per-room subscription in openRoom only covers
  // the active conversation). Also auto-un-hides a room I'd deleted-for-me if the
  // other person sends something new into it.
  const activeRoomIdRef = useRef<string | null>(null)
  useEffect(() => { activeRoomIdRef.current = activeRoom?.id ?? null }, [activeRoom?.id])

  useEffect(() => {
    if (!myId) return
    const listChannel = supabase
      .channel(`room-list:${myId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async (payload) => {
        const raw = payload.new as { id: string; room_id: string; content: string; created_at: string; sender_id: string | null }

        setRooms(prev => {
          const idx = prev.findIndex(r => r.id === raw.room_id)
          if (idx === -1) return prev // not a room I'm currently showing — ignore (covers rooms I'm not a member of)
          const room = prev[idx]
          const isOpen = raw.room_id === activeRoomIdRef.current
          const bumpUnread = !isOpen && raw.sender_id !== myId
          const updated: ChatRoom = { ...room, lastMsg: raw.content, lastMsgId: raw.id, lastMsgSenderId: raw.sender_id, lastMsgTime: formatTime(raw.created_at), lastMsgAt: raw.created_at, unread: bumpUnread ? room.unread + 1 : room.unread }
          const rest = prev.filter((_, i) => i !== idx)

          // Global Chat always stays first; pinned rooms float above unpinned, each
          // group re-sorted by recency. Skip resort entirely for the room the user
          // currently has open, so the list doesn't jump under their thumb mid-read.
          if (updated.type === 'global' || updated.id === activeRoomIdRef.current) {
            const merged = [updated, ...rest]
            const globalRoom = merged.find(r => r.type === 'global')
            const others = merged.filter(r => r.type !== 'global')
            return globalRoom ? [globalRoom, ...others] : others
          }

          const globalRoom = rest.find(r => r.type === 'global')
          const others = rest.filter(r => r.type !== 'global')
          const withUpdated = [...others, updated]
          const pinned = withUpdated.filter(r => r.pinned).sort((a, b) => (new Date(b.lastMsgAt ?? 0).getTime()) - (new Date(a.lastMsgAt ?? 0).getTime()))
          const unpinned = withUpdated.filter(r => !r.pinned).sort((a, b) => (new Date(b.lastMsgAt ?? 0).getTime()) - (new Date(a.lastMsgAt ?? 0).getTime()))
          return globalRoom ? [globalRoom, ...pinned, ...unpinned] : [...pinned, ...unpinned]
        })

        // If this room was hidden-for-me ("delete chat"), a fresh incoming message
        // should bring it back into view rather than staying silently hidden.
        const { data: myMembership } = await supabase
          .from('room_members').select('hidden_at').eq('room_id', raw.room_id).eq('user_id', myId).maybeSingle()
        if (myMembership?.hidden_at) {
          await supabase.from('room_members').update({ hidden_at: null }).eq('room_id', raw.room_id).eq('user_id', myId)
          loadRooms() // room was excluded from `rooms` state entirely — needs a full reload to reappear
        }
      })
      // Taking a message down is an UPDATE (deleted: true, from manual
      // delete — migrations 0024/0059 — or hidden: true, from the
      // automated content filter — migration 0031), not a DELETE row — so
      // without this, the room's last message preview kept showing the
      // original taken-down text in the sidebar forever (only a full
      // reload re-ran loadRooms and noticed). Only swaps the preview when
      // the affected message IS the one currently shown (matched by id) —
      // an older, already-superseded message getting taken down elsewhere
      // in the room shouldn't touch it.
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, (payload) => {
        const raw = payload.new as { id: string; room_id: string; deleted: boolean; hidden: boolean }
        if (!raw.deleted && !raw.hidden) return
        setRooms(prev => prev.map(r => (r.id === raw.room_id && r.lastMsgId === raw.id)
          ? { ...r, lastMsg: raw.deleted ? 'Message deleted' : 'Message removed' }
          : r))
      })
      .subscribe()

    return () => { supabase.removeChannel(listChannel) }
  }, [myId])

  async function loadRooms() {
    setRoomsLoading(true)

    // Ensure user is always in the global room
    await ensureGlobalRoom()

    const { data: memberRows, error: memErr } = await supabase
      .from('room_members').select('room_id, pinned, cleared_at, hidden_at, last_read_at').eq('user_id', myId)

    if (memErr || !memberRows?.length) { setRoomsLoading(false); return }

    // Rooms I've hidden ("delete chat") are excluded from the list entirely — but if a
    // NEW message lands in one after I hid it, the realtime handler below un-hides it.
    const myRoomState = new Map(memberRows.map(r => [r.room_id, r]))
    const visibleRoomIds = memberRows.filter(r => !r.hidden_at).map(r => r.room_id)
    if (!visibleRoomIds.length) { setRooms([]); setRoomsLoading(false); return }

    let roomsQuery = supabase
      .from('chat_rooms').select('id, type, name, pinned_message_id, spotlight_message_id, spotlight_expires_at, dm_initiator_id, dm_accepted_at').in('id', visibleRoomIds)
    if (roomFilter === 'global') roomsQuery = roomsQuery.eq('type', 'global')
    else if (roomFilter === 'dms') roomsQuery = roomsQuery.in('type', ['dm', 'group', 'global'])
    const { data: roomRows } = await roomsQuery

    if (!roomRows?.length) { setRooms([]); setRoomsLoading(false); return }

    const built: ChatRoom[] = await Promise.all(roomRows.map(async (room) => {
      const myState = myRoomState.get(room.id)
      const clearedAt = myState?.cleared_at ?? null
      // Unread = messages from someone else, newer than the later of my
      // last_read_at / cleared_at for this room (a soft-clear also resets
      // what counts as "unread", same as it does for the preview text below).
      const unreadSince = [myState?.last_read_at, clearedAt].filter(Boolean).sort().pop() as string | undefined

      const [{ data: memberData }, { data: lastMsgData }, unreadRes] = await Promise.all([
        supabase
          .from('room_members')
          .select('user_id, profiles(username, display_name, avatar, display_name_font, display_name_color, is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official)')
          .eq('room_id', room.id),
        // Respect the soft-clear cutoff: a cleared chat's "last message" preview
        // should reflect only what's still visible to me, not what I cleared.
        // Deliberately NOT filtering out deleted/hidden messages here — the
        // preview should reflect whatever the true last message is, even if
        // it's since been taken down, same as the realtime UPDATE handler
        // below. Filtering them out made loadRooms silently fall back to
        // showing an OLDER message instead, which is a worse, more
        // confusing bug than a stale "Message deleted" ever was.
        (clearedAt
          ? supabase.from('messages').select('id, content, created_at, sender_id, deleted, hidden')
              .eq('room_id', room.id).gt('created_at', clearedAt)
              .order('created_at', { ascending: false }).limit(1)
          : supabase.from('messages').select('id, content, created_at, sender_id, deleted, hidden')
              .eq('room_id', room.id)
              .order('created_at', { ascending: false }).limit(1)
        ),
        (() => {
          let q = supabase.from('messages').select('id', { count: 'exact', head: true })
            .eq('room_id', room.id).eq('deleted', false).neq('sender_id', myId)
          if (unreadSince) q = q.gt('created_at', unreadSince)
          return q
        })(),
      ])

      const members: RoomMember[] = (memberData ?? []).map((m: Record<string, unknown>) => ({
        user_id: m.user_id as string,
        profile: (m.profiles as { username: string; display_name: string | null; avatar: string; display_name_font?: string | null; display_name_color?: string | null }) ?? { username: '?', display_name: null, avatar: '?' },
      }))

      const lastMsg = lastMsgData?.[0] as { id: string; content: string; created_at: string; sender_id: string | null; deleted: boolean; hidden: boolean } | undefined
      const lastMsgText = lastMsg ? (lastMsg.deleted ? 'Message deleted' : lastMsg.hidden ? 'Message removed' : lastMsg.content) : ''
      return {
        id: room.id, type: room.type, name: room.name, members,
        lastMsg: lastMsgText,
        lastMsgId: lastMsg?.id ?? null,
        lastMsgSenderId: lastMsg?.sender_id ?? null,
        lastMsgTime: lastMsg ? formatTime(lastMsg.created_at) : '',
        lastMsgAt: lastMsg?.created_at ?? null,
        unread: unreadRes.count ?? 0,
        pinned: myState?.pinned ?? false,
        clearedAt,
        pinnedMessageId: room.pinned_message_id ?? null,
        spotlightMessageId: room.spotlight_message_id ?? null,
        spotlightExpiresAt: room.spotlight_expires_at ?? null,
        dmInitiatorId: (room as any).dm_initiator_id ?? null,
        dmAcceptedAt: (room as any).dm_accepted_at ?? null,
      }
    }))

    // Sort: Global Chat always first, then pinned DMs, then the rest by most-recent message.
    const globalRoom = built.find(r => r.type === 'global')
    const dmRooms = built.filter(r => r.type !== 'global')
    const byRecency = (a: ChatRoom, b: ChatRoom) => {
      const at = a.lastMsgAt ? new Date(a.lastMsgAt).getTime() : 0
      const bt = b.lastMsgAt ? new Date(b.lastMsgAt).getTime() : 0
      return bt - at
    }
    const pinnedDms = dmRooms.filter(r => r.pinned).sort(byRecency)
    const unpinnedDms = dmRooms.filter(r => !r.pinned).sort(byRecency)
    const sorted = globalRoom ? [globalRoom, ...pinnedDms, ...unpinnedDms] : [...pinnedDms, ...unpinnedDms]

    // Deduplicate by room id (guards against race between startDmWith + loadRooms)
    const seen = new Set<string>()
    const deduped = sorted.filter(r => { if (seen.has(r.id)) return false; seen.add(r.id); return true })

    setRooms(deduped)
    setRoomsLoading(false)
  }

  // ── Player search (debounced) ────────────────────────────────
  useEffect(() => {
    if (playerSearchTimer.current) clearTimeout(playerSearchTimer.current)
    if (!playerSearch.trim()) { setPlayerResults([]); return }
    setPlayerSearching(true)
    playerSearchTimer.current = setTimeout(async () => {
      const q = playerSearch.trim().toLowerCase()
      const { data } = await supabase
        .from('profiles')
        .select('id, username, display_name, avatar')
        .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
        .limit(8)
      setPlayerResults(data ?? [])
      setPlayerSearching(false)
    }, 350)
    return () => { if (playerSearchTimer.current) clearTimeout(playerSearchTimer.current) }
  }, [playerSearch])

  // ── Open room ───────────────────────────────────────────────
  const openRoom = useCallback(async (room: ChatRoom) => {
    setActiveRoom(room)
    setRooms(prev => prev.map(r => r.id === room.id ? { ...r, unread: 0 } : r))
    setShowConv(true)
    setMessages([]); setMsgsLoading(true)
    setReplyTo(null); setText('')
    setGhostReadActive(false)
    setPendingRankTag(null); setRankTagPickerOpen(false)
    setEmojiOpen(false)
    setHasMoreOlder(false)
    setOtherLastReadAt(null)
    setDmBlockState('none')
    setNewMessagesBeforeId(null)
    setShowJumpToBottom(false)
    setJumpToBottomCount(0)
    setHeaderDrawerOpen(false)
    setComposerDrawerOpen(false)
    setMsgSearchOpen(false)
    setMsgSearchQuery('')
    isNearBottomRef.current = true

    // Most recent page only — newest-first query, then reversed for display.
    // If I've cleared this chat, only fetch messages after that cutoff.
    let query = supabase
      .from('messages')
      .select('id, sender_id, content, created_at, deleted, hidden, hidden_reason, reply_to_id, type, audio_path, audio_duration_seconds, call_id, rank_tag_group, poll_id, image_url')
      .eq('room_id', room.id)
    if (room.clearedAt) query = query.gt('created_at', room.clearedAt)
    const [{ data, error }, { data: myMembership }] = await Promise.all([
      query.order('created_at', { ascending: false }).limit(MESSAGE_PAGE_SIZE),
      // My own last-read position, captured BEFORE markRoomAsRead (below) bumps
      // it to now — this is what draws the line between "read" and "new".
      myId
        ? supabase.from('room_members').select('last_read_at').eq('room_id', room.id).eq('user_id', myId).maybeSingle()
        : Promise.resolve({ data: null as { last_read_at: string | null } | null }),
    ])
    const myPrevLastReadAt = myMembership?.last_read_at ?? null

    if (error || !data) { setMsgsLoading(false); return }

    const page = [...data].reverse()
    setHasMoreOlder(data.length === MESSAGE_PAGE_SIZE)

    // Collect all unique sender IDs not in members to resolve names
    const unknownIds = [...new Set(page.map(m => m.sender_id).filter(Boolean)
      .filter(id => !room.members.find(mb => mb.user_id === id)))] as string[]

    let extraProfiles: RoomMember[] = []
    if (unknownIds.length > 0) {
      const { data: pData } = await supabase
        .from('profiles').select('id, username, display_name, avatar, display_name_font, display_name_color, is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official').in('id', unknownIds)
      extraProfiles = (pData ?? []).map(p => ({
        user_id: p.id,
        profile: { username: p.username, display_name: p.display_name, avatar: p.avatar, display_name_font: p.display_name_font, display_name_color: p.display_name_color, is_official: p.is_official, is_halo_ai: p.is_halo_ai, is_groove_official: p.is_groove_official, is_pvp_official: p.is_pvp_official, is_warden_official: p.is_warden_official },
      }))
    }
    const allMembers = [...room.members, ...extraProfiles]
    roomMembersRef.current = allMembers

    // For a DM: resolve block state (either direction) and the other member's
    // current read position, both needed for the composer guard + read ticks.
    const otherMember = room.type === 'dm' ? room.members.find(mb => mb.user_id !== myId) : undefined
    if (room.type === 'dm' && myId && otherMember) {
      const [{ data: iBlockedThem }, { data: theyBlockedMe }, { data: theirMembership }] = await Promise.all([
        supabase.from('blocks').select('blocked_id').eq('blocker_id', myId).eq('blocked_id', otherMember.user_id).maybeSingle(),
        supabase.from('blocks').select('blocker_id').eq('blocker_id', otherMember.user_id).eq('blocked_id', myId).maybeSingle(),
        supabase.from('room_members').select('last_read_at').eq('room_id', room.id).eq('user_id', otherMember.user_id).maybeSingle(),
      ])
      setDmBlockState(iBlockedThem ? 'blockedByMe' : theyBlockedMe ? 'blockedMe' : 'none')
      setOtherLastReadAt(theirMembership?.last_read_at ?? null)
    }

    // Batch-fetch reply previews for the whole page in 1 round-trip total,
    // instead of N sequential awaits inside a per-message loop.
    const replyIds = [...new Set(page.map(m => m.reply_to_id).filter(Boolean))] as string[]

    const { data: allReplySources } = replyIds.length
      ? await supabase.from('messages').select('id, sender_id, content, deleted').in('id', replyIds)
      : { data: [] as { id: string; sender_id: string | null; content: string; deleted: boolean }[] }

    const replyContentById = new Map<string, string>()
    const replySenderById = new Map<string, string | null>()
    for (const r of allReplySources ?? []) {
      replyContentById.set(r.id, r.deleted ? 'Message deleted' : r.content)
      replySenderById.set(r.id, r.sender_id)
    }
    const nameForSender = (id: string | null | undefined) => {
      if (!id) return 'Unknown'
      const member = allMembers.find(mb => mb.user_id === id)
      return member ? (member.profile.display_name || member.profile.username) : 'Unknown'
    }

    const enriched: Message[] = page.map(m => {
      const senderMember = allMembers.find(mb => mb.user_id === m.sender_id)
      const senderName = senderMember ? (senderMember.profile.display_name || senderMember.profile.username) : 'Unknown'
      const senderUsername = senderMember ? senderMember.profile.username : undefined
      return {
        ...m,
        deleted: m.deleted ?? false,
        hidden: m.hidden ?? false,
        senderName,
        senderNameFont: senderMember?.profile.display_name_font ?? null,
        senderNameColor: senderMember?.profile.display_name_color ?? null,
        senderUsername,
        replyPreview: m.reply_to_id ? replyContentById.get(m.reply_to_id) : undefined,
        replyPreviewName: m.reply_to_id ? nameForSender(replySenderById.get(m.reply_to_id)) : undefined,
      }
    })

    // Divider sits above the first message from someone else that arrived
    // after my last read position — and only if there's older, already-read
    // history above it (otherwise everything here is "new" and a line at
    // the very top wouldn't tell the reader anything).
    if (myPrevLastReadAt) {
      const firstUnreadIdx = enriched.findIndex(m => m.sender_id !== myId && m.created_at > myPrevLastReadAt)
      setNewMessagesBeforeId(firstUnreadIdx > 0 ? enriched[firstUnreadIdx].id : null)
    } else {
      setNewMessagesBeforeId(null)
    }

    scrollModeRef.current = 'bottom'
    setMessages(enriched)
    setMsgsLoading(false)

    // Reactions for exactly the messages just loaded — scoped by id rather
    // than room, so Global Chat doesn't drag down its whole reaction history.
    if (enriched.length > 0) {
      const { data: reactionRows } = await supabase
        .from('message_reactions')
        .select('message_id, user_id, emoji')
        .in('message_id', enriched.map(m => m.id))
      setReactions(reactionRows ?? [])
    } else {
      setReactions([])
    }
    markRoomAsRead(room.id)

    // Pinned message banner — fetch its content since ChatRoom only carries the id
    setPinnedMsgPreview(null)
    if (room.pinnedMessageId) {
      const { data: pinnedRow } = await supabase
        .from('messages').select('id, sender_id, content').eq('id', room.pinnedMessageId).maybeSingle()
      if (pinnedRow) {
        const pinnedSender = allMembers.find(mb => mb.user_id === pinnedRow.sender_id)
        setPinnedMsgPreview({
          id: pinnedRow.id,
          content: pinnedRow.content,
          senderName: pinnedSender ? (pinnedSender.profile.display_name || pinnedSender.profile.username) : 'Unknown',
        })
      }
    }

    // Spotlight banner — same idea as the pinned banner above, but temporary
    // (see spotlightExpiresAt) and Global Chat only.
    setSpotlightMsgPreview(null)
    if (room.spotlightMessageId && room.spotlightExpiresAt && new Date(room.spotlightExpiresAt) > new Date()) {
      const { data: spotlightRow } = await supabase
        .from('messages').select('id, sender_id, content').eq('id', room.spotlightMessageId).maybeSingle()
      if (spotlightRow) {
        const spotlightSender = allMembers.find(mb => mb.user_id === spotlightRow.sender_id)
        setSpotlightMsgPreview({
          id: spotlightRow.id,
          content: spotlightRow.content,
          senderName: spotlightSender ? (spotlightSender.profile.display_name || spotlightSender.profile.username) : 'Unknown',
        })
      }
    }

    // Trending Now — only staff need this Set (drives the context-menu
    // label), and only in Global Chat where messages can be promoted.
    if (room.type === 'global' && isStaff) {
      supabase.rpc('trending_list').then(({ data }) => {
        const ids = ((data as { kind: string; message_id?: string }[]) || [])
          .filter(t => t.kind === 'global_message' && t.message_id)
          .map(t => t.message_id as string)
        setTrendingMessageIds(new Set(ids))
      })
    }

    // ── Real-time subscription — appends only the new row, never re-fetches the list.
    //    Also syncs message edits/deletes, pin changes, and the other
    //    DM member's read position, all on one channel scoped to this room. ──
    if (subRef.current) supabase.removeChannel(subRef.current)
    subRef.current = supabase
      .channel(`room:${room.id}:${Date.now()}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `room_id=eq.${room.id}`
      }, async (payload) => {
        const raw = payload.new as { id: string; sender_id: string; content: string; created_at: string; deleted: boolean; hidden: boolean; hidden_reason: string | null; reply_to_id: string | null; type: MessageType; audio_path: string | null; audio_duration_seconds: number | null; call_id: string | null; rank_tag_group: string | null; poll_id: string | null; image_url: string | null }

        // Resolve sender name (may be a new global chat participant not in original members)
        let senderName = 'Unknown'
        let senderUsername: string | undefined
        let senderNameFont: string | null = null
        let senderNameColor: string | null = null
        const memberMatch = roomMembersRef.current.find(mb => mb.user_id === raw.sender_id)
        if (memberMatch) {
          senderName = memberMatch.profile.display_name || memberMatch.profile.username
          senderUsername = memberMatch.profile.username
          senderNameFont = memberMatch.profile.display_name_font ?? null
          senderNameColor = memberMatch.profile.display_name_color ?? null
        } else {
          const { data: pData } = await supabase.from('profiles').select('username, display_name, display_name_font, display_name_color').eq('id', raw.sender_id).single()
          if (pData) {
            senderName = pData.display_name || pData.username
            senderUsername = pData.username
            senderNameFont = pData.display_name_font ?? null
            senderNameColor = pData.display_name_color ?? null
          }
        }

        // Resolve the reply preview too — without this, everyone except the
        // sender (who has it from local `replyTo` state) sees a reply with
        // no indication of what it's replying to until they reload the page,
        // which is exactly the confusing-thread problem this is meant to avoid.
        let replyPreview: string | undefined
        let replyPreviewName: string | undefined
        if (raw.reply_to_id) {
          const { data: replySource } = await supabase
            .from('messages').select('sender_id, content, deleted').eq('id', raw.reply_to_id).maybeSingle()
          if (replySource) {
            replyPreview = replySource.deleted ? 'Message deleted' : replySource.content
            const replyMember = roomMembersRef.current.find(mb => mb.user_id === replySource.sender_id)
            replyPreviewName = replyMember ? (replyMember.profile.display_name || replyMember.profile.username) : 'Unknown'
          }
        }

        // Only auto-scroll if the reader was already at the bottom — otherwise
        // they're reading history and shouldn't get yanked down mid-scroll.
        scrollModeRef.current = isNearBottomRef.current ? 'bottom' : 'none'
        if (isNearBottomRef.current) {
          markRoomAsRead(room.id)
        } else if (raw.sender_id !== myId) {
          setJumpToBottomCount(c => c + 1)
        }

        setMessages(ms => {
          // Deduplicate — if msg already added (optimistic send), skip
          if (ms.find(m => m.id === raw.id)) return ms
          return [...ms, { ...raw, senderName, senderNameFont, senderNameColor, senderUsername, replyPreview, replyPreviewName }]
        })
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'messages',
        filter: `room_id=eq.${room.id}`
      }, (payload) => {
        // Live-syncs edits made by anyone in the room — message deletion, and a
        // voice note's audio_path arriving shortly after the row itself (upload
        // to Storage happens after the DB row exists, since the storage path is
        // keyed by message id). Without this, other viewers see "Message
        // deleted" or a perpetually-uploading voice note until they reload.
        const raw = payload.new as { id: string; content: string; deleted: boolean; hidden: boolean; hidden_reason: string | null; audio_path: string | null }
        setMessages(ms => ms.map(m => m.id === raw.id
          ? { ...m, deleted: raw.deleted, hidden: raw.hidden, hidden_reason: raw.hidden_reason, content: raw.deleted ? 'Message deleted' : raw.content, audio_path: raw.audio_path }
          : m))
      })
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'messages',
        filter: `room_id=eq.${room.id}`
      }, (payload) => {
        // Hard deletes only happen from the Global Chat 100-message trim
        // (migration 0048) — a soft "delete" elsewhere in the app is an
        // UPDATE (deleted=true), handled above. Just drop the row locally.
        const raw = payload.old as { id: string }
        setMessages(ms => ms.filter(m => m.id !== raw.id))
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'chat_rooms',
        filter: `id=eq.${room.id}`
      }, async (payload) => {
        // Live-syncs pin/unpin and Spotlight changes made by staff.
        const raw = payload.new as {
          pinned_message_id: string | null
          spotlight_message_id: string | null
          spotlight_expires_at: string | null
          dm_initiator_id: string | null
          dm_accepted_at: string | null
        }
        setActiveRoom(r => (r && r.id === room.id) ? {
          ...r,
          pinnedMessageId: raw.pinned_message_id,
          spotlightMessageId: raw.spotlight_message_id,
          spotlightExpiresAt: raw.spotlight_expires_at,
          // Carries the accept across devices — the sender's "waiting on
          // them" notice clears the moment the recipient taps Accept.
          dmInitiatorId: raw.dm_initiator_id ?? r.dmInitiatorId,
          dmAcceptedAt: raw.dm_accepted_at ?? r.dmAcceptedAt,
        } : r)
        setRooms(prev => prev.map(r => r.id === room.id ? {
          ...r,
          pinnedMessageId: raw.pinned_message_id,
          spotlightMessageId: raw.spotlight_message_id,
          spotlightExpiresAt: raw.spotlight_expires_at,
          dmInitiatorId: raw.dm_initiator_id ?? r.dmInitiatorId,
          dmAcceptedAt: raw.dm_accepted_at ?? r.dmAcceptedAt,
        } : r))

        if (!raw.pinned_message_id) { setPinnedMsgPreview(null) } else {
          const { data: pinnedRow } = await supabase
            .from('messages').select('id, sender_id, content').eq('id', raw.pinned_message_id).maybeSingle()
          if (pinnedRow) {
            const pinnedSender = roomMembersRef.current.find(mb => mb.user_id === pinnedRow.sender_id)
            setPinnedMsgPreview({
              id: pinnedRow.id,
              content: pinnedRow.content,
              senderName: pinnedSender ? (pinnedSender.profile.display_name || pinnedSender.profile.username) : 'Unknown',
            })
          }
        }

        if (!raw.spotlight_message_id || !raw.spotlight_expires_at || new Date(raw.spotlight_expires_at) <= new Date()) {
          setSpotlightMsgPreview(null)
        } else {
          const { data: spotlightRow } = await supabase
            .from('messages').select('id, sender_id, content').eq('id', raw.spotlight_message_id).maybeSingle()
          if (spotlightRow) {
            const spotlightSender = roomMembersRef.current.find(mb => mb.user_id === spotlightRow.sender_id)
            setSpotlightMsgPreview({
              id: spotlightRow.id,
              content: spotlightRow.content,
              senderName: spotlightSender ? (spotlightSender.profile.display_name || spotlightSender.profile.username) : 'Unknown',
            })
          }
        }
      })
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'message_reactions',
        filter: `room_id=eq.${room.id}`
      }, (payload) => {
        // Realtime DELETE payloads carry only the primary key columns, which
        // here is exactly (message_id, user_id, emoji) — enough to drop the
        // right row without a refetch.
        if (payload.eventType === 'DELETE') {
          const old = payload.old as ReactionRowData
          setReactions(rs => rs.filter(r => !(r.message_id === old.message_id && r.user_id === old.user_id && r.emoji === old.emoji)))
        } else {
          const row = payload.new as ReactionRowData
          setReactions(rs => rs.some(r => r.message_id === row.message_id && r.user_id === row.user_id && r.emoji === row.emoji)
            ? rs : [...rs, row])
        }
      })
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'poll_votes',
        filter: `room_id=eq.${room.id}`
      }, () => {
        // A vote count changed somewhere in this room — every visible
        // PollMessage refetches its own data. Simpler than diffing individual
        // vote rows, and Global Chat rarely has many polls open at once.
        setPollRefreshToken(t => t + 1)
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'polls',
        filter: `room_id=eq.${room.id}`
      }, () => {
        // Covers a poll being ended early (closed_at set) by someone else.
        setPollRefreshToken(t => t + 1)
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'room_members',
        filter: `room_id=eq.${room.id}`
      }, (payload) => {
        // The other DM member's read position moved — flip sent → read live.
        const raw = payload.new as { user_id: string; last_read_at: string }
        if (raw.user_id !== myId) setOtherLastReadAt(raw.last_read_at)
      })
      .subscribe()
  }, [myId, markRoomAsRead])

  /** Pulls in reactions for a freshly-paginated page and merges them beside
   *  what's already loaded, keyed on the full (message, user, emoji) primary
   *  key so a re-fetch can't double-count a pill. */
  const mergeReactionsFor = useCallback(async (msgs: Message[]) => {
    if (msgs.length === 0) return
    const { data } = await supabase
      .from('message_reactions')
      .select('message_id, user_id, emoji')
      .in('message_id', msgs.map(m => m.id))
    if (!data || data.length === 0) return
    setReactions(rs => {
      const seen = new Set(rs.map(r => `${r.message_id}|${r.user_id}|${r.emoji}`))
      return [...rs, ...data.filter(r => !seen.has(`${r.message_id}|${r.user_id}|${r.emoji}`))]
    })
  }, [])

  // ── Load older messages (scroll-up pagination) ──────────────
  const loadOlderMessages = useCallback(async () => {
    if (!activeRoom || loadingOlder || !hasMoreOlder || messages.length === 0) return
    setLoadingOlder(true)

    // Snapshot the current scroll geometry so we can restore the reader's exact
    // position after older messages are prepended above what they're looking at —
    // otherwise the browser keeps scrollTop fixed and the whole view jumps down.
    const container = scrollContainerRef.current
    if (container) {
      preserveScrollInfoRef.current = { scrollHeight: container.scrollHeight, scrollTop: container.scrollTop }
    }

    const oldestCreatedAt = messages[0].created_at
    let query = supabase
      .from('messages')
      .select('id, sender_id, content, created_at, deleted, hidden, hidden_reason, reply_to_id, type, audio_path, audio_duration_seconds, call_id, rank_tag_group, poll_id, image_url')
      .eq('room_id', activeRoom.id)
      .lt('created_at', oldestCreatedAt)
    // Never page past a soft-clear cutoff — that history is hidden for me.
    if (activeRoom.clearedAt) query = query.gt('created_at', activeRoom.clearedAt)
    const { data, error } = await query
      .order('created_at', { ascending: false })
      .limit(MESSAGE_PAGE_SIZE)

    if (error || !data || data.length === 0) {
      setHasMoreOlder(false)
      setLoadingOlder(false)
      return
    }

    const olderPage = [...data].reverse()
    setHasMoreOlder(data.length === MESSAGE_PAGE_SIZE)

    const allMembers = roomMembersRef.current
    const replyIds = [...new Set(olderPage.map(m => m.reply_to_id).filter(Boolean))] as string[]

    const { data: olderReplySources } = replyIds.length
      ? await supabase.from('messages').select('id, sender_id, content, deleted').in('id', replyIds)
      : { data: [] as { id: string; sender_id: string | null; content: string; deleted: boolean }[] }

    const replyContentById = new Map<string, string>()
    const replySenderById = new Map<string, string | null>()
    for (const r of olderReplySources ?? []) {
      replyContentById.set(r.id, r.deleted ? 'Message deleted' : r.content)
      replySenderById.set(r.id, r.sender_id)
    }
    const nameForSender = (id: string | null | undefined) => {
      if (!id) return 'Unknown'
      const member = allMembers.find(mb => mb.user_id === id)
      return member ? (member.profile.display_name || member.profile.username) : 'Unknown'
    }

    const enrichedOlder: Message[] = olderPage.map(m => {
      const senderMember = allMembers.find(mb => mb.user_id === m.sender_id)
      const senderName = senderMember ? (senderMember.profile.display_name || senderMember.profile.username) : 'Unknown'
      const senderUsername = senderMember ? senderMember.profile.username : undefined
      return {
        ...m,
        deleted: m.deleted ?? false,
        hidden: m.hidden ?? false,
        senderName,
        senderNameFont: senderMember?.profile.display_name_font ?? null,
        senderNameColor: senderMember?.profile.display_name_color ?? null,
        senderUsername,
        replyPreview: m.reply_to_id ? replyContentById.get(m.reply_to_id) : undefined,
        replyPreviewName: m.reply_to_id ? nameForSender(replySenderById.get(m.reply_to_id)) : undefined,
      }
    })

    scrollModeRef.current = 'preserve'
    setMessages(ms => [...enrichedOlder, ...ms])
    await mergeReactionsFor(enrichedOlder)
    setLoadingOlder(false)
  }, [activeRoom, loadingOlder, hasMoreOlder, messages, mergeReactionsFor])

  /** Flashes the highlight ring on an already-mounted message bubble, then
   *  clears it after the reader's had a moment to spot it. */
  const flashHighlight = useCallback((id: string) => {
    setHighlightedMsgId(id)
    window.setTimeout(() => setHighlightedMsgId(cur => (cur === id ? null : cur)), 1600)
  }, [])

  /** Scrolls to + highlights a message that's already in the loaded `messages`
   *  window. Returns whether it found one — false means the caller needs to
   *  go fetch it (see jumpToMessage below). */
  const scrollToLoadedMessage = useCallback((id: string) => {
    const el = msgElRefs.current.get(id)
    if (!el) return false
    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    flashHighlight(id)
    return true
  }, [flashHighlight])

  /** Jump-to-message: powers both tapping a reply quote (jump back to the
   *  original) and opening a mention notification (jump to the tagged
   *  message). If it's not in the currently-loaded window, pages backward
   *  through history looking for it; if it's been pruned by Global Chat's
   *  message cap, been soft-cleared, or deleted, shows a brief "no longer
   *  available" notice instead of erroring. */
  const jumpToMessage = useCallback(async (id: string) => {
    if (scrollToLoadedMessage(id)) return
    if (!activeRoom || jumpLoading) return

    setJumpLoading(true)
    try {
      const { data: target } = await supabase
        .from('messages').select('id, created_at').eq('id', id).eq('room_id', activeRoom.id).maybeSingle()

      if (!target || (activeRoom.clearedAt && target.created_at <= activeRoom.clearedAt)) {
        setJumpNotice('This message is no longer available.')
        window.setTimeout(() => setJumpNotice(null), 2500)
        return
      }

      // Page backward from the oldest currently-loaded message, a full page
      // at a time, until the target turns up or history runs out. Capped so
      // a message that's somehow missing can't spin this forever.
      let cursor = messages[0]?.created_at ?? new Date().toISOString()
      const collected: RawMessageRow[] = []
      let found = false
      for (let i = 0; i < 10 && !found; i++) {
        let q = supabase.from('messages')
          .select('id, sender_id, content, created_at, deleted, hidden, hidden_reason, reply_to_id, type, audio_path, audio_duration_seconds, call_id, rank_tag_group, poll_id, image_url')
          .eq('room_id', activeRoom.id).lt('created_at', cursor)
        if (activeRoom.clearedAt) q = q.gt('created_at', activeRoom.clearedAt)
        const { data } = await q.order('created_at', { ascending: false }).limit(MESSAGE_PAGE_SIZE)
        if (!data || data.length === 0) break
        collected.push(...data)
        cursor = data[data.length - 1].created_at
        if (data.some(m => m.id === id)) found = true
        if (data.length < MESSAGE_PAGE_SIZE) break
      }

      if (!found) {
        setJumpNotice('This message is no longer available.')
        window.setTimeout(() => setJumpNotice(null), 2500)
        return
      }

      const olderPage = [...collected].reverse()
      const allMembers = roomMembersRef.current
      const replyIds = [...new Set(olderPage.map(m => m.reply_to_id).filter(Boolean))] as string[]
      const { data: replySources } = replyIds.length
        ? await supabase.from('messages').select('id, sender_id, content, deleted').in('id', replyIds)
        : { data: [] as { id: string; sender_id: string | null; content: string; deleted: boolean }[] }
      const replyContentById = new Map<string, string>()
      const replySenderById = new Map<string, string | null>()
      for (const r of replySources ?? []) {
        replyContentById.set(r.id, r.deleted ? 'Message deleted' : r.content)
        replySenderById.set(r.id, r.sender_id)
      }
      const nameForSender = (sid: string | null | undefined) => {
        if (!sid) return 'Unknown'
        const member = allMembers.find(mb => mb.user_id === sid)
        return member ? (member.profile.display_name || member.profile.username) : 'Unknown'
      }
      const enrichedOlder: Message[] = olderPage.map(m => {
        const senderMember = allMembers.find(mb => mb.user_id === m.sender_id)
        const senderName = senderMember ? (senderMember.profile.display_name || senderMember.profile.username) : 'Unknown'
        const senderUsername = senderMember ? senderMember.profile.username : undefined
        return {
          ...m,
          deleted: m.deleted ?? false,
          hidden: m.hidden ?? false,
          senderName,
          senderNameFont: senderMember?.profile.display_name_font ?? null,
          senderNameColor: senderMember?.profile.display_name_color ?? null,
          senderUsername,
          replyPreview: m.reply_to_id ? replyContentById.get(m.reply_to_id) : undefined,
          replyPreviewName: m.reply_to_id ? nameForSender(replySenderById.get(m.reply_to_id)) : undefined,
        }
      })

      scrollModeRef.current = 'none'
      setMessages(ms => [...enrichedOlder, ...ms])
      await mergeReactionsFor(enrichedOlder)
      // Two rAFs: one for React to commit the prepended messages, one for the
      // browser to paint them — only then does the target bubble's ref exist.
      requestAnimationFrame(() => {
        requestAnimationFrame(() => { scrollToLoadedMessage(id) })
      })
    } finally {
      setJumpLoading(false)
    }
  }, [activeRoom, messages, scrollToLoadedMessage, jumpLoading, mergeReactionsFor])

  // ── Scroll behavior, driven by scrollModeRef ─────────────────
  // Fixes a real bug in the previous implementation: prepending older messages
  // and then unconditionally re-running a "scroll to bottom" effect on every
  // `messages.length` change caused the view to snap back to the newest message
  // immediately after the user scrolled up to read history — pagination was
  // effectively unusable. This single effect distinguishes the two cases:
  //   'bottom'   → room just opened, I sent a message, or a live message arrived
  //                while I was already reading the latest — snap to the newest.
  //   'preserve' → older history was just prepended above what I was reading —
  //                keep my exact reading position stable using a scrollHeight delta.
  useLayoutEffect(() => {
    const el = scrollContainerRef.current
    if (!el) return
    if (scrollModeRef.current === 'bottom') {
      el.scrollTop = el.scrollHeight
      scrollModeRef.current = 'none'
    } else if (scrollModeRef.current === 'preserve' && preserveScrollInfoRef.current) {
      const prev = preserveScrollInfoRef.current
      el.scrollTop = el.scrollHeight - prev.scrollHeight + prev.scrollTop
      preserveScrollInfoRef.current = null
      scrollModeRef.current = 'none'
    }
  }, [messages])

  useEffect(() => () => { if (subRef.current) supabase.removeChannel(subRef.current) }, [])

  // ── Start private DM with a user ────────────────────────────
  async function startDmWith(targetUserId: string): Promise<boolean> {
    if (!myId || targetUserId === myId) return false

    // Guard against slow-network double-taps.
    if (creatingDmWithRef.current.has(targetUserId)) return false
    creatingDmWithRef.current.add(targetUserId)
    setStartingDmId(targetUserId)
    setDmStartError(null)

    try {
      // Atomic, server-side: looks up an existing DM or creates one and adds
      // both members in a single transaction (see migration 0011). This
      // replaced a two-request client-side flow that could leave the other
      // person never actually added to a brand-new DM room.
      const { data: roomIdResult, error: rpcError } = await supabase.rpc('get_or_create_dm_room', { p_other_user_id: targetUserId })
      const roomId = roomIdResult as string | null
      if (rpcError || !roomId) {
        console.error('Failed to start DM:', rpcError?.message)
        setDmStartError(rpcError?.message || "Couldn't open that conversation. Please try again.")
        return false
      }

      // Fetch the target user's profile for the room member list, and the
      // room's own request state — get_or_create_dm_room decides whether
      // this is a request or an ordinary chat (it auto-accepts when they
      // already follow you, when you're duo partners, or when you're
      // staff), so the answer has to be read back, not assumed.
      const [{ data: targetProfile }, { data: roomState }] = await Promise.all([
        supabase.from('profiles').select('username, display_name, avatar').eq('id', targetUserId).single(),
        supabase.from('chat_rooms').select('dm_initiator_id, dm_accepted_at').eq('id', roomId).maybeSingle(),
      ])

      // Build the room object directly and open it — no setTimeout race
      const roomObj: ChatRoom = {
        id: roomId!,
        type: 'dm',
        name: null,
        members: [
          {
            user_id: myId,
            profile: {
              username: myProfile?.username ?? '',
              display_name: myProfile?.display_name ?? null,
              avatar: myProfile?.avatar ?? '',
            },
          },
          {
            user_id: targetUserId,
            profile: {
              username: targetProfile?.username ?? '',
              display_name: targetProfile?.display_name ?? null,
              avatar: targetProfile?.avatar ?? '',
            },
          },
        ],
        lastMsg: '',
        lastMsgId: null,
        lastMsgSenderId: null,
        lastMsgTime: '',
        lastMsgAt: null,
        unread: 0,
        pinned: false,
        clearedAt: null,
        pinnedMessageId: null,
        spotlightMessageId: null,
        spotlightExpiresAt: null,
        // Unknown until the room is re-read: get_or_create_dm_room decides
        // whether this needed a request at all (it auto-accepts when they
        // already follow you, you're duo partners, or you're staff). Read
        // back below rather than guessed here.
        dmInitiatorId: roomState?.dm_initiator_id ?? myId,
        dmAcceptedAt: roomState?.dm_accepted_at ?? null,
      }

      setPlayerSearch('')
      setPlayerResults([])

      // Add to rooms list (or skip if already there), then open
      let roomToOpen = roomObj
      setRooms(prev => {
        const existing = prev.find(r => r.id === roomId)
        if (existing) {
          roomToOpen = existing
          return prev
        }
        const globalRoom = prev.find(r => r.type === 'global')
        const dms = prev.filter(r => r.type !== 'global')
        return globalRoom ? [globalRoom, roomObj, ...dms] : [roomObj, ...dms]
      })
      // Small tick to ensure state is settled before opening. openRoom is
      // async and normally not awaited by its other callers (room-list
      // clicks), so a throw inside it would otherwise vanish as an unhandled
      // promise rejection with nothing telling the player it failed.
      try {
        await new Promise(resolve => setTimeout(resolve, 0))
        await openRoom(roomToOpen)
      } catch (openErr) {
        console.error('Failed to open DM room:', openErr)
        setDmStartError("Couldn't open that conversation. Please try again.")
        return false
      }
      return true
    } catch (err) {
      console.error('startDmWith unexpected error:', err)
      setDmStartError("Couldn't open that conversation. Please try again.")
      return false
    } finally {
      creatingDmWithRef.current.delete(targetUserId)
      setStartingDmId(null)
    }
  }

  // Handles the handoff from PlayerProfile.tsx's "Message" button, which
  // navigates here with `state: { openDmWith: userId }` for a user the
  // player may never have chatted with before. Waits for the initial room
  // list load to finish (so startDmWith's own setRooms update doesn't race
  // it) and clears the state afterward so refreshing/going back doesn't
  // re-trigger a duplicate DM lookup.
  useEffect(() => {
    const targetUserId = (location.state as { openDmWith?: string } | null)?.openDmWith
    if (!targetUserId || !myId || roomsLoading) return
    let cancelled = false
    startDmWith(targetUserId).finally(() => {
      if (!cancelled) navigate(location.pathname, { replace: true, state: {} })
    })
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.state, myId, roomsLoading])

  // Handles the handoff from IconRail's group-chat icons, which navigate
  // here with `state: { openRoomId }` to jump straight into a specific
  // room without going through the list first. Waits for the room list to
  // finish loading (the room has to already be in `rooms`), then clears
  // the state so refreshing/going back doesn't re-trigger it.
  useEffect(() => {
    const targetRoomId = (location.state as { openRoomId?: string } | null)?.openRoomId
    if (!targetRoomId || roomsLoading) return
    const room = rooms.find(r => r.id === targetRoomId)
    if (room) openRoom(room)
    navigate(location.pathname, { replace: true, state: {} })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.state, rooms, roomsLoading])

  // Handles the handoff from a mention notification tap, which links here as
  // `/chat?tab=chats&room=<id>&msg=<id>` (see notificationRoutes.ts). Opens
  // the room, then jumps to + highlights the tagged message once it's
  // loaded — falling back to jumpToMessage's own "no longer available"
  // notice if the message has since been deleted or pruned by Global Chat's
  // message cap. Strips the params afterward so refreshing doesn't re-fire it.
  useEffect(() => {
    const params = new URLSearchParams(location.search)
    const targetRoomId = params.get('room')
    const targetMsgId = params.get('msg')
    if (!targetRoomId || roomsLoading) return
    const room = rooms.find(r => r.id === targetRoomId)
    if (!room) return
    let cancelled = false
    openRoom(room).then(() => {
      if (cancelled || !targetMsgId) return
      // Two rAFs so the just-opened room's first message page has actually
      // painted before we try to scroll to something inside it.
      requestAnimationFrame(() => {
        requestAnimationFrame(() => { if (!cancelled) jumpToMessage(targetMsgId) })
      })
    })
    const cleanParams = new URLSearchParams(location.search)
    cleanParams.delete('room'); cleanParams.delete('msg')
    navigate({ pathname: location.pathname, search: cleanParams.toString() }, { replace: true })
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, rooms, roomsLoading])

  // ── Send ────────────────────────────────────────────────────
  interface MessageInsertPayload {
    room_id: string
    sender_id: string
    content: string
    reply_to_id?: string
    type?: MessageType
    audio_duration_seconds?: number
    rank_tag_group?: RankGroupId
    image_url?: string
  }

  // Halo AI has a real profile now and can be DM'd like anyone else, but
  // there's no live backend behind THAT surface yet (the dedicated Halo AI
  // page still calls the real edge function — this doesn't touch that).
  // This is a stopgap: a local-only message, never written to the
  // `messages` table, so it costs nothing and needs no new infra. It
  // won't survive a refresh or show up on another device — that's the
  // deliberate tradeoff for "simple for now". Delete this block (and its
  // call site above) once Halo AI's DMs get a real backend.
  //
  // Appends a local-only Halo message (never written to `messages`) and
  // keeps the room list preview in sync. Returns the message id so a flow
  // can come back and edit it in place once the real answer is ready (see
  // updateLocalHaloMessage below). Pulled out of maybeQueueHaloAutoReply so
  // handleHaloWidgetAction — which posts a Halo follow-up after an action
  // button is tapped, outside of any incoming-message flow — can reuse the
  // exact same "local Halo message" construction.
  function postLocalHaloMessage(room: ChatRoom, halo: RoomMember, content: string, widget?: HaloWidget): string {
    const nowIso = new Date().toISOString()
    const id = `local-halo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
    const localMsg: Message = {
      id,
      sender_id: halo.user_id,
      content,
      created_at: nowIso,
      deleted: false,
      hidden: false,
      hidden_reason: null,
      reply_to_id: null,
      senderName: halo.profile.display_name || halo.profile.username,
      senderNameFont: halo.profile.display_name_font ?? null,
      senderNameColor: halo.profile.display_name_color ?? null,
      senderUsername: halo.profile.username,
      type: 'text',
      audio_path: null,
      audio_duration_seconds: null,
      call_id: null,
      rank_tag_group: null,
      poll_id: null,
      image_url: null,
      haloWidget: widget,
    }
    // Only append if this room is still the one open — avoids a reply
    // landing in whatever room the user has since switched to.
    if (activeRoomIdRef.current === room.id) {
      scrollModeRef.current = 'bottom'
      setMessages(ms => [...ms, localMsg])
    }
    setRooms(prev => prev.map(r => r.id === room.id
      ? { ...r, lastMsg: content, lastMsgId: id, lastMsgSenderId: halo.user_id, lastMsgTime: formatTime(nowIso), lastMsgAt: nowIso }
      : r))
    return id
  }

  // Rewrites a "checking..." message this function already posted, in
  // place — the "checking.../honing..." → real-answer pattern for
  // data-backed flows. Only touches the room preview if that message is
  // still the room's most recent one, so a slow lookup can't clobber a
  // preview that's since moved on to a newer message.
  function updateLocalHaloMessage(room: ChatRoom, id: string, content: string, widget?: HaloWidget) {
    if (activeRoomIdRef.current === room.id) {
      setMessages(ms => ms.map(m => (m.id === id ? { ...m, content, haloWidget: widget } : m)))
    }
    setRooms(prev => prev.map(r => (r.id === room.id && r.lastMsgId === id)
      ? { ...r, lastMsg: content }
      : r))
  }

  /** Patches just the haloWidget on one already-posted local Halo message —
   *  used by handleHaloWidgetAction to flip a card from 'pending' to
   *  'confirmed'/'cancelled'/'error' (or mark one Mall item owned) without
   *  touching its text. */
  function patchLocalHaloWidget(msgId: string, patch: (w: HaloWidget) => HaloWidget) {
    setMessages(ms => ms.map(m => (m.id === msgId && m.haloWidget ? { ...m, haloWidget: patch(m.haloWidget) } : m)))
  }

  function maybeQueueHaloAutoReply(room: ChatRoom, userText: string) {
    if (room.type !== 'dm') return
    const halo = room.members.find(mb => mb.profile.is_halo_ai)
    if (!halo) return

    const delay = 800 + Math.random() * 900 // feels a little more human than instant

    setTimeout(async () => {
      // Action-system flows (username change, Elimination Weekend
      // registration, Mall/wallet previews) live in haloActionFlows.ts and
      // take priority over the read-only dynamic flows below — in
      // particular, an outstanding "what should your new username be?"
      // question always claims the very next message in this room,
      // regardless of what it looks like.
      const actionCtx: HaloActionContext = {
        myId,
        myUsername: myProfile?.username ?? null,
        myUsernameChangedAt: myProfile?.username_changed_at ?? null,
      }
      const pending = pendingHaloActionRef.current.get(room.id) ?? null
      const actionFlow = matchHaloActionFlow(userText, actionCtx, pending)
      if (actionFlow) {
        const msgId = actionFlow.checking ? postLocalHaloMessage(room, halo, actionFlow.checking) : null
        const result = await actionFlow.run()
        pendingHaloActionRef.current.set(room.id, result.nextPending ?? null)
        if (msgId) {
          updateLocalHaloMessage(room, msgId, result.text, result.widget)
        } else {
          postLocalHaloMessage(room, halo, result.text, result.widget)
        }
        return
      }

      // Data-backed flows (rank, recent post, PvP, achievements, mall
      // stats, username) live in haloDynamicReplies.ts and only fire on a
      // real intent match; everything else stays on pickHaloStaticReply's
      // instant, network-free path — no request made unless one's needed.
      const dynamicFlow = matchDynamicHaloFlow(userText, { myId, myUsername: myProfile?.username ?? null })
      if (dynamicFlow) {
        if (dynamicFlow.checking) {
          const msgId = postLocalHaloMessage(room, halo, dynamicFlow.checking)
          const [finalText, widget] = await Promise.all([
            dynamicFlow.resolve(),
            dynamicFlow.resolveWidget ? dynamicFlow.resolveWidget() : Promise.resolve(null),
          ])
          updateLocalHaloMessage(room, msgId, finalText, widget ?? undefined)
        } else {
          const [finalText, widget] = await Promise.all([
            dynamicFlow.resolve(),
            dynamicFlow.resolveWidget ? dynamicFlow.resolveWidget() : Promise.resolve(null),
          ])
          postLocalHaloMessage(room, halo, finalText, widget ?? undefined)
        }
        return
      }

      const staticReply = pickHaloStaticReply(userText, room.id)
      postLocalHaloMessage(room, halo, staticReply.text, staticReply.game ? { type: 'game', gameId: staticReply.game.id } : undefined)
    }, delay)
  }

  /**
   * Fires when a Halo action-card button (Confirm, Cancel, Register Me,
   * Buy) is tapped. Every branch re-validates through haloActionFlows.ts
   * (never trusts the state baked into the card, since time may have
   * passed since it was shown), patches that one message's widget in place
   * to reflect the outcome, and — for a state-changing success — has Halo
   * post one short follow-up message, matching the "Done! ..." pattern in
   * the spec.
   */
  function handleHaloWidgetAction(msg: Message, action: HaloAction) {
    if (!myId || !activeRoom) return
    const halo = activeRoom.members.find(mb => mb.profile.is_halo_ai)
    if (!halo) return
    const room = activeRoom

    if (action.type === 'cancel_username_change') {
      patchLocalHaloWidget(msg.id, w => (w.type === 'username_change' ? { ...w, status: 'cancelled' } : w))
      pendingHaloActionRef.current.set(room.id, null)
      return
    }

    if (action.type === 'confirm_username_change') {
      if (haloActionBusyKey === msg.id) return
      setHaloActionBusyKey(msg.id)
      changeUsernameAction(action.newUsername, {
        myId, myUsername: myProfile?.username ?? null, myUsernameChangedAt: myProfile?.username_changed_at ?? null,
      }).then(res => {
        setHaloActionBusyKey(null)
        if (res.success) {
          setMyProfile(p => (p ? { ...p, username: action.newUsername, username_changed_at: new Date().toISOString() } : p))
          patchLocalHaloWidget(msg.id, w => (w.type === 'username_change' ? { ...w, status: 'confirmed' } : w))
          pendingHaloActionRef.current.set(room.id, null)
          postLocalHaloMessage(room, halo, `Done! Your username is now @${action.newUsername}. 🎉`)
        } else {
          patchLocalHaloWidget(msg.id, w => (w.type === 'username_change' ? { ...w, status: 'error', errorMessage: res.error } : w))
        }
      })
      return
    }

    if (action.type === 'register_elimination') {
      if (haloActionBusyKey === msg.id) return
      setHaloActionBusyKey(msg.id)
      registerForEliminationAction().then(res => {
        setHaloActionBusyKey(null)
        if (res.success) {
          patchLocalHaloWidget(msg.id, w => (w.type === 'event_preview'
            ? { ...w, status: 'registered', registeredCount: res.registeredCount ?? w.registeredCount, errorMessage: undefined }
            : w))
          postLocalHaloMessage(room, halo, "You're registered! I'll notify you when the event starts.")
        } else {
          patchLocalHaloWidget(msg.id, w => (w.type === 'event_preview' ? { ...w, errorMessage: res.error } : w))
        }
      })
      return
    }

    if (action.type === 'buy_mall_item') {
      const busyKey = `${msg.id}:${action.itemId}`
      if (haloActionBusyKey === busyKey) return
      setHaloActionBusyKey(busyKey)
      buyMallItemAction(action.itemId, myId).then(res => {
        setHaloActionBusyKey(null)
        if (res.success) {
          patchLocalHaloWidget(msg.id, w => (w.type === 'mall_preview'
            ? { ...w, items: w.items.map(it => (it.id === action.itemId ? { ...it, owned: true } : it)) }
            : w))
        } else {
          postLocalHaloMessage(room, halo, `Couldn't grab ${action.itemName} — ${res.error || 'purchase failed.'}`)
        }
      })
      return
    }
  }

  async function sendMsg() {
    const trimmed = text.trim()
    if (!trimmed || !activeRoom || !myId || sending) return
    if (trimmed.length > MAX_MESSAGE_LENGTH) return // guards against a pasted block over the DB check-constraint limit
    if (activeRoom.type === 'dm' && dmBlockState !== 'none') return // composer is hidden in this state, but guard defensively
    if (activeRoom.type === 'dm' && dmRequestBlocking) return // request bar is up instead of the composer
    if (containsProfanity(trimmed)) { setComposerError(PROFANITY_BLOCKED_MESSAGE); return }
    // Members may only link to Chillverse. The DB trigger (migration 0119) is
    // the real enforcement — this just explains it instead of the message
    // silently arriving as "[link removed]".
    if (!isStaff) {
      const blockedHost = firstExternalHost(trimmed)
      if (blockedHost) {
        setComposerError(`Links to ${blockedHost} aren't allowed in chat — only chillverse.com.ng links can be shared.`)
        return
      }
    }

    setSending(true)

    try {
      // Stop broadcasting "typing" the instant the message goes out.
      if (typingTimeoutRef.current) { clearTimeout(typingTimeoutRef.current); typingTimeoutRef.current = null }
      isTypingRef.current = false
      presenceChannelRef.current?.track({ typing: false })

      const rankTag = pendingRankTag && isStaff && activeRoom.type === 'global' ? pendingRankTag : null

      const payload: MessageInsertPayload = { room_id: activeRoom.id, sender_id: myId, content: trimmed }
      if (replyTo) payload.reply_to_id = replyTo.id
      if (rankTag) { payload.type = 'rank_tag'; payload.rank_tag_group = rankTag }
      const { data: inserted, error } = await supabase.from('messages').insert(payload).select('id, sender_id, content, created_at, deleted, hidden, hidden_reason, reply_to_id, type, audio_path, audio_duration_seconds, call_id, rank_tag_group, poll_id, image_url').single()
      if (!error && inserted) {
        // Weekly mission: messages_sent
        if (myId) updateMissionProgress(myId, 'messages_sent', 1).catch(console.error)
        // Weekly mission: chat in N different rooms this week
        if (myId) trackWeeklyUniqueValue(myId, 'unique_rooms_chatted', activeRoom.id).catch(console.error)
        // Weekly mission: reply to N messages this week
        if (myId && replyTo) updateMissionProgress(myId, 'replies_sent', 1).catch(console.error)
        // Notify the other person in a DM (skip global chat to avoid spamming everyone)
        if (myId && activeRoom.type === 'dm') {
          const recipients = activeRoom.members.filter(mb => mb.user_id !== myId)
          notifyMessage(inserted.id).catch(console.error)
          // Weekly missions: dm_sent (every DM) + dm_unique (distinct recipients this week)
          updateMissionProgress(myId, 'dm_sent', 1).catch(console.error)
          recipients.forEach(mb => trackWeeklyUniqueValue(myId, 'dm_unique', mb.user_id).catch(console.error))
        }
        // Rank tag: fan out to every user currently in that rank group
        if (myId && rankTag) {
          notifyRankTag(myId, rankTag, { messageId: inserted.id }).catch(console.error)
        }
        // @mentions: resolve @username tokens against this room's membership and
        // notify whoever got tagged. notify_mention() re-verifies membership and
        // excludes the sender server-side, so this list is a hint, not a trust boundary.
        const mentionedIds = extractMentionedUserIds(trimmed, activeRoom.members, myId)
        if (mentionedIds.length > 0) {
          notifyMention(inserted.id, mentionedIds).catch(console.error)
        }
        // Optimistically add own message immediately without waiting for realtime
        const myMember = activeRoom.members.find(mb => mb.user_id === myId)
        const senderName = myMember ? (myMember.profile.display_name || myMember.profile.username) : 'Me'
        const senderUsername = myMember?.profile.username
        scrollModeRef.current = 'bottom'
        setMessages(ms => {
          if (ms.find(m => m.id === inserted.id)) return ms
          return [...ms, { ...inserted, deleted: false, senderName, senderUsername, replyPreview: replyTo?.content, replyPreviewName: replyTo?.senderName }]
        })
        setText(''); setReplyTo(null); setPendingRankTag(null); setMentionQuery(null); setMentionStartIndex(null)
        // Halo AI's DMs have no live backend yet — fake a reply locally so
        // the conversation doesn't look dead. See haloStaticReplies.ts.
        maybeQueueHaloAutoReply(activeRoom, trimmed)
      } else if (!error) {
        setText(''); setReplyTo(null); setPendingRankTag(null); setMentionQuery(null); setMentionStartIndex(null)
      } else if (error.message?.includes('CV_PROFANITY')) {
        setComposerError(PROFANITY_BLOCKED_MESSAGE)
      } else if (isDmRequestRejection(error.message ?? '')) {
        // The trigger refused it. That means our local copy of the room is
        // stale — they accepted and we missed it, or this send raced the
        // one-message cap. Re-read the room so the right bar appears
        // instead of leaving a bare error over a composer that can't work.
        setComposerError('Wait for them to accept before sending another')
        const { data: fresh } = await supabase
          .from('chat_rooms').select('dm_initiator_id, dm_accepted_at')
          .eq('id', activeRoom.id).maybeSingle()
        if (fresh) {
          setActiveRoom(r => r ? { ...r, dmInitiatorId: fresh.dm_initiator_id, dmAcceptedAt: fresh.dm_accepted_at } : r)
          setRooms(prev => prev.map(r => r.id === activeRoom.id
            ? { ...r, dmInitiatorId: fresh.dm_initiator_id, dmAcceptedAt: fresh.dm_accepted_at } : r))
        }
      } else {
        // Previously: unhandled errors (RLS denial, network hiccup mid-request, etc.)
        // failed silently — the composer just sat there with no feedback. Surface
        // something so it's clear the send didn't go through.
        console.error('Failed to send message:', error.message)
        setComposerError('Message failed to send. Please try again.')
      }
    } catch (err) {
      // Guards against the send button getting permanently stuck disabled: if the
      // request itself throws (offline, CORS, etc.) rather than resolving with an
      // { error } object, the old code skipped setSending(false) entirely below.
      console.error('Unexpected error sending message:', err)
      setComposerError('Message failed to send. Please try again.')
    } finally {
      setSending(false)
    }
  }

  /** Voice-note counterpart to sendMsg(). Two-step by necessity: the storage
   *  path convention (`<room_id>/<message_id>.<ext>`) requires a message id
   *  before the file can be uploaded, so the row is inserted first with
   *  audio_path null (MessageRow renders an "Uploading…" state for that),
   *  then patched with the real path once the upload finishes. */
  async function sendVoiceNote({ blob, mimeType, durationSeconds }: VoiceRecorderResult) {
    if (!activeRoom || !myId || sending) return
    if (activeRoom.type === 'dm' && dmBlockState !== 'none') return
    if (activeRoom.type === 'dm' && dmRequestBlocking) return
    if (!myIsVoid) { setMicError('Voice notes are a Chillverse Pro perk (Void).'); return }
    setSending(true)

    const payload: MessageInsertPayload = {
      room_id: activeRoom.id,
      sender_id: myId,
      content: '🎙️ Voice message',
      type: 'voice_note',
      audio_duration_seconds: durationSeconds,
    }
    if (replyTo) payload.reply_to_id = replyTo.id

    const { data: inserted, error } = await supabase.from('messages').insert(payload)
      .select('id, sender_id, content, created_at, deleted, hidden, hidden_reason, reply_to_id, type, audio_path, audio_duration_seconds, call_id, rank_tag_group, poll_id, image_url').single()

    if (error || !inserted) {
      if (error?.message?.includes('CV_VOICE_NOTES_PRO_ONLY')) {
        setMicError('Voice notes are a Chillverse Pro perk (Void).')
      }
      setSending(false)
      return
    }

    if (myId && activeRoom.type === 'dm') {
      const recipients = activeRoom.members.filter(mb => mb.user_id !== myId)
      notifyMessage(inserted.id).catch(console.error)
      updateMissionProgress(myId, 'dm_sent', 1).catch(console.error)
      recipients.forEach(mb => trackWeeklyUniqueValue(myId, 'dm_unique', mb.user_id).catch(console.error))
    }
    updateMissionProgress(myId, 'messages_sent', 1).catch(console.error)
    trackWeeklyUniqueValue(myId, 'unique_rooms_chatted', activeRoom.id).catch(console.error)
    if (replyTo) updateMissionProgress(myId, 'replies_sent', 1).catch(console.error)

    const myMember = activeRoom.members.find(mb => mb.user_id === myId)
    const senderName = myMember ? (myMember.profile.display_name || myMember.profile.username) : 'Me'
    const senderUsername = myMember?.profile.username
    scrollModeRef.current = 'bottom'
    setMessages(ms => {
      if (ms.find(m => m.id === inserted.id)) return ms
      return [...ms, { ...inserted, deleted: false, senderName, senderUsername, replyPreview: replyTo?.content, replyPreviewName: replyTo?.senderName }]
    })
    setReplyTo(null)
    setSending(false)

    try {
      const audioPath = await uploadVoiceNote(activeRoom.id, inserted.id, blob, mimeType)
      const { error: patchError } = await supabase.from('messages').update({ audio_path: audioPath }).eq('id', inserted.id)
      if (patchError) throw new Error(patchError.message)
      setMessages(ms => ms.map(m => m.id === inserted.id ? { ...m, audio_path: audioPath } : m))
    } catch (err) {
      console.error('Voice note upload failed:', err)
      setMessages(ms => ms.map(m => m.id === inserted.id ? { ...m, type: 'text', content: '⚠️ Voice message failed to send' } : m))
    }
  }

  /** Picture send. Upload first (so a rejected file never creates a row),
   *  then insert one message carrying the URL. Any text sitting in the
   *  composer rides along as the caption. */
  async function sendImage(file: File) {
    if (!activeRoom || !myId || sending) return
    if (activeRoom.type === 'dm' && dmBlockState !== 'none') return
    if (activeRoom.type === 'dm' && dmRequestBlocking) return
    if (!canSendImages) return

    // Refuse oversized files up front — nothing is uploaded, so the user
    // gets the toast immediately rather than after a wasted round trip.
    const invalid = validateChatImage(file, myImageLimitBytes)
    if (invalid) { showToast({ message: invalid, icon: AlertTriangle, iconColor: 'var(--red)' }); return }

    const caption = text.trim()
    if (caption && containsProfanity(caption)) { showToast({ message: PROFANITY_BLOCKED_MESSAGE, icon: AlertTriangle, iconColor: 'var(--red)' }); return }
    if (caption && !isStaff) {
      const blockedHost = firstExternalHost(caption)
      if (blockedHost) {
        setComposerError(`Links to ${blockedHost} aren't allowed in chat — only chillverse.com.ng links can be shared.`)
        return
      }
    }

    setSending(true)
    setComposerDrawerOpen(false)

    try {
      const imageUrl = await uploadChatImage(myId, file, myImageLimitBytes)

      const payload: MessageInsertPayload = {
        room_id: activeRoom.id,
        sender_id: myId,
        content: caption || '📷 Photo',
        image_url: imageUrl,
      }
      if (replyTo) payload.reply_to_id = replyTo.id

      const { data: inserted, error } = await supabase.from('messages').insert(payload)
        .select('id, sender_id, content, created_at, deleted, hidden, hidden_reason, reply_to_id, type, audio_path, audio_duration_seconds, call_id, rank_tag_group, poll_id, image_url').single()

      if (error || !inserted) {
        console.error('Failed to send image:', error?.message)
        const msg = error?.message?.includes('CV_IMAGES_DM_ONLY')
          ? 'Pictures can only be sent in personal DMs.'
          : error?.message?.includes('CV_IMAGES_FREE_SIZE')
            ? 'Images must be under 2MB on the free plan.'
            : error?.message?.includes('CV_IMAGES_VOID_ONLY')
              ? 'Image uploads are a Chillverse Pro perk (Void).'
              : 'Image failed to send. Please try again.'
        showToast({ message: msg, icon: AlertTriangle, iconColor: 'var(--red)' })
        return
      }

      if (activeRoom.type === 'dm') {
        const recipients = activeRoom.members.filter(mb => mb.user_id !== myId)
        notifyMessage(inserted.id).catch(console.error)
        updateMissionProgress(myId, 'dm_sent', 1).catch(console.error)
        recipients.forEach(mb => trackWeeklyUniqueValue(myId, 'dm_unique', mb.user_id).catch(console.error))
      }
      updateMissionProgress(myId, 'messages_sent', 1).catch(console.error)
      trackWeeklyUniqueValue(myId, 'unique_rooms_chatted', activeRoom.id).catch(console.error)

      const myMember = activeRoom.members.find(mb => mb.user_id === myId)
      const senderName = myMember ? (myMember.profile.display_name || myMember.profile.username) : 'Me'
      scrollModeRef.current = 'bottom'
      setMessages(ms => {
        if (ms.find(m => m.id === inserted.id)) return ms
        return [...ms, { ...inserted, deleted: false, senderName, senderUsername: myMember?.profile.username, replyPreview: replyTo?.content, replyPreviewName: replyTo?.senderName }]
      })
      setText(''); setReplyTo(null)
    } catch (err) {
      showToast({
        message: err instanceof Error ? err.message : 'Image failed to send. Please try again.',
        icon: AlertTriangle, iconColor: 'var(--red)',
      })
    } finally {
      setSending(false)
    }
  }

  function handleKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (mentionQuery !== null) {
      if (e.key === 'Escape') { e.preventDefault(); setMentionQuery(null); setMentionStartIndex(null); return }
      if (e.key === 'Enter' && !e.shiftKey) {
        const top = mentionSuggestions()[0]
        if (top) { e.preventDefault(); applyMention(top); return }
      }
    }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg() }
  }

  /** Tally the flat rows into per-message pills, in the order each emoji first
   *  appeared on that message (so pills don't reshuffle as counts change). */
  const reactionsByMessage = useMemo(() => {
    const map = new Map<string, MessageReaction[]>()
    for (const r of reactions) {
      const list = map.get(r.message_id) ?? []
      const existing = list.find(x => x.emoji === r.emoji)
      if (existing) {
        existing.count += 1
        if (r.user_id === myId) existing.mine = true
      } else {
        list.push({ emoji: r.emoji, count: 1, mine: r.user_id === myId })
      }
      map.set(r.message_id, list)
    }
    return map
  }, [reactions, myId])

  const reactionsFor = useCallback((msg: Message) => reactionsByMessage.get(msg.id) ?? [], [reactionsByMessage])

  /** Which message's "who reacted" sheet is open, if any — set from a
   *  pill tap, cleared on close. Only the message id is stored; the raw
   *  rows for it are re-derived from `reactions` on each render below,
   *  so a reaction arriving/leaving in real time while the sheet is open
   *  is reflected immediately instead of freezing a stale snapshot. */
  const [reactorsSheetMsgId, setReactorsSheetMsgId] = useState<string | null>(null)
  const openReactors = useCallback((msg: Message, _emoji: string) => setReactorsSheetMsgId(msg.id), [])
  const reactorsSheetRows = useMemo(
    () => reactorsSheetMsgId ? reactions.filter(r => r.message_id === reactorsSheetMsgId) : [],
    [reactorsSheetMsgId, reactions],
  )
  const reactorUserLookup = useCallback((userId: string) => {
    const member = activeRoom?.members.find(m => m.user_id === userId)
    if (!member) return undefined
    return { name: member.profile.display_name || member.profile.username, avatar: member.profile.avatar }
  }, [activeRoom])

  /** Toggle my reaction of one emoji on one message. Optimistic both ways —
   *  realtime echoes the same change back, and the dedupe guards in the
   *  subscription make that echo a no-op. */
  const toggleReaction = useCallback(async (msg: Message, emoji: string) => {
    const roomId = activeRoom?.id
    if (!myId || !roomId) return
    const mine = reactions.some(r => r.message_id === msg.id && r.user_id === myId && r.emoji === emoji)

    if (mine) {
      setReactions(rs => rs.filter(r => !(r.message_id === msg.id && r.user_id === myId && r.emoji === emoji)))
      const { error } = await supabase.from('message_reactions').delete()
        .eq('message_id', msg.id).eq('user_id', myId).eq('emoji', emoji)
      if (error) setReactions(rs => [...rs, { message_id: msg.id, user_id: myId, emoji }])
    } else {
      setReactions(rs => [...rs, { message_id: msg.id, user_id: myId, emoji }])
      const { error } = await supabase.from('message_reactions')
        .insert({ message_id: msg.id, user_id: myId, emoji, room_id: roomId })
      if (error) setReactions(rs => rs.filter(r => !(r.message_id === msg.id && r.user_id === myId && r.emoji === emoji)))
    }
  }, [myId, reactions, activeRoom])

  async function deleteMsg(id: string) {
    await supabase.from('messages').update({ deleted: true }).eq('id', id).eq('sender_id', myId)
    setMessages(ms => ms.map(m => m.id === id ? { ...m, deleted: true, content: 'Message deleted' } : m))
    setCtxMsg(null)
  }

  // ── Pin / clear / delete-for-me ──────────────────────────────

  /** Toggle "pin chat" for the given room — pinned rooms float to the top of the list. */
  async function togglePinChat(roomId: string) {
    if (!myId) return
    const room = rooms.find(r => r.id === roomId)
    if (!room) return
    const nextPinned = !room.pinned
    const { error } = await supabase.from('room_members').update({ pinned: nextPinned }).eq('room_id', roomId).eq('user_id', myId)
    if (error) {
      console.error('Failed to update pin state — has the pin/clear/delete migration been run on this Supabase project?', error.message)
      return
    }
    setRooms(prev => {
      const updated = prev.map(r => r.id === roomId ? { ...r, pinned: nextPinned } : r)
      const globalRoom = updated.find(r => r.type === 'global')
      const others = updated.filter(r => r.type !== 'global')
      const byRecency = (a: ChatRoom, b: ChatRoom) => (new Date(b.lastMsgAt ?? 0).getTime()) - (new Date(a.lastMsgAt ?? 0).getTime())
      const pinnedRooms = others.filter(r => r.pinned).sort(byRecency)
      const unpinnedRooms = others.filter(r => !r.pinned).sort(byRecency)
      return globalRoom ? [globalRoom, ...pinnedRooms, ...unpinnedRooms] : [...pinnedRooms, ...unpinnedRooms]
    })
    if (activeRoom?.id === roomId) setActiveRoom(r => r ? { ...r, pinned: nextPinned } : r)
  }

  /** Soft-clear a chat for me only — hides everything up to now, other member unaffected. */
  async function clearChatForMe(roomId: string) {
    if (!myId) return
    const cutoff = new Date().toISOString()
    const { error } = await supabase.from('room_members').update({ cleared_at: cutoff }).eq('room_id', roomId).eq('user_id', myId)
    if (error) {
      console.error('Failed to clear chat — has the pin/clear/delete migration been run on this Supabase project?', error.message)
      return
    }
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, clearedAt: cutoff, lastMsg: '', lastMsgId: null, lastMsgTime: '' } : r))
    if (activeRoom?.id === roomId) {
      setActiveRoom(r => r ? { ...r, clearedAt: cutoff } : r)
      setMessages([])
    }
  }

  /** Delete-for-me: hides a DM from my room list without affecting the other member. Global Chat is exempt. */
  async function deleteChatForMe(roomId: string) {
    if (!myId) return
    const room = rooms.find(r => r.id === roomId)
    if (!room || room.type === 'global') return
    const { error } = await supabase.from('room_members').update({ hidden_at: new Date().toISOString() }).eq('room_id', roomId).eq('user_id', myId)
    if (error) {
      console.error('Failed to delete chat — has the pin/clear/delete migration been run on this Supabase project?', error.message)
      return
    }
    setRooms(prev => prev.filter(r => r.id !== roomId))
    if (activeRoom?.id === roomId) { setActiveRoom(null); setShowConv(false); setMessages([]) }
  }

  /** Pin a message to the top of the active conversation, visible to all members.
   *  Global Chat: Staff/Moderator/Admin only. DMs: any member, unchanged. */
  async function pinMessage(msg: Message) {
    if (!activeRoom) return
    if (activeRoom.type === 'global' && !isStaff) return
    const { error } = await supabase.from('chat_rooms').update({ pinned_message_id: msg.id }).eq('id', activeRoom.id)
    if (error) {
      console.error('Failed to pin message — has the pin/clear/delete migration been run on this Supabase project?', error.message)
      return
    }
    setActiveRoom(r => r ? { ...r, pinnedMessageId: msg.id } : r)
    setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, pinnedMessageId: msg.id } : r))
    setPinnedMsgPreview({
      id: msg.id,
      content: msg.deleted ? 'Message deleted' : msg.content,
      senderName: msg.sender_id === myId ? 'You' : (msg.senderName || 'Unknown'),
    })
    setCtxMsg(null)
  }

  async function unpinMessage() {
    if (!activeRoom) return
    if (activeRoom.type === 'global' && !isStaff) return
    const { error } = await supabase.from('chat_rooms').update({ pinned_message_id: null }).eq('id', activeRoom.id)
    if (error) {
      console.error('Failed to unpin message:', error.message)
      return
    }
    setActiveRoom(r => r ? { ...r, pinnedMessageId: null } : r)
    setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, pinnedMessageId: null } : r))
    setPinnedMsgPreview(null)
  }

  /** Temporary pin, separate from the permanent pin above. Staff/Moderator/
   *  Admin, Global Chat only. Auto-expires client-side (no cron) — see the
   *  spotlightExpiresAt check wherever this is rendered/synced. */
  async function spotlightMessage(msg: Message, durationMinutes: number) {
    if (!activeRoom || activeRoom.type !== 'global' || !isStaff) return
    const expiresAt = new Date(Date.now() + durationMinutes * 60_000).toISOString()
    const { error } = await supabase.from('chat_rooms')
      .update({ spotlight_message_id: msg.id, spotlight_expires_at: expiresAt }).eq('id', activeRoom.id)
    if (error) {
      console.error('Failed to spotlight message:', error.message)
      return
    }
    setActiveRoom(r => r ? { ...r, spotlightMessageId: msg.id, spotlightExpiresAt: expiresAt } : r)
    setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, spotlightMessageId: msg.id, spotlightExpiresAt: expiresAt } : r))
    setSpotlightMsgPreview({
      id: msg.id,
      content: msg.deleted ? 'Message deleted' : msg.content,
      senderName: msg.sender_id === myId ? 'You' : (msg.senderName || 'Unknown'),
    })
    setCtxMsg(null)
  }

  async function clearSpotlight() {
    if (!activeRoom || activeRoom.type !== 'global' || !isStaff) return
    const { error } = await supabase.from('chat_rooms')
      .update({ spotlight_message_id: null, spotlight_expires_at: null }).eq('id', activeRoom.id)
    if (error) {
      console.error('Failed to clear spotlight:', error.message)
      return
    }
    setActiveRoom(r => r ? { ...r, spotlightMessageId: null, spotlightExpiresAt: null } : r)
    setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, spotlightMessageId: null, spotlightExpiresAt: null } : r))
    setSpotlightMsgPreview(null)

  }

  /** Surfaces a Global Chat poll as the Quick Poll in Discover. Same polls
   *  tables as any other poll — featured_poll just marks which one shows.
   *  Staff only, re-checked server-side in feature_poll(). */
  async function featureQuickPoll(msg: Message) {
    if (!msg.poll_id) return
    const { error } = await supabase.rpc('feature_poll', { p_poll_id: msg.poll_id })
    setCtxMsg(null)
    if (error) { showToast({ message: 'Could not feature that poll', icon: PieChart }); return }
    showToast({ message: 'Featured as Quick Poll', icon: PieChart })
  }

  /** Promotes/demotes a Global Chat message to Trending Now. Staff/Moderator/
   *  Admin only — enforced again server-side in trend_add_message/trend_remove,
   *  this is just the client-side gate. Capped at 3 live trends total (any
   *  mix of promoted messages + the QOTD thread); the server raises
   *  'trend_limit_reached' once full rather than silently evicting one. */
  async function toggleTrendMessage(msg: Message) {
    if (!activeRoom || activeRoom.type !== 'global' || !isStaff) return
    setCtxMsg(null)

    if (trendingMessageIds.has(msg.id)) {
      const { data: items } = await supabase.rpc('trending_list')
      const match = ((items as { id: string; message_id?: string }[]) || []).find(t => t.message_id === msg.id)
      if (match) await supabase.rpc('trend_remove', { p_id: match.id })
      setTrendingMessageIds(prev => { const next = new Set(prev); next.delete(msg.id); return next })
      showToast({ message: 'Removed from Trending', icon: Check })
      return
    }

    const { error } = await supabase.rpc('trend_add_message', { p_message_id: msg.id })
    if (error) {
      showToast({
        message: error.message?.includes('trend_limit_reached')
          ? 'Trending is full (max 3) — remove one first'
          : 'Could not add to Trending',
        icon: AlertTriangle, iconColor: 'var(--red)',
      })
      return
    }
    setTrendingMessageIds(prev => new Set(prev).add(msg.id))
    showToast({ message: 'Added to Trending Now', icon: Sparkles })
  }

  /** Private per-user bookmark — DMs only (see toggleStar's guard below and
   *  the context-menu condition that hides Star in Global Chat). Capped at
   *  MAX_STARRED_PER_ROOM per conversation. Nobody else ever sees this
   *  (see migration 0046). */
  async function toggleStar(messageId: string) {
    if (!myId || !activeRoom || activeRoom.type !== 'dm') return
    const currentlyStarred = myStarredIds.has(messageId)
    setMyStarredIds(prev => {
      const next = new Set(prev)
      currentlyStarred ? next.delete(messageId) : next.add(messageId)
      return next
    })
    const { error } = currentlyStarred ? await unstarMessage(myId, messageId) : await starMessage(myId, messageId, activeRoom.id)
    if (error) {
      setMyStarredIds(prev => {
        const next = new Set(prev)
        currentlyStarred ? next.add(messageId) : next.delete(messageId)
        return next
      })
      if (!currentlyStarred) setComposerError(error) // cap-reached message; unstar failures are rare enough to just log
      else console.error('Failed to toggle star:', error)
    }
  }

  function formatTime(iso: string) {
    const d = new Date(iso); const now = new Date(); const diff = now.getTime() - d.getTime()
    if (diff < 60000) return 'now'
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m`
    if (diff < 86400000) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    return d.toLocaleDateString([], { day: 'numeric', month: 'short' })
  }

  function roomLabel(room: ChatRoom): string {
    if (room.type === 'global') return 'Global Chat'
    if (room.name) return room.name
    const other = room.members.find(m => m.user_id !== myId)
    if (other) return other.profile.display_name || other.profile.username
    return 'Chat'
  }

  /** Resolves the last message's sender name from a room's already-loaded
   *  member list — used for the Global Chat preview ("Name: message"),
   *  where the sender could be anyone, not just "the other person". */
  function lastMsgSenderName(room: ChatRoom): string | null {
    if (!room.lastMsgSenderId) return null
    if (room.lastMsgSenderId === myId) return 'You'
    const sender = room.members.find(m => m.user_id === room.lastMsgSenderId)
    return sender ? (sender.profile.display_name || sender.profile.username) : null
  }

  // Open sender profile from a message click
  function openSenderProfile(msg: Message) {
    if (!msg.sender_id) return
    openProfilePreview(msg.sender_id)
  }

  const scopedRooms = roomFilter === 'global' ? rooms.filter(r => r.type === 'global')
    : rooms
  const filteredRooms = scopedRooms.filter(r => !roomSearch || roomLabel(r).toLowerCase().includes(roomSearch.toLowerCase()))
  const totalUnread = scopedRooms.reduce((s, r) => s + r.unread, 0)
  const groupedMessages = useMemo(() => groupMessages(messages), [messages])

  // Global Chat is pinned as its own fixed row directly under the list
  // header — above "Add Friends" and the scrollable list — rather than
  // sorted in amongst the DMs, so it's always the first thing visible.
  const globalRoomEntry = roomFilter === 'dms' ? filteredRooms.find(r => r.type === 'global') ?? null : null

  // Dynamic Duo — the partner's DM is lifted out of Messages into its own
  // section above it. It's still the same room, so opening it, its unread
  // count, and its context menu all behave exactly as before; only its
  // position and chrome change. Ending the duo drops it straight back
  // into the list, because duoState goes inactive and this becomes null.
  const duoPartnerId = duoState?.active ? duoState.partner.id : null
  const duoRoomEntry = duoPartnerId && roomFilter === 'dms'
    ? filteredRooms.find(r => r.type !== 'global' && r.members.some(m => m.user_id === duoPartnerId)) ?? null
    : null

  const nonGlobalFilteredRooms = filteredRooms.filter(
    r => r.type !== 'global' && r.id !== duoRoomEntry?.id,
  )

  // Global mode has exactly one room and no list UI — open it the moment it's loaded.
  useEffect(() => {
    if (roomFilter !== 'global' || activeRoom) return
    const globalRoom = rooms.find(r => r.type === 'global')
    if (globalRoom) openRoom(globalRoom)
  }, [roomFilter, rooms, activeRoom, openRoom])

  const showList = roomFilter !== 'global' && (!isMobile || !showConv)
  const showChat = roomFilter === 'global' || !isMobile || showConv

  // Tell ChatHub when we're showing a conversation with no list beside it on
  // mobile, so it can hide the rail and let the chat use the full width.
  useEffect(() => {
    onFullScreenChatChange?.(isMobile && showChat && !showList)
  }, [isMobile, showChat, showList, onFullScreenChatChange])

  useEffect(() => {
    return () => { onFullScreenChatChange?.(false) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (!chatFlagLoading && !isChatFlagEnabled('system:chat') && !isStaff) {
    return (
      <FeatureGateScreen title="Chat is temporarily unavailable" />
    )
  }

  return (
    <div className="flex overflow-hidden relative" style={{ height: 'calc(100dvh - 60px - var(--dock-space, 0px))' }}>
      <PageOnboarding pageKey="chat" />

      {/* ── Contact list + player search ── */}
      {showList && (
        <div className="w-full sm:w-[320px] flex-shrink-0 flex flex-col overflow-hidden" style={{ borderRight: isMobile ? 'none' : '1px solid rgba(255,255,255,0.06)' }}>

          {/* Header */}
          <div className="p-0 sm:p-3 md:p-4 pb-2">
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10, padding: isMobile ? '12px 12px 0' : 0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <span style={{ fontSize:17, fontWeight:700, color:'var(--text)' }}>Messages</span>
                {totalUnread > 0 && <span style={{ background:'var(--accent)', color:'#fff', fontSize:10, fontWeight:700, padding:'2px 7px', borderRadius:10 }}>{totalUnread}</span>}
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                <IBtn title="Search chats" onClick={() => setRoomSearchOpen(o => !o)} style={roomSearchOpen ? { color:'var(--text)', borderColor:'var(--accent)' } : undefined}>
                  <Search size={15} />
                </IBtn>
                <IBtn><MoreVertical size={15} /></IBtn>
              </div>
            </div>

            {/* Room search — icon above reveals this inline */}
            {roomSearchOpen && (
              <div className="neu-inset" style={{ display:'flex', alignItems:'center', gap:8, borderRadius:12, padding:'8px 12px', marginBottom:8, marginInline: isMobile ? 12 : 0 }}>
                <Search size={14} style={{ color:'var(--text-muted)', flexShrink:0 }} />
                <input type="text" autoFocus placeholder="Search chats…" value={roomSearch} onChange={e => setRoomSearch(e.target.value)}
                  style={{ flex:1, background:'transparent', border:'none', outline:'none', fontSize:13, color:'var(--text)' }} />
                <button type="button" onClick={() => { setRoomSearchOpen(false); setRoomSearch('') }} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:0, display:'flex' }}>
                  <X size={13} />
                </button>
              </div>
            )}

            {/* Global Chat — pinned as its own fixed row directly under the
                header, above Add Friends and the scrollable DM list, so it's
                always the first thing visible instead of sorted in amongst
                other rooms. Bare Globe icon (no background chip), themed to
                the active accent instead of a fixed blue, and the preview
                shows who sent the last message. */}
            {globalRoomEntry && (() => {
              const room = globalRoomEntry
              const senderName = lastMsgSenderName(room)
              const preview = !room.lastMsg ? '👋 Say hello to everyone!' : senderName ? `${senderName}: ${room.lastMsg}` : room.lastMsg
              return (
                <div className="ripple-wrap ripple-neu" style={{ marginBottom: 8, marginInline: isMobile ? 12 : 0 }}>
                  <div role="button" tabIndex={0} onClick={(e) => { ripple(e); openRoom(room) }}
                    onKeyDown={e => { if (e.key === 'Enter') openRoom(room) }}
                    className="neu-card"
                    style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 14px', width:'100%', cursor:'pointer', border: activeRoom?.id === room.id && !isMobile ? '1px solid var(--accent)' : undefined }}>
                    <div style={{ width:44, height:44, borderRadius:13, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--accent)' }}>
                      <Globe size={26} />
                    </div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:3 }}>
                        <span style={{ fontSize:14, fontWeight:700, color:'var(--accent)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{roomLabel(room)}</span>
                        <span style={{ fontSize:11, color:'var(--text-muted)', flexShrink:0, marginLeft:8 }}>{room.lastMsgTime}</span>
                      </div>
                      <span style={{ fontSize:12, color:'var(--text-muted)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', display:'block' }}>{preview}</span>
                    </div>
                    {room.unread > 0 && <span style={{ fontSize:10, fontWeight:700, color:'#fff', background:'var(--accent)', borderRadius:10, padding:'2px 6px', flexShrink:0 }}>{room.unread}</span>}
                  </div>
                </div>
              )
            })()}

            {/* Dynamic Duo — its own labelled section between Global Chat
                and the DM list, so the partner never has to be hunted for
                among ordinary conversations. The row carries the live duo
                level; everything else about the room is unchanged. */}
            {duoRoomEntry && duoState?.active && (
              <div style={{ marginInline: isMobile ? 12 : 0, marginBottom: 8 }}>
                <p style={{
                  fontSize: 10.5, fontWeight: 800, letterSpacing: 0.08, textTransform: 'uppercase',
                  color: 'var(--text-muted)', padding: '2px 4px 8px', margin: 0,
                  display: 'flex', alignItems: 'center', gap: 5,
                }}>
                  <VenetianMask size={12} /> Dynamic Duo
                </p>
                <DuoRow
                  name={roomLabel(duoRoomEntry)}
                  avatarUrl={duoRoomEntry.members.find(m => m.user_id !== myId)?.profile?.avatar ?? null}
                  userId={duoRoomEntry.members.find(m => m.user_id !== myId)?.user_id ?? null}
                  level={duoState.level}
                  subtitle={duoRoomEntry.lastMsg || 'No messages yet'}
                  onClick={() => openRoom(duoRoomEntry)}
                  trailing={duoRoomEntry.unread > 0 ? (
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#fff', background: 'var(--accent)', borderRadius: 10, padding: '2px 6px', flexShrink: 0 }}>
                      {duoRoomEntry.unread}
                    </span>
                  ) : undefined}
                />
              </div>
            )}

            {/* Add Friends — lives inline with the chat list itself, Discord-style,
                instead of a separate full-screen overlay. Toggles the same
                find-players search used inside Global Chat (playerSearchOpen). */}
            {roomFilter === 'dms' && (
              <button type="button" onClick={() => setPlayerSearchOpen(o => !o)}
                className={playerSearchOpen ? undefined : 'neu-card-sm'}
                style={{
                  display:'flex', alignItems:'center', justifyContent:'center', gap:6, width: isMobile ? 'calc(100% - 24px)' : '100%',
                  marginInline: isMobile ? 12 : 0, marginBottom:8, padding:'8px 12px', borderRadius:12, cursor:'pointer', border:'none',
                  background: playerSearchOpen ? 'var(--accent)' : undefined,
                  color: playerSearchOpen ? '#fff' : 'var(--text-dim)', fontSize:12.5, fontWeight:700,
                }}>
                <UserPlus size={13} /> Add Friends
              </button>
            )}

            {/* Inline find-players — same search UI Global Chat uses, surfaced here too
                so DMs and "start a new chat" live in one screen instead of a modal
                that sits on top of (and dims) the icon rail. */}
            {roomFilter === 'dms' && playerSearchOpen && (
              <div style={{ background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:12, marginBottom:8, marginInline: isMobile ? 12 : 0, overflow:'hidden' }}>
                {dmStartError && (
                  <div style={{ margin:'8px 10px 0', padding:'8px 12px', borderRadius:10, background:'rgba(255,107,107,0.1)', border:'1px solid rgba(255,107,107,0.25)', fontSize:12, color:'#ff6b6b' }}>
                    {dmStartError}
                  </div>
                )}
                <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 12px' }}>
                  <Search size={13} style={{ color:'var(--accent)', flexShrink:0 }} />
                  <input type="text" autoFocus placeholder="Find players by username…" value={playerSearch} onChange={e => setPlayerSearch(e.target.value)}
                    style={{ flex:1, background:'transparent', border:'none', outline:'none', fontSize:13, color:'var(--text)' }} />
                  {playerSearch && (
                    <button type="button" onClick={() => { setPlayerSearch(''); setPlayerResults([]) }} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:0, display:'flex' }}>
                      <X size={13} />
                    </button>
                  )}
                </div>
                {playerSearch.trim() && (
                  <div style={{ borderTop:'1px solid var(--border)', paddingBottom:6, maxHeight:280, overflowY:'auto' }}>
                    {playerSearching ? (
                      <div style={{ display:'flex', justifyContent:'center', padding:16 }}>
                        <span style={{ width:20, height:20, border:'2px solid var(--surface3)', borderTopColor:'var(--accent)', borderRadius:'50%', display:'block', animation:'spin 0.8s linear infinite' }} />
                      </div>
                    ) : playerResults.length === 0 ? (
                      <div style={{ padding:'8px 16px', fontSize:12, color:'var(--text-muted)' }}>No players found</div>
                    ) : (
                      playerResults.map(p => (
                        <button key={p.id} type="button" onClick={() => openProfilePreview(p.id)}
                          style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 12px', width:'100%', background:'transparent', border:'none', cursor:'pointer', textAlign:'left', transition:'background 0.12s' }}
                          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)' }}
                          onMouseLeave={e => { e.currentTarget.style.background = 'transparent' }}>
                          <Avatar name={p.display_name || p.username} avatarUrl={p.avatar || null} size={36} radius={10} />
                          <div style={{ flex:1, minWidth:0 }}>
                            <div style={{ fontSize:13, fontWeight:600, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.display_name || p.username}</div>
                            <div style={{ fontSize:11, color:'var(--text-muted)' }}>@{p.username}</div>
                          </div>
                          <button type="button" onClick={e => { e.stopPropagation(); startDmWith(p.id); setPlayerSearchOpen(false); setPlayerSearch('') }}
                            disabled={startingDmId === p.id}
                            title="Start chat"
                            style={{ background:'rgba(79,142,247,0.12)', border:'1px solid rgba(79,142,247,0.3)', borderRadius:8, padding:'5px 8px', cursor: startingDmId === p.id ? 'not-allowed' : 'pointer', color:'#4f8ef7', display:'flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, flexShrink:0, opacity: startingDmId === p.id ? 0.6 : 1 }}>
                            {startingDmId === p.id
                              ? <span style={{ width:12, height:12, border:'2px solid rgba(79,142,247,0.3)', borderTopColor:'#4f8ef7', borderRadius:'50%', display:'block', animation:'spin 0.8s linear infinite' }} />
                              : <MessageCircle size={12} />}
                            {startingDmId === p.id ? 'Opening…' : 'Chat'}
                          </button>
                        </button>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Room list — DMs only now; Global Chat is its own fixed row above (see globalRoomEntry) */}
          {dmStartError && (
            <div style={{ margin:'8px 16px', padding:'8px 12px', borderRadius:10, background:'rgba(255,107,107,0.1)', border:'1px solid rgba(255,107,107,0.25)', fontSize:12, color:'#ff6b6b' }}>
              {dmStartError}
            </div>
          )}
          <div style={{ flex:1, overflowY:'auto', padding: isMobile ? '0 12px' : 0 }}>
            {roomsLoading ? (
              <SkeletonRoomList />
            ) : nonGlobalFilteredRooms.length === 0 ? (
              <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', padding:40, gap:12 }}>
                <MessageCircle size={40} style={{ color:'var(--text-muted)' }} />
                <p style={{ fontSize:14, fontWeight:600, color:'var(--text-dim)', textAlign:'center' }}>No chats yet</p>
                <p style={{ fontSize:12, color:'var(--text-muted)', textAlign:'center', lineHeight:1.5 }}>Start a conversation from someone's profile.</p>
              </div>
            ) : (
              nonGlobalFilteredRooms.map(room => {
                return (
                  <div key={room.id} className="ripple-wrap" style={{ position:'relative', marginBottom:8 }}>
                    <div role="button" tabIndex={0} onClick={(e) => { ripple(e); openRoom(room) }}
                      onKeyDown={e => { if (e.key === 'Enter') openRoom(room) }}
                      className={activeRoom?.id === room.id && !isMobile ? undefined : 'neu-card-sm'}
                      style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 44px 12px 16px', width:'100%', cursor:'pointer', border: activeRoom?.id === room.id && !isMobile ? '1px solid var(--accent)' : 'none', background: activeRoom?.id === room.id && !isMobile ? 'var(--surface)' : undefined, borderRadius: 14, textAlign:'left' }}>
                      {(() => {
                        const other = room.members.find(m => m.user_id !== myId)
                        return (
                          <div style={{ position:'relative', flexShrink:0 }}>
                            <Avatar name={roomLabel(room)} avatarUrl={other?.profile?.avatar || null} size={44} />
                            {other && onlineUserIds.has(other.user_id) && <OnlineDot />}
                          </div>
                        )
                      })()}
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:3 }}>
                          <div style={{ display:'flex', alignItems:'center', gap:6, minWidth:0 }}>
                            {room.pinned && <Pin size={11} style={{ color:'var(--accent)', flexShrink:0 }} />}
                            <span style={{ fontSize:14, fontWeight:700, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{roomLabel(room)}</span>
                            {room.type === 'dm' && room.members.find(m => m.user_id !== myId && (m.profile.is_official === true || m.profile.is_halo_ai === true || m.profile.is_groove_official === true || m.profile.is_pvp_official === true || m.profile.is_warden_official === true)) && (
                              <VerifiedBadge size={12} />
                            )}
                            {/* A pending DM request stays in the normal list
                                rather than getting its own tab — the pill is
                                what separates it from an open conversation.
                                Incoming reads "Request", outgoing "Sent", so
                                the sender can tell their message is still
                                waiting rather than ignored. */}
                            {(() => {
                              const req = dmRequestStateOf(
                                { type: room.type, dm_initiator_id: room.dmInitiatorId, dm_accepted_at: room.dmAcceptedAt },
                                myId,
                              )
                              if (req === 'none') return null
                              return (
                                <span style={{
                                  fontSize:9.5, fontWeight:800, letterSpacing:0.3, textTransform:'uppercase',
                                  color: req === 'incoming' ? 'var(--accent)' : 'var(--text-muted)',
                                  border: `1px solid ${req === 'incoming' ? 'var(--accent)' : 'var(--border-strong)'}`,
                                  borderRadius:6, padding:'1px 5px', flexShrink:0,
                                }}>
                                  {req === 'incoming' ? 'Request' : 'Sent'}
                                </span>
                              )
                            })()}
                          </div>
                          <span style={{ fontSize:11, color:'var(--text-muted)', flexShrink:0, marginLeft:8 }}>{room.lastMsgTime}</span>
                        </div>
                        <span style={{ fontSize:12, color:'var(--text-muted)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', display:'block' }}>
                          {room.lastMsg || 'No messages yet'}
                        </span>
                      </div>
                      {room.unread > 0 && <span style={{ fontSize:10, fontWeight:700, color:'#fff', background:'var(--accent)', borderRadius:10, padding:'2px 6px', flexShrink:0 }}>{room.unread}</span>}
                    </div>

                    {/* Per-row 3-dot menu — Pin / Delete */}
                    <div style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)' }}>
                      <button type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          const rect = e.currentTarget.getBoundingClientRect()
                          setRoomMenuPos({ x: rect.right, y: rect.bottom + 4 })
                          setRoomMenuOpenFor(o => o === room.id ? null : room.id)
                        }}
                        style={{ width:28, height:28, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)' }}>
                        <MoreVertical size={15} />
                      </button>
                    </div>
                  </div>
                )
              })
            )}

            {/* ── Discover ──────────────────────────────────────────
                Section header lives here rather than inside QotdCard, so
                the QOTD card, the Quick Poll and Trending all sit under
                one heading — and so the staff gear has somewhere to go.
                Restored after it was lost in the Dynamic Duo merge. */}
            <div style={{
              display:'flex', alignItems:'center', justifyContent:'space-between',
              padding:'12px 4px 8px', marginInline: isMobile ? 12 : 0,
            }}>
              <p style={{
                fontSize:10.5, fontWeight:800, letterSpacing:0.08, textTransform:'uppercase',
                color:'var(--text-muted)', margin:0,
              }}>
                Discover
              </p>
              {isStaff && (
                <button
                  type="button"
                  onClick={() => setDiscoverManageOpen(true)}
                  title="Manage Discover"
                  style={{
                    width:26, height:26, borderRadius:8, border:'none', cursor:'pointer',
                    background:'var(--surface2)', color:'var(--text-muted)',
                    display:'flex', alignItems:'center', justifyContent:'center',
                  }}>
                  <Settings size={13} />
                </button>
              )}
            </div>

            <div style={{ marginInline: isMobile ? 12 : 0 }}>
              <QotdCard />
              <QuickPoll />
            </div>
            <TrendingNow />
          </div>
        </div>
      )}

      {/* ── Conversation panel ── */}
      {showChat && (
        <div style={{ flex:1, display:'flex', flexDirection:'column', minWidth:0, position:'relative' }}>
          {activeRoom ? (
            <>
              {/* Conv topbar — single full-width header block: title on the left, back
                  arrow + retractable action drawer on the right. The drawer is a small
                  rectangle that slides open horizontally to reveal icons, then retracts
                  cleanly back into the header on toggle. */}
              <div style={{ display:'flex', alignItems:'center', gap:10, padding:'0 12px 0 16px', height:56, flexShrink:0, background:'color-mix(in srgb, var(--nav) 92%, transparent)', backdropFilter:'blur(14px)', borderBottom:'1px solid var(--border)', position:'relative' }}>
                <div style={{ display:'flex', alignItems:'center', gap:10, flex:1, minWidth:0,
                  cursor: activeRoom.type === 'dm' ? 'pointer' : 'default' }}
                  onClick={() => { if (activeRoom.type === 'dm') setDmOptionsOpen(true) }}>
                  {activeRoom.type === 'global' ? (
                    <div style={{ width:34, height:34, borderRadius:10, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--accent)' }}>
                      <Globe size={20} />
                    </div>
                  ) : (() => {
                    const other = activeRoom.members.find(m => m.user_id !== myId)
                    return (
                      <div style={{ position:'relative', flexShrink:0 }}>
                        <Avatar name={roomLabel(activeRoom)} avatarUrl={other?.profile?.avatar || null} size={34} radius={10} />
                        {other && onlineUserIds.has(other.user_id) && <OnlineDot size={9} />}
                      </div>
                    )
                  })()}
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontSize:14, fontWeight:700, color: activeRoom.type === 'global' ? 'var(--accent)' : 'var(--text)', display:'flex', alignItems:'center', gap:5 }}>
                      {roomLabel(activeRoom)}
                      {activeRoom.type === 'dm' && activeRoom.members.some(m => m.user_id !== myId && (m.profile.is_official === true || m.profile.is_halo_ai === true || m.profile.is_groove_official === true || m.profile.is_pvp_official === true || m.profile.is_warden_official === true)) && (
                        <VerifiedBadge size={13} />
                      )}
                    </div>
                    {activeRoom.type === 'global' && (
                      <div style={{ fontSize:11, color:'var(--text-muted)' }}>
                        Open to all Chillverse players
                      </div>
                    )}
                    {activeRoom.type === 'dm' && (() => {
                      const other = activeRoom.members.find(m => m.user_id !== myId)
                      if (!other || !onlineUserIds.has(other.user_id)) return null
                      return <div style={{ fontSize:11, color:'#3ecf8e', fontWeight:600 }}>Online</div>
                    })()}
                  </div>
                </div>

                {/* Retractable action drawer + back arrow, grouped on the right */}
                <div style={{ display:'flex', alignItems:'center', gap:6, flexShrink:0 }}>
                  <div style={{
                    display:'flex', alignItems:'center', gap:6,
                    overflow: 'hidden',
                    maxWidth: headerDrawerOpen ? 220 : 0,
                    opacity: headerDrawerOpen ? 1 : 0,
                    background: headerDrawerOpen ? 'var(--surface2)' : 'transparent',
                    border: headerDrawerOpen ? '1px solid rgba(255,255,255,0.08)' : '1px solid transparent',
                    borderRadius:10,
                    padding: headerDrawerOpen ? '2px 4px' : '2px 0',
                    transition:'max-width 0.28s ease, opacity 0.2s ease, padding 0.28s ease, background 0.2s ease',
                  }}>
                    {activeRoom.type === 'dm' && dmBlockState === 'none' && (() => {
                      const other = activeRoom.members.find(m => m.user_id !== myId)
                      if (!other) return null
                      // Official/Halo AI accounts don't take calls — same posture as
                      // the Call button ProfilePreviewModal already hides for isOfficial.
                      if (other.profile.is_official === true || other.profile.is_halo_ai === true || other.profile.is_groove_official === true || other.profile.is_pvp_official === true || other.profile.is_warden_official === true) return null
                      return <StartCallButton roomId={activeRoom.id} callee={{ id: other.user_id, username: other.profile.username, display_name: other.profile.display_name, avatar: other.profile.avatar }} size={32} />
                    })()}
                    {activeRoom.type === 'dm' && (
                      <IBtn onClick={() => setGhostReadActive(v => !v)} style={{ width:32, height:32, ...(ghostReadActive ? { color:'var(--accent)', borderColor:'var(--accent)' } : {}) }}
                        title={ghostReadActive ? 'Ghost Read is on — reopen the chat to turn it off' : 'Open without marking as read (this visit only)'}>
                        {ghostReadActive ? <EyeOff size={14} /> : <Eye size={14} />}
                      </IBtn>
                    )}
                    {activeRoom.type === 'dm' && (
                      <IBtn onClick={() => setStarredPanelOpen(true)} style={{ width:32, height:32 }} title="Starred messages">
                        <Star size={14} />
                      </IBtn>
                    )}
                    <IBtn onClick={() => { setMsgSearchOpen(o => !o); if (msgSearchOpen) setMsgSearchQuery('') }} style={{ width:32, height:32 }}>
                      <Search size={14} />
                    </IBtn>
                    {activeRoom.type === 'global' && (
                      <IBtn onClick={() => setPlayerSearchOpen(o => !o)} style={{ width:32, height:32, ...(playerSearchOpen ? { color:'#4f8ef7', borderColor:'rgba(79,142,247,0.4)' } : {}) }} title="Find players by username">
                        <MessageCircle size={14} />
                      </IBtn>
                    )}
                    {isStaff && activeRoom.type === 'global' && (
                      <IBtn onClick={() => setGlobalInviteOpen(true)} style={{ width:32, height:32 }} title="Manage invite link (staff only)">
                        <Link2 size={14} />
                      </IBtn>
                    )}
                    {activeRoom.type === 'dm' && (
                      <IBtn onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect()
                        setConvMenuPos({ x: rect.right, y: rect.bottom + 4 })
                        setConvMenuOpen(o => !o)
                      }} style={{ width:32, height:32 }}><MoreVertical size={14} /></IBtn>
                    )}
                  </div>
                  <IBtn onClick={() => setHeaderDrawerOpen(o => !o)} style={{ background: headerDrawerOpen ? 'var(--surface2)' : 'var(--surface)' }}>
                    {headerDrawerOpen ? <X size={15} /> : <MoreVertical size={15} />}
                  </IBtn>
                  <IBtn onClick={() => { setShowConv(false); if (!isMobile) setActiveRoom(null) }}>
                    <ArrowLeft size={15} />
                  </IBtn>
                </div>
              </div>

              {/* Message search bar — slides in below the header when the drawer's search icon is toggled */}
              {msgSearchOpen && (
                <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 14px', background:'var(--surface2)', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
                  <Search size={13} style={{ color:'var(--text-muted)', flexShrink:0 }} />
                  <input
                    type="text"
                    autoFocus
                    placeholder="Search in this chat…"
                    value={msgSearchQuery}
                    onChange={e => setMsgSearchQuery(e.target.value)}
                    style={{ flex:1, background:'transparent', border:'none', outline:'none', fontSize:13, color:'var(--text)' }}
                  />
                  {msgSearchQuery && (
                    <button type="button" onClick={() => setMsgSearchQuery('')} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:0, display:'flex' }}>
                      <X size={13} />
                    </button>
                  )}
                </div>
              )}

              {/* Find-players composer — Global Chat only, slides in below the header */}
              {activeRoom.type === 'global' && playerSearchOpen && (
                <div style={{ borderBottom:'1px solid var(--border)', background:'var(--surface2)', flexShrink:0 }}>
                  {dmStartError && (
                    <div style={{ margin:'8px 14px 0', padding:'8px 12px', borderRadius:10, background:'rgba(255,107,107,0.1)', border:'1px solid rgba(255,107,107,0.25)', fontSize:12, color:'#ff6b6b' }}>
                      {dmStartError}
                    </div>
                  )}
                  <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 14px' }}>
                    <Search size={13} style={{ color:'#4f8ef7', flexShrink:0 }} />
                    <input type="text" autoFocus placeholder="Find players by username…" value={playerSearch} onChange={e => setPlayerSearch(e.target.value)}
                      style={{ flex:1, background:'transparent', border:'none', outline:'none', fontSize:13, color:'var(--text)' }} />
                    {playerSearch && (
                      <button type="button" onClick={() => { setPlayerSearch(''); setPlayerResults([]) }} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:0, display:'flex' }}>
                        <X size={13} />
                      </button>
                    )}
                  </div>
                  {playerSearch.trim() && (
                    <div style={{ borderTop:'1px solid var(--border)', paddingBottom:6, maxHeight:280, overflowY:'auto' }}>
                      {playerSearching ? (
                        <div style={{ display:'flex', justifyContent:'center', padding:16 }}>
                          <span style={{ width:20, height:20, border:'2px solid var(--surface3)', borderTopColor:'#4f8ef7', borderRadius:'50%', display:'block', animation:'spin 0.8s linear infinite' }} />
                        </div>
                      ) : playerResults.length === 0 ? (
                        <div style={{ padding:'8px 16px', fontSize:12, color:'var(--text-muted)' }}>No players found</div>
                      ) : (
                        playerResults.map(p => (
                          <button key={p.id} type="button" onClick={() => openProfilePreview(p.id)}
                            style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 16px', width:'100%', background:'transparent', border:'none', cursor:'pointer', textAlign:'left', transition:'background 0.12s' }}
                            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)' }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'transparent' }}>
                            <Avatar name={p.display_name || p.username} avatarUrl={p.avatar || null} size={36} radius={10} />
                            <div style={{ flex:1, minWidth:0 }}>
                              <div style={{ fontSize:13, fontWeight:600, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.display_name || p.username}</div>
                              <div style={{ fontSize:11, color:'var(--text-muted)' }}>@{p.username}</div>
                            </div>
                            <button type="button" onClick={e => { e.stopPropagation(); startDmWith(p.id); setPlayerSearchOpen(false) }}
                              disabled={startingDmId === p.id}
                              title="Start chat"
                              style={{ background:'rgba(79,142,247,0.12)', border:'1px solid rgba(79,142,247,0.3)', borderRadius:8, padding:'5px 8px', cursor: startingDmId === p.id ? 'not-allowed' : 'pointer', color:'#4f8ef7', display:'flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, flexShrink:0, opacity: startingDmId === p.id ? 0.6 : 1 }}>
                              {startingDmId === p.id
                                ? <span style={{ width:12, height:12, border:'2px solid rgba(79,142,247,0.3)', borderTopColor:'#4f8ef7', borderRadius:'50%', display:'block', animation:'spin 0.8s linear infinite' }} />
                                : <MessageCircle size={12} />}
                              {startingDmId === p.id ? 'Opening…' : 'Chat'}
                            </button>
                          </button>
                        ))
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Spotlight banner — temporary pin, shows above the permanent pin below */}
              {spotlightMsgPreview && activeRoom.type === 'global' && (
                <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 16px', background:'rgba(255,193,7,0.10)', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
                  <Zap size={13} style={{ color:'#ffc107', flexShrink:0 }} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:10.5, fontWeight:700, color:'#ffc107' }}>Spotlight — {spotlightMsgPreview.senderName}</div>
                    <div style={{ fontSize:12, color:'var(--text-dim)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{spotlightMsgPreview.content}</div>
                  </div>
                  {isStaff && (
                    <button type="button" onClick={clearSpotlight} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:4, flexShrink:0 }}>
                      <X size={13} />
                    </button>
                  )}
                </div>
              )}

              {/* Pinned message banner */}
              {pinnedMsgPreview && (
                <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 16px', background:'rgba(79,142,247,0.08)', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
                  <Pin size={13} style={{ color:'#4f8ef7', flexShrink:0 }} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:10.5, fontWeight:700, color:'#4f8ef7' }}>{pinnedMsgPreview.senderName}</div>
                    <div style={{ fontSize:12, color:'var(--text-dim)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{pinnedMsgPreview.content}</div>
                  </div>
                  {(activeRoom.type !== 'global' || isStaff) && (
                    <button type="button" onClick={unpinMessage} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:4, flexShrink:0 }}>
                      <X size={13} />
                    </button>
                  )}
                </div>
              )}

              {/* Messages */}
              <div style={{ position:'relative', flex:1, minHeight:0, display:'flex', flexDirection:'column' }}>
              <div
                ref={scrollContainerRef}
                onScroll={e => {
                  const el = e.currentTarget
                  isNearBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < NEAR_BOTTOM_PX
                  if (isNearBottomRef.current) {
                    markRoomAsRead(activeRoom.id)
                    setShowJumpToBottom(false)
                    setJumpToBottomCount(0)
                  } else {
                    setShowJumpToBottom(true)
                  }
                  if (el.scrollTop < 80) loadOlderMessages()
                }}
                style={{ flex:1, overflowY:'auto', padding:'12px 10px', display:'flex', flexDirection:'column' }}>
                {msgsLoading ? (
                  <SkeletonBubbles />
                ) : messages.length === 0 ? (
                  activeRoom.type === 'dm' ? (() => {
                    const other = activeRoom.members.find(m => m.user_id !== myId)
                    const otherName = other ? (other.profile.display_name || other.profile.username) : roomLabel(activeRoom)
                    return (
                      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flex:1, gap:18, padding:'0 24px', textAlign:'center' }}>
                        <div style={{ position:'relative', width:82, height:74 }}>
                          <span style={{ position:'absolute', left:0, bottom:0, borderRadius:20, display:'block', overflow:'hidden', boxShadow:'0 8px 20px rgba(0,0,0,0.3)', border:'3px solid var(--bg)' }}>
                            <Avatar name={otherName} avatarUrl={other?.profile.avatar || null} size={56} radius={17} />
                          </span>
                          <span style={{ position:'absolute', right:0, top:0, borderRadius:20, display:'block', overflow:'hidden', boxShadow:'0 8px 20px rgba(0,0,0,0.3)', border:'3px solid var(--bg)' }}>
                            <Avatar name={myProfile?.display_name || myProfile?.username || 'You'} avatarUrl={myProfile?.avatar || null} size={56} radius={17} />
                          </span>
                          <span style={{ position:'absolute', left:-6, top:-6, width:26, height:26, borderRadius:'50%', background:'var(--surface2)', border:'1px solid var(--border)', boxShadow:'var(--elev-raise)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                            <MessageCircle size={12} style={{ color:'var(--text-dim)' }} />
                          </span>
                          <span style={{ position:'absolute', right:-6, bottom:-6, width:26, height:26, borderRadius:'50%', background:'var(--surface2)', border:'1px solid var(--border)', boxShadow:'var(--elev-raise)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:13 }}>
                            👋
                          </span>
                        </div>
                        <div>
                          <p style={{ fontSize:15, fontWeight:700, color:'var(--text)', margin:0 }}>{otherName}</p>
                          <p style={{ fontSize:12.5, color:'var(--text-muted)', margin:'4px 0 0' }}>This could be the beginning of something good</p>
                        </div>
                      </div>
                    )
                  })() : (
                    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flex:1, gap:10 }}>
                      <MessageCircle size={32} style={{ color:'var(--text-muted)' }} />
                      <p style={{ fontSize:13, color:'var(--text-muted)' }}>No messages yet. Say hello!</p>
                    </div>
                  )
                ) : (
                  <>
                    {loadingOlder && (
                      <div style={{ display:'flex', justifyContent:'center', padding:'8px 0 12px' }}>
                        <span style={{ width:18, height:18, border:'2px solid var(--surface3)', borderTopColor:'var(--accent)', borderRadius:'50%', display:'block', animation:'spin 0.8s linear infinite' }} />
                      </div>
                    )}
                    {(() => {
                      const notBlocked = groupedMessages.filter(m => !m.sender_id || !myBlockedIds.has(m.sender_id))
                      const query = msgSearchQuery.trim().toLowerCase()
                      const visible = query
                        ? notBlocked.filter(m => !m.deleted && !m.hidden && m.content.toLowerCase().includes(query))
                        : notBlocked

                      // Fold the flat, filtered list into consecutive-sender bursts — one
                      // chat-line block per burst, sharing a single avatar and underline.
                      // While searching, every match stands alone as its own block so it
                      // keeps its own avatar/context regardless of the original grouping.
                      const bursts: GroupedMessage[][] = []
                      for (const m of visible) {
                        const last = bursts[bursts.length - 1]
                        if (!query && last && !m.isGroupFirst) last.push(m)
                        else bursts.push([m])
                      }

                      // Resolve avatar for a sender: own messages use myProfile, others look up in room members
                      const avatarFor = (msg: Message, isMine: boolean): string | null => {
                        if (isMine) return myProfile?.avatar ?? null
                        const member = activeRoom?.members.find(mb => mb.user_id === msg.sender_id)
                        return member?.profile?.avatar ?? null
                      }

                      // Read receipt only means something for a DM — with a single
                      // other member, "read" is unambiguous. Global chat skips this.
                      const readReceiptFor = (msg: Message): ReadReceipt => {
                        const isMine = msg.sender_id === myId
                        if (!isMine || msg.deleted) return null
                        return activeRoom.type === 'dm' && otherLastReadAt && new Date(msg.created_at) <= new Date(otherLastReadAt)
                          ? 'read'
                          : 'sent'
                      }

                      if (query && bursts.length === 0) {
                        return (
                          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flex:1, gap:8, padding:'40px 0' }}>
                            <Search size={26} style={{ color:'var(--text-muted)' }} />
                            <p style={{ fontSize:12.5, color:'var(--text-muted)' }}>No messages match "{msgSearchQuery.trim()}"</p>
                          </div>
                        )
                      }

                      return bursts.map(burst => {
                        const first = burst[0]
                        const isMine = first.sender_id === myId
                        const senderLabel = isMine ? 'You' : (first.senderName || 'Unknown')

                        // Discord-style "new messages" line — rendered once, right
                        // above the burst that contains the first unread message.
                        const divider = (!query && newMessagesBeforeId && burst.some(m => m.id === newMessagesBeforeId)) ? (
                          <div key={`divider-${first.id}`} style={{ display:'flex', alignItems:'center', gap:10, margin:'6px 4px 12px' }}>
                            <div style={{ flex:1, height:1, background:'#f23f42' }} />
                            <span style={{ fontSize:10.5, fontWeight:800, letterSpacing:0.6, color:'#f23f42', textTransform:'uppercase', flexShrink:0 }}>New messages</span>
                            <div style={{ flex:1, height:1, background:'#f23f42' }} />
                          </div>
                        ) : null

                        // Rank Tags and Polls are always a burst of one (see the grouping
                        // fix in groupMessages) and render full-width, outside the normal
                        // avatar+bubble column — deliberately not styled like a chat message.
                        if (burst.length === 1 && first.type === 'rank_tag') {
                          return (
                            <Fragment key={first.id}>
                              {divider}
                              <RankTagAnnouncement msg={first} senderLabel={senderLabel} formatTime={formatTime} myId={myId} />
                            </Fragment>
                          )
                        }
                        if (burst.length === 1 && first.type === 'poll' && first.poll_id) {
                          return (
                            <Fragment key={first.id}>
                              {divider}
                              {first.hidden
                                ? <HiddenContentNotice reason={first.hidden_reason} isOwner={isMine} />
                                : <PollMessage pollId={first.poll_id} myId={myId} isStaff={isStaff} refreshToken={pollRefreshToken} />}
                            </Fragment>
                          )
                        }

                        return (
                          <Fragment key={first.id}>
                            {divider}
                            <MessageBurst
                              reactionsFor={reactionsFor}
                              onOpenReactors={openReactors}
                              burst={burst}
                              isMine={isMine}
                              senderLabel={senderLabel}
                              senderNameFont={first.senderNameFont}
                              senderNameColor={first.senderNameColor}
                              avatarUrl={avatarFor(first, isMine)}
                              onOpenProfile={openSenderProfile}
                              onContextMenu={(m, _x, _y) => { setCtxMsg(m) }}
                              onDoubleClick={m => setReplyTo(m)}
                              formatTime={formatTime}
                              readReceiptFor={readReceiptFor}
                              starredIds={myStarredIds}
                              isGroupChat={activeRoom.type === 'global'}
                              onJumpToReply={jumpToMessage}
                              highlightedMsgId={highlightedMsgId}
                              registerRef={registerMsgRef}
                              members={activeRoom.members}
                              onHaloAction={handleHaloWidgetAction}
                              haloActionBusyKey={haloActionBusyKey}
                            />
                          </Fragment>
                        )
                      })
                    })()}
                  </>
                )}
                <div ref={msgEnd} />
              </div>

              {/* Jump-to-bottom pill — shows once the reader scrolls away from the
                  latest message; badges how many new messages arrived while away. */}
              {showJumpToBottom && (
                <button
                  type="button"
                  className="ripple-wrap"
                  onClick={(e) => {
                    ripple(e)
                    const el = scrollContainerRef.current
                    if (el) el.scrollTop = el.scrollHeight
                    setShowJumpToBottom(false)
                    setJumpToBottomCount(0)
                    if (activeRoom) markRoomAsRead(activeRoom.id)
                  }}
                  style={{
                    position:'absolute', bottom:14, right:16, zIndex:20,
                    display:'flex', alignItems:'center', gap:6,
                    padding: jumpToBottomCount > 0 ? '6px 8px 6px 12px' : '9px',
                    borderRadius:20, border:'1px solid var(--border-strong)',
                    background:'var(--surface2)', boxShadow:'var(--elev-popover)',
                    cursor:'pointer', color:'var(--text)',
                  }}
                  title="Jump to latest messages"
                >
                  {jumpToBottomCount > 0 && (
                    <span style={{ fontSize:11, fontWeight:700, color:'var(--text-dim)' }}>
                      {jumpToBottomCount} new
                    </span>
                  )}
                  <span style={{
                    width:24, height:24, borderRadius:'50%', flexShrink:0,
                    background: jumpToBottomCount > 0 ? 'var(--accent)' : 'transparent',
                    display:'flex', alignItems:'center', justifyContent:'center',
                  }}>
                    <ChevronDown size={16} color={jumpToBottomCount > 0 ? '#fff' : 'var(--text)'} />
                  </span>
                </button>
              )}

              {/* Jump-to-message notice — a reply quote or mention notification pointed
                  at a message that's since been deleted or fallen out of Global Chat's
                  100-message cap. Brief and self-dismissing, not a hard error. */}
              {jumpNotice && (
                <div style={{
                  position:'absolute', bottom:14, left:'50%', transform:'translateX(-50%)', zIndex:20,
                  padding:'8px 14px', borderRadius:20, border:'1px solid var(--border-strong)',
                  background:'var(--surface2)', boxShadow:'var(--elev-popover)',
                  fontSize:12, color:'var(--text-dim)', whiteSpace:'nowrap',
                }}>
                  {jumpNotice}
                </div>
              )}
              </div>

              {/* Typing indicator — WhatsApp-style, shown just above the composer */}
              {typingUserIds.size > 0 && (
                <div style={{ padding:'2px 16px 4px', fontSize:11.5, fontStyle:'italic', color:'var(--text-muted)', flexShrink:0 }}>
                  {activeRoom.type === 'dm'
                    ? `${roomLabel(activeRoom)} is typing…`
                    : (() => {
                        const names = [...typingUserIds]
                          .map(id => activeRoom.members.find(m => m.user_id === id))
                          .filter((m): m is RoomMember => !!m)
                          .map(m => m.profile.display_name || m.profile.username)
                        if (names.length === 0) return null
                        if (names.length === 1) return `${names[0]} is typing…`
                        if (names.length === 2) return `${names[0]} and ${names[1]} are typing…`
                        return `${names.length} people are typing…`
                      })()}
                </div>
              )}

              {/* Reply bar */}
              {replyTo && (
                <div style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 14px', background:'var(--surface2)', borderTop:'1px solid var(--border)' }}>
                  <Reply size={14} style={{ color:'var(--accent)', flexShrink:0 }} />
                  <div style={{ flex:1, fontSize:12, color:'var(--text-dim)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                    <span style={{ color:'var(--accent)', fontWeight:600 }}>Replying to {replyTo.sender_id === myId ? 'yourself' : (replyTo.senderName || 'Unknown')}: </span>{replyTo.content}
                  </div>
                  <button type="button" onClick={() => setReplyTo(null)} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)' }}><X size={14} /></button>
                </div>
              )}

              {/* Pending rank tag — clears itself on send, mirrors the reply bar above */}
              {pendingRankTag && (() => {
                const g = RANK_GROUPS.find(rg => rg.id === pendingRankTag)!
                return (
                  <div style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 14px', background:'var(--surface2)', borderTop:'1px solid var(--border)' }}>
                    <Megaphone size={14} style={{ color: g.color, flexShrink:0 }} />
                    <div style={{ flex:1, fontSize:12, color:'var(--text-dim)' }}>
                      <span style={{ color: g.color, fontWeight:700 }}>Tagging @{g.label}</span> — notifies everyone in that rank
                    </div>
                    <button type="button" onClick={() => setPendingRankTag(null)} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)' }}><X size={14} /></button>
                  </div>
                )
              })()}

              {/* Request bar — replaces the composer while a DM is still a
                  request. Checked BEFORE the block banner: a pending room
                  can't have a block on it yet, and the request's own Block
                  button is the way one gets created. */}
              {activeRoom.type === 'dm' && dmRequestBlocking ? (
                <DmRequestBar
                  roomId={activeRoom.id}
                  state={dmRequestState}
                  otherName={(() => {
                    const other = activeRoom.members.find(mb => mb.user_id !== myId)
                    return other?.profile.display_name || other?.profile.username || 'They'
                  })()}
                  onAccepted={() => {
                    const now = new Date().toISOString()
                    setActiveRoom(r => r ? { ...r, dmAcceptedAt: now } : r)
                    setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, dmAcceptedAt: now } : r))
                  }}
                  onDismissed={(blocked) => {
                    // The room is deleted server-side for both sides, so
                    // there is nothing left to navigate back into.
                    const other = activeRoom.members.find(mb => mb.user_id !== myId)
                    setRooms(prev => prev.filter(r => r.id !== activeRoom.id))
                    setActiveRoom(null)
                    if (blocked && other) handleBlockChange(other.user_id, true)
                  }}
                  onError={message => setComposerError(message)}
                />
              ) : activeRoom.type === 'dm' && dmBlockState !== 'none' ? (
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, padding:'12px 16px', background:'rgba(255,107,107,0.08)', borderTop:'1px solid rgba(255,107,107,0.15)' }}>
                  <span style={{ fontSize:12.5, color:'#ff6b6b', fontWeight:600 }}>
                    {dmBlockState === 'blockedByMe' ? 'You blocked this user.' : "You can't reply to this conversation."}
                  </span>
                  {dmBlockState === 'blockedByMe' && (
                    <button type="button"
                      onClick={async () => {
                        const other = activeRoom.members.find(m => m.user_id !== myId)
                        if (!myId || !other) return
                        await supabase.from('blocks').delete().eq('blocker_id', myId).eq('blocked_id', other.user_id)
                        setDmBlockState('none')
                        handleBlockChange(other.user_id, false)
                      }}
                      style={{ fontSize:12, fontWeight:700, color:'#ff6b6b', background:'rgba(255,107,107,0.12)', border:'1px solid rgba(255,107,107,0.3)', borderRadius:10, padding:'6px 12px', cursor:'pointer', flexShrink:0 }}>
                      Unblock
                    </button>
                  )}
                </div>
              ) : (
                /* Input bar — text + emoji + send, or a voice-note recorder in place of the send button when idle */
                <div style={{ display:'flex', flexDirection:'column', position:'relative' }}>
                  {/* @mention autocomplete — opens while typing "@partial" in the composer,
                      lists matching room members to tap or Enter to insert. */}
                  {mentionQuery !== null && !isRecordingVoiceNote && (() => {
                    const suggestions = mentionSuggestions()
                    if (suggestions.length === 0) return null
                    return (
                      <div style={{
                        position:'absolute', left:12, right:12, bottom:'100%', marginBottom:6,
                        background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:12,
                        boxShadow:'var(--elev-popover)', overflow:'hidden', zIndex:50,
                      }}>
                        {suggestions.map(mb => (
                          <button
                            key={mb.user_id}
                            type="button"
                            onClick={() => applyMention(mb)}
                            style={{
                              width:'100%', display:'flex', alignItems:'center', gap:8,
                              padding:'8px 10px', background:'none', border:'none', cursor:'pointer', textAlign:'left',
                            }}
                            onMouseEnter={e => { e.currentTarget.style.background = 'var(--surface)' }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'none' }}
                          >
                            <Avatar name={mb.profile.display_name || mb.profile.username} avatarUrl={mb.profile.avatar} size={24} radius={8} />
                            <span style={{ fontSize:12.5, fontWeight:600, color:'var(--text)' }}>{mb.profile.display_name || mb.profile.username}</span>
                            <span style={{ fontSize:11.5, color:'var(--text-muted)' }}>@{mb.profile.username}</span>
                          </button>
                        ))}
                      </div>
                    )
                  })()}
                  {micError && (
                    <div style={{ padding:'6px 16px', fontSize:11.5, color:'#ff6b6b', background:'rgba(255,107,107,0.08)' }}>{micError}</div>
                  )}
                  {composerError && (
                    <div style={{ padding:'6px 16px', fontSize:11.5, color:'#ff6b6b', background:'rgba(255,107,107,0.08)' }}>{composerError}</div>
                  )}
                  <div style={{ display:'flex', alignItems:'flex-end', gap:8, padding:'10px 12px', background:'color-mix(in srgb, var(--nav) 92%, transparent)', backdropFilter:'blur(14px)', borderTop:'1px solid var(--border)' }}>
                    {!isRecordingVoiceNote && (
                      <div style={{ position:'relative', flexShrink:0 }}>
                        <input
                          ref={imageInputRef}
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/gif"
                          style={{ display:'none' }}
                          onChange={e => {
                            const file = e.target.files?.[0]
                            e.target.value = '' // let the same file be picked again after an error
                            if (file) sendImage(file)
                          }}
                        />
                        <IBtn onClick={() => setComposerDrawerOpen(o => !o)} style={{ background: composerDrawerOpen ? 'var(--surface2)' : 'var(--surface)' }}>
                          {composerDrawerOpen ? <X size={15} /> : <Paperclip size={15} />}
                        </IBtn>
                        <div style={{
                          position:'absolute', left:0, bottom:'calc(100% + 8px)',
                          display:'flex', flexDirection:'column', alignItems:'center', gap:6, overflow:'hidden',
                          maxHeight: composerDrawerOpen ? 160 : 0,
                          opacity: composerDrawerOpen ? 1 : 0,
                          transform: composerDrawerOpen ? 'translateY(0)' : 'translateY(8px)',
                          pointerEvents: composerDrawerOpen ? 'auto' : 'none',
                          background: 'var(--surface2)',
                          border: '1px solid var(--border)',
                          borderRadius:14,
                          padding: composerDrawerOpen ? '6px' : '0 6px',
                          boxShadow:'var(--elev-popover)',
                          transition:'max-height 0.28s ease, opacity 0.2s ease, transform 0.28s ease, padding 0.28s ease',
                          zIndex:50,
                        }}>
                          <IBtn onClick={() => setEmojiOpen(v => !v)} style={{ width:32, height:32 }}><Smile size={14} /></IBtn>
                          {canSendImages && (
                            <IBtn onClick={() => imageInputRef.current?.click()} title={`Send a picture (under ${Math.round(myImageLimitBytes / (1024 * 1024))}MB)`} style={{ width:32, height:32 }}><ImagePlus size={14} /></IBtn>
                          )}
                          {isStaff && activeRoom.type === 'global' && (
                            <IBtn onClick={() => setRankTagPickerOpen(v => !v)} title="Tag a rank group" style={{ width:32, height:32 }}><Megaphone size={14} /></IBtn>
                          )}
                          {canCreatePoll && activeRoom.type === 'global' && (
                            <IBtn onClick={() => setPollModalOpen(true)} title="Create a poll" style={{ width:32, height:32 }}><BarChart3 size={14} /></IBtn>
                          )}
                        </div>
                      </div>
                    )}
                    {!isRecordingVoiceNote && (
                      <div style={{ flex:1, background:'var(--surface)', boxShadow:'var(--elev-inset)', border:'1px solid var(--border)', borderRadius:14, padding:'9px 12px', display:'flex', alignItems:'flex-end' }}>
                        <textarea ref={textareaRef} rows={1} value={text} onChange={handleTextChange} onKeyDown={handleKey} onBlur={handleTextBlur}
                          placeholder="Type a message…" maxLength={MAX_MESSAGE_LENGTH}
                          style={{ flex:1, background:'transparent', border:'none', outline:'none', color:'var(--text)', fontSize:13.5, resize:'none', maxHeight:COMPOSER_MAX_HEIGHT, overflowY:'auto', lineHeight:1.4, fontFamily:'inherit' }} />
                      </div>
                    )}
                    {text.trim() ? (
                      <button type="button" onClick={sendMsg} disabled={!text.trim() || sending}
                        style={{ width:40, height:40, borderRadius:11, flexShrink:0, border:'none', background:'linear-gradient(135deg,var(--accent),var(--accent2))', boxShadow:'0 4px 14px color-mix(in srgb, var(--accent) 35%, transparent)', color:'#fff', cursor: !text.trim() || sending ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', justifyContent:'center', transition:'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out), opacity var(--dur-fast) var(--ease-out)', opacity: !text.trim() || sending ? 0.6 : 1 }}>
                        <Send size={16} />
                      </button>
                    ) : myIsVoid ? (
                      <VoiceNoteRecorderButton
                        onSend={sendVoiceNote}
                        onError={setMicError}
                        onRecordingChange={setIsRecordingVoiceNote}
                        disabled={sending}
                      />
                    ) : (
                      <button
                        type="button"
                        onClick={() => navigate('/pro')}
                        title="Voice notes are a Chillverse Pro perk (Void)"
                        style={{ width:40, height:40, borderRadius:11, flexShrink:0, border:'1px solid var(--border)', background:'var(--surface2)', color:'var(--text-dim)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}
                      >
                        <Lock size={15} />
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Emoji picker */}
              {emojiOpen && (
                <div style={{ position:'absolute', bottom:70, right:14, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:16, padding:12, display:'flex', flexWrap:'wrap', gap:4, boxShadow:'var(--elev-popover)', maxWidth:230, zIndex:50 }}>
                  {EMOJIS.map(em => (
                    <button key={em} type="button" onClick={() => { setText(t => t + em); setEmojiOpen(false) }} style={{ background:'none', border:'none', cursor:'pointer', fontSize:20, padding:3 }}>{em}</button>
                  ))}
                </div>
              )}

              {/* Rank tag picker — Staff/Moderator/Admin, Global Chat only */}
              {rankTagPickerOpen && (
                <div style={{ position:'absolute', bottom:70, right:14, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:16, padding:10, display:'flex', flexDirection:'column', gap:4, boxShadow:'var(--elev-popover)', minWidth:170, zIndex:50 }}>
                  <div style={{ fontSize:10.5, fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:0.3, padding:'2px 6px 4px' }}>Tag a rank</div>
                  {RANK_GROUPS.map(g => (
                    <button key={g.id} type="button"
                      onClick={() => { setPendingRankTag(g.id); setRankTagPickerOpen(false) }}
                      style={{ display:'flex', alignItems:'center', gap:8, background:'none', border:'none', cursor:'pointer', padding:'6px 8px', borderRadius:8, textAlign:'left' }}
                      onMouseEnter={e => { e.currentTarget.style.background = 'var(--surface)' }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'none' }}>
                      <span style={{ width:9, height:9, borderRadius:'50%', background:g.color, flexShrink:0 }} />
                      <span style={{ fontSize:13, fontWeight:600, color:'var(--text)' }}>{g.label}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Context menu — bottom sheet, items grouped into cards (Reply/Forward,
                  then everything else, then danger actions last) instead of one flat
                  list, matching the reference bottom-sheet menu design. */}
              {ctxMsg && (() => {
                const primaryItems = [
                  { icon: <Reply size={14} />, label:'Reply', action: () => { setReplyTo(ctxMsg); setCtxMsg(null) } },
                  { icon: <Forward size={14} />, label:'Forward', action: () => { setForwardPickerFor(ctxMsg); setCtxMsg(null) } },
                ]
                const middleItems = [
                  { icon: <Copy size={14} />, label:'Copy', action: () => {
                    navigator.clipboard.writeText(ctxMsg.content)
                    showToast({ message: 'Copied', icon: Check })
                    setCtxMsg(null)
                  } },
                  ...(activeRoom?.type === 'dm' ? [{
                    icon: <Star size={14} fill={myStarredIds.has(ctxMsg.id) ? 'currentColor' : 'none'} />,
                    label: myStarredIds.has(ctxMsg.id) ? 'Unstar' : 'Star',
                    action: () => { toggleStar(ctxMsg.id); setCtxMsg(null) }
                  }] : []),
                  ...(!ctxMsg.deleted && (activeRoom?.type !== 'global' || isStaff) ? [
                    activeRoom?.pinnedMessageId === ctxMsg.id
                      ? { icon: <PinOff size={14} />, label:'Unpin', action: unpinMessage }
                      : { icon: <Pin size={14} />, label:'Pin', action: () => pinMessage(ctxMsg) }
                  ] : []),
                  ...(!ctxMsg.deleted && activeRoom?.type === 'global' && isStaff ? [
                    { icon: <Zap size={14} />, label:'Spotlight', action: () => { setSpotlightPickerFor(ctxMsg); setCtxMsg(null) } }
                  ] : []),
                  ...(!ctxMsg.deleted && activeRoom?.type === 'global' && isStaff ? [
                    trendingMessageIds.has(ctxMsg.id)
                      ? { icon: <Sparkles size={14} />, label:'Remove from Trending', action: () => toggleTrendMessage(ctxMsg) }
                      : { icon: <Sparkles size={14} />, label:'Send to Trending', action: () => toggleTrendMessage(ctxMsg) }
                  ] : []),
                  ...(!ctxMsg.deleted && ctxMsg.type === 'poll' && ctxMsg.poll_id && activeRoom?.type === 'global' && isStaff ? [
                    { icon: <PieChart size={14} />, label:'Feature as Quick Poll', action: () => featureQuickPoll(ctxMsg) }
                  ] : []),
                  ...(activeRoom?.type === 'global' && ctxMsg.sender_id !== myId ? [{
                    icon: <UserPlus size={14} />,
                    label: 'View Profile',
                    action: () => { openSenderProfile(ctxMsg); setCtxMsg(null) }
                  }] : []),
                  ...(activeRoom?.type === 'global' && ctxMsg.sender_id !== myId ? [{
                    icon: <MessageCircle size={14} />,
                    label: 'DM the user',
                    action: () => { if (ctxMsg.sender_id) startDmWith(ctxMsg.sender_id); setCtxMsg(null) }
                  }] : []),
                  ...(activeRoom?.type === 'global' && ctxMsg.sender_id !== myId ? [{
                    icon: <AtSign size={14} />,
                    label: 'Mention',
                    action: () => {
                      const sender = activeRoom?.members.find(m => m.user_id === ctxMsg.sender_id)
                      if (sender) {
                        setText(t => (t ? t + ' ' : '') + '@' + sender.profile.username + ' ')
                        setCtxMsg(null)
                        textareaRef.current?.focus()
                      } else {
                        setCtxMsg(null)
                      }
                    }
                  }] : []),
                  ...(activeRoom?.type === 'dm' ? [{
                    icon: <CircleDot size={14} />,
                    label: 'Mark as unread',
                    action: () => { if (activeRoom) markRoomUnread(activeRoom.id); setCtxMsg(null) }
                  }] : []),
                ]
                const dangerItems = [
                  ...(ctxMsg.sender_id !== myId ? [{
                    icon: <ShieldOff size={14} />,
                    label: 'Block',
                    action: async () => {
                      if (myId && ctxMsg.sender_id) {
                        await supabase.from('blocks').upsert({ blocker_id: myId, blocked_id: ctxMsg.sender_id })
                        handleBlockChange(ctxMsg.sender_id, true)
                      }
                      setCtxMsg(null)
                    }
                  }] : []),
                  ...(ctxMsg.sender_id !== myId ? [{
                    icon: <Flag size={14} />,
                    label: 'Report',
                    action: () => {
                      setReportTarget({ id: ctxMsg.id, senderName: ctxMsg.senderName || 'this user' })
                      setCtxMsg(null)
                    }
                  }] : []),
                  ...(ctxMsg.sender_id === myId ? [{ icon: <Trash2 size={14} />, label:'Delete', action: () => deleteMsg(ctxMsg.id) }] : []),
                ]
                const groups = [primaryItems, middleItems, dangerItems].filter(g => g.length > 0)
                return (
                  <>
                    <div className="cv-ctx-sheet-backdrop" style={{ position:'fixed', inset:0, zIndex:90 }} onClick={() => setCtxMsg(null)} />
                    <div className="cv-ctx-sheet">
                      <div className="cv-ctx-sheet-handle" />
                      <div className="cv-ctx-reactions">
                        {QUICK_REACTIONS.map(emoji => {
                          const mine = reactions.some(r => r.message_id === ctxMsg.id && r.user_id === myId && r.emoji === emoji)
                          return (
                            <button
                              key={emoji}
                              type="button"
                              className={`cv-emoji cv-ctx-reaction${mine ? ' active' : ''}`}
                              onClick={() => { toggleReaction(ctxMsg, emoji); setCtxMsg(null) }}>
                              {emoji}
                            </button>
                          )
                        })}
                      </div>
                      {groups.map((group, gi) => (
                        <div key={gi} className="cv-ctx-sheet-group">
                          {group.map(({ icon, label, action }) => (
                            <button key={label} type="button" onClick={action}
                              className={`cv-ctx-sheet-item${label === 'Delete' || label === 'Block' || label === 'Report' ? ' danger' : ''}`}>
                              {icon} {label}
                            </button>
                          ))}
                        </div>
                      ))}
                    </div>
                  </>
                )
              })()}
            </>
          ) : (
            !isMobile && (
              <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:14 }}>
                <MessageCircle size={48} style={{ color:'var(--text-muted)' }} />
                <p style={{ fontSize:15, fontWeight:600, color:'var(--text-dim)' }}>Select a conversation</p>
                <p style={{ fontSize:13, color:'var(--text-muted)' }}>Choose from your chats on the left</p>
              </div>
            )
          )}
        </div>
      )}

      {/* Spotlight duration picker — opened from the Spotlight context-menu action above.
          Same bottom-sheet treatment as the message menu for visual consistency. */}
      {spotlightPickerFor && (
        <>
          <div className="cv-ctx-sheet-backdrop" style={{ position:'fixed', inset:0, zIndex:90 }} onClick={() => { setSpotlightPickerFor(null); setSpotlightCustomMinutes('') }} />
          <div className="cv-ctx-sheet">
            <div className="cv-ctx-sheet-handle" />
            <div style={{ fontSize:10.5, fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:0.3, padding:'2px 6px 8px' }}>Spotlight duration</div>
            <div className="cv-ctx-sheet-group">
              {[{ label: '10 minutes', minutes: 10 }, { label: '1 hour', minutes: 60 }].map(p => (
                <button key={p.minutes} type="button"
                  onClick={() => { spotlightMessage(spotlightPickerFor, p.minutes); setSpotlightPickerFor(null); setSpotlightCustomMinutes('') }}
                  className="cv-ctx-sheet-item">
                  {p.label}
                </button>
              ))}
              <div style={{ display:'flex', alignItems:'center', gap:6, padding:'10px 16px' }}>
                <input type="number" min={1} max={1440} value={spotlightCustomMinutes} onChange={e => setSpotlightCustomMinutes(e.target.value)}
                  placeholder="Custom (min)"
                  style={{ flex:1, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:7, padding:'8px 8px', fontSize:12.5, color:'var(--text)' }} />
                <button type="button"
                  disabled={!spotlightCustomMinutes || Number(spotlightCustomMinutes) <= 0}
                  onClick={() => {
                    const mins = Number(spotlightCustomMinutes)
                    if (mins > 0) { spotlightMessage(spotlightPickerFor, mins); setSpotlightPickerFor(null); setSpotlightCustomMinutes('') }
                  }}
                  style={{ padding:'8px 12px', borderRadius:7, border:'none', background:'var(--accent)', color:'#fff', fontSize:12.5, fontWeight:700, cursor: !spotlightCustomMinutes || Number(spotlightCustomMinutes) <= 0 ? 'default' : 'pointer', opacity: !spotlightCustomMinutes || Number(spotlightCustomMinutes) <= 0 ? 0.5 : 1 }}>
                  Set
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Forward room-picker — opened from the Forward context-menu action above. Same
          bottom-sheet treatment as the message menu for visual consistency. */}
      {forwardPickerFor && (
        <>
          <div className="cv-ctx-sheet-backdrop" style={{ position:'fixed', inset:0, zIndex:90 }} onClick={() => setForwardPickerFor(null)} />
          <div className="cv-ctx-sheet">
            <div className="cv-ctx-sheet-handle" />
            <div style={{ fontSize:10.5, fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:0.3, padding:'2px 6px 8px' }}>Forward to</div>
            <div className="cv-ctx-sheet-group">
              {rooms.length === 0 && (
                <div style={{ padding:'13px 16px', fontSize:13, color:'var(--text-muted)' }}>No chats available</div>
              )}
              {rooms.map(r => (
                <button key={r.id} type="button"
                  onClick={() => { forwardMessage(r.id, forwardPickerFor); setForwardPickerFor(null) }}
                  className="cv-ctx-sheet-item">
                  <Avatar name={roomLabel(r)} avatarUrl={r.type === 'dm' ? (r.members.find(m => m.user_id !== myId)?.profile.avatar) : null} size={26} radius={9} />
                  {roomLabel(r)}
                </button>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Conversation-header 3-dot menu — Pin/Unpin chat, Clear chat, Block user. Same
          fixed/top-level pattern as the room-row menu above — the old version was nested
          inside the topbar's backdrop-filter container, which was the actual cause of it
          rendering behind other elements instead of floating cleanly on top. */}
      {convMenuOpen && activeRoom && (
        <>
          <div style={{ position:'fixed', inset:0, zIndex:190 }} onClick={() => setConvMenuOpen(false)} />
          <div style={{ position:'fixed', left: Math.min(convMenuPos.x - 180, window.innerWidth - 188), top: Math.min(convMenuPos.y, window.innerHeight - 140), zIndex:200, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:14, overflow:'hidden', boxShadow:'var(--elev-popover)', minWidth:180 }}>
            {[
              {
                icon: activeRoom.pinned ? <PinOff size={14} /> : <Pin size={14} />,
                label: activeRoom.pinned ? 'Unpin chat' : 'Pin chat',
                action: () => { togglePinChat(activeRoom.id); setConvMenuOpen(false) },
              },
              {
                icon: <Trash2 size={14} />,
                label: 'Clear chat',
                action: () => { clearChatForMe(activeRoom.id); setConvMenuOpen(false) },
                danger: true,
              },
              {
                icon: <ShieldOff size={14} />,
                label: 'Block user',
                action: async () => {
                  const other = activeRoom.members.find(m => m.user_id !== myId)
                  if (myId && other) {
                    await supabase.from('blocks').upsert({ blocker_id: myId, blocked_id: other.user_id })
                    handleBlockChange(other.user_id, true)
                    setDmBlockState('blockedByMe')
                  }
                  setConvMenuOpen(false)
                },
                danger: true,
              },
            ].map(({ icon, label, action, danger }) => (
              <button key={label} type="button" onClick={action}
                style={{ display:'flex', alignItems:'center', gap:10, padding:'11px 16px', width:'100%', background:'none', border:'none', cursor:'pointer', fontSize:13, color: danger ? '#ff6b6b' : 'var(--text-dim)' }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.06)' }}
                onMouseLeave={e => { e.currentTarget.style.background = 'none' }}>
                {icon} {label}
              </button>
            ))}
          </div>
        </>
      )}

      {/* Room-row 3-dot menu — Pin / Delete chat. Rendered at the true top level (fixed,
          viewport-anchored) rather than nested inside the scrolling room list, so it can
          never get visually clipped or layered behind sibling rows the way an
          absolute-positioned nested menu can. Also lives outside showChat's block so it
          still works on mobile while only the room list (not a conversation) is showing. */}
      {roomMenuOpenFor && (() => {
        const menuRoom = rooms.find(r => r.id === roomMenuOpenFor)
        if (!menuRoom) return null
        return (
          <>
            <div style={{ position:'fixed', inset:0, zIndex:190 }} onClick={() => setRoomMenuOpenFor(null)} />
            <div style={{ position:'fixed', left: Math.min(roomMenuPos.x - 170, window.innerWidth - 178), top: Math.min(roomMenuPos.y, window.innerHeight - 100), zIndex:200, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:14, overflow:'hidden', boxShadow:'var(--elev-popover)', minWidth:170 }}>
              {[
                {
                  icon: menuRoom.pinned ? <PinOff size={14} /> : <Pin size={14} />,
                  label: menuRoom.pinned ? 'Unpin chat' : 'Pin chat',
                  action: () => { togglePinChat(menuRoom.id); setRoomMenuOpenFor(null) },
                },
                {
                  icon: <Trash2 size={14} />,
                  label: 'Delete chat',
                  action: () => { deleteChatForMe(menuRoom.id); setRoomMenuOpenFor(null) },
                  danger: true,
                },
              ].map(({ icon, label, action, danger }) => (
                <button key={label} type="button" onClick={() => action()}
                  style={{ display:'flex', alignItems:'center', gap:10, padding:'11px 16px', width:'100%', background:'none', border:'none', cursor:'pointer', fontSize:13, color: danger ? '#ff6b6b' : 'var(--text-dim)' }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.06)' }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'none' }}>
                  {icon} {label}
                </button>
              ))}
            </div>
          </>
        )
      })()}

      {/* DM options modal — delete chat */}
      {dmOptionsOpen && activeRoom && activeRoom.type === 'dm' && (
        <>
          <div style={{ position:'fixed', inset:0, zIndex:200, background:'rgba(0,0,0,0.5)', backdropFilter:'blur(3px)' }} onClick={() => setDmOptionsOpen(false)} />
          <div style={{ position:'fixed', top:'50%', left:'50%', transform:'translate(-50%,-50%)', zIndex:201, background:'var(--surface2)', border:'1px solid var(--border-strong)', borderRadius:18, padding:'20px 20px 16px', width: Math.min(260, window.innerWidth - 32), boxShadow:'var(--elev-popover)' }}>
            <button type="button" onClick={() => setDmOptionsOpen(false)} style={{ position:'absolute', top:12, right:12, background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)' }}>
              <X size={15} />
            </button>
            <p style={{ fontSize:14, fontWeight:700, color:'var(--text)', marginBottom:14 }}>Chat options</p>
            <button type="button"
              onClick={() => {
                if (!activeRoom) return
                deleteChatForMe(activeRoom.id)
                setDmOptionsOpen(false)
              }}
              style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 14px', width:'100%', borderRadius:11, border:'none', background:'rgba(255,107,107,0.1)', color:'#ff6b6b', fontSize:13, fontWeight:600, cursor:'pointer' }}>
              <Trash2 size={14} /> Delete Chat
            </button>
          </div>
        </>
      )}

      {reportTarget && myId && (
        <ReportModal
          reporterId={myId}
          targetType="message"
          targetId={reportTarget.id}
          targetLabel={`message from ${reportTarget.senderName}`}
          onClose={() => setReportTarget(null)}
        />
      )}

      {activeRoom && (
        <PollComposerModal
          open={pollModalOpen}
          onClose={() => setPollModalOpen(false)}
          roomId={activeRoom.id}
          maxDurationHours={isStaff ? 168 : 48}
          onCreated={() => { scrollModeRef.current = 'bottom' }}
        />
      )}

      {globalInviteOpen && (
        <GlobalInviteModal onClose={() => setGlobalInviteOpen(false)} />
      )}

      {discoverManageOpen && (
        <DiscoverManageModal onClose={() => setDiscoverManageOpen(false)} />
      )}

      {reactorsSheetMsgId && reactorsSheetRows.length > 0 && (
        <ReactorsSheet
          reactions={reactorsSheetRows}
          getUser={reactorUserLookup}
          onClose={() => setReactorsSheetMsgId(null)}
        />
      )}

      <StarredMessagesPanel
        open={starredPanelOpen}
        onClose={() => setStarredPanelOpen(false)}
        myId={myId}
        roomId={activeRoom?.type === 'dm' ? activeRoom.id : null}
        roomLabel={activeRoom ? roomLabel(activeRoom) : ''}
      />

      <Toast toast={toast} />

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes skeletonPulse { 0%, 100% { opacity: 0.35; } 50% { opacity: 0.7; } }
      `}</style>
    </div>
  )
}
