// src/features/chat/haloWidgets/HaloEventCard.tsx
//
// Elimination Weekend preview + registration card. "View Details" routes to
// the real Most Wanted / Elimination tab rather than duplicating that UI
// here; "Register Me" runs registerForEliminationAction (see
// haloActionFlows.ts), which is the exact same pvp_elimination_register RPC
// the dedicated registration sheet uses.
import { useNavigate } from 'react-router-dom'
import { Users, ImageOff } from 'lucide-react'
import type { HaloWidget } from '../haloDynamicReplies'

type Widget = Extract<HaloWidget, { type: 'event_preview' }>

const DANGER = '#ff4d6d'

export default function HaloEventCard({ widget, onRegister, busy }: {
  widget: Widget
  onRegister: () => void
  busy: boolean
}) {
  const navigate = useNavigate()

  return (
    <div style={{
      marginTop: 6, width: 260, maxWidth: '100%', overflow: 'hidden',
      background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 14,
    }}>
      <div style={{
        position: 'relative', height: 100,
        background: widget.bannerUrl ? `center/cover no-repeat url(${widget.bannerUrl})` : `linear-gradient(140deg, ${DANGER}2e, #1a0e14)`,
      }}>
        {!widget.bannerUrl && (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.5 }}>
            <ImageOff size={20} color="#fff" />
          </div>
        )}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, var(--surface2) 4%, rgba(0,0,0,0.15))' }} />
      </div>

      <div style={{ padding: 12 }}>
        <div style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1, color: DANGER, textTransform: 'uppercase' }}>Event</div>
        <div style={{ fontSize: 14.5, fontWeight: 900, color: 'var(--text)', marginTop: 2 }}>{widget.title}</div>
        {widget.windowLabel && (
          <div style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 3 }}>{widget.windowLabel}</div>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6 }}>
          <Users size={11} color="var(--text-dim)" />
          <span style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 700 }}>{widget.registeredCount} registered</span>
        </div>

        {widget.status === 'registered' ? (
          <div style={{ marginTop: 10, fontSize: 11.5, fontWeight: 700, color: 'var(--green)' }}>✓ You're registered!</div>
        ) : widget.errorMessage ? (
          <div style={{ marginTop: 10, fontSize: 11, color: 'var(--red)' }}>{widget.errorMessage}</div>
        ) : null}

        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button
            type="button"
            onClick={() => navigate('/most-wanted?tab=elimination')}
            style={{
              flex: 1, minHeight: 34, borderRadius: 10, fontSize: 11, fontWeight: 800,
              cursor: 'pointer', border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)',
            }}
          >
            View Details
          </button>
          <button
            type="button"
            onClick={onRegister}
            disabled={widget.status !== 'eligible' || busy}
            style={{
              flex: 1, minHeight: 34, borderRadius: 10, fontSize: 11, fontWeight: 800,
              cursor: widget.status === 'eligible' && !busy ? 'pointer' : 'default',
              border: 'none', background: DANGER, color: '#fff',
              opacity: widget.status === 'eligible' && !busy ? 1 : 0.55,
            }}
          >
            {widget.status === 'registered' ? 'Registered' : busy ? 'Registering...' : widget.status === 'closed' ? 'Closed' : 'Register Me'}
          </button>
        </div>
      </div>
    </div>
  )
}
