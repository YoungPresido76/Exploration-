// src/features/chat/haloWidgets/GameCardWidget.tsx
//
// Shown under a Halo DM reply when Halo names or suggests a specific game
// (see findNamedGame / pickFreshGame in haloStaticReplies.ts). Looks the
// game up fresh from the shared GAMES catalog by id, so the card always
// reflects the real banner/name/accent — never anything baked into the
// canned reply text.
//
// "Play" doesn't launch a round directly — it deep-links into the Games
// Zone with `previewGame` in router state, the same convention feed-post
// game tags already use (see PostCard.tsx) — that opens GameDetailModal
// (the "game modal") for a confirm-then-play step, rather than spending a
// session on a tap that was really just "show me this game".
import { useNavigate } from 'react-router-dom'
import { Play } from 'lucide-react'
import { getGameById } from '../../games/games'
import type { HaloWidget } from '../haloDynamicReplies'

export default function GameCardWidget({ widget }: { widget: Extract<HaloWidget, { type: 'game' }> }) {
  const navigate = useNavigate()
  const game = getGameById(widget.gameId)
  if (!game) return null

  const Icon = game.icon

  return (
    <div
      style={{
        marginTop: 6,
        width: 230,
        maxWidth: '100%',
        background: 'var(--surface2)',
        border: `1px solid ${game.accent}40`,
        borderRadius: 14,
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          height: 76,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: game.bannerUrl
            ? `linear-gradient(180deg, transparent 40%, rgba(0,0,0,0.55)), url(${game.bannerUrl})`
            : `linear-gradient(135deg, ${game.accent}55, ${game.accent}15)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        {!game.bannerUrl && <Icon size={30} color={game.accent} />}
      </div>

      <div style={{ padding: 10 }}>
        <div style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--text)', marginBottom: 2 }}>{game.name}</div>
        <div
          style={{
            fontSize: 10.5,
            color: 'var(--text-muted)',
            marginBottom: 10,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {game.tagline}
        </div>
        <button
          type="button"
          onClick={() => navigate('/games', { state: { previewGame: game.id } })}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 6,
            padding: '8px 0',
            borderRadius: 10,
            border: 'none',
            background: game.accent,
            color: '#0b0b0f',
            fontSize: 12,
            fontWeight: 800,
            cursor: 'pointer',
          }}
        >
          <Play size={13} fill="#0b0b0f" /> Play
        </button>
      </div>
    </div>
  )
}
