// src/features/chat/haloWidgets/HaloMallCard.tsx
//
// A small horizontally-scrolling row of real Mall item thumbnails, each
// with a Buy button wired to buyMallItemAction (purchase_mall_item RPC —
// same atomic, server-priced purchase path the Mall page itself uses).
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ShoppingBag, ImageOff } from 'lucide-react'
import type { HaloWidget } from '../haloDynamicReplies'

type Widget = Extract<HaloWidget, { type: 'mall_preview' }>
type Item = Widget['items'][number]

function priceLabel(item: Item): string {
  if (item.priceGems != null) return `${item.priceGems} 💎`
  if (item.priceOrbs != null) return `${item.priceOrbs} 🔮`
  return ''
}

function ItemTile({ item, onBuy, busy, bought }: { item: Item; onBuy: () => void; busy: boolean; bought: boolean }) {
  const [broken, setBroken] = useState(false)
  return (
    <div style={{
      width: 108, flexShrink: 0, background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 12, overflow: 'hidden',
    }}>
      <div style={{ width: '100%', height: 72, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {item.imageUrl && !broken ? (
          <img src={item.imageUrl} alt="" onError={() => setBroken(true)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <ImageOff size={16} color="var(--text-muted)" />
        )}
      </div>
      <div style={{ padding: '7px 8px 8px' }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text)', lineHeight: 1.25, height: 26, overflow: 'hidden' }}>
          {item.name}
        </div>
        <div style={{ fontSize: 10, color: item.affordable ? 'var(--text-muted)' : 'var(--red)', fontWeight: 700, marginTop: 2 }}>
          {priceLabel(item)}
        </div>
        <button
          type="button"
          onClick={onBuy}
          disabled={!item.affordable || busy || bought}
          style={{
            width: '100%', marginTop: 6, minHeight: 26, borderRadius: 8, fontSize: 10, fontWeight: 800,
            cursor: item.affordable && !busy && !bought ? 'pointer' : 'default', border: 'none',
            background: bought ? 'var(--green)' : 'var(--accent)', color: '#fff',
            opacity: item.affordable && !bought ? 1 : 0.5,
          }}
        >
          {bought ? 'Bought' : busy ? '...' : 'Buy'}
        </button>
      </div>
    </div>
  )
}

export default function HaloMallCard({ widget, onBuy, busyItemId, boughtIds }: {
  widget: Widget
  onBuy: (itemId: string, itemName: string) => void
  busyItemId: string | null
  boughtIds: Set<string>
}) {
  const navigate = useNavigate()
  return (
    <div style={{ marginTop: 6, width: 280, maxWidth: '100%' }}>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
        {widget.items.map(item => (
          <ItemTile
            key={item.id}
            item={item}
            onBuy={() => onBuy(item.id, item.name)}
            busy={busyItemId === item.id}
            bought={boughtIds.has(item.id)}
          />
        ))}
      </div>
      <button
        type="button"
        onClick={() => navigate('/mall')}
        style={{
          width: '100%', marginTop: 8, minHeight: 32, borderRadius: 10, fontSize: 11, fontWeight: 800,
          cursor: 'pointer', border: 'none', background: 'var(--accent)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}
      >
        <ShoppingBag size={12} /> View Mall
      </button>
    </div>
  )
}
