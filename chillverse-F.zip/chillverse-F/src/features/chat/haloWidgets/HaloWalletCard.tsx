// src/features/chat/haloWidgets/HaloWalletCard.tsx
//
// Read-only — no confirmation needed for a balance lookup (see the
// confirmation policy in the Halo action-system spec). gem_balance is
// always displayed as "Diamonds", matching every other surface in the app
// (see useWallet.ts for why the DB column name stays gem_balance).
import { useNavigate } from 'react-router-dom'
import { Gem, Sparkles, Ticket } from 'lucide-react'
import type { HaloWidget } from '../haloDynamicReplies'

type Widget = Extract<HaloWidget, { type: 'wallet_preview' }>

function Currency({ icon, value, label, color }: { icon: React.ReactNode; value: number; label: string; color: string }) {
  return (
    <div style={{ flex: 1, textAlign: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, color }}>
        {icon}
        <span style={{ fontSize: 15, fontWeight: 900 }}>{value.toLocaleString()}</span>
      </div>
      <div style={{ fontSize: 9, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 2 }}>
        {label}
      </div>
    </div>
  )
}

export default function HaloWalletCard({ widget }: { widget: Widget }) {
  const navigate = useNavigate()
  return (
    <div style={{
      marginTop: 6, width: 250, maxWidth: '100%',
      background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 14, padding: 13,
    }}>
      <div style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1, color: 'var(--accent)', textTransform: 'uppercase', marginBottom: 8 }}>
        Wallet
      </div>
      <div style={{ display: 'flex' }}>
        <Currency icon={<Gem size={13} />} value={widget.gemBalance} label="Diamonds" color="#4f8ef7" />
        <Currency icon={<Sparkles size={13} />} value={widget.orbBalance} label="Orbs" color="#c86dff" />
        <Currency icon={<Ticket size={13} />} value={widget.voucherBalance} label="Vouchers" color="#ffb648" />
      </div>
      <button
        type="button"
        onClick={() => navigate('/wallet')}
        style={{
          width: '100%', marginTop: 10, minHeight: 30, borderRadius: 10, fontSize: 10.5, fontWeight: 800,
          cursor: 'pointer', border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)',
        }}
      >
        Go to Wallet
      </button>
    </div>
  )
}
