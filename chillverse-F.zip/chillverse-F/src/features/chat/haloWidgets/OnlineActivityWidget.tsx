// src/features/chat/haloWidgets/OnlineActivityWidget.tsx
//
// Shown under a Halo DM reply when the player asks how online/active
// they've been. All numbers come straight from fetchOnlineActivityData in
// haloDynamicReplies.ts (real game_sessions + profile rows), not from any
// canned text.
import type { HaloWidget } from '../haloDynamicReplies'

const DAY_LABELS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']

function fmtMinutes(mins: number): string {
  if (mins < 60) return `${mins}m`
  const h = Math.floor(mins / 60)
  const m = mins % 60
  return m === 0 ? `${h}h` : `${h}h ${m}m`
}

function fmtLastSeen(iso: string | null): string {
  if (!iso) return 'Unknown'
  const ms = Date.now() - new Date(iso).getTime()
  const mins = Math.round(ms / 60000)
  if (mins < 2) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.round(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.round(hrs / 24)
  return `${days}d ago`
}

export default function OnlineActivityWidget({
  widget,
}: {
  widget: Extract<HaloWidget, { type: 'online_activity' }>
}) {
  const maxMinutes = Math.max(1, ...widget.last7Days.map(d => d.minutes))

  return (
    <div
      style={{
        marginTop: 6,
        width: 240,
        maxWidth: '100%',
        background: 'var(--surface2)',
        border: '1px solid rgba(155,109,255,0.2)',
        borderRadius: 14,
        padding: 12,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
        <div style={{ fontSize: 9, fontWeight: 700, color: 'var(--purple)', letterSpacing: 1, textTransform: 'uppercase' }}>
          Last 7 Days
        </div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600 }}>
          {fmtMinutes(widget.totalMinutesThisWeek)} total
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 5, height: 54, marginBottom: 5 }}>
        {widget.last7Days.map((d, i) => {
          const isToday = i === widget.last7Days.length - 1
          const heightPct = Math.max(6, Math.round((d.minutes / maxMinutes) * 100))
          return (
            <div key={d.date} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
              <div
                title={`${d.date}: ${fmtMinutes(d.minutes)}`}
                style={{
                  width: '100%',
                  height: `${heightPct}%`,
                  minHeight: 3,
                  borderRadius: 3,
                  background:
                    d.minutes > 0
                      ? isToday
                        ? 'linear-gradient(180deg, #9b6dff, #4f8ef7)'
                        : 'rgba(155,109,255,0.45)'
                      : 'rgba(255,255,255,0.08)',
                }}
              />
            </div>
          )
        })}
      </div>
      <div style={{ display: 'flex', gap: 5, marginBottom: 10 }}>
        {widget.last7Days.map((d, i) => (
          <div
            key={d.date}
            style={{
              flex: 1,
              textAlign: 'center',
              fontSize: 8.5,
              fontWeight: 700,
              color: i === widget.last7Days.length - 1 ? 'var(--purple)' : 'var(--text-muted)',
            }}
          >
            {DAY_LABELS[new Date(d.date + 'T00:00:00Z').getUTCDay()]}
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid var(--border)', paddingTop: 8 }}>
        <div style={{ textAlign: 'center', flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>🔥 {widget.currentStreak}</div>
          <div style={{ fontSize: 8, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Streak</div>
        </div>
        <div style={{ textAlign: 'center', flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>{widget.totalSessionsThisWeek}</div>
          <div style={{ fontSize: 8, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Sessions</div>
        </div>
        <div style={{ textAlign: 'center', flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>{fmtLastSeen(widget.lastSeenAt)}</div>
          <div style={{ fontSize: 8, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Last Seen</div>
        </div>
      </div>
    </div>
  )
}
