// src/features/chat/haloWidgets/HaloUsernameConfirmCard.tsx
//
// The visual confirmation card for a Halo-driven username change. Only
// pressing Confirm executes the mutation (see handleHaloWidgetAction in
// Chat.tsx) — this component never calls Supabase itself, it just reports
// taps upward.
import { Check, X } from 'lucide-react'
import type { HaloWidget } from '../haloDynamicReplies'

type Widget = Extract<HaloWidget, { type: 'username_change' }>

export default function HaloUsernameConfirmCard({ widget, onConfirm, onCancel, busy }: {
  widget: Widget
  onConfirm: () => void
  onCancel: () => void
  busy: boolean
}) {
  const isPending = widget.status === 'pending'

  return (
    <div style={{
      marginTop: 6, width: 250, maxWidth: '100%',
      background: 'var(--surface2)', border: '1px solid var(--border)',
      borderRadius: 14, padding: 13,
    }}>
      <div style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1, color: 'var(--accent)', textTransform: 'uppercase' }}>
        Change Username
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
        <span style={{ fontSize: 13, color: 'var(--text-muted)', textDecoration: widget.status === 'confirmed' ? 'line-through' : 'none' }}>
          @{widget.currentUsername}
        </span>
        <span style={{ color: 'var(--text-dim)', fontSize: 12 }}>→</span>
        <strong style={{ fontSize: 13, color: 'var(--text)' }}>@{widget.newUsername}</strong>
      </div>

      {widget.status === 'pending' && !widget.usernameAvailable && (
        <p style={{ fontSize: 11, color: 'var(--red)', margin: '8px 0 0' }}>{widget.unavailableReason}</p>
      )}
      {widget.status === 'confirmed' && (
        <p style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--green)', margin: '8px 0 0' }}>✓ Done — username updated.</p>
      )}
      {widget.status === 'cancelled' && (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '8px 0 0' }}>Cancelled — kept @{widget.currentUsername}.</p>
      )}
      {widget.status === 'error' && (
        <p style={{ fontSize: 11.5, color: 'var(--red)', margin: '8px 0 0' }}>{widget.errorMessage || 'Something went wrong.'}</p>
      )}

      {isPending && widget.usernameAvailable && (
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            style={{
              flex: 1, minHeight: 34, borderRadius: 10, fontSize: 11, fontWeight: 800,
              cursor: busy ? 'default' : 'pointer', border: '1px solid var(--border)',
              background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
              opacity: busy ? 0.6 : 1,
            }}
          >
            <X size={12} /> Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={busy}
            style={{
              flex: 1, minHeight: 34, borderRadius: 10, fontSize: 11, fontWeight: 800,
              cursor: busy ? 'default' : 'pointer', border: 'none',
              background: 'var(--accent)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
              opacity: busy ? 0.7 : 1,
            }}
          >
            <Check size={12} /> {busy ? 'Working...' : 'Confirm'}
          </button>
        </div>
      )}
    </div>
  )
}
