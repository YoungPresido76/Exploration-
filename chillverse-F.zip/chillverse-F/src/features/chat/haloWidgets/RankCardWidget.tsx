// src/features/chat/haloWidgets/RankCardWidget.tsx
//
// Shown under a Halo DM reply when the player asks about their rank.
// Reuses the exact same tier math + badge art as the Ranks page (RankBadge,
// RANK_TIERS, getRankProgress) so this can never drift out of sync with
// what the player sees on /ranks.
import RankBadge from '../../../shared/components/RankBadge'
import { getUserRankTier, getNextRankTier, getRankProgress, fmtXP } from '../../profile/ranks'
import type { HaloWidget } from '../haloDynamicReplies'

export default function RankCardWidget({ widget }: { widget: Extract<HaloWidget, { type: 'rank' }> }) {
  const tier = getUserRankTier(widget.activeRankXp)
  const nextTier = getNextRankTier(tier)
  const { pct, xpIntoTier, xpNeeded } = getRankProgress(widget.activeRankXp)

  return (
    <div
      style={{
        marginTop: 6,
        width: 220,
        maxWidth: '100%',
        background: `linear-gradient(135deg, ${tier.color}22, var(--surface2))`,
        border: `1px solid ${tier.color}40`,
        borderRadius: 14,
        padding: 12,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div
          style={{
            width: 44,
            height: 44,
            borderRadius: 14,
            flexShrink: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: `linear-gradient(135deg, ${tier.color}40, ${tier.color}15)`,
            border: `2px solid ${tier.color}60`,
            boxShadow: `0 0 14px ${tier.glowColor}`,
          }}
        >
          <RankBadge tier={tier} size={32} />
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: tier.color, letterSpacing: 1, textTransform: 'uppercase' }}>
            Rank
          </div>
          <div style={{ fontSize: 16, fontWeight: 900, color: tier.color, letterSpacing: '-0.3px' }}>{tier.name}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600 }}>{fmtXP(widget.xp)} XP lifetime</div>
        </div>
      </div>

      {nextTier ? (
        <div style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9.5, color: 'var(--text-dim)', marginBottom: 5 }}>
            <span style={{ fontWeight: 700 }}>
              {fmtXP(xpIntoTier)} / {fmtXP(xpNeeded)} XP
            </span>
            <span style={{ color: nextTier.color, fontWeight: 700 }}>{nextTier.name}</span>
          </div>
          <div
            style={{
              height: 7,
              borderRadius: 4,
              background: 'rgba(0,0,0,0.3)',
              overflow: 'hidden',
              boxShadow: 'inset 1px 1px 4px rgba(0,0,0,0.4)',
            }}
          >
            <div
              style={{
                height: '100%',
                borderRadius: 4,
                width: `${pct}%`,
                background: `linear-gradient(90deg, ${tier.color}, ${nextTier.color})`,
                boxShadow: `0 0 8px ${tier.glowColor}`,
                transition: 'width 1s ease',
              }}
            />
          </div>
        </div>
      ) : (
        <div style={{ marginTop: 8, fontSize: 10, fontWeight: 700, color: tier.color, textAlign: 'center' }}>
          Max rank reached 🏆
        </div>
      )}
    </div>
  )
}
