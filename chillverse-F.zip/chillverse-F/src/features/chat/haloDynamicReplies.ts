// src/features/chat/haloDynamicReplies.ts
//
// haloStaticReplies.ts is pure text pattern-matching with zero network
// calls — that's deliberate for the "vibe" replies (greetings, win/loss
// energy, game suggestions, canned policy lines). But questions like "how
// do I rank up" or "what was my last post" need the player's *actual*
// data, not a guess from their wording. This module is that layer: each
// flow below is an intent check (cheap, synchronous) plus a `resolve()`
// that fetches real rows and turns them into a sentence.
//
// Single entry point for the call site: matchDynamicHaloFlow(). It tries
// each flow's intent check in order and returns the first match, or null
// if nothing here applies — in which case the caller falls back to
// pickHaloStaticReply for the vibe-only path (no request made at all, so
// the fast path stays exactly as fast as before).
//
// Ordering matters where two flows could both read as "how do I ___":
// rank-progress and achievement-guide both start with "how do i get/rank"
// phrasing, so rank-progress is checked first (it only fires on
// rank/level wording) and achievement-guide requires an actual achievement
// title match before it commits — an ambiguous phrase that matches neither
// precisely just falls through to null, which is the safe default.

import { supabase } from '../../shared/lib/supabase'
import {
  getUserRankTier,
  getNextRankTier,
  getRankProgress,
  isRankDecayed,
  fmtXP,
  type RankTier,
} from '../profile/ranks'
import { RANK_GROUP_FLAVOR } from './haloStaticReplies'
import { CHILLVERSE_HOST } from './messageContent'
import { getPvpState, type PvpState } from '../pvp/pvp'
import { getMyKillStanding, type MyKillStanding } from '../pvp/killBoard'
import { getAllAchievements, getPlayerAchievements, type Achievement } from '../achievements/achievements'
import type { MallItem } from '../../shared/types'
import type { GameId } from '../games/games'

// A rich card shown under a Halo DM reply — the rank badge + XP bar, a
// 7-day activity chart, or a game card (icon/banner + Play button). Built
// from the exact same rows/catalog entries the text reply is built from,
// so the numbers/game on the card and in Halo's sentence never disagree.
export type HaloWidget =
  | { type: 'rank'; xp: number; activeRankXp: number }
  | {
      type: 'online_activity'
      last7Days: { date: string; minutes: number }[]
      totalMinutesThisWeek: number
      totalSessionsThisWeek: number
      currentStreak: number
      longestStreak: number
      lastSeenAt: string | null
    }
  | { type: 'game'; gameId: GameId }
  // ── Action-system widgets (see haloActionFlows.ts) ──────────────────────
  // These back a Halo DM "action card" — a visual preview with buttons that
  // invoke a typed, server-validated mutation through handleHaloWidgetAction
  // in Chat.tsx. `status` on each doubles as both what to show AND whether
  // the buttons are live — once a card is actioned it's replaced with a
  // 'done' or 'error' status so a stale card can't be tapped twice.
  | {
      type: 'username_change'
      currentUsername: string
      newUsername: string
      usernameAvailable: boolean
      unavailableReason: string | null
      status: 'pending' | 'confirmed' | 'cancelled' | 'error'
      errorMessage?: string
    }
  | {
      type: 'event_preview'
      eventId: 'elimination_weekend'
      title: string
      bannerUrl: string | null
      windowLabel: string
      registeredCount: number
      status: 'eligible' | 'registered' | 'closed'
      errorMessage?: string
    }
  | {
      type: 'mall_preview'
      items: {
        id: string
        name: string
        imageUrl: string | null
        priceGems: number | null
        priceOrbs: number | null
        affordable: boolean
        owned: boolean
      }[]
    }
  | {
      type: 'wallet_preview'
      gemBalance: number
      orbBalance: number
      voucherBalance: number
    }

export interface HaloDynamicContext {
  myId: string | null
  myUsername: string | null
}

export interface DynamicHaloFlow {
  /** Shown immediately while resolve() is in flight. Omit for flows that
   *  resolve from data Chat.tsx already has in memory (e.g. username) —
   *  those skip the "checking..." bubble and just answer directly. */
  checking?: string
  resolve: () => Promise<string>
  /** Optional rich card (rank badge + XP bar, activity chart) to show
   *  under the text reply once it lands. Only a couple of flows have one —
   *  most flows just omit this. When both this and resolve() are backed by
   *  the same underlying fetch, share one in-flight promise (see the rank
   *  and online-activity flows below) so the data is only fetched once. */
  resolveWidget?: () => Promise<HaloWidget | null>
}

// ── Shared helpers ──────────────────────────────────────────────────────

const FALLBACK_MESSAGE = "Couldn't pull that up just now — try again in a bit?"

function relativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diffMs / 60_000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}d ago`
  return new Date(iso).toLocaleDateString()
}

// ── Rank progress ────────────────────────────────────────────────────────

export const RANK_PROGRESS_CHECKING_MESSAGE = 'Checking your rank...'

export const RANK_PROGRESS_QUERY_HINT =
  /\b(rank up|level up|(my|current) rank|what('?s| is) my rank|next rank|higher rank|how (do|can) i (rank|level)|rank progress)\b/i

const RANK_NEXT_STEP_SUGGESTIONS = [
  "Weekly missions are a solid shortcut if you haven't cleared this week's yet.",
  'Ranked PvP wins add up fast — a few solid games could close that gap quick.',
  "Keep playing and posting — XP stacks from all over, not just PvP.",
]

function buildRankProgressReply(xp: number, activeRankXp?: number | null): string {
  const effectiveXp = activeRankXp ?? xp
  const current: RankTier = getUserRankTier(effectiveXp)
  const next = getNextRankTier(current)
  const flavor = RANK_GROUP_FLAVOR[current.group] ?? 'nice climb'
  const decayed = activeRankXp != null && isRankDecayed(xp, activeRankXp)
  const decayNote = decayed ? " (it's dipped a little from inactivity, but easy to climb back)" : ''

  if (!next) {
    return `You're ${current.name}${decayNote} — ${flavor}. That's the top of the ladder, nothing left to climb. 🏆`
  }

  const { xpIntoTier, xpNeeded } = getRankProgress(effectiveXp)
  const xpToGo = Math.max(0, xpNeeded - xpIntoTier)
  const suggestion = RANK_NEXT_STEP_SUGGESTIONS[Math.floor(Math.random() * RANK_NEXT_STEP_SUGGESTIONS.length)]
  return `You're ${current.name}${decayNote} — ${flavor}. ${fmtXP(xpToGo)} XP to ${next.name}. ${suggestion}`
}

/** Fetches the profile row once; resolve() and resolveWidget() for the
 *  rank flow both await THIS shared promise (created once per match, see
 *  matchDynamicHaloFlow below) instead of each issuing their own query. */
async function fetchRankData(myId: string): Promise<{ xp: number; activeRankXp: number } | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('xp, active_rank_xp')
    .eq('id', myId)
    .single()
  if (error || !data) return null
  return { xp: data.xp ?? 0, activeRankXp: data.active_rank_xp ?? data.xp ?? 0 }
}

// ── Online activity ──────────────────────────────────────────────────────

export const ONLINE_ACTIVITY_CHECKING_MESSAGE = 'Pulling up your activity...'

export const ONLINE_ACTIVITY_QUERY_HINT =
  /\b(how online|been online|how active (have|am) i|my activity|activity (this week|lately)|how much (have i|did i) play(ed)?|play\s?time|time (online|played)|online (time|activity)|my streak|(current|login) streak)\b/i

function buildOnlineActivityReply(totalMinutes: number, streak: number, sessions: number): string {
  if (sessions === 0) {
    return "You haven't logged any playtime this week — jump into a game and I'll start tracking it. 👀"
  }
  const hrs = Math.floor(totalMinutes / 60)
  const mins = totalMinutes % 60
  const timeStr = hrs > 0 ? `${hrs}h ${mins}m` : `${mins}m`
  const streakLine = streak > 1 ? ` You're on a ${streak}-day streak — keep it going. 🔥` : ''
  return `You've played ${timeStr} across ${sessions} session${sessions === 1 ? '' : 's'} this week.${streakLine}`
}

/** Fetches game_sessions + profile once; resolve() and resolveWidget() for
 *  this flow both await this shared promise. */
async function fetchOnlineActivityData(myId: string): Promise<HaloWidget & { type: 'online_activity' } | null> {
  const sevenDaysAgoIso = new Date(Date.now() - 7 * 86400000).toISOString()
  const [{ data: sessions, error: sessionsErr }, { data: profile }] = await Promise.all([
    supabase
      .from('game_sessions')
      .select('duration_sec, played_at')
      .eq('user_id', myId)
      .gte('played_at', sevenDaysAgoIso),
    supabase
      .from('profiles')
      .select('streak, longest_streak, last_seen_at')
      .eq('id', myId)
      .maybeSingle(),
  ])
  if (sessionsErr) return null

  // Bucket seconds-online by UTC calendar day into a fixed 7-slot array
  // (oldest -> today) so a quiet day still shows as a zero bar.
  const secondsByDate = new Map<string, number>()
  for (const s of sessions ?? []) {
    const day = (s.played_at as string).slice(0, 10)
    secondsByDate.set(day, (secondsByDate.get(day) ?? 0) + (s.duration_sec ?? 0))
  }
  const last7Days: { date: string; minutes: number }[] = []
  for (let i = 6; i >= 0; i--) {
    const day = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10)
    last7Days.push({ date: day, minutes: Math.round((secondsByDate.get(day) ?? 0) / 60) })
  }

  return {
    type: 'online_activity',
    last7Days,
    totalMinutesThisWeek: last7Days.reduce((sum, d) => sum + d.minutes, 0),
    totalSessionsThisWeek: (sessions ?? []).length,
    currentStreak: profile?.streak ?? 0,
    longestStreak: profile?.longest_streak ?? 0,
    lastSeenAt: profile?.last_seen_at ?? null,
  }
}



// ── Recent post ──────────────────────────────────────────────────────────

export const RECENT_POST_CHECKING_MESSAGE = 'Checking your feed...'

export const RECENT_POST_QUERY_HINT =
  /\b(my (recent|last|latest) post|(recent|last|latest) post i|what was my post|show my post|check my post|see my post)\b/i

const NO_RECENT_POST_REPLIES = [
  "Looks like you haven't posted anything lately — or it's aged out of the feed. Might be time for a new one 👀",
  "Nothing recent showing up on your feed — either it's been a while, or it got auto-cleared. Go post something!",
]

async function resolveRecentPost(myId: string): Promise<string> {
  const { data, error } = await supabase
    .from('posts')
    .select('id, body, created_at')
    .eq('author_id', myId)
    .eq('hidden', false)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()
  if (error) return FALLBACK_MESSAGE
  if (!data) return NO_RECENT_POST_REPLIES[Math.floor(Math.random() * NO_RECENT_POST_REPLIES.length)]

  const snippet = data.body.length > 60 ? `${data.body.slice(0, 60)}…` : data.body
  return `Your most recent post (${relativeTime(data.created_at)}): "${snippet}"\n[View post →](https://${CHILLVERSE_HOST}/feed/${data.id})`
}

// ── PvP progress ─────────────────────────────────────────────────────────

export const PVP_PROGRESS_CHECKING_MESSAGE = 'Checking your PvP stats...'

export const PVP_PROGRESS_QUERY_HINT =
  /\b(my pvp|pvp progress|pvp status|pvp stats|show my pvp|check my pvp)\b/i

function buildPvpProgressReply(state: PvpState | null, standing: MyKillStanding | null): string {
  if (!state) return FALLBACK_MESSAGE

  const hpLine = state.status === 'dead' ? "you're currently down" : `${state.hp}/${state.max_hp} HP`
  const jailNote = state.is_jailed ? ' and sitting in jail' : ''
  const killsLine = standing && standing.my_kills > 0
    ? ` You've landed ${standing.my_kills} kill${standing.my_kills === 1 ? '' : 's'}${standing.my_rank ? `, ranked #${standing.my_rank} on the kill board` : ''}.`
    : ' No kills on the board yet — go rattle somebody.'
  const hype = state.status === 'alive' && !state.is_jailed ? " You're in good shape — go hunt. 🔥" : ''

  return `You're at ${hpLine}${jailNote}.${killsLine}${hype}`
}

async function resolvePvpProgress(myId: string): Promise<string> {
  const [state, standing] = await Promise.all([
    getPvpState(myId).catch(() => null),
    getMyKillStanding().catch(() => null),
  ])
  return buildPvpProgressReply(state, standing)
}

// ── Achievement guide ────────────────────────────────────────────────────

export const ACHIEVEMENT_GUIDE_CHECKING_MESSAGE = 'Checking achievement requirements...'

const NO_ACHIEVEMENT_MATCH_REPLY =
  "Not sure which achievement you mean — check the Achievements tab for the full list and what each one needs."

// Only the "how do I ___" shape — the actual achievement gets matched
// against real titles in resolveAchievementGuide, so this alone is
// deliberately loose (it never fires anything on its own).
const ACHIEVEMENT_HOW_TO_HINT = /\b(how (do|can) i (get|unlock|earn)|what do i need (for|to get)|how to (get|unlock|earn))\b/i

export function isAchievementGuideQuery(text: string): boolean {
  return ACHIEVEMENT_HOW_TO_HINT.test(text.toLowerCase())
}

async function findNamedAchievement(text: string): Promise<Achievement | null> {
  const all = await getAllAchievements()
  const lower = text.toLowerCase()
  const matches = all
    .filter(a => a.title && lower.includes(a.title.toLowerCase()))
    .sort((a, b) => b.title.length - a.title.length)
  return matches[0] ?? null
}

async function resolveAchievementGuide(myId: string, text: string): Promise<string> {
  const ach = await findNamedAchievement(text)
  if (!ach) return NO_ACHIEVEMENT_MATCH_REPLY
  const mine = await getPlayerAchievements(myId)
  const alreadyGot = mine.some(m => m.achievement_id === ach.id)
  return alreadyGot
    ? `You've already got ${ach.title} ✅ — ${ach.description}`
    : `${ach.title}: ${ach.description}. You haven't unlocked it yet — go get it!`
}

// ── Most bought mall item ────────────────────────────────────────────────

export const MOST_BOUGHT_ITEM_CHECKING_MESSAGE = 'Checking mall stats...'

export const MOST_BOUGHT_ITEM_QUERY_HINT =
  /\b(most bought|best.?selling|most purchased|most popular item|what'?s (the )?(most|top) (bought|purchased|popular))\b/i

// No purchase-count view exists yet (unlike wishlist_counts, which Mall.tsx
// already reads for likes) — this tallies ownership from user_items
// client-side instead. Fine at current scale; if the table grows large a
// real `mall_item_purchase_counts` view (same shape as wishlist_counts)
// would be the right fix so this isn't pulling every row.
async function resolveMostBoughtItem(): Promise<string> {
  const { data, error } = await supabase.from('user_items').select('item_id').limit(5000)
  if (error || !data || data.length === 0) return FALLBACK_MESSAGE

  const tally = new Map<string, number>()
  for (const row of data) {
    const id = row.item_id as string | null
    if (!id) continue
    tally.set(id, (tally.get(id) ?? 0) + 1)
  }
  let topId: string | null = null
  let topCount = 0
  for (const [id, count] of tally) {
    if (count > topCount) { topId = id; topCount = count }
  }
  if (!topId) return FALLBACK_MESSAGE

  const { data: item } = await supabase
    .from('mall_items')
    .select('id, name, price_gems, price_orbs')
    .eq('id', topId)
    .maybeSingle()
  if (!item) return FALLBACK_MESSAGE

  const mallItem = item as Pick<MallItem, 'id' | 'name' | 'price_gems' | 'price_orbs'>
  const price = mallItem.price_gems
    ? `${mallItem.price_gems} gems`
    : mallItem.price_orbs
      ? `${mallItem.price_orbs} orbs`
      : ''
  return `${mallItem.name} is the most bought item right now${price ? ` (${price})` : ''} — owned by ${topCount} player${topCount === 1 ? '' : 's'}.\n[View in mall →](https://${CHILLVERSE_HOST}/mall?item=${mallItem.id})`
}

// ── Username ─────────────────────────────────────────────────────────────
// No request needed — Chat.tsx already has the player's own profile loaded
// in memory, so this resolves instantly and skips the "checking..." step.

export const USERNAME_QUERY_HINT = /\b(what'?s|what is) my username\b|\bmy username\b/i

function buildUsernameReply(username: string | null): string {
  return username ? `Your username is @${username}` : "Hm, I can't find your username right now — try reopening the app?"
}

// ── Dispatcher ───────────────────────────────────────────────────────────

/**
 * Tries each data-backed flow's intent check in order and returns the
 * first match. Returns null if nothing here applies, so the caller can
 * fall back to pickHaloStaticReply's instant, network-free path.
 */
export function matchDynamicHaloFlow(userText: string, ctx: HaloDynamicContext): DynamicHaloFlow | null {
  const lower = userText.toLowerCase()

  if (USERNAME_QUERY_HINT.test(lower)) {
    return { resolve: async () => buildUsernameReply(ctx.myUsername) }
  }

  if (!ctx.myId) return null // everything else needs to know who's asking
  const myId = ctx.myId

  if (RANK_PROGRESS_QUERY_HINT.test(lower)) {
    // One shared fetch — both resolve() and resolveWidget() await it, so
    // the profile row is only queried once even though both are called.
    const rankData = fetchRankData(myId)
    return {
      checking: RANK_PROGRESS_CHECKING_MESSAGE,
      resolve: async () => {
        const d = await rankData
        return d ? buildRankProgressReply(d.xp, d.activeRankXp) : FALLBACK_MESSAGE
      },
      resolveWidget: async () => {
        const d = await rankData
        return d ? { type: 'rank', xp: d.xp, activeRankXp: d.activeRankXp } : null
      },
    }
  }

  if (ONLINE_ACTIVITY_QUERY_HINT.test(lower)) {
    const activityData = fetchOnlineActivityData(myId)
    return {
      checking: ONLINE_ACTIVITY_CHECKING_MESSAGE,
      resolve: async () => {
        const d = await activityData
        return d ? buildOnlineActivityReply(d.totalMinutesThisWeek, d.currentStreak, d.totalSessionsThisWeek) : FALLBACK_MESSAGE
      },
      resolveWidget: () => activityData,
    }
  }

  if (RECENT_POST_QUERY_HINT.test(lower)) {
    return { checking: RECENT_POST_CHECKING_MESSAGE, resolve: () => resolveRecentPost(myId) }
  }

  if (PVP_PROGRESS_QUERY_HINT.test(lower)) {
    return { checking: PVP_PROGRESS_CHECKING_MESSAGE, resolve: () => resolvePvpProgress(myId) }
  }

  if (MOST_BOUGHT_ITEM_QUERY_HINT.test(lower)) {
    return { checking: MOST_BOUGHT_ITEM_CHECKING_MESSAGE, resolve: () => resolveMostBoughtItem() }
  }

  if (isAchievementGuideQuery(lower)) {
    // Only commits to this flow if a real achievement title turns up in
    // resolveAchievementGuide — see the ordering note at the top of the
    // file for why this stays last rather than firing on the phrase alone.
    return { checking: ACHIEVEMENT_GUIDE_CHECKING_MESSAGE, resolve: () => resolveAchievementGuide(myId, userText) }
  }

  return null
}
