// src/features/chat/QotdThread.tsx
// Opens when QotdCard is tapped. Intentionally NOT built on top of the
// normal messages/MessageBubble system: no reactions, no reply-to, no
// pins, no history beyond today. It's a single rotating prompt with a
// lightweight response feed underneath — closer to a live poll thread
// than a DM. Backed by qotd_daily/qotd_messages, which really do get
// wiped once the next day's question is created (see qotd_get_today in
// the DB) — this screen just always shows "today," whatever that is.

import { useEffect, useRef, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Send, Sparkles, Flame, Settings } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { useAuth } from '../auth/useAuth'
import { useModRole } from '../moderation/useModRole'
import { usePageHeader } from '../../context/PageHeader'
import QotdManageModal from './QotdManageModal'

interface QotdSnapshot {
  daily_id: string
  question: string
  day: string
  reply_count: number
  participant_count: number
}

interface QotdReply {
  id: string
  user_id: string
  body: string
  created_at: string
  display_name: string | null
  username: string | null
  avatar: string | null
}

function initials(name: string) {
  return name.trim().slice(0, 1).toUpperCase() || '?'
}

const AVATAR_COLORS = ['#ff6b00', '#3ecf8e', '#4f8ef7', '#9b6dff', '#f5c542', '#ff5c8a']
function colorFor(id: string) {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0
  return AVATAR_COLORS[h % AVATAR_COLORS.length]
}

export default function QotdThread() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { isStaff } = useModRole()
  const [qotd, setQotd] = useState<QotdSnapshot | null>(null)
  const [replies, setReplies] = useState<QotdReply[]>([])
  const [loading, setLoading] = useState(true)
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [trendBusy, setTrendBusy] = useState(false)
  const [trendMsg, setTrendMsg] = useState<string | null>(null)
  const [manageOpen, setManageOpen] = useState(false)

  // Registered unconditionally, ahead of the loading/no-question early
  // returns below (rules of hooks). No onBack override — the old button
  // used generic navigate(-1), same as the Topbar's default.
  usePageHeader({ title: 'Question of the Day' })

  // Same convention as Chat.tsx's context menu: slide the bottom dock away
  // while this full sheet is open.
  useEffect(() => {
    document.body.classList.toggle('cv-popover-open', manageOpen)
    return () => { document.body.classList.remove('cv-popover-open') }
  }, [manageOpen])
  const scrollRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = useCallback((smooth = true) => {
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
    })
  }, [])

  useEffect(() => {
    let cancelled = false

    async function load() {
      const { data: today } = await supabase.rpc('qotd_get_today')
      if (cancelled || !today) { setLoading(false); return }
      const snapshot = today as QotdSnapshot
      setQotd(snapshot)

      const { data: msgs } = await supabase.rpc('qotd_replies', { p_daily_id: snapshot.daily_id })
      if (cancelled) return
      setReplies((msgs as QotdReply[]) || [])
      setLoading(false)
      scrollToBottom(false)
    }
    load()

    return () => { cancelled = true }
  }, [scrollToBottom])

  // Realtime: new replies land live for everyone in the thread, same as
  // a normal room, but scoped to today's daily_id via the table filter.
  useEffect(() => {
    if (!qotd) return
    const channel = supabase
      .channel(`qotd:${qotd.daily_id}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'qotd_messages',
        filter: `daily_id=eq.${qotd.daily_id}`,
      }, async (payload) => {
        const row = payload.new as { id: string; user_id: string; body: string; created_at: string }
        // Skip our own optimistic insert to avoid a duplicate.
        if (row.user_id === user?.id) return
        const { data: profile } = await supabase
          .from('profiles').select('display_name, username, avatar, equipped_avatar')
          .eq('id', row.user_id).maybeSingle()
        setReplies(prev => [...prev, {
          id: row.id, user_id: row.user_id, body: row.body, created_at: row.created_at,
          display_name: profile?.display_name ?? null, username: profile?.username ?? null,
          avatar: profile?.equipped_avatar || profile?.avatar || null,
        }])
        scrollToBottom()
      })
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [qotd, user?.id, scrollToBottom])

  async function addToTrending() {
    if (trendBusy) return
    setTrendBusy(true)
    setTrendMsg(null)
    const { error: err } = await supabase.rpc('trend_add_qotd')
    setTrendBusy(false)
    if (err) {
      setTrendMsg(
        err.message?.includes('trend_limit_reached') ? 'Trending is full (max 3) — remove one first' :
        err.message?.includes('already_trending') ? 'Already in Trending Now' :
        'Could not add to Trending'
      )
      return
    }
    setTrendMsg('Added to Trending Now')
  }

  async function send() {
    const body = draft.trim()
    if (!body || sending || !qotd) return
    setSending(true)
    setError(null)
    const { data, error: err } = await supabase.rpc('qotd_reply', { p_body: body })
    setSending(false)
    if (err) {
      setError(
        err.message?.includes('message_blocked') ? "That message can't be posted here." :
        err.message?.includes('sending_too_fast') ? 'Slow down a little.' :
        "Couldn't send — try again."
      )
      return
    }
    const row = data as QotdReply
    setReplies(prev => [...prev, row])
    setDraft('')
    scrollToBottom()
  }

  if (loading) {
    return <div style={{ minHeight: '100vh', background: 'var(--bg)' }} />
  }

  if (!qotd) {
    return (
      <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 24, textAlign: 'center' }}>
        <p style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>No question today</p>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Check back a little later.</p>
        <button onClick={() => navigate(-1)} style={{ marginTop: 6, background: 'var(--accent)', color: '#fff', border: 'none', borderRadius: 12, padding: '9px 18px', fontSize: 13, fontWeight: 700 }}>
          Back
        </button>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100dvh - 60px - var(--dock-space, 0px))', background: 'var(--bg)' }}>

      {/* Header — solid accent gradient, not the neutral chat topbar, so
          it registers as a different place the instant it opens. Title +
          back button now live in the app Topbar via usePageHeader() above
          (see PAGE_HEADER_MIGRATION_PLAN.md Phase 7) — this row used to
          also draw its own back arrow, which not only duplicated the
          Topbar's but, since this container is deliberately sized to
          exactly one viewport (100dvh), was pushing content below the
          fold by the Topbar's own height. Fixed the sizing to account for
          that alongside removing the duplicate button. */}
      <div style={{
        flexShrink: 0, position: 'relative', overflow: 'hidden',
        padding: '16px 16px 20px',
        background: 'linear-gradient(160deg, color-mix(in srgb, var(--accent) 30%, var(--bg)), var(--bg) 85%)',
        borderBottom: '1px solid color-mix(in srgb, var(--accent) 25%, transparent)',
      }}>
        <div style={{ position: 'absolute', top: -50, right: -40, width: 160, height: 160, borderRadius: '50%', background: 'radial-gradient(circle, color-mix(in srgb, var(--accent) 30%, transparent), transparent 70%)', pointerEvents: 'none' }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1 }}>
            <Sparkles size={13} style={{ color: 'var(--accent)' }} />
            <span style={{ fontSize: 10.5, fontWeight: 800, letterSpacing: 0.06, textTransform: 'uppercase', color: 'var(--accent)' }}>
              Question of the Day
            </span>
          </div>
          {isStaff && (
            <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
              <button onClick={addToTrending} disabled={trendBusy} title="Add to Trending Now"
                style={{ width: 32, height: 32, borderRadius: 10, background: 'rgba(0,0,0,0.2)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text)', cursor: 'pointer' }}>
                <Flame size={14} />
              </button>
              <button onClick={() => setManageOpen(true)} title="Manage question bank"
                style={{ width: 32, height: 32, borderRadius: 10, background: 'rgba(0,0,0,0.2)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text)', cursor: 'pointer' }}>
                <Settings size={14} />
              </button>
            </div>
          )}
        </div>

        {trendMsg && (
          <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--accent)', marginBottom: 8, position: 'relative' }}>{trendMsg}</p>
        )}

        <p style={{ fontSize: 20, fontWeight: 800, lineHeight: 1.3, color: 'var(--text)', letterSpacing: '-0.02em', position: 'relative' }}>
          {qotd.question}
        </p>

        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', fontWeight: 600, marginTop: 10, position: 'relative' }}>
          {qotd.participant_count > 0
            ? `${qotd.participant_count} ${qotd.participant_count === 1 ? 'person has' : 'people have'} answered · resets tomorrow`
            : 'Nobody has answered yet — resets tomorrow'}
        </p>
      </div>

      {/* Reply feed — plain rows, not chat bubbles: no tails, no per-message
          menu, no reactions. Reads more like a comment thread than a DM. */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {replies.length === 0 ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, opacity: 0.7 }}>
            <Sparkles size={26} style={{ color: 'var(--text-muted)' }} />
            <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-muted)' }}>Nobody's answered yet</p>
            <p style={{ fontSize: 11.5, color: 'var(--text-dim)' }}>Yours could be the first</p>
          </div>
        ) : (
          replies.map(r => {
            const name = r.display_name || r.username || 'Someone'
            const mine = r.user_id === user?.id
            return (
              <div key={r.id} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                {r.avatar ? (
                  <img src={r.avatar} alt="" style={{ width: 32, height: 32, borderRadius: 10, flexShrink: 0, objectFit: 'cover' }} />
                ) : (
                  <div style={{
                    width: 32, height: 32, borderRadius: 10, flexShrink: 0,
                    background: colorFor(r.user_id), display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 13, fontWeight: 800, color: '#fff',
                  }}>
                    {initials(name)}
                  </div>
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 2 }}>
                    <span style={{ fontSize: 12.5, fontWeight: 700, color: mine ? 'var(--accent)' : 'var(--text)' }}>
                      {mine ? 'You' : name}
                    </span>
                  </div>
                  <p style={{ fontSize: 13.5, color: 'var(--text)', lineHeight: 1.45, wordBreak: 'break-word' }}>
                    {r.body}
                  </p>
                </div>
              </div>
            )
          })
        )}
      </div>

      {error && (
        <div style={{ margin: '0 16px 8px', padding: '7px 12px', borderRadius: 10, background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.25)', fontSize: 12, color: '#ff6b6b', flexShrink: 0 }}>
          {error}
        </div>
      )}

      {/* Composer — same bar/input/send-button styling as Global Chat's
          composer (blurred nav-tinted bar, inset-shadow input pill, gradient
          send button), just without the attach/emoji/poll drawer — those
          don't apply to a same-day text-only answer. */}
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, padding: '10px 12px calc(10px + env(safe-area-inset-bottom))', background: 'color-mix(in srgb, var(--nav) 92%, transparent)', backdropFilter: 'blur(14px)', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
        <div style={{ flex: 1, background: 'var(--surface)', boxShadow: 'var(--elev-inset)', border: '1px solid var(--border)', borderRadius: 14, padding: '9px 12px', display: 'flex', alignItems: 'flex-end' }}>
          <textarea
            rows={1}
            value={draft}
            onChange={e => setDraft(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
            placeholder="Share your answer…"
            maxLength={300}
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'var(--text)', fontSize: 13.5, resize: 'none', maxHeight: 120, overflowY: 'auto', lineHeight: 1.4, fontFamily: 'inherit' }}
          />
        </div>
        <button
          type="button"
          onClick={send}
          disabled={!draft.trim() || sending}
          style={{
            width: 40, height: 40, borderRadius: 11, flexShrink: 0, border: 'none',
            background: draft.trim() ? 'linear-gradient(135deg,var(--accent),var(--accent2))' : 'var(--surface2)',
            boxShadow: draft.trim() ? '0 4px 14px color-mix(in srgb, var(--accent) 35%, transparent)' : 'none',
            color: draft.trim() ? '#fff' : 'var(--text-muted)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: draft.trim() ? 'pointer' : 'default', opacity: sending ? 0.6 : 1,
          }}
        >
          <Send size={16} />
        </button>
      </div>

      {manageOpen && <QotdManageModal onClose={() => setManageOpen(false)} />}
    </div>
  )
}
