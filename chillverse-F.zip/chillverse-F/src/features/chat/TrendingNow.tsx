// src/features/chat/TrendingNow.tsx
// Purely a read surface — creation happens from the Global Chat message
// context menu (Chat.tsx, "Send to Trending") or, for QOTD, wherever we
// wire the equivalent staff action on the thread itself. This component
// just polls trending_list() and renders whatever's currently live
// (0 to 3 items, staff-curated, never algorithmic).

import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Flame, Sparkles, ChevronRight } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'

interface TrendMessageItem {
  id: string
  kind: 'global_message'
  message_id: string
  content: string
  sender_name: string | null
  reaction_count: number
}
interface TrendQotdItem {
  id: string
  kind: 'qotd'
  qotd_daily_id: string
  question: string
  reply_count: number
  participant_count: number
}
type TrendItem = TrendMessageItem | TrendQotdItem

export default function TrendingNow() {
  const navigate = useNavigate()
  const [items, setItems] = useState<TrendItem[] | null>(null)

  useEffect(() => {
    let cancelled = false
    supabase.rpc('trending_list').then(({ data }) => {
      if (!cancelled) setItems((data as TrendItem[]) || [])
    })

    // Live updates — a mod adding/removing a trend on another device (or
    // another mod entirely) should show up without a manual refresh.
    const channel = supabase
      .channel('trending-items')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trending_items' }, () => {
        supabase.rpc('trending_list').then(({ data }) => { if (!cancelled) setItems((data as TrendItem[]) || []) })
      })
      .subscribe()

    return () => { cancelled = true; supabase.removeChannel(channel) }
  }, [])

  if (!items || items.length === 0) return null

  return (
    <div style={{ padding: '2px 0 4px' }}>
      <p style={{
        fontSize: 10.5, fontWeight: 800, letterSpacing: 0.08, textTransform: 'uppercase',
        color: 'var(--text-muted)', padding: '14px 4px 8px', display: 'flex', alignItems: 'center', gap: 5,
      }}>
        <Flame size={12} style={{ color: '#ff8a3c' }} /> Trending Now
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {items.map(item => (
          <div
            key={item.id}
            role="button" tabIndex={0}
            onClick={() => navigate(item.kind === 'qotd' ? '/chat/qotd' : '/chat')}
            onKeyDown={e => { if (e.key === 'Enter') navigate(item.kind === 'qotd' ? '/chat/qotd' : '/chat') }}
            style={{
              display: 'flex', alignItems: 'center', gap: 11, cursor: 'pointer',
              padding: '11px 12px', borderRadius: 15,
              background: 'var(--surface)', border: '1px solid rgba(255,255,255,0.05)',
            }}
          >
            <div style={{
              width: 30, height: 30, borderRadius: 10, flexShrink: 0,
              background: item.kind === 'qotd'
                ? 'color-mix(in srgb, var(--accent) 22%, transparent)'
                : 'color-mix(in srgb, #ff5c8a 22%, transparent)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {item.kind === 'qotd'
                ? <Sparkles size={14} style={{ color: 'var(--accent)' }} />
                : <Flame size={14} style={{ color: '#ff5c8a' }} />}
            </div>

            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{
                fontSize: 12.5, fontWeight: 700, color: 'var(--text)',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 2,
              }}>
                {item.kind === 'qotd' ? item.question : item.content}
              </p>
              <p style={{ fontSize: 10.5, color: 'var(--text-muted)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                {item.kind === 'qotd' ? (
                  <>Question of the Day · {item.reply_count} {item.reply_count === 1 ? 'reply' : 'replies'}</>
                ) : (
                  <>Global Chat{item.sender_name ? ` · ${item.sender_name}` : ''}{item.reaction_count > 0 ? ` · ${item.reaction_count} reactions` : ''}</>
                )}
              </p>
            </div>

            <ChevronRight size={15} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />
          </div>
        ))}
      </div>
    </div>
  )
}
