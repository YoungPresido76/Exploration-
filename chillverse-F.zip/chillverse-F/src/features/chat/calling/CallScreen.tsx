// src/features/chat/calling/CallScreen.tsx
//
// Redesigned per spec: full-bleed background is the other person's equipped
// avatar skin (their profile picture stays as the small circle in the
// center, unchanged) — top-left minimize, a top-right Speaker|Mute pair,
// and a single centered End button at the bottom. Nothing else.
import { useEffect, useRef, type ReactNode } from 'react'
import { Volume2, Mic, MicOff, PhoneOff, ChevronDown } from 'lucide-react'
import { useCall } from './CallContext'
import Avatar from '../../../shared/components/Avatar'

function formatCallDuration(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60)
  const seconds = totalSeconds % 60
  return `${minutes}:${seconds.toString().padStart(2, '0')}`
}

function CallIconButton({
  onClick, active, title, children,
}: { onClick: () => void; active?: boolean; title: string; children: ReactNode }) {
  return (
    <button type="button" onClick={onClick} title={title}
      style={{
        width: 44, height: 44, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.16)',
        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: active ? '#fff' : 'rgba(20,20,24,0.55)', color: active ? '#111' : '#fff',
        backdropFilter: 'blur(8px)', transition: 'background .15s ease, color .15s ease',
      }}>
      {children}
    </button>
  )
}

export default function CallScreen() {
  const {
    phase, call, otherParticipant, localStream, remoteStream, isMuted, isSpeakerOn,
    durationSeconds, endCall, toggleMute, toggleSpeaker, minimizeCall,
  } = useCall()

  // Remote AUDIO is handled entirely by the persistent <audio> element in
  // CallProvider (see CallContext.tsx) so it survives minimizing — this
  // element is video-only and explicitly muted so sound is never doubled.
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const isVideoCall = call?.type === 'video'

  useEffect(() => {
    if (isVideoCall && remoteVideoRef.current) remoteVideoRef.current.srcObject = remoteStream
  }, [remoteStream, isVideoCall])

  useEffect(() => {
    if (isVideoCall && localVideoRef.current) localVideoRef.current.srcObject = localStream
  }, [localStream, isVideoCall])

  if (!call || !otherParticipant) return null
  const name = otherParticipant.display_name || otherParticipant.username

  const statusLabel =
    phase === 'dialing' ? 'Calling…' :
    phase === 'connecting' ? 'Connecting…' :
    formatCallDuration(durationSeconds)

  // Background = the callee/caller's equipped avatar skin, full-bleed and
  // softened, so the person is still recognizable behind the UI without the
  // background competing with the centered profile-pic circle. Falls back to
  // the app's normal dark surface gradient when nothing is equipped (or the
  // equipped value isn't an image — some skins are stored as a bare glyph).
  const bgImage = otherParticipant.equipped_avatar?.startsWith('http') ? otherParticipant.equipped_avatar : null

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: bgImage ? '#000' : 'linear-gradient(160deg, var(--surface2), var(--bg))',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'space-between',
      padding: '64px 24px 48px', overflow: 'hidden',
    }}>
      {/* Equipped-avatar background layer */}
      {bgImage && !isVideoCall && (
        <>
          <div style={{
            position: 'absolute', inset: -20, zIndex: 0,
            backgroundImage: `url(${bgImage})`, backgroundSize: 'cover', backgroundPosition: 'center',
            filter: 'blur(18px) brightness(0.55)', transform: 'scale(1.1)',
          }} />
          <div style={{ position: 'absolute', inset: 0, zIndex: 0, background: 'radial-gradient(ellipse at 50% 40%, transparent 0%, rgba(0,0,0,0.55) 100%)' }} />
        </>
      )}

      {/* Video call: remote video fills the screen instead, muted here since
          audio comes from the provider's persistent <audio> element. */}
      {isVideoCall && (
        <video ref={remoteVideoRef} autoPlay playsInline muted
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 }} />
      )}

      {/* Top-left: minimize */}
      <button type="button" onClick={minimizeCall} title="Minimize"
        style={{
          position: 'absolute', top: 'max(20px, env(safe-area-inset-top))', left: 20, zIndex: 3,
          width: 40, height: 40, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.16)',
          background: 'rgba(20,20,24,0.55)', color: '#fff', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(8px)',
        }}>
        <ChevronDown size={20} />
      </button>

      {/* Top-right: Speaker | Mute */}
      <div style={{ position: 'absolute', top: 'max(20px, env(safe-area-inset-top))', right: 20, zIndex: 3, display: 'flex', gap: 10 }}>
        <CallIconButton onClick={toggleSpeaker} active={isSpeakerOn} title={isSpeakerOn ? 'Speaker on' : 'Speaker off'}>
          <Volume2 size={19} />
        </CallIconButton>
        <CallIconButton onClick={toggleMute} active={isMuted} title={isMuted ? 'Unmute' : 'Mute'}>
          {isMuted ? <MicOff size={19} /> : <Mic size={19} />}
        </CallIconButton>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, marginTop: 32, zIndex: 1 }}>
        <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', fontWeight: 600, letterSpacing: 0.5 }}>
          {statusLabel}
        </span>
      </div>

      {/* Centered profile-pic circle — the person's actual profile picture,
          not the equipped-avatar background layer behind it. */}
      {(!isVideoCall || phase !== 'connected') && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, zIndex: 1 }}>
          <div style={{
            width: 120, height: 120, borderRadius: '50%', overflow: 'hidden', flexShrink: 0,
            boxShadow: 'var(--elev-popover)', border: '3px solid rgba(255,255,255,0.15)',
          }}>
            <Avatar src={otherParticipant.avatar} name={name} size={120} radius="50%" disabled />
          </div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#fff' }}>{name}</div>
        </div>
      )}

      {/* Local video preview (video calls only) — small corner tile, self-view
          while the call is on, same as before this redesign. */}
      {isVideoCall && (
        <video ref={localVideoRef} autoPlay playsInline muted
          style={{
            position: 'absolute', top: 76, right: 20, width: 88, height: 118, borderRadius: 12, objectFit: 'cover',
            border: '2px solid rgba(255,255,255,0.2)', zIndex: 2, background: '#111',
          }} />
      )}

      {/* Bottom-center: End, alone */}
      <button type="button" onClick={endCall} title="End call"
        style={{
          width: 64, height: 64, borderRadius: '50%', border: 'none', cursor: 'pointer',
          background: '#ff4f4f', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(255,79,79,0.4)', zIndex: 1,
        }}>
        <PhoneOff size={26} />
      </button>
    </div>
  )
}
