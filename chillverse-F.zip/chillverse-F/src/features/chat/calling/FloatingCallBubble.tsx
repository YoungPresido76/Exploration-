// src/features/chat/calling/FloatingCallBubble.tsx
//
// Replaces the old full-width MinimizedCallBar. This is just the other
// person's avatar in a small circle, freely draggable anywhere on screen,
// that reopens the full call screen on tap — the call's WebRTC connection
// and audio are untouched by this (they live in CallProvider, above this
// component, and the persistent <audio> element there keeps playing
// regardless of where this bubble sits or whether it's being dragged).
import { useRef, useState, type PointerEvent as ReactPointerEvent } from 'react'
import { useCall } from './CallContext'
import Avatar from '../../../shared/components/Avatar'

const BUBBLE_SIZE = 64
const EDGE_MARGIN = 12
// Pointer movement below this (px) counts as a tap, not a drag — lets a
// quick tap still restore the call even if the finger wobbles slightly.
const DRAG_THRESHOLD = 6

export default function FloatingCallBubble() {
  const { call, otherParticipant, restoreCall } = useCall()

  // Starting corner: bottom-right, clear of the bottom nav / home indicator.
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null)
  const draggingRef = useRef(false)
  const movedRef = useRef(false)
  const startRef = useRef({ pointerX: 0, pointerY: 0, originX: 0, originY: 0 })

  function clamp(x: number, y: number) {
    const maxX = window.innerWidth - BUBBLE_SIZE - EDGE_MARGIN
    const maxY = window.innerHeight - BUBBLE_SIZE - EDGE_MARGIN
    return { x: Math.min(Math.max(EDGE_MARGIN, x), Math.max(EDGE_MARGIN, maxX)), y: Math.min(Math.max(EDGE_MARGIN, y), Math.max(EDGE_MARGIN, maxY)) }
  }

  function currentPos() {
    if (pos) return pos
    return clamp(window.innerWidth - BUBBLE_SIZE - EDGE_MARGIN, window.innerHeight - BUBBLE_SIZE - 120)
  }

  function onPointerDown(e: ReactPointerEvent<HTMLDivElement>) {
    e.currentTarget.setPointerCapture(e.pointerId)
    draggingRef.current = true
    movedRef.current = false
    const p = currentPos()
    startRef.current = { pointerX: e.clientX, pointerY: e.clientY, originX: p.x, originY: p.y }
  }

  function onPointerMove(e: ReactPointerEvent<HTMLDivElement>) {
    if (!draggingRef.current) return
    const dx = e.clientX - startRef.current.pointerX
    const dy = e.clientY - startRef.current.pointerY
    if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) movedRef.current = true
    setPos(clamp(startRef.current.originX + dx, startRef.current.originY + dy))
  }

  function onPointerUp() {
    draggingRef.current = false
    if (!movedRef.current) restoreCall()
  }

  if (!call || !otherParticipant) return null
  const name = otherParticipant.display_name || otherParticipant.username
  const { x, y } = currentPos()

  return (
    <div
      role="button"
      tabIndex={0}
      title="Return to call"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') restoreCall() }}
      style={{
        position: 'fixed', left: x, top: y, width: BUBBLE_SIZE, height: BUBBLE_SIZE, zIndex: 9998,
        borderRadius: '50%', cursor: 'grab', touchAction: 'none',
        boxShadow: '0 8px 24px rgba(0,0,0,0.45)', border: '2px solid color-mix(in srgb, var(--accent) 55%, transparent)',
        transition: draggingRef.current ? 'none' : 'left .15s ease, top .15s ease',
      }}>
      <Avatar src={otherParticipant.avatar} name={name} size={BUBBLE_SIZE - 4} radius="50%" disabled style={{ margin: 2 }} />
    </div>
  )
}
