// src/features/chat/ReactorsSheet.tsx
//
// Tapping a reaction pill under a message used to just toggle your own
// reaction of that emoji. It no longer does — tapping now opens this
// sheet, listing who reacted and with what (WhatsApp-style). Toggling
// your own reaction still happens, just from the long-press/right-click
// quick-reaction row each surface (Chat.tsx, ClubChat.tsx) already had —
// this sheet is read-only.
//
// Shared between Chat.tsx (DMs + Global Chat) and ClubChat.tsx so the
// list, tabs and dock-hiding behavior can't drift between the two
// surfaces. Each caller supplies its own `getUser` lookup since the two
// screens resolve identity differently (Chat.tsx's `activeRoom.members`
// vs ClubChat.tsx's club member list).
import { useEffect, useState } from 'react'
import { X } from 'lucide-react'
import { useRealViewportHeight, useSheetDrag } from '../../shared/hooks/useBottomSheet'
import { Avatar } from './MessageBubble'

export interface ReactorEntry {
  user_id: string
  emoji: string
}

export interface ReactorUser {
  name: string
  avatar: string | null
}

interface ReactorsSheetProps {
  /** Every raw reaction row on the one message the sheet was opened for. */
  reactions: ReactorEntry[]
  /** Resolves a reactor's display name/avatar. Returns undefined for a
   *  reactor outside whatever member list the caller has loaded (e.g. a
   *  Global Chat reactor who's never sent a message in the current
   *  window) — the row falls back to a generic placeholder rather than
   *  disappearing, since the reaction itself is still real. */
  getUser: (userId: string) => ReactorUser | undefined
  onClose: () => void
}

const SHEET_MAX_HEIGHT_VH = 62

export default function ReactorsSheet({ reactions, getUser, onClose }: ReactorsSheetProps) {
  const realVh = useRealViewportHeight()
  const maxHeightPx = Math.round(realVh * (SHEET_MAX_HEIGHT_VH / 100))
  const { dragY, dragging, dragHandleProps } = useSheetDrag(onClose)

  // Same "lock the page, hide the portaled dock" pattern every other
  // sheet in the app uses — see Mall.tsx's ItemModal.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  // Distinct emoji, in first-appearance order — same ordering rule the
  // pills themselves use, so the tab row and the pill row never disagree
  // about which comes first.
  const emojiOrder: string[] = []
  for (const r of reactions) if (!emojiOrder.includes(r.emoji)) emojiOrder.push(r.emoji)

  const [activeTab, setActiveTab] = useState<'all' | string>('all')
  const effectiveTab = activeTab === 'all' || emojiOrder.includes(activeTab) ? activeTab : 'all'
  const visible = effectiveTab === 'all' ? reactions : reactions.filter(r => r.emoji === effectiveTab)

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{
        position: 'fixed', inset: 0, zIndex: 800, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      <div style={{
        background: 'var(--surface)', borderRadius: '20px 20px 0 0', padding: '0 16px 20px', width: '100%', maxWidth: 460,
        border: '1px solid var(--border)', borderBottom: 'none', boxShadow: '0 -12px 40px -12px var(--sh)',
        position: 'relative', maxHeight: maxHeightPx, overflowY: 'hidden', display: 'flex', flexDirection: 'column',
        transform: `translateY(${dragY}px)`,
        transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.16,1,0.3,1)',
        animation: dragging ? undefined : 'slideUp 0.28s cubic-bezier(0.16,1,0.3,1) both',
      }}>
        <div
          {...dragHandleProps}
          style={{ ...dragHandleProps.style, padding: '10px 0 8px', margin: '0 auto', flexShrink: 0, display: 'flex', justifyContent: 'center' }}
        >
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, flexShrink: 0 }}>
          <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
            {reactions.length} reaction{reactions.length === 1 ? '' : 's'}
          </span>
          <button onClick={onClose} style={{ width: 28, height: 28, borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)' }}>
            <X size={13} />
          </button>
        </div>

        {emojiOrder.length > 1 && (
          <div style={{ display: 'flex', gap: 6, marginBottom: 10, overflowX: 'auto', flexShrink: 0 }}>
            <button
              onClick={() => setActiveTab('all')}
              style={{
                padding: '6px 12px', borderRadius: 20, whiteSpace: 'nowrap', cursor: 'pointer', fontFamily: 'inherit',
                fontSize: 11.5, fontWeight: 700, border: effectiveTab === 'all' ? '1px solid var(--border-strong)' : '1px solid transparent',
                background: effectiveTab === 'all' ? 'var(--active)' : 'transparent',
                color: effectiveTab === 'all' ? 'var(--text)' : 'var(--text-dim)',
              }}
            >
              All {reactions.length}
            </button>
            {emojiOrder.map(emoji => {
              const count = reactions.filter(r => r.emoji === emoji).length
              return (
                <button
                  key={emoji}
                  onClick={() => setActiveTab(emoji)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 4, padding: '6px 12px', borderRadius: 20, whiteSpace: 'nowrap', cursor: 'pointer', fontFamily: 'inherit',
                    fontSize: 11.5, fontWeight: 700, border: effectiveTab === emoji ? '1px solid var(--border-strong)' : '1px solid transparent',
                    background: effectiveTab === emoji ? 'var(--active)' : 'transparent',
                    color: effectiveTab === emoji ? 'var(--text)' : 'var(--text-dim)',
                  }}
                >
                  <span className="cv-emoji">{emoji}</span> {count}
                </button>
              )
            })}
          </div>
        )}

        <div style={{ overflowY: 'auto', flex: 1 }}>
          {visible.map((r, i) => {
            const user = getUser(r.user_id)
            return (
              <div key={`${r.user_id}-${r.emoji}-${i}`} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 2px' }}>
                <Avatar name={user?.name ?? 'Chillverse User'} avatarUrl={user?.avatar ?? null} size={34} radius={11} />
                <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {user?.name ?? 'Chillverse User'}
                </span>
                <span className="cv-emoji" style={{ fontSize: 17 }}>{r.emoji}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
