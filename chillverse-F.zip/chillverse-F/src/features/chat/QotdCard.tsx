// src/features/chat/QotdCard.tsx
// The "Discover" entry point inside the Chats list. Deliberately doesn't
// look like a room row (no avatar-left/preview-right pattern) — it's a
// gradient prompt card, because clicking it opens a thread that isn't a
// normal chat either (see QotdThread.tsx): no history, wiped daily, no
// reactions/replies/pins. The visual break here is what tells the user
// "this is a different kind of space" before they even tap it.

import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Sparkles } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'

interface QotdSnapshot {
  daily_id: string
  question: string
  reply_count: number
  participant_count: number
}
interface RecentReplier {
  user_id: string
  avatar: string | null
  display_name: string | null
  username: string | null
}

const STACK_COLORS = ['#ff6b00', '#3ecf8e', '#4f8ef7']
function colorFor(id: string) {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0
  return STACK_COLORS[h % STACK_COLORS.length]
}

export default function QotdCard() {
  const navigate = useNavigate()
  const [qotd, setQotd] = useState<QotdSnapshot | null>(null)
  const [repliers, setRepliers] = useState<RecentReplier[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    supabase.rpc('qotd_get_today').then(async ({ data }) => {
      if (cancelled || !data) { if (!cancelled) setLoading(false); return }
      const snapshot = data as QotdSnapshot
      setQotd(snapshot)
      setLoading(false)

      if (snapshot.reply_count > 0) {
        const { data: replies } = await supabase.rpc('qotd_replies', { p_daily_id: snapshot.daily_id, p_limit: 30 })
        if (cancelled) return
        const rows = (replies as { user_id: string; avatar: string | null; display_name: string | null; username: string | null }[]) || []
        const seen = new Set<string>()
        const uniqueRepliers: RecentReplier[] = []
        for (let i = rows.length - 1; i >= 0 && uniqueRepliers.length < 3; i--) {
          if (seen.has(rows[i].user_id)) continue
          seen.add(rows[i].user_id)
          uniqueRepliers.push(rows[i])
        }
        setRepliers(uniqueRepliers)
      }
    })
    return () => { cancelled = true }
  }, [])

  // Bank is empty (shouldn't happen once seeded, but fail quiet rather
  // than show a broken-looking card) or still loading — render nothing.
  if (loading || !qotd) return null

  return (
    <div style={{ padding: '2px 0 4px' }}>
      <div
        role="button" tabIndex={0}
        onClick={() => navigate('/chat/qotd')}
        onKeyDown={e => { if (e.key === 'Enter') navigate('/chat/qotd') }}
        style={{
          position: 'relative', overflow: 'hidden', cursor: 'pointer',
          borderRadius: 18, padding: '16px 17px 14px',
          background: 'linear-gradient(135deg, color-mix(in srgb, var(--accent) 20%, var(--surface)), var(--surface))',
          border: '1px solid color-mix(in srgb, var(--accent) 35%, transparent)',
        }}
      >
        {/* soft glow, purely decorative — reinforces "this one's special" */}
        <div style={{
          position: 'absolute', top: -30, right: -30, width: 110, height: 110, borderRadius: '50%',
          background: 'radial-gradient(circle, color-mix(in srgb, var(--accent) 35%, transparent), transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 9, position: 'relative' }}>
          <Sparkles size={13} style={{ color: 'var(--accent)' }} />
          <span style={{ fontSize: 10.5, fontWeight: 800, letterSpacing: 0.06, textTransform: 'uppercase', color: 'var(--accent)' }}>
            Question of the Day
          </span>
        </div>

        <p style={{
          fontSize: 15.5, fontWeight: 700, lineHeight: 1.35, color: 'var(--text)',
          marginBottom: 12, position: 'relative', letterSpacing: '-0.01em',
        }}>
          {qotd.question}
        </p>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {repliers.length > 0 && (
              <div style={{ display: 'flex', alignItems: 'center' }}>
                {repliers.map((r, i) => {
                  const name = r.display_name || r.username || '?'
                  return r.avatar ? (
                    <img key={r.user_id} src={r.avatar} alt=""
                      style={{ width: 21, height: 21, borderRadius: '50%', border: '2px solid var(--surface)', marginLeft: i === 0 ? 0 : -7, objectFit: 'cover' }} />
                  ) : (
                    <div key={r.user_id} style={{
                      width: 21, height: 21, borderRadius: '50%', border: '2px solid var(--surface)', marginLeft: i === 0 ? 0 : -7,
                      background: colorFor(r.user_id), display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 9, fontWeight: 800, color: '#fff', flexShrink: 0,
                    }}>
                      {name.slice(0, 1).toUpperCase()}
                    </div>
                  )
                })}
              </div>
            )}
            <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--text-muted)' }}>
              {qotd.reply_count > 0
                ? `${qotd.reply_count} ${qotd.reply_count === 1 ? 'reply' : 'replies'}`
                : 'Be the first to answer'}
            </span>
          </div>
          <span style={{
            fontSize: 11, fontWeight: 700, color: '#fff', background: 'var(--accent)',
            padding: '6px 13px', borderRadius: 20,
          }}>
            Join in
          </span>
        </div>
      </div>
    </div>
  )
}
