// src/features/chat/DmRequestBar.tsx
//
// Replaces the composer while a DM is still a request.
//
// Two faces:
//   incoming — the three answers: accept, decline, block.
//   outgoing — a plain notice, so the sender learns the rule from the UI
//              instead of discovering it as a send error on their second
//              message.
//
// Sits in the same slot as the existing block banner in Chat.tsx, which
// is already the established "composer is unavailable" pattern.
import { useState } from 'react'
import { Check, X, ShieldOff, Clock } from 'lucide-react'
import { acceptDmRequest, declineDmRequest } from './dmRequests'

interface Props {
  roomId: string
  state: 'incoming' | 'outgoing'
  /** Display name of the other person, for the copy. */
  otherName: string
  /** Fired after accept so the parent can show the composer. */
  onAccepted: () => void
  /** Fired after decline or block — the room is gone, so the parent
   *  should drop it from the list and leave the conversation. */
  onDismissed: (blocked: boolean) => void
  onError: (message: string) => void
}

export default function DmRequestBar({ roomId, state, otherName, onAccepted, onDismissed, onError }: Props) {
  const [busy, setBusy] = useState(false)
  const [confirming, setConfirming] = useState<null | 'decline' | 'block'>(null)

  if (state === 'outgoing') {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 9, padding: '13px 16px',
        background: 'var(--surface)', borderTop: '1px solid var(--border)',
      }}>
        <Clock size={14} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
        <span style={{ fontSize: 12.5, color: 'var(--text-dim)', fontWeight: 600, lineHeight: 1.45 }}>
          Message request sent. You can send another once {otherName} accepts.
        </span>
      </div>
    )
  }

  async function accept() {
    setBusy(true)
    try {
      await acceptDmRequest(roomId)
      onAccepted()
    } catch (e: any) {
      onError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function dismiss(block: boolean) {
    setBusy(true)
    try {
      await declineDmRequest(roomId, block)
      onDismissed(block)
    } catch (e: any) {
      onError(e.message)
      setBusy(false)
      setConfirming(null)
    }
  }

  // Deleting is irreversible and takes the message with it, so the two
  // destructive answers ask once. Accept doesn't — it's undoable by
  // blocking afterwards.
  if (confirming) {
    const isBlock = confirming === 'block'
    return (
      <div style={{
        padding: '13px 16px',
        background: 'rgba(255,107,107,0.07)', borderTop: '1px solid rgba(255,107,107,0.18)',
      }}>
        <p style={{ fontSize: 12.5, color: 'var(--text)', fontWeight: 600, marginBottom: 10, lineHeight: 1.5 }}>
          {isBlock
            ? `Block ${otherName} and delete this chat? They won't be able to message you again.`
            : `Delete this chat? ${otherName} won't be told.`}
        </p>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            type="button" onClick={() => dismiss(isBlock)} disabled={busy}
            style={{ flex: 1, padding: '9px 0', borderRadius: 11, border: 'none', background: '#ff6b6b', color: '#fff', fontWeight: 800, fontSize: 12.5, cursor: 'pointer', opacity: busy ? 0.7 : 1 }}
          >
            {busy ? '…' : isBlock ? 'Block and delete' : 'Delete'}
          </button>
          <button
            type="button" onClick={() => setConfirming(null)} disabled={busy}
            style={{ padding: '9px 18px', borderRadius: 11, border: '1px solid var(--border)', background: 'none', color: 'var(--text-dim)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer' }}
          >
            Cancel
          </button>
        </div>
      </div>
    )
  }

  return (
    <div style={{
      padding: '12px 16px 14px',
      background: 'var(--surface)', borderTop: '1px solid var(--border)',
    }}>
      <p style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, marginBottom: 10 }}>
        {otherName} wants to message you. Accept to reply.
      </p>
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          type="button" onClick={accept} disabled={busy}
          style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '10px 0', borderRadius: 11, border: 'none', background: 'var(--accent)', color: '#fff', fontWeight: 800, fontSize: 12.5, cursor: 'pointer', opacity: busy ? 0.7 : 1 }}
        >
          <Check size={14} /> Accept
        </button>
        <button
          type="button" onClick={() => setConfirming('decline')} disabled={busy}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '10px 15px', borderRadius: 11, border: '1px solid var(--border)', background: 'none', color: 'var(--text-dim)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer' }}
        >
          <X size={14} /> Decline
        </button>
        <button
          type="button" onClick={() => setConfirming('block')} disabled={busy}
          aria-label="Block"
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '10px 13px', borderRadius: 11, border: '1px solid rgba(255,107,107,0.3)', background: 'none', color: '#ff6b6b', cursor: 'pointer' }}
        >
          <ShieldOff size={14} />
        </button>
      </div>
    </div>
  )
}
