// src/pages/Dashboard.tsx
import { useState, useEffect, useMemo } from 'react'
import type { CSSProperties } from 'react'
import { Link } from 'react-router-dom'
import type { LucideIcon } from 'lucide-react'
import {
  TreePine, ShoppingBag, Film, Swords, Sparkles,
  Flame, Zap, ChevronRight, Fan, Trophy, Wallet,
} from 'lucide-react'
import { useProfile } from '../profile/useProfile'
import { getUserRankTier, getNextRankTier, getRankProgress } from '../profile/ranks'
import { ripple } from '../../shared/lib/ripple'
import Avatar from '../../shared/components/Avatar'
import RankBadge from '../../shared/components/RankBadge'
import PageOnboarding from '../onboarding/PageOnboarding'
import { useFeatureFlags } from '../../shared/lib/featureFlags'
import { fetchDashboardGreeting } from '../admin/adminOps'
import EliminationDashboardCard from '../pvp/EliminationDashboardCard'
import ChampionshipDashboardCard from '../championship/ChampionshipDashboardCard'
import { useMallNewItemsBadge } from '../economy/useMallNewItemsBadge'
import { NewDot } from '../economy/useMallNewBadges'

interface QuickAction {
  label: string
  sub: string
  to: string
  bg: string
  icon: LucideIcon
  dot?: boolean
}

const MINI_AVATAR_COLORS = ['#ff6b6b','#4f8ef7','#9b6dff','#3ecf8e','#f5c542']

// ─── Smart greeting ───────────────────────────────────────────
function getGreeting(name: string): { line: string; sub: string } {
  const h = new Date().getHours()
  const day = new Date().getDay() // 0=Sun,6=Sat

  // Time-aware pool. Mixed in a few warmer, more conversational lines
  // (the "Claude-ish" register — direct, a little wry, genuinely glad
  // to see you) alongside the punchier hype-man originals, so the pool
  // doesn't read as one voice repeated on a loop.
  const greetings = {
    lateNight: [   // 0-4
      { line: `Late night, ${name}..`,    sub: "Still up? Respect the grind." },
      { line: `Can't sleep, ${name}?`,    sub: "Neither can we. Let's go." },
      { line: `Night owl mode 🦉`,         sub: `What's good, ${name}?` },
      { line: `You're up late, ${name}`,  sub: "No judgment — glad you're here." },
      { line: `Hey ${name}, it's quiet`,  sub: "Good time for something low-key." },
      { line: `3am thoughts, ${name}?`,   sub: "Let's turn them into a win streak." },
    ],
    earlyMorning: [ // 5-8
      { line: `Early bird, ${name} 🐦`,   sub: "You're up before everyone." },
      { line: `Good morning, ${name}`,    sub: "Coffee first or games first?" },
      { line: `Rise & grind, ${name}`,    sub: "The leaderboard won't climb itself." },
      { line: `Morning, ${name}`,         sub: "Nice and early. I like it." },
      { line: `First thing, ${name}?`,    sub: "Let's ease into the day right." },
    ],
    morning: [     // 9-11
      { line: `Morning, ${name} ☀️`,      sub: "What are we getting into today?" },
      { line: `Coffee time, ${name}?`,    sub: "Or are you already on it." },
      { line: `Back at it, ${name}`,      sub: "Let's make today count." },
      { line: `Good to see you, ${name}`, sub: "What's the plan this morning?" },
      { line: `Hey ${name}`,              sub: "Ready when you are." },
    ],
    afternoon: [   // 12-16
      { line: `Hey ${name} 👋`,           sub: "Good to see you back." },
      { line: `Game time, ${name}?`,      sub: "Sessions are waiting." },
      { line: `Bored?¿ ${name}`,          sub: "Yeah we got you." },
      { line: `Afternoon, ${name}`,       sub: "Perfect time for a quick round." },
      { line: `Hey there, ${name}`,       sub: "What sounds good right now?" },
    ],
    evening: [     // 17-20
      { line: `Evening, ${name}`,         sub: "Wind down or heat up?" },
      { line: `Hey ${name}, what's up`,   sub: "The crew's online." },
      { line: `Moonlight chat, ${name}?`, sub: "It's that time of day." },
      { line: `Good evening, ${name}`,    sub: "Glad you made it back." },
      { line: `Hey ${name}`,              sub: "How'd the day treat you?" },
    ],
    night: [       // 21-23
      { line: `Night mode, ${name} 🌙`,   sub: "Last sessions of the day." },
      { line: `Still here, ${name}?`,     sub: "One more game won't hurt." },
      { line: `Moonlight chat, ${name}?`, sub: "Quiet hours, real ones only." },
      { line: `Hey ${name}`,              sub: "Winding down or just getting started?" },
      { line: `Good to see you, ${name}`, sub: "Let's close the day out well." },
    ],
  }

  // Weekend bonus
  if ((day === 0 || day === 6) && h >= 10 && h < 14) {
    return { line: `Weekend energy, ${name}`, sub: "No alarm, no rules. Let's go." }
  }

  let pool
  if (h < 5)       pool = greetings.lateNight
  else if (h < 9)  pool = greetings.earlyMorning
  else if (h < 12) pool = greetings.morning
  else if (h < 17) pool = greetings.afternoon
  else if (h < 21) pool = greetings.evening
  else              pool = greetings.night

  // Pick deterministically by hour — only changes when the hour changes
  const idx = h % pool.length
  return pool[idx]
}

// ─── Streak message ───────────────────────────────────────────
function getStreakMessage(streak: number): { emoji: string; message: string; color: string } {
  if (streak === 0) {
    return { emoji: '👀', message: "No streak yet — today's a good day to start.", color: 'var(--text-muted)' }
  }
  if (streak === 1) {
    return { emoji: '🌱', message: "Day 1. The seed is planted.", color: '#3ecf8e' }
  }
  if (streak <= 3) {
    return { emoji: '🔥', message: `${streak}-day streak — you're just warming up.`, color: 'var(--accent2)' }
  }
  if (streak <= 6) {
    return { emoji: '⚡', message: `${streak} days straight. The momentum is real.`, color: '#f5c542' }
  }
  if (streak <= 13) {
    return { emoji: '🚀', message: `${streak}-day streak. You're locked in.`, color: '#4f8ef7' }
  }
  if (streak <= 29) {
    return { emoji: '💎', message: `${streak} days. This is becoming a lifestyle.`, color: '#a8f0ff' }
  }
  if (streak <= 59) {
    return { emoji: '👑', message: `${streak}-day streak. Absolute legend behaviour.`, color: '#9b6dff' }
  }
  return { emoji: '🌌', message: `${streak} days. You ARE Chillverse.`, color: '#f5c542' }
}

// ─── Skeleton block ─────────────────────────────────────────
function SkeletonBlock({ style }: { style?: CSSProperties }) {
  return (
    <div
      style={{
        borderRadius: 14,
        background: 'var(--surface2)',
        boxShadow: 'var(--elev-raise)',
        animation: 'pulse 1.6s ease-in-out infinite',
        ...style,
      }}
    />
  )
}

export default function Dashboard() {
  const { profile, loading, error } = useProfile()
  // Halo AI is still rolling out — the card below says so rather than
  // promising a chat that /halo won't give them. Same fail-closed read as
  // the gate in HaloAI.tsx: unknown flag state means "not yet".
  const { flags: cvFlags } = useFeatureFlags()
  const haloReleased = cvFlags['system:halo_ai_released'] === true

  // Mall quick-action tile dot — must be before any early returns, same
  // as everything else on this line.
  const hasNewMallItems = useMallNewItemsBadge()

  // currentHour drives greeting — must be before any early returns
  const [currentHour, setCurrentHour] = useState(() => new Date().getHours())
  useEffect(() => {
    const iv = setInterval(() => {
      const h = new Date().getHours()
      setCurrentHour(prev => prev !== h ? h : prev)
    }, 60_000)
    return () => clearInterval(iv)
  }, [])
  const autoGreeting = useMemo(
    () => getGreeting(profile?.display_name || profile?.username || 'friend'),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [profile, currentHour],
  )

  // Admin override — pinned via Admin ops → Dashboard greeting. 'automatic'
  // (the default) just falls through to the time-of-day pool above; a
  // fetch hiccup fails the same way, so a broken override can never hide
  // the real greeting.
  const [greetingOverride, setGreetingOverride] = useState<{ line: string; sub: string } | null>(null)
  useEffect(() => {
    let active = true
    fetchDashboardGreeting().then(({ data }) => {
      if (!active || !data) return
      if (data.dashboard_greeting_mode === 'custom' && data.dashboard_greeting_line) {
        setGreetingOverride({
          line: data.dashboard_greeting_line,
          sub: data.dashboard_greeting_sub || '',
        })
      } else {
        setGreetingOverride(null)
      }
    })
    return () => { active = false }
  }, [])

  const greeting = greetingOverride ?? autoGreeting

  // ── Lazy random "glint" — one dashboard card at a time gets a glass
  // shine sweep, on a random delay, so it feels like a subtle temptation
  // rather than a busy/looping effect on every card at once.
  const GLINT_CARD_KEYS = useMemo(
    () => ['qa-0', 'qa-1', 'qa-2', 'multiplayer', 'tile-0', 'tile-1', 'tile-2', 'tile-3', 'artifacts', 'halo'],
    [],
  )
  const [glintCard, setGlintCard] = useState<string | null>(null)
  useEffect(() => {
    let waitId: ReturnType<typeof setTimeout>
    let playId: ReturnType<typeof setTimeout>
    let cancelled = false

    const scheduleNext = () => {
      const delay = 7000 + Math.random() * 11000 // lazy: every ~7–18s
      waitId = setTimeout(() => {
        if (cancelled) return
        const key = GLINT_CARD_KEYS[Math.floor(Math.random() * GLINT_CARD_KEYS.length)]
        setGlintCard(key)
        playId = setTimeout(() => {
          if (cancelled) return
          setGlintCard(null)
          scheduleNext()
        }, 1500) // sweep duration, matches dashGlintSweep animation
      }, delay)
    }
    scheduleNext()

    return () => { cancelled = true; clearTimeout(waitId); clearTimeout(playId) }
  }, [GLINT_CARD_KEYS])

  if (loading) {
    return (
      <div className="flex flex-col max-w-[800px] mx-auto">
        {/* ── Welcome card skeleton ── */}
        <section className="su d1">
          <div className="neu-card" style={{ padding: '22px 20px' }}>
            <div className="flex items-center justify-between gap-4">
              <div style={{ flex: 1, minWidth: 0 }}>
                <SkeletonBlock style={{ width: 130, height: 11, marginBottom: 9 }} />
                <SkeletonBlock style={{ width: 190, height: 22, marginBottom: 12 }} />
                <SkeletonBlock style={{ width: 150, height: 24, borderRadius: 10 }} />
              </div>
              <SkeletonBlock style={{ width: 54, height: 54, borderRadius: 16, flexShrink: 0 }} />
            </div>
          </div>
        </section>

        {/* ── XP bar skeleton ── */}
        <section className="su d2" style={{ marginTop: 12 }}>
          <div className="flex items-center justify-between" style={{ marginBottom: 6 }}>
            <SkeletonBlock style={{ width: 90, height: 11 }} />
            <SkeletonBlock style={{ width: 70, height: 11 }} />
          </div>
          <SkeletonBlock style={{ width: '100%', height: 8, borderRadius: 4 }} />
        </section>

        {/* ── Quick actions skeleton ── */}
        <section className="su d3">
          <SkeletonBlock style={{ width: 100, height: 11, marginBottom: 10 }} />
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <SkeletonBlock key={i} style={{ height: 116 }} />
            ))}
          </div>
        </section>

        {/* ── Multiplayer skeleton ── */}
        <section className="su d4">
          <SkeletonBlock style={{ width: 100, height: 11, marginBottom: 10 }} />
          <SkeletonBlock style={{ height: 88 }} />
        </section>

        {/* ── Explore grid skeleton ── */}
        <section className="su d5">
          <SkeletonBlock style={{ width: 150, height: 11, marginBottom: 10 }} />
          <div className="grid grid-cols-2 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <SkeletonBlock key={i} style={{ height: 108 }} />
            ))}
          </div>
        </section>

        {/* ── Halo AI skeleton ── */}
        <section className="su" style={{ animationDelay: '0.35s', paddingBottom: 8 }}>
          <SkeletonBlock style={{ width: 70, height: 11, marginBottom: 10 }} />
          <SkeletonBlock style={{ height: 150 }} />
        </section>

        <style>{`@keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.45; } }`}</style>
      </div>
    )
  }

  if (error || !profile) {
    return (
      <div className="neu-card p-8 text-center max-w-[800px] mx-auto mt-8" style={{ color: 'var(--text-dim)' }}>
        Couldn't load your profile. Try refreshing.
      </div>
    )
  }

  const displayName = profile?.display_name || profile?.username || ''
  const _userXp   = profile?.xp ?? 0
  const _userTier = getUserRankTier(_userXp)
  const _nextTier = getNextRankTier(_userTier)
  const { pct: xpPct } = getRankProgress(_userXp)
  const streakInfo = getStreakMessage(profile?.streak ?? 0)

  const QUICK_ACTIONS: QuickAction[] = [
    { label: 'The Grove', sub: 'Water it',    to: '/play/water-the-tree', bg: 'linear-gradient(135deg,#7DB8D9,#4f8ef7)', icon: TreePine },
    { label: 'Mall',      sub: 'New drops',   to: '/mall',       bg: 'linear-gradient(135deg,var(--accent),var(--accent2))', icon: ShoppingBag, dot: hasNewMallItems },
    { label: 'Rank',      sub: 'Your standing',  to: '/ranks',    bg: 'linear-gradient(135deg,#00e5ff,#4f8ef7)', icon: Trophy },
  ]

  // Renders the glass-shine sweep for a card only when it's this card's turn
  const Glint = ({ cardKey }: { cardKey: string }) =>
    glintCard === cardKey ? <span className="dash-glint-sweep" aria-hidden="true" /> : null

  return (
    <div className="flex flex-col max-w-[800px] mx-auto">
      <PageOnboarding pageKey="dashboard" />

      {/* ── Welcome card ── */}
      <section className="su d1">
        <div
          className="neu-card ripple-wrap"
          style={{ padding: '22px 20px', position: 'relative', overflow: 'hidden' }}
          onClick={(e) => ripple(e)}
        >
          <div style={{ position: 'absolute', right: -30, top: -30, width: 160, height: 160, borderRadius: '50%', background: 'radial-gradient(circle, color-mix(in srgb, var(--accent) 10%, transparent) 0%, transparent 70%)', pointerEvents: 'none' }} />

          <div className="flex items-start justify-between gap-4">
            <div>
              {/* Smart greeting line */}
              <p style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 3 }}>{greeting.sub}</p>
              <h1 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', color: 'var(--text)', marginBottom: 8 }}>
                {greeting.line}
              </h1>

              {/* Streak — conditional message */}
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'var(--surface2)', borderRadius: 10, padding: '5px 10px' }}>
                <span style={{ fontSize: 13 }}>{streakInfo.emoji}</span>
                <span style={{ fontSize: 11, color: streakInfo.color, fontWeight: 600, lineHeight: 1.4 }}>
                  {streakInfo.message}
                </span>
              </div>
            </div>

            {/* Avatar — top-right, tap through to your profile. NO level badge */}
            <div style={{ flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <Link
                to="/you"
                aria-label="View your profile"
                onClick={(e) => ripple(e)}
                className="ripple-wrap"
                style={{
                  display: 'block',
                  width: 64,
                  height: 64,
                  borderRadius: 18,
                  boxShadow: '0 4px 16px rgba(155,109,255,0.32)',
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                <Avatar src={profile.avatar} name={displayName} size={64} radius={18} disabled style={{ background: 'linear-gradient(135deg, var(--purple), var(--blue))' }} />
              </Link>
              <div className="flex gap-2 mt-3">
                <span style={{ background: 'var(--surface2)', padding: '4px 8px', borderRadius: 8, fontSize: 11, color: 'var(--text-dim)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Flame size={11} style={{ color: 'var(--accent)' }} />
                  <strong style={{ color: 'var(--text)' }}>{profile.streak}</strong>
                </span>
                <span style={{ background: 'var(--surface2)', padding: '4px 8px', borderRadius: 8, fontSize: 11, color: 'var(--text-dim)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Zap size={11} style={{ color: 'var(--gold)' }} />
                  <strong style={{ color: 'var(--text)' }}>{profile.xp.toLocaleString()}</strong>
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── XP Bar ── */}
      <section className="su d2" style={{ marginTop: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-dim)', marginBottom: 6 }}>
          <span>Level {profile.level} · XP</span>
          <span>{_userXp.toLocaleString()} / {(_nextTier?.xpRequired ?? _userTier.xpRequired).toLocaleString()}</span>
        </div>
        <div className="xp-track">
          <div className="xp-fill" style={{ width: `${xpPct}%` }} />
        </div>
      </section>

      {/* ── Quick Actions ── */}
      <section className="su d3">
        <p className="section-label">Quick Actions</p>
        <div className="grid grid-cols-3 gap-2">
          {QUICK_ACTIONS.map((a, i) => {
            const Icon = a.icon
            const isRank = a.label === 'Rank'
            return (
              <Link key={a.label} to={a.to} onClick={(e) => ripple(e)} className="neu-card ripple-wrap" style={{ padding: '12px 8px', textAlign: 'center', cursor: 'pointer', position: 'relative', overflow: 'hidden' }}>
                <Glint cardKey={`qa-${i}`} />
                {isRank ? (
                  <div
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 10,
                      background: `color-mix(in srgb, ${_userTier.color} 18%, var(--surface2))`,
                      boxShadow: 'var(--elev-raise)',
                      margin: '0 auto 6px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <RankBadge tier={_userTier} size={26} />
                  </div>
                ) : (
                  <div style={{ width: 34, height: 34, borderRadius: 10, background: a.bg, boxShadow: 'var(--elev-raise)', color: '#fff', margin: '0 auto 6px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                    <Icon size={16} />
                    {a.dot && <NewDot />}
                  </div>
                )}
                <div style={{ fontSize: 10.5, fontWeight: 600, color: 'var(--text)', lineHeight: 1.2 }}>
                  {isRank ? _userTier.name : a.label}
                </div>
                <div style={{ fontSize: 9, color: 'var(--text-muted)', marginTop: 2, lineHeight: 1.2 }}>{a.sub}</div>
              </Link>
            )
          })}
        </div>
      </section>

      {/* ── Multiplayer ── */}
      <section className="su d4">
        <p className="section-label">Multiplayer</p>
        <Link
          to="/multiplayer"
          onClick={(e) => ripple(e)}
          className="neu-card ripple-wrap"
          style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 18, position: 'relative', overflow: 'hidden' }}
        >
          <Glint cardKey="multiplayer" />
          <div style={{ width: 52, height: 52, borderRadius: 16, flexShrink: 0, background: 'linear-gradient(135deg, var(--blue), var(--purple))', boxShadow: '0 4px 14px rgba(79,142,247,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Swords size={24} style={{ color: '#fff' }} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 4 }}>Join a Session</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>
              Play with friends
            </div>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {MINI_AVATAR_COLORS.slice(0, 5).map((bg, i) => (
                <div key={i} style={{ width: 26, height: 26, borderRadius: 8, background: bg, color: '#fff', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid var(--surface)', marginLeft: i === 0 ? 0 : -6 }}>
                  {String.fromCharCode(65 + i)}
                </div>
              ))}
            </div>
          </div>
          <ChevronRight size={20} style={{ color: 'var(--blue)', flexShrink: 0 }} />
        </Link>

        {/* Elimination Weekend sits under Multiplayer rather than in the
            Explore grid: it is a scheduled event with a sign-up deadline, so
            it needs the width to say which of its four states it's in. The
            card draws nothing at all until the status has loaded. */}
        <ChampionshipDashboardCard />
        <EliminationDashboardCard />
      </section>

      {/* ── Explore Chillverse ── */}
      <section className="su d5">
        <p className="section-label">Explore Chillverse</p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Watch',            desc: 'Trending videos & streams',    icon: Film,     iconBg: 'rgba(62,207,142,0.12)',  iconColor: '#3ecf8e', to: '/watch'           },
            { label: 'Battle Deck',      desc: 'Your cards and consumables',    icon: Swords,   iconBg: 'rgba(155,109,255,0.12)', iconColor: '#9b6dff', to: '/skill-tree'      },
            { label: 'Weekly Missions',  desc: 'Complete missions, earn XP',    icon: Sparkles, iconBg: 'rgba(245,197,66,0.12)',  iconColor: '#f5c542', to: '/weekly-missions' },
            { label: 'Wallet',           desc: 'Balance & Orbs',                icon: Wallet,   iconBg: 'rgba(52,211,153,0.12)', iconColor: '#34d399', to: '/wallet'          },
          ].map((tile, i) => {
            const Icon = tile.icon
            return (
              <Link key={tile.label} to={tile.to} onClick={(e) => ripple(e)} className="neu-card ripple-wrap" style={{ padding: 14, cursor: 'pointer', position: 'relative', overflow: 'hidden' }}>
                <Glint cardKey={`tile-${i}`} />
                <div style={{ width: 34, height: 34, borderRadius: 10, background: tile.iconBg, boxShadow: 'var(--elev-raise-sm)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 10, color: tile.iconColor }}>
                  <Icon size={16} />
                </div>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', marginBottom: 2 }}>{tile.label}</div>
                <div style={{ fontSize: 10, color: 'var(--text-muted)', lineHeight: 1.4 }}>{tile.desc}</div>
              </Link>
            )
          })}
        </div>

        {/* Artifacts — full-width, styled like the Multiplayer card */}
        <Link
          to="/artifacts"
          onClick={(e) => ripple(e)}
          className="neu-card ripple-wrap"
          style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 16, marginTop: 12, position: 'relative', overflow: 'hidden' }}
        >
          <Glint cardKey="artifacts" />
          <div style={{ width: 44, height: 44, borderRadius: 12, flexShrink: 0, background: 'rgba(239,68,68,0.12)', boxShadow: 'var(--elev-raise-sm)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ef4444' }}>
            <Fan size={20} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', marginBottom: 2 }}>Artifacts</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Collect &amp; explore relics</div>
          </div>
          <ChevronRight size={20} style={{ color: '#ef4444', flexShrink: 0 }} />
        </Link>
      </section>

      {/* ── Halo AI ── */}
      <section className="su" style={{ animationDelay: '0.35s', paddingBottom: 8 }}>
        <p className="section-label">Halo AI</p>
        <Link
          to="/halo"
          onClick={(e) => ripple(e)}
          className="neu-card ripple-wrap"
          style={{
            display: 'block', padding: 20, cursor: 'pointer',
            border: '1px solid rgba(155,109,255,0.18)',
            position: 'relative', overflow: 'hidden', textDecoration: 'none',
          }}
        >
          <Glint cardKey="halo" />
          <div style={{
            position: 'absolute', bottom: -20, right: -20,
            width: 140, height: 140, borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(155,109,255,0.15) 0%, transparent 70%)',
            pointerEvents: 'none',
          }} />
          <div style={{
            fontSize: 10, fontWeight: 700, color: 'var(--purple)',
            letterSpacing: 1, textTransform: 'uppercase',
            marginBottom: 6, display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <Sparkles size={11} /> {haloReleased ? 'AI COACH' : 'COMING SOON'}
          </div>
          <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text)', marginBottom: 4 }}>
            Ask Halo
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.5, marginBottom: 14 }}>
            {haloReleased
              ? 'Your personal guide — XP tips, rank strategy, missions, and more.'
              : "Your personal guide — XP tips, rank strategy, missions, and more. Not available yet."}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 44, height: 44, borderRadius: '50%', flexShrink: 0,
              background: 'conic-gradient(#9b6dff, #4f8ef7, #3ecf8e, #9b6dff)',
              boxShadow: '0 0 20px rgba(155,109,255,0.4)',
              animation: 'spin 4s linear infinite',
            }} />
            <div style={{
              flex: 1, background: 'var(--bg)', borderRadius: 10,
              padding: '10px 14px',
              border: '1px solid var(--border)',
              fontSize: 12, color: 'var(--text-muted)',
            }}>
              {haloReleased ? '"How do I rank up faster?"' : "Halo isn't taking questions yet — tap to get notified."}
            </div>
          </div>
        </Link>
      </section>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }

        /* Lazy random glass-glint sweep — plays once on whichever card is
           currently "it", then goes quiet until the next random turn. */
        .dash-glint-sweep {
          position: absolute;
          top: -50%;
          left: -60%;
          width: 42%;
          height: 200%;
          background: linear-gradient(115deg, transparent 0%, rgba(255,255,255,0.32) 45%, rgba(255,255,255,0.55) 50%, rgba(255,255,255,0.32) 55%, transparent 100%);
          transform: skewX(-18deg);
          animation: dashGlintSweep 1.4s ease-in-out forwards;
          pointer-events: none;
          z-index: 2;
        }
        @keyframes dashGlintSweep {
          0%   { left: -60%; opacity: 0; }
          10%  { opacity: 1; }
          55%  { opacity: 1; }
          100% { left: 130%; opacity: 0; }
        }
      `}</style>
    </div>
  )
        }
