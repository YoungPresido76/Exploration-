// src/features/drip/DripPicker.tsx
//
// "Your drip" — pick which earned effect to wear.
//
// The list is never filtered down to what you hold: an unheld tile is
// shown greyed with how it's earned, because "Chill Link top 3" sitting
// there dimmed tells you what to go and do, where an absent tile tells you
// nothing. What you no longer hold simply stops being selectable, and the
// server refuses it anyway.
import { useState } from 'react'
import { Check, X } from 'lucide-react'
import DripLayer from './DripLayer'
import { PirateHat } from '../../shared/components/Avatar'
import { DRIP_KEYS, DRIP_LABEL, DRIP_SOURCE, dripErrorMessage, useMyDrip, type DripKey } from './drip'
import { refreshPlunderHat } from '../games/plunderCrown'

export default function DripPicker({
  open, onClose, onSaved,
}: {
  open: boolean
  onClose: () => void
  onSaved?: (drip: DripKey | null) => void
}) {
  const { options, equipped, loading, equip } = useMyDrip()
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  if (!open) return null

  const heldCount = options.filter(o => o.held).length

  async function choose(drip: DripKey) {
    const held = options.find(o => o.drip === drip)?.held
    if (!held || saving) return
    setSaving(true)
    setError(null)
    try {
      // Tapping what you already wear takes it off, so there is a way back
      // to plain without a separate "none" tile.
      const next = equipped === drip ? null : drip
      await equip(next)
      // The hat rides on Avatar, which reads a cached module-level store —
      // without this it keeps the old answer for up to five minutes and
      // your own face in the corner doesn't change.
      refreshPlunderHat()
      onSaved?.(next)
    } catch (e) {
      setError(dripErrorMessage(e))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div
      className="sheet-or-modal sheet-or-modal-over-dock"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050, display: 'flex', alignItems: 'flex-end',
        background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(3px)',
      }}
    >
      {/* Portalled or not, taps inside a sheet opened FROM the profile
          modal bubble up the React tree to its backdrop handler and close
          the profile underneath. */}
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: 'var(--surface2)', borderRadius: '22px 22px 0 0',
          padding: '20px 18px 26px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)' }}>Your drip</p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
              {loading ? 'Checking what you hold…' : `Pick one to wear. ${heldCount} held.`}
            </p>
          </div>
          <button
            type="button" onClick={onClose} aria-label="Close"
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}
          >
            <X size={20} />
          </button>
        </div>

        {error && (
          <p style={{ fontSize: 12, color: '#ff5470', marginTop: 10 }}>{error}</p>
        )}

        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 16,
        }}>
          {DRIP_KEYS.map(key => {
            const held = options.find(o => o.drip === key)?.held ?? false
            const worn = equipped === key
            return (
              <button
                key={key}
                type="button"
                onClick={() => choose(key)}
                disabled={!held}
                style={{
                  position: 'relative', textAlign: 'center', cursor: held ? 'pointer' : 'default',
                  background: 'var(--surface)', borderRadius: 14,
                  border: `1px solid ${worn ? '#ffc53d' : 'var(--border)'}`,
                  boxShadow: worn ? '0 0 0 1px rgba(255,197,61,.45)' : 'none',
                  padding: '26px 8px 12px', opacity: held ? 1 : 0.45,
                }}
              >
                <div style={{ position: 'relative', width: 44, height: 44, margin: '0 auto 10px' }}>
                  <div style={{
                    position: 'absolute', inset: 0, borderRadius: '50%',
                    background: 'linear-gradient(140deg,#5b6cff,#b06dff)',
                  }} />
                  {/* The hat belongs to Avatar, which isn't here — a swatch
                      is not an avatar — so this tile draws it directly. */}
                  {key === 'pirate' ? <PirateHat size={44} /> : (
                  <DripLayer
                    drip={key}
                    size={44}
                    portrait={
                      <div style={{
                        position: 'absolute', inset: 3, borderRadius: '50%',
                        background: 'linear-gradient(140deg,#5b6cff,#b06dff)',
                      }} />
                    }
                  />
                  )}
                </div>
                <p style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)' }}>
                  {DRIP_LABEL[key]}
                </p>
                <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 2 }}>
                  {held ? DRIP_SOURCE[key] : `${DRIP_SOURCE[key]} — not yet`}
                </p>
                <p style={{
                  fontSize: 10, marginTop: 5, height: 13, color: '#ffc53d',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3,
                }}>
                  {worn && <><Check size={11} /> Wearing</>}
                </p>
              </button>
            )
          })}
        </div>

        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 14, lineHeight: 1.5 }}>
          Lose the spot and it comes off by itself. The pirate hat is the only
          one that follows you off your profile — chat, feed, everywhere. The
          PvP Boss orbit isn't in here; that one shows on top of whatever
          you're wearing.
        </p>
      </div>
    </div>
  )
}
