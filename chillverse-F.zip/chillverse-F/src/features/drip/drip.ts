// src/features/drip/drip.ts
//
// "Drip" is the earned-effect slot: crown, frozen, jelly. You can hold
// several and wear one.
//
// Nothing about who holds what is stored. Every holder set is recomputed
// server-side on read from the thing that earns it — the XP leaderboard,
// the Chill Link scores, the elimination survivors — so losing the
// position takes the effect off by itself. No cron, no counter, nothing
// that can drift out of step with the board it came from. Same posture as
// the Kill Board, and the same re-derivation trick 0168a used for a
// lapsed Void membership.
//
// The PvP Boss orbit is deliberately NOT part of this. It rides the
// pvp_boss badge and stacks on top of whatever is worn — a boss wearing
// frozen shows both.
//
// The Plunder pirate hat IS part of it, as of 0181. It used to be an
// Avatar decoration driven straight off game_crowns, which meant it landed
// on the same forehead as the crown and there was no way to take it off.
// One slot holds one thing, so putting it here makes that clash impossible
// rather than merely tidy. Its 24h grace is unchanged and still lives in
// game_crowns; only the wearing is new.
import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'

export type DripKey = 'crown' | 'frozen' | 'jelly' | 'pirate'

export const DRIP_KEYS: DripKey[] = ['crown', 'frozen', 'jelly', 'pirate']

export const DRIP_LABEL: Record<DripKey, string> = {
  crown: 'Crown',
  frozen: 'Frozen',
  jelly: 'Jelly',
  pirate: 'Pirate hat',
}

/** How each one is earned — shown under the tile in the picker. */
export const DRIP_SOURCE: Record<DripKey, string> = {
  crown: 'Number one overall',
  frozen: 'Elimination survivor',
  jelly: 'Chill Link top 3',
  pirate: 'Plunder champion',
}

export interface DripOption {
  drip: DripKey
  held: boolean
}

export function isDripKey(value: string | null | undefined): value is DripKey {
  return value === 'crown' || value === 'frozen' || value === 'jelly' || value === 'pirate'
}

/**
 * What the signed-in player currently holds, and what they're wearing.
 *
 * `equipped` comes off profiles directly rather than from get_public_profile
 * so the picker can show a selection the viewer has since stopped
 * qualifying for — the tile greys out instead of silently unselecting.
 */
export function useMyDrip() {
  const [options, setOptions] = useState<DripOption[]>([])
  const [equipped, setEquipped] = useState<DripKey | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    const [{ data: opts }, { data: auth }] = await Promise.all([
      supabase.rpc('my_drip_options'),
      supabase.auth.getUser(),
    ])
    setOptions(((opts ?? []) as DripOption[]).filter(o => isDripKey(o.drip)))

    const uid = auth?.user?.id
    if (uid) {
      const { data: row } = await supabase
        .from('profiles').select('equipped_drip').eq('id', uid).maybeSingle()
      const value = (row as { equipped_drip: string | null } | null)?.equipped_drip
      setEquipped(isDripKey(value) ? value : null)
    }
    setLoading(false)
  }, [])

  useEffect(() => { load() }, [load])

  /**
   * profiles carries a column-level UPDATE allow-list for `authenticated`
   * and equipped_drip is not on it (same position as profile_ui_skin and
   * holo_profile_enabled), so the RPC is the only write path. It also
   * re-checks the holding server-side, which is why a stale tile can't be
   * used to equip something you've been passed on.
   */
  const equip = useCallback(async (drip: DripKey | null) => {
    const previous = equipped
    setEquipped(drip)
    const { error } = await supabase.rpc('set_equipped_drip', { p_drip: drip })
    if (error) {
      setEquipped(previous)
      throw error
    }
  }, [equipped])

  return { options, equipped, loading, equip, reload: load }
}

export function dripErrorMessage(error: unknown): string {
  const message = (error as { message?: string })?.message ?? ''
  if (message.includes('drip_not_held')) return "You don't hold that any more."
  if (message.includes('not_authenticated')) return 'Sign in first.'
  return 'Could not save that. Try again.'
}
