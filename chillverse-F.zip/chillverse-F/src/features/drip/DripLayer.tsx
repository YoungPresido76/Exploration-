// src/features/drip/DripLayer.tsx
//
// Draws whichever drip a profile is wearing around its portrait.
//
// Mounting rules, same as BossOrbit:
//   - The parent must be position:relative and sized to the avatar.
//   - On the full profile pages this must be a SIBLING of the
//     [data-cv-part="portrait"] div, never a child — several Void skins
//     square off `[data-cv-part="portrait"] > *`.
//
// Two of the three sit in FRONT of the portrait (crown, ice) and one
// REPLACES it (jelly, which has to deform the picture itself). That is why
// jelly takes a `portrait` render prop: it can't wrap something it doesn't
// own. Callers that pass nothing simply get no jelly, never a broken one.
import './drip.css'
import type { DripKey } from './drip'
import BossOrbit from '../pvp/BossOrbit'

export default function DripLayer({
  drip, size, portrait,
}: {
  /** What this profile is wearing. Null renders nothing. */
  drip: DripKey | null | undefined
  /** The avatar's size in px — every measurement scales off it. */
  size: number
  /**
   * The portrait itself, for jelly only. Jelly wobbles the picture rather
   * than a shell around it, so it needs the image inside its own wrapper.
   */
  portrait?: React.ReactNode
}) {
  if (!drip) return null

  // The pirate hat is drawn by Avatar, not here. It is the one drip that
  // travels outside the profile — chat, feed, leaderboards — so its owner
  // has to be the component that renders in all those places. Drawing it
  // here too would put two hats on the same head on every profile card.
  if (drip === 'pirate') return null

  const vars = { ['--sz' as string]: `${size}px` } as React.CSSProperties

  if (drip === 'crown') {
    return (
      <div className="cv-drip" style={vars} aria-hidden="true">
        <span className="cv-crown-gleam" />
        <span className="cv-spark" style={{ left: '-6%', top: '2%' }} />
        <span className="cv-spark" style={{ right: '-4%', top: '18%', animationDelay: '1.3s' }} />
        <div className="cv-crown">
          <span className="cv-crown-body" />
          <span className="cv-crown-band" />
          <u className="l" /><u className="c" /><u className="r" />
          <i className="p1" /><i className="p2" />
        </div>
      </div>
    )
  }

  if (drip === 'frozen') {
    return (
      <div className="cv-drip" style={vars} aria-hidden="true">
        <span className="cv-ice-slab" />
        <div className="cv-ice">
          <div className="cv-ice-plane"><i /><i /><i /><i /></div>
          <span className="cv-ice-caustic" />
          <span className="cv-ice-crack" />
          <span className="cv-ice-crack b" />
          <span className="cv-ice-frost" />
          <span className="cv-ice-shine" />
        </div>
        <span className="cv-ice-vapour" />
      </div>
    )
  }

  if (!portrait) return null
  return (
    <div className="cv-drip" style={{ ...vars, pointerEvents: 'auto' }}>
      <div className="cv-jelly">
        {portrait}
        <span className="cv-jelly-gloss" aria-hidden="true" />
      </div>
    </div>
  )
}

/**
 * One portrait, dressed.
 *
 * Every call site passes its avatar node once and gets the right stacking
 * for whatever is worn: the crown and the ice sit in FRONT of the picture,
 * jelly REPLACES it (it has to own the picture to deform it), and the boss
 * orbit rides on top of all of them.
 *
 * Keeping the order here rather than at each call site is deliberate —
 * this markup is repeated on the preview sheet and both profile pages, and
 * the three copies have drifted before.
 */
export function DrippedPortrait({
  drip, size, boss, children,
}: {
  drip: DripKey | null | undefined
  size: number
  /** Holds the pvp_boss badge — stacks with anything worn. */
  boss?: boolean
  children: React.ReactNode
}) {
  const vars = { ['--sz' as string]: `${size}px` } as React.CSSProperties

  if (drip === 'jelly') {
    return (
      <>
        <div className="cv-drip" style={{ ...vars, pointerEvents: 'auto' }}>
          <div className="cv-jelly">
            {children}
            <span className="cv-jelly-gloss" aria-hidden="true" />
          </div>
        </div>
        <BossOrbit active={!!boss} inset={14} />
      </>
    )
  }

  if (drip === 'frozen') {
    return (
      <>
        <span className="cv-ice-slab" style={vars} aria-hidden="true" />
        <div className="cv-ice-chill">{children}</div>
        <span className="cv-ice-refract" aria-hidden="true">{children}</span>
        <DripLayer drip="frozen" size={size} />
        <BossOrbit active={!!boss} inset={18} />
      </>
    )
  }

  return (
    <>
      {children}
      <DripLayer drip={drip} size={size} />
      <BossOrbit active={!!boss} inset={14} />
    </>
  )
}
