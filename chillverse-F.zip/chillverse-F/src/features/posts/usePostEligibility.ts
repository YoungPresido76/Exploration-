// src/features/posts/usePostEligibility.ts
import { useEffect, useState } from 'react'
import { useAuth } from '../auth/useAuth'
import { checkPostingEligibility } from './posts'
import type { PostingEligibility } from './types'

interface UsePostEligibilityState {
  eligibility: PostingEligibility | null
  loading: boolean
}

/**
 * Only queried when the user actually opens the composer (see Composer.tsx) —
 * viewing the feed itself is never gated.
 */
export function usePostEligibility(active: boolean): UsePostEligibilityState {
  const { user } = useAuth()
  const [eligibility, setEligibility] = useState<PostingEligibility | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!active || !user) return
    let alive = true
    setLoading(true)
    checkPostingEligibility(user.id).then(result => {
      if (alive) {
        setEligibility(result)
        setLoading(false)
      }
    })
    return () => { alive = false }
  }, [active, user])

  return { eligibility, loading }
}

/** Short reason string for the locked state — e.g. "Locked · Profile pic" */
export function lockedReasonText(e: PostingEligibility): string {
  const missing: string[] = []
  if (!e.has_profile_pic) missing.push('Profile pic')
  if (!e.account_age_ok) missing.push('Account too new')
  return missing.length ? `Locked · ${missing.join(' · ')}` : 'Locked'
}

/** Why the image button is greyed out, for the toast. */
export const MEDIA_LOCKED_MESSAGE =
  "Oops — photos are for verified accounts. Void members can add them too."

export function mediaLockedReason(e: PostingEligibility | null): string {
  if (!e) return MEDIA_LOCKED_MESSAGE
  if (!e.eligible) return lockedReasonText(e)
  return MEDIA_LOCKED_MESSAGE
}
