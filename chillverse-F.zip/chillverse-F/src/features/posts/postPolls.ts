// src/features/posts/postPolls.ts
//
// Data layer for polls attached to a feed post (migration 0131). Separate
// tables from the Global Chat polls in src/features/chat/polls.ts — those
// are keyed on room_id, which a feed post doesn't have. Same shape of API
// though: every mutation goes through a SECURITY DEFINER RPC, and this
// file is the typed wrappers plus one hydration helper for rendering.
//
// Unlike chat polls there is no hide-results mode: counts are public the
// moment a vote lands. The post's author is the only one who gets told
// anything extra — vote_post_poll fires a "Poll updated" notification at
// them, collapsed while unread.
import { supabase } from '../../shared/lib/supabase'

export type PostPollVoteMode = 'single' | 'multi'

export interface PostPollOption {
  id: string
  label: string
  position: number
}

export interface PostPollData {
  id: string
  post_id: string
  question: string
  vote_mode: PostPollVoteMode
  /** null = this poll never ends. */
  closes_at: string | null
  options: PostPollOption[]
  /** option_id → vote count. Always trustworthy — results are never hidden. */
  voteCounts: Record<string, number>
  /** Distinct people who voted, NOT the number of vote rows. In a
   *  multi-select poll one person can tick three options, so counting rows
   *  would make the bars add up past 100% and overstate turnout. This is
   *  the denominator for the bars and the number shown on the card. */
  voterCount: number
  /** option ids the current viewer has voted for, if any. */
  myVotes: string[]
  closed: boolean
}

/** What the Composer collects before the post itself exists. */
export interface NewPostPoll {
  question: string
  options: string[]
  voteMode: PostPollVoteMode
  /** null = never ends. */
  durationHours: number | null
}

function friendlyPollError(error: { message?: string } | null): string | null {
  if (!error) return null
  const msg = error.message || ''
  if (msg.includes('CV_POLL_FORBIDDEN')) return "You don't have permission to do that."
  if (msg.includes('CV_POLL_DUPLICATE')) return 'That post already has a poll.'
  if (msg.includes('CV_POLL_NOT_FOUND')) return 'That poll could not be found.'
  if (msg.includes('CV_POLL_CLOSED')) return 'This poll has ended.'
  if (msg.includes('CV_POLL_VALIDATION:')) {
    return msg.split('CV_POLL_VALIDATION:')[1]?.trim() || 'That poll setting is invalid.'
  }
  return 'Something went wrong. Please try again.'
}

export async function createPostPoll(postId: string, poll: NewPostPoll): Promise<{ pollId: string | null; error: string | null }> {
  const { data, error } = await supabase.rpc('create_post_poll', {
    p_post_id: postId,
    p_question: poll.question,
    p_options: poll.options,
    p_vote_mode: poll.voteMode,
    p_duration_hours: poll.durationHours,
  })
  return { pollId: (data as string | null) ?? null, error: friendlyPollError(error) }
}

/** Replaces the caller's existing votes on this poll rather than adding to
 *  them — changing your mind is the same call in both vote modes. */
export async function votePostPoll(pollId: string, optionIds: string[]): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('vote_post_poll', { p_poll_id: pollId, p_option_ids: optionIds })
  return { error: friendlyPollError(error) }
}

/** Which of these posts have a poll — one query for a whole feed page, so
 *  PostCard doesn't have to probe per card. Returns post_id → poll_id. */
export async function fetchPollIdsForPosts(postIds: string[]): Promise<Record<string, string>> {
  if (postIds.length === 0) return {}
  const { data, error } = await supabase
    .from('post_polls')
    .select('id, post_id')
    .in('post_id', postIds)
  if (error) {
    console.error('fetchPollIdsForPosts error:', error)
    return {}
  }
  const out: Record<string, string> = {}
  for (const row of data ?? []) out[row.post_id] = row.id
  return out
}

export async function fetchPostPoll(pollId: string, myId: string | null): Promise<PostPollData | null> {
  const { data: poll } = await supabase.from('post_polls').select('*').eq('id', pollId).maybeSingle()
  if (!poll) return null

  const [{ data: options }, { data: votes }] = await Promise.all([
    supabase.from('post_poll_options').select('id, label, position').eq('poll_id', pollId).order('position'),
    supabase.from('post_poll_votes').select('option_id, user_id').eq('poll_id', pollId),
  ])

  const voteCounts: Record<string, number> = {}
  const myVotes: string[] = []
  const voters = new Set<string>()
  for (const v of votes ?? []) {
    voteCounts[v.option_id] = (voteCounts[v.option_id] ?? 0) + 1
    voters.add(v.user_id)
    if (myId && v.user_id === myId) myVotes.push(v.option_id)
  }

  return {
    id: poll.id,
    post_id: poll.post_id,
    question: poll.question,
    vote_mode: poll.vote_mode,
    closes_at: poll.closes_at,
    options: options ?? [],
    voteCounts,
    voterCount: voters.size,
    myVotes,
    closed: poll.closes_at !== null && new Date(poll.closes_at) <= new Date(),
  }
}
