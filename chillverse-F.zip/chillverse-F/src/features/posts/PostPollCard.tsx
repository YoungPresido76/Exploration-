// src/features/posts/PostPollCard.tsx
//
// The poll attached to a feed post: live bars, voting, and a countdown.
// Deliberately close in look to chat's PollMessage so a poll reads the
// same wherever you meet it, but the rules differ in two ways:
//
//   • Results are never hidden. Everyone watches the numbers move.
//   • Counts update live via Realtime on post_poll_votes, so a vote from
//     someone else nudges the bars without a refresh. That's the "number
//     boosts" everyone sees; the author separately gets a notification.
//
// Nobody can end a poll early — a poll either runs to its close time or
// runs forever. Deleting the post takes the poll with it.
import { useCallback, useEffect, useState } from 'react'
import { BarChart3 } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { fetchPostPoll, votePostPoll, type PostPollData } from './postPolls'

/** Close times are always in the future while a poll is open, so the feed's
 *  elapsed-time formatters (which expect a past timestamp) all collapse to
 *  "now" here. This is countdown formatting instead. */
function formatCloseTime(iso: string): string {
  const diff = new Date(iso).getTime() - Date.now()
  if (diff <= 0) return 'now'
  if (diff < 3600000) return `${Math.max(1, Math.round(diff / 60000))}m`
  if (diff < 86400000) return `${Math.round(diff / 3600000)}h`
  return `${Math.round(diff / 86400000)}d`
}

export default function PostPollCard({ pollId, myId }: { pollId: string; myId: string | null }) {
  const [poll, setPoll] = useState<PostPollData | null>(null)
  const [loading, setLoading] = useState(true)
  const [pendingMulti, setPendingMulti] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    const data = await fetchPostPoll(pollId, myId)
    setPoll(data)
    setPendingMulti(data?.myVotes ?? [])
    setLoading(false)
  }, [pollId, myId])

  useEffect(() => { load() }, [load])

  // Live counts. One channel per poll card — a feed page rarely holds more
  // than a couple of polls, and the filter keeps each subscription to the
  // rows that actually belong to this one.
  useEffect(() => {
    const channel = supabase
      .channel(`post-poll-${pollId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'post_poll_votes', filter: `poll_id=eq.${pollId}` },
        () => { load() },
      )
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [pollId, load])

  if (loading) {
    return (
      <div style={{ marginTop: 10, padding: '12px 14px', borderRadius: 14, background: 'var(--surface2)', fontSize: 12.5, color: 'var(--text-muted)' }}>
        Loading poll…
      </div>
    )
  }
  if (!poll) return null

  const { closed } = poll
  const canVote = !!myId && !closed

  async function handleSingleVote(optionId: string) {
    if (!poll || !canVote || busy) return
    setBusy(true); setError(null)
    const { error: err } = await votePostPoll(poll.id, [optionId])
    setBusy(false)
    if (err) { setError(err); return }
    load()
  }

  function toggleMulti(optionId: string) {
    if (!canVote || busy) return
    setPendingMulti(prev => prev.includes(optionId) ? prev.filter(id => id !== optionId) : [...prev, optionId])
  }

  async function submitMulti() {
    if (!poll || !canVote || busy || pendingMulti.length === 0) return
    setBusy(true); setError(null)
    const { error: err } = await votePostPoll(poll.id, pendingMulti)
    setBusy(false)
    if (err) { setError(err); return }
    load()
  }

  const multiChanged = poll.vote_mode === 'multi' &&
    (pendingMulti.length !== poll.myVotes.length || pendingMulti.some(id => !poll.myVotes.includes(id)))
  const multiDisabled = busy || pendingMulti.length === 0 || !multiChanged

  return (
    <div style={{ marginTop: 10, padding: '12px 14px', borderRadius: 14, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
        <BarChart3 size={13} style={{ color: 'var(--accent)', flexShrink: 0 }} />
        <span style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.3 }}>
          {closed ? 'Poll closed' : 'Poll'} · {poll.vote_mode === 'multi' ? 'pick any number' : 'pick one'}
        </span>
      </div>

      <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 10, lineHeight: 1.35, color: 'var(--text)' }}>
        {poll.question}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {poll.options.map(opt => {
          const count = poll.voteCounts[opt.id] ?? 0
          const pct = poll.voterCount > 0 ? Math.round((count / poll.voterCount) * 100) : 0
          const selected = poll.vote_mode === 'single' ? poll.myVotes.includes(opt.id) : pendingMulti.includes(opt.id)
          return (
            <button
              key={opt.id}
              type="button"
              disabled={!canVote || busy}
              onClick={() => poll.vote_mode === 'single' ? handleSingleVote(opt.id) : toggleMulti(opt.id)}
              style={{
                position: 'relative', textAlign: 'left', padding: '8px 10px', borderRadius: 9, overflow: 'hidden',
                border: selected ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                background: 'var(--surface)', cursor: canVote && !busy ? 'pointer' : 'default',
                fontFamily: 'inherit', color: 'var(--text)',
              }}
            >
              <div style={{
                position: 'absolute', inset: 0, width: `${pct}%`,
                background: 'color-mix(in srgb, var(--accent) 14%, transparent)', transition: 'width 0.3s',
              }} />
              <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <span style={{ fontSize: 13, fontWeight: selected ? 700 : 500 }}>{selected ? '✓ ' : ''}{opt.label}</span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)', flexShrink: 0 }}>{pct}% ({count})</span>
              </div>
            </button>
          )
        })}
      </div>

      {poll.vote_mode === 'multi' && canVote && (
        <button
          type="button"
          onClick={submitMulti}
          disabled={multiDisabled}
          style={{
            marginTop: 8, width: '100%', padding: '7px 0', borderRadius: 8, border: 'none',
            background: 'var(--accent)', color: '#fff', fontSize: 12.5, fontWeight: 700,
            cursor: multiDisabled ? 'default' : 'pointer', opacity: multiDisabled ? 0.5 : 1,
          }}
        >
          {poll.myVotes.length > 0 ? 'Update vote' : 'Vote'}
        </button>
      )}

      {error && <div style={{ color: 'var(--red)', fontSize: 11, marginTop: 6 }}>{error}</div>}

      <div style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 9 }}>
        {poll.voterCount} vote{poll.voterCount === 1 ? '' : 's'}
        {' · '}
        {closed ? 'Ended' : poll.closes_at ? `Closes in ${formatCloseTime(poll.closes_at)}` : 'No end date'}
      </div>
    </div>
  )
}
