// src/features/posts/PremiumAdCard.tsx
//
// In-feed "Chillverse Premium" ad card, styled to match the visual grammar
// of a real post (avatar/name/handle row) so it doesn't read as a jarring
// popup — same idea as a sponsored post on other feeds. Shown once per
// feed render, a few posts down (see PREMIUM_AD_AFTER_POST in Feed.tsx),
// and only to players who aren't Pro yet.
//
// The preview inside isn't a fake banner-color swap — it's a genuine
// miniature render of the viewer's OWN profile (their real avatar +
// display name) dressed in a real Void UI skin, using the exact same
// tokens/textures profile pages use (see shared/lib/profileSkins.ts and
// VoidUiChangerSheet.tsx's SkinPreview, which this mirrors). Tapping
// "Tap for another look" shuffles to a different random skin so people
// get a feel for how different the skins actually look, not just a
// recolor. Tapping anywhere else on the card goes to /pro.
//
// Deliberately has no "..." menu — this ad can't be dismissed/muted like
// a normal post, only scrolled past.
import { useState, useRef } from 'react'
import type React from 'react'
import { useNavigate } from 'react-router-dom'
import { Sparkles, Shuffle } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { ripple } from '../../shared/lib/ripple'
import Avatar from '../../shared/components/Avatar'
import VerifiedBadge from '../../shared/components/VerifiedBadge'
import ProfileSkinStyles from '../profile/ProfileSkinStyles'
import {
  PROFILE_SKINS, profileSkinStyle, profileSkinOverlayStyle, profileSkinAttr,
  type ProfileSkinId,
} from '../../shared/lib/profileSkins'

// House account for the ad itself — same badge treatment as any other
// official account (profiles.is_official), just hardcoded here since this
// card isn't backed by a real post row.
const AD_AVATAR = 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/4bedfbaf83cb0de06fc80eff704c7762.jpg'

const PERKS: { icon: string; label: string }[] = [
  { icon: '🏅', label: 'Evolving badge' },
  { icon: '👽', label: 'Void UI changer' },
  { icon: '🎨', label: 'Full profile' },
]

/** Miniature version of the viewer's own profile, skinned with `skinId`. Mirrors VoidUiChangerSheet's SkinPreview 1:1 so it never drifts from the real thing. */
function MiniProfilePreview({ skinId, name, avatar, bannerUrl }: {
  skinId: ProfileSkinId
  name: string
  avatar: string | null | undefined
  bannerUrl: string | null | undefined
}) {
  const overlay = profileSkinOverlayStyle(skinId)

  return (
    <div
      aria-hidden
      data-cv-skin={profileSkinAttr(skinId)}
      style={{
        ...profileSkinStyle(skinId, 'var(--bg)'),
        backgroundAttachment: 'scroll',
        position: 'relative',
        height: 168, borderRadius: 14, overflow: 'hidden',
      }}
    >
      {overlay && <div style={overlay} />}

      {/* Banner — the viewer's own equipped banner if they have one, else
          the skin's own accent gradient (still authentic to the skin). */}
      <div style={{
        height: 46, position: 'relative',
        background: bannerUrl ? `center/cover no-repeat url(${bannerUrl})` : 'linear-gradient(120deg, var(--accent), var(--accent2))',
      }} />

      <div style={{ padding: '0 14px', marginTop: -18, position: 'relative', zIndex: 1 }}>
        {/* Avatar + name — the viewer's real pfp + display name */}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 9 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 'var(--radius-sm)', overflow: 'hidden',
            border: '2px solid var(--bg)', flexShrink: 0, background: 'var(--surface3)',
          }}>
            <Avatar src={avatar} name={name} size={32} radius={0} />
          </div>
          <div style={{ paddingBottom: 3 }}>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', lineHeight: 1.1 }}>{name}</div>
            <div style={{ fontSize: 9.5, color: 'var(--text-muted)' }}>Void member</div>
          </div>
        </div>

        {/* Stat cards — carry the skin's surface texture, the part a flat
            color swap can't fake */}
        <div style={{ display: 'flex', gap: 7, marginTop: 11 }}>
          {['128', '64', '31'].map((v, i) => (
            <div key={i} style={{
              flex: 1, borderRadius: 'var(--radius-sm)', padding: '7px 4px', textAlign: 'center',
              background: 'var(--surface)', border: '1px solid var(--border)',
            }}>
              <div style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--text)' }}>{v}</div>
            </div>
          ))}
        </div>

        {/* A real .btn-primary, so the button treatment is honest too */}
        <div style={{ display: 'flex', gap: 7, marginTop: 9, alignItems: 'center' }}>
          <div className="btn-primary" style={{
            flex: 1, padding: '7px 0', textAlign: 'center', fontSize: 9.5,
            fontWeight: 800, borderRadius: 'var(--radius-sm)',
          }}>
            Follow
          </div>
          <div style={{
            width: 54, padding: '7px 0', textAlign: 'center', fontSize: 9.5,
            fontWeight: 700, color: 'var(--text)', borderRadius: 'var(--radius-sm)',
            background: 'var(--surface2)', border: '1px solid var(--border-strong)',
          }}>
            Share
          </div>
        </div>
      </div>
    </div>
  )
}

export default function PremiumAdCard() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { profile } = useProfile()
  const [skinIndex, setSkinIndex] = useState(() => Math.floor(Math.random() * PROFILE_SKINS.length))
  const [spinning, setSpinning] = useState(false)
  const spinTimeout = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Never shown to Pro members, and never before we actually know the
  // viewer isn't one (avoids a flash for Pro users while profile loads).
  if (!user || !profile || profile.is_pro) return null

  const skin = PROFILE_SKINS[skinIndex]
  const displayName = profile.display_name || profile.username || 'You'

  function shuffleSkin(e: React.MouseEvent<HTMLButtonElement>) {
    e.stopPropagation()
    ripple(e)
    setSpinning(true)
    if (spinTimeout.current) clearTimeout(spinTimeout.current)
    spinTimeout.current = setTimeout(() => setSpinning(false), 420)
    setSkinIndex(prev => {
      if (PROFILE_SKINS.length <= 1) return prev
      let next = prev
      while (next === prev) next = Math.floor(Math.random() * PROFILE_SKINS.length)
      return next
    })
  }

  function goToPro() {
    navigate('/pro')
  }

  return (
    <div
      className="neu-card ripple-wrap"
      onClick={goToPro}
      style={{ padding: 14, marginBottom: 12, cursor: 'pointer' }}
    >
      <ProfileSkinStyles />

      {/* Ad poster header — same grammar as a normal post's author row */}
      <div style={{ display: 'flex', gap: 10 }}>
        <Avatar src={AD_AVATAR} name="Chillverse Premium" size={38} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
              Chillverse Premium <VerifiedBadge size={14} />
            </div>
            <span style={{
              fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)',
              border: '1px solid var(--border)', background: 'var(--surface2)',
              padding: '2px 8px', borderRadius: 20, flexShrink: 0,
            }}>
              Ad
            </span>
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>@chillverse_premium</div>
        </div>
      </div>

      {/* Headline */}
      <div style={{ margin: '10px 0 12px' }}>
        <div style={{ fontSize: 15.5, fontWeight: 800, color: 'var(--text)', marginBottom: 2 }}>
          Pro looks good on you 👑
        </div>
        <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>
          This is your profile — Void UI style.
        </div>
      </div>

      {/* Live mini preview of the viewer's own profile, in a random Void skin */}
      <div style={{ border: '1px solid var(--border-strong)', borderRadius: 16, padding: 8, background: 'var(--surface)' }}>
        <MiniProfilePreview
          skinId={skin.id}
          name={displayName}
          avatar={profile.avatar}
          bannerUrl={profile.banner_url}
        />

        {/* Perk tags */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 10 }}>
          {PERKS.map(p => (
            <span key={p.label} style={{
              display: 'flex', alignItems: 'center', gap: 5,
              fontSize: 11, fontWeight: 700, color: 'var(--accent)',
              background: 'var(--accent-soft)', border: '1px solid var(--border-strong)',
              padding: '5px 9px', borderRadius: 20,
            }}>
              <span>{p.icon}</span>{p.label}
            </span>
          ))}
        </div>

        {/* Single nudge button — shuffles to a random different skin */}
        <button
          type="button"
          onClick={shuffleSkin}
          className="btn-secondary ripple-wrap"
          style={{
            width: '100%', marginTop: 10, padding: '9px 0', borderRadius: 12,
            fontSize: 12.5, fontWeight: 800, display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: 7,
          }}
        >
          <Shuffle size={13} style={{ transition: 'transform 380ms ease', transform: spinning ? 'rotate(180deg)' : 'rotate(0deg)' }} />
          Tap for another look
        </button>
      </div>

      {/* Footer CTA */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginTop: 12, padding: '10px 12px', borderRadius: 12,
        background: 'var(--surface2)', border: '1px solid var(--border)',
      }}>
        <div>
          <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)' }}>Chillverse Premium</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>From ₦1,400/mo · Orbit &amp; Void</div>
        </div>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); ripple(e); goToPro() }}
          className="btn-primary"
          style={{ padding: '8px 16px', borderRadius: 20, fontSize: 12, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 5 }}
        >
          <Sparkles size={12} /> View plans
        </button>
      </div>
    </div>
  )
}
