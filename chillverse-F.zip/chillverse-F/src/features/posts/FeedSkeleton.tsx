// src/features/posts/FeedSkeleton.tsx

// Shaped like PostCard (avatar + name row, a couple text lines, an image
// block) so the layout doesn't jump when the real posts land.
function SkeletonCard() {
  const bar = (width: string, height = 10) => ({
    width, height, borderRadius: 6, background: 'var(--surface2)',
  })

  return (
    <div className="neu-card cv-skeleton-pulse" style={{ padding: 16, marginBottom: 12 }}>
      <div className="flex items-center gap-2" style={{ marginBottom: 12 }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--surface2)', flexShrink: 0 }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={bar('120px')} />
          <div style={bar('70px', 8)} />
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
        <div style={bar('100%')} />
        <div style={bar('80%')} />
      </div>
      <div style={{ width: '100%', height: 140, borderRadius: 12, background: 'var(--surface2)' }} />
    </div>
  )
}

export default function FeedSkeleton() {
  return (
    <div>
      {[0, 1, 2].map(i => <SkeletonCard key={i} />)}
      <style>{`
        @keyframes cv-skeleton-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.55; } }
        .cv-skeleton-pulse { animation: cv-skeleton-pulse 1.3s ease-in-out infinite; }
      `}</style>
    </div>
  )
}
