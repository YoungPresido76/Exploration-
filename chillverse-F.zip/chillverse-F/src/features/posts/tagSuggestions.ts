// src/features/posts/tagSuggestions.ts
import { supabase } from '../../shared/lib/supabase'
import { getAllAchievements, getPlayerAchievements } from '../achievements/achievements'
import { getUserRankTier } from '../profile/ranks'
import { getAllArtifacts, getPlayerArtifacts } from '../economy/artifacts'
import { GAMES } from '../games/games'
import type { TagSuggestion } from './types'

const matches = (label: string, query: string) => label.toLowerCase().includes(query.toLowerCase())

// GAMES entries use a hyphenated `id` (routing key) and an underscored `dbKey`
// (what's actually stored in game_sessions.game). Build a quick lookup both ways.
const gameByDbKey = new Map<string, (typeof GAMES)[number]>(GAMES.map(g => [g.dbKey, g]))
const gameById = new Map<string, (typeof GAMES)[number]>(GAMES.map(g => [g.id, g]))

/**
 * How well a label answers the query, lower being better. A search for
 * "tri" should put "Trivia Clash" above "Nutrition Streak" — without this,
 * ordering inside a category is just whatever order the catalog happened
 * to come back in.
 */
function matchRank(label: string, query: string): number {
  const l = label.toLowerCase()
  const q = query.toLowerCase()
  if (l === q) return 0
  if (l.startsWith(q)) return 1
  // Start of any word — "clash" matching "Trivia Clash" is a better hit
  // than "clash" matching "Backslash Master".
  if (l.includes(` ${q}`)) return 2
  return 3
}

function byMatchRank(query: string) {
  return (a: TagSuggestion, b: TagSuggestion) =>
    matchRank(a.label, query) - matchRank(b.label, query)
}

/**
 * Round-robins across the per-category lists so no single category can eat
 * the whole result set.
 *
 * This used to be one flat array that each source pushed onto in turn,
 * sliced to 20 at the end. With 80-odd achievements in the catalog, a
 * short query filled all 20 slots with achievements before the game and
 * mention sources were ever appended — so those categories didn't rank
 * low, they vanished entirely. Taking one from each list per pass means
 * every category with a match is represented before any category gets a
 * second entry.
 */
function interleave(lists: TagSuggestion[][], limit: number): TagSuggestion[] {
  const out: TagSuggestion[] = []
  const deepest = Math.max(0, ...lists.map(l => l.length))
  for (let round = 0; round < deepest && out.length < limit; round++) {
    for (const list of lists) {
      if (round >= list.length) continue
      out.push(list[round])
      if (out.length >= limit) break
    }
  }
  return out
}

/**
 * Builds the typed-match suggestion list for the composer's tag box.
 * Each source is a best-effort fetch — if one fails, the others still return.
 * `query` may be empty (used to show the full recent/available pool before typing).
 */
export async function getTagSuggestions(userId: string, query: string): Promise<TagSuggestion[]> {
  const q = query.trim()
  if (q.length === 0) return [] // nothing shows until you actually type something

  // One list per category rather than one shared array — see interleave().
  const games: TagSuggestion[] = []
  const achievements: TagSuggestion[] = []
  const unlockedArtifacts: TagSuggestion[] = []
  const mallItems: TagSuggestion[] = []
  const gameResults: TagSuggestion[] = []
  const multiplayer: TagSuggestion[] = []
  const completedMissions: TagSuggestion[] = []
  const users: TagSuggestion[] = []
  const profileBits: TagSuggestion[] = [] // rank / streak / avatar — at most one each

  // ── Games ──────────────────────────────────────────────────────────────
  // The catalog is a local array, so unlike every other source this costs
  // no round-trip and can answer from the first character typed. Tagging
  // the game itself is separate from tagging a score you posted in it:
  // this one is available whether or not you've ever played it, and isn't
  // capped at your recent sessions.
  for (const game of GAMES) {
    if (matches(game.name, q) || (game.category != null && matches(game.category, q))) {
      games.push({ type: 'game', ref_id: game.id, label: game.name, meta: { gameId: game.id } })
    }
  }

  const [profileRes, unlockedAch, allAch, artifacts, playerArtifacts, inventory, missions] =
    await Promise.all([
      supabase.from('profiles').select('xp, streak, avatar').eq('id', userId).single(),
      getPlayerAchievements(userId).catch(() => []),
      getAllAchievements().catch(() => []),
      getAllArtifacts().catch(() => []),
      getPlayerArtifacts(userId).catch(() => []),
      supabase.from('user_inventory').select('item_id, is_equipped, mall_items(name)').eq('user_id', userId).eq('is_equipped', true),
      supabase.from('user_weekly_missions').select('mission_id, completed_at').eq('user_id', userId).not('completed_at', 'is', null),
    ])

  // Rank
  const profile = profileRes.data
  if (profile) {
    const tier = getUserRankTier(profile.xp ?? 0)
    if (matches(tier.name, q)) {
      profileBits.push({ type: 'rank', ref_id: tier.id, label: `Rank: ${tier.name}` })
    }
    if (matches('streak', q) && (profile.streak ?? 0) > 0) {
      profileBits.push({ type: 'streak', ref_id: 'streak', label: `${profile.streak}-day streak` })
    }
    if (matches('avatar', q) || matches('profile pic', q)) {
      profileBits.push({ type: 'avatar', ref_id: userId, label: 'My avatar' })
    }
  }

  // Achievements (unlocked only)
  const unlockedIds = new Set(unlockedAch.map(a => a.achievement_id))
  for (const ach of allAch) {
    if (unlockedIds.has(ach.id) && matches(ach.title, q)) {
      achievements.push({ type: 'achievement', ref_id: ach.id, label: ach.title })
    }
  }

  // Artifacts (unlocked only)
  const unlockedArtifactIds = new Set(playerArtifacts.map(a => a.artifact_id))
  for (const art of artifacts) {
    if (unlockedArtifactIds.has(art.id) && matches(art.name, q)) {
      unlockedArtifacts.push({ type: 'artifact', ref_id: art.id, label: art.name })
    }
  }

  // Equipped mall items
  for (const row of inventory.data ?? []) {
    const item = (row as unknown as { mall_items?: { name: string } }).mall_items
    if (item?.name && matches(item.name, q)) {
      mallItems.push({ type: 'mall_item', ref_id: row.item_id, label: item.name })
    }
  }

  // Completed missions
  for (const m of missions.data ?? []) {
    if (matches(m.mission_id, q)) {
      completedMissions.push({ type: 'mission', ref_id: m.mission_id, label: `Mission: ${m.mission_id}` })
    }
  }

  // Recent game results (last 10 completed sessions) — carries the real game
  // name + its routable id so the tag is clickable straight into that game.
  // Still capped, because this is "a score I just posted", not a catalog;
  // tagging the game in general is what the `game` source above is for.
  if (q.length >= 2) {
    const { data: sessions } = await supabase
      .from('game_sessions')
      .select('id, game, score')
      .eq('user_id', userId)
      .eq('result', 'completed')
      .order('created_at', { ascending: false })
      .limit(10)
    for (const s of sessions ?? []) {
      const meta = gameByDbKey.get(s.game)
      const gameName = meta?.name ?? s.game.replace(/_/g, ' ')
      const label = `${gameName} · Score ${s.score}`
      if (matches(label, q)) {
        gameResults.push({ type: 'game_result', ref_id: s.id, label, meta: meta ? { gameId: meta.id } : undefined })
      }
    }
  }

  // Recent multiplayer rooms
  if (q.length >= 2) {
    const { data: rooms } = await supabase
      .from('room_players')
      .select('room_id, rooms(id, game_id, code)')
      .eq('user_id', userId)
      .order('room_id', { ascending: false })
      .limit(5)
    for (const r of rooms ?? []) {
      const room = (r as unknown as { rooms?: { id: string; game_id: string | null; code: string } }).rooms
      if (!room?.game_id) continue
      const meta = gameById.get(room.game_id)
      const gameName = meta?.name ?? room.game_id.replace(/-/g, ' ')
      const label = `Multiplayer: ${gameName} (#${room.code})`
      if (matches(label, q)) {
        multiplayer.push({ type: 'multiplayer_result', ref_id: room.id, label, meta: { gameId: room.game_id } })
      }
    }
  }

  // @mention — followers only (people who follow this user), per product decision.
  if (q.length >= 2) {
    const { data: followRows } = await supabase
      .from('follows')
      .select('follower_id')
      .eq('following_id', userId)
      .limit(200)
    const followerIds = (followRows ?? []).map(f => f.follower_id)
    if (followerIds.length > 0) {
      const { data: followerProfiles } = await supabase
        .from('profiles')
        .select('id, username, display_name')
        .in('id', followerIds)
        .ilike('username', `%${q}%`)
        .limit(10)
      for (const u of followerProfiles ?? []) {
        users.push({ type: 'user', ref_id: u.id, label: `@${u.username}` })
      }
    }

    // Halo AI (and any other official account) is always taggable, follow
    // relationship aside — it's an AI, not a person who has or hasn't
    // followed you back, so the "followers only" product decision above
    // doesn't apply to it.
    const alreadyListed = new Set(users.map(u => u.ref_id))
    const { data: officialProfiles } = await supabase
      .from('profiles')
      .select('id, username, display_name')
      .or('is_official.eq.true,is_halo_ai.eq.true,is_groove_official.eq.true,is_pvp_official.eq.true,is_warden_official.eq.true')
      .ilike('username', `%${q}%`)
      .limit(5)
    for (const u of officialProfiles ?? []) {
      if (alreadyListed.has(u.id)) continue
      users.push({ type: 'user', ref_id: u.id, label: `@${u.username}` })
    }
  }

  // Best match first inside each category, then one from each category per
  // pass. Category order below only breaks ties within a round, so it's a
  // mild preference rather than the hard priority the old flat list gave
  // whichever source happened to push first.
  const lists = [
    games, achievements, gameResults, users,
    unlockedArtifacts, mallItems, multiplayer, profileBits, completedMissions,
  ]
  for (const list of lists) list.sort(byMatchRank(q))

  return interleave(lists, 20)
}
