// src/features/posts/posts.ts
import { supabase } from '../../shared/lib/supabase'
import { containsProfanity, PROFANITY_BLOCKED_MESSAGE } from '../../shared/lib/profanityFilter'
import { createPostPoll, fetchPollIdsForPosts, type NewPostPoll } from './postPolls'
import { compressImage } from '../../shared/lib/imageCompress'
import type { Post, Comment, PostTag, PostingEligibility, NotInterestedChoice } from './types'

/** Shape of a raw row straight off `posts`, before the author/like-status
 *  joins that turn it into a display-ready `Post`. Exported so other
 *  modules querying `posts` directly (e.g. staffPosts.ts) can type their
 *  results consistently instead of falling back to `any`. */
export type PostRow = Omit<Post, 'author' | 'liked_by_me' | 'poll_id'>

// ── Shared hydration: attach author profile + "did I like this" flag ───
// Pulled out of fetchFeed so fetchAnnouncements (staffPosts.ts) can reuse
// the exact same join logic instead of duplicating it.
export async function hydratePosts(rows: PostRow[], userId: string | null): Promise<Post[]> {
  if (rows.length === 0) return []

  const authorIds = [...new Set(rows.map(p => p.author_id).filter(Boolean))] as string[]
  const authorsById = new Map<string, { id: string; username: string; display_name: string | null; avatar: string; is_official?: boolean; is_halo_ai?: boolean; is_groove_official?: boolean; is_pvp_official?: boolean; is_warden_official?: boolean }>()

  if (authorIds.length > 0) {
    const { data: authors } = await supabase
      .from('profiles')
      .select('id, username, display_name, avatar, is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official')
      .in('id', authorIds)
    for (const a of authors ?? []) authorsById.set(a.id, a)
  }

  // Persona bylines ("post as Willam") — see migration 0100. Joined the
  // same way as author profiles, from blog_personas instead of profiles.
  const personaIds = [...new Set(rows.map(p => p.persona_author_id).filter(Boolean))] as string[]
  const personasById = new Map<string, { id: string; username: string; display_name: string; avatar: string | null }>()

  if (personaIds.length > 0) {
    const { data: personas } = await supabase
      .from('blog_personas')
      .select('id, username, display_name, avatar')
      .in('id', personaIds)
    for (const p of personas ?? []) personasById.set(p.id, p)
  }

  let likedPostIds = new Set<string>()
  let repostedPostIds = new Set<string>()
  if (userId) {
    const postIds = rows.map(p => p.id)
    const [{ data: likes }, { data: reposts }] = await Promise.all([
      supabase.from('post_likes').select('post_id').eq('user_id', userId).in('post_id', postIds),
      supabase.from('post_reposts').select('post_id').eq('user_id', userId).in('post_id', postIds),
    ])
    likedPostIds = new Set((likes ?? []).map(l => l.post_id))
    repostedPostIds = new Set((reposts ?? []).map(r => r.post_id))
  }

  // Which of these posts carry a poll — one query for the page, so
  // PostCard never has to probe per card.
  const pollIdsByPost = await fetchPollIdsForPosts(rows.map(p => p.id))

  return rows.map(p => ({
    ...p,
    author: p.author_id ? authorsById.get(p.author_id) : undefined,
    persona_author: p.persona_author_id ? personasById.get(p.persona_author_id) ?? null : null,
    liked_by_me: likedPostIds.has(p.id),
    reposted_by_me: repostedPostIds.has(p.id),
    poll_id: pollIdsByPost[p.id] ?? null,
  }))
}

// ── Feed ──────────────────────────────────────────────────────
// Newest first.
//
// This used to sort by `influence` first with created_at only as a
// tiebreak. Every post starts at influence 0, so a post published a minute
// ago sat below every post that had ever earned a single like — in
// practice new posts landed at the very bottom of the feed, under posts
// six weeks old. Nobody saw them, so they never earned influence, so they
// never moved. The metric was sorting the feed by "what was already
// popular" and quietly burying everything new.
//
// Influence hasn't gone anywhere — it's still counted, still shown on the
// card, still opens InfluenceModal. It just isn't what decides the order.
export async function fetchFeed(userId: string | null, limit = 30): Promise<Post[]> {
  const prefs = await fetchFeedFeedback(userId)

  let query = supabase.from('posts').select('*')

  // Hard exclusions go in the query so they don't eat into the row budget.
  if (prefs.hiddenPostIds.size > 0) {
    query = query.not('id', 'in', pgList(prefs.hiddenPostIds))
  }
  if (prefs.mutedAuthorIds.size > 0) {
    query = query.not('author_id', 'in', pgList(prefs.mutedAuthorIds))
  }

  // "Reduce" is a sampling rule, not a filter, so it can only be applied
  // after the rows come back. Over-fetch a little when it's in play so a
  // reduced author's dropped posts don't leave the feed short.
  const fetchLimit = prefs.reducedAuthorIds.size > 0 ? Math.ceil(limit * 1.5) : limit

  const { data: posts, error } = await query
    .order('created_at', { ascending: false })
    .limit(fetchLimit)

  if (error || !posts) {
    console.error('fetchFeed error:', error)
    return []
  }

  const kept = (posts as PostRow[])
    .filter(p => !(p.author_id && prefs.reducedAuthorIds.has(p.author_id)) || keepWhenReduced(p.id))
    .slice(0, limit)

  return hydratePosts(kept, userId)
}

// ── Posts by a single author (moderator showcase profile feed) ──
export async function fetchPostsByAuthor(authorId: string, userId: string | null, limit = 30): Promise<Post[]> {
  const { data: posts, error } = await supabase
    .from('posts')
    .select('*')
    .eq('author_id', authorId)
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error || !posts) {
    console.error('fetchPostsByAuthor error:', error)
    return []
  }

  return hydratePosts(posts as PostRow[], userId)
}

// ── Single post (for share links) ───────────────────────────────
export async function fetchPostById(postId: string, userId: string | null): Promise<Post | null> {
  const { data: post, error } = await supabase.from('posts').select('*').eq('id', postId).maybeSingle()
  if (error || !post) {
    console.error('fetchPostById error:', error)
    return null
  }

  let author: { id: string; username: string; display_name: string | null; avatar: string; is_official?: boolean; is_halo_ai?: boolean; is_groove_official?: boolean; is_pvp_official?: boolean; is_warden_official?: boolean } | undefined
  if (post.author_id) {
    const { data } = await supabase.from('profiles').select('id, username, display_name, avatar, is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official').eq('id', post.author_id).maybeSingle()
    author = data ?? undefined
  }

  let personaAuthor: { id: string; username: string; display_name: string; avatar: string | null } | null = null
  if (post.persona_author_id) {
    const { data } = await supabase.from('blog_personas').select('id, username, display_name, avatar').eq('id', post.persona_author_id).maybeSingle()
    personaAuthor = data ?? null
  }

  let likedByMe = false
  let repostedByMe = false
  if (userId) {
    const [{ data: like }, { data: repost }] = await Promise.all([
      supabase.from('post_likes').select('post_id').eq('post_id', postId).eq('user_id', userId).maybeSingle(),
      supabase.from('post_reposts').select('post_id').eq('post_id', postId).eq('user_id', userId).maybeSingle(),
    ])
    likedByMe = !!like
    repostedByMe = !!repost
  }

  const pollIdsByPost = await fetchPollIdsForPosts([postId])

  return {
    ...post, author, persona_author: personaAuthor,
    liked_by_me: likedByMe, reposted_by_me: repostedByMe,
    poll_id: pollIdsByPost[postId] ?? null,
  } as Post
}

// ── Delete ────────────────────────────────────────────────────
// RLS (see migrations 0008 and 0028) allows an author to delete their own
// posts, and staff to delete any staff-authored post.
export async function deletePost(postId: string): Promise<boolean> {
  // Read the attachment BEFORE the row goes, or the path is unrecoverable
  // and the file sits in the bucket forever. Deleting a DB row never
  // deletes a storage object — the two are separate systems.
  const { data: row } = await supabase
    .from('posts')
    .select('media_url')
    .eq('id', postId)
    .maybeSingle<{ media_url: string | null }>()

  const { error } = await supabase.from('posts').delete().eq('id', postId)
  if (error) {
    console.error('deletePost error:', error)
    return false
  }

  if (row?.media_url) {
    // Best-effort: the post is already gone, and a stranded file is a
    // tidiness problem, not a failure worth reporting to the user.
    deletePostImage(row.media_url).catch(e => console.error('deletePostImage error:', e))
  }
  return true
}

// ── Post images (migration 0182a) ─────────────────────────────
// Members who may post media write into their OWN folder of the
// `feed-images` bucket, matching the staff uploader's path convention.

const FEED_IMAGES_BUCKET = 'feed-images'
const MAX_POST_IMAGE_BYTES = 400 * 1024

/**
 * Compresses, then uploads, and returns the public URL.
 *
 * Deliberately called at SUBMIT time, never when the file is picked: an
 * upload-on-pick composer leaves a stranded file behind every time someone
 * changes their mind or the browser discards the tab.
 */
export async function uploadPostImage(authorId: string, file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Only images can be attached to a post.')
  }

  const compressed = await compressImage(file, { maxBytes: MAX_POST_IMAGE_BYTES, maxDimension: 1280 })
  const ext = compressed.type.includes('webp') ? 'webp' : 'jpg'
  const path = `${authorId}/${crypto.randomUUID()}.${ext}`

  const { error } = await supabase.storage
    .from(FEED_IMAGES_BUCKET)
    .upload(path, compressed, {
      contentType: compressed.type,
      upsert: false,
      // A post image never changes once posted, so it can be cached for a
      // year. supabase-js otherwise defaults to ONE HOUR, which is what
      // makes repeat feed scrolls re-download every image.
      cacheControl: '31536000',
    })
  if (error) throw new Error(`Failed to upload image: ${error.message}`)

  const { data } = supabase.storage.from(FEED_IMAGES_BUCKET).getPublicUrl(path)
  return data.publicUrl
}

/** Removes an uploaded post image by its public URL. */
export async function deletePostImage(publicUrl: string): Promise<void> {
  const marker = `/${FEED_IMAGES_BUCKET}/`
  const idx = publicUrl.indexOf(marker)
  if (idx === -1) return
  const path = decodeURIComponent(publicUrl.slice(idx + marker.length))
  const { error } = await supabase.storage.from(FEED_IMAGES_BUCKET).remove([path])
  if (error) console.error('deletePostImage error:', error)
}

// ── Create ────────────────────────────────────────────────────
export async function createPost(input: {
  authorId: string
  body: string
  tags: PostTag[]
  commentable: boolean
  /** Public URL from uploadPostImage. RLS refuses this for anyone who
   *  isn't verified or Void (0182a), so the client gate is a courtesy,
   *  not the boundary. */
  mediaUrl?: string | null
  /** Optional poll to attach (migration 0131). Created in a second call
   *  after the post row lands, since create_post_poll needs a post id to
   *  check ownership against. */
  poll?: NewPostPoll | null
}) {
  if (containsProfanity(input.body)) {
    return { data: null, error: { message: PROFANITY_BLOCKED_MESSAGE } }
  }

  const { data, error } = await supabase
    .from('posts')
    .insert({
      author_id: input.authorId,
      author_type: 'user',
      body: input.body,
      tags: input.tags,
      commentable: input.commentable,
      media_url: input.mediaUrl ?? null,
      media_type: input.mediaUrl ? 'image' : null,
    })
    .select()
    .single()

  if (error) {
    console.error('createPost error:', error)
    if (error.message?.includes('CV_PROFANITY')) {
      return { data, error: { message: PROFANITY_BLOCKED_MESSAGE } }
    }
    return { data, error }
  }

  // Awaited, unlike the notification fan-outs below: a post that was meant
  // to carry a poll and silently didn't is a broken post, not a missed
  // nicety. If the poll fails the post is left standing (it's already
  // inserted) and the error comes back so the composer can say so.
  if (input.poll) {
    const { error: pollError } = await createPostPoll(data.id, input.poll)
    if (pollError) return { data, error: { message: pollError } }
  }

  // Fire-and-forget: don't block the composer closing on notification delivery.
  notifyFollowersOfNewPost(data.id).catch(e => console.error('notifyFollowersOfNewPost error:', e))
  notifyTaggedUsers(data.id).catch(e => console.error('notifyTaggedUsers error:', e))

  return { data, error }
}

// ── Notifications ─────────────────────────────────────────────
// Both fan-outs live in RPCs now (migration 0106), not in client loops.
// They used to iterate every follower / every tagged user issuing one
// insert_notification round-trip each, with the title and body composed
// here — which meant any authenticated client could push arbitrary text
// to arbitrary users under a real notification type. Since every
// notification row also fires a native push, that was attacker-controlled
// copy landing on someone's lock screen from Chillverse's own push
// credentials.
//
// The RPCs verify the caller authored the post, read the preview and the
// tag list from the stored row, and insert set-based in one statement.
async function notifyFollowersOfNewPost(postId: string) {
  const { error } = await supabase.rpc('notify_new_post', { p_post_id: postId })
  if (error) console.error('notify_new_post error:', error)
}

async function notifyTaggedUsers(postId: string) {
  const { error } = await supabase.rpc('notify_post_tags', { p_post_id: postId })
  if (error) console.error('notify_post_tags error:', error)
}

// ── Likes (toggle) ───────────────────────────────────────────
export async function toggleLike(postId: string, userId: string, currentlyLiked: boolean) {
  if (currentlyLiked) {
    const { error } = await supabase.from('post_likes').delete().eq('post_id', postId).eq('user_id', userId)
    if (error) console.error('unlike error:', error)
    return !error
  }
  const { error } = await supabase.from('post_likes').insert({ post_id: postId, user_id: userId })
  if (error) console.error('like error:', error)
  // Fire-and-forget, and only on the way up — unliking notifies nobody.
  // The RPC names the liker ("Victor liked your post"), verifies the like
  // actually exists, skips the author's own likes, and only ever fires once
  // per (post, liker) so unlike/relike can't be used to spam someone.
  if (!error) notifyPostLike(postId).catch(e => console.error('notifyPostLike error:', e))
  return !error
}

async function notifyPostLike(postId: string) {
  const { error } = await supabase.rpc('notify_post_like', { p_post_id: postId })
  if (error) console.error('notify_post_like error:', error)
}

// ── Reposts (toggle) ─────────────────────────────────────────
// Deliberately thin: a repost is a count and a notification. It does not
// copy the post into the reposter's feed, doesn't quote it, doesn't affect
// influence or feed order. See migration 0115.
export async function toggleRepost(postId: string, userId: string, currentlyReposted: boolean) {
  if (currentlyReposted) {
    const { error } = await supabase.from('post_reposts').delete().eq('post_id', postId).eq('user_id', userId)
    if (error) console.error('unrepost error:', error)
    return !error
  }
  const { error } = await supabase.from('post_reposts').insert({ post_id: postId, user_id: userId })
  if (error) console.error('repost error:', error)
  // Fire-and-forget, and only on the way up. The RPC composes the copy
  // server-side ("{name} reposted a post"), verifies the repost row is
  // really there, and fires at most once per (post, reposter) — so
  // unrepost/repost can't be used to buzz someone's followers repeatedly.
  if (!error) notifyPostRepost(postId).catch(e => console.error('notifyPostRepost error:', e))
  return !error
}

async function notifyPostRepost(postId: string) {
  const { error } = await supabase.rpc('notify_post_repost', { p_post_id: postId })
  if (error) console.error('notify_post_repost error:', error)
}

// ── "Not interested" feed feedback (migration 0115) ───────────
export interface FeedFeedback {
  hiddenPostIds: Set<string>
  mutedAuthorIds: Set<string>
  reducedAuthorIds: Set<string>
}

const EMPTY_FEEDBACK: FeedFeedback = {
  hiddenPostIds: new Set(), mutedAuthorIds: new Set(), reducedAuthorIds: new Set(),
}

/** Postgres list literal for .not('col', 'in', ...) — ids are UUIDs from
 *  our own tables, so no quoting/escaping is needed. */
function pgList(ids: Set<string>) {
  return `(${[...ids].join(',')})`
}

/** Stable 1-in-3 sample for authors the viewer chose to see less of.
 *  Hashing the post id (rather than sampling randomly) keeps the same
 *  posts visible across refetches, so the feed doesn't reshuffle itself
 *  every time it reloads. */
function keepWhenReduced(postId: string) {
  let h = 0
  for (let i = 0; i < postId.length; i++) h = (h * 31 + postId.charCodeAt(i)) | 0
  return Math.abs(h) % 3 === 0
}

export async function fetchFeedFeedback(userId: string | null): Promise<FeedFeedback> {
  if (!userId) return EMPTY_FEEDBACK

  const [{ data: hidden, error: hiddenErr }, { data: prefs, error: prefsErr }] = await Promise.all([
    supabase.from('post_not_interested').select('post_id').eq('user_id', userId),
    supabase.from('author_feed_prefs').select('author_id, mode').eq('user_id', userId),
  ])

  if (hiddenErr) console.error('fetchFeedFeedback (hidden) error:', hiddenErr)
  if (prefsErr) console.error('fetchFeedFeedback (prefs) error:', prefsErr)

  return {
    hiddenPostIds: new Set((hidden ?? []).map(r => r.post_id)),
    mutedAuthorIds: new Set((prefs ?? []).filter(r => r.mode === 'mute').map(r => r.author_id)),
    reducedAuthorIds: new Set((prefs ?? []).filter(r => r.mode === 'reduce').map(r => r.author_id)),
  }
}

/** One call for all three choices in the "not interested" sheet.
 *  'hide_post' needs no authorId; the other two ignore postId. */
export async function submitNotInterested(input: {
  userId: string
  postId: string
  authorId: string | null
  choice: NotInterestedChoice
}) {
  if (input.choice === 'hide_post') {
    const { error } = await supabase
      .from('post_not_interested')
      .upsert({ user_id: input.userId, post_id: input.postId }, { onConflict: 'user_id,post_id' })
    if (error) console.error('submitNotInterested (hide_post) error:', error)
    return !error
  }

  if (!input.authorId) return false

  const { error } = await supabase
    .from('author_feed_prefs')
    .upsert({
      user_id: input.userId,
      author_id: input.authorId,
      mode: input.choice === 'mute_author' ? 'mute' : 'reduce',
    }, { onConflict: 'user_id,author_id' })
  if (error) console.error('submitNotInterested (author pref) error:', error)
  return !error
}

// ── Comments ──────────────────────────────────────────────────
export async function fetchComments(postId: string): Promise<Comment[]> {
  const { data: comments, error } = await supabase
    .from('comments')
    .select('*')
    .eq('post_id', postId)
    .order('created_at', { ascending: true })

  if (error || !comments) {
    console.error('fetchComments error:', error)
    return []
  }

  const authorIds = [...new Set(comments.map(c => c.author_id))]
  const { data: authors } = authorIds.length
    ? await supabase.from('profiles').select('id, username, display_name, avatar, is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official').in('id', authorIds)
    : { data: [] as { id: string; username: string; display_name: string | null; avatar: string; is_official?: boolean; is_halo_ai?: boolean; is_groove_official?: boolean; is_pvp_official?: boolean; is_warden_official?: boolean }[] }

  const authorsById = new Map((authors ?? []).map(a => [a.id, a]))
  return comments.map(c => ({ ...c, author: authorsById.get(c.author_id) })) as Comment[]
}

export async function addComment(
  postId: string,
  authorId: string,
  body: string,
  isNotice = false,
  /** Top-level comment this is a reply to. A DB trigger refuses a parent
   *  that is itself a reply, so callers must pass the PARENT's id even
   *  when the tap came from a reply. */
  parentId: string | null = null,
) {
  if (containsProfanity(body)) {
    return { data: null, error: { message: PROFANITY_BLOCKED_MESSAGE } }
  }

  const { data, error } = await supabase
    .from('comments')
    .insert({ post_id: postId, author_id: authorId, body, is_notice: isNotice, parent_id: parentId })
    .select()
    .single()

  if (error) {
    console.error('addComment error:', error)
    if (error.message?.includes('CV_PROFANITY')) {
      return { data, error: { message: PROFANITY_BLOCKED_MESSAGE } }
    }
  }

  // Fire-and-forget so the comment box doesn't wait on delivery. The RPC
  // deliberately does NOT name the commenter or quote the comment — the
  // author gets "Someone commented on your post" and finds out who by
  // opening the thread, where it's attributed anyway. It also collapses
  // while unread, so ten comments on one post is one notification.
  // A reply notifies the person being replied to, not the post's author —
  // otherwise the poster gets pinged for every side conversation under
  // their post and the person actually being answered gets nothing.
  if (data && !error) {
    if (parentId) {
      notifyCommentReply(data.id).catch(e => console.error('notifyCommentReply error:', e))
    } else {
      notifyPostComment(data.id).catch(e => console.error('notifyPostComment error:', e))
    }
  }

  return { data, error }
}

async function notifyCommentReply(commentId: string) {
  const { error } = await supabase.rpc('notify_comment_reply', { p_comment_id: commentId })
  if (error) console.error('notify_comment_reply error:', error)
}

async function notifyPostComment(commentId: string) {
  const { error } = await supabase.rpc('notify_post_comment', { p_comment_id: commentId })
  if (error) console.error('notify_post_comment error:', error)
}

// ── Threaded comments (migrations 0179a/0179b) ────────────────
// Top-level comments and replies live in the SAME table, split by
// parent_id. The sheet loads top-level rows in pages and pulls a
// parent's replies only when the viewer expands them — a post with 300
// comments should cost one query to open, not 300.

const COMMENT_PAGE_SIZE = 30

const COMMENT_COLUMNS = 'id, post_id, author_id, body, created_at, hidden, hidden_reason, parent_id, likes_count, replies_count'

/**
 * Attaches author profiles, the viewer's own like state, and whether the
 * POST's author liked each comment.
 *
 * "Liked by the creator" needs no schema of its own — it is just a
 * comment_likes row whose user_id is the post's author — so it costs one
 * extra query per page rather than a migration.
 */
async function hydrateComments(
  rows: Comment[],
  viewerId: string | null,
  creatorId: string | null,
): Promise<Comment[]> {
  if (rows.length === 0) return []

  const ids = rows.map(c => c.id)
  const authorIds = [...new Set(rows.map(c => c.author_id))]
  const [{ data: authors }, likedIds, creatorLikedIds] = await Promise.all([
    supabase.from('profiles').select('id, username, display_name, avatar, is_official, is_halo_ai, is_groove_official, is_pvp_official, is_warden_official').in('id', authorIds),
    fetchMyCommentLikes(ids, viewerId),
    // Skipped entirely on staff/system posts, where author_id is null.
    creatorId ? fetchCommentLikesBy(ids, creatorId) : Promise.resolve(new Set<string>()),
  ])

  const authorsById = new Map((authors ?? []).map(a => [a.id, a]))
  return rows.map(c => ({
    ...c,
    author: authorsById.get(c.author_id),
    liked_by_me: likedIds.has(c.id),
    liked_by_creator: creatorLikedIds.has(c.id),
  })) as Comment[]
}

/** Which of these comments a given user has liked. */
async function fetchCommentLikesBy(commentIds: string[], userId: string): Promise<Set<string>> {
  if (commentIds.length === 0) return new Set()
  const { data, error } = await supabase
    .from('comment_likes')
    .select('comment_id')
    .eq('user_id', userId)
    .in('comment_id', commentIds)
  if (error) {
    console.error('fetchCommentLikesBy error:', error)
    return new Set()
  }
  return new Set((data ?? []).map(r => r.comment_id as string))
}

async function fetchMyCommentLikes(commentIds: string[], viewerId: string | null): Promise<Set<string>> {
  if (!viewerId) return new Set()
  return fetchCommentLikesBy(commentIds, viewerId)
}

/**
 * One page of TOP-LEVEL comments, most-liked first then newest. With low
 * like counts that degrades to plain "newest first", which is what we
 * want while the app is small.
 */
export async function fetchTopLevelComments(
  postId: string,
  viewerId: string | null,
  creatorId: string | null,
  page = 0,
): Promise<{ comments: Comment[]; hasMore: boolean }> {
  const from = page * COMMENT_PAGE_SIZE
  const { data, error } = await supabase
    .from('comments')
    .select(COMMENT_COLUMNS)
    .eq('post_id', postId)
    .is('parent_id', null)
    .order('likes_count', { ascending: false })
    .order('created_at', { ascending: false })
    .range(from, from + COMMENT_PAGE_SIZE)

  if (error || !data) {
    console.error('fetchTopLevelComments error:', error)
    return { comments: [], hasMore: false }
  }

  // One row over the page size tells us whether a "Load more" is needed
  // without a second count query.
  const hasMore = data.length > COMMENT_PAGE_SIZE
  const page_ = hasMore ? data.slice(0, COMMENT_PAGE_SIZE) : data
  return { comments: await hydrateComments(page_ as Comment[], viewerId, creatorId), hasMore }
}

/** Every reply under one top-level comment, oldest first (conversation order). */
/** One comment by id, hydrated the same way a list would be — used to
 *  pull a single comment into view when a notification points at it. */
export async function fetchCommentById(
  commentId: string,
  viewerId: string | null,
  creatorId: string | null,
): Promise<Comment | null> {
  const { data, error } = await supabase
    .from('comments')
    .select(COMMENT_COLUMNS)
    .eq('id', commentId)
    .maybeSingle()
  if (error || !data) return null
  const [hydrated] = await hydrateComments([data as Comment], viewerId, creatorId)
  return hydrated ?? null
}

export async function fetchReplies(
  parentId: string,
  viewerId: string | null,
  creatorId: string | null,
): Promise<Comment[]> {
  const { data, error } = await supabase
    .from('comments')
    .select(COMMENT_COLUMNS)
    .eq('parent_id', parentId)
    .order('created_at', { ascending: true })

  if (error || !data) {
    console.error('fetchReplies error:', error)
    return []
  }
  return hydrateComments(data as Comment[], viewerId, creatorId)
}

export async function likeComment(commentId: string, userId: string): Promise<boolean> {
  const { error } = await supabase
    .from('comment_likes')
    .insert({ comment_id: commentId, user_id: userId })
  if (error) {
    // 23505 = already liked. Treat as success so a double-tap doesn't
    // bounce the heart back off.
    if (error.code === '23505') return true
    console.error('likeComment error:', error)
    return false
  }
  // Notification is entirely a DB trigger now (0183c) — it aggregates
  // "X and N others liked your comment" and needs to react to unlikes
  // too, which an RPC fired only from here never could.
  return true
}

export async function unlikeComment(commentId: string, userId: string): Promise<boolean> {
  const { error } = await supabase
    .from('comment_likes')
    .delete()
    .eq('comment_id', commentId)
    .eq('user_id', userId)
  if (error) {
    console.error('unlikeComment error:', error)
    return false
  }
  return true
}

/**
 * RLS allows this for the comment's author and for staff (migration
 * 0179a — before it there was no DELETE policy at all, so even authors
 * silently failed). Deleting a parent cascades its replies.
 */
export async function deleteComment(commentId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('comments').delete().eq('id', commentId)
  if (error) {
    console.error('deleteComment error:', error)
    return { error: 'Failed to delete that comment. Please try again.' }
  }
  return { error: null }
}

// ── Posting eligibility (server-checked, see migration 0007) ───
export async function checkPostingEligibility(userId: string): Promise<PostingEligibility | null> {
  const { data, error } = await supabase
    .rpc('check_posting_eligibility', { p_user_id: userId })
    .maybeSingle<PostingEligibility>()

  if (error) {
    console.error('checkPostingEligibility error:', error)
    return null
  }
  return data ?? null
}
