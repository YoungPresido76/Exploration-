// src/features/posts/CommentSheet.tsx
//
// The comment surface for a feed post: a draw-up sheet rather than an
// inline expander under the card.
//
// Sheet mechanics follow the house pattern (Composer.tsx): portal to
// <body>, `sheet-or-modal sheet-or-modal-over-dock` so it sits OVER the
// dock instead of above it, and `cv-sheet-open` on <body> so the dock
// hides itself rather than showing through and swallowing taps.
//
// Threading is ONE level deep, enforced in the DB (0179a). Replying to a
// reply attaches to that reply's PARENT and only prefills the @name — so
// a thread can never nest into an unreadable staircase at 360px.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { AtSign, Heart, Send, Trash2, Flag, Copy, CornerUpLeft, X, Lock } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { useModRole } from '../moderation/useModRole'
import {
  fetchTopLevelComments, fetchReplies, fetchCommentById, addComment,
  likeComment, unlikeComment, deleteComment,
} from './posts'
import type { Comment } from './types'
import Avatar from '../../shared/components/Avatar'
import VerifiedBadge from '../../shared/components/VerifiedBadge'
import HiddenContentNotice from '../moderation/HiddenContentNotice'
import ReportModal from '../safety/ReportModal'
import Toast, { useToast } from '../../shared/components/Toast'
import CommentBody from './CommentBody'
import MentionPicker from './MentionPicker'
import { useCommentMentions } from './useCommentMentions'
import { useLongPress } from '../../shared/lib/useLongPress'
import { updateMissionProgress } from '../missions/weeklyMissions'
import { useProfilePreviewOptional } from '../../context/ProfilePreview'
import { vibrate } from '../../shared/lib/vibrate'

const SHEET_Z = 105

function shortAgo(iso: string): string {
  const secs = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000)
  if (secs < 60) return 'now'
  const mins = Math.floor(secs / 60)
  if (mins < 60) return `${mins}m`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}d`
  const weeks = Math.floor(days / 7)
  if (weeks < 5) return `${weeks}w`
  return `${Math.floor(days / 365) >= 1 ? `${Math.floor(days / 365)}y` : `${Math.floor(days / 30)}mo`}`
}

export interface CommentCreator {
  id: string
  username: string
  display_name: string | null
  avatar: string
}

interface RowProps {
  comment: Comment
  isReply?: boolean
  viewerId: string | null
  /** The post's author, for the "liked by creator" badge. Null on
   *  staff/system posts, which have no author to speak for. */
  creator: CommentCreator | null
  mentions: ReturnType<typeof useCommentMentions>
  onReply: (c: Comment) => void
  onToggleLike: (c: Comment) => void
  onLongPress: (c: Comment) => void
  /** True for the ~1.8s window right after this comment was scrolled to
   *  from a notification, so it can flash rather than just silently
   *  appear mid-list. */
  flash?: boolean
  registerRef?: (id: string, el: HTMLDivElement | null) => void
}

function CommentRow({ comment, isReply = false, viewerId, creator, mentions, onReply, onToggleLike, onLongPress, flash = false, registerRef }: RowProps) {
  const preview = useProfilePreviewOptional()
  const { wasLongPress, handlers } = useLongPress(() => {
    vibrate(12)
    onLongPress(comment)
  })

  const name = comment.author?.display_name || comment.author?.username || 'User'
  const liked = comment.liked_by_me === true
  const likes = comment.likes_count ?? 0
  const avatarSize = isReply ? 26 : 32
  // A creator liking their own comment is not an endorsement, it's a
  // person liking themselves — no badge for that.
  const showCreatorLike = comment.liked_by_creator === true && !!creator && creator.id !== comment.author_id
  // The post's author gets an "Author" tag on their own comments/replies,
  // same as e.g. YouTube/Reddit OP tags — helps readers spot when the
  // person who made the post is weighing in on their own thread.
  const isCreator = !!creator && creator.id === comment.author_id

  return (
    <div
      ref={el => registerRef?.(comment.id, el)}
      {...handlers}
      onClick={() => { if (wasLongPress()) return }}
      style={{
        display: 'flex', gap: 10, marginBottom: isReply ? 12 : 14, marginLeft: isReply ? 42 : 0,
        borderRadius: 10, padding: flash ? 8 : 0,
        background: flash ? 'var(--accent-soft)' : 'transparent',
        transition: 'background 1.2s ease',
      }}
    >
      <Avatar
        src={comment.author?.avatar}
        name={name}
        userId={comment.author_id}
        size={avatarSize}
        style={{ flex: 'none' }}
      />

      <div style={{ flex: 1, minWidth: 0 }}>
        <button
          type="button"
          onClick={() => preview?.openProfilePreview(comment.author_id)}
          style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', fontSize: isReply ? 11.5 : 12, color: 'var(--text-dim)', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}
        >
          {comment.author?.username ? `@${comment.author.username}` : name}
          {(comment.author?.is_official || comment.author?.is_halo_ai || comment.author?.is_groove_official || comment.author?.is_pvp_official || comment.author?.is_warden_official) && <VerifiedBadge size={isReply ? 12 : 13} />}
          {isCreator && (
            <span
              style={{
                color: 'var(--accent)', fontSize: 9.5, fontWeight: 800, letterSpacing: 0.2,
              }}
            >
              · Author
            </span>
          )}
        </button>

        {comment.hidden ? (
          <div style={{ marginTop: 3 }}>
            <HiddenContentNotice reason={comment.hidden_reason} isOwner={viewerId === comment.author_id} inline />
          </div>
        ) : (
          <CommentBody body={comment.body} mentions={mentions} size={isReply ? 13 : 13.5} />
        )}

        <div style={{ display: 'flex', gap: 14, marginTop: 6, fontSize: 11.5, color: 'var(--text-dim)' }}>
          <span>{shortAgo(comment.created_at)}</span>
          <button
            type="button"
            onClick={() => onReply(comment)}
            style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--text-dim)', fontSize: 11.5, fontWeight: 700 }}
          >
            Reply
          </button>

          {showCreatorLike && creator && (
            <span
              title={`Liked by @${creator.username}`}
              style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}
            >
              <Avatar
                src={creator.avatar}
                name={creator.display_name || creator.username}
                ownerId={creator.id}
                size={17}
              />
              <Heart
                size={10}
                fill="#ff4d6d"
                color="#ff4d6d"
                style={{
                  position: 'absolute', right: -4, bottom: -3,
                  background: 'var(--surface)', borderRadius: '50%', padding: 1,
                }}
              />
            </span>
          )}
        </div>
      </div>

      <button
        type="button"
        onClick={() => onToggleLike(comment)}
        aria-label={liked ? 'Unlike comment' : 'Like comment'}
        style={{
          flex: 'none', width: 30, background: 'none', border: 'none', cursor: 'pointer',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, padding: 0,
          color: liked ? '#ff4d6d' : 'var(--text-dim)',
        }}
      >
        <Heart size={isReply ? 15 : 16} fill={liked ? '#ff4d6d' : 'none'} />
        {likes > 0 && <span style={{ fontSize: 11 }}>{likes}</span>}
      </button>
    </div>
  )
}

export default function CommentSheet({
  postId,
  creator,
  commentable,
  open,
  onClose,
  onCountChange,
  initialCount,
  highlightCommentId,
}: {
  postId: string
  /** The post's author. Null on staff/system posts. */
  creator: CommentCreator | null
  /** When false, the sheet still opens (the comment button always shows
   *  now) but shows a locked notice instead of the list/composer. */
  commentable: boolean
  open: boolean
  onClose: () => void
  /** Fires with the signed delta so the card's counter tracks the sheet. */
  onCountChange?: (delta: number) => void
  initialCount: number
  /** A comment_reply/comment_like notification tap lands here wanting
   *  this exact comment scrolled to and briefly highlighted. May be a
   *  reply, in which case its parent gets expanded to reveal it. */
  highlightCommentId?: string | null
}) {
  const { user } = useAuth()
  // The optimistic row needs a real username/avatar — auth's user_metadata
  // carries neither, so it comes from the cached profiles row.
  const { profile } = useProfile()
  const { isStaff } = useModRole()
  const { toast, showToast } = useToast()

  const [comments, setComments] = useState<Comment[]>([])
  const [repliesByParent, setRepliesByParent] = useState<Record<string, Comment[]>>({})
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(0)
  const [hasMore, setHasMore] = useState(false)
  const [count, setCount] = useState(initialCount)

  const [draft, setDraft] = useState('')
  const [replyTo, setReplyTo] = useState<Comment | null>(null)
  const [posting, setPosting] = useState(false)
  const [error, setError] = useState('')

  const [pickerQuery, setPickerQuery] = useState<string | null>(null)
  const [actionTarget, setActionTarget] = useState<Comment | null>(null)
  const [reportTarget, setReportTarget] = useState<Comment | null>(null)

  const [visible, setVisible] = useState(false)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  // Hide the dock while the sheet is up — see index.css's body.cv-sheet-open.
  useEffect(() => {
    if (!open) return
    setVisible(true)
    // Save/restore rather than a bare remove — see the same note in
    // ProfilePreviewModal. Anything that opens on top of this sheet and
    // clears the flag on close would otherwise let the dock back in over
    // the composer.
    const dockWasHidden = document.body.classList.contains('cv-sheet-open')
    document.body.classList.add('cv-sheet-open')
    return () => { if (!dockWasHidden) document.body.classList.remove('cv-sheet-open') }
  }, [open])

  const close = useCallback(() => {
    setVisible(false)
    setTimeout(onClose, 260)
  }, [onClose])

  useEffect(() => {
    if (!open) return
    let active = true
    setLoading(true)
    fetchTopLevelComments(postId, user?.id ?? null, creator?.id ?? null, 0).then(res => {
      if (!active) return
      setComments(res.comments)
      setHasMore(res.hasMore)
      setPage(0)
      setLoading(false)
    })
    return () => { active = false }
  }, [open, postId, user?.id, creator?.id])

  // ── Deep-link into one comment (from a comment_reply/comment_like tap) ──
  const [pendingScrollId, setPendingScrollId] = useState<string | null>(null)
  const [flashId, setFlashId] = useState<string | null>(null)
  const rowRefs = useRef<Record<string, HTMLDivElement | null>>({})
  const registerRowRef = useCallback((id: string, el: HTMLDivElement | null) => {
    rowRefs.current[id] = el
  }, [])

  useEffect(() => {
    if (!open || !highlightCommentId || loading) return
    let active = true

    ;(async () => {
      const target = await fetchCommentById(highlightCommentId, user?.id ?? null, creator?.id ?? null)
      if (!active || !target) return

      const topLevelId = target.parent_id ?? target.id

      if (target.parent_id == null) {
        // Top-level: make sure it's actually in the loaded page (a like
        // notification can point at a comment further down than the
        // first page loaded).
        setComments(cs => (cs.some(c => c.id === target.id) ? cs : [target, ...cs]))
      } else {
        // A reply — its parent needs to be present and expanded before
        // there's anywhere on screen to scroll to.
        setComments(cs => (cs.some(c => c.id === topLevelId) ? cs : cs))
        const parent = await fetchCommentById(topLevelId, user?.id ?? null, creator?.id ?? null)
        if (!active) return
        if (parent) {
          setComments(cs => (cs.some(c => c.id === topLevelId) ? cs : [parent, ...cs]))
        }
        setExpanded(s => new Set(s).add(topLevelId))
        setRepliesByParent(m => {
          if (m[topLevelId]) return m
          fetchReplies(topLevelId, user?.id ?? null, creator?.id ?? null).then(rows => {
            if (active) setRepliesByParent(mm => ({ ...mm, [topLevelId]: rows }))
          })
          return m
        })
      }

      setPendingScrollId(target.id)
    })()

    return () => { active = false }
    // Deliberately only re-runs on the sheet opening with a new target —
    // comments/repliesByParent changing shouldn't re-trigger the fetch.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, highlightCommentId, loading])

  useEffect(() => {
    if (!pendingScrollId) return
    const el = rowRefs.current[pendingScrollId]
    if (!el) return // not mounted yet — this effect re-runs as rows render
    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    setFlashId(pendingScrollId)
    setPendingScrollId(null)
    const t = setTimeout(() => setFlashId(null), 1800)
    return () => clearTimeout(t)
  }, [pendingScrollId, comments, repliesByParent, expanded])

  // Every loaded body pooled into ONE mention lookup for the whole sheet.
  const allBodies = useMemo(
    () => [...comments, ...Object.values(repliesByParent).flat()].map(c => c.body),
    [comments, repliesByParent],
  )
  const mentions = useCommentMentions(allBodies)

  function bumpCount(delta: number) {
    setCount(c => Math.max(0, c + delta))
    onCountChange?.(delta)
  }

  async function loadMore() {
    const next = page + 1
    const res = await fetchTopLevelComments(postId, user?.id ?? null, creator?.id ?? null, next)
    setComments(c => [...c, ...res.comments])
    setHasMore(res.hasMore)
    setPage(next)
  }

  async function toggleReplies(parent: Comment) {
    const next = new Set(expanded)
    if (next.has(parent.id)) {
      next.delete(parent.id)
      setExpanded(next)
      return
    }
    next.add(parent.id)
    setExpanded(next)
    if (!repliesByParent[parent.id]) {
      const rows = await fetchReplies(parent.id, user?.id ?? null, creator?.id ?? null)
      setRepliesByParent(m => ({ ...m, [parent.id]: rows }))
    }
  }

  // Optimistic: the heart has to answer the tap immediately, and a failed
  // write just puts it back.
  async function handleToggleLike(target: Comment) {
    if (!user) return
    const liked = target.liked_by_me === true
    const delta = liked ? -1 : 1

    // If the viewer IS the post's author, their like is the creator like —
    // the badge has to appear on the same tap, not on the next open.
    const viewerIsCreator = !!creator && creator.id === user.id

    const apply = (c: Comment): Comment =>
      c.id === target.id
        ? {
            ...c,
            liked_by_me: !liked,
            likes_count: Math.max(0, (c.likes_count ?? 0) + delta),
            ...(viewerIsCreator ? { liked_by_creator: !liked } : {}),
          }
        : c

    setComments(cs => cs.map(apply))
    setRepliesByParent(m => {
      const out: Record<string, Comment[]> = {}
      for (const [k, v] of Object.entries(m)) out[k] = v.map(apply)
      return out
    })

    const ok = liked
      ? await unlikeComment(target.id, user.id)
      : await likeComment(target.id, user.id)

    if (!ok) {
      const revert = (c: Comment): Comment =>
        c.id === target.id
          ? {
              ...c,
              liked_by_me: liked,
              likes_count: Math.max(0, (c.likes_count ?? 0) - delta),
              ...(viewerIsCreator ? { liked_by_creator: liked } : {}),
            }
          : c
      setComments(cs => cs.map(revert))
      setRepliesByParent(m => {
        const out: Record<string, Comment[]> = {}
        for (const [k, v] of Object.entries(m)) out[k] = v.map(revert)
        return out
      })
      showToast({ message: 'Could not save that like.', icon: Heart, iconColor: '#ff4d6d' })
    }
  }

  function startReply(target: Comment) {
    // A reply to a reply belongs to the same parent — that is the one-level
    // rule, and the DB refuses anything deeper anyway.
    setReplyTo(target)
    setDraft(d => {
      const handle = target.author?.username ? `@${target.author.username} ` : ''
      return d.startsWith(handle) ? d : handle + d
    })
    inputRef.current?.focus()
  }

  async function handleSend() {
    const body = draft.trim()
    if (!body || !user || posting) return
    setPosting(true)
    setError('')

    const parentId = replyTo ? (replyTo.parent_id ?? replyTo.id) : null
    const { data, error: sendError } = await addComment(postId, user.id, body, false, parentId)

    if (sendError || !data) {
      setError(sendError?.message || 'Failed to post that comment. Please try again.')
      setPosting(false)
      return
    }

    const fresh: Comment = {
      ...(data as Comment),
      author: {
        id: user.id,
        username: profile?.username ?? 'you',
        display_name: profile?.display_name ?? null,
        avatar: profile?.avatar ?? '',
      },
      likes_count: 0,
      replies_count: 0,
      liked_by_me: false,
    }

    if (parentId) {
      setRepliesByParent(m => ({ ...m, [parentId]: [...(m[parentId] ?? []), fresh] }))
      setExpanded(s => new Set(s).add(parentId))
      setComments(cs => cs.map(c => (
        c.id === parentId ? { ...c, replies_count: (c.replies_count ?? 0) + 1 } : c
      )))
    } else {
      setComments(cs => [fresh, ...cs])
    }

    bumpCount(1)
    setDraft('')
    setReplyTo(null)
    setPickerQuery(null)
    setPosting(false)
    // Collapse the box back to one row now that the draft is cleared —
    // otherwise it stays stretched to whatever height the sent comment grew it to.
    if (inputRef.current) inputRef.current.style.height = 'auto'
    updateMissionProgress(user.id, 'comments_posted', 1).catch(console.error)
  }

  async function handleDelete(target: Comment) {
    setActionTarget(null)
    const { error: delError } = await deleteComment(target.id)
    if (delError) {
      showToast({ message: delError, icon: Trash2, iconColor: '#ff6b6b' })
      return
    }

    if (target.parent_id) {
      setRepliesByParent(m => ({
        ...m,
        [target.parent_id!]: (m[target.parent_id!] ?? []).filter(c => c.id !== target.id),
      }))
      setComments(cs => cs.map(c => (
        c.id === target.parent_id ? { ...c, replies_count: Math.max(0, (c.replies_count ?? 0) - 1) } : c
      )))
      bumpCount(-1)
    } else {
      // Deleting a parent cascades its replies in the DB, so the count
      // drops by the whole subtree, not by one.
      const lost = 1 + (target.replies_count ?? 0)
      setComments(cs => cs.filter(c => c.id !== target.id))
      setRepliesByParent(m => {
        const { [target.id]: _dropped, ...rest } = m
        return rest
      })
      bumpCount(-lost)
    }
    showToast({ message: 'Comment deleted', icon: Trash2, iconColor: 'var(--accent)' })
  }

  function handleDraftChange(value: string) {
    setDraft(value)
    // Typing "@" opens the picker; it closes as soon as the word ends.
    const match = /(?:^|\s)@([A-Za-z0-9_]*)$/.exec(value)
    setPickerQuery(match ? match[1] : null)
    // Auto-grow: reset to one row first so the box shrinks back down when
    // text is deleted, then measure the real content height and grow to
    // fit it (capped below in the JSX-side maxHeight/overflow so a very
    // long comment scrolls inside the box instead of pushing it off-screen).
    const el = inputRef.current
    if (el) {
      el.style.height = 'auto'
      el.style.height = `${el.scrollHeight}px`
    }
  }

  function insertMention(username: string) {
    setDraft(d => {
      const replaced = d.replace(/(?:^|\s)@([A-Za-z0-9_]*)$/, m => {
        const lead = m.startsWith(' ') ? ' ' : ''
        return `${lead}@${username} `
      })
      return replaced === d ? `${d}${d && !d.endsWith(' ') ? ' ' : ''}@${username} ` : replaced
    })
    setPickerQuery(null)
    inputRef.current?.focus()
  }

  if (!open) return null

  const canDelete = (c: Comment) => !!user && (c.author_id === user.id || isStaff)

  return createPortal(
    <>
      <div className="overlay-backdrop" onClick={close} style={{ zIndex: SHEET_Z - 1 }} />

      <div className="sheet-or-modal sheet-or-modal-over-dock" style={{ zIndex: SHEET_Z }}>
        <div
          className="neu-card sheet-or-modal-inner"
          style={{
            padding: 0, height: '78vh', display: 'flex', flexDirection: 'column', overflow: 'hidden',
            transform: visible ? 'translateY(0)' : 'translateY(100%)',
          }}
          onClick={e => e.stopPropagation()}
        >
          <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 8 }}>
            <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--surface3)' }} />
          </div>

          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '10px 14px 12px', borderBottom: '1px solid var(--border)' }}>
            <p style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--text)' }}>
              {count === 1 ? '1 comment' : `${count.toLocaleString()} comments`}
            </p>
            <button
              type="button"
              onClick={close}
              aria-label="Close comments"
              style={{ position: 'absolute', right: 12, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}
            >
              <X size={18} />
            </button>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '12px 14px 4px' }}>
            {!commentable ? (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '40px 20px', gap: 10 }}>
                <span style={{
                  width: 44, height: 44, borderRadius: '50%', display: 'flex', alignItems: 'center',
                  justifyContent: 'center', background: 'var(--surface2)', color: 'var(--text-dim)',
                }}>
                  <Lock size={19} />
                </span>
                <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>
                  Oops — the creator turned off comments
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                  Nobody can comment on this post right now.
                </p>
              </div>
            ) : loading ? (
              <p style={{ fontSize: 12.5, color: 'var(--text-dim)' }}>Loading comments…</p>
            ) : comments.length === 0 ? (
              <p style={{ fontSize: 12.5, color: 'var(--text-dim)' }}>No comments yet — be the first.</p>
            ) : (
              <>
                {comments.map(c => (
                  <div key={c.id}>
                    <CommentRow
                      comment={c}
                      viewerId={user?.id ?? null}
                      creator={creator}
                      mentions={mentions}
                      onReply={startReply}
                      onToggleLike={handleToggleLike}
                      onLongPress={setActionTarget}
                      flash={flashId === c.id}
                      registerRef={registerRowRef}
                    />

                    {(c.replies_count ?? 0) > 0 && (
                      <button
                        type="button"
                        onClick={() => toggleReplies(c)}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none',
                          cursor: 'pointer', color: 'var(--blue)', fontSize: 11.5, fontWeight: 700,
                          margin: '0 0 14px 42px', padding: 0,
                        }}
                      >
                        <span style={{ width: 18, height: 1, background: 'var(--border)' }} />
                        {expanded.has(c.id)
                          ? 'Hide replies'
                          : `View ${c.replies_count} ${c.replies_count === 1 ? 'reply' : 'replies'}`}
                      </button>
                    )}

                    {expanded.has(c.id) && (repliesByParent[c.id] ?? []).map(r => (
                      <CommentRow
                        key={r.id}
                        comment={r}
                        isReply
                        viewerId={user?.id ?? null}
                        creator={creator}
                        mentions={mentions}
                        onReply={startReply}
                        onToggleLike={handleToggleLike}
                        onLongPress={setActionTarget}
                        flash={flashId === r.id}
                        registerRef={registerRowRef}
                      />
                    ))}
                  </div>
                ))}

                {hasMore && (
                  <button
                    type="button"
                    onClick={loadMore}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', fontSize: 12, fontWeight: 700, padding: '4px 0 12px' }}
                  >
                    Load more comments
                  </button>
                )}
              </>
            )}
          </div>

          {commentable && user && (
            <div style={{ borderTop: '1px solid var(--border)', padding: '10px 14px calc(12px + env(safe-area-inset-bottom))' }}>
              {pickerQuery !== null && (
                <MentionPicker viewerId={user.id} query={pickerQuery} onPick={insertMention} />
              )}

              {replyTo && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8, fontSize: 11.5, color: 'var(--text-dim)' }}>
                  <CornerUpLeft size={13} />
                  <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    Replying to @{replyTo.author?.username || 'user'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setReplyTo(null)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}
                  >
                    <X size={13} />
                  </button>
                </div>
              )}

              {error && <p style={{ fontSize: 11, color: '#ff6b6b', marginBottom: 6 }}>{error}</p>}

              <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                <Avatar src={profile?.avatar} name={profile?.display_name || profile?.username || 'You'} ownerId={user.id} size={30} style={{ flex: 'none' }} />

                <div style={{ flex: 1, display: 'flex', alignItems: 'flex-end', gap: 8, background: 'var(--surface2)', borderRadius: 18, padding: '4px 10px 4px 12px' }}>
                  <textarea
                    ref={inputRef}
                    value={draft}
                    onChange={e => handleDraftChange(e.target.value)}
                    onKeyDown={e => {
                      // Enter sends, same as before; Shift+Enter still lets
                      // someone drop to a new line instead of posting early.
                      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
                    }}
                    placeholder={replyTo ? 'Write a reply…' : 'Add comment…'}
                    maxLength={300}
                    rows={1}
                    style={{
                      flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none',
                      color: 'var(--text)', fontSize: 13, padding: '7px 0', fontFamily: 'inherit',
                      resize: 'none', maxHeight: 120, overflowY: 'auto', lineHeight: 1.4,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setPickerQuery(q => (q === null ? '' : null))}
                    aria-label="Mention someone"
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: pickerQuery !== null ? 'var(--accent)' : 'var(--text-dim)', display: 'flex', flex: 'none', padding: '7px 0' }}
                  >
                    <AtSign size={17} />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleSend}
                  disabled={!draft.trim() || posting}
                  aria-label="Post comment"
                  style={{
                    flex: 'none', background: 'none', border: 'none', display: 'flex',
                    cursor: !draft.trim() || posting ? 'default' : 'pointer',
                    color: 'var(--accent)', opacity: !draft.trim() || posting ? 0.4 : 1,
                  }}
                >
                  <Send size={19} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {actionTarget && (
        <>
          <div className="overlay-backdrop" onClick={() => setActionTarget(null)} style={{ zIndex: SHEET_Z + 10 }} />
          <div className="sheet-or-modal sheet-or-modal-over-dock" style={{ zIndex: SHEET_Z + 11 }}>
            <div className="neu-card sheet-or-modal-inner" style={{ padding: 10 }} onClick={e => e.stopPropagation()}>
              <ActionRow
                icon={<CornerUpLeft size={16} />}
                label="Reply"
                onClick={() => { const t = actionTarget; setActionTarget(null); startReply(t) }}
              />
              <ActionRow
                icon={<Copy size={16} />}
                label="Copy text"
                onClick={() => {
                  navigator.clipboard?.writeText(actionTarget.body).catch(() => {})
                  setActionTarget(null)
                  showToast({ message: 'Copied', icon: Copy, iconColor: 'var(--accent)' })
                }}
              />
              {user && actionTarget.author_id !== user.id && (
                <ActionRow
                  icon={<Flag size={16} />}
                  label="Report"
                  onClick={() => { setReportTarget(actionTarget); setActionTarget(null) }}
                />
              )}
              {canDelete(actionTarget) && (
                <ActionRow
                  icon={<Trash2 size={16} />}
                  label="Delete"
                  danger
                  onClick={() => handleDelete(actionTarget)}
                />
              )}
            </div>
          </div>
        </>
      )}

      {reportTarget && user && (
        <ReportModal
          reporterId={user.id}
          targetType="comment"
          targetId={reportTarget.id}
          targetLabel={`comment by @${reportTarget.author?.username || 'user'}`}
          onClose={() => setReportTarget(null)}
        />
      )}

      <Toast toast={toast} zIndex={SHEET_Z + 20} />
    </>,
    document.body,
  )
}

function ActionRow({
  icon, label, onClick, danger,
}: { icon: React.ReactNode; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 10, background: 'none',
        border: 'none', borderRadius: 10, padding: '12px 10px', cursor: 'pointer',
        color: danger ? '#ff6b6b' : 'var(--text)', fontSize: 13.5, fontWeight: 600, textAlign: 'left',
      }}
    >
      {icon}
      {label}
    </button>
  )
}
