// src/features/posts/types.ts

export type PostAuthorType = 'user' | 'admin' | 'system'

export type PostKind = 'announcement' | 'feature_update' | 'general' | 'rank_tag' | 'blog_feature'

export type TagType =
  | 'achievement'
  /** The game itself, from the local GAMES catalog — taggable whether or
   *  not you've played it. Distinct from 'game_result', which is one
   *  specific session of yours and carries a score. */
  | 'game'
  | 'game_result'
  | 'multiplayer_result'
  | 'rank'
  | 'streak'
  | 'mission'
  | 'user'
  | 'avatar'
  | 'artifact'
  | 'mall_item'

export interface PostTag {
  type: TagType
  ref_id: string
  label: string
  /** Extra data needed to make the tag clickable — currently just game navigation. */
  meta?: { gameId?: string }
}

export interface PostAuthor {
  id: string | null
  username: string
  display_name: string | null
  avatar: string
  /** profiles.is_official — chillverse_official and similar house accounts.
   *  Drives the small verified checkmark next to the name on posts and
   *  comments (see PostCard.tsx / CommentSheet.tsx). Optional because rows
   *  read by older code paths won't have selected it. */
  is_official?: boolean
  /** profiles.is_halo_ai — the Halo AI account. Same checkmark as
   *  is_official, but a separate flag since is_official is limited to a
   *  single row (profiles_single_official). */
  is_halo_ai?: boolean
  /** profiles.is_groove_official — the groove house account. Same checkmark
   *  as is_official/is_halo_ai, its own singleton flag for the same reason
   *  (profiles_single_groove_official). */
  is_groove_official?: boolean
  /** profiles.is_pvp_official — the chillverse_pvp house account. Same
   *  checkmark as is_official/is_halo_ai/is_groove_official, its own
   *  singleton flag for the same reason (profiles_single_pvp_official). */
  is_pvp_official?: boolean
  /** profiles.is_warden_official — the warden house account. Same
   *  checkmark as is_official/is_halo_ai/is_groove_official/is_pvp_official,
   *  its own singleton flag for the same reason. */
  is_warden_official?: boolean
}

/** A house persona byline (see migration 0099/0100) — e.g. "Willam" — used
 *  in place of the real poster's name/avatar when post.persona_author_id
 *  is set. Joined client-side from `blog_personas`, same table the blog
 *  editor's persona picker reads from. */
export interface PostPersonaAuthor {
  id: string
  username: string
  display_name: string
  avatar: string | null
}

export interface Post {
  id: string
  author_id: string | null
  author_type: PostAuthorType
  /** Optional headline (migration 0101) — mainly for staff/system posts,
   *  used as the article title in the public Editorial Room. Null on
   *  regular user posts and on older staff posts predating this column. */
  title?: string | null
  body: string
  tags: PostTag[]
  likes_count: number
  /** Migration 0115. Pure counter — a repost does not copy the post into
   *  anyone's feed, it just bumps this and notifies the reposter's
   *  followers. Optional because rows written before 0115 won't have it. */
  reposts_count?: number
  comments_count: number
  influence: number
  commentable: boolean
  created_at: string
  hidden: boolean
  hidden_reason: string | null
  /** Real DB column (set by StaffComposer) — not previously on this type. */
  post_kind?: PostKind
  /** Set only when post_kind === 'rank_tag' — one of the 8 rank groups (see
   *  RANK_GROUP_IDS in src/features/profile/ranks.ts). */
  rank_tag_group?: string | null
  // attached image, if any (set by StaffComposer's uploadFeedImage — see staffPosts.ts)
  media_url?: string | null
  media_type?: 'image' | null
  /** Set only when post_kind === 'blog_feature' — a snapshot of the source
   *  blog_posts row taken at share time (see migration 0092). These are
   *  plain copied values, not a live join: the source article can later be
   *  edited, unpublished, or deleted with zero effect on this post. */
  blog_slug?: string | null
  blog_title?: string | null
  blog_excerpt?: string | null
  blog_hero_image_url?: string | null
  /** Set only on staff posts, when the staffer chose to "post as" a house
   *  persona instead of themselves (migration 0100). author_id/author_type
   *  are still the real poster for RLS/audit purposes — this is a display
   *  override only, resolved client-side into `persona_author` below. */
  persona_author_id?: string | null
  // joined client-side, not a real column
  author?: PostAuthor
  persona_author?: PostPersonaAuthor | null
  liked_by_me?: boolean
  reposted_by_me?: boolean
  /** Set when this post has a poll attached (migration 0131). Joined from
   *  post_polls in hydratePosts — one query per feed page, not per card. */
  poll_id?: string | null
}

/** What the viewer chose in the "not interested" sheet (migration 0115).
 *  'hide_post' affects this post only; the other two are about the author. */
export type NotInterestedChoice = 'hide_post' | 'mute_author' | 'reduce_author'

export interface Comment {
  id: string
  post_id: string
  author_id: string
  body: string
  created_at: string
  hidden: boolean
  hidden_reason: string | null
  /** Migration 0179a. Null on a top-level comment; otherwise the top-level
   *  comment this is a reply to. Replies are ONE level deep — a DB trigger
   *  refuses a parent that is itself a reply, so replying to a reply
   *  attaches to the same parent and only prefills the @name. */
  parent_id?: string | null
  /** Denormalised counters kept by triggers (0179a/0179b), same shape as
   *  posts.likes_count. Optional because rows read by older code paths
   *  won't have selected them. */
  likes_count?: number
  replies_count?: number
  // joined client-side, not a real column
  liked_by_me?: boolean
  /** True when the POST's author has liked this comment. Derived from a
   *  comment_likes row, not a column — see hydrateComments. */
  liked_by_creator?: boolean
  author?: PostAuthor
}

export interface PostingEligibility {
  /** Can post at all: profile picture + account 7 days old + not banned
   *  (migration 0182a — this used to mean "has Void"). */
  eligible: boolean
  is_void_plan: boolean
  has_profile_pic: boolean
  account_age_ok: boolean
  is_verified: boolean
  /** Can attach an image: eligible AND (verified OR active Void). */
  media_allowed: boolean
}

export interface TagSuggestion extends PostTag {
  /** true when this suggestion comes from something the user just did (shown first) */
  fromRecentEvent?: boolean
}
