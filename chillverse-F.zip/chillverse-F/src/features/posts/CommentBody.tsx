// src/features/posts/CommentBody.tsx
//
// Renders one comment's text with @mentions and game names lit up.
//
// Two deliberate differences from PostBody:
//  1. A mention opens the profile PREVIEW sheet, not /profile/:id — the
//     comment sheet stays open behind it, which is the whole point of a
//     quick look at who said something.
//  2. Game names link without a leading # (see mentionParsing's
//     bareGames option).
import { useNavigate } from 'react-router-dom'
import { tokenizeBody } from './mentionParsing'
import { useProfilePreviewOptional } from '../../context/ProfilePreview'
import type { MentionMap } from './useCommentMentions'

export default function CommentBody({
  body,
  mentions,
  size = 13.5,
}: {
  body: string
  mentions: MentionMap
  size?: number
}) {
  const navigate = useNavigate()
  const preview = useProfilePreviewOptional()

  const validUsernames = new Set(mentions.keys())
  const tokens = tokenizeBody(body, validUsernames, { bareGames: true })

  return (
    <p style={{ fontSize: size, color: 'var(--text)', lineHeight: 1.45, margin: '2px 0 0', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
      {tokens.map((t, i) => {
        if (t.type === 'mention') {
          const hit = mentions.get(t.username.toLowerCase())
          return (
            <span
              key={i}
              onClick={() => hit && preview?.openProfilePreview(hit.id)}
              style={{ color: 'var(--blue)', fontWeight: 700, cursor: hit ? 'pointer' : 'default' }}
            >
              {t.text}
            </span>
          )
        }
        if (t.type === 'game') {
          return (
            <span
              key={i}
              onClick={() => navigate('/games', { state: { previewGame: t.gameId } })}
              style={{ color: 'var(--blue)', fontWeight: 700, cursor: 'pointer' }}
            >
              {t.text}
            </span>
          )
        }
        return <span key={i}>{t.text}</span>
      })}
    </p>
  )
}
