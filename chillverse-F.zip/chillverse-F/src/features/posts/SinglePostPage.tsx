// src/features/posts/SinglePostPage.tsx
import { useEffect, useState } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { useAuth } from '../auth/useAuth'
import { usePageHeader } from '../../context/PageHeader'
import { fetchPostById } from './posts'
import PostCard from './PostCard'
import type { Post } from './types'

export default function SinglePostPage() {
  const navigate = useNavigate()
  const { postId } = useParams<{ postId: string }>()
  // Set only when a comment_reply/comment_like notification sent us here —
  // it tells PostCard to auto-open the comment sheet on that exact comment.
  const [searchParams] = useSearchParams()
  const highlightCommentId = searchParams.get('comment')
  const { user } = useAuth()
  const [post, setPost] = useState<Post | null>(null)
  const [loading, setLoading] = useState(true)

  usePageHeader({ title: 'Post', onBack: () => navigate('/feed') })

  useEffect(() => {
    if (!postId) return
    let active = true
    setLoading(true)
    fetchPostById(postId, user?.id ?? null).then(data => {
      if (active) { setPost(data); setLoading(false) }
    })
    return () => { active = false }
  }, [postId, user?.id])

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', paddingBottom: 56 }}>
      {/* Subtitle stays as page content — title + back button now live in
          the app Topbar via usePageHeader() (see
          PAGE_HEADER_MIGRATION_PLAN.md Phase 7). */}
      <div style={{ padding: '4px 20px 0', marginBottom: 16 }}>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>Shared from Chillverse</p>
      </div>

      <div style={{ padding: '0 20px' }}>
        {loading ? (
          <div className="neu-card" style={{ padding: 20, textAlign: 'center', color: 'var(--text-dim)', fontSize: 12.5 }}>
            Loading post…
          </div>
        ) : post ? (
          <PostCard
            post={post}
            onDeleted={() => navigate('/feed')}
            truncate={false}
            card={false}
            autoOpenCommentId={highlightCommentId}
          />
        ) : (
          <div className="neu-card" style={{ padding: 20, textAlign: 'center', color: 'var(--text-dim)', fontSize: 12.5 }}>
            This post doesn't exist or was deleted.
          </div>
        )}
      </div>
    </div>
  )
}
