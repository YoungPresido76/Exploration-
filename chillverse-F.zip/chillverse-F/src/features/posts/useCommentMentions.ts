// src/features/posts/useCommentMentions.ts
//
// Resolves every @mention across a WHOLE list of comments in one query.
//
// PostBody does this per body and fires one request per candidate — fine
// for a single post, brutal in a sheet holding 30 comments and their
// replies. Here the candidates from every loaded body are pooled,
// deduped, and looked up together; the result is a shared map each
// CommentBody reads from.
import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { extractMentionCandidates } from './mentionParsing'

export interface ResolvedMention {
  id: string
  username: string
}

/** Keyed by LOWERCASE username — mentions are matched case-insensitively. */
export type MentionMap = Map<string, ResolvedMention>

export function useCommentMentions(bodies: string[]): MentionMap {
  const [resolved, setResolved] = useState<MentionMap>(new Map())

  // Joined into one string so the effect doesn't re-run on every render
  // just because the caller rebuilt the array.
  const candidateKey = useMemo(() => {
    const all = new Set<string>()
    for (const body of bodies) {
      for (const c of extractMentionCandidates(body)) all.add(c.toLowerCase())
    }
    return [...all].sort().join(',')
  }, [bodies])

  useEffect(() => {
    const candidates = candidateKey ? candidateKey.split(',') : []
    if (candidates.length === 0) {
      setResolved(new Map())
      return
    }

    let active = true
    // The @mention grammar is [A-Za-z0-9_]+, so these values can't carry
    // the commas or dots that would break PostgREST's `or` syntax.
    const filter = candidates.map(c => `username.ilike.${c}`).join(',')

    supabase
      .from('profiles')
      .select('id, username')
      .or(filter)
      .then(({ data, error }) => {
        if (!active) return
        if (error) {
          console.error('useCommentMentions error:', error)
          return
        }
        const map: MentionMap = new Map()
        for (const row of data ?? []) {
          map.set(row.username.toLowerCase(), { id: row.id, username: row.username })
        }
        setResolved(map)
      })

    return () => { active = false }
  }, [candidateKey])

  return resolved
}
