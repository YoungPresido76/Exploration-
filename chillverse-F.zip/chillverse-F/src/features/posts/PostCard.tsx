// src/features/posts/PostCard.tsx
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { Heart, MessageCircle, Sparkles, MoreVertical, Share2, Trash2, Check, Flag, Repeat2, HeartCrack, ShieldAlert } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { useModRole } from '../moderation/useModRole'
import { toggleLike, toggleRepost, deletePost, submitNotInterested } from './posts'
import { takedownPost } from '../moderation/moderation'
import { ripple } from '../../shared/lib/ripple'
import CommentSheet from './CommentSheet'
import FollowButton from './FollowButton'
import InfluenceModal from './InfluenceModal'
import { AchievementTagInline, AchievementTagModal } from './AchievementTagPreview'
import PostBody from './PostBody'
import PostPollCard from './PostPollCard'
import { getTagColor } from './tagColor'
import ReportModal from '../safety/ReportModal'
import type { Post, PostTag, NotInterestedChoice } from './types'
import { getRankGroupInfo, type RankGroupId } from '../profile/ranks'
import HiddenContentNotice from '../moderation/HiddenContentNotice'
import Avatar from '../../shared/components/Avatar'
import VerifiedBadge from '../../shared/components/VerifiedBadge'
import { useProfilePreviewOptional } from '../../context/ProfilePreview'
import { updateMissionProgress } from '../missions/weeklyMissions'

const TAG_ICON: Record<string, string> = {
  achievement: '🏆', game: '🕹️', game_result: '🎮', multiplayer_result: '⚔️', rank: '🎖️',
  streak: '🔥', mission: '📋', user: '👤', avatar: '🖼️', artifact: '💎', mall_item: '🛍️',
}

// The three tag types that point at a game, all of which open it in the
// lobby. They still need meta.gameId to be present — older posts predating
// the composer persisting meta won't have it, so they render unclickable
// rather than navigating nowhere.
const isGameTag = (tag: PostTag) =>
  tag.type === 'game' || tag.type === 'game_result' || tag.type === 'multiplayer_result'

// Long-form staff posts (see migration 0100) get clipped on the card with a
// "Read more" link into /feed/:id (SinglePostPage), same shape as the blog
// card → blog article pattern. Regular user posts are capped at 500 chars
// server-side, so this never fires for them.
const CARD_TRUNCATE_AT = 600

export default function PostCard({ post, onDeleted, truncate = true, card = true, autoOpenCommentId = null }: { post: Post; onDeleted?: (postId: string) => void; truncate?: boolean; card?: boolean; autoOpenCommentId?: string | null }) {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { isStaff } = useModRole()
  const preview = useProfilePreviewOptional()
  const [liked, setLiked] = useState(post.liked_by_me ?? false)
  const [likesCount, setLikesCount] = useState(post.likes_count)
  const [reposted, setReposted] = useState(post.reposted_by_me ?? false)
  const [repostsCount, setRepostsCount] = useState(post.reposts_count ?? 0)
  const [notInterestedOpen, setNotInterestedOpen] = useState(false)
  // Set once the viewer picks an option — the card collapses to a short
  // confirmation in place rather than vanishing mid-scroll, which would
  // yank everything below it up under their thumb.
  const [dismissed, setDismissed] = useState(false)
  // A comment_reply/comment_like notification tap lands here already
  // wanting the sheet open on a specific comment.
  const [showComments, setShowComments] = useState(!!autoOpenCommentId)
  // Mirrors the sheet so the card's counter moves the moment a comment is
  // posted or deleted, without refetching the feed.
  const [commentsCount, setCommentsCount] = useState(post.comments_count)
  const [showInfluenceModal, setShowInfluenceModal] = useState(false)
  const [modalAchievementId, setModalAchievementId] = useState<string | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [confirmingDelete, setConfirmingDelete] = useState(false)
  // Staff takedown: hides the post with a public reason instead of deleting
  // it, so the timeline shows why and the author gets a notice they can
  // appeal. Only offered on other people's posts — a staff member removing
  // their own post is just a delete.
  const [takedownOpen, setTakedownOpen] = useState(false)
  const [takedownReason, setTakedownReason] = useState('it went against our Terms and Conditions')
  const [takingDown, setTakingDown] = useState(false)
  const [takedownError, setTakedownError] = useState<string | null>(null)
  const [takenDown, setTakenDown] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [linkCopied, setLinkCopied] = useState(false)
  const [reportOpen, setReportOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  const isAuthor = !!user && post.author_type === 'user' && post.author_id === user.id
  // Staff/mod/admin can delete any announcement/system post (RLS in
  // migration 0028 already allows this server-side) — not just their own.
  const isStaffPost = post.author_type === 'admin' || post.author_type === 'system'
  const canDelete = isAuthor || (isStaff && isStaffPost)
  const rankTagInfo = post.post_kind === 'rank_tag' && post.rank_tag_group
    ? getRankGroupInfo(post.rank_tag_group as RankGroupId)
    : null
  // See migration 0092 — blog_slug/title/excerpt/hero_image are a snapshot
  // taken at share time, not a live join, so this renders fine even if the
  // source article (or its category) was since edited, unpublished, or
  // deleted entirely.
  const isBlogFeature = post.post_kind === 'blog_feature' && !!post.blog_slug

  function goToBlogArticle() {
    if (post.blog_slug) navigate(`/blog/${post.blog_slug}`)
  }

  useEffect(() => {
    if (!menuOpen) return
    function handleOutsideClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false)
    }
    window.addEventListener('mousedown', handleOutsideClick)
    return () => window.removeEventListener('mousedown', handleOutsideClick)
  }, [menuOpen])

  const author = post.author
  // A staff post can be "posted as" a house persona (Willam) — see
  // migration 0100. When set, the persona's name/avatar take over the
  // byline entirely; author_type/author still reflect the real poster
  // underneath (for RLS/audit) so this is purely a display swap.
  const persona = post.persona_author
  const authorName = persona
    ? persona.display_name
    : post.author_type === 'system'
      ? 'Chillverse'
      : post.author_type === 'admin'
        ? (author?.display_name || author?.username || 'Admin')
        : (author?.display_name || author?.username || 'Unknown')

  const isSystemOrAdmin = post.author_type !== 'user' || !!persona
  // The popup names the account by handle. Falls back to the display name
  // on older posts whose author row didn't join (deleted account, etc.).
  const authorHandle = author?.username ? `@${author.username}` : authorName
  const singleAchievementTag = post.tags.length === 1 && post.tags[0].type === 'achievement' ? post.tags[0] : null

  const isClipped = truncate && post.body.length > CARD_TRUNCATE_AT
  // Cut at the last whole word before the limit so we don't slice a word in half.
  const clippedBody = isClipped
    ? `${post.body.slice(0, CARD_TRUNCATE_AT).replace(/\s+\S*$/, '')}…`
    : post.body

  async function handleLike() {
    if (!user) return
    const next = !liked
    setLiked(next)
    setLikesCount(c => c + (next ? 1 : -1))
    const ok = await toggleLike(post.id, user.id, liked)
    if (!ok) {
      setLiked(!next)
      setLikesCount(c => c + (next ? -1 : 1))
    } else if (next) {
      updateMissionProgress(user.id, 'posts_liked', 1).catch(console.error)
    }
  }

  async function handleRepost() {
    if (!user) return
    const next = !reposted
    setReposted(next)
    setRepostsCount(c => c + (next ? 1 : -1))
    const ok = await toggleRepost(post.id, user.id, reposted)
    if (!ok) {
      setReposted(!next)
      setRepostsCount(c => c + (next ? -1 : 1))
    }
  }

  async function handleNotInterested(choice: NotInterestedChoice) {
    if (!user) return
    setNotInterestedOpen(false)
    setDismissed(true)
    const ok = await submitNotInterested({
      userId: user.id, postId: post.id, authorId: post.author_id, choice,
    })
    // If the write failed, put the card back rather than leaving a
    // confirmation for something that didn't happen — the post would
    // reappear on the next refetch anyway, with no explanation.
    if (!ok) setDismissed(false)
  }

  function goToAuthorProfile() {
    if (isSystemOrAdmin || !post.author_id) return
    preview?.openProfilePreview(post.author_id)
  }

  function handleTagClick(tag: PostTag) {
    if (tag.type === 'achievement') { setModalAchievementId(tag.ref_id); return }
    if (isGameTag(tag) && tag.meta?.gameId) {
      // previewGame, not openGame: tapping a game tag while reading the
      // feed opens the game's detail sheet with its session count and Play
      // button. openGame would start a round on the spot and spend a
      // session on someone who was only curious what the post was about.
      navigate('/games', { state: { previewGame: tag.meta.gameId } })
      return
    }
    if (tag.type === 'user') {
      navigate(tag.ref_id === user?.id ? '/profile' : `/profile/${tag.ref_id}`)
    }
    // rank / streak / avatar / artifact / mission / mall_item — display only, no navigation target
  }

  function isClickableTag(tag: PostTag) {
    return tag.type === 'achievement' || tag.type === 'user' ||
      (isGameTag(tag) && !!tag.meta?.gameId)
  }

  async function handleShare() {
    const url = `${window.location.origin}/feed/${post.id}`
    const shareText = post.body.length > 100 ? `${post.body.slice(0, 100)}…` : post.body

    if (navigator.share) {
      setMenuOpen(false)
      try {
        await navigator.share({ title: `${authorName} on Chillverse`, text: shareText, url })
      } catch {
        // user cancelled the share sheet — no action needed
      }
      return
    }

    try {
      await navigator.clipboard.writeText(url)
      setLinkCopied(true)
      setTimeout(() => { setLinkCopied(false); setMenuOpen(false) }, 1200)
    } catch (e) {
      console.error('copy link error:', e)
      setMenuOpen(false)
    }
  }

  const canTakedown = isStaff && !isAuthor && !post.hidden && !takenDown

  async function handleTakedown() {
    if (!takedownReason.trim()) { setTakedownError('Please enter a reason.'); return }
    setTakingDown(true)
    const { error } = await takedownPost(post.id, takedownReason)
    setTakingDown(false)
    if (error) { setTakedownError(error); return }
    setTakedownOpen(false)
    setTakedownError(null)
    // Not onDeleted: the post stays in the feed as a takedown notice rather
    // than disappearing, which is the whole point. `post` is a prop and this
    // card won't be re-fetched until the feed reloads, so the notice is shown
    // from local state in the meantime.
    setTakenDown(true)
  }

  async function handleConfirmDelete() {
    setDeleting(true)
    const ok = await deletePost(post.id)
    setDeleting(false)
    setConfirmingDelete(false)
    if (ok) onDeleted?.(post.id)
  }

  if (dismissed) {
    return (
      <div className={card ? 'neu-card' : undefined} style={{ padding: 16, marginBottom: 12, textAlign: 'center' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-dim)' }}>
          Thanks — you'll see less like this.
        </p>
      </div>
    )
  }

  return (
    <div className={card ? 'neu-card' : undefined} style={{ ...(card ? { padding: 16, marginBottom: 12 } : {}), ...(rankTagInfo ? { background: `${rankTagInfo.color}0d`, border: `1px solid ${rankTagInfo.color}55`, ...(card ? {} : { padding: 16, borderRadius: 14 }) } : {}) }}>
      <div className="flex items-center gap-3">
        <Avatar
          src={persona ? persona.avatar : author?.avatar}
          name={authorName}
          userId={isSystemOrAdmin ? null : post.author_id}
          size={38}
          radius={12}
          disabled={isSystemOrAdmin}
          style={{ background: 'linear-gradient(135deg, var(--purple), var(--blue))' }}
        />
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="flex items-center">
            <button
              type="button"
              onClick={goToAuthorProfile}
              disabled={isSystemOrAdmin}
              style={{
                fontSize: 13.5, fontWeight: 700, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: 5,
                background: 'none', border: 'none', padding: 0, cursor: isSystemOrAdmin ? 'default' : 'pointer',
              }}
            >
              {authorName}
              {!isSystemOrAdmin && (author?.is_official || author?.is_halo_ai || author?.is_groove_official || author?.is_pvp_official || author?.is_warden_official) && <VerifiedBadge />}
              {isSystemOrAdmin && !persona && (
                <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--accent)', background: 'color-mix(in srgb, var(--accent) 12%, transparent)', padding: '1px 6px', borderRadius: 6 }}>
                  {post.author_type === 'system' ? 'SYSTEM' : 'ADMIN'}
                </span>
              )}
              {persona && (
                <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--accent)', background: 'color-mix(in srgb, var(--accent) 12%, transparent)', padding: '1px 6px', borderRadius: 6 }}>
                  STAFF
                </span>
              )}
              {rankTagInfo && (
                <span style={{ fontSize: 10, fontWeight: 700, color: rankTagInfo.color, background: `${rankTagInfo.color}22`, padding: '1px 6px', borderRadius: 6 }}>
                  @{rankTagInfo.label} Tag
                </span>
              )}
            </button>
            {user && !isSystemOrAdmin && post.author_id && (
              <FollowButton myId={user.id} authorId={post.author_id} />
            )}
          </div>
          <p style={{ fontSize: 11, color: 'var(--text-dim)' }}>
            {new Date(post.created_at).toLocaleString()}
          </p>
        </div>

        <div ref={menuRef} style={{ position: 'relative', flexShrink: 0 }}>
          <button
            type="button"
            onClick={() => setMenuOpen(o => !o)}
            style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', padding: 4 }}
          >
            <MoreVertical size={16} />
          </button>
          {menuOpen && (
            <div className="neu-card" style={{ position: 'absolute', right: 0, top: '110%', zIndex: 20, padding: 6, minWidth: 150 }}>
              <button
                type="button"
                onClick={handleShare}
                style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, background: 'none', border: 'none', padding: '8px 10px', borderRadius: 8, cursor: 'pointer', color: 'var(--text)', fontSize: 12.5, textAlign: 'left' }}
              >
                {linkCopied ? <Check size={14} color="var(--gold)" /> : <Share2 size={14} />}
                {linkCopied ? 'Link copied!' : 'Share'}
              </button>
              {canDelete && (
                <button
                  type="button"
                  onClick={() => { setMenuOpen(false); setConfirmingDelete(true) }}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, background: 'none', border: 'none', padding: '8px 10px', borderRadius: 8, cursor: 'pointer', color: 'var(--red)', fontSize: 12.5, textAlign: 'left' }}
                >
                  <Trash2 size={14} /> Delete
                </button>
              )}
              {canTakedown && (
                <button
                  type="button"
                  onClick={() => { setMenuOpen(false); setTakedownOpen(true) }}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, background: 'none', border: 'none', padding: '8px 10px', borderRadius: 8, cursor: 'pointer', color: 'var(--red)', fontSize: 12.5, textAlign: 'left' }}
                >
                  <ShieldAlert size={14} /> Take down
                </button>
              )}
              {!isAuthor && !isSystemOrAdmin && user && (
                <button
                  type="button"
                  onClick={() => { setMenuOpen(false); setNotInterestedOpen(true) }}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, background: 'none', border: 'none', padding: '8px 10px', borderRadius: 8, cursor: 'pointer', color: 'var(--text)', fontSize: 12.5, textAlign: 'left' }}
                >
                  <HeartCrack size={14} /> Not interested
                </button>
              )}
              {!isAuthor && !isSystemOrAdmin && user && (
                <button
                  type="button"
                  onClick={() => { setMenuOpen(false); setReportOpen(true) }}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, background: 'none', border: 'none', padding: '8px 10px', borderRadius: 8, cursor: 'pointer', color: 'var(--red)', fontSize: 12.5, textAlign: 'left' }}
                >
                  <Flag size={14} /> Report
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {post.hidden || takenDown ? (
        <HiddenContentNotice reason={post.hidden_reason ?? takedownReason} isOwner={isAuthor} variant="post" />
      ) : (
        <>
          {post.title && (
            <h3 style={{ fontSize: 15.5, fontWeight: 800, color: 'var(--text)', lineHeight: 1.35, margin: '10px 0 0' }}>
              {post.title}
            </h3>
          )}
          <PostBody body={isClipped ? clippedBody : post.body} />
          {isClipped && (
            <button
              type="button"
              onClick={() => navigate(`/feed/${post.id}`)}
              style={{
                background: 'none', border: 'none', padding: 0, marginTop: 4,
                color: 'var(--accent)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
              }}
            >
              Read more
            </button>
          )}
        </>
      )}

      {!post.hidden && isBlogFeature && (
        <button
          type="button"
          onClick={(e) => { ripple(e); goToBlogArticle() }}
          className="ripple-wrap"
          style={{
            display: 'flex', flexDirection: 'column', textAlign: 'left', cursor: 'pointer',
            background: 'var(--surface2)', border: 'none', borderRadius: 14,
            padding: 0, width: '100%', marginTop: 10, overflow: 'hidden',
          }}
        >
          {post.blog_hero_image_url && (
            <img
              src={post.blog_hero_image_url}
              alt=""
              loading="lazy"
              style={{ width: '100%', maxHeight: 220, objectFit: 'cover', display: 'block' }}
            />
          )}
          <div style={{ padding: 12 }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: 0.4 }}>
              📰 From the blog
            </span>
            <h4 style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', margin: '4px 0 0', lineHeight: 1.3 }}>
              {post.blog_title}
            </h4>
          </div>
        </button>
      )}

      {!post.hidden && !isBlogFeature && post.media_type === 'image' && post.media_url && (
        <img
          src={post.media_url}
          alt=""
          loading="lazy"
          style={{ width: '100%', maxHeight: 420, objectFit: 'cover', borderRadius: 14, marginTop: 10, display: 'block' }}
        />
      )}

      {!post.hidden && post.poll_id && (
        <PostPollCard pollId={post.poll_id} myId={user?.id ?? null} />
      )}

      {/* Single achievement tag gets the rich inline card; anything else gets compact chips. */}
      {singleAchievementTag ? (
        <div style={{ marginTop: 10 }}>
          <AchievementTagInline achievementId={singleAchievementTag.ref_id} />
        </div>
      ) : post.tags.length > 0 && (
        <div className="flex flex-wrap gap-2" style={{ marginTop: 10 }}>
          {post.tags.map((tag, i) => {
            const clickable = isClickableTag(tag)
            const color = getTagColor(tag)
            // A user tag (an @mention someone added via the tag picker) reads
            // as a plain mention, same as one typed inline in the body —
            // just blue text, no pill/border/icon — rather than a chip.
            if (tag.type === 'user') {
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => clickable && handleTagClick(tag)}
                  style={{
                    fontFamily: 'inherit', appearance: 'none', WebkitAppearance: 'none',
                    background: 'none', border: 'none', padding: 0, fontSize: 14, fontWeight: 700,
                    cursor: clickable ? 'pointer' : 'default',
                    color: color ?? 'var(--accent)',
                  }}
                >
                  {tag.label}
                </button>
              )
            }
            return (
              <button
                key={i}
                type="button"
                onClick={() => clickable && handleTagClick(tag)}
                className="chip"
                style={{
                  fontFamily: 'inherit', appearance: 'none', WebkitAppearance: 'none',
                  cursor: clickable ? 'pointer' : 'default',
                  textDecoration: clickable ? 'underline' : 'none', textUnderlineOffset: 2,
                  ...(color ? { color, borderColor: `${color}44` } : {}),
                }}
              >
                {TAG_ICON[tag.type] ?? '🏷️'} {tag.label}
              </button>
            )
          })}
        </div>
      )}

      <div className="flex items-center gap-4" style={{ marginTop: 12 }}>
        <button
          type="button"
          className="ripple-wrap"
          onClick={(e) => { ripple(e); handleLike() }}
          style={{
            display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none',
            cursor: 'pointer', color: liked ? 'var(--red)' : 'var(--text-dim)', fontSize: 12.5, fontWeight: 600,
          }}
        >
          <Heart size={15} fill={liked ? 'var(--red)' : 'none'} />
          {likesCount}
        </button>

        {/* The author sees the tally but can't repost themselves — their
            followers were already told about the post once. */}
        <button
          type="button"
          className={isAuthor ? undefined : 'ripple-wrap'}
          disabled={isAuthor || !user}
          onClick={(e) => { ripple(e); handleRepost() }}
          style={{
            display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none',
            cursor: isAuthor || !user ? 'default' : 'pointer',
            color: reposted ? '#3ecf8e' : 'var(--text-dim)', fontSize: 12.5, fontWeight: 600,
          }}
        >
          <Repeat2 size={16} />
          {repostsCount}
        </button>

        <button
          type="button"
          onClick={() => setShowComments(true)}
          style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 600 }}
        >
          <MessageCircle size={15} />
          {commentsCount}
        </button>

        {post.influence > 0 && (
          <button
            type="button"
            onClick={() => setShowInfluenceModal(true)}
            style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--gold)', fontWeight: 700, background: 'none', border: 'none', cursor: 'pointer' }}
          >
            <Sparkles size={12} /> {post.influence}
          </button>
        )}
      </div>

      {showComments && (
        <CommentSheet
          postId={post.id}
          commentable={post.commentable}
          highlightCommentId={autoOpenCommentId}
          creator={post.author_id && post.author
            ? {
                id: post.author_id,
                username: post.author.username,
                display_name: post.author.display_name,
                avatar: post.author.avatar,
              }
            : null}
          open={showComments}
          onClose={() => setShowComments(false)}
          initialCount={commentsCount}
          onCountChange={delta => setCommentsCount(c => Math.max(0, c + delta))}
        />
      )}

      <InfluenceModal
        open={showInfluenceModal}
        onClose={() => setShowInfluenceModal(false)}
        authorName={authorName}
        influence={post.influence}
      />

      {modalAchievementId && (
        <AchievementTagModal achievementId={modalAchievementId} onClose={() => setModalAchievementId(null)} />
      )}

      {confirmingDelete && createPortal(
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 120, padding: 20 }}
          onClick={() => !deleting && setConfirmingDelete(false)}
        >
          <div className="neu-card" style={{ width: '100%', maxWidth: 320, padding: 20, textAlign: 'center' }} onClick={e => e.stopPropagation()}>
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>Delete this post?</p>
            <p style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 6 }}>
              This can't be undone — comments and likes on it will be removed too.
            </p>
            <div className="flex items-center gap-3" style={{ marginTop: 16 }}>
              <button
                type="button"
                onClick={() => setConfirmingDelete(false)}
                disabled={deleting}
                style={{ flex: 1, padding: '10px 0', borderRadius: 10, background: 'var(--surface2)', border: 'none', color: 'var(--text)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: deleting ? 0.6 : 1 }}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={deleting}
                style={{ flex: 1, padding: '10px 0', borderRadius: 10, background: 'var(--red)', border: 'none', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: deleting ? 0.6 : 1 }}
              >
                {deleting ? 'Deleting…' : 'Delete'}
              </button>
            </div>
          </div>
        </div>,
        document.body,
      )}
      {takedownOpen && createPortal(
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 120, padding: 20 }}
          onClick={() => !takingDown && setTakedownOpen(false)}
        >
          <div className="neu-card" style={{ width: '100%', maxWidth: 340, padding: 20 }} onClick={e => e.stopPropagation()}>
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>Take this post down?</p>
            <p style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 6, lineHeight: 1.5 }}>
              The post stays in the feed as a notice. Everyone who scrolls past reads
              “This feed post was taken down, because …”, so write the reason as a clause.
              {authorHandle} gets a sheet with it on their next visit.
            </p>
            <input
              value={takedownReason}
              onChange={e => setTakedownReason(e.target.value)}
              placeholder="e.g. it violated our Terms and Conditions"
              style={{ width: '100%', marginTop: 12, padding: '9px 11px', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', fontSize: 12.5 }}
            />
            {takedownError && (
              <p style={{ fontSize: 11.5, color: 'var(--red)', marginTop: 8 }}>{takedownError}</p>
            )}
            <div className="flex items-center gap-3" style={{ marginTop: 16 }}>
              <button
                type="button"
                onClick={() => setTakedownOpen(false)}
                disabled={takingDown}
                style={{ flex: 1, padding: '10px 0', borderRadius: 10, background: 'var(--surface2)', border: 'none', color: 'var(--text)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: takingDown ? 0.6 : 1 }}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleTakedown}
                disabled={takingDown}
                style={{ flex: 1, padding: '10px 0', borderRadius: 10, background: 'var(--red)', border: 'none', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', opacity: takingDown ? 0.6 : 1 }}
              >
                {takingDown ? 'Taking down…' : 'Take down'}
              </button>
            </div>
          </div>
        </div>,
        document.body,
      )}
      {notInterestedOpen && user && createPortal(
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', zIndex: 120 }}
          onClick={() => setNotInterestedOpen(false)}
        >
          <div
            className="neu-card"
            style={{ width: '100%', maxWidth: 420, padding: 20, borderRadius: '20px 20px 0 0' }}
            onClick={e => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
              <HeartCrack size={26} color="var(--text-dim)" />
            </div>
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', textAlign: 'center' }}>
              We will not show you posts from {authorHandle} anymore
            </p>
            <p style={{ fontSize: 12, color: 'var(--text-dim)', textAlign: 'center', marginTop: 6 }}>
              Tell us why, so we get your feed right.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 16 }}>
              {([
                ['hide_post', 'I don\u2019t like the post'],
                ['mute_author', 'I don\u2019t like the user'],
                ['reduce_author', 'Reduce posts from the user'],
              ] as [NotInterestedChoice, string][]).map(([choice, label]) => (
                <button
                  key={choice}
                  type="button"
                  className="ripple-wrap"
                  onClick={(e) => { ripple(e); handleNotInterested(choice) }}
                  style={{
                    width: '100%', padding: '12px 14px', borderRadius: 12, textAlign: 'left',
                    background: 'var(--surface2)', border: '1px solid var(--border)',
                    color: 'var(--text)', fontSize: 13, fontWeight: 600, cursor: 'pointer',
                  }}
                >
                  {label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setNotInterestedOpen(false)}
              style={{ width: '100%', marginTop: 14, padding: '10px 0', borderRadius: 10, background: 'none', border: 'none', color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}
            >
              Cancel
            </button>
          </div>
        </div>,
        document.body,
      )}
      {reportOpen && user && (
        <ReportModal
          reporterId={user.id}
          targetType="post"
          targetId={post.id}
          targetLabel="this post"
          onClose={() => setReportOpen(false)}
        />
      )}
    </div>
  )
}
