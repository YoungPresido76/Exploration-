// src/features/posts/Composer.tsx
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { X, Sparkles, BarChart3, Plus, Trash2, ImagePlus, Lock } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { supabase } from '../../shared/lib/supabase'
import { usePostEligibility, lockedReasonText, mediaLockedReason } from './usePostEligibility'
import { getTagSuggestions } from './tagSuggestions'
import { createPost, uploadPostImage } from './posts'
import { tokenizeBody } from './mentionParsing'
import { getTagColor } from './tagColor'
import { ripple } from '../../shared/lib/ripple'
import { updateMissionProgress } from '../missions/weeklyMissions'
import TagAutosuggest from './TagAutosuggest'
import PostSubmitOverlay from './PostSubmitOverlay'
import Toast, { useToast } from '../../shared/components/Toast'
import { useFeatureFlags } from '../../shared/lib/featureFlags'
import type { PostPollVoteMode } from './postPolls'
import type { PostTag, TagSuggestion } from './types'

interface ComposerProps {
  open: boolean
  onClose: () => void
  onPosted: () => void
  /** Pass this when opening the composer right after an in-game event
   *  (e.g. a game win, achievement unlock) so it's pre-suggested at the top. */
  initialTag?: PostTag
}

// Textarea and its highlight backdrop must share these exact values pixel-for-pixel,
// or the colored text will visibly drift from what you're actually typing.
const TEXTAREA_BOX_STYLE = {
  padding: 12,
  fontSize: 14,
  lineHeight: '1.45',
  fontFamily: 'inherit',
} as const

// null hours = the poll never ends. The server treats a null duration the
// same way (closes_at stays null), so "Never" isn't a special case anywhere
// past this list.
const POLL_DURATIONS: { label: string; hours: number | null }[] = [
  { label: '1 day', hours: 24 },
  { label: '3 days', hours: 72 },
  { label: '7 days', hours: 168 },
  { label: 'Never', hours: null },
]

const pollFieldLabel = {
  fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)',
  textTransform: 'uppercase', letterSpacing: 0.3, margin: '0 0 6px',
} as const

function pollChipStyle(active: boolean) {
  return {
    padding: '7px 13px', borderRadius: 999, fontSize: 12, fontWeight: 700,
    cursor: 'pointer', fontFamily: 'inherit',
    border: active ? '1px solid var(--accent)' : '1px solid var(--border)',
    background: active ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'var(--surface)',
    color: active ? 'var(--accent)' : 'var(--text-dim)',
  } as const
}

export default function Composer({ open, onClose, onPosted, initialTag }: ComposerProps) {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { eligibility, loading: checkingEligibility } = usePostEligibility(open)
  const { isEnabled: isPostsFlagEnabled, getFlag: getPostsFlag } = useFeatureFlags()

  const [body, setBody] = useState('')
  const [tags, setTags] = useState<PostTag[]>(initialTag ? [initialTag] : [])
  const [commentable, setCommentable] = useState(false)
  const [tagQuery, setTagQuery] = useState('')
  const [suggestions, setSuggestions] = useState<TagSuggestion[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState('')
  // 'uploading' plays first only when there's an image still left to upload;
  // 'posting' always runs afterward with a hard 5s-minimum animated progress
  // (see runSubmit below). 'error' surfaces submitError inside the overlay
  // itself with a Retry button, rather than closing it.
  const [stage, setStage] = useState<'uploading' | 'posting' | 'error'>('posting')
  const [progress, setProgress] = useState(0)
  // Set once uploadPostImage succeeds so a Retry after a later createPost
  // failure doesn't upload the same image a second time.
  const uploadedMediaUrlRef = useRef<string | null>(null)
  const [followerUsernames, setFollowerUsernames] = useState<Set<string>>(new Set())
  const [visible, setVisible] = useState(false)

  // ── Image (optional, verified/Void only) ──
  // The File is held in memory and uploaded at SUBMIT time. Uploading on
  // pick would strand a file in the bucket every time someone changes
  // their mind or the browser discards the tab.
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const { toast, showToast } = useToast()

  // ── Poll (optional) ──
  const [pollOpen, setPollOpen] = useState(false)
  const [pollQuestion, setPollQuestion] = useState('')
  const [pollOptions, setPollOptions] = useState<string[]>(['', ''])
  const [pollVoteMode, setPollVoteMode] = useState<PostPollVoteMode>('single')
  // null = the poll never ends.
  const [pollDurationHours, setPollDurationHours] = useState<number | null>(24)

  useEffect(() => {
    if (!open) { setVisible(false); return }
    const raf = requestAnimationFrame(() => setVisible(true))
    return () => cancelAnimationFrame(raf)
  }, [open])

  // The dock is portaled to <body> at z-index 320, so it outranks this
  // sheet no matter what z-index the sheet claims — which is why the
  // composer used to sit above the dock (`.sheet-or-modal` anchors to
  // --dock-space) rather than over it, with the two competing for the
  // bottom of the screen. `cv-sheet-open` is the app's existing answer to
  // exactly this (Mall, AttackSheet, RegionMap, ProfilePreviewModal all
  // use it): the dock stands down entirely while a modal sheet owns the
  // screen, then springs back on close. Paired with the scroll lock so the
  // page doesn't drift underneath, and with .sheet-or-modal-over-dock
  // below, which drops the sheet to bottom: 0 now that nothing's there.
  //
  // Keyed on `open`, so cancelling or posting (both of which flip `open`
  // false via close()) brings the dock back on its own.
  useEffect(() => {
    if (!open) return
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = prevOverflow
      document.body.classList.remove('cv-sheet-open')
    }
  }, [open])

  function close() { setVisible(false); setTimeout(onClose, 280) }

  function pickImage(file: File | null) {
    if (imagePreview) URL.revokeObjectURL(imagePreview)
    setImageFile(file)
    setImagePreview(file ? URL.createObjectURL(file) : null)
  }

  // Object URLs leak until revoked.
  useEffect(() => () => { if (imagePreview) URL.revokeObjectURL(imagePreview) }, [imagePreview])

  const backdropRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Fetch once per open — who's allowed to light up as a valid @mention while typing.
  useEffect(() => {
    if (!open || !user) return
    let active = true
    supabase.from('follows').select('follower_id').eq('following_id', user.id).then(async ({ data }) => {
      const ids = (data ?? []).map(f => f.follower_id)
      if (ids.length === 0) { if (active) setFollowerUsernames(new Set()); return }
      const { data: profiles } = await supabase.from('profiles').select('username').in('id', ids)
      if (active) setFollowerUsernames(new Set((profiles ?? []).map(p => p.username.toLowerCase())))
    })
    return () => { active = false }
  }, [open, user])

  // typed tag search (debounced-lite via effect)
  useEffect(() => {
    if (!user || !open) return
    const handle = setTimeout(() => {
      getTagSuggestions(user.id, tagQuery).then(results => {
        const withRecent = initialTag && tagQuery === ''
          ? [{ ...initialTag, fromRecentEvent: true }, ...results]
          : results
        setSuggestions(withRecent)
      })
    }, 200)
    return () => clearTimeout(handle)
  }, [tagQuery, user, open, initialTag])

  if (!open) return null

  function addTag(s: TagSuggestion) {
    if (tags.some(t => t.type === s.type && t.ref_id === s.ref_id)) return
    // `meta` has to come along: it carries meta.gameId, which is the only
    // thing that makes a game tag clickable in the feed. Rebuilding the
    // tag field-by-field without it is why game tags used to render as
    // dead chips even when the suggestion had the id attached.
    setTags(t => [...t, { type: s.type, ref_id: s.ref_id, label: s.label, ...(s.meta ? { meta: s.meta } : {}) }])
    setTagQuery('')
  }

  function removeTag(i: number) {
    setTags(t => t.filter((_, idx) => idx !== i))
  }

  function updatePollOption(i: number, value: string) {
    setPollOptions(prev => prev.map((o, idx) => idx === i ? value : o))
  }

  function addPollOption() {
    setPollOptions(prev => prev.length >= 10 ? prev : [...prev, ''])
  }

  function removePollOption(i: number) {
    setPollOptions(prev => prev.length <= 2 ? prev : prev.filter((_, idx) => idx !== i))
  }

  function resetPoll() {
    setPollOpen(false)
    setPollQuestion('')
    setPollOptions(['', ''])
    setPollVoteMode('single')
    setPollDurationHours(24)
  }

  function syncScroll() {
    if (textareaRef.current && backdropRef.current) {
      backdropRef.current.scrollTop = textareaRef.current.scrollTop
    }
  }

  // A half-filled poll blocks posting rather than being silently dropped:
  // if someone opened the poll builder they meant to ask something, and
  // quietly posting without it is the worse surprise. "Remove" is right
  // there for changing their mind.
  const trimmedPollOptions = pollOptions.map(o => o.trim()).filter(Boolean)
  const pollReady = !pollOpen || (pollQuestion.trim().length > 0 && trimmedPollOptions.length >= 2)
  const canSubmit = !!body.trim() && pollReady && !submitting

  // Animates progress 0 -> 100 over a flat 5s, independent of network speed.
  // Callers await this alongside the real request so the "posting" stage
  // never closes before 5s even when the server replies instantly.
  function animatePostingProgress(): Promise<void> {
    return new Promise(resolve => {
      const durationMs = 5000
      const start = performance.now()
      function tick(now: number) {
        const pct = Math.min(100, ((now - start) / durationMs) * 100)
        setProgress(pct)
        if (pct < 100) requestAnimationFrame(tick)
        else resolve()
      }
      requestAnimationFrame(tick)
    })
  }

  async function runSubmit() {
    if (!user) return

    if (imageFile && !uploadedMediaUrlRef.current) {
      setStage('uploading')
      try {
        uploadedMediaUrlRef.current = await uploadPostImage(user.id, imageFile)
      } catch (err) {
        setSubmitError(err instanceof Error ? err.message : 'Could not upload that image.')
        setStage('error')
        return
      }
    }

    setStage('posting')
    setProgress(0)
    const [{ error }] = await Promise.all([
      createPost({
        authorId: user.id,
        body: body.trim(),
        tags,
        commentable,
        mediaUrl: uploadedMediaUrlRef.current,
        poll: pollOpen
          ? {
              question: pollQuestion.trim(),
              options: trimmedPollOptions,
              voteMode: pollVoteMode,
              durationHours: pollDurationHours,
            }
          : null,
      }),
      animatePostingProgress(),
    ])

    if (!error) {
      updateMissionProgress(user.id, 'posts_created', 1).catch(console.error)
      uploadedMediaUrlRef.current = null
      setSubmitting(false)
      setBody('')
      setTags([])
      setCommentable(false)
      pickImage(null)
      resetPoll()
      onPosted()
      close()
    } else {
      setSubmitError(error.message || 'Failed to post. Please try again.')
      setStage('error')
    }
  }

  function handleSubmit() {
    if (!user || !canSubmit) return
    if (!isPostsFlagEnabled('system:posts')) {
      setSubmitError(getPostsFlag('system:posts')?.toast_message || 'Failed to post. Please try again.')
      return
    }
    setSubmitError('')
    setSubmitting(true)
    runSubmit()
  }

  function handleRetry() {
    setSubmitError('')
    runSubmit()
  }

  const bodyTokens = tokenizeBody(body, followerUsernames)

  return createPortal(
    <>
      <div className="overlay-backdrop" onClick={submitting ? undefined : close} style={{ zIndex: 100 }} />
      {/* Mobile: bottom sheet | Desktop (lg+): centered modal */}
      <Toast toast={toast} zIndex={120} />
      <div className="sheet-or-modal sheet-or-modal-wide sheet-or-modal-over-dock" style={{ zIndex: 105 }}>
        <div
          className="neu-card sheet-or-modal-inner"
          style={{
            position: 'relative', padding: 18, maxHeight: '85vh', overflowY: 'auto',
            transform: visible ? 'translateY(0)' : 'translateY(100%)',
          }}
          onClick={e => e.stopPropagation()}
        >
        {submitting && (
          <PostSubmitOverlay stage={stage} progress={progress} errorMessage={submitError} onRetry={handleRetry} />
        )}
        <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
          <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)' }}>New Post</p>
          <button type="button" onClick={submitting ? undefined : close} disabled={submitting} style={{ background: 'none', border: 'none', cursor: submitting ? 'default' : 'pointer', color: 'var(--text-dim)', opacity: submitting ? 0.35 : 1 }}>
            <X size={18} />
          </button>
        </div>

        {checkingEligibility ? (
          <div style={{ padding: '24px 0', textAlign: 'center', color: 'var(--text-dim)', fontSize: 13 }}>
            Checking eligibility…
          </div>
        ) : eligibility && !eligibility.eligible ? (
          <div className="neu-inset" style={{ padding: 16, textAlign: 'center' }}>
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)' }}>
              {lockedReasonText(eligibility)}
            </p>
            {/* Posting is no longer a Void perk (0182a) — the only two
                things standing in the way are a profile picture and a
                week-old account, so the copy points at those instead of
                selling a plan that would not help. */}
            <p style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 6 }}>
              {!eligibility.has_profile_pic
                ? 'Set a profile picture to unlock posting.'
                : 'Your account needs to be 7 days old before you can post.'}
            </p>
            {!eligibility.has_profile_pic && (
              <button
                type="button"
                onClick={(e) => { ripple(e); close(); navigate('/profile') }}
                className="ripple-wrap"
                style={{ marginTop: 12, padding: '9px 20px', borderRadius: 10, border: 'none', background: 'var(--accent)', color: '#fff', fontWeight: 700, fontSize: 12.5, cursor: 'pointer' }}
              >
                Take me there
              </button>
            )}
          </div>
        ) : (
          <>
            {/* Highlighted textarea: a transparent-text textarea sits exactly on top of a
                styled backdrop that renders the same text with @mentions/#games colored.
                The two must stay pixel-identical (padding/font/line-height) and scroll in sync. */}
            <div style={{ position: 'relative', background: 'var(--surface2)', borderRadius: 12 }}>
              <div
                ref={backdropRef}
                aria-hidden
                style={{
                  ...TEXTAREA_BOX_STYLE,
                  position: 'absolute', inset: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                  overflow: 'hidden', pointerEvents: 'none', color: 'var(--text)',
                }}
              >
                {bodyTokens.map((t, i) => {
                  if (t.type === 'mention') return <span key={i} style={{ color: 'var(--accent)', fontWeight: 700 }}>{t.text}</span>
                  if (t.type === 'game') return <span key={i} style={{ color: 'var(--blue)', fontWeight: 700 }}>{t.text}</span>
                  return <span key={i}>{t.text}</span>
                })}
              </div>
              <textarea
                ref={textareaRef}
                value={body}
                onChange={e => setBody(e.target.value)}
                onScroll={syncScroll}
                maxLength={500}
                placeholder="What's happening?"
                rows={4}
                className="mention-textarea"
                style={{
                  ...TEXTAREA_BOX_STYLE,
                  position: 'relative', width: '100%', background: 'transparent', border: 'none',
                  color: 'transparent', caretColor: 'var(--text)', outline: 'none', resize: 'none',
                }}
              />
            </div>
            <style>{`.mention-textarea::placeholder { color: var(--text-muted); opacity: 1; }`}</style>

            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2" style={{ marginTop: 8 }}>
                {tags.map((t, i) => (
                  <span key={i} className="chip" style={{ display: 'flex', alignItems: 'center', gap: 5, ...(getTagColor(t) ? { color: getTagColor(t), borderColor: `${getTagColor(t)}44` } : {}) }}>
                    {t.label}
                    <button type="button" onClick={() => removeTag(i)} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0, display: 'flex' }}>
                      <X size={11} />
                    </button>
                  </span>
                ))}
              </div>
            )}

            <input
              value={tagQuery}
              onChange={e => setTagQuery(e.target.value)}
              placeholder="Tag an achievement, rank, game, friend…"
              style={{
                width: '100%', background: 'var(--surface2)', border: 'none', borderRadius: 10,
                padding: '8px 10px', fontSize: 12.5, color: 'var(--text)', outline: 'none', marginTop: 8,
              }}
            />
            <TagAutosuggest suggestions={suggestions} onPick={addTag} />

            {/* ── Image (optional) ── */}
            {imagePreview ? (
              <div style={{ position: 'relative', marginTop: 12 }}>
                <img
                  src={imagePreview}
                  alt="Attached"
                  style={{ width: '100%', maxHeight: 220, objectFit: 'cover', borderRadius: 12, display: 'block' }}
                />
                <button
                  type="button"
                  onClick={() => pickImage(null)}
                  aria-label="Remove image"
                  style={{
                    position: 'absolute', top: 8, right: 8, width: 28, height: 28, borderRadius: '50%',
                    border: 'none', background: 'rgba(0,0,0,0.6)', color: '#fff', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  // Greyed, not hidden: people should be able to see the
                  // feature exists and find out how to unlock it.
                  if (!eligibility?.media_allowed) {
                    showToast({ message: mediaLockedReason(eligibility), icon: Lock, iconColor: 'var(--accent)' })
                    return
                  }
                  imageInputRef.current?.click()
                }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6, marginTop: 12, padding: '7px 12px',
                  borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface2)',
                  color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
                  fontFamily: 'inherit', opacity: eligibility?.media_allowed ? 1 : 0.45,
                }}
              >
                <ImagePlus size={13} /> Add a photo
              </button>
            )}
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              hidden
              onChange={e => {
                const file = e.target.files?.[0] ?? null
                if (file) pickImage(file)
                e.target.value = ''
              }}
            />

            {/* ── Poll (optional) ── */}
            {!pollOpen ? (
              <button
                type="button"
                onClick={() => setPollOpen(true)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6, marginTop: 12, padding: '7px 12px',
                  borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface2)',
                  color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
                  fontFamily: 'inherit',
                }}
              >
                <BarChart3 size={13} /> Add a poll
              </button>
            ) : (
              <div style={{ marginTop: 12, padding: 12, borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
                <div className="flex items-center justify-between" style={{ marginBottom: 10 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, fontWeight: 800, color: 'var(--text)' }}>
                    <BarChart3 size={13} style={{ color: 'var(--accent)' }} /> Poll
                  </span>
                  <button
                    type="button"
                    onClick={resetPoll}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', fontSize: 11.5, fontWeight: 700 }}
                  >
                    Remove
                  </button>
                </div>

                <input
                  value={pollQuestion}
                  onChange={e => setPollQuestion(e.target.value)}
                  placeholder="What do you want to ask?"
                  maxLength={300}
                  style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 9, padding: '8px 11px', fontSize: 13, color: 'var(--text)', outline: 'none', marginBottom: 8 }}
                />

                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 6 }}>
                  {pollOptions.map((opt, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <input
                        value={opt}
                        onChange={e => updatePollOption(i, e.target.value)}
                        placeholder={`Option ${i + 1}`}
                        maxLength={80}
                        style={{ flex: 1, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 9, padding: '7px 11px', fontSize: 12.5, color: 'var(--text)', outline: 'none' }}
                      />
                      {pollOptions.length > 2 && (
                        <button
                          type="button"
                          onClick={() => removePollOption(i)}
                          aria-label={`Remove option ${i + 1}`}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', flexShrink: 0, display: 'flex' }}
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                {pollOptions.length < 10 && (
                  <button
                    type="button"
                    onClick={addPollOption}
                    style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent)', fontSize: 12, fontWeight: 700, padding: '2px 0', marginBottom: 10, fontFamily: 'inherit' }}
                  >
                    <Plus size={12} /> Add option
                  </button>
                )}

                <p style={pollFieldLabel}>Answers</p>
                <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                  {(['single', 'multi'] as PostPollVoteMode[]).map(mode => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setPollVoteMode(mode)}
                      style={{ ...pollChipStyle(pollVoteMode === mode), flex: 1 }}
                    >
                      {mode === 'single' ? 'Pick one' : 'Pick any number'}
                    </button>
                  ))}
                </div>

                <p style={pollFieldLabel}>Runs for</p>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {POLL_DURATIONS.map(d => (
                    <button
                      key={d.label}
                      type="button"
                      onClick={() => setPollDurationHours(d.hours)}
                      style={pollChipStyle(pollDurationHours === d.hours)}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <label className="flex items-center gap-2" style={{ marginTop: 12, cursor: 'pointer' }}>
              <input type="checkbox" checked={commentable} onChange={e => setCommentable(e.target.checked)} />
              <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>Allow comments on this post</span>
            </label>

            {submitError && (
              <p style={{ fontSize: 11.5, color: '#ff6b6b', marginTop: 10 }}>{submitError}</p>
            )}
            {pollOpen && !pollReady && (
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 10 }}>
                Your poll needs a question and at least 2 options — or remove it to post without one.
              </p>
            )}

            <button
              type="button"
              className="btn-primary ripple-wrap"
              onClick={(e) => { ripple(e); handleSubmit() }}
              disabled={!canSubmit}
              style={{ width: '100%', padding: '11px 0', marginTop: 14, opacity: canSubmit ? 1 : 0.5, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
            >
              <Sparkles size={14} /> {submitting ? 'Posting…' : 'Post'}
            </button>
          </>
        )}
        </div>
      </div>
    </>,
    document.body,
  )
}
