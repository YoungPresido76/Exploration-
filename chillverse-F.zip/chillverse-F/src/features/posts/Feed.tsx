// src/features/posts/Feed.tsx
import { useState } from 'react'
import { PenSquare } from 'lucide-react'
import { useFeed } from './useFeed'
import { useAuth } from '../auth/useAuth'
import { ripple } from '../../shared/lib/ripple'
import PostCard from './PostCard'
import FeedFollowStrip from './FeedFollowStrip'
import PremiumAdCard from './PremiumAdCard'
import Composer from './Composer'
import FeedSkeleton from './FeedSkeleton'
import FeatureFlagGate from '../../shared/components/FeatureFlagGate'
import type { PostTag } from './types'

// The follow-suggestions strip appears exactly once, right after this many
// posts — not repeated further down the feed.
const FOLLOW_STRIP_AFTER_POST = 6

// The Chillverse Premium ad card appears exactly once, earlier than the
// follow strip so it isn't competing with it for attention. PremiumAdCard
// itself no-ops (renders null) for Pro members, so no gating is needed here.
const PREMIUM_AD_AFTER_POST = 3

/**
 * Drop this into Dashboard.tsx. Pass `initialTag` when navigating here
 * right after an in-game event (win, achievement, rank-up) so the composer
 * opens with that tag pre-suggested — see Composer.tsx's `initialTag` prop.
 */
export default function Feed({ initialTag }: { initialTag?: PostTag }) {
  return (
    <FeatureFlagGate flagKey="system:posts">
      <FeedInner initialTag={initialTag} />
    </FeatureFlagGate>
  )
}

function FeedInner({ initialTag }: { initialTag?: PostTag }) {
  const { user } = useAuth()
  const { posts, loading, refetch, removePostLocally } = useFeed()
  const [composerOpen, setComposerOpen] = useState(false)

  return (
    <section className="su d3" style={{ marginTop: 12 }}>
      <div className="flex items-center justify-end" style={{ marginBottom: 10 }}>
        <button
          type="button"
          className="btn-secondary ripple-wrap"
          onClick={(e) => { ripple(e); setComposerOpen(true) }}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', fontSize: 12 }}
        >
          <PenSquare size={13} /> Post
        </button>
      </div>

      {loading ? (
        <FeedSkeleton />
      ) : posts.length === 0 ? (
        <div className="neu-card" style={{ padding: 20, textAlign: 'center', color: 'var(--text-dim)', fontSize: 12.5 }}>
          No posts yet — be the first to share something.
        </div>
      ) : (
        posts.map((post, i) => (
          <div key={post.id}>
            <PostCard post={post} onDeleted={removePostLocally} />
            {i === PREMIUM_AD_AFTER_POST - 1 && <PremiumAdCard />}
            {i === FOLLOW_STRIP_AFTER_POST - 1 && user?.id && (
              <FeedFollowStrip myId={user.id} />
            )}
          </div>
        ))
      )}

      <Composer
        open={composerOpen}
        onClose={() => setComposerOpen(false)}
        onPosted={refetch}
        initialTag={initialTag}
      />
    </section>
  )
}
