// src/features/posts/FeedPage.tsx
import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Rss, Camera, Megaphone } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import Feed from './Feed'
import AnnouncementsFeed from './AnnouncementsFeed'
import HighlightsFeed from '../highlights/HighlightsFeed'

type FeedTab = 'feed' | 'highlights' | 'announcements'

const TABS: { key: FeedTab; label: string; icon: typeof Rss }[] = [
  { key: 'feed', label: 'Feed', icon: Rss },
  { key: 'highlights', label: 'Highlights', icon: Camera },
  { key: 'announcements', label: 'Announcements', icon: Megaphone },
]

/**
 * Deep links (e.g. the "highlight_posted" notification route) still point
 * at /feed/highlights — this page renders for that path too (see App.tsx),
 * so on mount it opens straight to the Highlights tab instead of dropping
 * the visitor on Feed.
 */
function initialTabFromPath(pathname: string): FeedTab {
  return pathname.endsWith('/highlights') ? 'highlights' : 'feed'
}

export default function FeedPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const [tab, setTab] = useState<FeedTab>(() => initialTabFromPath(location.pathname))

  usePageHeader({ title: 'Community', onBack: () => navigate('/dashboard') })

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', paddingBottom: 56 }}>
      {/* Subtitle stays as page content below the Topbar — the title +
          back button themselves now live in the app Topbar via
          usePageHeader() (see PAGE_HEADER_MIGRATION_PLAN.md Phase 7). */}
      <div style={{ padding: '4px 20px 0', marginBottom: 16 }}>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>What the community's up to</p>
      </div>

      <div style={{ padding: '0 20px' }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 14, borderBottom: '1px solid var(--border)' }}>
          {TABS.map(t => {
            const Icon = t.icon
            const active = tab === t.key
            return (
              <button
                key={t.key}
                type="button"
                onClick={(e) => { ripple(e); setTab(t.key) }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6, padding: '10px 14px',
                  background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: 13, fontWeight: 700,
                  color: active ? 'var(--accent)' : 'var(--text-dim)',
                  borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
                  marginBottom: -1,
                }}
              >
                <Icon size={14} /> {t.label}
              </button>
            )
          })}
        </div>

        <style>{`
          @keyframes feedTabZoomOut {
            from { transform: scale(1.06); opacity: 0; }
            to   { transform: scale(1);    opacity: 1; }
          }
        `}</style>
        <div key={tab} style={{ animation: 'feedTabZoomOut 220ms ease-out' }}>
          {tab === 'feed' && <Feed />}
          {tab === 'highlights' && <HighlightsFeed />}
          {tab === 'announcements' && <AnnouncementsFeed />}
        </div>
      </div>
    </div>
  )
}
