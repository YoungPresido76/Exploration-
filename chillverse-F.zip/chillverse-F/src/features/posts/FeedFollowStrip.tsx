// src/features/posts/FeedFollowStrip.tsx
//
// The "who to follow" strip that lives inline in the Feed, appearing once
// after the 6th post (see Feed.tsx) — not the old always-visible block at
// the top of Search. Each person is their own card, not grouped under a
// shared title/dismiss — scrolling near the end fetches more people, and
// each card shows its own mutual-connection count (or nothing, if there
// isn't one) and its own X to dismiss just that person.
import { useEffect, useState } from 'react'
import type { MouseEvent, UIEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { X } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { ripple } from '../../shared/lib/ripple'
import { notifyFollow } from '../achievements/achievements'
import { trackWeeklyUniqueValue } from '../missions/weeklyMissions'
import { getFollowSuggestions, type FollowSuggestion } from '../search/search'
import Avatar from '../../shared/components/Avatar'

const PAGE_SIZE = 8
const LOAD_MORE_THRESHOLD_PX = 200

export default function FeedFollowStrip({ myId }: { myId: string }) {
  const navigate = useNavigate()

  const [people, setPeople] = useState<FollowSuggestion[]>([])
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [exhausted, setExhausted] = useState(false)
  const [following, setFollowing] = useState<Set<string>>(new Set())
  const [busy, setBusy] = useState<Set<string>>(new Set())

  useEffect(() => {
    let active = true
    setLoading(true)
    getFollowSuggestions(myId, { limit: PAGE_SIZE }).then(list => {
      if (!active) return
      setPeople(list)
      setLoading(false)
      if (list.length < PAGE_SIZE) setExhausted(true)
    })
    return () => { active = false }
  }, [myId])

  async function loadMore() {
    if (loadingMore || exhausted) return
    setLoadingMore(true)
    const more = await getFollowSuggestions(myId, { limit: PAGE_SIZE, excludeIds: people.map(p => p.id) })
    if (more.length === 0) {
      setExhausted(true)
    } else {
      setPeople(prev => [...prev, ...more])
      if (more.length < PAGE_SIZE) setExhausted(true)
    }
    setLoadingMore(false)
  }

  function onScroll(e: UIEvent<HTMLDivElement>) {
    const el = e.currentTarget
    if (el.scrollWidth - el.scrollLeft - el.clientWidth < LOAD_MORE_THRESHOLD_PX) {
      loadMore()
    }
  }

  function dismiss(e: MouseEvent<HTMLButtonElement>, id: string) {
    e.stopPropagation()
    ripple(e)
    setDismissedIds(prev => new Set(prev).add(id))
  }

  async function toggleFollow(e: MouseEvent<HTMLButtonElement>, id: string) {
    e.stopPropagation()
    ripple(e)
    if (busy.has(id)) return
    setBusy(prev => new Set(prev).add(id))
    const alreadyFollowing = following.has(id)
    if (alreadyFollowing) {
      await supabase.from('follows').delete().eq('follower_id', myId).eq('following_id', id)
      setFollowing(prev => { const next = new Set(prev); next.delete(id); return next })
    } else {
      await supabase.from('follows').insert({ follower_id: myId, following_id: id })
      await notifyFollow(id)
      trackWeeklyUniqueValue(myId, 'users_followed', id).catch(console.error)
      setFollowing(prev => new Set(prev).add(id))
    }
    setBusy(prev => { const next = new Set(prev); next.delete(id); return next })
  }

  const visiblePeople = people.filter(p => !dismissedIds.has(p.id))

  if (!loading && visiblePeople.length === 0) return null

  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.6, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: 10 }}>
        People you might know
      </div>

      {loading ? (
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', padding: '8px 0' }}>Finding people you may know…</p>
      ) : (
        <div
          onScroll={onScroll}
          style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 4, marginRight: -20, paddingRight: 20 }}
        >
          {visiblePeople.map(p => (
            <div
              key={p.id}
              role="button"
              tabIndex={0}
              onClick={() => navigate(`/profile/${p.id}`)}
              onKeyDown={e => { if (e.key === 'Enter') navigate(`/profile/${p.id}`) }}
              className="neu-card"
              style={{
                position: 'relative', flex: '0 0 168px', padding: '22px 14px 16px',
                display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
                cursor: 'pointer',
              }}
            >
              <button
                type="button"
                onClick={e => dismiss(e, p.id)}
                aria-label="Dismiss suggestion"
                style={{
                  position: 'absolute', top: 8, right: 8, width: 24, height: 24, borderRadius: '50%',
                  background: 'transparent', border: 'none', color: 'var(--text-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                }}
              >
                <X size={14} />
              </button>

              <Avatar src={p.avatar} name={p.display_name || p.username} size={64} radius="50%" />

              <div style={{
                fontSize: 14, fontWeight: 800, color: 'var(--text)', marginTop: 10,
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%',
              }}>
                {p.display_name || p.username}
              </div>

              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3, minHeight: 15 }}>
                {p.mutualCount > 0 ? `${p.mutualCount} mutual${p.mutualCount > 1 ? 's' : ''}` : ''}
              </div>

              <button
                type="button"
                onClick={e => toggleFollow(e, p.id)}
                disabled={busy.has(p.id)}
                style={{
                  marginTop: 12, width: '100%', padding: '8px 0', borderRadius: 10,
                  fontSize: 12, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase',
                  border: following.has(p.id) ? '1px solid rgba(255,255,255,0.12)' : 'none',
                  background: following.has(p.id) ? 'transparent' : 'var(--accent)',
                  color: following.has(p.id) ? 'var(--text-dim)' : '#fff',
                  cursor: 'pointer', opacity: busy.has(p.id) ? 0.6 : 1,
                }}
              >
                {following.has(p.id) ? 'Following' : 'Follow'}
              </button>
            </div>
          ))}

          {loadingMore && (
            <div style={{ flex: '0 0 40px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', fontSize: 11 }}>
              …
            </div>
          )}
        </div>
      )}
    </div>
  )
}
