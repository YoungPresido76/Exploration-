// src/features/posts/PostSubmitOverlay.tsx
import { Loader2, TriangleAlert } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'

interface PostSubmitOverlayProps {
  stage: 'uploading' | 'posting' | 'error'
  /** 0-100, only meaningful during the 'posting' stage. */
  progress: number
  errorMessage: string
  onRetry: () => void
}

// Sits absolutely over the composer's inner card (which sets position:
// relative for this) and blocks interaction with the form underneath while
// a post is going out. Composer also disables its own close button/backdrop
// while this is up, so the only way out of an error is Retry.
export default function PostSubmitOverlay({ stage, progress, errorMessage, onRetry }: PostSubmitOverlayProps) {
  return (
    <div
      style={{
        position: 'absolute', inset: 0, zIndex: 10, borderRadius: 'inherit',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'color-mix(in srgb, var(--surface) 94%, transparent)',
      }}
    >
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, padding: 24, textAlign: 'center' }}>
        {stage === 'error' ? (
          <>
            <TriangleAlert size={28} style={{ color: '#ff6b6b' }} />
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', maxWidth: 220 }}>{errorMessage}</p>
            <button
              type="button"
              className="btn-primary ripple-wrap"
              onClick={(e) => { ripple(e); onRetry() }}
              style={{ padding: '9px 22px', fontSize: 12.5, fontWeight: 700, border: 'none', cursor: 'pointer' }}
            >
              Retry
            </button>
          </>
        ) : stage === 'uploading' ? (
          <>
            <Loader2 size={32} className="spin" style={{ color: 'var(--accent)' }} />
            <p style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-dim)' }}>Uploading image…</p>
          </>
        ) : (
          <>
            <div style={{ position: 'relative', width: 56, height: 56, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Loader2 size={56} className="spin" style={{ color: 'var(--accent)', position: 'absolute' }} />
              <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--text)' }}>{Math.round(progress)}%</span>
            </div>
            <p style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-dim)' }}>Posting…</p>
          </>
        )}
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } } .spin { animation: spin 0.8s linear infinite; }`}</style>
    </div>
  )
}
