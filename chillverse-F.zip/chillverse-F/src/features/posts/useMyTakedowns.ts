// src/features/posts/useMyTakedowns.ts
//
// The author side of a feed-post takedown. Loads the notices this player
// hasn't seen yet, oldest first, and hands back one at a time — if two posts
// went while they were away they work through them in the order it happened
// rather than getting a stack to dismiss.
import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'

export interface PendingTakedown {
  id: string
  post_id: string
  /** The public reason clause a mod wrote, e.g. "it violated our Terms and
   *  Conditions". Rendered under a "Reason:" label. */
  reason: string
  /** First 140 characters of what they posted, so they can tell which one. */
  excerpt: string
  post_created_at: string | null
  taken_down_at: string
}

export function useMyTakedowns(userId: string | null) {
  const [queue, setQueue] = useState<PendingTakedown[]>([])
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    if (!userId) { setQueue([]); setLoaded(true); return }
    let active = true
    setLoaded(false)
    supabase.rpc('my_pending_takedowns').then(({ data }) => {
      if (!active) return
      setQueue((data ?? []) as PendingTakedown[])
      setLoaded(true)
    })
    return () => { active = false }
  }, [userId])

  /** Drops the front of the queue once the sheet has been closed or appealed.
   *  Both server calls mark it acknowledged, so this just mirrors that
   *  locally instead of re-fetching. */
  const advance = useCallback(() => {
    setQueue(q => q.slice(1))
  }, [])

  return { current: queue[0] ?? null, loaded, advance }
}
