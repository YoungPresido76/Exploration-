// src/features/posts/MentionPicker.tsx
//
// The "@" affordance in the comment composer. Tapping @ (or typing one)
// opens this list; picking someone inserts their exact handle, which is
// what makes the mention resolve and turn blue. That's the trade behind
// NOT auto-linking bare usernames: the picker does the exact-spelling
// work so the renderer doesn't have to guess.
import { useEffect, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import Avatar from '../../shared/components/Avatar'

interface PickerProfile {
  id: string
  username: string
  display_name: string | null
  avatar: string
}

export default function MentionPicker({
  viewerId,
  query,
  onPick,
}: {
  viewerId: string | null
  /** Text typed after the "@", or '' right after the button was tapped. */
  query: string
  onPick: (username: string) => void
}) {
  const [results, setResults] = useState<PickerProfile[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)

    const run = async () => {
      const trimmed = query.trim()

      // No query yet: suggest the people most likely to be meant — the
      // ones who follow you.
      if (!trimmed) {
        if (!viewerId) return active ? (setResults([]), setLoading(false), undefined) : undefined
        const { data: follows } = await supabase
          .from('follows')
          .select('follower_id')
          .eq('following_id', viewerId)
          .limit(20)
        const ids = (follows ?? []).map(f => f.follower_id as string)
        if (ids.length === 0) {
          if (active) { setResults([]); setLoading(false) }
          return
        }
        const { data } = await supabase
          .from('profiles')
          .select('id, username, display_name, avatar')
          .eq('is_bot', false)
          .in('id', ids)
          .limit(20)
        if (active) { setResults((data ?? []) as PickerProfile[]); setLoading(false) }
        return
      }

      const { data } = await supabase
        .from('profiles')
        .select('id, username, display_name, avatar')
        .eq('is_bot', false)
        .ilike('username', `${trimmed}%`)
        .limit(20)
      if (active) { setResults((data ?? []) as PickerProfile[]); setLoading(false) }
    }

    const handle = setTimeout(run, 180)
    return () => { active = false; clearTimeout(handle) }
  }, [query, viewerId])

  return (
    <div
      className="neu-card-sm"
      style={{ padding: 6, maxHeight: 200, overflowY: 'auto', marginBottom: 8 }}
      onClick={e => e.stopPropagation()}
    >
      {loading ? (
        <p style={{ fontSize: 12, color: 'var(--text-dim)', padding: '8px 6px' }}>Searching…</p>
      ) : results.length === 0 ? (
        <p style={{ fontSize: 12, color: 'var(--text-dim)', padding: '8px 6px' }}>No one found.</p>
      ) : (
        results.map(p => (
          <button
            key={p.id}
            type="button"
            onClick={() => onPick(p.username)}
            style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 9, textAlign: 'left',
              background: 'transparent', border: 'none', borderRadius: 8, padding: '6px 6px',
              cursor: 'pointer', color: 'var(--text)',
            }}
          >
            <Avatar src={p.avatar} name={p.display_name || p.username} ownerId={p.id} size={26} />
            <span style={{ flex: 1, minWidth: 0 }}>
              <span style={{ display: 'block', fontSize: 12.5, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {p.display_name || p.username}
              </span>
              <span style={{ display: 'block', fontSize: 11, color: 'var(--text-dim)' }}>@{p.username}</span>
            </span>
          </button>
        ))
      )}
    </div>
  )
}
