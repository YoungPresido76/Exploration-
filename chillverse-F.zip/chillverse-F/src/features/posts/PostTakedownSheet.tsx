// src/features/posts/PostTakedownSheet.tsx
//
// What the AUTHOR of a taken-down feed post sees the next time they open the
// app. Draws up from the bottom, and sits ahead of every promotional overlay
// in AppLayout's priority chain — a bounty poster or a What's New note
// shouldn't land on top of "your post was removed". Whatever loses that round
// isn't consumed; it shows once this is closed.
//
// Two ways out, both final for this notice: Close acknowledges it, Appeal
// acknowledges it AND flags it for the mod centre. Appeals carry no message
// by design — the flag says "I disagree", and that is the whole of it.
import { useEffect, useState } from 'react'
import { ShieldAlert, X } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { ripple } from '../../shared/lib/ripple'
import { formatDuration } from '../../shared/lib/localTime'
import type { PendingTakedown } from './useMyTakedowns'

interface PostTakedownSheetProps {
  takedown: PendingTakedown
  /** @username, shown in the greeting. */
  username: string
  /** Called after the server has recorded Close or Appeal. */
  onDone: () => void
}

/**
 * "3 hours ago on Friday".
 *
 * The weekday comes from Intl in the reader's own zone, never a hardcoded
 * string — a post made late on a Friday in Lagos was made on Friday for
 * someone in London and still Friday afternoon in Los Angeles, but only the
 * device knows which. Same rule the elimination copy follows.
 */
function whenPosted(iso: string | null): string {
  if (!iso) return 'earlier'
  const then = new Date(iso)
  if (Number.isNaN(then.getTime())) return 'earlier'
  const ago = formatDuration(Date.now() - then.getTime())
  const weekday = new Intl.DateTimeFormat(undefined, { weekday: 'long' }).format(then)
  return `${ago} ago on ${weekday}`
}

export default function PostTakedownSheet({ takedown, username, onDone }: PostTakedownSheetProps) {
  const [busy, setBusy] = useState(false)

  // The dock is portaled to <body> in its own stacking context, so z-index
  // alone can't outrank it — this is the same body lock every other sheet
  // uses (see body.cv-sheet-open in index.css).
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  async function run(rpc: 'ack_takedown' | 'appeal_takedown') {
    setBusy(true)
    // Advance regardless of the result: a failed acknowledge would otherwise
    // trap the player behind a sheet they can't dismiss, and the notice
    // simply reappears next session, which is the safe way to fail.
    await supabase.rpc(rpc, { p_id: takedown.id })
    setBusy(false)
    onDone()
  }

  return (
    <div
      className="sheet-or-modal sheet-or-modal-over-dock"
      style={{
        position: 'fixed', inset: 0, zIndex: 20000,
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        background: 'rgba(0,0,0,0.62)', backdropFilter: 'blur(3px)',
        animation: 'cvTakedownIn 0.2s ease',
      }}
    >
      <style>{`
        @keyframes cvTakedownIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes cvTakedownUp {
          from { opacity: 0; transform: translateY(30px) }
          to   { opacity: 1; transform: translateY(0) }
        }
      `}</style>

      <div
        style={{
          width: '100%', maxWidth: 460, padding: '24px 22px 26px',
          borderTopLeftRadius: 24, borderTopRightRadius: 24,
          background: 'var(--surface2)',
          borderTop: '1px solid rgba(255,77,77,0.3)',
          boxShadow: '0 -18px 50px rgba(0,0,0,0.5)',
          animation: 'cvTakedownUp 0.3s cubic-bezier(0.22,1,0.36,1)',
          position: 'relative',
        }}
      >
        {/* Close in the corner does the same thing as the Close button —
            dismissing is dismissing however you reach for it. */}
        <button
          type="button" onClick={() => { if (!busy) run('ack_takedown') }} disabled={busy}
          style={{
            position: 'absolute', top: 16, right: 16, background: 'none',
            border: 'none', cursor: busy ? 'default' : 'pointer', color: 'var(--text-muted)',
          }}
        >
          <X size={17} />
        </button>

        <div style={{
          width: 46, height: 46, borderRadius: 15, display: 'grid', placeItems: 'center',
          background: 'rgba(255,77,77,0.14)', border: '1px solid rgba(255,77,77,0.35)',
          marginBottom: 14,
        }}>
          <ShieldAlert size={22} color="#ff4d4d" />
        </div>

        <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', margin: 0, lineHeight: 1.45 }}>
          Hello @{username}, your feed post from {whenPosted(takedown.post_created_at)} has been taken down.
        </p>

        {takedown.excerpt.trim() !== '' && (
          <p style={{
            margin: '12px 0 0', padding: '10px 12px', borderRadius: 10,
            background: 'var(--surface)', border: '1px solid var(--border)',
            fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.5,
            fontStyle: 'italic',
          }}>
            “{takedown.excerpt}”
          </p>
        )}

        <p style={{ margin: '16px 0 0', fontSize: 11.5, fontWeight: 800, color: 'var(--text-muted)', letterSpacing: 0.4, textTransform: 'uppercase' }}>
          Reason
        </p>
        <p style={{ margin: '6px 0 0', fontSize: 13, color: 'var(--text)', lineHeight: 1.55 }}>
          {takedown.reason}
        </p>

        <div style={{ display: 'flex', gap: 10, marginTop: 22 }}>
          <button
            type="button"
            onClick={(e) => { ripple(e); if (!busy) run('appeal_takedown') }}
            disabled={busy}
            className="ripple-wrap"
            style={{
              flex: 1, padding: '12px 8px', borderRadius: 13, fontSize: 13, fontWeight: 700,
              border: '1px solid var(--border-strong)', background: 'var(--surface)',
              color: 'var(--text)', cursor: busy ? 'default' : 'pointer', opacity: busy ? 0.6 : 1,
            }}
          >
            Appeal
          </button>
          <button
            type="button"
            onClick={(e) => { ripple(e); if (!busy) run('ack_takedown') }}
            disabled={busy}
            className="ripple-wrap"
            style={{
              flex: 1, padding: '12px 8px', borderRadius: 13, fontSize: 13, fontWeight: 700,
              border: 'none', background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
              color: '#fff', cursor: busy ? 'default' : 'pointer', opacity: busy ? 0.6 : 1,
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )
}
