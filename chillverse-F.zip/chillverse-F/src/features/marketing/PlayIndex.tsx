// src/features/marketing/PlayIndex.tsx
//
// Public games directory at /play. Signed-out visitors (and crawlers) can
// read what every game is and how it works without an account — the app
// itself stays behind auth, this is the shop window for it.
//
// Live play counts come from public_game_stats(), a SECURITY DEFINER RPC
// that returns aggregate counts only (no user ids, no names). If the call
// fails the page renders fine without the numbers.

import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Nav from '../../layout/Nav'
import Footer from '../../layout/Footer'
import Seo from '../../shared/components/Seo'
import { supabase } from '../../shared/lib/supabase'
import { GAME_GUIDES } from './gameGuides'
import { getGameMeta } from '../games/games'

const SITE_URL = 'https://chillverse.com.ng'

export interface GameStatRow {
  game: string
  plays: number
  players: number
  top_score: number | null
}

const JSON_LD = [
  {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    name: 'Chillverse Games',
    url: `${SITE_URL}/play`,
    description:
      'Every game on Chillverse, with full rules, scoring and strategy for each one.',
    hasPart: GAME_GUIDES.map((g) => ({
      '@type': 'VideoGame',
      name: g.name,
      url: `${SITE_URL}/play/${g.slug}`,
      description: g.metaDescription,
      gamePlatform: 'Web browser',
      applicationCategory: 'Game',
    })),
  },
  {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Chillverse', item: `${SITE_URL}/` },
      { '@type': 'ListItem', position: 2, name: 'Games', item: `${SITE_URL}/play` },
    ],
  },
]

export default function PlayIndex() {
  const [stats, setStats] = useState<Record<string, GameStatRow>>({})

  useEffect(() => {
    let cancelled = false
    supabase
      .rpc('public_game_stats')
      .then(({ data }) => {
        if (cancelled || !data) return
        const map: Record<string, GameStatRow> = {}
        for (const row of data as GameStatRow[]) map[row.game] = row
        setStats(map)
      })
      // Stats are decoration — a failure here must never blank the page.
      .then(undefined, () => {})
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <div data-theme="midnight">
      <Seo
        title="Games"
        description="Every game on Chillverse — reflex tests, word games, trivia, block puzzles and a press-your-luck treasure dive. Full rules, scoring and tips for all twenty."
        path="/play"
        jsonLd={JSON_LD}
      />
      <Nav />

      <div className="max-w-5xl mx-auto px-5 md:px-10 pt-28 pb-20">
        <div className="mb-12">
          <div className="font-mono text-[11px] font-bold tracking-[2px] uppercase text-chill-violet mb-3">
            Games
          </div>
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-4">
            Twenty games, one universe
          </h1>
          <p className="text-[17px] text-chill-textSecondary leading-relaxed max-w-[620px]">
            Chillverse games are short, competitive and built for a phone. Every one of
            them tracks its own rank ladder, feeds the same XP pool, and gets harder as
            you climb. Here is what each one is and how to be good at it — no account
            needed to read.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {GAME_GUIDES.map((guide) => {
            const meta = getGameMeta(guide.dbKey)
            const stat = stats[guide.dbKey]
            return (
              <Link
                key={guide.slug}
                to={`/play/${guide.slug}`}
                className="glass-panel rounded-2xl p-6 no-underline block hover:border-chill-violetSoft transition-colors"
                style={{ borderLeft: `3px solid ${meta?.accent ?? '#9b6dff'}` }}
              >
                <div className="flex items-baseline justify-between gap-3 mb-2">
                  <h2 className="text-[18px] font-bold text-chill-text">{guide.name}</h2>
                  {meta?.category && (
                    <span className="text-[11px] font-mono uppercase tracking-wider text-chill-textMuted shrink-0">
                      {meta.category}
                    </span>
                  )}
                </div>
                <p className="text-[14px] leading-relaxed text-chill-textSecondary mb-4">
                  {meta?.tagline}
                </p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-chill-textMuted font-mono">
                  {meta?.difficulty && <span>{meta.difficulty}</span>}
                  <span>
                    {meta?.unlimitedPlays
                      ? 'unlimited plays'
                      : `${meta?.sessionCost ?? 1} session${(meta?.sessionCost ?? 1) === 1 ? '' : 's'}`}
                  </span>
                  {stat && <span>{stat.plays.toLocaleString()} plays</span>}
                  {meta?.requiresPro && <span className="text-chill-violetSoft">Pro only</span>}
                </div>
              </Link>
            )
          })}
        </div>

        <div className="bg-chill-surface border border-chill-border rounded-2xl p-7 text-center mt-12">
          <h2 className="text-lg font-bold mb-2">Ready to play?</h2>
          <p className="text-sm text-chill-textSecondary mb-5">
            Every game is free to play. Sign up and your first sessions are waiting.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link
              to="/about"
              className="px-5 py-2.5 rounded-full text-sm font-semibold border border-chill-border text-chill-text no-underline"
            >
              About Chillverse
            </Link>
            <Link
              to="/signup"
              className="px-5 py-2.5 rounded-full text-sm font-bold text-white bg-gradient-to-br from-chill-violet to-[#3d1fb5] no-underline"
            >
              Sign up free →
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
