// src/features/marketing/Version.tsx
//
// The Versions page. This used to sell purchasable version tiers, then
// spent a while as a "coming soon" teaser card floating in the middle of
// an empty screen. Neither is true any more: versions ship now, and this
// is the page where you switch them on.
//
// It's a PAGE, not a modal. AppLayout already renders the "Version"
// topbar for this route, so there is no header, no close button and no
// card to dismiss — you leave with the back arrow like every other page.
//
// The old close handler fired a `version_coming_soon` notification every
// single time you left. That promise has been kept, so it's gone.
import { useState } from 'react'
import { Box, Loader2, Sparkles } from 'lucide-react'
import { useProfile } from '../profile/useProfile'
import PageOnboarding from '../onboarding/PageOnboarding'
import Toast, { useToast } from '../../shared/components/Toast'
import { useHoloToggle, HOLO_EFFECT_NOTICE } from '../holo/holoVersion'

/** One shipped version. Open to every account. */
function VersionRow({
  initial, hasCardEffect, onToast,
}: {
  initial: boolean
  hasCardEffect: boolean
  onToast: (msg: string) => void
}) {
  const { on, busy, set } = useHoloToggle(initial)
  const [noticeShown, setNoticeShown] = useState(false)

  async function tap() {
    if (busy) return
    const next = !on
    const res = await set(next)
    if (!res.ok) { onToast(res.error ?? 'Could not save that'); return }

    // Once per switch-on, not every time — a warning that never goes
    // away stops being read.
    if (next && hasCardEffect && !noticeShown) {
      setNoticeShown(true)
      onToast(HOLO_EFFECT_NOTICE)
      return
    }
    onToast(next ? 'Dynamic Profile is live' : 'Dynamic Profile switched off')
  }

  const live = on

  return (
    <button
      type="button"
      onClick={tap}
      disabled={busy}
      style={{
        width: '100%', textAlign: 'left', padding: '15px 16px',
        borderRadius: 'var(--radius)', cursor: busy ? 'wait' : 'pointer',
        background: live
          ? 'linear-gradient(135deg, rgba(155,109,255,0.16), rgba(79,142,247,0.09))'
          : 'var(--surface)',
        border: `1px solid ${live ? 'rgba(201,167,255,0.45)' : 'var(--border)'}`,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 42, height: 42, borderRadius: 13, flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: live ? 'rgba(155,109,255,0.22)' : 'var(--surface2)',
          border: `1px solid ${live ? 'rgba(201,167,255,0.45)' : 'var(--border)'}`,
          color: live ? '#c9a7ff' : 'var(--text-muted)',
        }}>
          {busy ? <Loader2 size={18} className="spin" /> : <Box size={19} />}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>v1.0 · Dynamic Profile</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 3, lineHeight: 1.45 }}>
            {live
              ? 'On — everyone who opens your profile sees it this way'
              : 'Your profile, reskinned into something with depth'}
          </div>
        </div>

        <span style={{
          width: 46, height: 27, borderRadius: 20, flexShrink: 0, position: 'relative',
          background: on ? '#9b6dff' : 'var(--surface3)',
          transition: 'background .2s ease', display: 'block',
        }}>
          <span style={{
            position: 'absolute', top: 3, left: on ? 22 : 3,
            width: 21, height: 21, borderRadius: '50%', background: '#fff',
            transition: 'left .2s cubic-bezier(.4,0,.2,1)', display: 'block',
          }} />
        </span>
      </div>
    </button>
  )
}

export default function Version() {
  const { profile } = useProfile()
  const { toast, showToast } = useToast(3400)

  return (
    <>
      <PageOnboarding pageKey="version" />

      <div style={{ padding: '16px 16px 32px', maxWidth: 560, margin: '0 auto' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.6, margin: '0 2px 18px' }}>
          Versions are new ways your profile can work. Switch one on and it applies
          everywhere your profile is opened.
        </p>

        <p style={{
          fontSize: 10, fontWeight: 800, letterSpacing: 1, textTransform: 'uppercase',
          color: 'var(--text-muted)', margin: '0 2px 9px',
        }}>
          Released
        </p>

        <VersionRow
          initial={!!profile?.holo_profile_enabled}
          hasCardEffect={!!profile?.equipped_profile_effect_url}
          onToast={message => showToast({ message, icon: Sparkles, iconColor: '#9b6dff' })}
        />

        <p style={{
          fontSize: 10, fontWeight: 800, letterSpacing: 1, textTransform: 'uppercase',
          color: 'var(--text-muted)', margin: '22px 2px 9px',
        }}>
          Next
        </p>
        <div style={{
          padding: '15px 16px', borderRadius: 'var(--radius)',
          background: 'var(--surface)', border: '1px dashed var(--border-strong)',
        }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-dim)' }}>v2.0</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 3 }}>
            In the works. It'll show up here the day it's ready.
          </div>
        </div>
      </div>

      <Toast toast={toast} zIndex={25000} />
    </>
  )
}
