// src/features/marketing/gameGuides.ts
//
// Typed accessor for the public /play page copy.
//
// WHY THE DATA IS JSON
// --------------------
// The copy itself lives in src/shared/content/gameGuides.json so that BOTH
// the React pages and scripts/prerender.mjs can read the same file. The
// prerender script is plain Node and cannot import a .ts module, and the
// alternative — duplicating ~8,000 words of copy into the build script —
// guarantees the crawlable version drifts from what visitors actually see.
// One file, two consumers, no sync problem.
//
// WHAT THESE PAGES ARE FOR
// ------------------------
// Everything worth reading on Chillverse sits behind the login wall and is
// Disallowed in robots.txt, so a crawler (or an AdSense reviewer) only ever
// sees the landing page, the legal pages and the blog. These guides turn the
// ~20 games we already built into real, public, indexable pages.
//
// The rules and numbers in the JSON are read out of each game's own source
// in src/features/games/play/. If you retune a game — XP per correct answer,
// round timers, lives, rank ladders — update the matching entry too, or the
// public page starts lying to people.

import guides from '../../shared/content/gameGuides.json'

export interface GuideTip {
  title: string
  body: string
}

export interface GuideFaq {
  q: string
  a: string
}

export interface GameGuide {
  /** URL segment: /play/<slug>. Never the same as dbKey — see Last Card. */
  slug: string
  /** game_sessions.game value, used to look up live stats. */
  dbKey: string
  /** GameMeta.id from games.ts, used for the "Play now" deep link. */
  gameId: string
  name: string
  metaTitle: string
  metaDescription: string
  intro: string[]
  howToPlay: string[]
  scoring: string[]
  tips: GuideTip[]
  faq: GuideFaq[]
  /**
   * Some games store something other than a score in game_sessions.score
   * (Last Card stores a win flag), so the top-score stat is meaningless
   * there and gets hidden rather than shown as a confusing "1".
   */
  showTopScore?: boolean
  scoreLabel?: string
}

export const GAME_GUIDES = guides as GameGuide[]

export const GUIDES_BY_SLUG: Record<string, GameGuide> = Object.fromEntries(
  GAME_GUIDES.map((g) => [g.slug, g]),
)

export function getGuide(slug: string | undefined): GameGuide | undefined {
  return slug ? GUIDES_BY_SLUG[slug] : undefined
}
