// src/features/marketing/PlayGame.tsx
//
// Public page for one game: /play/<slug>. Readable signed out, which is the
// whole point — this is the only place a crawler or a curious visitor can
// find out what a Chillverse game actually is.
//
// The "Play now" button deep-links into the authed Game Zone with the game
// pre-opened, the same shape Multiplayer.tsx already uses. Signed-out users
// land on the login screen and come back here afterwards.

import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import Nav from '../../layout/Nav'
import Footer from '../../layout/Footer'
import Seo from '../../shared/components/Seo'
import { supabase } from '../../shared/lib/supabase'
import { getGuide, GAME_GUIDES } from './gameGuides'
import { getGameMeta } from '../games/games'
import type { GameStatRow } from './PlayIndex'

const SITE_URL = 'https://chillverse.com.ng'

export default function PlayGame() {
  const { slug } = useParams<{ slug: string }>()
  const navigate = useNavigate()
  const guide = getGuide(slug)
  const meta = guide ? getGameMeta(guide.dbKey) : undefined
  const [stat, setStat] = useState<GameStatRow | null>(null)

  useEffect(() => {
    if (!guide) return
    let cancelled = false
    supabase
      .rpc('public_game_stats')
      .then(({ data }) => {
        if (cancelled || !data) return
        const row = (data as GameStatRow[]).find((r) => r.game === guide.dbKey)
        setStat(row ?? null)
      })
      .then(undefined, () => {})
    return () => {
      cancelled = true
    }
  }, [guide])

  if (!guide) {
    return (
      <div data-theme="midnight">
        <Seo title="Game not found" description="That game does not exist on Chillverse." path="/play" noindex />
        <Nav />
        <div className="max-w-3xl mx-auto px-5 md:px-10 pt-28 pb-20 text-center">
          <h1 className="text-2xl font-bold mb-4">We don't have a game by that name</h1>
          <Link to="/play" className="text-chill-violetSoft hover:underline">
            See all Chillverse games →
          </Link>
        </div>
        <Footer />
      </div>
    )
  }

  const accent = meta?.accent ?? '#9b6dff'
  const url = `${SITE_URL}/play/${guide.slug}`

  const jsonLd = [
    {
      '@context': 'https://schema.org',
      '@type': 'VideoGame',
      name: guide.name,
      url,
      description: guide.metaDescription,
      gamePlatform: 'Web browser',
      applicationCategory: 'Game',
      operatingSystem: 'Any',
      genre: meta?.category,
      playMode: 'SinglePlayer',
      publisher: { '@type': 'Organization', name: 'Chillverse', url: SITE_URL },
      ...(meta?.bannerUrl ? { image: meta.bannerUrl } : {}),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'HowTo',
      name: `How to play ${guide.name}`,
      step: guide.howToPlay.map((text, i) => ({
        '@type': 'HowToStep',
        position: i + 1,
        text,
      })),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: guide.faq.map((item) => ({
        '@type': 'Question',
        name: item.q,
        acceptedAnswer: { '@type': 'Answer', text: item.a },
      })),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Chillverse', item: `${SITE_URL}/` },
        { '@type': 'ListItem', position: 2, name: 'Games', item: `${SITE_URL}/play` },
        { '@type': 'ListItem', position: 3, name: guide.name, item: url },
      ],
    },
  ]

  const others = GAME_GUIDES.filter((g) => g.slug !== guide.slug).slice(0, 6)

  return (
    <div data-theme="midnight">
      <Seo
        title={guide.metaTitle}
        description={guide.metaDescription}
        path={`/play/${guide.slug}`}
        ogImage={meta?.bannerUrl}
        jsonLd={jsonLd}
      />
      <Nav />

      <div className="max-w-3xl mx-auto px-5 md:px-10 pt-28 pb-20">
        <Link to="/play" className="text-[13px] text-chill-textMuted no-underline hover:underline">
          ← All games
        </Link>

        <div className="mt-5 mb-10">
          <div
            className="font-mono text-[11px] font-bold tracking-[2px] uppercase mb-3"
            style={{ color: accent }}
          >
            {meta?.category ?? 'Game'}
          </div>
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-4">{guide.name}</h1>
          <p className="text-[17px] text-chill-textSecondary leading-relaxed">{meta?.tagline}</p>
        </div>

        {meta?.bannerUrl && (
          <img
            src={meta.bannerUrl}
            alt={`${guide.name} on Chillverse`}
            loading="lazy"
            className="w-full rounded-2xl mb-10 border border-chill-border"
          />
        )}

        {/* Facts strip — the live numbers make this page unlike anyone else's. */}
        <div className="flex flex-wrap gap-x-8 gap-y-3 mb-12 pb-8 border-b border-chill-border">
          <Fact label="Difficulty" value={meta?.difficulty ?? '—'} />
          <Fact
            label="Cost"
            value={
              meta?.unlimitedPlays
                ? 'Unlimited plays'
                : `${meta?.sessionCost ?? 1} session${(meta?.sessionCost ?? 1) === 1 ? '' : 's'}`
            }
          />
          <Fact label="Players" value={meta?.players ?? 'Solo'} />
          {stat && <Fact label="Plays so far" value={stat.plays.toLocaleString()} />}
          {stat && guide.showTopScore && stat.top_score != null && (
            <Fact label={guide.scoreLabel ?? 'Best score'} value={stat.top_score.toLocaleString()} />
          )}
        </div>

        <Section title={`What ${guide.name} is`}>
          {guide.intro.map((p, i) => (
            <p key={i} className="text-[16px] leading-relaxed text-chill-textSecondary mb-4">
              {p}
            </p>
          ))}
        </Section>

        <Section title="How to play">
          <ol className="list-decimal pl-5 flex flex-col gap-2.5">
            {guide.howToPlay.map((step, i) => (
              <li key={i} className="text-[15px] leading-relaxed text-chill-textSecondary">
                {step}
              </li>
            ))}
          </ol>
        </Section>

        <Section title="Scoring and XP">
          <ul className="list-disc pl-5 flex flex-col gap-2.5">
            {guide.scoring.map((line, i) => (
              <li key={i} className="text-[15px] leading-relaxed text-chill-textSecondary">
                {line}
              </li>
            ))}
          </ul>
        </Section>

        <Section title={`How to get better at ${guide.name}`}>
          <div className="flex flex-col gap-4">
            {guide.tips.map((tip, i) => (
              <div key={i} className="glass-panel rounded-2xl px-6 py-5">
                <h3 className="text-[15px] font-bold text-chill-text mb-2">{tip.title}</h3>
                <p className="text-[15px] leading-relaxed text-chill-textSecondary">{tip.body}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Common questions">
          <div className="flex flex-col gap-3.5">
            {guide.faq.map((item, i) => (
              <details key={i} className="group glass-panel rounded-2xl px-6 py-5 open:pb-5 transition-all">
                <summary className="cursor-pointer list-none flex items-center justify-between gap-4 font-semibold text-[15px] text-chill-text">
                  {item.q}
                  <span className="shrink-0 text-chill-textMuted transition-transform group-open:rotate-45 text-xl leading-none">+</span>
                </summary>
                <p className="mt-3 text-[15px] leading-relaxed text-chill-textSecondary">{item.a}</p>
              </details>
            ))}
          </div>
        </Section>

        <div className="bg-chill-surface border border-chill-border rounded-2xl p-7 text-center mt-12">
          <h2 className="text-lg font-bold mb-2">Play {guide.name}</h2>
          <p className="text-sm text-chill-textSecondary mb-5">
            {meta?.requiresPro
              ? 'This one is exclusive to Chillverse Pro. Free to sign up and look around first.'
              : 'Free to play. Sign up and your first sessions are waiting.'}
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <button
              onClick={() => navigate('/games', { state: { openGame: guide.gameId } })}
              className="px-5 py-2.5 rounded-full text-sm font-bold text-white bg-gradient-to-br from-chill-violet to-[#3d1fb5] border-0 cursor-pointer"
            >
              Play now →
            </button>
            <Link
              to="/play"
              className="px-5 py-2.5 rounded-full text-sm font-semibold border border-chill-border text-chill-text no-underline"
            >
              Other games
            </Link>
          </div>
        </div>

        <div className="mt-14">
          <h2 className="text-[13px] font-mono uppercase tracking-[2px] text-chill-textMuted mb-4">
            More games
          </h2>
          <div className="flex flex-wrap gap-2.5">
            {others.map((g) => (
              <Link
                key={g.slug}
                to={`/play/${g.slug}`}
                className="px-4 py-2 rounded-full text-[13px] font-semibold border border-chill-border text-chill-textSecondary no-underline hover:text-chill-text"
              >
                {g.name}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-12">
      <h2 className="text-xl md:text-2xl font-bold tracking-tight mb-4">{title}</h2>
      {children}
    </section>
  )
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] font-mono uppercase tracking-wider text-chill-textMuted mb-1">
        {label}
      </div>
      <div className="text-[15px] font-semibold text-chill-text">{value}</div>
    </div>
  )
}
