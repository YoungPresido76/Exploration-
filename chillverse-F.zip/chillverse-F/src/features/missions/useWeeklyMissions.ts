// src/features/missions/useWeeklyMissions.ts
import { useState, useEffect, useCallback, useRef } from 'react'
import { useAuth } from '../auth/useAuth'
import { supabase } from '../../shared/lib/supabase'
import { getWeeklyMissions, getTimeUntilReset, mapRowToMissions } from './weeklyMissions'
import type { MissionWithProgress, MissionDefinition, UserWeeklyMission } from './weeklyMissions'

interface WeeklyMissionsState {
  missions: MissionWithProgress[]
  loading: boolean
  weekProgress: number
  totalMissionCount: number
  totalXpEarned: number
  totalDiamondsEarned: number
  boostersEarned: number
  /** One-time bonus XP for clearing every selected mission this week. */
  bonusXpEarned: number
  bonusClaimed: boolean
  countdown: { days: number; hours: number; minutes: number }
  refresh: () => void
}

export function useWeeklyMissions(): WeeklyMissionsState {
  const { user } = useAuth()
  const userId = user?.id ?? null

  const [missions, setMissions] = useState<MissionWithProgress[]>([])
  const [loading, setLoading] = useState(true)
  const [totalXpEarned, setTotalXpEarned] = useState(0)
  const [totalDiamondsEarned, setTotalDiamondsEarned] = useState(0)
  const [boostersEarned, setBoostersEarned] = useState(0)
  const [bonusXpEarned, setBonusXpEarned] = useState(0)
  const [bonusClaimed, setBonusClaimed] = useState(false)
  const [countdown, setCountdown] = useState(getTimeUntilReset())

  // This week's mission definitions, cached so a realtime row update can be
  // re-mapped into MissionWithProgress[] locally (definitions don't change
  // mid-week — only progress/completed_ids/reward totals do).
  const definitionsRef = useRef<MissionDefinition[]>([])
  // Guards against a realtime event for a *new* week's row (e.g. reset
  // ticked over mid-session) arriving before we've loaded its definitions.
  const weekStartRef = useRef<string | null>(null)

  const applyRow = useCallback((row: UserWeeklyMission | null) => {
    if (!row) return
    setMissions(mapRowToMissions(row, definitionsRef.current))
    setTotalXpEarned(row.total_xp_earned ?? 0)
    setTotalDiamondsEarned(row.total_diamonds_earned ?? 0)
    setBoostersEarned(row.boosters_earned ?? 0)
    setBonusXpEarned(row.bonus_xp_earned ?? 0)
    setBonusClaimed(row.bonus_claimed ?? false)
  }, [])

  const load = useCallback(async () => {
    if (!userId) {
      setLoading(false)
      return
    }
    setLoading(true)
    try {
      const { missions: result, row } = await getWeeklyMissions()
      setMissions(result)
      // Totals come from the authoritative server-tracked row, not a
      // client-side recomputation from the completed set.
      setTotalXpEarned(row?.total_xp_earned ?? 0)
      setTotalDiamondsEarned(row?.total_diamonds_earned ?? 0)
      setBoostersEarned(row?.boosters_earned ?? 0)
      setBonusXpEarned(row?.bonus_xp_earned ?? 0)
      setBonusClaimed(row?.bonus_claimed ?? false)
      weekStartRef.current = row?.week_start ?? null
      definitionsRef.current = result.map(({ current_progress, is_completed, ...def }) => def)
    } catch (err) {
      console.error('[useWeeklyMissions] load error:', err)
    } finally {
      setLoading(false)
    }
  }, [userId])

  useEffect(() => {
    load()
  }, [load])

  // Live progress — record_mission_progress() (see 0053/0114) writes
  // progress, completed_ids, and every reward total to this one row inside
  // a single transaction, so one UPDATE event has everything needed to
  // re-render the page without the user refreshing or leaving/returning.
  useEffect(() => {
    if (!userId) return
    const ch = supabase
      .channel(`weekly-missions-${userId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'user_weekly_missions', filter: `user_id=eq.${userId}` },
        (payload) => {
          const row = payload.new as UserWeeklyMission
          // A new week rolled over server-side (rare mid-session, but the
          // countdown can hit zero while the tab is open) — the cached
          // definitions belong to the old week, so do a full reload instead
          // of a local re-map.
          if (row.week_start !== weekStartRef.current) {
            load()
            return
          }
          applyRow(row)
        }
      )
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [userId, applyRow, load])

  // Countdown ticker — updates every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown(getTimeUntilReset())
    }, 30_000)
    return () => clearInterval(interval)
  }, [])

  const weekProgress = missions.filter(m => m.is_completed).length

  return {
    missions,
    loading,
    weekProgress,
    totalMissionCount: missions.length,
    totalXpEarned,
    totalDiamondsEarned,
    boostersEarned,
    bonusXpEarned,
    bonusClaimed,
    countdown,
    refresh: load,
  }
}
