// src/features/fortune/VaultBoard.tsx
//
// The board itself: eight prize tiles around a centre cell.
//
// A grid rather than a wheel, deliberately. Prize art is square (it's Mall
// item art), and in Clear mode a spent tile going dim and hatched reads
// instantly — where a wheel segment shrinking out of existence just looks
// broken. The centre shows how many prizes are left in Clear mode and an
// infinity mark in Repeat, which is the whole pitch: you can count what's
// still in there.
//
// Purely presentational. It is told which slot is lit and which were won;
// the sweep itself is driven from FortuneVault.tsx, because the server has
// already decided the outcome before a single frame plays.
import { Lock, Sparkles, Zap, Gem, Ticket } from 'lucide-react'
import type { VaultTile } from './fortuneVault'
import { SLOT_GRID_INDEX, tileLabel } from './fortuneVault'

const ACCENT = '#f5c542'

function PrizeGlyph({ tile, size }: { tile: VaultTile; size: number }) {
  if (tile.kind === 'item' && tile.image_url) {
    return (
      <img
        src={tile.image_url}
        alt=""
        style={{ width: size, height: size, objectFit: 'cover', borderRadius: 10, display: 'block' }}
      />
    )
  }
  if (tile.kind === 'xp') return <Zap size={size * 0.6} color={ACCENT} />
  if (tile.currency === 'voucher') return <Ticket size={size * 0.6} color="#3ecf8e" />
  if (tile.currency === 'orb') return <Sparkles size={size * 0.6} color="#9b6dff" />
  return <Gem size={size * 0.6} color="#4f8ef7" />
}

export default function VaultBoard({
  tiles, activeSlot, wonSlots, mode, poolSize, onTapTile,
}: {
  tiles: VaultTile[]
  activeSlot: number | null
  wonSlots: number[]
  mode: 'clear' | 'repeat'
  poolSize: number
  onTapTile?: (tile: VaultTile) => void
}) {
  const bySlot = new Map(tiles.map(t => [t.slot, t]))
  const wonSet = new Set(wonSlots)

  // Nine cells; index 4 is the centre. SLOT_GRID_INDEX maps slot -> cell.
  const cells: (number | 'centre')[] = Array.from({ length: 9 }, (_, i) => {
    if (i === 4) return 'centre'
    const slot = SLOT_GRID_INDEX.indexOf(i as (typeof SLOT_GRID_INDEX)[number])
    return slot
  })

  return (
    <div>
      <style>{`
        @keyframes cvVaultWin {
          0%   { transform: scale(1);    box-shadow: 0 0 0 0 rgba(245,197,66,0.55); }
          45%  { transform: scale(1.07); box-shadow: 0 0 0 10px rgba(245,197,66,0); }
          100% { transform: scale(1);    box-shadow: 0 0 0 0 rgba(245,197,66,0); }
        }
        @keyframes cvVaultCentre {
          0%, 100% { opacity: 1; }
          50%      { opacity: 0.72; }
        }
        .cv-vault-tile { transition: border-color 0.12s linear, background 0.12s linear, transform 0.12s ease; }
        .cv-vault-tile--won { animation: cvVaultWin 0.7s ease-out; }
      `}</style>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 8,
        padding: 10,
        borderRadius: 20,
        background: 'var(--surface2)',
        border: '1px solid var(--border)',
        boxShadow: 'var(--elev-raise-sm)',
      }}>
        {cells.map((cell, i) => {
          if (cell === 'centre') {
            return (
              <div
                key="centre"
                style={{
                  aspectRatio: '1/1', borderRadius: 14,
                  display: 'grid', placeItems: 'center', gap: 2,
                  background: 'radial-gradient(circle at 50% 35%, rgba(245,197,66,0.16), transparent 70%), var(--surface3)',
                  border: `1px solid ${ACCENT}44`,
                }}
              >
                <span style={{
                  fontSize: mode === 'repeat' ? 30 : 26, fontWeight: 900, lineHeight: 1,
                  color: ACCENT, animation: 'cvVaultCentre 2.4s ease-in-out infinite',
                }}>
                  {mode === 'repeat' ? '∞' : poolSize}
                </span>
                <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 0.4, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                  {mode === 'repeat' ? 'Endless' : poolSize === 1 ? 'Last one' : 'Left'}
                </span>
              </div>
            )
          }

          const tile = bySlot.get(cell)
          if (!tile) return <div key={i} style={{ aspectRatio: '1/1' }} />

          const lit = activeSlot === tile.slot
          const won = wonSet.has(tile.slot)
          const out = !tile.in_pool

          return (
            <button
              key={tile.id}
              type="button"
              onClick={() => onTapTile?.(tile)}
              className={`cv-vault-tile${won ? ' cv-vault-tile--won' : ''}`}
              style={{
                position: 'relative', aspectRatio: '1/1', borderRadius: 14, padding: 6,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 5,
                cursor: onTapTile ? 'pointer' : 'default',
                background: lit ? `${ACCENT}26` : 'var(--surface)',
                border: `1.5px solid ${lit ? ACCENT : tile.is_grand ? `${ACCENT}55` : 'var(--border)'}`,
                // A spent or owned tile stays on the board on purpose: it is
                // why the odds on everything else went up.
                opacity: out ? 0.4 : 1,
                filter: out ? 'grayscale(0.75)' : 'none',
                transform: lit ? 'scale(1.04)' : 'scale(1)',
              }}
            >
              {tile.is_grand && !out && (
                <span style={{
                  position: 'absolute', top: 4, right: 4, fontSize: 8, fontWeight: 900,
                  letterSpacing: 0.3, color: '#0d0d10', background: ACCENT,
                  borderRadius: 5, padding: '2px 4px',
                }}>
                  GRAND
                </span>
              )}

              <PrizeGlyph tile={tile} size={38} />

              <span style={{
                fontSize: 9, fontWeight: 700, lineHeight: 1.2, textAlign: 'center',
                color: 'var(--text-muted)', maxWidth: '100%',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>
                {tileLabel(tile)}
              </span>

              {out && (
                <span style={{
                  position: 'absolute', inset: 0, borderRadius: 14,
                  display: 'flex', alignItems: 'flex-end', justifyContent: 'center', paddingBottom: 5,
                  // Hatching, so "gone" is legible at a glance and not just "dim".
                  background: 'repeating-linear-gradient(135deg, rgba(0,0,0,0.28) 0 5px, transparent 5px 10px)',
                }}>
                  <span style={{
                    display: 'flex', alignItems: 'center', gap: 3,
                    fontSize: 8.5, fontWeight: 900, letterSpacing: 0.3, textTransform: 'uppercase',
                    color: 'var(--text)', background: 'rgba(0,0,0,0.55)', borderRadius: 5, padding: '2px 5px',
                  }}>
                    <Lock size={8} /> {tile.owned ? 'Owned' : 'Won'}
                  </span>
                </span>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
