// src/features/fortune/FortuneVault.tsx
//
// The Fortune Vault screen — reached from the Game Zone hero slide, as a view
// swap rather than a route, following the ActivityGoals precedent.
//
// The server has already decided the outcome, granted the prizes and written
// the ledger before the first frame of the sweep plays. The animation is
// theatre over a settled result: nothing here can change what was won, and a
// player who closes the app mid-sweep still keeps everything.
//
// The sweep is driven from a useEffect keyed on `step`, NOT a chain of
// setTimeouts held in a ref. React.StrictMode mounts, unmounts and remounts in
// dev, which wipes a pending ref-chain and freezes the animation half way —
// the exact bug that bit ColourBlock and Pattern King.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Info, Sparkles, X, Clock, PartyPopper, AlertTriangle } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { ripple } from '../../shared/lib/ripple'
import Toast, { useToast } from '../../shared/components/Toast'
import FeatureFlagGate from '../../shared/components/FeatureFlagGate'
import { playTileMatch, playCoin, playRuby } from '../games/sfx'
import VaultBoard from './VaultBoard'
import RatesSheet from './RatesSheet'
import TopUpModal from './TopUpModal'
import {
  fetchFortuneVault, spinVault, tileLabel, RING_ORDER,
  CURRENCY_LABEL, VAULT_FALLBACK, type VaultState, type SpinResult,
} from './fortuneVault'

const ACCENT = '#f5c542'
const LAPS = 3

function timeLeft(endsAt: string | null): string {
  if (!endsAt) return ''
  const ms = new Date(endsAt).getTime() - Date.now()
  if (ms <= 0) return 'closing'
  const days = Math.floor(ms / 86_400_000)
  const hours = Math.floor((ms % 86_400_000) / 3_600_000)
  const mins = Math.floor((ms % 3_600_000) / 60_000)
  if (days > 0) return `${days}d ${hours}h left`
  if (hours > 0) return `${hours}h ${mins}m left`
  return `${mins}m left`
}

/** Eases from a fast blur to a slow crawl. Cubic, so the last three steps are
 *  where all the tension is. */
function stepDelay(i: number, total: number): number {
  const t = total <= 1 ? 1 : i / (total - 1)
  return 42 + Math.pow(t, 3) * 240
}

export default function FortuneVault({ onBack }: { onBack: () => void }) {
  return (
    <FeatureFlagGate flagKey="fortune:vault">
      <VaultScreen onBack={onBack} />
    </FeatureFlagGate>
  )
}

function VaultScreen({ onBack }: { onBack: () => void }) {
  const [state, setState] = useState<VaultState | null>(null)
  const [loading, setLoading] = useState(true)
  const [showRates, setShowRates] = useState(false)
  const [busy, setBusy] = useState(false)
  const { toast, showToast } = useToast(3200)
  const navigate = useNavigate()
  const [topUp, setTopUp] = useState<{ price: number } | null>(null)

  // Sweep state. `step` is the whole animation clock — one effect below reads
  // it, schedules the next tick, and nothing else touches timers.
  const [step, setStep] = useState<number | null>(null)
  const [sweep, setSweep] = useState<{ startRing: number; totalSteps: number } | null>(null)
  const [pending, setPending] = useState<SpinResult[] | null>(null)
  const [wonSlots, setWonSlots] = useState<number[]>([])
  const [reveal, setReveal] = useState<SpinResult[] | null>(null)
  const [banner, setBanner] = useState<string | null>(null)
  const [, forceTick] = useState(0)

  const lastRing = useRef(0)

  usePageHeader({ title: 'Fortune Vault', onBack })

  const load = useCallback(async () => {
    const { data, error } = await fetchFortuneVault()
    if (error) showToast({ message: 'Could not load the Vault.', icon: AlertTriangle, iconColor: 'var(--red)' })
    setState(data)
    setLoading(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => { load() }, [load])

  // Keeps the countdown honest without a refetch.
  useEffect(() => {
    const t = setInterval(() => forceTick(n => n + 1), 60_000)
    return () => clearInterval(t)
  }, [])

  const vault = state?.vault ?? null
  const tiles = state?.prizes ?? []
  const poolSize = state?.pool_size ?? 0
  const balance = state?.balance ?? 0

  const activeSlot = useMemo(() => {
    if (step === null || !sweep) return null
    return RING_ORDER[(sweep.startRing + step) % RING_ORDER.length]
  }, [step, sweep])

  // ── The sweep clock ───────────────────────────────────────────────────
  useEffect(() => {
    if (step === null || !sweep || !pending) return

    if (step >= sweep.totalSteps) {
      // Landed. Flash every slot the spin actually hit, then reveal.
      const slots = Array.from(new Set(pending.map(r => r.slot)))
      setWonSlots(slots)
      if (pending.some(r => r.is_grand)) playRuby(); else playCoin()

      const t = setTimeout(() => {
        setReveal(pending)
        setPending(null)
        setStep(null)
        setSweep(null)
        setWonSlots([])
        load()
      }, 700)
      return () => clearTimeout(t)
    }

    const t = setTimeout(() => {
      // Only the closing steps click, or a five-spin sounds like a machine gun.
      if (sweep.totalSteps - step <= 6) playTileMatch()
      setStep(s => (s === null ? null : s + 1))
    }, stepDelay(step, sweep.totalSteps))
    return () => clearTimeout(t)
  }, [step, sweep, pending, load])

  async function spin(count: 1 | 5) {
    if (busy || step !== null || !vault) return

    const price = count === 5 ? vault.price_five : vault.price_one

    // Checked here, not by grey-ing the button out. The server re-checks and
    // is still the authority — this only saves a round trip and lets us name
    // the shortfall.
    if (balance < price) {
      setTopUp({ price })
      return
    }
    if (poolSize < count) {
      showToast({
        message: count === 5
          ? 'Fewer than 5 prizes left on your board.'
          : 'No prizes left on your board.',
        icon: AlertTriangle,
        iconColor: 'var(--red)',
      })
      return
    }

    setBusy(true)
    setBanner(null)
    const { data, error } = await spinVault(count)
    setBusy(false)

    if (error || !data) {
      showToast({ message: error ?? 'That spin failed.', icon: AlertTriangle, iconColor: 'var(--red)' })
      return
    }

    if (data.outcome === 'refilled') setBanner('Board cleared — it came back full.')
    if (data.outcome === 'finished') setBanner('You cleared the Vault. That is everything.')

    // Land on the FIRST result. The rest flash alongside it when the sweep
    // ends — five separate sweeps would take half a minute.
    const targetRing = RING_ORDER.indexOf(data.results[0].slot as (typeof RING_ORDER)[number])
    const startRing = lastRing.current
    const offset = (targetRing - startRing + RING_ORDER.length) % RING_ORDER.length
    lastRing.current = targetRing

    setPending(data.results)
    setSweep({ startRing, totalSteps: LAPS * RING_ORDER.length + offset })
    setStep(0)
  }

  if (loading) {
    return (
      <div style={{ maxWidth: 520, margin: '0 auto', padding: '8px 0 48px' }}>
        <div style={{ height: 300, borderRadius: 20, background: 'var(--surface2)' }} />
      </div>
    )
  }

  if (!vault) {
    return (
      <div style={{ maxWidth: 520, margin: '0 auto', padding: '40px 20px', textAlign: 'center' }}>
        <Sparkles size={30} color={ACCENT} style={{ marginBottom: 12 }} />
        <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>The Vault is empty</p>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.55 }}>
          No prize board is running right now. Keep an eye on the Game Zone — a new one goes up without warning.
        </p>
      </div>
    )
  }

  const spinning = step !== null
  const canAfford1 = balance >= vault.price_one
  const canAfford5 = balance >= vault.price_five
  const fiveBlocked = poolSize < 5
  const spentLabel = CURRENCY_LABEL[vault.currency]

  return (
    <div style={{ maxWidth: 520, margin: '0 auto', paddingBottom: 48 }}>
      {/* The event's own name over its own art. A scrim rather than a flat
          overlay: banner art is admin-uploaded and unpredictable, and pale
          artwork would eat white text without it. */}
      <div style={{
        position: 'relative', minHeight: vault.banner_url ? 140 : 0,
        borderRadius: 18, marginBottom: 14, overflow: 'hidden',
        border: vault.banner_url ? '1px solid var(--border)' : 'none',
        background: vault.banner_url ? `center/cover no-repeat url(${vault.banner_url})` : 'none',
      }}>
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 7,
          padding: vault.banner_url ? '52px 14px 14px' : '0 0 4px',
          background: vault.banner_url
            ? 'linear-gradient(to top, rgba(0,0,0,0.82) 0%, rgba(0,0,0,0.45) 45%, transparent 100%)'
            : 'none',
        }}>
          <span style={{
            fontSize: 9.5, fontWeight: 900, letterSpacing: 1.2, textTransform: 'uppercase',
            color: '#0d0d10', background: ACCENT, borderRadius: 6, padding: '4px 9px',
          }}>
            {vault.tag || VAULT_FALLBACK.tag}
          </span>
          <p style={{
            fontSize: 22, fontWeight: 900, lineHeight: 1.15, margin: 0,
            color: vault.banner_url ? '#fff' : 'var(--text)',
            textShadow: vault.banner_url ? '0 2px 12px rgba(0,0,0,0.65)' : 'none',
          }}>
            {vault.title || VAULT_FALLBACK.title}
          </p>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <p style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text)', margin: 0 }}>
            {balance.toLocaleString()} {spentLabel}
          </p>
          {vault.ends_at && (
            <p style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--text-muted)', margin: '3px 0 0' }}>
              <Clock size={11} /> {timeLeft(vault.ends_at)}
            </p>
          )}
        </div>
        <button
          type="button"
          onClick={(e) => { ripple(e); setShowRates(true) }}
          style={{
            display: 'flex', alignItems: 'center', gap: 5,
            fontSize: 11.5, fontWeight: 700, color: ACCENT,
            background: `${ACCENT}1a`, border: `1px solid ${ACCENT}44`,
            borderRadius: 10, padding: '7px 11px', cursor: 'pointer', fontFamily: 'inherit',
          }}
        >
          <Info size={12} /> Drop rates
        </button>
      </div>

      {banner && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12,
          padding: '10px 12px', borderRadius: 12,
          background: 'rgba(62,207,142,0.12)', border: '1px solid rgba(62,207,142,0.3)',
        }}>
          <PartyPopper size={14} color="#3ecf8e" style={{ flexShrink: 0 }} />
          <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)' }}>{banner}</span>
        </div>
      )}

      <VaultBoard
        tiles={tiles}
        activeSlot={activeSlot}
        wonSlots={wonSlots}
        mode={vault.mode}
        poolSize={poolSize}
        onTapTile={() => setShowRates(true)}
      />

      {vault.mode === 'clear' && poolSize === 1 && !spinning && (
        <p style={{ fontSize: 12, fontWeight: 800, color: ACCENT, textAlign: 'center', margin: '12px 0 0' }}>
          One prize left. Your next spin wins it.
        </p>
      )}

      <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
        <SpinButton
          label={`Spin ×1`}
          price={vault.price_one}
          currency={spentLabel}
          disabled={spinning || busy}
          note={!canAfford1 ? `You have ${balance.toLocaleString()}` : undefined}
          onClick={() => spin(1)}
        />
        <SpinButton
          label={`Spin ×5`}
          price={vault.price_five}
          currency={spentLabel}
          primary
          disabled={spinning || busy}
          // ×5 is refused rather than charged pro-rata when the pool is short
          // — easier to explain than a partial refund, and it protects the
          // guaranteed last tile. The tap says so instead of the button dying.
          note={fiveBlocked ? 'Fewer than 5 prizes left' : !canAfford5 ? `You have ${balance.toLocaleString()}` : undefined}
          onClick={() => spin(5)}
        />
      </div>

      <p style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: 'center', margin: '14px 0 0', lineHeight: 1.55 }}>
        {vault.mode === 'clear'
          ? 'Every prize you win leaves your board until it clears.'
          : 'Cosmetics you already own drop off your board for good — everything else can come round again.'}
      </p>

      <RatesSheet
        open={showRates}
        onClose={() => setShowRates(false)}
        tiles={tiles}
        mode={vault.mode}
        poolSize={poolSize}
      />

      {topUp && (
        <TopUpModal
          currency={vault.currency}
          price={topUp.price}
          balance={balance}
          onClose={() => setTopUp(null)}
          onTopUp={(route) => { setTopUp(null); navigate(route) }}
        />
      )}

      <RevealSheet results={reveal} onClose={() => setReveal(null)} />
      <Toast toast={toast} zIndex={21000} />
    </div>
  )
}

function SpinButton({
  label, price, currency, disabled, primary, note, onClick,
}: {
  label: string
  price: number
  currency: string
  disabled: boolean
  primary?: boolean
  note?: string
  onClick: () => void
}) {
  return (
    <div style={{ flex: 1, minWidth: 0 }}>
      <button
        type="button"
        disabled={disabled}
        onClick={(e) => { ripple(e); onClick() }}
        style={{
          width: '100%', padding: '13px 10px', borderRadius: 14,
          fontFamily: 'inherit', fontSize: 13.5, fontWeight: 800, lineHeight: 1.3,
          cursor: disabled ? 'not-allowed' : 'pointer',
          color: disabled ? 'var(--text-muted)' : primary ? '#0d0d10' : 'var(--text)',
          background: disabled ? 'var(--surface3)' : primary ? ACCENT : 'var(--surface2)',
          border: disabled || primary ? 'none' : `1px solid ${ACCENT}55`,
          boxShadow: disabled ? 'none' : 'var(--elev-raise-sm)',
        }}
      >
        {label}
        <span style={{ display: 'block', fontSize: 10.5, fontWeight: 700, opacity: 0.85, marginTop: 3 }}>
          {price.toLocaleString()} {currency}
        </span>
      </button>
      {note && (
        <p style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'center', margin: '5px 0 0' }}>{note}</p>
      )}
    </div>
  )
}

/** What you got. Shown after the sweep, and after the grant has already
 *  happened — closing this changes nothing. */
function RevealSheet({ results, onClose }: { results: SpinResult[] | null; onClose: () => void }) {
  if (!results || results.length === 0) return null

  return (
    <div
      className="sheet-or-modal"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20500, display: 'grid', placeItems: 'center',
        background: 'rgba(0,0,0,0.62)', backdropFilter: 'blur(3px)', padding: 20,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 380, maxHeight: '80vh', overflowY: 'auto',
          background: 'var(--surface2)', borderRadius: 20, padding: '20px 18px 22px',
          border: `1px solid ${ACCENT}44`,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <p style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)' }}>
            {results.length === 1 ? 'You won' : `You won ${results.length}`}
          </p>
          <button type="button" onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
            <X size={18} />
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
          {results.map(r => (
            <div
              key={r.win_id}
              style={{
                display: 'flex', alignItems: 'center', gap: 11, padding: 10, borderRadius: 13,
                background: 'var(--surface)',
                border: r.is_grand ? `1px solid ${ACCENT}77` : '1px solid var(--border)',
              }}
            >
              <span style={{
                width: 44, height: 44, borderRadius: 11, flexShrink: 0, overflow: 'hidden',
                background: 'var(--surface3)', display: 'grid', placeItems: 'center',
              }}>
                {r.image_url
                  ? <img src={r.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <span style={{ fontSize: 18 }}>{r.kind === 'xp' ? '⚡' : '💰'}</span>}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
                  {tileLabel(r)}
                </p>
                <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 0' }}>
                  {r.kind === 'item' ? 'Added to your inventory' : r.kind === 'xp' ? 'Added to your XP' : 'Added to your wallet'}
                </p>
              </div>
              {r.is_grand && (
                <span style={{
                  fontSize: 9, fontWeight: 900, letterSpacing: 0.3, color: '#0d0d10',
                  background: ACCENT, borderRadius: 6, padding: '3px 6px', flexShrink: 0,
                }}>
                  GRAND
                </span>
              )}
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={(e) => { ripple(e); onClose() }}
          style={{
            width: '100%', marginTop: 16, padding: '12px', borderRadius: 13, border: 'none',
            fontFamily: 'inherit', fontSize: 13.5, fontWeight: 800, color: '#0d0d10',
            background: ACCENT, cursor: 'pointer',
          }}
        >
          Nice
        </button>
      </div>
    </div>
  )
}
