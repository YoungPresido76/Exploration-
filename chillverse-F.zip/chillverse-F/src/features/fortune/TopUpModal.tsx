// src/features/fortune/TopUpModal.tsx
//
// Shown when someone taps a spin they can't afford.
//
// The spin buttons deliberately do NOT grey out for a short balance any more.
// A dead button tells you nothing — not what's missing, not how much, not
// where to get it. Letting the tap through and answering all three is the
// whole point of this modal.
//
// It borrows the layout and animation of PurchaseResultModal (the screen you
// get when a Paystack checkout is closed) rather than importing it, since
// that component's props are checkout-shaped — kind/item/onRetry — and
// bending them around "you're short 40 Orbs" would leave both harder to read.
import { X } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { CURRENCY_LABEL, type VaultCurrency } from './fortuneVault'

const MODAL_IMG =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Onboarding/e0cda9106501f1ad6c3c37ff5c1cbe98.jpg'

/** Where each currency is actually topped up. Vouchers and Orbs aren't sold,
 *  so those land on their Wallet tab — which is where the earn routes (ad
 *  watching, the ledger showing what pays out) already live. */
const TOP_UP_ROUTE: Record<VaultCurrency, string> = {
  gem: '/buy-diamonds',
  orb: '/wallet?tab=orbs',
  voucher: '/wallet?tab=vouchers',
}

const TOP_UP_LABEL: Record<VaultCurrency, string> = {
  gem: 'Top up',
  orb: 'Get Orbs',
  voucher: 'Get Vouchers',
}

export default function TopUpModal({
  currency, price, balance, onClose, onTopUp,
}: {
  currency: VaultCurrency
  price: number
  balance: number
  onClose: () => void
  onTopUp: (route: string) => void
}) {
  const label = CURRENCY_LABEL[currency]
  const short = Math.max(0, price - balance)

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{
        position: 'fixed', inset: 0, zIndex: 21500,
        background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(10px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 20, animation: 'fadeIn 0.2s ease both',
      }}
    >
      <div
        style={{
          width: '100%', maxWidth: 360,
          background: 'var(--surface2)', borderRadius: 24,
          border: '1px solid var(--border)', boxShadow: 'var(--elev-popover)',
          overflow: 'visible', position: 'relative',
          animation: 'popIn 0.38s cubic-bezier(0.34,1.56,0.64,1) both',
        }}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          style={{
            position: 'absolute', top: 14, right: 14, width: 28, height: 28, borderRadius: 8,
            background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer',
            color: 'var(--text-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10,
          }}
        >
          <X size={13} />
        </button>

        <div
          style={{
            position: 'relative', height: 200, borderRadius: '24px 24px 0 0',
            overflow: 'visible', borderBottom: '1px solid var(--border)',
            background: 'linear-gradient(160deg,color-mix(in srgb, var(--accent) 12%, transparent),rgba(245,197,66,0.08))',
          }}
        >
          <div style={{ position: 'absolute', inset: 0, borderRadius: '24px 24px 0 0', overflow: 'hidden' }}>
            <img
              src={MODAL_IMG} alt=""
              style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.18, filter: 'blur(4px)', transform: 'scale(1.1)' }}
            />
          </div>
          <div style={{ position: 'absolute', bottom: -8, left: '50%', transform: 'translateX(-50%)', width: 160, height: 220, zIndex: 5 }}>
            <img
              src={MODAL_IMG} alt=""
              style={{
                width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center top',
                borderRadius: 16, boxShadow: 'var(--elev-popover)',
                filter: 'drop-shadow(0 8px 24px color-mix(in srgb, var(--accent) 30%, transparent))',
              }}
            />
          </div>
        </div>

        <div style={{ padding: '28px 20px 22px', textAlign: 'center' }}>
          <div style={{ fontSize: 24, marginBottom: 8 }}>😔</div>
          <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>
            Not enough {label}
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-dim)', lineHeight: 1.6, marginBottom: 20 }}>
            That spin costs {price.toLocaleString()} {label} and you have {balance.toLocaleString()}.
            {short > 0 && <> You need {short.toLocaleString()} more.</>}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <button
              onClick={(e) => { ripple(e); onTopUp(TOP_UP_ROUTE[currency]) }}
              className="ripple-wrap"
              style={{
                width: '100%', padding: 13, borderRadius: 14, border: 'none', cursor: 'pointer',
                background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
                color: '#fff', fontSize: 14, fontWeight: 800, fontFamily: 'inherit',
                boxShadow: '0 4px 20px color-mix(in srgb, var(--accent) 35%, transparent)',
              }}
            >
              {TOP_UP_LABEL[currency]}
            </button>
            <button
              onClick={(e) => { ripple(e); onClose() }}
              className="ripple-wrap"
              style={{
                width: '100%', padding: 13, borderRadius: 14, cursor: 'pointer',
                border: '1px solid var(--border-strong)', background: 'var(--surface)',
                color: 'var(--text-dim)', fontSize: 14, fontWeight: 700, fontFamily: 'inherit',
              }}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
