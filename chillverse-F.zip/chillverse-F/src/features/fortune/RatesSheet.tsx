// src/features/fortune/RatesSheet.tsx
//
// Drop rates, and they are THIS player's rates rather than a global table.
// That distinction is the point: once a cosmetic leaves your pool its weight
// is redistributed, so your odds on everything else are genuinely better than
// the next player's. Showing a global table would be a lie in both directions.
//
// The numbers come straight off get_fortune_vault() — the same computation
// the spin uses, not a client-side re-derivation that could drift from it.
import { X, Info } from 'lucide-react'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'
import type { VaultTile, VaultMode } from './fortuneVault'
import { tileLabel } from './fortuneVault'

const ACCENT = '#f5c542'

export default function RatesSheet({
  open, onClose, tiles, mode, poolSize,
}: {
  open: boolean
  onClose: () => void
  tiles: VaultTile[]
  mode: VaultMode
  poolSize: number
}) {
  // Declared above the bail-out — hooks can't sit after an early return.
  const { dragY, dragging, sheetProps } = useSheetDrag(onClose)

  if (!open) return null

  const inPool = tiles.filter(t => t.in_pool).sort((a, b) => b.chance_pct - a.chance_pct)
  const outOfPool = tiles.filter(t => !t.in_pool)

  return (
    <div
      className="sheet-or-modal"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20000, display: 'flex', alignItems: 'flex-end',
        background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(3px)',
      }}
    >
      <div
        className="sheet-or-modal-inner"
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxHeight: '82vh', overflowY: 'auto',
          background: 'var(--surface2)', borderRadius: '22px 22px 0 0',
          padding: '20px 20px 28px',
          transform: `translateY(${dragY}px)`,
          transition: dragging ? 'none' : 'transform 0.32s cubic-bezier(0.22,1,0.36,1)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)' }}>Your drop rates</p>
          <button type="button" onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
            <X size={18} />
          </button>
        </div>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 16, lineHeight: 1.5 }}>
          {mode === 'clear'
            ? 'Everything you win leaves your board until it refills, so these numbers climb as you go.'
            : 'Cosmetics leave your board once you own them. Cards, boosters and currency can be won again.'}
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {inPool.map(t => (
            <div key={t.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                width: 34, height: 34, borderRadius: 9, flexShrink: 0, overflow: 'hidden',
                background: 'var(--surface3)', display: 'grid', placeItems: 'center',
                border: t.is_grand ? `1px solid ${ACCENT}66` : '1px solid var(--border)',
              }}>
                {t.image_url
                  ? <img src={t.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <span style={{ fontSize: 13 }}>{t.kind === 'xp' ? '⚡' : '💰'}</span>}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{
                  fontSize: 12.5, fontWeight: 700, color: 'var(--text)', margin: 0,
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {tileLabel(t)}
                </p>
                <div style={{ height: 4, borderRadius: 2, background: 'var(--surface3)', marginTop: 5, overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(100, t.chance_pct)}%`, height: '100%', background: ACCENT, borderRadius: 2 }} />
                </div>
              </div>
              <span style={{ fontSize: 12.5, fontWeight: 800, color: ACCENT, flexShrink: 0 }}>
                {t.chance_pct}%
              </span>
            </div>
          ))}
        </div>

        {outOfPool.length > 0 && (
          <>
            <div style={{
              display: 'flex', gap: 8, alignItems: 'flex-start',
              marginTop: 18, padding: 12, borderRadius: 12,
              background: 'rgba(62,207,142,0.10)', border: '1px solid rgba(62,207,142,0.28)',
            }}>
              <Info size={14} color="#3ecf8e" style={{ flexShrink: 0, marginTop: 1 }} />
              <p style={{ fontSize: 11.5, color: 'var(--text)', margin: 0, lineHeight: 1.5 }}>
                {outOfPool.length} {outOfPool.length === 1 ? 'prize is' : 'prizes are'} off your board — their odds went
                to everything above. That's why your rates beat the base board.
              </p>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 12 }}>
              {outOfPool.map(t => (
                <span key={t.id} style={{
                  fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)',
                  background: 'var(--surface3)', border: '1px solid var(--border)',
                  borderRadius: 8, padding: '4px 8px',
                }}>
                  {tileLabel(t)} · {t.owned ? 'owned' : 'won'}
                </span>
              ))}
            </div>
          </>
        )}

        {poolSize === 1 && (
          <p style={{ fontSize: 12, fontWeight: 700, color: ACCENT, margin: '16px 0 0', textAlign: 'center' }}>
            One prize left — your next spin can only land on it.
          </p>
        )}
      </div>
    </div>
  )
}
