// src/features/fortune/fortuneVault.ts
//
// Data layer for the Fortune Vault — the admin-run prize board in the Game
// Zone (migrations 0172a/0172b).
//
// The client sends a NUMBER and animates whatever comes back. It never picks
// a prize, never sees a weight, and never decides what is in the pool: all of
// that lives in fortune_vault_spin(), one transaction, server-side. What
// arrives here is already granted and already in the ledger.
//
// Player calls and admin calls share this file the way bounties.ts does —
// they are the same feature, and splitting them only makes the pair drift.
import { supabase } from '../../shared/lib/supabase'

export type VaultCurrency = 'gem' | 'orb' | 'voucher'
export type VaultMode = 'clear' | 'repeat'
export type VaultOnClear = 'refill' | 'stop'
export type VaultStatus = 'draft' | 'live' | 'ended'
export type PrizeKind = 'item' | 'currency' | 'xp'

/** Ring order over slot indices: clockwise around the 3x3 board, starting
 *  top-left. DOM order alone jumps across the centre cell (slot 3 sits to the
 *  LEFT of the middle and slot 4 to the right), so the highlight would hop
 *  diagonally without this. */
export const RING_ORDER = [0, 1, 2, 4, 7, 6, 5, 3] as const

/** Grid position of each slot, 0-8, with 4 reserved for the centre cell. */
export const SLOT_GRID_INDEX = [0, 1, 2, 3, 5, 6, 7, 8] as const

export const CURRENCY_LABEL: Record<VaultCurrency, string> = {
  gem: 'Diamonds',
  orb: 'Orbs',
  voucher: 'Vouchers',
}

export const CURRENCY_SHORT: Record<VaultCurrency, string> = {
  gem: '💎',
  orb: 'Orbs',
  voucher: 'Vouchers',
}

export interface FortuneVault {
  id: string
  status: VaultStatus
  mode: VaultMode
  on_clear: VaultOnClear
  currency: VaultCurrency
  price_one: number
  price_five: number
  banner_url: string | null
  /** Event dressing. All three are null on a plain board and the client
   *  falls back to the stock Fortune Vault copy — so an admin who fills
   *  none of them still gets a sensible slide. */
  tag: string | null
  title: string | null
  subtitle: string | null
  rolled_out_at: string | null
  ends_at: string | null
  created_at: string
  updated_at: string
}

export interface VaultTile {
  id: string
  slot: number
  kind: PrizeKind
  item_id: string | null
  currency: VaultCurrency | null
  amount: number | null
  is_grand: boolean
  /** Mall fields, present only for kind === 'item'. */
  name: string | null
  image_url: string | null
  category: string | null
  rarity: string | null
  /** A cosmetic this player already has. Stays on the board, dimmed. */
  owned: boolean
  won_this_cycle: boolean
  /** in_pool === false means it cannot be rolled for this player right now. */
  in_pool: boolean
  /** THIS player's odds, not a global rate. Owned tiles read 0 and their
   *  weight is redistributed across everything else. */
  chance_pct: number
}

export interface VaultState {
  vault: FortuneVault | null
  prizes: VaultTile[]
  pool_size: number
  balance: number
  cycle_no: number
  spins: number
  cleared_count: number
}

export interface SpinResult {
  win_id: string
  prize_id: string
  slot: number
  kind: PrizeKind
  item_id: string | null
  currency: VaultCurrency | null
  amount: number | null
  is_grand: boolean
  name: string | null
  image_url: string | null
  category: string | null
}

export interface SpinOutcome {
  results: SpinResult[]
  /** 'refilled' — the board cleared and came back for another cycle.
   *  'finished' — it cleared and this vault is set to stop there.
   *  'open'     — business as usual. */
  outcome: 'open' | 'refilled' | 'finished'
  cycle_no: number
  balance: number
  spent: number
}

export const VAULT_FALLBACK = {
  tag: 'Prize Board',
  title: 'Fortune Vault',
  subtitle: 'Eight prizes, one board. Spin to claim them — everything you win clears a tile and lifts your odds on the rest.',
} as const

const EMPTY: VaultState = {
  vault: null, prizes: [], pool_size: 0, balance: 0,
  cycle_no: 0, spins: 0, cleared_count: 0,
}

/** Everything the board needs in one round trip, including the caller's own
 *  pool state and odds. Returns a null vault when none is live or the live
 *  one has expired — the caller renders nothing in that case. */
export async function fetchFortuneVault(): Promise<{ data: VaultState; error: string | null }> {
  const { data, error } = await supabase.rpc('get_fortune_vault')
  if (error) return { data: EMPTY, error: error.message }
  return { data: (data ?? EMPTY) as VaultState, error: null }
}

/** Server errors carry a CV_VAULT_* prefix so the sheet can say something
 *  true instead of leaking a Postgres string. */
export function vaultErrorMessage(raw: string): string {
  if (raw.includes('CV_VAULT_INSUFFICIENT')) return "You don't have enough for that spin."
  if (raw.includes('CV_VAULT_POOL_TOO_SMALL')) return 'Not enough prizes left on your board for that.'
  if (raw.includes('CV_VAULT_CLOSED')) return 'The Vault just closed.'
  if (raw.includes('CV_VAULT_BAD_COUNT')) return 'Spin once or five times.'
  return 'That spin failed. Try again in a moment.'
}

export async function spinVault(count: 1 | 5): Promise<{ data: SpinOutcome | null; error: string | null }> {
  const { data, error } = await supabase.rpc('fortune_vault_spin', { p_count: count })
  if (error) return { data: null, error: vaultErrorMessage(error.message) }
  return { data: data as SpinOutcome, error: null }
}

/** What a tile says on its face. Items carry their Mall name; currency and XP
 *  prizes have no row to borrow a name from, so they build one. */
export function tileLabel(tile: { kind: PrizeKind; name: string | null; amount: number | null; currency: VaultCurrency | null }): string {
  if (tile.kind === 'item') return tile.name ?? 'Mystery item'
  if (tile.kind === 'xp') return `${(tile.amount ?? 0).toLocaleString()} XP`
  return `${(tile.amount ?? 0).toLocaleString()} ${CURRENCY_LABEL[tile.currency ?? 'gem']}`
}

// ── Admin ────────────────────────────────────────────────────────────────
// Every one of these is is_admin_role()-gated server-side. The section that
// calls them hides itself for non-admins as a courtesy, not as the guard.

export interface VaultMallItem {
  id: string
  name: string
  image_url: string | null
  category: string
}

/** Mall lookup for the slot picker.
 *
 *  Unlike adminOps.searchMallItems this returns a BROWSE list for an empty
 *  query instead of nothing. A picker that shows an empty panel until you
 *  guess two correct characters reads as broken, and there is no way to find
 *  out what's in the Mall from inside it. */
export async function searchVaultItems(query: string): Promise<{ data: VaultMallItem[]; error: string | null }> {
  const term = query.trim()
  let q = supabase
    .from('mall_items')
    .select('id, name, image_url, category')
    .eq('is_active', true)
    .order('name')
    .limit(term ? 12 : 30)
  if (term) q = q.ilike('name', `%${term}%`)

  const { data, error } = await q
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as VaultMallItem[], error: null }
}

/** Where the uploaded banner lands.
 *
 *  Reusing the flash-sale bucket rather than minting `fortune-vault-images`:
 *  that bucket is already public-read with admin-only write (0107's storage
 *  RLS), and a second bucket buys nothing but another policy set to keep in
 *  sync. The upload shape here is a deliberate copy of uploadFlashSaleImage —
 *  root path, uuid filename — because that shape is known to satisfy the
 *  existing policy. Prefixing the path would be tidier and is exactly the
 *  kind of change that fails at runtime if the policy constrains `name`. */
const VAULT_IMAGES_BUCKET = 'flash-sale-images'
const MAX_VAULT_IMAGE_BYTES = 5 * 1024 * 1024

function extensionForImageFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

/** Uploads a banner and returns its public URL, to be saved as banner_url on
 *  the draft. Nothing is committed to the vault until the draft is saved, so
 *  an upload the admin then abandons is just an orphaned file, not a board
 *  with a half-changed picture. */
export async function uploadVaultImage(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Only image files can be used for the Vault banner.')
  }
  if (file.size > MAX_VAULT_IMAGE_BYTES) {
    throw new Error('Image is too large — please use a file under 5MB.')
  }

  const path = `${crypto.randomUUID()}.${extensionForImageFile(file)}`
  const { error } = await supabase.storage
    .from(VAULT_IMAGES_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (error) throw new Error(`Failed to upload image: ${error.message}`)

  const { data } = supabase.storage.from(VAULT_IMAGES_BUCKET).getPublicUrl(path)
  return data.publicUrl
}

export interface AdminVaultPrize {
  slot: number
  kind: PrizeKind
  item_id: string | null
  currency: VaultCurrency | null
  amount: number | null
  weight: number
  is_grand: boolean
  item_name?: string | null
  item_image_url?: string | null
  item_category?: string | null
}

export interface AdminVault extends FortuneVault {
  prizes: AdminVaultPrize[]
  spins: number
  players: number
  wins: number
}

export async function fetchAdminVaults(): Promise<{ data: AdminVault[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_get_fortune_vaults')
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as AdminVault[], error: null }
}

export interface SaveVaultInput {
  vaultId?: string | null
  mode: VaultMode
  onClear: VaultOnClear
  currency: VaultCurrency
  priceOne: number
  priceFive: number
  bannerUrl: string
  endsAt: string | null
  tag: string
  title: string
  subtitle: string
  prizes: AdminVaultPrize[]
}

export async function saveVaultDraft(input: SaveVaultInput): Promise<{ data: FortuneVault | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_save_fortune_vault_draft', {
    p_mode: input.mode,
    p_on_clear: input.onClear,
    p_currency: input.currency,
    p_price_one: input.priceOne,
    p_price_five: input.priceFive,
    p_prizes: input.prizes.map(p => ({
      slot: p.slot,
      kind: p.kind,
      item_id: p.kind === 'item' ? p.item_id : null,
      currency: p.kind === 'currency' ? p.currency : null,
      amount: p.kind === 'item' ? null : p.amount,
      weight: p.weight,
      is_grand: p.is_grand,
    })),
    p_banner_url: input.bannerUrl.trim() || null,
    p_ends_at: input.endsAt,
    p_vault_id: input.vaultId ?? null,
    p_tag: input.tag.trim() || null,
    p_title: input.title.trim() || null,
    p_subtitle: input.subtitle.trim() || null,
  })
  if (error) return { data: null, error: adminErrorMessage(error.message) }
  return { data: data as FortuneVault, error: null }
}

/** Changes the dressing on a board that is already running.
 *
 *  Deliberately narrow: banner, tag, title, subtitle and nothing else. The
 *  save-draft RPC still refuses to touch a live board, because rewriting
 *  prizes or weights underneath someone who is mid-spin is a different thing
 *  entirely from renaming the event. */
export async function setVaultPresentation(input: {
  vaultId: string
  tag: string
  title: string
  subtitle: string
  bannerUrl: string
}): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_set_fortune_vault_presentation', {
    p_vault_id: input.vaultId,
    p_tag: input.tag.trim() || null,
    p_title: input.title.trim() || null,
    p_subtitle: input.subtitle.trim() || null,
    p_banner_url: input.bannerUrl.trim() || null,
  })
  return { error: error ? adminErrorMessage(error.message) : null }
}

export async function rolloutVault(vaultId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_rollout_fortune_vault', { p_vault_id: vaultId })
  return { error: error ? adminErrorMessage(error.message) : null }
}

export async function endVault(vaultId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_end_fortune_vault', { p_vault_id: vaultId })
  return { error: error ? adminErrorMessage(error.message) : null }
}

export async function deleteVaultDraft(vaultId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_delete_fortune_vault', { p_vault_id: vaultId })
  return { error: error ? adminErrorMessage(error.message) : null }
}

/** The server raises 'CV_ADMIN_VALIDATION: <the actual reason>'. The reason is
 *  written for a human, so show it rather than replacing it with a generic. */
function adminErrorMessage(raw: string): string {
  const marker = raw.indexOf('CV_ADMIN_VALIDATION: ')
  if (marker >= 0) return raw.slice(marker + 'CV_ADMIN_VALIDATION: '.length)
  if (raw.includes('CV_ADMIN_FORBIDDEN')) return 'Admins only.'
  if (raw.includes('CV_ADMIN_NOT_FOUND')) return 'That vault is no longer there — reload the list.'
  return raw
}
