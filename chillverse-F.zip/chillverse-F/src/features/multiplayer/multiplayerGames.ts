// src/lib/multiplayerGames.ts
// Thin wrappers around the server-authoritative RPCs for live multiplayer
// games. All rules, turn validation, win detection, and XP live in Postgres
// (see 0008_multiplayer_games.sql) — this file just calls them and types
// the state shape that comes back on `rooms.game_state`.
import { supabase } from '../../shared/lib/supabase'

// ─── Tac Zone (tic-tac-toe) ─────────────────────────────────────
export interface TacState {
  board: (('X' | 'O') | null)[]
  players: { X: string; O: string }
  winner: 'X' | 'O' | 'draw' | null
  winner_user?: string
  started_at: string
}

export async function tacStart(roomId: string): Promise<TacState> {
  const { data, error } = await supabase.rpc('tac_start', { p_room_id: roomId })
  if (error) throw new Error(error.message)
  return data as TacState
}

export async function tacMove(roomId: string, cell: number): Promise<TacState> {
  const { data, error } = await supabase.rpc('tac_move', { p_room_id: roomId, p_cell: cell })
  if (error) throw new Error(error.message)
  return data as TacState
}

// ─── Pattern King Relay ─────────────────────────────────────────
export interface PKState {
  players: [string, string]
  active_idx: 0 | 1
  round: number
  rounds_completed: number
  grid: string[]
  target_sym: string
  phase: 'peek' | 'match' | 'done'
  phase_started_at: string
  peek_ms: number
  deadline: string | null
  picks: number[]
  winner: string | null
  loser: string | null
  started_at: string
}

export async function pkStart(roomId: string): Promise<PKState> {
  const { data, error } = await supabase.rpc('pk_start', { p_room_id: roomId })
  if (error) throw new Error(error.message)
  return data as PKState
}

export async function pkBeginMatch(roomId: string): Promise<PKState> {
  const { data, error } = await supabase.rpc('pk_begin_match', { p_room_id: roomId })
  if (error) throw new Error(error.message)
  return data as PKState
}

export async function pkPick(roomId: string, index: number): Promise<PKState> {
  const { data, error } = await supabase.rpc('pk_pick', { p_room_id: roomId, p_index: index })
  if (error) throw new Error(error.message)
  return data as PKState
}

export async function pkTimeout(roomId: string): Promise<PKState> {
  const { data, error } = await supabase.rpc('pk_timeout', { p_room_id: roomId })
  if (error) throw new Error(error.message)
  return data as PKState
}

// ─── Chill Merge (live score race) ─────────────────────────────
// Each player plays their own private board against the same 90s clock —
// there's no shared board and no per-move RPC. Every ~5s (and once at the
// end) each client reports its own current score; the opponent's score
// arrives back on `rooms.game_state.scores` through the same realtime path
// as everything else in this file. See merge_start/merge_report_score/
// merge_finish/merge_timeout in the tile_merge_live_pvp migration.
export interface MergeState {
  seed: number
  duration_sec: number
  started_at: string
  players: [string, string]
  /** Keyed by user id. */
  scores: Record<string, number>
  /** Keyed by user id — individual merge (triple-collapse) counts. Drives the doubled multiplayer XP payout in merge_resolve (12 XP/merge vs solo's 6). */
  merges: Record<string, number>
  /** Keyed by user id — present (true) once that player's board has filled before the clock ran out. Once both players are here, the match resolves immediately instead of waiting for the deadline. */
  full: Record<string, boolean>
  /** Keyed by user id — present (true) once that player has called mergeFinish. */
  finished: Record<string, boolean>
  winner: string | null
  is_draw: boolean
}

export async function mergeStart(roomId: string): Promise<MergeState> {
  const { data, error } = await supabase.rpc('merge_start', { p_room_id: roomId })
  if (error) throw new Error(error.message)
  return data as MergeState
}

export async function mergeReportScore(roomId: string, score: number, merges: number, full = false): Promise<MergeState> {
  const { data, error } = await supabase.rpc('merge_report_score', { p_room_id: roomId, p_score: score, p_merges: merges, p_full: full })
  if (error) throw new Error(error.message)
  return data as MergeState
}

export async function mergeFinish(roomId: string, score: number, merges: number): Promise<MergeState> {
  const { data, error } = await supabase.rpc('merge_finish', { p_room_id: roomId, p_score: score, p_merges: merges })
  if (error) throw new Error(error.message)
  return data as MergeState
}

export async function mergeTimeout(roomId: string): Promise<MergeState> {
  const { data, error } = await supabase.rpc('merge_timeout', { p_room_id: roomId })
  if (error) throw new Error(error.message)
  return data as MergeState
}

/**
 * Server clock in ms, for correcting a client's own Date.now() before it's
 * used to gate a timed multiplayer round (Chill Merge). A client whose clock
 * is skewed ahead of the server would otherwise see the round as "already
 * over" the instant it starts and every tap would silently do nothing.
 */
export async function fetchServerNowMs(): Promise<number> {
  const { data, error } = await supabase.rpc('server_now')
  if (error) throw new Error(error.message)
  return new Date(data as string).getTime()
}
