// src/hooks/useRoom.ts
// Subscribes to a single room's live state: the room row itself (status,
// turn_user_id, game_state) and its player roster (join/leave/kick).
//
// RELIABILITY NOTE — read this before touching the reconnect logic below.
// `postgres_changes` has no catch-up/replay: if this client is disconnected
// for even a moment while an event fires — phone locks, tab gets backgrounded
// and the browser throttles/suspends the socket, wifi hands off to cellular —
// that event is gone forever. There is no "give me what I missed" call. On a
// turn-based game that shows up as exactly what it looks like: a move that
// "didn't register" (it did, server-side — the client just never heard about
// it), or a screen stuck on "waiting" / showing the wrong turn.
//
// So this hook treats the realtime push as the fast path, not the only path:
//   1. Reconnect with backoff whenever the channel drops (CHANNEL_ERROR /
//      TIMED_OUT / CLOSED), and reconcile with a fresh fetch the moment it's
//      back — so the fetch itself, not just the socket, closes the gap.
//   2. Reconcile immediately on tab foreground and on network-back-online,
//      since those are exactly the moments a missed event is likely.
//   3. Reconcile on a short poll (RECONCILE_MS) as a pure backstop, only
//      while the tab is visible, so a drop that produces no status change at
//      all still can't strand a match for more than one poll tick.
// None of this adds latency to the good path — the realtime push still
// updates state the instant it arrives. This only shortens how long a bad
// path can stay bad.

import { useCallback, useEffect, useRef, useState } from 'react'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from '../../shared/lib/supabase'
import { fetchRoom, fetchRoomPlayers, type RoomRow, type RoomPlayerRow } from './rooms'

export interface RoomPlayerWithProfile extends RoomPlayerRow {
  username: string | null
  display_name: string | null
  avatar: string | null
}

interface ProfileLite {
  id: string
  username: string | null
  display_name: string | null
  avatar: string | null
}

const RECONCILE_MS = 2500
const RETRY_MS_START = 1000
const RETRY_MS_MAX = 10000

/** Cheap identity check so a reconcile fetch that found nothing new doesn't force a re-render. */
function fingerprint(room: RoomRow | null): string {
  if (!room) return ''
  return `${room.status}|${room.turn_user_id ?? ''}|${JSON.stringify(room.game_state)}`
}

export function useRoom(roomId: string | null) {
  const [room, setRoom] = useState<RoomRow | null>(null)
  const [players, setPlayers] = useState<RoomPlayerWithProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fingerprintRef = useRef('')

  const applyRoom = useCallback((next: RoomRow | null) => {
    fingerprintRef.current = fingerprint(next)
    setRoom(next)
  }, [])

  const reloadPlayers = useCallback(async (id: string) => {
    try {
      const rows = await fetchRoomPlayers(id)
      if (rows.length === 0) {
        setPlayers([])
        return
      }
      const ids = rows.map(r => r.user_id)
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username, display_name, avatar')
        .in('id', ids)
      const byId = new Map((((profiles ?? []) as ProfileLite[])).map(p => [p.id, p]))
      setPlayers(rows.map(r => ({
        ...r,
        username: byId.get(r.user_id)?.username ?? null,
        display_name: byId.get(r.user_id)?.display_name ?? null,
        avatar: byId.get(r.user_id)?.avatar ?? null,
      })))
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load players')
    }
  }, [])

  const refetchRoom = useCallback(async (id: string) => {
    try {
      const r = await fetchRoom(id)
      // Skip the state update (and the re-render) when nothing changed —
      // this runs on every poll tick, so it needs to be cheap when idle.
      if (fingerprint(r) !== fingerprintRef.current) applyRoom(r)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load room')
    }
  }, [applyRoom])

  const reconcile = useCallback((id: string) => {
    void refetchRoom(id)
    void reloadPlayers(id)
  }, [refetchRoom, reloadPlayers])

  useEffect(() => {
    if (!roomId) { applyRoom(null); setPlayers([]); setLoading(false); return }
    const id = roomId
    let cancelled = false
    let channel: RealtimeChannel | null = null
    let retryTimer: ReturnType<typeof setTimeout> | null = null
    let retryDelay = RETRY_MS_START

    setLoading(true)
    setError(null)

    Promise.all([fetchRoom(id), reloadPlayers(id)])
      .then(([r]) => { if (!cancelled) applyRoom(r) })
      .catch((e: unknown) => { if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load room') })
      .finally(() => { if (!cancelled) setLoading(false) })

    function clearRetryTimer() {
      if (retryTimer) { clearTimeout(retryTimer); retryTimer = null }
    }

    function subscribe() {
      if (cancelled) return
      const ch = supabase
        .channel(`room:${id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms', filter: `id=eq.${id}` }, (payload) => {
          if (payload.eventType === 'DELETE') { applyRoom(null); return }
          applyRoom(payload.new as RoomRow)
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'room_players', filter: `room_id=eq.${id}` }, () => {
          void reloadPlayers(id)
        })
        .subscribe((status) => {
          if (cancelled) return
          if (status === 'SUBSCRIBED') {
            retryDelay = RETRY_MS_START
            // Catch up on anything that landed while this socket was
            // (re)connecting — postgres_changes has no replay, so this
            // fetch is what actually closes the gap, not the subscribe call.
            reconcile(id)
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
            clearRetryTimer()
            const delay = retryDelay
            retryDelay = Math.min(retryDelay * 2, RETRY_MS_MAX)
            retryTimer = setTimeout(() => {
              if (cancelled) return
              supabase.removeChannel(ch)
              subscribe()
            }, delay)
          }
        })
      channel = ch
    }

    subscribe()

    function handleVisible() {
      if (document.visibilityState === 'visible') reconcile(id)
    }
    function handleOnline() {
      reconcile(id)
    }
    document.addEventListener('visibilitychange', handleVisible)
    window.addEventListener('online', handleOnline)

    const pollTimer = setInterval(() => {
      if (document.visibilityState === 'visible') reconcile(id)
    }, RECONCILE_MS)

    return () => {
      cancelled = true
      clearRetryTimer()
      clearInterval(pollTimer)
      document.removeEventListener('visibilitychange', handleVisible)
      window.removeEventListener('online', handleOnline)
      if (channel) supabase.removeChannel(channel)
    }
  }, [roomId, reloadPlayers, refetchRoom, reconcile, applyRoom])

  return { room, players, loading, error }
}
