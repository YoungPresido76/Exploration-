// src/features/multiplayer/play/ChillMergeResultModal.tsx
// End-of-match screen for multiplayer Chill Merge. Thin wrapper around the
// shared MultiplayerResultModal (see that file for the actual overlay markup) —
// this file just maps Chill Merge's state (score/merges/XP) onto the generic
// props. XP is animated the same way solo's ResultScreen does (a beat after
// the score finishes), at the multiplayer rate (double solo's per-merge XP —
// see merge_resolve in the tile_merge_multiplayer_double_xp_and_early_finish
// migration).
import { Layers } from 'lucide-react'
import MultiplayerResultModal, { useCountUp } from './MultiplayerResultModal'
import type { MergeState } from '../multiplayerGames'

// Mirrors TileMerge.tsx's solo MERGE_XP (6), doubled — kept in sync with
// the server-side v_merge_xp constant in merge_resolve().
const MULTIPLAYER_MERGE_XP = 12

interface PlayerCardInfo {
  userId: string
  name: string
  avatar: string | null
}

interface Props {
  state: MergeState
  accent: string
  me: PlayerCardInfo
  opponent: PlayerCardInfo
  myScore: number
  opponentScore: number
  myMerges: number
  opponentMerges: number
  isHost: boolean
  startBusy: boolean
  onRematch: () => void
}

export default function ChillMergeResultModal({
  state, accent, me, opponent, myScore, opponentScore, myMerges, opponentMerges, isHost, startBusy, onRematch,
}: Props) {
  const iWon = state.winner === me.userId
  const isDraw = state.is_draw
  const myXP = myMerges * MULTIPLAYER_MERGE_XP
  const displayXP = useCountUp(myXP, 500)

  const headline = isDraw ? "🤝 It's a tie!" : iWon ? '🏆 You win!' : `${opponent.name} wins!`
  const headlineColor = isDraw ? 'var(--text-muted)' : iWon ? accent : 'var(--text-muted)'

  return (
    <MultiplayerResultModal
      accent={accent}
      headline={headline}
      headlineColor={headlineColor}
      isDraw={isDraw}
      me={{ userId: me.userId, name: me.name, avatar: me.avatar, score: myScore, caption: `${myMerges} merges` }}
      opponent={{ userId: opponent.userId, name: opponent.name, avatar: opponent.avatar, score: opponentScore, caption: `${opponentMerges} merges` }}
      stats={[
        { label: 'XP Earned', value: `+${displayXP}`, color: 'var(--accent)' },
        { label: 'Result', value: isDraw ? 'Draw' : iWon ? 'Win' : 'Loss', color: headlineColor },
      ]}
      isHost={isHost}
      startBusy={startBusy}
      onRematch={onRematch}
      rematchLabel="Rematch"
      rematchIcon={<Layers size={13} style={{ marginRight: 6, verticalAlign: -2 }} />}
    />
  )
}
