// src/features/multiplayer/play/MultiplayerResultModal.tsx
// Shared end-of-match screen for every live "Vs Players" game (Tac Zone,
// Pattern King, Chill Merge). Renders as a genuine modal overlay (same
// .overlay-backdrop + neu-card + popUp pattern used by GameShell's
// QuitModal) and shows both players by avatar/name side by side rather
// than a generic "You win!" line, so every live game gets the same
// finished-match feel instead of each screen inventing its own.
//
// Originally this UI lived only in ChillMergeResultModal.tsx; it's been
// generalized here so Tac Zone and Pattern King can use it too — see
// TacZoneMultiplayer.tsx and PatternKingRelay.tsx. ChillMergeResultModal
// is now a thin wrapper around this component.
import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { Trophy } from 'lucide-react'
import Avatar from '../../../shared/components/Avatar'

export interface ResultStat {
  label: string
  value: string
  color?: string
}

export interface PlayerResultInfo {
  userId: string
  name: string
  avatar: string | null
  /** Main number shown under the avatar (animated with a count-up). */
  score: number
  /** Small caption under the score, e.g. "6 merges", "3 rounds". */
  caption?: string
}

interface Props {
  accent: string
  headline: string
  headlineColor: string
  isDraw?: boolean
  /** Who won, for the avatar ring highlight. Defaults to comparing scores when omitted (fine when scores differ, as in Tac Zone/Chill Merge — but Pattern King's score is shared by both players, so it passes this explicitly). */
  iWon?: boolean
  me: PlayerResultInfo
  opponent: PlayerResultInfo
  /** Rendered as a 2-column stat grid, same slot Chill Merge uses for XP/Result. */
  stats: ResultStat[]
  isHost: boolean
  startBusy: boolean
  onRematch: () => void
  rematchLabel?: string
  rematchIcon?: ReactNode
  waitingLabel?: string
}

export function useCountUp(target: number, delayMs: number, durationMs = 900) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    setValue(0)
    const steps = 30
    let cancelled = false
    const startTimer = setTimeout(() => {
      let step = 0
      const t = setInterval(() => {
        if (cancelled) return
        step++
        setValue(Math.min(Math.round((target / steps) * step), target))
        if (step >= steps) clearInterval(t)
      }, durationMs / steps)
    }, delayMs)
    return () => { cancelled = true; clearTimeout(startTimer) }
  }, [target, delayMs, durationMs])
  return value
}

export default function MultiplayerResultModal({
  accent, headline, headlineColor, isDraw, iWon: iWonProp, me, opponent, stats,
  isHost, startBusy, onRematch, rematchLabel = 'Rematch', rematchIcon, waitingLabel = 'Waiting for host to start a rematch…',
}: Props) {
  const iWon = iWonProp ?? (!isDraw && me.score >= opponent.score && me.score !== opponent.score)
  const displayMyScore = useCountUp(me.score, 0, 700)
  const displayOppScore = useCountUp(opponent.score, 0, 700)

  return (
    <>
      <div className="overlay-backdrop" />
      <div style={{ position: 'fixed', inset: 0, zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div className="neu-card" style={{ padding: '26px 22px', textAlign: 'center', maxWidth: 340, width: '100%', animation: 'popUp 0.3s cubic-bezier(0.34,1.56,0.64,1) both' }}>
          <div style={{ marginBottom: 10 }}>
            <Trophy size={40} style={{ color: isDraw ? 'var(--text-muted)' : accent }} />
          </div>
          <p style={{ fontSize: 19, fontWeight: 900, color: headlineColor, marginBottom: 18 }}>{headline}</p>

          {/* Head-to-head row — both players by avatar and name, not just a generic result line. */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, marginBottom: 20 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flex: 1 }}>
              <Avatar src={me.avatar} name={me.name} size={52} ring={!isDraw && iWon ? accent : undefined} />
              <div style={{ fontSize: 20, fontWeight: 800, fontFamily: 'monospace', color: accent }}>{displayMyScore}</div>
              <div style={{ fontSize: 10.5, color: 'var(--text-muted)', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 100 }}>{me.name}</div>
              {me.caption && <div style={{ fontSize: 9.5, color: 'var(--text-muted)' }}>{me.caption}</div>}
            </div>
            <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--text-muted)', flexShrink: 0 }}>VS</div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flex: 1 }}>
              <Avatar src={opponent.avatar} name={opponent.name} size={52} ring={!isDraw && !iWon ? 'var(--text-muted)' : undefined} />
              <div style={{ fontSize: 20, fontWeight: 800, fontFamily: 'monospace', color: 'var(--text)' }}>{displayOppScore}</div>
              <div style={{ fontSize: 10.5, color: 'var(--text-muted)', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 100 }}>{opponent.name}</div>
              {opponent.caption && <div style={{ fontSize: 9.5, color: 'var(--text-muted)' }}>{opponent.caption}</div>}
            </div>
          </div>

          {/* Stats — mirrors solo ResultScreen's 2x2 grid. */}
          {stats.length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 20 }}>
              {stats.map(({ label, value, color }) => (
                <div key={label} style={{ background: 'var(--surface2)', borderRadius: 10, padding: '10px 12px', textAlign: 'left' }}>
                  <div style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 3, fontWeight: 700 }}>{label}</div>
                  <div style={{ fontSize: 16, fontWeight: 800, color: color ?? 'var(--text)', fontFamily: 'monospace' }}>{value}</div>
                </div>
              ))}
            </div>
          )}

          {isHost ? (
            <button onClick={onRematch} disabled={startBusy} style={{ padding: '11px 22px', borderRadius: 13, background: `linear-gradient(135deg, ${accent}, ${accent}bb)`, border: 'none', color: '#fff', fontSize: 13.5, fontWeight: 700, cursor: 'pointer', width: '100%' }}>
              {rematchIcon}{startBusy ? 'Starting…' : rematchLabel}
            </button>
          ) : (
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{waitingLabel}</p>
          )}
        </div>
      </div>
    </>
  )
}
