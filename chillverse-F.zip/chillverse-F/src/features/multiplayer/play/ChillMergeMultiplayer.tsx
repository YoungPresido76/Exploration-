// src/features/multiplayer/play/ChillMergeMultiplayer.tsx
// Renders inside Room.tsx once a Chill Merge room is in_progress.
//
// This is NOT a shared board — it's a simultaneous score race (Option A).
// Each player places tiles on their own private 4x4 board for the same 90s
// window, same rules and same "Place Now / Next Up" queue as the solo game
// (src/features/games/play/TileMerge.tsx). The only thing that crosses the
// wire mid-match is a score number, roughly every 5s — see REPORT_MS below —
// which is what makes the opponent's score update live without needing any
// per-move server round trip (and so nothing here can "lag" a placement).
//
// CLOCK NOTE: the 90s deadline is computed from the server-issued
// started_at, but compared against each device's own clock. A client whose
// clock runs ahead of the server would otherwise see the round as "already
// over" the instant it starts, and every tap would silently do nothing —
// no error, just an unresponsive board. clockOffsetRef corrects for that:
// one cheap server_now() call on mount gives us how far off this device's
// clock is, and every deadline check below uses that corrected time instead
// of a raw Date.now().
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { MouseEvent as ReactMouseEvent } from 'react'
import { Star, Flag, Heart, Flame as FlameIcon, Zap } from 'lucide-react'
import { mergeStart, mergeReportScore, mergeFinish, mergeTimeout, fetchServerNowMs, type MergeState } from '../multiplayerGames'
import type { RoomRow } from '../rooms'
import type { RoomPlayerWithProfile } from '../useRoom'
import { ripple } from '../../../shared/lib/ripple'
import ChillMergeResultModal from './ChillMergeResultModal'

const ACCENT = '#38bdf8'
const GRID = 4
const CELLS = GRID * GRID

// How often a client pushes its current score up so the opponent sees it
// live. The 90s round tolerates this easily — this is a display refresh
// rate, not a gameplay-critical sync (placements never leave the client).
const REPORT_MS = 5000
const TICK_MS = 100

type TileColor = 'yellow' | 'blue' | 'purple' | 'red'
const COLORS: TileColor[] = ['yellow', 'blue', 'purple', 'red']

const COLOR_META: Record<TileColor, { base: string; light: string; Icon: typeof Star; filled: boolean }> = {
  yellow: { base: '#f5c542', light: '#ffe08a', Icon: Star, filled: true },
  blue:   { base: '#4f8ef7', light: '#8ab4ff', Icon: Flag, filled: true },
  purple: { base: '#9b6dff', light: '#c3a8ff', Icon: Heart, filled: true },
  red:    { base: '#ff5f4f', light: '#ff9a8f', Icon: FlameIcon, filled: true },
}

interface Tile { color: TileColor; level: number }
type Cell = Tile | null

// New tiles are always handed out at level 1 — every higher level can only
// be reached by merging a triple. No other level ever spawns directly.
function randomTile(): Tile {
  return {
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
    level: 1,
  }
}

function fontSizeForLevel(level: number): number {
  const digits = String(level).length
  if (digits <= 2) return 22
  if (digits === 3) return 16
  return 13
}

function tileKey(t: Tile): string {
  return `${t.color}:${t.level}`
}

function idxToRC(i: number): { r: number; c: number } {
  return { r: Math.floor(i / GRID), c: i % GRID }
}

/** Same adjacency rule as the solo game: a straight 3 or a 2x2/L-shape — matching tiles scattered elsewhere don't count. */
function isAdjacentTriple(cells: number[]): boolean {
  const rc = cells.map(idxToRC)
  const rows = rc.map(p => p.r)
  const cols = rc.map(p => p.c)
  const rowSpan = Math.max(...rows) - Math.min(...rows)
  const colSpan = Math.max(...cols) - Math.min(...cols)
  if (rowSpan === 0 && colSpan === 2) return true
  if (colSpan === 0 && rowSpan === 2) return true
  if (rowSpan <= 1 && colSpan <= 1) return true
  return false
}

function combinationsOf3(arr: number[]): number[][] {
  const out: number[][] = []
  for (let i = 0; i < arr.length - 2; i++)
    for (let j = i + 1; j < arr.length - 1; j++)
      for (let k = j + 1; k < arr.length; k++)
        out.push([arr[i], arr[j], arr[k]])
  return out
}

function findGroups(board: Cell[]): { key: string; cells: number[] }[] {
  const byKey = new Map<string, number[]>()
  board.forEach((cell, i) => {
    if (!cell) return
    const k = tileKey(cell)
    const arr = byKey.get(k) ?? []
    arr.push(i)
    byKey.set(k, arr)
  })
  const groups: { key: string; cells: number[] }[] = []
  for (const [key, cells] of byKey) {
    if (cells.length < 3) continue
    for (const combo of combinationsOf3(cells)) {
      if (isAdjacentTriple(combo)) {
        groups.push({ key, cells: combo })
        break
      }
    }
  }
  return groups
}

function emptyBoard(): Cell[] {
  return Array.from({ length: CELLS }, () => null)
}

interface Props {
  room: RoomRow
  players: RoomPlayerWithProfile[]
  userId: string
  isHost: boolean
}

export default function ChillMergeMultiplayer({ room, players, userId, isHost }: Props) {
  const state = room.game_state as MergeState | null
  const opponent = players.find(p => p.user_id !== userId)

  const [startBusy, setStartBusy] = useState(false)
  const [startError, setStartError] = useState('')
  const [now, setNow] = useState(Date.now())

  const [board, setBoard] = useState<Cell[]>(emptyBoard)
  const [current, setCurrent] = useState<Tile>(randomTile)
  const [next, setNext] = useState<Tile>(randomTile)
  const [score, setScore] = useState(0)
  const [mergeCount, setMergeCount] = useState(0)
  const [popPositions, setPopPositions] = useState<number[]>([])
  const [groups, setGroups] = useState<{ key: string; cells: number[] }[]>([])
  const [boardFull, setBoardFull] = useState(false)

  const startedKeyRef = useRef<string | null>(null)
  const lastReportRef = useRef(0)
  const finishSentRef = useRef<string | null>(null) // started_at we've already called mergeFinish for
  const timeoutSentRef = useRef<string | null>(null)
  const fullSentRef = useRef<string | null>(null) // started_at we've already sent the immediate p_full report for
  // How far ahead (+) or behind (-) this device's clock is vs the server's,
  // in ms. Applied to every Date.now() used for deadline math below.
  const clockOffsetRef = useRef(0)

  // One cheap round trip on mount to learn this device's clock skew.
  useEffect(() => {
    let cancelled = false
    fetchServerNowMs()
      .then(serverMs => { if (!cancelled) clockOffsetRef.current = serverMs - Date.now() })
      .catch(() => {}) // worst case we fall back to trusting the local clock
    return () => { cancelled = true }
  }, [])

  // 10x/sec clock — countdown display + deadline triggers.
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), TICK_MS)
    return () => clearInterval(t)
  }, [])

  const correctedNow = now + clockOffsetRef.current

  // Fresh local board exactly once per match (gated on started_at, not on
  // every game_state update — those arrive constantly as scores stream in).
  useEffect(() => {
    if (!state || startedKeyRef.current === state.started_at) return
    startedKeyRef.current = state.started_at
    finishSentRef.current = null
    timeoutSentRef.current = null
    fullSentRef.current = null
    lastReportRef.current = 0
    setBoard(emptyBoard())
    setCurrent(randomTile())
    setNext(randomTile())
    setScore(0)
    setMergeCount(0)
    setGroups([])
    setPopPositions([])
    setBoardFull(false)
  }, [state?.started_at])

  const deadline = state ? new Date(state.started_at).getTime() + state.duration_sec * 1000 : null
  const secLeft = deadline ? Math.max(0, (deadline - correctedNow) / 1000) : 0
  const roundOver = deadline !== null && correctedNow >= deadline
  const matchOver = !!state && (state.winner !== null || state.is_draw)
  const iAmDone = boardFull || roundOver

  const reportScore = useCallback((value: number, merges: number, full = false) => {
    if (!state || finishSentRef.current === state.started_at) return
    void mergeReportScore(room.id, value, merges, full).catch(() => {})
  }, [room.id, state])

  // Push score roughly every REPORT_MS while the round is live.
  useEffect(() => {
    if (!state || matchOver || iAmDone) return
    const elapsed = now - lastReportRef.current
    if (lastReportRef.current === 0 || elapsed >= REPORT_MS) {
      lastReportRef.current = now
      reportScore(score, mergeCount)
    }
  }, [now, score, mergeCount, state, matchOver, iAmDone, reportScore])

  // The instant this client's board fills — independent of the REPORT_MS
  // cadence above — flag it server-side via p_full. Once both players'
  // boards are flagged full, merge_report_score resolves the match right
  // there instead of everyone waiting out the rest of the 90s clock.
  useEffect(() => {
    if (!state || matchOver) return
    if (!boardFull) return
    if (fullSentRef.current === state.started_at) return
    fullSentRef.current = state.started_at
    reportScore(score, mergeCount, true)
  }, [boardFull, state, matchOver, score, mergeCount, reportScore])

  // Once the deadline passes (or the board fills early), send the final
  // score exactly once. The server won't accept it before duration_sec-2s
  // regardless, so an early board-full just waits here quietly (the
  // p_full report above may have already resolved the match by then).
  useEffect(() => {
    if (!state || matchOver) return
    if (!iAmDone) return
    if (finishSentRef.current === state.started_at) return
    if (!roundOver) return // board filled early — wait for the clock, nothing to send yet
    finishSentRef.current = state.started_at
    void mergeFinish(room.id, score, mergeCount).catch(() => { finishSentRef.current = null })
  }, [state, matchOver, iAmDone, roundOver, room.id, score, mergeCount])

  // Safety net: if the opponent's client never reports finishing (closed
  // the tab, connection dropped), force resolution well past the deadline
  // so this match can't hang forever. Mirrors PatternKingRelay's pk_timeout use.
  useEffect(() => {
    if (!state || matchOver || !deadline) return
    if (correctedNow < deadline + 15000) return
    if (timeoutSentRef.current === state.started_at) return
    timeoutSentRef.current = state.started_at
    void mergeTimeout(room.id).catch(() => { timeoutSentRef.current = null })
  }, [correctedNow, state, matchOver, deadline, room.id])

  const highlightedCells = useMemo(() => new Set(groups.flatMap(g => g.cells)), [groups])
  const resolving = groups.length > 0

  function placeTile(i: number) {
    if (!state || matchOver || iAmDone || resolving) return
    if (board[i] !== null) return

    const nb = board.slice()
    nb[i] = current
    const foundGroups = findGroups(nb)
    const newScore = score + 1

    setBoard(nb)
    setScore(newScore)
    setPopPositions([i])
    setTimeout(() => setPopPositions([]), 220)

    if (foundGroups.length > 0) {
      setGroups(foundGroups)
      return
    }

    setCurrent(next)
    setNext(randomTile())
    if (nb.every(c => c !== null)) setBoardFull(true)
  }

  function resolveTap(i: number) {
    const group = groups.find(g => g.cells.includes(i))
    if (!group) return
    const mergedTile = board[group.cells[0]]
    if (!mergedTile) return
    const newLevel = mergedTile.level + 1

    const nb = board.slice()
    for (const c of group.cells) nb[c] = null
    nb[i] = { color: mergedTile.color, level: newLevel }

    const newScore = score + newLevel * 5
    setBoard(nb)
    setScore(newScore)
    setMergeCount(c => c + 1)
    setPopPositions([i])
    setTimeout(() => setPopPositions([]), 220)

    const nextGroups = findGroups(nb)
    setGroups(nextGroups)
    if (nextGroups.length > 0) return
    if (nb.every(c => c !== null)) setBoardFull(true)
  }

  function handleCellClick(e: ReactMouseEvent<HTMLDivElement>, i: number) {
    if (!state || matchOver || iAmDone) return
    if (resolving) {
      if (!highlightedCells.has(i)) return
      ripple(e)
      resolveTap(i)
    } else {
      if (board[i] !== null) return
      ripple(e)
      placeTile(i)
    }
  }

  async function start() {
    setStartBusy(true); setStartError('')
    try { await mergeStart(room.id) } catch (e) { setStartError(e instanceof Error ? e.message : 'Failed to start') }
    setStartBusy(false)
  }

  if (!state) {
    return (
      <div style={{ textAlign: 'center', padding: '30px 16px' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 6 }}>90 seconds. Same board rules, your own board.</p>
        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 14 }}>Highest score when time's up wins — you'll see their score update live as you play.</p>
        {isHost && (
          <button onClick={start} disabled={startBusy} style={{ padding: '11px 24px', borderRadius: 13, background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT}bb)`, border: 'none', color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
            {startBusy ? 'Starting…' : 'Start Race'}
          </button>
        )}
        {startError && <p style={{ color: '#ff6b6b', fontSize: 12, marginTop: 10 }}>{startError}</p>}
      </div>
    )
  }

  const opponentScore = state.scores[opponent?.user_id ?? ''] ?? 0
  const opponentName = opponent?.display_name ?? opponent?.username ?? 'Opponent'
  const opponentMerges = state.merges?.[opponent?.user_id ?? ''] ?? 0
  const me = players.find(p => p.user_id === userId)
  const myName = me?.display_name ?? me?.username ?? 'You'
  const myMerges = state.merges?.[userId] ?? mergeCount
  const iAmAhead = score > opponentScore
  const isTied = score === opponentScore

  if (matchOver) {
    return (
      <ChillMergeResultModal
        state={state}
        accent={ACCENT}
        me={{ userId, name: myName, avatar: me?.avatar ?? null }}
        opponent={{ userId: opponent?.user_id ?? '', name: opponentName, avatar: opponent?.avatar ?? null }}
        myScore={state.scores[userId] ?? score}
        opponentScore={opponentScore}
        myMerges={myMerges}
        opponentMerges={opponentMerges}
        isHost={isHost}
        startBusy={startBusy}
        onRematch={start}
      />
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '4px 0 8px', width: '100%' }}>
      {/* Live score bar — this is the "multiplayer feel": both scores, right next to each other, updating as you play. */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%', maxWidth: 320 }}>
        <div style={{ flex: 1, textAlign: 'center', padding: '8px 6px', borderRadius: 12, background: `${ACCENT}14`, border: `1px solid ${ACCENT}33` }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: ACCENT }}>{score}</div>
          <div style={{ fontSize: 9.5, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>You</div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 800,
          color: secLeft < 15 ? '#ff6b6b' : 'var(--text)', flexShrink: 0,
        }}>
          <Zap size={12} /> {Math.ceil(secLeft)}s
        </div>
        <div style={{ flex: 1, textAlign: 'center', padding: '8px 6px', borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text)' }}>{opponentScore}</div>
          <div style={{ fontSize: 9.5, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{opponentName}</div>
        </div>
      </div>

      <div style={{ width: '100%', maxWidth: 320, height: 4, background: 'var(--surface2)', borderRadius: 4, overflow: 'hidden' }}>
        <div style={{ height: '100%', background: secLeft < 15 ? '#ff6b6b' : ACCENT, width: `${(secLeft / state.duration_sec) * 100}%`, transition: 'width 0.1s linear' }} />
      </div>

      <p style={{ fontSize: 11.5, fontWeight: 700, color: isTied ? 'var(--text-muted)' : iAmAhead ? ACCENT : '#ff9a3c' }}>
        {iAmDone ? "Board full — waiting for time…" : isTied ? "Dead even" : iAmAhead ? `Ahead by ${score - opponentScore}` : `Behind by ${opponentScore - score}`}
      </p>

      {resolving && (
        <p style={{ fontSize: 12, fontWeight: 800, color: ACCENT, textTransform: 'uppercase', letterSpacing: '0.6px', animation: 'cm-textPulse 1.1s ease-in-out infinite' }}>
          Tap a highlighted tile to merge
        </p>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${GRID}, 68px)`, gridTemplateRows: `repeat(${GRID}, 68px)`, gap: 6 }}>
        {board.map((cell, i) => {
          const isHighlighted = highlightedCells.has(i)
          const dimmed = resolving && !isHighlighted
          const popped = popPositions.includes(i)
          const meta = cell ? COLOR_META[cell.color] : null
          const Icon = meta?.Icon
          const clickable = !iAmDone && !matchOver && (!resolving ? cell === null : isHighlighted)
          return (
            <div
              key={i}
              onClick={(e) => handleCellClick(e, i)}
              style={{
                width: 68, height: 68, borderRadius: 14,
                cursor: clickable ? 'pointer' : 'default',
                background: cell && meta ? `linear-gradient(135deg, ${meta.light}, ${meta.base})` : 'var(--surface)',
                border: isHighlighted ? '2px solid #fff' : '1px solid var(--border)',
                opacity: dimmed ? 0.32 : 1,
                filter: dimmed ? 'grayscale(0.6)' : 'none',
                boxShadow: isHighlighted ? `0 0 16px ${meta?.base ?? ACCENT}99` : '3px 3px 8px var(--neu-dark), -2px -2px 6px var(--neu-light)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                position: 'relative',
                transform: isHighlighted ? 'scale(1.06)' : popped ? 'scale(1.1)' : 'scale(1)',
                transition: 'transform 180ms var(--ease-out), opacity 180ms var(--ease-out), box-shadow 180ms var(--ease-out)',
                animation: isHighlighted ? 'cm-heartbeat 0.9s ease-in-out infinite' : undefined,
              }}
            >
              {cell && Icon && (
                <>
                  <Icon size={12} fill={meta?.filled ? 'rgba(255,255,255,0.85)' : 'none'} style={{ color: 'rgba(255,255,255,0.85)', position: 'absolute', top: 6, left: 6 }} />
                  <span style={{ fontSize: fontSizeForLevel(cell.level), fontWeight: 800, color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,0.35)' }}>{cell.level}</span>
                </>
              )}
            </div>
          )
        })}
      </div>

      {/* Place Now / Next Up — same queue the solo game shows, so you always know what you're about to drop and what's coming after. */}
      {!resolving && !iAmDone && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, marginTop: 2 }}>
          <div style={{ display: 'flex', gap: 22 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
              <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.8px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Place Now</span>
              <QueueTile tile={current} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, opacity: 0.65 }}>
              <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.8px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Next Up</span>
              <QueueTile tile={next} small />
            </div>
          </div>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'center' }}>Tap any empty cell to place it</p>
        </div>
      )}

      <style>{`
        @keyframes cm-heartbeat { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
        @keyframes cm-textPulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
      `}</style>
    </div>
  )
}

function QueueTile({ tile, small }: { tile: Tile; small?: boolean }) {
  const meta = COLOR_META[tile.color]
  const Icon = meta.Icon
  const size = small ? 48 : 58
  return (
    <div style={{
      width: size, height: size, borderRadius: 14,
      background: `linear-gradient(135deg, ${meta.light}, ${meta.base})`,
      boxShadow: `0 0 12px ${meta.base}55, 3px 3px 8px var(--neu-dark)`,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      position: 'relative',
    }}>
      <Icon size={11} fill={meta.filled ? 'rgba(255,255,255,0.85)' : 'none'} style={{ color: 'rgba(255,255,255,0.85)', position: 'absolute', top: 5, left: 5 }} />
      <span style={{ fontSize: small ? 18 : 22, fontWeight: 800, color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,0.35)' }}>{tile.level}</span>
    </div>
  )
}
