// src/pages/games/TacZoneMultiplayer.tsx
// Renders inside Room.tsx once a Tac Zone room is in_progress. All logic
// (turn validation, win detection, XP) lives server-side in tac_move/tac_start —
// this component just reflects room.game_state and calls the RPCs.
import { useState } from 'react'
import { X, Circle, Grid3X3 as RematchIcon } from 'lucide-react'
import { tacMove, tacStart, type TacState } from '../multiplayerGames'
import type { RoomRow } from '../rooms'
import type { RoomPlayerWithProfile } from '../useRoom'
import MultiplayerResultModal from './MultiplayerResultModal'

// Mirrors tac_move()'s server-side v_win_xp/v_draw_xp/v_lose_xp constants —
// XP itself is awarded in Postgres; these are only used to show the number
// the player already earned.
const TAC_WIN_XP = 40
const TAC_DRAW_XP = 15
const TAC_LOSE_XP = 5
const TAC_WIN_SCORE = 100
const TAC_DRAW_SCORE = 30
const TAC_LOSE_SCORE = 0

const ACCENT = '#3ecf8e'

interface Props {
  room: RoomRow
  players: RoomPlayerWithProfile[]
  userId: string
  isHost: boolean
}

export default function TacZoneMultiplayer({ room, players, userId, isHost }: Props) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const state = room.game_state as TacState | null

  const opponent = players.find(p => p.user_id !== userId)
  const me = players.find(p => p.user_id === userId)

  async function rematch() {
    setBusy(true); setError('')
    try { await tacStart(room.id) } catch (e: any) { setError(e.message) }
    setBusy(false)
  }

  if (!state) {
    return (
      <div style={{ textAlign: 'center', padding: '30px 16px' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 14 }}>Ready to play Tac Zone.</p>
        {isHost && (
          <button onClick={rematch} disabled={busy} style={{ padding: '11px 24px', borderRadius: 13, background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT}bb)`, border: 'none', color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
            {busy ? 'Starting…' : 'Start Match'}
          </button>
        )}
        {error && <p style={{ color: '#ff6b6b', fontSize: 12, marginTop: 10 }}>{error}</p>}
      </div>
    )
  }

  const mySymbol = state.players.X === userId ? 'X' : 'O'
  const isMyTurn = room.turn_user_id === userId
  const gameOver = !!state.winner

  async function tapCell(idx: number) {
    if (!state || busy || gameOver || !isMyTurn || state.board[idx]) return
    setBusy(true); setError('')
    try { await tacMove(room.id, idx) } catch (e: any) { setError(e.message) }
    setBusy(false)
  }

  const iWon = state.winner === mySymbol
  const isDraw = state.winner === 'draw'

  if (gameOver) {
    const opponentName = opponent?.display_name ?? opponent?.username ?? 'Opponent'
    const myXP = isDraw ? TAC_DRAW_XP : iWon ? TAC_WIN_XP : TAC_LOSE_XP
    const myScore = isDraw ? TAC_DRAW_SCORE : iWon ? TAC_WIN_SCORE : TAC_LOSE_SCORE
    const opponentScore = isDraw ? TAC_DRAW_SCORE : iWon ? TAC_LOSE_SCORE : TAC_WIN_SCORE
    const headline = isDraw ? "🤝 It's a tie!" : iWon ? '🏆 You win!' : `${opponentName} wins!`
    const headlineColor = isDraw ? 'var(--text-muted)' : iWon ? ACCENT : 'var(--text-muted)'

    return (
      <MultiplayerResultModal
        accent={ACCENT}
        headline={headline}
        headlineColor={headlineColor}
        isDraw={isDraw}
        me={{ userId, name: me?.display_name ?? me?.username ?? 'You', avatar: me?.avatar ?? null, score: myScore }}
        opponent={{ userId: opponent?.user_id ?? '', name: opponentName, avatar: opponent?.avatar ?? null, score: opponentScore }}
        stats={[
          { label: 'XP Earned', value: `+${myXP}`, color: 'var(--accent)' },
          { label: 'Result', value: isDraw ? 'Draw' : iWon ? 'Win' : 'Loss', color: headlineColor },
        ]}
        isHost={isHost}
        startBusy={busy}
        onRematch={rematch}
        rematchIcon={<RematchIcon size={13} style={{ marginRight: 6, verticalAlign: -2 }} />}
      />
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, padding: '4px 0 8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: ACCENT, background: `${ACCENT}18`, border: `1px solid ${ACCENT}33`, borderRadius: 12, padding: '4px 10px' }}>
          You are {mySymbol}
        </span>
        <p style={{ fontSize: 13.5, fontWeight: 700, minHeight: 20, color: isMyTurn ? ACCENT : 'var(--text-muted)' }}>
          {isMyTurn ? 'Your move' : `Waiting on ${opponent?.display_name ?? opponent?.username ?? 'opponent'}…`}
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 78px)', gridTemplateRows: 'repeat(3, 78px)', gap: 8 }}>
        {state.board.map((cell, i) => (
          <button key={i} type="button" onClick={() => tapCell(i)} disabled={!!cell || !isMyTurn}
            style={{
              width: 78, height: 78, borderRadius: 18, cursor: cell || !isMyTurn ? 'default' : 'pointer',
              background: 'var(--surface)',
              boxShadow: '4px 4px 12px var(--neu-dark), -3px -3px 8px var(--neu-light)',
              border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'background-color var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
            }}>
            {cell === 'X' && <X size={34} style={{ color: ACCENT }} />}
            {cell === 'O' && <Circle size={30} style={{ color: 'var(--pink)' }} />}
          </button>
        ))}
      </div>

      {error && <p style={{ color: '#ff6b6b', fontSize: 12 }}>{error}</p>}
    </div>
  )
}
