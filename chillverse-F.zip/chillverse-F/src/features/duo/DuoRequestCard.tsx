// src/features/duo/DuoRequestCard.tsx
//
// The accept/reject card that lands in the recipient's DM thread. The
// message row (type 'duo_request') is only the anchor — the live status
// comes from duo_requests, so a request answered on another device shows
// as answered here without a refresh, and an expired one can't be
// accepted from stale UI.

import { useEffect, useState } from 'react'
import { VenetianMask } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { respondToDuoRequest, duoErrorText } from './duo'

interface DuoRequestCardProps {
  /** Sender of the message row this card is anchored to. */
  senderId: string
  /** Message text, used as the headline. */
  content: string
  /** True when the viewer is the one who SENT the request. */
  isMine: boolean
}

type Status = 'pending' | 'accepted' | 'rejected' | 'cancelled' | 'expired' | 'unknown'

export default function DuoRequestCard({ senderId, content, isMine }: DuoRequestCardProps) {
  const [status, setStatus] = useState<Status>('unknown')
  const [requestId, setRequestId] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false

    async function load() {
      // RLS already limits duo_requests to the two participants, so the
      // sender filter alone is enough to find ours.
      const { data } = await supabase
        .from('duo_requests')
        .select('id, status, expires_at')
        .eq('sender_id', senderId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle<{ id: string; status: Status; expires_at: string }>()

      if (cancelled) return
      if (!data) { setStatus('unknown'); return }
      setRequestId(data.id)
      setStatus(
        data.status === 'pending' && new Date(data.expires_at) <= new Date()
          ? 'expired'
          : data.status,
      )
    }

    load()
    const channel = supabase
      .channel(`duo-req-card-${senderId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'duo_requests' }, load)
      .subscribe()

    return () => { cancelled = true; supabase.removeChannel(channel) }
  }, [senderId])

  async function respond(accept: boolean) {
    if (!requestId) return
    setBusy(true); setError(null)
    const { error: err } = await respondToDuoRequest(requestId, accept)
    setBusy(false)
    if (err) { setError(duoErrorText(err)); return }
    setStatus(accept ? 'accepted' : 'rejected')
  }

  const settled =
    status === 'accepted' ? 'Duo started 🎭'
    : status === 'rejected' ? 'Request declined'
    : status === 'cancelled' ? 'Request withdrawn'
    : status === 'expired' ? 'Request expired'
    : null

  return (
    <div style={{ display: 'flex', justifyContent: 'center', margin: '10px 0' }}>
      <div style={{
        maxWidth: 320, width: '100%', padding: 14, borderRadius: 16,
        background: 'linear-gradient(135deg, color-mix(in srgb, var(--accent) 12%, var(--surface)), var(--surface))',
        border: '1px solid color-mix(in srgb, var(--accent) 30%, transparent)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 5 }}>
          <VenetianMask size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />
          <span style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--text)', lineHeight: 1.3 }}>
            {content}
          </span>
        </div>

        <p style={{ margin: '0 0 12px', fontSize: 11.5, color: 'var(--text-muted)', lineHeight: 1.45 }}>
          You'll both need to play a game every day to level up. One duo at a time.
        </p>

        {error && (
          <p style={{ margin: '0 0 8px', fontSize: 11, color: '#ff6b6b' }}>{error}</p>
        )}

        {settled ? (
          <p style={{
            margin: 0, fontSize: 12, fontWeight: 800, textAlign: 'center',
            color: status === 'accepted' ? 'var(--green, #3ecf8e)' : 'var(--text-muted)',
          }}>
            {settled}
          </p>
        ) : isMine ? (
          <p style={{ margin: 0, fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textAlign: 'center' }}>
            Waiting for a reply…
          </p>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" disabled={busy || !requestId} onClick={() => respond(true)}
              style={{
                flex: 1, padding: '8px 14px', borderRadius: 11, fontSize: 12, fontWeight: 800,
                fontFamily: 'inherit', cursor: busy ? 'default' : 'pointer',
                background: 'rgba(62,207,142,0.14)', border: '1px solid rgba(62,207,142,0.42)',
                color: 'var(--green, #3ecf8e)',
              }}>
              Accept
            </button>
            <button type="button" disabled={busy || !requestId} onClick={() => respond(false)}
              style={{
                flex: 1, padding: '8px 14px', borderRadius: 11, fontSize: 12, fontWeight: 800,
                fontFamily: 'inherit', cursor: busy ? 'default' : 'pointer',
                background: 'rgba(255,77,77,0.1)', border: '1px solid rgba(255,77,77,0.34)',
                color: '#ff4d4d',
              }}>
              Reject
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
