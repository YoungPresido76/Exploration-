// src/features/duo/DuoPickerSheet.tsx
//
// Followers only — that's the server rule too (duo_send_request checks
// the follow), so this list can't offer anyone the RPC would reject.
// Players who already have a duo, or already have a request open with
// you, stay visible but disabled: seeing "Taken" answers the question
// "why isn't X here?" that a filtered-out row would leave hanging.

import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { Search, X, VenetianMask } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { getDuoCandidates, sendDuoRequest, cancelDuoRequest, duoErrorText, type DuoCandidate } from './duo'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

interface DuoPickerSheetProps {
  onClose: () => void
  onSent: () => void
}

export default function DuoPickerSheet({ onClose, onSent }: DuoPickerSheetProps) {
  const [candidates, setCandidates] = useState<DuoCandidate[] | null>(null)
  const [search, setSearch] = useState('')
  const [sendingId, setSendingId] = useState<string | null>(null)
  const [sentIds, setSentIds] = useState<Set<string>>(new Set())
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    const t = setTimeout(() => {
      getDuoCandidates(search).then(rows => { if (!cancelled) setCandidates(rows) })
    }, search ? 220 : 0)
    return () => { cancelled = true; clearTimeout(t) }
  }, [search])

  async function handleWithdraw(target: DuoCandidate) {
    if (!target.pending_request_id) return
    setSendingId(target.id)
    setError(null)
    const { error: err } = await cancelDuoRequest(target.pending_request_id)
    setSendingId(null)
    if (err) { setError(duoErrorText(err)); return }
    setSentIds(prev => { const next = new Set(prev); next.delete(target.id); return next })
    setCandidates(null)
    getDuoCandidates(search).then(setCandidates)
    onSent()
  }

  async function handleSend(target: DuoCandidate) {
    setSendingId(target.id)
    setError(null)
    const { error: err } = await sendDuoRequest(target.id)
    setSendingId(null)
    if (err) { setError(duoErrorText(err)); return }
    setSentIds(prev => new Set(prev).add(target.id))
    onSent()
  }

  // Drag-to-dismiss from anywhere inside the sheet — engages only when the
  // content under the finger is already scrolled to the top, so the body
  // still scrolls normally. See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(onClose)

  return createPortal(
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20100,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          width: 'min(100%, 460px)', maxHeight: '72vh',
          background: 'var(--bg)', borderRadius: '20px 20px 0 0',
          border: '1px solid var(--border)', borderBottom: 'none',
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
          transform: `translateY(${dragY}px)`,
          transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.32,0.72,0,1)',
        }}
      >
        <div style={{ padding: '10px 0 6px', display: 'flex', justifyContent: 'center' }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '2px 16px 10px' }}>
          <VenetianMask size={16} style={{ color: 'var(--accent)' }} />
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', margin: 0 }}>Pick your duo</p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0 }}>From people who follow you</p>
          </div>
          <button type="button" onClick={onClose}
            style={{ width: 28, height: 28, borderRadius: 9, background: 'var(--surface2)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
            <X size={14} />
          </button>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '0 16px 10px', padding: '8px 12px', borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
          <Search size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
          <input
            type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search your followers…"
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: 'var(--text)', fontFamily: 'inherit' }}
          />
        </div>

        {error && (
          <div style={{ margin: '0 16px 10px', padding: '8px 12px', borderRadius: 10, background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.25)', fontSize: 12, color: '#ff6b6b' }}>
            {error}
          </div>
        )}

        <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 20px', display: 'flex', flexDirection: 'column', gap: 7 }}>
          {candidates === null ? (
            [0, 1, 2].map(i => (
              <div key={i} style={{ height: 56, borderRadius: 13, background: 'var(--surface)' }} />
            ))
          ) : candidates.length === 0 ? (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '24px 20px', lineHeight: 1.5 }}>
              {search
                ? 'No followers match that.'
                : 'Nobody follows you yet. Once they do, you can pick a duo here.'}
            </p>
          ) : (
            candidates.map(c => {
              const outgoing = c.pending_direction === 'outgoing' || sentIds.has(c.id)
              const incoming = c.pending_direction === 'incoming'
              const disabled = c.already_paired || incoming || sendingId === c.id
              return (
                <div key={c.id}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 10, padding: '9px 11px',
                    borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--border)',
                    opacity: c.already_paired ? 0.5 : 1,
                  }}>
                  <Avatar name={c.display_name || c.username} src={c.avatar} size={36} radius={10} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {c.display_name || c.username}
                    </span>
                    <span style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)' }}>
                      {c.already_paired ? 'Already in a duo'
                        : incoming ? 'They asked you — answer in DMs'
                        : outgoing ? 'Waiting for their answer'
                        : `@${c.username}`}
                    </span>
                  </div>
                  <button
                    type="button" disabled={disabled}
                    onClick={() => (outgoing ? handleWithdraw(c) : handleSend(c))}
                    style={{
                      flexShrink: 0, padding: '7px 14px', borderRadius: 11,
                      border: outgoing ? '1px solid rgba(255,77,77,0.34)' : 'none',
                      fontSize: 12, fontWeight: 800, fontFamily: 'inherit',
                      cursor: disabled ? 'default' : 'pointer',
                      background: disabled ? 'var(--surface3)'
                        : outgoing ? 'rgba(255,77,77,0.1)'
                        : 'linear-gradient(135deg, var(--accent), var(--accent2))',
                      color: disabled ? 'var(--text-muted)' : outgoing ? '#ff4d4d' : '#fff',
                    }}>
                    {c.already_paired ? 'Taken'
                      : incoming ? 'In DMs'
                      : sendingId === c.id ? '…'
                      : outgoing ? 'Withdraw'
                      : 'Send'}
                  </button>
                </div>
              )
            })
          )}
        </div>
      </div>
    </div>,
    document.body,
  )
}
