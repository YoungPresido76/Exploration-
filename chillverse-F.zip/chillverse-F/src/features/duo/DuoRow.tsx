// src/features/duo/DuoRow.tsx
//
// One row, two homes: the profile preview sheet (under Member Since) and
// the top of the chat list. Same component so a duo always looks like
// itself — the level colour is the recognisable thing, and it would stop
// being recognisable if each surface styled it separately.

import Avatar from '../../shared/components/Avatar'
import { duoColor } from './duoLevels'

interface DuoRowProps {
  name: string
  username?: string | null
  avatarUrl?: string | null
  /** The partner's user id — decoration only, so the Plunder crown can
   *  render on their avatar. Does not make the avatar tappable. */
  userId?: string | null
  level: number
  /** Replaces @username as the secondary line — the chat list puts the
   *  last message here instead. */
  subtitle?: string | null
  onClick?: () => void
  /** Right-hand slot for the chat list's unread pill. */
  trailing?: React.ReactNode
  compact?: boolean
}

export default function DuoRow({
  name, username, avatarUrl, userId, level, subtitle, onClick, trailing, compact,
}: DuoRowProps) {
  const color = duoColor(level)
  const size = compact ? 38 : 44

  return (
    <div
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={e => { if (onClick && e.key === 'Enter') onClick() }}
      style={{
        position: 'relative', overflow: 'hidden',
        display: 'flex', alignItems: 'center', gap: 11,
        padding: compact ? '10px 11px' : '11px 13px',
        borderRadius: 15,
        background: `linear-gradient(100deg, color-mix(in srgb, ${color} 11%, var(--surface)), var(--surface))`,
        border: `1px solid color-mix(in srgb, ${color} 32%, transparent)`,
        cursor: onClick ? 'pointer' : 'default',
      }}
    >
      {/* Corner bloom — the only decoration, and it's what makes the row
          read as "special" at a glance in a list of plain DM rows. */}
      <div
        aria-hidden
        style={{
          position: 'absolute', right: -30, top: -40, width: 110, height: 110,
          background: `radial-gradient(circle, color-mix(in srgb, ${color} 20%, transparent), transparent 70%)`,
          pointerEvents: 'none',
        }}
      />

      <div style={{ flexShrink: 0, borderRadius: 12, padding: 2, border: `2px solid color-mix(in srgb, ${color} 62%, transparent)`, display: 'flex' }}>
        <Avatar name={name} src={avatarUrl ?? null} size={size - 6} radius={9} ownerId={userId} />
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <span style={{ display: 'block', fontSize: 13.5, fontWeight: 800, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {name}
        </span>
        <span style={{ display: 'block', fontSize: 11.5, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {subtitle ?? (username ? `@${username}` : '')}
        </span>
      </div>

      <div
        title={`Duo level ${level}`}
        style={{
          flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
          padding: '5px 11px', borderRadius: 11,
          background: `color-mix(in srgb, ${color} 16%, transparent)`,
          border: `1px solid color-mix(in srgb, ${color} 40%, transparent)`,
        }}
      >
        <span style={{ fontSize: 15, fontWeight: 900, color, lineHeight: 1, fontFamily: 'ui-monospace, monospace' }}>{level}</span>
        <span style={{ fontSize: 8, fontWeight: 800, letterSpacing: 0.7, color, opacity: 0.75 }}>LVL</span>
      </div>

      {trailing}
    </div>
  )
}
