// src/features/duo/duoLevels.ts
//
// The colour ladder. Levels are not bucketed into six flat bands — the
// colour is INTERPOLATED between the anchors below, so level 12 is a
// yellow-green and level 27 is an orange-red. A pair can see their duo
// shifting hue week to week, which is the whole point of putting a
// colour on it rather than a number.
//
// Anchors are the spec's own breakpoints:
//   0 black-grey · 1 grey-white · 10 yellow · 15 green
//   25 orange · 30 red · 40 purple (max)

export const DUO_MAX_LEVEL = 40

const ANCHORS: Array<[level: number, hex: string]> = [
  [0,  '#3a3a42'],
  [1,  '#d8d8e0'],
  [10, '#f5c542'],
  [15, '#3ecf8e'],
  [25, '#ff6b00'],
  [30, '#ff4d4d'],
  [40, '#a855f7'],
]

function hexToRgb(hex: string): [number, number, number] {
  return [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)) as [number, number, number]
}

function rgbToHex(rgb: number[]): string {
  return '#' + rgb.map(v => Math.round(v).toString(16).padStart(2, '0')).join('')
}

/** The duo's colour at a given level. Clamped at both ends. */
export function duoColor(level: number): string {
  const lvl = Math.max(0, Math.min(DUO_MAX_LEVEL, Math.round(level)))
  if (lvl <= 0) return ANCHORS[0][1]

  for (let i = 0; i < ANCHORS.length - 1; i++) {
    const [a, colorA] = ANCHORS[i]
    const [b, colorB] = ANCHORS[i + 1]
    if (lvl >= a && lvl <= b) {
      const t = (lvl - a) / (b - a)
      const from = hexToRgb(colorA)
      const to = hexToRgb(colorB)
      return rgbToHex(from.map((v, k) => v + (to[k] - v) * t))
    }
  }
  return ANCHORS[ANCHORS.length - 1][1]
}

/**
 * Bonus percentage at a level — must stay in step with duo_bonus_pct()
 * in migration 0128. The server is authoritative for anything that
 * actually awards XP; this is for labels only.
 */
export function duoBonusPct(level: number): number {
  if (level <= 0) return 0
  return Math.round((5 + level * 0.5) * 10) / 10
}

/** Human label for a level, used in tooltips and the end-duo warning. */
export function duoLevelLabel(level: number): string {
  if (level <= 0) return 'Not started'
  if (level >= DUO_MAX_LEVEL) return 'Max level'
  return `Level ${level}`
}

/** Mixes the duo colour into a surface at the given strength. */
export function duoTint(level: number, pct: number): string {
  return `color-mix(in srgb, ${duoColor(level)} ${pct}%, transparent)`
}
