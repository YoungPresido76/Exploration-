// src/features/duo/duoBus.ts
//
// saveGameSession() records the duo play (it's the only place that knows
// a run was actually banked), but the ResultScreen is what has to show
// the DUO XP line. They have no component relationship, so the result
// hops across on this bus — same reasoning as levelUpBus.ts.
//
// Deliberately holds only the LATEST result, keyed by a monotonic id:
// the win modal wants "what did the run I just finished earn", never a
// backlog. A stale result from a previous game is dropped by the key.

import type { DuoPlayResult } from './duo'

export interface DuoPlaySnapshot {
  /** Bumped on every publish so subscribers can tell results apart. */
  key: number
  result: DuoPlayResult | null
  /** True between the game ending and the RPC answering. */
  pending: boolean
}

let snapshot: DuoPlaySnapshot = { key: 0, result: null, pending: false }
const listeners = new Set<() => void>()

function commit(next: DuoPlaySnapshot) {
  snapshot = next
  for (const listener of listeners) listener()
}

export function subscribeDuoPlay(listener: () => void): () => void {
  listeners.add(listener)
  return () => { listeners.delete(listener) }
}

export function getDuoPlaySnapshot(): DuoPlaySnapshot {
  return snapshot
}

/** Called the moment a run is banked, before the RPC resolves. */
export function markDuoPlayPending(): void {
  commit({ key: snapshot.key + 1, result: null, pending: true })
}

/** Called with whatever duo_record_play returned (null on failure). */
export function publishDuoPlay(result: DuoPlayResult | null): void {
  commit({ key: snapshot.key + 1, result, pending: false })
}

/** Clears the slot when the player leaves the result screen. */
export function clearDuoPlay(): void {
  if (!snapshot.result && !snapshot.pending) return
  commit({ key: snapshot.key + 1, result: null, pending: false })
}
