// src/features/duo/useDuo.ts

import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { getDuoState, type DuoState } from './duo'

/**
 * Loads a profile's duo panel and keeps it live.
 *
 * Realtime matters more here than in most places: the level changes when
 * the OTHER person finishes a game, which can happen while this sheet is
 * open. Without the subscription the row would sit on a stale level until
 * the next navigation.
 *
 * @param userId  whose duo to show — null/undefined means "mine"
 * @param enabled skip all work when the surface isn't visible
 */
export function useDuo(userId?: string | null, enabled = true) {
  const [state, setState] = useState<DuoState | null>(null)
  const [loading, setLoading] = useState(enabled)
  const cancelled = useRef(false)

  const reload = useCallback(async () => {
    const next = await getDuoState(userId)
    if (!cancelled.current) {
      setState(next)
      setLoading(false)
    }
  }, [userId])

  useEffect(() => {
    cancelled.current = false
    if (!enabled) {
      setLoading(false)
      return () => { cancelled.current = true }
    }

    setLoading(true)
    reload()

    // Any change to a pair or a request could affect this panel; the
    // filter would have to cover four columns across two tables, so we
    // just refetch on anything and let duo_get_state decide. These
    // tables see a handful of writes a day per user.
    const channel = supabase
      .channel(`duo-${userId ?? 'me'}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'duo_pairs' }, reload)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'duo_requests' }, reload)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'duo_day_plays' }, reload)
      .subscribe()

    return () => {
      cancelled.current = true
      supabase.removeChannel(channel)
    }
  }, [userId, enabled, reload])

  return { state, loading, reload }
}
