// src/features/duo/duo.ts
//
// Every duo mutation is an RPC (see migration 0128) — there are no direct
// table writes, because the level and the XP grants have to be decided
// server-side or a determined player can just award themselves level 40.

import { supabase } from '../../shared/lib/supabase'

export interface DuoProfileCard {
  id: string
  username: string
  display_name: string | null
  avatar: string | null
  presence: string | null
}

export interface DuoIncomingRequest {
  id: string
  sender: DuoProfileCard
  created_at: string
  expires_at: string
}

export interface DuoOutgoingRequest {
  id: string
  recipient: DuoProfileCard
  created_at: string
  expires_at: string
}

/** Shape returned by duo_get_state(). Discriminated on `active`. */
export type DuoState =
  | {
      active: true
      is_me: boolean
      pair_id: string
      partner: DuoProfileCard
      level: number
      bonus_pct: number
      since: string
      today: string
      i_played_today: boolean
      partner_played_today: boolean
      day_complete: boolean
      missed_run: number
      freeze_available: boolean
      nudge_used_today: boolean
      resets_at: string
    }
  | {
      active: false
      is_me: boolean
      cooldown_until?: string | null
      incoming?: DuoIncomingRequest[]
      outgoing?: DuoOutgoingRequest[]
    }

export interface DuoCandidate {
  id: string
  username: string
  display_name: string | null
  avatar: string | null
  already_paired: boolean
  request_pending: boolean
  /** Which way a pending request runs — decides whether the row offers
   *  Withdraw (you asked them) or points at the DMs (they asked you). */
  pending_direction: 'outgoing' | 'incoming' | null
  pending_request_id: string | null
}

export interface DuoPlayResult {
  active: boolean
  pair_id?: string
  partner?: DuoProfileCard
  level?: number
  bonus_pct?: number
  duo_xp?: number
  levelled_up?: boolean
  partner_played_today?: boolean
  capped?: boolean
  plays_today?: number
  daily_play_cap?: number
}

/** Server error codes → something a player can act on. */
const ERROR_TEXT: Record<string, string> = {
  duo_self: "You can't duo with yourself.",
  duo_not_a_follower: 'You can only pick a duo from people who follow you.',
  duo_blocked: 'That player is blocked.',
  duo_already_paired: 'You already have a duo. End it first.',
  duo_target_paired: 'They already have a duo.',
  duo_cooldown: 'You need to wait 72 hours after ending a duo.',
  duo_request_exists: "There's already a request open between you two.",
  duo_request_missing: 'That request no longer exists.',
  duo_request_closed: 'That request was already answered.',
  duo_request_expired: 'That request expired.',
  duo_none: "You don't have a duo.",
  duo_nudge_used: "You've already nudged today.",
  duo_nudge_play_first: 'Play a game first, then you can nudge.',
  duo_nudge_unneeded: 'They already played today.',
  not_authorized: "That isn't your request.",
  not_authenticated: 'Sign in first.',
}

export function duoErrorText(error: { message?: string } | null | undefined): string {
  const raw = error?.message ?? ''
  for (const code of Object.keys(ERROR_TEXT)) {
    if (raw.includes(code)) return ERROR_TEXT[code]
  }
  return 'Something went wrong. Try again.'
}

/** Duo panel for a profile. Pass null/undefined for your own. */
export async function getDuoState(userId?: string | null): Promise<DuoState | null> {
  const { data, error } = await supabase.rpc('duo_get_state', { p_user_id: userId ?? null })
  if (error) {
    console.error('duo_get_state error:', error)
    return null
  }
  return data as DuoState
}

/** Your followers, annotated with whether they're actually pickable. */
export async function getDuoCandidates(search?: string): Promise<DuoCandidate[]> {
  const { data, error } = await supabase.rpc('duo_candidates', { p_search: search ?? null })
  if (error) {
    console.error('duo_candidates error:', error)
    return []
  }
  return (data as DuoCandidate[]) ?? []
}

export async function sendDuoRequest(targetId: string) {
  const { data, error } = await supabase.rpc('duo_send_request', { p_target: targetId })
  return { data, error }
}

export async function respondToDuoRequest(requestId: string, accept: boolean) {
  const { data, error } = await supabase.rpc('duo_respond_request', {
    p_request_id: requestId,
    p_accept: accept,
  })
  return { data, error }
}

export async function cancelDuoRequest(requestId: string) {
  const { data, error } = await supabase.rpc('duo_cancel_request', { p_request_id: requestId })
  return { data, error }
}

/** Ends the duo. 72h cooldown lands on BOTH sides — see migration 0128. */
export async function endDuo() {
  const { data, error } = await supabase.rpc('duo_end')
  return { data, error }
}

/** One "your duo is waiting" ping per day, and only if you've played. */
export async function nudgeDuo() {
  const { data, error } = await supabase.rpc('duo_nudge')
  return { data, error }
}

/**
 * Banks a finished game against the duo. Returns the bonus XP minted for
 * BOTH partners plus whether this play completed the day and levelled
 * them up. Called from saveGameSession, never from a component.
 */
export async function recordDuoPlay(xpEarned: number): Promise<DuoPlayResult | null> {
  const { data, error } = await supabase.rpc('duo_record_play', { p_xp: xpEarned })
  if (error) {
    console.error('duo_record_play error:', error)
    return null
  }
  return data as DuoPlayResult
}

/** Pending requests waiting on you — used to badge the chat list. */
export async function getIncomingDuoRequests(): Promise<DuoIncomingRequest[]> {
  const state = await getDuoState()
  if (!state || state.active) return []
  return state.incoming ?? []
}

/** "72h" → "2d 4h" for the cooldown notice. */
export function formatCooldown(until: string): string {
  const ms = new Date(until).getTime() - Date.now()
  if (ms <= 0) return 'now'
  const hours = Math.floor(ms / 3_600_000)
  const days = Math.floor(hours / 24)
  if (days > 0) return `${days}d ${hours % 24}h`
  const mins = Math.floor((ms % 3_600_000) / 60_000)
  return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`
}

/** Countdown to the Lagos-midnight day boundary, e.g. "6h 12m left". */
export function formatResetIn(resetsAt: string): string {
  const ms = new Date(resetsAt).getTime() - Date.now()
  if (ms <= 0) return 'resetting…'
  const hours = Math.floor(ms / 3_600_000)
  const mins = Math.floor((ms % 3_600_000) / 60_000)
  return hours > 0 ? `${hours}h ${mins}m left` : `${mins}m left`
}
