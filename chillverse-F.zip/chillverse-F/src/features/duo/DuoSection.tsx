// src/features/duo/DuoSection.tsx
//
// The Dynamic Duo block inside ProfilePreviewModal, sitting directly
// under Member Since.
//
// Three shapes:
//   • You have a duo      → the row, the day's progress, nudge/end.
//   • Your own empty slot → a + that opens the follower picker.
//   • Someone else's slot → the row only, or nothing. No controls, and
//     no + button: you can't start a duo from another person's sheet.

import { useEffect, useState } from 'react'
import { Plus, VenetianMask, Snowflake, Bell, Check } from 'lucide-react'
import DuoRow from './DuoRow'
import DuoPickerSheet from './DuoPickerSheet'
import { useDuo } from './useDuo'
import { duoColor } from './duoLevels'
import { endDuo, nudgeDuo, cancelDuoRequest, duoErrorText, formatCooldown, formatResetIn } from './duo'

interface DuoSectionProps {
  userId: string
  isMe: boolean
  /** Opens the partner's own profile sheet. */
  onOpenProfile?: (userId: string) => void
}

const LABEL: React.CSSProperties = {
  fontSize: 10, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase',
  color: 'var(--text-muted)', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 5,
}

export default function DuoSection({ userId, isMe, onOpenProfile }: DuoSectionProps) {
  const { state, loading, reload } = useDuo(userId)
  const [pickerOpen, setPickerOpen] = useState(false)
  const [confirmEnd, setConfirmEnd] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [nudged, setNudged] = useState(false)
  const [, forceTick] = useState(0)

  // Re-render each minute so the "6h 12m left" countdown stays honest
  // while the sheet sits open.
  useEffect(() => {
    const t = setInterval(() => forceTick(n => n + 1), 60_000)
    return () => clearInterval(t)
  }, [])

  if (loading) {
    return (
      <div className="pv-section">
        <p style={LABEL}><VenetianMask size={11} /> Dynamic Duo</p>
        <div className="pv-skel" style={{ height: 62, borderRadius: 15 }} />
      </div>
    )
  }

  if (!state) return null

  // ── Nobody's duo to show ────────────────────────────────────
  if (!state.active) {
    // Someone else's profile with no duo: say so plainly rather than
    // rendering an empty slot that looks like a broken control.
    if (!isMe) {
      return (
        <div className="pv-section">
          <p style={LABEL}><VenetianMask size={11} /> Dynamic Duo</p>
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>None</p>
        </div>
      )
    }

    const cooling = state.cooldown_until && new Date(state.cooldown_until) > new Date()

    return (
      <div className="pv-section">
        <p style={LABEL}><VenetianMask size={11} /> Dynamic Duo</p>

        <div style={{
          display: 'flex', alignItems: 'center', gap: 11, padding: 11,
          borderRadius: 15, background: 'var(--surface)', border: '1px dashed var(--border-strong)',
        }}>
          <button
            type="button"
            aria-label="Choose a duo"
            disabled={!!cooling}
            onClick={() => setPickerOpen(true)}
            style={{
              width: 38, height: 38, borderRadius: 11, flexShrink: 0, border: 'none',
              cursor: cooling ? 'default' : 'pointer',
              background: 'var(--surface3)', color: cooling ? 'var(--text-muted)' : 'var(--accent)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
            <Plus size={17} />
          </button>
          <p style={{ margin: 0, fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.4 }}>
            <b style={{ display: 'block', fontSize: 12.5, color: 'var(--text-dim)', fontWeight: 700 }}>
              {cooling ? 'Cooling down' : 'Pick your duo'}
            </b>
            {cooling
              ? `You can pair again in ${formatCooldown(state.cooldown_until!)}.`
              : 'Play a game the same day to keep the streak and split bonus XP.'}
          </p>
        </div>

        {(state.incoming?.length ?? 0) > 0 && (
          <p style={{ fontSize: 11, color: 'var(--accent)', marginTop: 7, fontWeight: 700 }}>
            {state.incoming!.length === 1
              ? '1 duo request waiting in your DMs'
              : `${state.incoming!.length} duo requests waiting in your DMs`}
          </p>
        )}

        {/* Outgoing request — without this, a sent request silently locked
            the slot with no way to take it back. */}
        {(state.outgoing?.length ?? 0) > 0 && state.outgoing!.map(req => (
          <div key={req.id} style={{
            display: 'flex', alignItems: 'center', gap: 8, marginTop: 7,
            padding: '8px 11px', borderRadius: 12,
            background: 'var(--surface)', border: '1px solid var(--border)',
          }}>
            <p style={{ flex: 1, margin: 0, fontSize: 11.5, color: 'var(--text-muted)' }}>
              Waiting on{' '}
              <b style={{ color: 'var(--text-dim)' }}>
                {req.recipient.display_name || req.recipient.username}
              </b>
            </p>
            <button
              type="button" disabled={busy}
              onClick={async () => {
                setBusy(true); setError(null)
                const { error: err } = await cancelDuoRequest(req.id)
                setBusy(false)
                if (err) { setError(duoErrorText(err)); return }
                reload()
              }}
              style={{
                flexShrink: 0, padding: '6px 12px', borderRadius: 10,
                fontSize: 11.5, fontWeight: 800, fontFamily: 'inherit', cursor: 'pointer',
                background: 'rgba(255,77,77,0.1)', border: '1px solid rgba(255,77,77,0.3)',
                color: '#ff4d4d',
              }}>
              Withdraw
            </button>
          </div>
        ))}

        {error && <p style={{ fontSize: 11, color: '#ff6b6b', marginTop: 6 }}>{error}</p>}

        {pickerOpen && (
          <DuoPickerSheet onClose={() => setPickerOpen(false)} onSent={reload} />
        )}
      </div>
    )
  }

  // ── Active duo ──────────────────────────────────────────────
  const color = duoColor(state.level)
  const partnerName = state.partner.display_name || state.partner.username
  const bothDone = state.day_complete
  const halfDone = state.i_played_today !== state.partner_played_today

  async function handleEnd() {
    setBusy(true); setError(null)
    const { error: err } = await endDuo()
    setBusy(false)
    if (err) { setError(duoErrorText(err)); return }
    setConfirmEnd(false)
    reload()
  }

  async function handleNudge() {
    setBusy(true); setError(null)
    const { error: err } = await nudgeDuo()
    setBusy(false)
    if (err) { setError(duoErrorText(err)); return }
    setNudged(true)
  }

  return (
    <div className="pv-section">
      <p style={LABEL}><VenetianMask size={11} /> Dynamic Duo</p>

      <DuoRow
        name={partnerName}
        username={state.partner.username}
        avatarUrl={state.partner.avatar}
        userId={state.partner.id}
        level={state.level}
        onClick={onOpenProfile ? () => onOpenProfile(state.partner.id) : undefined}
      />

      {/* Progress, countdown, and freeze status are only meaningful to
          the two people in the duo — someone browsing a third party's
          profile just needs the name, avatar, and level. */}
      {isMe && (
        <>
          {/* Today's state. Two ticks means the level already went up; one
              means somebody still has to play, and that's the moment the
              nudge is worth offering. */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
            <div style={{ flex: 1, height: 5, borderRadius: 3, background: 'var(--surface3)', overflow: 'hidden' }}>
              <div style={{
                height: '100%', borderRadius: 3,
                width: bothDone ? '100%' : halfDone ? '50%' : '0%',
                background: `linear-gradient(90deg, color-mix(in srgb, ${color} 55%, transparent), ${color})`,
                transition: 'width 0.4s ease',
              }} />
            </div>
            <small style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
              {bothDone
                ? `Level ${state.level} locked in`
                : formatResetIn(state.resets_at)}
            </small>
          </div>

          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6, lineHeight: 1.45 }}>
            {bothDone
              ? `You both played today. Duo bonus is ${state.bonus_pct}% on every game.`
              : state.i_played_today
                ? `You've played. ${partnerName} hasn't yet — if neither of you completes the day, you both lose a level.`
                : state.partner_played_today
                  ? `${partnerName} played today. Play one game to level up.`
                  : 'Neither of you has played today.'}
          </p>

          {state.freeze_available && !bothDone && (
            <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
              <Snowflake size={10} /> Weekly freeze ready — it covers the first missed day automatically.
            </p>
          )}

          {error && (
            <p style={{ fontSize: 11, color: '#ff6b6b', marginTop: 6 }}>{error}</p>
          )}
        </>
      )}

      {isMe && (
        <div style={{ display: 'flex', gap: 7, marginTop: 10 }}>
          {state.i_played_today && !state.partner_played_today && (
            <button
              type="button" disabled={busy || nudged || state.nudge_used_today}
              onClick={handleNudge}
              style={{
                flex: 1, padding: '8px 12px', borderRadius: 11, fontSize: 12, fontWeight: 800,
                fontFamily: 'inherit', cursor: nudged || state.nudge_used_today ? 'default' : 'pointer',
                background: `color-mix(in srgb, ${color} 13%, transparent)`,
                border: `1px solid color-mix(in srgb, ${color} 36%, transparent)`,
                color, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}>
              {nudged || state.nudge_used_today ? <Check size={13} /> : <Bell size={13} />}
              {nudged || state.nudge_used_today ? 'Nudged today' : 'Nudge them'}
            </button>
          )}

          {confirmEnd ? (
            <>
              <button type="button" disabled={busy} onClick={handleEnd}
                style={{
                  flex: 1, padding: '8px 12px', borderRadius: 11, fontSize: 12, fontWeight: 800,
                  fontFamily: 'inherit', cursor: 'pointer', color: '#ff6b6b',
                  background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.3)',
                }}>
                {busy ? 'Ending…' : `End duo — lose level ${state.level}`}
              </button>
              <button type="button" onClick={() => setConfirmEnd(false)}
                style={{
                  padding: '8px 12px', borderRadius: 11, fontSize: 12, fontWeight: 800,
                  fontFamily: 'inherit', cursor: 'pointer', color: 'var(--text-dim)',
                  background: 'var(--surface2)', border: '1px solid var(--border)',
                }}>
                Keep
              </button>
            </>
          ) : (
            <button type="button" onClick={() => setConfirmEnd(true)}
              style={{
                flex: state.i_played_today && !state.partner_played_today ? 0 : 1,
                padding: '8px 14px', borderRadius: 11, fontSize: 12, fontWeight: 700,
                fontFamily: 'inherit', cursor: 'pointer', color: 'var(--text-muted)',
                background: 'var(--surface2)', border: '1px solid var(--border)', whiteSpace: 'nowrap',
              }}>
              End duo
            </button>
          )}
        </div>
      )}

      {isMe && confirmEnd && (
        <p style={{ fontSize: 10.5, color: 'var(--text-muted)', marginTop: 6, lineHeight: 1.4 }}>
          The level is gone for good, and you both wait 72 hours before pairing with anyone else.
        </p>
      )}
    </div>
  )
}
