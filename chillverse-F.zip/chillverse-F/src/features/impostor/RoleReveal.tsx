// src/features/impostor/RoleReveal.tsx
//
// The slot machine. Flips between POLICE and THIEF for most of the reveal
// window, then lands on the real answer with about a second to spare so the
// word is readable before the hide phase takes over.
//
// The flip is driven by an interval keyed on the phase, not a chain of
// setTimeouts held in a ref — StrictMode's mount/unmount/remount in dev wipes
// a pending ref chain and freezes the animation half way, which is the bug
// that bit ColourBlock and Pattern King.
import { useEffect, useState } from 'react'
import { useCountdown } from './useCountdown'
import type { ImpostorMe, ImpostorState } from './impostor'

const FLIP_MS = 110
/** Stop rolling this long before the phase ends. */
const LAND_BEFORE_MS = 1400

export default function RoleReveal({
  state, me, skewMs,
}: { state: ImpostorState; me: ImpostorMe; skewMs: number }) {
  const { ms } = useCountdown(state.ends_at, skewMs)
  const landed = ms <= LAND_BEFORE_MS
  const [flip, setFlip] = useState(true)

  useEffect(() => {
    if (landed) return
    const t = setInterval(() => setFlip(f => !f), FLIP_MS)
    return () => clearInterval(t)
  }, [landed])

  const isPolice = me.role === 'police'
  const shown = landed ? (isPolice ? 'POLICE' : 'THIEF') : (flip ? 'POLICE' : 'THIEF')
  const colour = landed
    ? (isPolice ? '#4fd1ff' : '#ff8a3d')
    : (flip ? '#4fd1ff' : '#ff8a3d')

  // A spectator (joined mid-match, or left and came back) gets an honest
  // screen rather than a role they don't hold.
  if (me.role === 'none') {
    return (
      <div className="imp-reveal">
        <div className="imp-slot landed" style={{ color: '#7d879e', fontSize: 40 }}>WATCHING</div>
        <div className="imp-reveal-sub">You're not in this round. Sit tight — roles rotate next round.</div>
      </div>
    )
  }

  return (
    <div className="imp-reveal">
      <div className="imp-hud-chip" style={{ justifyContent: 'center' }}>
        Round {state.round} of {state.rounds}
      </div>
      <div
        className={`imp-slot ${landed ? 'landed' : 'rolling'}`}
        style={{ color: colour }}
        key={landed ? 'landed' : 'rolling'}
      >
        {shown}
      </div>
      {landed && (
        <div className="imp-reveal-sub">
          {isPolice
            ? 'Take the torch. Hold it on a mask until something breathes.'
            : 'Pick a mask. When the light finds you, hold your breath.'}
        </div>
      )}
    </div>
  )
}
