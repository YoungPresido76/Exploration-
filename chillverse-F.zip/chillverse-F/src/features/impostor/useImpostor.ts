// src/features/impostor/useImpostor.ts
//
// Owns one match: joins it, keeps its state fresh, and exposes the three
// actions a player can take.
//
// There is no cron and no server process behind Impostor. impostor_state
// runs impostor_tick first, and tick is what notices a deadline has passed
// and moves the round on. In other words THE POLLING IS THE CLOCK — if every
// client stopped calling, a live round would simply hang at whatever phase it
// was in. That is why the interval keeps running while the tab is hidden and
// only the render loop stops.
//
// Realtime on `rooms` is the fast path on top: a phase flip caused by another
// player's tap lands in ~100ms instead of waiting out the poll. Same posture
// as useRoom.ts — postgres_changes has no replay, so the poll is what
// actually guarantees the gap closes.
import { useCallback, useEffect, useRef, useState } from 'react'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from '../../shared/lib/supabase'
import {
  fetchImpostor, matchmake, pickCard, tapCard, leaveImpostor,
  type ImpostorSnapshot, type PickOutcome,
} from './impostor'

const POLL_MS = 1000

export interface UseImpostor {
  roomId: string | null
  snap: ImpostorSnapshot | null
  loading: boolean
  error: string | null
  /** server clock minus device clock, so every countdown agrees across
   *  phones with badly set time. */
  skewMs: number
  refresh: () => void
  pick: (idx: number) => Promise<PickOutcome | null>
  tap: (idx: number) => Promise<boolean | null>
  quit: () => Promise<void>
}

export function useImpostor(active: boolean): UseImpostor {
  const [roomId, setRoomId] = useState<string | null>(null)
  const [snap, setSnap] = useState<ImpostorSnapshot | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [skewMs, setSkewMs] = useState(0)

  const roomRef = useRef<string | null>(null)
  const busyRef = useRef(false)
  const deadRef = useRef(false)

  // ── Join ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!active) return
    deadRef.current = false
    let cancelled = false
    setLoading(true)
    matchmake()
      .then(id => {
        if (cancelled) return
        roomRef.current = id
        setRoomId(id)
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Could not find a match')
      })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [active])

  // ── The clock ───────────────────────────────────────────────────────
  const refresh = useCallback(() => {
    const id = roomRef.current
    if (!id || deadRef.current) return
    // One in flight at a time. A slow network must not queue up ticks that
    // all land at once and stampede the state machine.
    if (busyRef.current) return
    busyRef.current = true
    const sentAt = Date.now()
    fetchImpostor(id)
      .then(next => {
        if (deadRef.current || !next) return
        // Halve the round trip out of the skew, so a slow link doesn't make
        // every countdown read a second fast.
        const rtt = (Date.now() - sentAt) / 2
        setSkewMs(new Date(next.server_now).getTime() - (Date.now() - rtt))
        setSnap(next)
      })
      .catch((e: unknown) => {
        setError(e instanceof Error ? e.message : 'Lost the match')
      })
      .finally(() => { busyRef.current = false })
  }, [])

  useEffect(() => {
    if (!roomId) return
    refresh()
    const t = setInterval(refresh, POLL_MS)
    return () => clearInterval(t)
  }, [roomId, refresh])

  // ── Fast path ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!roomId) return
    let ch: RealtimeChannel | null = supabase
      .channel(`impostor-room:${roomId}`)
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'rooms', filter: `id=eq.${roomId}` },
        () => refresh())
      .subscribe()

    function onVisible() {
      if (document.visibilityState === 'visible') refresh()
    }
    document.addEventListener('visibilitychange', onVisible)
    window.addEventListener('online', refresh)

    return () => {
      document.removeEventListener('visibilitychange', onVisible)
      window.removeEventListener('online', refresh)
      if (ch) supabase.removeChannel(ch)
      ch = null
    }
  }, [roomId, refresh])

  // ── Actions ─────────────────────────────────────────────────────────
  const pick = useCallback(async (idx: number) => {
    const id = roomRef.current
    if (!id) return null
    try {
      const got = await pickCard(id, idx)
      // A clash changed nothing on the server, so there is no point paying
      // for a refetch — the caller just re-prompts.
      if (!got.taken) refresh()
      return got
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not hide')
      return null
    }
  }, [refresh])

  const tap = useCallback(async (idx: number) => {
    const id = roomRef.current
    if (!id) return null
    try {
      const out = await tapCard(id, idx)
      // The RPC hands back the whole post-tap state, so the shot resolves on
      // screen without waiting for the next poll.
      setSnap(prev => (prev ? { ...prev, state: out.state } : prev))
      return out.last?.hit ?? null
    } catch (e) {
      setError(e instanceof Error ? e.message : 'That shot did not land')
      return null
    }
  }, [])

  const quit = useCallback(async () => {
    const id = roomRef.current
    if (!id) return
    deadRef.current = true
    await leaveImpostor(id)
  }, [])

  // Leaving the screen mid-match frees the seat, so a lobby is not held open
  // by someone who navigated away.
  useEffect(() => {
    return () => {
      const id = roomRef.current
      if (id && !deadRef.current) {
        deadRef.current = true
        void leaveImpostor(id)
      }
    }
  }, [])

  return { roomId, snap, loading, error, skewMs, refresh, pick, tap, quit }
}
