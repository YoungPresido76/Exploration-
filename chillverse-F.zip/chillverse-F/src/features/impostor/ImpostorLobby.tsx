// src/features/impostor/ImpostorLobby.tsx
//
// The matchmaking screen.
//
// The headline number is REAL PLAYERS, not seats. A match needs three of them
// before it can start; bots only top the room up above that. So the copy has
// to be honest about what is missing — "2/3" and an invite button, rather
// than a filling bar that implies the room is about to go.
import { useCallback, useState } from 'react'
import { ArrowLeft, Users, Share2, Check } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { useCountdown } from './useCountdown'
import type { ImpostorState } from './impostor'

const DEFAULT_MIN_HUMANS = 3
const INVITE_URL = 'https://chillverse.com.ng/games'

export default function ImpostorLobby({
  state, skewMs, onQuit,
}: { state: ImpostorState; skewMs: number; onQuit: () => void }) {
  const { secs } = useCountdown(state.ends_at, skewMs)
  const [shared, setShared] = useState(false)

  const seats = state.seats ?? []
  const humans = seats.filter(s => !s.bot)
  const need = state.min_humans ?? DEFAULT_MIN_HUMANS
  const short = Math.max(0, need - humans.length)

  const invite = useCallback(async () => {
    const text = "I'm in an Impostor lobby on Chillverse — we need one more to start."
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Impostor', text, url: INVITE_URL })
        return
      }
      await navigator.clipboard.writeText(`${text} ${INVITE_URL}`)
      setShared(true)
      setTimeout(() => setShared(false), 2200)
    } catch {
      // Share sheet dismissed, or clipboard refused. Nothing worth saying.
    }
  }, [])

  return (
    <div className="imp-stage" style={{ paddingBottom: 40 }}>
      <button
        onClick={onQuit}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, border: 0, background: 'transparent',
          color: '#9aa4bd', fontSize: 14, fontWeight: 700, padding: '10px 0', cursor: 'pointer',
        }}
      >
        <ArrowLeft size={18} /> Leave
      </button>

      <div style={{ textAlign: 'center', padding: '10px 0 20px' }}>
        <div className="imp-hud-chip" style={{ justifyContent: 'center', marginBottom: 8 }}>
          <Users size={13} /> Matchmaking
        </div>
        <div className="imp-clock" style={{ fontSize: 42, color: short > 0 ? '#ffb020' : '#7af0c8' }}>
          {humans.length}<span style={{ fontSize: 22, color: '#5b6479' }}>/{need}</span>
        </div>
        <div style={{ color: '#9aa4bd', fontSize: 12.5, marginTop: 6 }}>
          {short > 0
            ? `${short} more player${short === 1 ? '' : 's'} needed · ${Math.max(0, secs)}s`
            : `Starting in ${Math.max(0, secs)}s`}
        </div>
      </div>

      {short > 0 && (
        <button
          onClick={invite}
          style={{
            width: '100%', border: '1px solid rgba(255,176,32,0.35)', borderRadius: 14,
            background: 'rgba(255,176,32,0.10)', color: '#ffb020',
            padding: '14px 0', fontSize: 13.5, fontWeight: 900, letterSpacing: 0.6,
            cursor: 'pointer', marginBottom: 18,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}
        >
          {shared ? <Check size={16} /> : <Share2 size={16} />}
          {shared ? 'Link copied' : 'Invite people to join'}
        </button>
      )}

      <div className="imp-roster">
        {humans.map((s, i) => (
          <div key={s.sid} className="imp-seat" style={{ animationDelay: `${Math.min(i, 7) * 40}ms` }}>
            <Avatar src={s.avatar} name={s.name} size={36} />
            <div style={{ minWidth: 0 }}>
              <div className="imp-seat-name">{s.name}</div>
              <div className="imp-seat-sub">{s.username ? `@${s.username}` : 'Ready'}</div>
            </div>
          </div>
        ))}
        {Array.from({ length: short }).map((_, i) => (
          <div key={`empty-${i}`} className="imp-seat imp-seat-empty">
            Waiting for a player…
          </div>
        ))}
      </div>
    </div>
  )
}
