// src/features/impostor/Scene.tsx
//
// The scenery, and the ambient life in it.
//
// The theme is derived from a hash of room id + round, NOT stored on the
// server. Every client hashes the same two values and lands on the same
// scene, so a whole extra column in game_state (and the migration to add it)
// buys nothing. Three rounds therefore means three different scenes, and the
// same room always replays the same sequence.
//
// Everything here is CSS. The org is over its cached-egress quota with a hard
// Fair Use date, so a bubble is a div with a keyframe, not a sprite sheet.
import { hash32 } from './breath'

export type SceneTheme = 'alley' | 'ocean' | 'ice' | 'farm'

const THEMES: SceneTheme[] = ['alley', 'ocean', 'ice', 'farm']

export function themeFor(roomId: string, round: number): SceneTheme {
  if (!roomId || round < 1) return 'alley'
  return THEMES[hash32(`${roomId}:${round}:scene`) % THEMES.length]
}

/** Fixed counts, fixed inline delays. Randomising per mount would make the
 *  scene jump on every re-render, and these are decoration — they don't need
 *  to differ between players. */
const BUBBLES = [
  { left: 8, size: 7, dur: 7.5, delay: 0 },
  { left: 21, size: 11, dur: 9.5, delay: 2.4 },
  { left: 34, size: 5, dur: 6.2, delay: 1.1 },
  { left: 48, size: 9, dur: 8.8, delay: 4.0 },
  { left: 61, size: 6, dur: 7.0, delay: 0.7 },
  { left: 73, size: 13, dur: 10.5, delay: 3.2 },
  { left: 86, size: 8, dur: 8.0, delay: 5.1 },
  { left: 94, size: 5, dur: 6.6, delay: 1.9 },
]

const MOTES = [
  { left: 12, top: 22, dur: 13, delay: 0 },
  { left: 29, top: 58, dur: 16, delay: 3 },
  { left: 44, top: 34, dur: 11, delay: 6 },
  { left: 63, top: 70, dur: 15, delay: 1.5 },
  { left: 78, top: 28, dur: 12, delay: 4.5 },
  { left: 90, top: 55, dur: 14, delay: 7 },
]

export default function Scene({ theme }: { theme: SceneTheme }) {
  return (
    <>
      <div className="imp-fog" />
      {theme === 'ocean' && (
        <div className="imp-bubbles" aria-hidden="true">
          {BUBBLES.map((b, i) => (
            <span
              key={i}
              style={{
                left: `${b.left}%`,
                width: b.size,
                height: b.size,
                animationDuration: `${b.dur}s`,
                animationDelay: `${b.delay}s`,
              }}
            />
          ))}
        </div>
      )}
      {theme === 'ice' && (
        // Two panes on long, offset cycles so the frost creeps in now and
        // then rather than pulsing on a beat you could set a watch by.
        <>
          <div className="imp-frost imp-frost-a" aria-hidden="true" />
          <div className="imp-frost imp-frost-b" aria-hidden="true" />
        </>
      )}
      {theme === 'farm' && (
        <div className="imp-motes" aria-hidden="true">
          {MOTES.map((m, i) => (
            <span
              key={i}
              style={{
                left: `${m.left}%`,
                top: `${m.top}%`,
                animationDuration: `${m.dur}s`,
                animationDelay: `${m.delay}s`,
              }}
            />
          ))}
        </div>
      )}
    </>
  )
}
