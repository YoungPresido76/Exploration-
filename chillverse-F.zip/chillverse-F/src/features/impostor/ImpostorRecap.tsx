// src/features/impostor/ImpostorRecap.tsx
//
// Between-round verdict, and the final board.
//
// The XP shown here is read straight off state.scores, which is the same
// number the server banked — _impostor_finish inserts one game_sessions row
// per human seat and the on_game_session_insert trigger grants the XP. This
// screen never awards anything, and closing it early can't cost you a payout
// that already happened.
import { useEffect, useRef } from 'react'
import { Crosshair, Flame, RotateCcw, ArrowLeft } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { playGameOver, playPraiseSound } from '../games/sfx'
import { useCountdown } from './useCountdown'
import { seatOf, type ImpostorMe, type ImpostorState } from './impostor'

const XP_CAP = 250

export function RoundRecap({
  state, me, skewMs,
}: { state: ImpostorState; me: ImpostorMe; skewMs: number }) {
  const { secs } = useCountdown(state.ends_at, skewMs)
  const r = state.round_result
  const playedRef = useRef(false)

  const iWon = r
    ? (r.winner === 'police' ? state.police.includes(me.sid) : state.thieves.includes(me.sid))
    : false

  useEffect(() => {
    if (!r || playedRef.current) return
    playedRef.current = true
    if (iWon) playPraiseSound('Nailed it!')
    else playGameOver()
  }, [r, iWon])

  if (!r) return null

  const caughtNames = r.caught
    .map(sid => seatOf(state, sid)?.name)
    .filter(Boolean) as string[]

  return (
    <div className="imp-stage" style={{ paddingBottom: 40 }}>
      <div className="imp-hud">
        <span className="imp-hud-chip">Round {r.round} of {state.rounds}</span>
        <span className="imp-clock">{Math.max(0, secs)}</span>
      </div>

      <div className="imp-verdict" style={{ color: r.winner === 'police' ? '#4fd1ff' : '#ff8a3d' }}>
        {r.winner === 'police' ? (r.sweep ? 'CLEAN SWEEP' : 'POLICE WIN') : 'THIEVES GET AWAY'}
      </div>

      <div style={{ textAlign: 'center', color: '#9aa4bd', fontSize: 13, margin: '10px 0 22px', lineHeight: 1.6 }}>
        {caughtNames.length === 0
          ? 'Nobody got caught.'
          : `Caught: ${caughtNames.join(', ')}`}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
        {state.seats.map(s => {
          const wasPolice = state.police.includes(s.sid)
          const wasCaught = r.caught.includes(s.sid)
          return (
            <div key={s.sid} className={`imp-score-row ${s.sid === me.sid ? 'me' : ''}`}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                <Avatar src={s.avatar} name={s.name} size={28} />
                <span style={{ fontSize: 13.5, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {s.name}
                </span>
              </span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                fontSize: 11.5, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase',
                color: wasPolice ? '#4fd1ff' : wasCaught ? '#ff5566' : '#7af0c8',
              }}>
                {wasPolice ? <Crosshair size={12} /> : <Flame size={12} />}
                {wasPolice ? `${r.catches?.[s.sid] ?? 0} caught` : wasCaught ? 'Caught' : 'Got away'}
              </span>
            </div>
          )
        })}
      </div>

      <div style={{ textAlign: 'center', color: '#5b6479', fontSize: 12, marginTop: 20 }}>
        {state.round >= state.rounds ? 'Counting up the night…' : 'Roles change next round'}
      </div>
    </div>
  )
}

export function MatchRecap({
  state, me, onAgain, onBack,
}: { state: ImpostorState; me: ImpostorMe; onAgain: () => void; onBack: () => void }) {
  const rows = [...state.seats].sort(
    (a, b) => (state.scores?.[b.sid] ?? 0) - (state.scores?.[a.sid] ?? 0),
  )
  const raw = state.scores?.[me.sid] ?? 0
  const banked = Math.min(raw, XP_CAP)
  const wins = state.history?.filter(h =>
    h.winner === 'police' ? state.police.includes(me.sid) : state.thieves.includes(me.sid),
  ).length ?? 0

  return (
    <div className="imp-stage" style={{ paddingBottom: 60 }}>
      <div style={{ textAlign: 'center', padding: '26px 0 20px' }}>
        <div className="imp-verdict" style={{ color: '#ffb020' }}>NIGHT OVER</div>
        <div style={{ fontSize: 13, color: '#9aa4bd', marginTop: 10 }}>
          {state.rounds} rounds · {wins} won
        </div>
        <div style={{
          fontFamily: 'Bangers, Impact, system-ui, sans-serif',
          fontSize: 54, color: '#7af0c8', marginTop: 14, letterSpacing: 2,
        }}>
          +{banked} XP
        </div>
        {raw > XP_CAP && (
          <div style={{ fontSize: 11.5, color: '#5b6479', marginTop: 4 }}>
            capped at {XP_CAP} a match
          </div>
        )}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 26 }}>
        {rows.map((s, i) => (
          <div key={s.sid} className={`imp-score-row ${s.sid === me.sid ? 'me' : ''}`}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
              <span style={{ width: 16, fontSize: 12, fontWeight: 900, color: '#5b6479' }}>{i + 1}</span>
              <Avatar src={s.avatar} name={s.name} size={28} />
              <span style={{ fontSize: 13.5, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {s.name}
              </span>
            </span>
            <span style={{ fontSize: 13, fontWeight: 900, color: '#e8eaf2' }}>
              {state.scores?.[s.sid] ?? 0}
            </span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={onBack}
          style={{
            flex: 1, border: '1px solid rgba(255,255,255,0.14)', background: 'transparent',
            color: '#e8eaf2', borderRadius: 13, padding: '15px 0', fontSize: 13.5, fontWeight: 800,
            cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
          }}
        >
          <ArrowLeft size={16} /> Games
        </button>
        <button
          onClick={onAgain}
          style={{
            flex: 1.4, border: 0, borderRadius: 13, padding: '15px 0',
            fontSize: 13.5, fontWeight: 900, letterSpacing: 0.8,
            color: '#1a1206', background: 'linear-gradient(180deg,#ffc75a,#ffa310)',
            cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
          }}
        >
          <RotateCcw size={16} /> Again
        </button>
      </div>
    </div>
  )
}
