// src/features/impostor/HidePhase.tsx
//
// Thieves claim a mask; the police waits.
//
// Deliberately absent: any indication that a mask is already taken. The
// server silently reassigns a clash rather than saying "that one's gone",
// because knowing a card is occupied is precisely the fact the hunt is built
// on hiding — and the police is looking at this same grid.
import { useState } from 'react'
import { Eye, Check, Hand } from 'lucide-react'
import Toast, { useToast } from '../../shared/components/Toast'
import { useCountdown } from './useCountdown'
import type { ImpostorMe, ImpostorState, PickOutcome } from './impostor'

export default function HidePhase({
  state, me, skewMs, onPick,
}: {
  state: ImpostorState
  me: ImpostorMe
  skewMs: number
  onPick: (idx: number) => Promise<PickOutcome | null>
}) {
  const { secs } = useCountdown(state.ends_at, skewMs)
  const { toast, showToast } = useToast(2200)
  const [sending, setSending] = useState(false)
  const mine = me.card

  async function choose(idx: number) {
    if (sending || mine !== null || me.role !== 'thief') return
    setSending(true)
    const res = await onPick(idx)
    setSending(false)
    // Another thief got there first. Safe to say out loud: the police can't
    // tap this grid, so only thieves ever see it, and they're on your side.
    if (res?.taken) {
      showToast({ message: 'Someone is already behind that one — pick another', icon: Hand, iconColor: 'var(--accent)' })
    }
  }

  if (me.role !== 'thief') {
    return (
      <div className="imp-stage">
        <div className="imp-hud">
          <span className="imp-hud-chip"><Eye size={13} /> Round {state.round}</span>
          <span className={`imp-clock ${secs <= 3 ? 'urgent' : ''}`}>{Math.max(0, secs)}</span>
        </div>
        <div className="imp-reveal" style={{ minHeight: '52vh' }}>
          <div className="imp-slot landed" style={{ color: '#4fd1ff', fontSize: 'clamp(30px,10vw,52px)' }}>
            THEY'RE HIDING
          </div>
          <div className="imp-reveal-sub">
            Masks are going up on the wall. Get your grip on the torch.
          </div>
        </div>
        <div className="imp-board" style={{ opacity: 0.5, pointerEvents: 'none' }}>
          {state.cards.map(c => (
            <div key={c.i} className="imp-card">
              <span className="imp-face">{c.e}</span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="imp-stage">
      <div className="imp-hud">
        <span className="imp-hud-chip">
          {mine === null ? 'Pick a mask' : 'Hidden'}
        </span>
        <span className={`imp-clock ${secs <= 3 ? 'urgent' : ''}`}>{Math.max(0, secs)}</span>
      </div>

      <div className="imp-board">
        {state.cards.map(c => {
          const isMine = mine === c.i
          return (
            <button
              key={c.i}
              className={`imp-card lit ${isMine ? 'mine' : ''}`}
              onClick={() => choose(c.i)}
              disabled={sending || mine !== null}
              style={mine !== null && !isMine ? { filter: 'brightness(0.55) saturate(0.5)' } : undefined}
            >
              <span className="imp-face">{c.e}</span>
              {isMine && (
                <span style={{
                  position: 'absolute', bottom: 6, right: 7,
                  color: '#7af0c8', display: 'inline-flex',
                }}>
                  <Check size={15} />
                </span>
              )}
            </button>
          )
        })}
      </div>

      <div style={{ textAlign: 'center', fontSize: 12.5, color: '#9aa4bd', paddingBottom: 30 }}>
        {mine === null
          ? "Nobody sees which one you take. Leave it and you'll be given one."
          : "That's you. Hold your breath when the light lands."}
      </div>
      <Toast toast={toast} />
    </div>
  )
}
