// src/features/impostor/impostor.ts
//
// Typed layer over the six impostor_* RPCs. Nothing here reads or writes a
// table directly: impostor_cards holds the one secret in the whole game
// (which card a thief is hiding behind) and is unreadable by clients on
// purpose, so every fact about the board arrives through impostor_state.
//
// Note that impostor_state is NOT a pure read — it runs impostor_tick first,
// which is what advances the round when a deadline passes. There is no cron
// and no server process behind this game; the players' own polling is the
// clock. That is why useImpostor keeps polling even when the tab is idle in
// a live round.
import { supabase } from '../../shared/lib/supabase'

export type ImpostorPhase = 'lobby' | 'reveal' | 'hide' | 'hunt' | 'round_end' | 'match_end' | 'expired'
export type ImpostorRole = 'police' | 'thief' | 'none'
export type CardStatus = 'alive' | 'caught' | 'burned'

export interface ImpostorSeat {
  sid: string
  bot: boolean
  name: string
  username: string | null
  avatar: string | null
}

export interface ImpostorCard {
  i: number
  e: string
  s: CardStatus
}

export interface ImpostorRoundResult {
  round: number
  winner: 'police' | 'thieves'
  caught: string[]
  sweep: boolean
  catches: Record<string, number>
}

export interface ImpostorLastTap {
  sid: string
  i: number
  hit: boolean
  /** Seat id of the thief behind that card, null on a miss. Public the
   *  moment it lands — the card is spent either way. */
  target: string | null
  at: string
}

/** Per-seat running tally for the whole match, folded in by
 *  _impostor_end_round before the next round wipes the round state. Keys are
 *  short because this rides in every poll: rounds, as police, as thief,
 *  catches, clean sweeps, rounds survived as a thief, rounds on the winning
 *  side. Only present from round 1's end onward. */
export interface ImpostorTally {
  r: number
  p: number
  t: number
  c: number
  sw: number
  s: number
  w: number
}

export interface ImpostorState {
  v: number
  phase: ImpostorPhase
  round: number
  rounds: number
  seats: ImpostorSeat[]
  police: string[]
  thieves: string[]
  police_done: string[]
  scores: Record<string, number>
  history: { round: number; winner: string }[]
  cards: ImpostorCard[]
  caught: string[]
  round_catches: Record<string, number>
  /** Lives REMAINING PER POLICE, keyed by seat id — not a shared pool. With
   *  two police, one running dry doesn't end the round for the other. */
  lives: Record<string, number>
  /** What each police started the round on, so the HUD can draw spent pips. */
  lives_base?: number
  /** Police who have burned through their own lives. They stop shooting and
   *  spectate; the round falls to the thieves only when all of them are here. */
  police_out?: string[]
  /** Real players required before a match may start. Bots only top up seats
   *  above this — they never manufacture a match for one person. */
  min_humans?: number
  ends_at: string | null
  hunt_secs?: number
  /** True when no human drew thief this round — see the bot-tell migration.
   *  The board is shorter and the police gets an extra life, because there
   *  is no breathing to read. */
  solo?: boolean
  /** Match-long per-seat tally, keyed by seat id. The server writes each
   *  human's slice into game_sessions.metadata.stats at match_end; this copy
   *  is what the client credits weekly missions from. */
  tally?: Record<string, ImpostorTally>
  round_result: ImpostorRoundResult | null
  last_tap?: ImpostorLastTap
}

export interface ImpostorMe {
  sid: string
  role: ImpostorRole
  /** Which card this player is hiding behind. Thieves only, never sent to
   *  the police for any seat. */
  card: number | null
  /** Indices this client is responsible for broadcasting breathing on — its
   *  own card plus a slice of the cards nobody is playing. Without the decoy
   *  slice, the police could read the board off the realtime channel by
   *  noting which indices ever appear. */
  cover: number[]
  /** The subset of `cover` that a bot is hiding behind, so this client can
   *  simulate them into the same stream. */
  bots: number[]
}

export interface ImpostorSnapshot {
  state: ImpostorState
  me: ImpostorMe
  server_now: string
}

export interface TapOutcome {
  state: ImpostorState
  last: ImpostorLastTap | null
}

/** Joins the fullest open lobby, or opens one. Safe to call twice — a player
 *  already seated in a live match is handed that room back rather than a
 *  second one. */
export async function matchmake(): Promise<string> {
  const { data, error } = await supabase.rpc('impostor_matchmake')
  if (error) throw new Error(friendly(error.message))
  return data as string
}

export async function fetchImpostor(roomId: string): Promise<ImpostorSnapshot | null> {
  const { data, error } = await supabase.rpc('impostor_state', { p_room: roomId })
  if (error) throw new Error(friendly(error.message))
  return (data as ImpostorSnapshot | null) ?? null
}

export interface PickOutcome {
  /** null when the card was already taken and nothing was claimed. */
  idx: number | null
  taken: boolean
}

/** Claims a card to hide behind.
 *
 *  A clash comes back as `taken` rather than being silently reassigned. Only
 *  another thief can ever see that — the police cannot tap the hide grid —
 *  and thieves share a side, so there is nothing to protect. Anyone who never
 *  picks is given a random card when the hunt opens. */
export async function pickCard(roomId: string, idx: number): Promise<PickOutcome> {
  const { data, error } = await supabase.rpc('impostor_pick', { p_room: roomId, p_idx: idx })
  if (error) throw new Error(friendly(error.message))
  const row = data as { idx: number | null; taken?: boolean }
  return { idx: row.idx, taken: !!row.taken }
}

export async function tapCard(roomId: string, idx: number): Promise<TapOutcome> {
  const { data, error } = await supabase.rpc('impostor_tap', { p_room: roomId, p_idx: idx })
  if (error) throw new Error(friendly(error.message))
  return data as TapOutcome
}

export async function leaveImpostor(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('impostor_leave', { p_room: roomId })
  if (error) console.error('impostor_leave', error)
}

/** The RPCs raise CV_-prefixed codes so the client can show the human half
 *  without leaking a Postgres error into the UI. */
function friendly(message: string): string {
  const m = /CV_[A-Z_]+:\s*(.+)$/.exec(message)
  return m ? m[1] : message
}

export function seatOf(state: ImpostorState, sid: string): ImpostorSeat | undefined {
  return state.seats.find(s => s.sid === sid)
}

export function isPoliceSeat(state: ImpostorState, sid: string): boolean {
  return state.police.includes(sid)
}

/** Milliseconds until the current phase's deadline, floored at zero. */
export function msLeft(endsAt: string | null, skewMs = 0): number {
  if (!endsAt) return 0
  return Math.max(0, new Date(endsAt).getTime() - (Date.now() + skewMs))
}
