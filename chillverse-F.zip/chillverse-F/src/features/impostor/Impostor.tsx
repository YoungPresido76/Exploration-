// src/features/impostor/Impostor.tsx
//
// Shell for the whole game — reached from the Game Zone hero slide as a view
// swap, following the FortuneVault / ActivityGoals precedent rather than a
// route of its own.
//
// The intro screen exists to protect the session allowance: matchmaking is
// what costs the 2 sessions, so wandering onto this screen and backing out
// must not spend anything. Sessions are taken once per MATCH, not per round.
import { useCallback, useEffect, useRef, useState } from 'react'
import { ArrowLeft, Crosshair, Eye, Loader2 } from 'lucide-react'
import FeatureFlagGate from '../../shared/components/FeatureFlagGate'
import Toast, { useToast } from '../../shared/components/Toast'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { getSessionLimits } from '../../shared/lib/proPlans'
import { tryConsumeSession, refundSession } from '../games/gameSession'
import { useGamePresence } from '../games/useGamePresence'
import { checkForLevelUp } from '../levelup/levelUpDetector'
import { recordDuoPlay } from '../duo/duo'
import { markDuoPlayPending, publishDuoPlay } from '../duo/duoBus'
import { updateMissionProgress } from '../missions/weeklyMissions'
import { triggerAchievementCheck } from '../achievements/triggerAchievements'
import Scene, { themeFor } from './Scene'
import { useImpostor } from './useImpostor'
import ImpostorLobby from './ImpostorLobby'
import RoleReveal from './RoleReveal'
import HidePhase from './HidePhase'
import HuntScene from './HuntScene'
import { RoundRecap, MatchRecap } from './ImpostorRecap'
import './impostor.css'

const SESSION_COST = 2

export default function Impostor({ onBack }: { onBack: () => void }) {
  return (
    <FeatureFlagGate flagKey="game:impostor">
      <ImpostorEntry onBack={onBack} />
    </FeatureFlagGate>
  )
}

function ImpostorEntry({ onBack }: { onBack: () => void }) {
  const { session } = useAuth()
  const userId = session?.user?.id ?? ''
  const { profile } = useProfile()
  const { toast, showToast } = useToast(3600)

  const [runId, setRunId] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [starting, setStarting] = useState(false)

  const start = useCallback(async () => {
    if (!userId || starting) return
    setStarting(true)
    const limit = getSessionLimits(profile).limit
    const res = await tryConsumeSession(userId, SESSION_COST, limit)
    setStarting(false)
    // null means the call itself failed — that's "unknown", not "denied", so
    // it must not block play (same reading as every other game).
    if (res && !res.allowed) {
      showToast({ message: 'Your sessions are spent. Come back when they reset.', icon: Crosshair, iconColor: 'var(--red)' })
      return
    }
    setPlaying(true)
  }, [userId, profile, starting, showToast])

  // "Again" is a fresh match, so it costs sessions again — it drops the old
  // one (which frees the seat via useImpostor's cleanup), bumps the key so the
  // hook re-runs matchmaking, and goes straight back in rather than bouncing
  // the player through the intro a second time.
  const again = useCallback(() => {
    setPlaying(false)
    setRunId(r => r + 1)
    void start()
  }, [start])



  if (playing) {
    return (
      <ImpostorMatch
        key={runId}
        userId={userId}
        onBack={onBack}
        onAgain={again}
      />
    )
  }

  return (
    <div className="imp-root t-alley">
      <Scene theme="alley" />
      <div className="imp-lamp" />
      <div className="imp-stage" style={{ paddingBottom: 40 }}>
        <button
          onClick={onBack}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 6, border: 0, background: 'transparent',
            color: '#9aa4bd', fontSize: 14, fontWeight: 700, padding: '10px 0', cursor: 'pointer',
          }}
        >
          <ArrowLeft size={18} /> Games
        </button>

        <div style={{ textAlign: 'center', padding: '18px 0 26px' }}>
          <div style={{
            fontFamily: 'Bangers, Impact, system-ui, sans-serif',
            fontSize: 'clamp(44px, 15vw, 78px)', letterSpacing: 3, lineHeight: 1,
            color: '#ffb020', textShadow: '0 0 34px rgba(255,176,32,0.45)',
          }}>
            IMPOSTOR
          </div>
          <div style={{ color: '#9aa4bd', fontSize: 13.5, marginTop: 8 }}>
            Three rounds. Everyone gets a turn with the torch.
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 26 }}>
          <Rule
            icon={<Crosshair size={17} />}
            title="If you draw police"
            body="Drag the torch across the masks. A decoy is an object and sits still. A thief is a person — hold the light on them and eventually they breathe. Tap the one that twitches. Two lives."
          />
          <Rule
            icon={<Eye size={17} />}
            title="If you draw thief"
            body="Pick a mask to hide behind, then hold your breath every time the torch lands on you. You can only hold it so long, so pray it moves on."
          />
        </div>

        <button
          onClick={start}
          disabled={starting}
          style={{
            width: '100%', border: 0, borderRadius: 15, padding: '18px 0',
            fontSize: 15, fontWeight: 900, letterSpacing: 1.4, textTransform: 'uppercase',
            color: '#1a1206', background: 'linear-gradient(180deg,#ffc75a,#ffa310)',
            boxShadow: '0 10px 26px rgba(255,163,16,0.3)', cursor: 'pointer',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 9,
            opacity: starting ? 0.7 : 1,
          }}
        >
          {starting ? <Loader2 size={18} className="spin" /> : null}
          {starting ? 'Finding a match' : `Play · ${SESSION_COST} sessions`}
        </button>
      </div>
      <Toast toast={toast} />
    </div>
  )
}

function Rule({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div style={{
      display: 'flex', gap: 12, padding: '13px 14px', borderRadius: 14,
      background: 'rgba(255,255,255,0.045)', border: '1px solid rgba(255,255,255,0.06)',
    }}>
      <span style={{ color: '#ffb020', flexShrink: 0, marginTop: 2 }}>{icon}</span>
      <div>
        <div style={{ fontWeight: 800, fontSize: 13.5, marginBottom: 3 }}>{title}</div>
        <div style={{ fontSize: 12.5, lineHeight: 1.55, color: '#9aa4bd' }}>{body}</div>
      </div>
    </div>
  )
}

function ImpostorMatch({
  userId, onBack, onAgain,
}: { userId: string; onBack: () => void; onAgain: () => void }) {
  const { roomId, snap, loading, error, skewMs, pick, tap, quit } = useImpostor(true)
  const { toast, showToast } = useToast(3600)
  const { profile } = useProfile()
  const bankedRef = useRef(false)
  const refundedRef = useRef(false)
  const [refunded, setRefunded] = useState<'pending' | 'done' | 'failed'>('pending')

  useGamePresence('impostor')

  // The controls own the bottom of the screen, so the dock has to go for the
  // duration — same body-class mechanism AttackSheet and the bounty poster
  // use. .imp-breath-wrap anchors to bottom:0 to match.
  useEffect(() => {
    document.body.classList.add('cv-sheet-open')
    return () => { document.body.classList.remove('cv-sheet-open') }
  }, [])

  useEffect(() => {
    if (error) showToast({ message: error, icon: Crosshair, iconColor: 'var(--red)' })
  }, [error, showToast])

  // The server already inserted the game_session and the on_game_session_insert
  // trigger already granted the XP — nothing here awards anything. These two
  // are the client-side consequences that would otherwise be missed, since
  // this game never goes through saveGameSession.
  const phase = snap?.state.phase
  const myXp = snap ? (snap.state.scores?.[snap.me.sid] ?? 0) : 0
  // The match-long tally the server folded in at each round end. Read once at
  // match_end rather than per round, so a player who reloads mid-match can't
  // credit the same round twice.
  const myTally = snap ? snap.state.tally?.[snap.me.sid] : undefined
  useEffect(() => {
    if (phase !== 'match_end' || bankedRef.current || !userId) return
    bankedRef.current = true
    checkForLevelUp(userId)
    if (myXp > 0) {
      markDuoPlayPending()
      recordDuoPlay(myXp).then(publishDuoPlay).catch(() => publishDuoPlay(null))
    }

    // ── Weekly missions ──────────────────────────────────────
    // Impostor never goes through Games.tsx handleResult, which is where
    // every other game's mission metrics fire — so without this block the
    // game counts for nothing. Credited from the server's own tally, and
    // only for metrics that actually moved, so a spectator round sends
    // nothing. All five impostor missions carry requires_flag, so they can
    // only be on a card while the game is switched on.
    updateMissionProgress(userId, 'impostor_played', 1).catch(console.error)
    if (myTally) {
      if (myTally.c  > 0) updateMissionProgress(userId, 'impostor_catches',    myTally.c).catch(console.error)
      if (myTally.s  > 0) updateMissionProgress(userId, 'impostor_survived',   myTally.s).catch(console.error)
      if (myTally.w  > 0) updateMissionProgress(userId, 'impostor_rounds_won', myTally.w).catch(console.error)
      if (myTally.sw > 0) updateMissionProgress(userId, 'impostor_sweep',      myTally.sw).catch(console.error)
    }

    // Achievements read game_sessions.metadata.stats, which _impostor_finish
    // writes in the same transaction that ends the match — so this can run
    // straight away rather than waiting for a poll.
    triggerAchievementCheck(userId).catch(console.error)
  }, [phase, userId, myXp, myTally])

  // Sessions are taken at Play, before we know whether three real players
  // will turn up. If the match never starts — the room expired, or you left
  // while still in the lobby — that charge has to come back. Guarded by a ref
  // because the expiry effect and a manual Leave can both reach it.
  const refundIfUnplayed = useCallback(async (): Promise<boolean> => {
    if (refundedRef.current || !userId) return false
    refundedRef.current = true
    const limit = getSessionLimits(profile).limit
    const res = await refundSession(userId, SESSION_COST, limit)
    return res !== null
  }, [userId, profile])

  useEffect(() => {
    if (phase !== 'expired') return
    void refundIfUnplayed().then(ok => setRefunded(ok ? 'done' : 'failed'))
  }, [phase, refundIfUnplayed])

  const leaveNow = useCallback(async () => {
    // Only an un-started match is refundable. Bailing out of a live round is
    // forfeiting, not a failed match.
    if (phase === 'lobby' || phase === 'expired') await refundIfUnplayed()
    await quit()
    onBack()
  }, [phase, refundIfUnplayed, quit, onBack])

  if (loading && !snap) {
    return (
      <div className="imp-root t-alley">
        <Scene theme="alley" />
        <div className="imp-stage" style={{ display: 'grid', placeContent: 'center', minHeight: '70vh', textAlign: 'center' }}>
          <Loader2 size={30} className="spin" style={{ margin: '0 auto 12px', color: '#ffb020' }} />
          <div style={{ color: '#9aa4bd', fontSize: 13.5 }}>Slipping into the alley…</div>
        </div>
      </div>
    )
  }

  if (!snap) {
    return (
      <div className="imp-root t-alley">
        <div className="imp-stage" style={{ display: 'grid', placeContent: 'center', minHeight: '70vh', textAlign: 'center', gap: 14 }}>
          <div style={{ color: '#9aa4bd', fontSize: 14 }}>That match is gone.</div>
          <button onClick={onBack} style={ghostBtn}>Back to Games</button>
        </div>
        <Toast toast={toast} />
      </div>
    )
  }

  const { state, me } = snap

  // A different scene each round, agreed across clients by hashing room+round
  // rather than by storing it — see Scene.tsx.
  const theme = themeFor(roomId ?? '', state.round)

  return (
    <div className={`imp-root t-${theme}`}>
      <Scene theme={theme} />
      {state.phase !== 'hunt' && <div className="imp-lamp" />}

      {state.phase === 'lobby' && (
        <ImpostorLobby state={state} skewMs={skewMs} onQuit={leaveNow} />
      )}
      {state.phase === 'reveal' && (
        <RoleReveal state={state} me={me} skewMs={skewMs} />
      )}
      {state.phase === 'hide' && (
        <HidePhase state={state} me={me} skewMs={skewMs} onPick={pick} />
      )}
      {state.phase === 'hunt' && roomId && (
        <HuntScene roomId={roomId} state={state} me={me} skewMs={skewMs} onTap={tap} />
      )}
      {state.phase === 'round_end' && (
        <RoundRecap state={state} me={me} skewMs={skewMs} />
      )}
      {state.phase === 'expired' && (
        <ExpiredScreen
          humans={state.seats.filter(s => !s.bot).length}
          refunded={refunded}
          onAgain={onAgain}
          onBack={leaveNow}
        />
      )}
      {state.phase === 'match_end' && (
        <MatchRecap state={state} me={me} onAgain={onAgain} onBack={leaveNow} />
      )}
      <Toast toast={toast} />
    </div>
  )
}

/** Not enough real players turned up. Said plainly rather than dressed up —
 *  the alternative was a lobby of bots pretending to be a match. */
function ExpiredScreen({
  humans, refunded, onAgain, onBack,
}: {
  humans: number
  refunded: 'pending' | 'done' | 'failed'
  onAgain: () => void
  onBack: () => void
}) {
  return (
    <div className="imp-stage">
      <div className="imp-reveal" style={{ minHeight: '62vh' }}>
        <div className="imp-slot landed" style={{ color: '#7d879e', fontSize: 'clamp(30px,10vw,52px)' }}>
          NO MATCH
        </div>
        <div className="imp-reveal-sub">
          Only {humans} {humans === 1 ? 'player' : 'players'} showed up. Impostor needs three before
          it can start, so this room has closed.
        </div>
        <div style={{
          margin: '4px auto 0', padding: '11px 14px', maxWidth: 300, borderRadius: 12,
          background: refunded === 'failed' ? 'rgba(255,85,102,0.10)' : 'rgba(122,240,200,0.10)',
          border: `1px solid ${refunded === 'failed' ? 'rgba(255,85,102,0.3)' : 'rgba(122,240,200,0.3)'}`,
          color: refunded === 'failed' ? '#ff8a99' : '#7af0c8',
          fontSize: 12.5, fontWeight: 700, lineHeight: 1.5,
        }}>
          {refunded === 'pending' && 'Returning your sessions…'}
          {refunded === 'done' && `Your ${SESSION_COST} sessions have been refunded.`}
          {refunded === 'failed' && `We couldn't return your ${SESSION_COST} sessions automatically. Contact support and they'll sort it.`}
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 22 }}>
          <button onClick={onBack} style={{ ...ghostBtn, flex: 1 }}>Games</button>
          <button
            onClick={onAgain}
            style={{
              flex: 1.3, border: 0, borderRadius: 12, padding: '12px 0',
              fontSize: 13.5, fontWeight: 900, color: '#1a1206',
              background: 'linear-gradient(180deg,#ffc75a,#ffa310)', cursor: 'pointer',
            }}
          >
            Try again
          </button>
        </div>
      </div>
    </div>
  )
}

const ghostBtn: React.CSSProperties = {
  border: '1px solid rgba(255,255,255,0.14)',
  background: 'transparent',
  color: '#e8eaf2',
  borderRadius: 12,
  padding: '12px 20px',
  fontSize: 13.5,
  fontWeight: 800,
  cursor: 'pointer',
}
