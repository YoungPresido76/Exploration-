// src/features/impostor/breath.ts
//
// The tell, and the wire it travels on.
//
// FICTION: the board is a wall of masks. Under the torch a decoy is an
// object and sits perfectly still. A thief is a person wearing one, and a
// person under a torch has to hold their breath — hold too long and you
// gasp, and the mask twitches. Out of the beam everything drifts idly and
// nothing is readable. So the police's tool is to LINGER, and the thief's
// job is to survive the linger.
//
// WHY IT IS NOT IN game_state: rooms.game_state is readable by every player
// in the room, so anything written there is readable by the police. Twitches
// therefore travel over an ephemeral Realtime broadcast channel instead, and
// each human thief broadcasts for a slice of the unplayed cards as well as
// its own (`me.cover`) — otherwise the police could read the board simply by
// noting which indices ever appear on the wire.
//
// The honest limit, unchanged from the design note: a thief who opens
// devtools can fake their own breathing. They cannot force a wrong catch,
// change a life count, or alter a result — the server owns all of those.

import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from '../../shared/lib/supabase'

// ─── Timing ────────────────────────────────────────────────────────────
/** How long a human thief can hold the beam before they gasp. */
export const HOLD_CAPACITY_MS = 3500
/** Time from empty to full once the beam has moved on. */
export const HOLD_REFILL_MS = 5000
/** How long a gasp stays visible. Long enough to react to, short enough
 *  that a police who blinks genuinely misses it. */
export const GASP_MS = 900
/** A twitch older than this is treated as stale and rendered as still, so a
 *  thief who backgrounds their phone doesn't freeze mid-gasp forever. */
export const TWITCH_TTL_MS = 700
/** Heartbeat for covered indices. Also what keeps a still card's silence
 *  from being distinguishable from a disconnected one. */
export const BEAT_MS = 350

// ─── Seeded noise ──────────────────────────────────────────────────────
// Bot behaviour has to look organic without being predictable to anyone who
// can read the code. Seeding off room+round+index means every client that
// simulates the same bot card agrees with itself frame to frame, which is
// all that is needed — no client but the covering thief's ever runs it.

export function hash32(input: string): number {
  let h = 2166136261
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** Idle drift, used for every card whether or not anyone is behind it.
 *  Purely cosmetic — it is what makes the unlit board unreadable. */
export function idleDrift(roomId: string, round: number, idx: number, nowMs: number): number {
  const rnd = mulberry32(hash32(`${roomId}:${round}:${idx}:drift`))
  const period = 2400 + rnd() * 1400
  const offset = rnd() * period
  return 0.5 + 0.5 * Math.sin((2 * Math.PI * (nowMs + offset)) / period)
}

// ─── Bot thieves ───────────────────────────────────────────────────────
/** A bot holds for a seeded stretch once the beam lands, then gasps, then
 *  gathers itself and holds again. Leaving the beam resets it. Tuned to sit
 *  either side of a human's capacity so bots are neither free catches nor
 *  better than the players. */
export class BotBreath {
  private rnd: () => number
  private litSince = 0
  private nextGaspAt = 0
  private gaspUntil = 0

  constructor(roomId: string, round: number, idx: number) {
    this.rnd = mulberry32(hash32(`${roomId}:${round}:${idx}:bot`))
  }

  update(lit: boolean, nowMs: number): boolean {
    if (!lit) {
      this.litSince = 0
      this.nextGaspAt = 0
      // A gasp already in flight is allowed to finish, so the police is not
      // robbed of a tell by their own finger moving on a frame too early.
      return nowMs < this.gaspUntil
    }
    if (this.litSince === 0) {
      this.litSince = nowMs
      this.nextGaspAt = nowMs + 900 + this.rnd() * 2200
    }
    if (nowMs >= this.gaspUntil && nowMs >= this.nextGaspAt) {
      this.gaspUntil = nowMs + GASP_MS
      this.nextGaspAt = this.gaspUntil + 700 + this.rnd() * 1500
    }
    return nowMs < this.gaspUntil
  }
}

// ─── The human thief's lungs ───────────────────────────────────────────
export interface BreathState {
  /** 0..1 — what the meter shows. */
  left: number
  /** True when the card is visibly twitching right now. */
  twitching: boolean
  /** True once the meter has bottomed out and the beam has not yet left. */
  spent: boolean
}

export class Lungs {
  private ms = HOLD_CAPACITY_MS
  private gaspUntil = 0
  private spent = false

  /** @param lit     is the beam on my card
   *  @param holding is the player pressing HOLD
   *  @param dt      ms since the last update */
  update(lit: boolean, holding: boolean, dt: number, nowMs: number): BreathState {
    if (!lit) {
      this.spent = false
      if (!holding) this.ms = Math.min(HOLD_CAPACITY_MS, this.ms + (dt * HOLD_CAPACITY_MS) / HOLD_REFILL_MS)
      return { left: this.ms / HOLD_CAPACITY_MS, twitching: nowMs < this.gaspUntil, spent: false }
    }

    // Lit and not holding: a person under a torch who is still breathing.
    if (!holding) {
      this.gaspUntil = Math.max(this.gaspUntil, nowMs + 220)
      return { left: this.ms / HOLD_CAPACITY_MS, twitching: true, spent: this.spent }
    }

    this.ms = Math.max(0, this.ms - dt)
    if (this.ms <= 0) {
      this.spent = true
      if (nowMs >= this.gaspUntil) this.gaspUntil = nowMs + GASP_MS
    }
    return { left: this.ms / HOLD_CAPACITY_MS, twitching: nowMs < this.gaspUntil, spent: this.spent }
  }

  reset() {
    this.ms = HOLD_CAPACITY_MS
    this.gaspUntil = 0
    this.spent = false
  }
}

// ─── Wire ──────────────────────────────────────────────────────────────
// Two message types only. `beam` is public information — it is drawn on
// every screen anyway — so the police sends it plainly. `card` carries a
// twitch flag for one index, and says nothing about who sent it.

export interface BeamMessage { i: number | null }
export interface CardMessage { i: number; t: boolean }

export class ImpostorChannel {
  private ch: RealtimeChannel | null = null
  private onBeam: (i: number | null) => void
  private onCard: (i: number, twitching: boolean) => void

  constructor(
    roomId: string,
    handlers: { onBeam: (i: number | null) => void; onCard: (i: number, twitching: boolean) => void },
  ) {
    this.onBeam = handlers.onBeam
    this.onCard = handlers.onCard
    this.ch = supabase.channel(`impostor:${roomId}`, { config: { broadcast: { self: false } } })
    this.ch
      .on('broadcast', { event: 'beam' }, ({ payload }) => {
        const p = payload as BeamMessage
        this.onBeam(typeof p?.i === 'number' ? p.i : null)
      })
      .on('broadcast', { event: 'card' }, ({ payload }) => {
        const p = payload as CardMessage
        if (typeof p?.i === 'number') this.onCard(p.i, !!p.t)
      })
      .subscribe()
  }

  sendBeam(i: number | null) {
    this.ch?.send({ type: 'broadcast', event: 'beam', payload: { i } satisfies BeamMessage })
  }

  sendCard(i: number, twitching: boolean) {
    this.ch?.send({ type: 'broadcast', event: 'card', payload: { i, t: twitching } satisfies CardMessage })
  }

  close() {
    if (this.ch) supabase.removeChannel(this.ch)
    this.ch = null
  }
}
