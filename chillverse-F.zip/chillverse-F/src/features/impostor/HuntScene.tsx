// src/features/impostor/HuntScene.tsx
//
// The round itself.
//
// AIM AND FIRE ARE SEPARATE. The torch stays where you leave it rather than
// following a held finger, and a dedicated FIRE button takes the shot. That
// is not decoration: the police's only real tool is to LINGER on a mask until
// the person behind it runs out of breath, and a "hold to aim, lift to shoot"
// scheme would take the light away at the exact moment you decided to shoot.
//
// PERFORMANCE. Every card breathes and up to fifteen are on screen. Drift,
// twitch and lit states are written straight to the DOM from a single rAF
// loop rather than through React state — a setState per card per frame drops
// the board to single-figure fps on a cheap Android.
//
// The loop reads its inputs through refs on purpose. `me.cover` and friends
// are fresh array identities on every poll, so putting them in the dependency
// list would tear down and rebuild the animation loop once a second.
import { useCallback, useEffect, useRef, useState } from 'react'
import { Crosshair, Flame } from 'lucide-react'
import { playGunshot, playWrongCard, playCoin, playGameOver } from '../games/sfx'
import { useCountdown } from './useCountdown'
import { seatOf } from './impostor'
import {
  BotBreath, ImpostorChannel, Lungs, idleDrift,
  BEAT_MS, TWITCH_TTL_MS,
} from './breath'
import type { ImpostorMe, ImpostorState } from './impostor'

/** How long a miss locks the police out. Long enough to hurt, short enough
 *  that one bad shot isn't the whole round. */
const STUN_MS = 1500

export default function HuntScene({
  roomId, state, me, skewMs, onTap,
}: {
  roomId: string
  state: ImpostorState
  me: ImpostorMe
  skewMs: number
  onTap: (idx: number) => Promise<boolean | null>
}) {
  const { secs, ms } = useCountdown(state.ends_at, skewMs)
  const isPolice = me.role === 'police'
  const round = state.round
  const roundKey = `${roomId}:${round}`

  const boardRef = useRef<HTMLDivElement | null>(null)
  const cardRefs = useRef<Map<number, HTMLButtonElement>>(new Map())
  const faceRefs = useRef<Map<number, HTMLSpanElement>>(new Map())
  const torchRef = useRef<HTMLDivElement | null>(null)
  const fillRef = useRef<HTMLDivElement | null>(null)

  const chanRef = useRef<ImpostorChannel | null>(null)
  const lungsRef = useRef<Lungs>(new Lungs())
  const botsRef = useRef<Map<number, BotBreath>>(new Map())
  /** index -> timestamp we last heard "twitching" for it on the wire */
  const heardRef = useRef<Map<number, number>>(new Map())

  const beamRef = useRef<number | null>(null)
  const holdRef = useRef(false)
  const stunUntilRef = useRef(0)
  // Snapshots the loop reads instead of closing over props.
  const meRef = useRef(me)
  const cardsRef = useRef(state.cards)
  const litMeRef = useRef(false)
  const lowRef = useRef(false)

  // The locked card, which is what Fire actually shoots. Aiming by drag moves
  // the torch without arming anything; only a deliberate tap locks.
  const [lock, setLock] = useState<number | null>(null)
  const lockRef = useRef<number | null>(null)
  const [holding, setHolding] = useState(false)
  const [firing, setFiring] = useState(false)
  const [flash, setFlash] = useState(0)
  const [damage, setDamage] = useState(0)
  const [litMe, setLitMe] = useState(false)
  const [lowBreath, setLowBreath] = useState(false)
  const [shot, setShot] = useState(0)
  const [callout, setCallout] = useState<{ id: string; name: string; mine: boolean } | null>(null)

  const iAmThief = me.role === 'thief'
  const caughtAsThief = iAmThief && (state.caught ?? []).includes(me.sid)
  // A police who has spent their own lives is out of the round but the round
  // carries on for any partner still holding a torch.
  const outAsPolice = isPolice && (state.police_out ?? []).includes(me.sid)
  const caught = caughtAsThief || outAsPolice
  const caughtRef = useRef(caught)
  const myLives = state.lives?.[me.sid] ?? 0
  const livesBase = state.lives_base ?? 2

  useEffect(() => { meRef.current = me }, [me])

  // Announce a catch to everyone: the police who took the shot gets credit,
  // everyone else just learns who went down. Keyed on last_tap.at so a poll
  // that repeats the same tap doesn't replay it.
  const tap = state.last_tap
  useEffect(() => {
    if (!tap || !tap.hit || !tap.target) return
    const name = seatOf(state, tap.target)?.name ?? 'Someone'
    setCallout({ id: tap.at, name, mine: tap.sid === me.sid })
    const t = setTimeout(() => setCallout(null), 1900)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tap?.at])

  // One splatter on the hit itself, not on every poll that still reports you
  // as caught.
  useEffect(() => {
    caughtRef.current = caught
    if (!caught) return
    setShot(Date.now())
    // You hear the shot that got you, then the round falls away.
    playGunshot()
    setTimeout(() => playGameOver(), 260)
  }, [caught])
  useEffect(() => { cardsRef.current = state.cards }, [state.cards])

  // ── Channel ───────────────────────────────────────────────────────────
  useEffect(() => {
    const ch = new ImpostorChannel(roomId, {
      onBeam: i => {
        // Only a thief takes the beam off the wire; the police owns its own.
        if (meRef.current.role === 'police') return
        beamRef.current = i
      },
      onCard: (i, twitching) => {
        if (twitching) heardRef.current.set(i, performance.now())
        else heardRef.current.delete(i)
      },
    })
    chanRef.current = ch
    return () => { ch.close(); chanRef.current = null }
  }, [roomId])

  // ── Fresh round: forget everything from the last one ─────────────────
  useEffect(() => {
    botsRef.current = new Map()
    heardRef.current = new Map()
    lungsRef.current.reset()
    beamRef.current = null
    lockRef.current = null
    stunUntilRef.current = 0
    setLock(null)
    setLitMe(false)
    setLowBreath(false)
  }, [roundKey])

  // ── Aim ───────────────────────────────────────────────────────────────
  const aimAt = useCallback((idx: number | null) => {
    if (!isPolice) return
    if (Date.now() < stunUntilRef.current) return
    if (idx !== null) {
      const card = cardsRef.current.find(c => c.i === idx)
      if (!card || card.s !== 'alive') return
    }
    beamRef.current = idx
    chanRef.current?.sendBeam(idx)
  }, [isPolice])

  /** A tap arms the shot. Separate from aiming so dragging the torch across
   *  the board can never fire, and so a mistap costs nothing until you
   *  actually pull the trigger. */
  const lockOn = useCallback((idx: number) => {
    if (!isPolice || caughtRef.current || Date.now() < stunUntilRef.current) return
    const card = cardsRef.current.find(c => c.i === idx)
    if (!card || card.s !== 'alive') return
    aimAt(idx)
    lockRef.current = idx
    setLock(idx)
  }, [isPolice, aimAt])

  const clearLock = useCallback(() => {
    lockRef.current = null
    setLock(null)
  }, [])

  const pointerAim = useCallback((clientX: number, clientY: number) => {
    const el = document.elementFromPoint(clientX, clientY)
    const card = el?.closest('[data-idx]') as HTMLElement | null
    if (!card) return
    const idx = Number(card.dataset.idx)
    if (!Number.isFinite(idx) || idx === beamRef.current) return
    if (lockRef.current !== null && lockRef.current !== idx) clearLock()
    aimAt(idx)
  }, [aimAt, clearLock])

  // ── Fire ──────────────────────────────────────────────────────────────
  const fire = useCallback(async () => {
    if (!isPolice || firing || caughtRef.current) return
    const idx = lockRef.current
    if (idx === null || Date.now() < stunUntilRef.current) return
    const card = cardsRef.current.find(c => c.i === idx)
    if (!card || card.s !== 'alive') return

    setFiring(true)
    setFlash(Date.now())
    playGunshot()
    const hit = await onTap(idx)
    setFiring(false)

    // Either way the mask is spent, so the lock and the light both release.
    lockRef.current = null
    setLock(null)
    beamRef.current = null
    chanRef.current?.sendBeam(null)

    if (hit === true) {
      playCoin()
    } else if (hit === false) {
      playWrongCard()
      stunUntilRef.current = Date.now() + STUN_MS
      setDamage(Date.now())
    }
  }, [isPolice, firing, onTap])

  // ── Render loop ───────────────────────────────────────────────────────
  useEffect(() => {
    let raf = 0
    let last = performance.now()
    let beat = 0

    function frame(now: number) {
      const dt = Math.min(64, now - last)
      last = now
      const lit = beamRef.current
      const mine = meRef.current
      const cards = cardsRef.current

      // The thief's lungs. Only the beam sitting on THEIR card costs
      // anything; anywhere else the meter refills.
      let myTwitch = false
      if (mine.role === 'thief' && mine.card !== null && !caughtRef.current) {
        const onMe = lit === mine.card
        const st = lungsRef.current.update(onMe, holdRef.current, dt, now)
        myTwitch = st.twitching
        if (fillRef.current) fillRef.current.style.width = `${Math.round(st.left * 100)}%`
        const isLow = st.left < 0.3
        if (isLow !== lowRef.current) { lowRef.current = isLow; setLowBreath(isLow) }
        if (onMe !== litMeRef.current) { litMeRef.current = onMe; setLitMe(onMe) }
      }

      for (const card of cards) {
        const i = card.i
        const el = cardRefs.current.get(i)
        const face = faceRefs.current.get(i)
        if (!el || !face) continue

        const dead = card.s !== 'alive'
        const isLit = lit === i && !dead

        let twitching = false
        if (!dead) {
          if (mine.role === 'thief' && i === mine.card) {
            twitching = myTwitch
          } else {
            const heard = heardRef.current.get(i) ?? 0
            twitching = now - heard < TWITCH_TTL_MS
          }
        }

        el.classList.toggle('lit', isLit)
        el.classList.toggle('locked', lockRef.current === i && !dead)
        el.classList.toggle('twitch', twitching)

        // Drift only away from the light. Under the torch a decoy is an
        // object and holds perfectly still — that stillness is what makes a
        // twitch mean something.
        if (!isLit && !dead) {
          const d = idleDrift(roundKey, round, i, now)
          face.style.transform = `translate3d(0, ${(d - 0.5) * 3.2}px, 0)`
        } else if (!twitching) {
          face.style.transform = 'translate3d(0,0,0)'
        }
      }

      if (torchRef.current && boardRef.current) {
        const el = lit === null ? null : cardRefs.current.get(lit)
        if (!el) {
          torchRef.current.style.opacity = '0'
        } else {
          const b = boardRef.current.getBoundingClientRect()
          const r = el.getBoundingClientRect()
          torchRef.current.style.opacity = '1'
          torchRef.current.style.transform =
            `translate3d(${r.left - b.left + r.width / 2}px, ${r.top - b.top + r.height / 2}px, 0)`
        }
      }

      // Outbound breathing, thieves only: own card plus the cover slice, so
      // the police can't read the board by noting which indices ever talk.
      if (mine.role === 'thief' && now - beat > BEAT_MS) {
        beat = now
        for (const i of mine.cover) {
          let t = false
          if (i === mine.card) {
            t = caughtRef.current ? false : myTwitch
          } else if (mine.bots.includes(i)) {
            let bot = botsRef.current.get(i)
            if (!bot) { bot = new BotBreath(roundKey, round, i); botsRef.current.set(i, bot) }
            t = bot.update(lit === i, now)
          }
          chanRef.current?.sendCard(i, t)
        }
      }

      raf = requestAnimationFrame(frame)
    }

    raf = requestAnimationFrame(frame)
    return () => cancelAnimationFrame(raf)
  }, [roundKey, round])

  const boardHandlers = isPolice ? {
    onPointerDown: (e: React.PointerEvent) => pointerAim(e.clientX, e.clientY),
    onPointerMove: (e: React.PointerEvent) => {
      if (e.pointerType === 'mouse' && e.buttons === 0) return
      pointerAim(e.clientX, e.clientY)
    },
  } : {}

  const urgent = ms < 10_000

  return (
    <div className="imp-stage" style={{ paddingBottom: 165 }}>
      {isPolice && !outAsPolice && myLives <= 1 && <div className="imp-siren" />}

      <div className="imp-hud">
        <span className="imp-hud-chip">
          {isPolice ? <Crosshair size={13} /> : <Flame size={13} />}
          {isPolice ? 'Police' : 'Thief'} · R{state.round}
        </span>
        {isPolice && (
          <span className="imp-lives">
            {Array.from({ length: livesBase }).map((_, i) => (
              <span key={i} className={`imp-life ${i >= myLives ? 'gone' : ''}`} />
            ))}
          </span>
        )}
        <span className={`imp-clock ${urgent ? 'urgent' : ''}`}>{Math.max(0, secs)}</span>
      </div>

      <div className={`imp-board ${caught ? 'spectating' : ''}`} ref={boardRef} {...boardHandlers}>
        <div className="imp-torch" ref={torchRef} style={{ opacity: 0 }} />
        {state.cards.map(c => {
          const dead = c.s !== 'alive'
          return (
            <button
              key={c.i}
              data-idx={c.i}
              ref={el => { if (el) cardRefs.current.set(c.i, el); else cardRefs.current.delete(c.i) }}
              className={`imp-card ${dead ? `dead ${c.s}` : ''} ${me.card === c.i ? 'mine' : ''}`}
              onClick={() => { if (isPolice && !dead) lockOn(c.i) }}
              disabled={dead}
            >
              <span
                className="imp-face"
                ref={el => { if (el) faceRefs.current.set(c.i, el); else faceRefs.current.delete(c.i) }}
              >
                {c.e}
              </span>
              {lock === c.i && !dead && (
                <span className="imp-reticle" key={`lock-${c.i}`} aria-hidden="true">
                  <i /><i /><i /><i />
                </span>
              )}
            </button>
          )
        })}
      </div>

      {isPolice && outAsPolice ? (
        <div className="imp-breath-wrap">
          <div className="imp-lit-warning" style={{ color: '#ff8a99' }}>
            Out of lives
          </div>
          <button className="imp-hold dead" disabled>Dead · spectating</button>
        </div>
      ) : isPolice ? (
        <div className="imp-breath-wrap">
          <div className="imp-lit-warning">
            {lock === null
              ? 'Tap a mask to lock on'
              : state.solo
                ? 'Nothing breathing tonight — trust your gut'
                : 'Locked. Hold it and wait for the breath.'}
          </div>
          <button
            className="imp-hold"
            style={{
              background: lock === null
                ? 'linear-gradient(180deg,#3a4256,#2a3040)'
                : 'linear-gradient(180deg,#ff8a3d,#ff4d5e)',
              color: '#fff',
              opacity: lock === null || firing ? 0.55 : 1,
            }}
            disabled={lock === null || firing}
            onClick={fire}
          >
            Fire
          </button>
        </div>
      ) : (
        <div className="imp-breath-wrap">
          <div className="imp-lit-warning" style={caught ? { color: '#ff8a99' } : undefined}>
            {caught ? 'They got you' : litMe ? 'The light is on you' : ''}
          </div>
          {!caught && (
            <div className="imp-breath-track">
              <div ref={fillRef} className={`imp-breath-fill ${lowBreath ? 'low' : ''}`} style={{ width: '100%' }} />
            </div>
          )}
          {caught ? (
            <button className="imp-hold dead" disabled>
              Dead · spectating
            </button>
          ) : (
            <button
              className={`imp-hold ${holding ? 'held' : ''} ${litMe && !holding ? 'danger' : ''}`}
              onPointerDown={e => { e.preventDefault(); holdRef.current = true; setHolding(true) }}
              onPointerUp={() => { holdRef.current = false; setHolding(false) }}
              onPointerCancel={() => { holdRef.current = false; setHolding(false) }}
              onPointerLeave={() => { holdRef.current = false; setHolding(false) }}
            >
              {holding ? 'Holding…' : 'Hold breath'}
            </button>
          )}
        </div>
      )}

      {isPolice && !outAsPolice && (
        <div className={`imp-gun ${flash ? 'kick' : ''}`} key={`gun-${flash}`}>
          <div className="imp-gun-body" />
          <div className="imp-gun-slide" />
          {flash > 0 && <div className="imp-muzzle" key={flash} />}
        </div>
      )}

      {damage > 0 && <div className="imp-damage" key={damage} />}
      {callout && (
        <div
          className={`imp-callout ${callout.mine ? '' : 'taken'}`}
          key={callout.id}
          role="status"
        >
          <b>{callout.mine ? `You caught ${callout.name}` : `${callout.name} caught`}</b>
          <small>{callout.mine ? 'one down' : 'one less mask'}</small>
        </div>
      )}
      {shot > 0 && <div className="imp-blood" key={shot} />}
      {caught && <div className="imp-dead-stain" />}
    </div>
  )
}
