// src/features/impostor/useCountdown.ts
//
// Seconds remaining on the current phase, corrected for the difference
// between this device's clock and the server's. Phones with a badly set
// clock are common enough that an uncorrected countdown would show two
// players wildly different timers on the same round.
import { useEffect, useState } from 'react'
import { msLeft } from './impostor'

export function useCountdown(endsAt: string | null, skewMs: number): { ms: number; secs: number } {
  const [ms, setMs] = useState(() => msLeft(endsAt, skewMs))

  useEffect(() => {
    setMs(msLeft(endsAt, skewMs))
    if (!endsAt) return
    const t = setInterval(() => setMs(msLeft(endsAt, skewMs)), 200)
    return () => clearInterval(t)
  }, [endsAt, skewMs])

  return { ms, secs: Math.ceil(ms / 1000) }
}
