// src/features/leaderboards/GameLeaderboardPage.tsx
// Per-game leaderboard destination — reached by tapping a game bar on the
// Leaderboards hub. Hosts a compact personal-stats dashboard for this one
// game plus its ranked leaderboard (top 25, with the viewer pinned at the
// bottom if they rank outside it) and an All-time/Weekly/Daily toggle that
// swaps the same list in place rather than routing to another page.
import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { BarChart3, ChevronRight, Crown, Flame, Gamepad2, Medal, Trophy, Zap } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { supabase } from '../../shared/lib/supabase'
import { getGameById } from '../games/games'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import Avatar from '../../shared/components/Avatar'
import {
  fetchGlobalLeaderboard, fetchPersonalGameStats, PERIOD_LABELS,
  type LeaderboardEntry, type LeaderboardPeriod, type PersonalGameStats,
} from './leaderboardData'
import { updateMissionProgress } from '../missions/weeklyMissions'

const EMPTY_STATS: PersonalGameStats = {
  sessionsPlayed: 0,
  bestScore: 0,
  recentRank: 'unranked',
  currentStreak: 0,
  xpEarned: 0,
}

const PERIODS: LeaderboardPeriod[] = ['alltime', 'weekly', 'daily']

function formatDate(value: string) {
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(new Date(value))
}

const MEDALS = [
  { ring: 'linear-gradient(135deg, #ffe484, #d4af37 55%, #a97a1f)', glow: '#f5c542', label: '1st', icon: Crown },
  { ring: 'linear-gradient(135deg, #eef2f6, #b9c2cc 55%, #8b95a1)', glow: '#c7cdd4', label: '2nd', icon: Medal },
  { ring: 'linear-gradient(135deg, #e8a86c, #b9702f 55%, #7a4a1e)', glow: '#cd7f32', label: '3rd', icon: Medal },
] as const

const RANK_TIER_STYLE: Record<string, { bg: string; fg: string; label: string }> = {
  beginner: { bg: 'var(--surface2)', fg: 'var(--text-dim)', label: 'Beginner' },
  intermediate: { bg: '#3ecf8e1f', fg: '#3ecf8e', label: 'Intermediate' },
  advanced: { bg: '#a855f71f', fg: '#b083ff', label: 'Advanced' },
  master: { bg: '#f5c5421f', fg: '#f5c542', label: 'Master' },
  unranked: { bg: 'var(--surface2)', fg: 'var(--text-muted)', label: 'Unranked' },
}

function rankTierStyle(rank: string) {
  return RANK_TIER_STYLE[rank] ?? RANK_TIER_STYLE.unranked
}

function MiniStat({ label, value, icon }: { label: string; value: string | number; icon: React.ReactNode }) {
  return (
    <div style={{ background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 12, padding: '10px 12px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--text-dim)', fontSize: 9.5, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5 }}>
        {icon}
        {label}
      </div>
      <div style={{ marginTop: 5, color: 'var(--text)', fontSize: 16, fontWeight: 850 }}>{value}</div>
    </div>
  )
}

function LeaderboardRow({ entry, index, isYou, accent, pinned }: { entry: LeaderboardEntry; index: number; isYou: boolean; accent: string; pinned?: boolean }) {
  const tier = rankTierStyle(entry.rank)
  return (
    <div
      style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '10px 12px', borderRadius: 14,
        background: isYou ? `${accent}14` : 'var(--surface2)',
        border: isYou ? `1px solid ${accent}55` : '1px solid var(--border)',
        borderStyle: pinned ? 'dashed' : 'solid',
      }}
    >
      <div style={{ width: 26, textAlign: 'center', fontWeight: 800, fontSize: 13, color: 'var(--text-dim)', flexShrink: 0 }}>{index + 1}</div>
      <Avatar src={entry.avatar ?? undefined} name={entry.name} size={38} radius={12} ownerId={entry.userId} disabled />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontWeight: 750, fontSize: 13.5, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {entry.name}{isYou ? ' (you)' : ''}
          </span>
          <span style={{ background: tier.bg, color: tier.fg, fontSize: 9.5, fontWeight: 800, padding: '2px 7px', borderRadius: 999, textTransform: 'uppercase', letterSpacing: 0.3, flexShrink: 0 }}>{tier.label}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 3, color: 'var(--text-muted)', fontSize: 11 }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><Zap size={11} />{entry.xpEarned.toLocaleString()} XP</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><BarChart3 size={11} />{entry.sessionsPlayed} sessions</span>
          {entry.currentStreak > 0 && <span style={{ display: 'flex', alignItems: 'center', gap: 3, color: '#ff8a3c' }}><Flame size={11} />{entry.currentStreak}</span>}
          <span>{formatDate(entry.lastPlayedAt)}</span>
        </div>
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div style={{ fontWeight: 900, fontSize: 15, color: 'var(--text)' }}>{entry.bestScore.toLocaleString()}</div>
        <div style={{ fontSize: 9.5, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: 0.4 }}>best</div>
      </div>
    </div>
  )
}

export default function GameLeaderboardPage() {
  const { gameId } = useParams<{ gameId: string }>()
  const navigate = useNavigate()
  const { session } = useAuth()
  const userId = session?.user.id ?? ''

  const game = useMemo(() => (gameId ? getGameById(gameId) : undefined), [gameId])

  const [period, setPeriod] = useState<LeaderboardPeriod>('alltime')
  const [stats, setStats] = useState<PersonalGameStats>(EMPTY_STATS)
  const [leaders, setLeaders] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  usePageHeader({ title: game?.name ?? 'Leaderboard', onBack: () => navigate('/leaderboards') })

  // Redirect out if the gameId in the URL doesn't match a known game.
  useEffect(() => {
    if (gameId && !game) navigate('/leaderboards', { replace: true })
  }, [gameId, game, navigate])

  useEffect(() => {
    let active = true
    async function load() {
      if (!userId || !game) return
      setLoading(true)
      setError(null)
      try {
        const [personalStats, globalRows] = await Promise.all([
          fetchPersonalGameStats(userId, game.dbKey),
          fetchGlobalLeaderboard(game.dbKey, period),
        ])
        if (!active) return
        setStats(personalStats)
        setLeaders(globalRows)
      } catch (err) {
        if (!active) return
        console.error('game leaderboard load error:', err)
        setStats(EMPTY_STATS)
        setLeaders([])
        setError('Leaderboard data could not be loaded right now.')
      } finally {
        if (active) setLoading(false)
      }
    }
    load()
    return () => { active = false }
  }, [game, period, userId])

  // Fire once per game visited, not on every period toggle.
  useEffect(() => {
    if (!userId || !game) return
    updateMissionProgress(userId, 'leaderboard_views', 1).catch(console.error)
    supabase.rpc('check_all_leaderboard_ranks').then(({ error: rankErr }) => {
      if (rankErr) console.error('[GameLeaderboardPage] check_all_leaderboard_ranks failed:', rankErr)
    })
  }, [game, userId])

  if (!game) return null

  const GameIcon = game.icon
  const top25 = leaders.slice(0, 25)
  const viewerIndex = leaders.findIndex(entry => entry.userId === userId)
  const viewerInTop25 = viewerIndex > -1 && viewerIndex < 25
  const viewerPinned = viewerIndex >= 25 ? { entry: leaders[viewerIndex], rank: viewerIndex } : null

  const top3 = top25.slice(0, 3)
  const rest = top25.slice(3)
  const showPodium = top3.length === 3
  const podiumOrder = showPodium ? [top3[1], top3[0], top3[2]] : []
  const podiumRanks = showPodium ? [1, 0, 2] : []
  const listEntries = showPodium ? rest : top25

  return (
    <div className="flex flex-col max-w-[980px] mx-auto" style={{ gap: 16 }}>
      {/* Compact identity + Play strip */}
      <section className="neu-card" style={{ padding: 16, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 'auto -40px -60px auto', width: 180, height: 180, borderRadius: '50%', background: `radial-gradient(circle, ${game.accent}30 0%, transparent 68%)`, pointerEvents: 'none' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, position: 'relative' }}>
          <div style={{ width: 46, height: 46, borderRadius: 14, background: `${game.accent}18`, border: `1px solid ${game.accent}33`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <GameIcon size={22} style={{ color: game.accent }} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={{ color: 'var(--text)', fontSize: 17, fontWeight: 900, margin: 0 }}>{game.name}</h1>
            <p style={{ color: 'var(--text-dim)', fontSize: 11.5, margin: '2px 0 0' }}>Your stats, then how you stack up against everyone else.</p>
          </div>
          <button
            type="button"
            onClick={(e) => { ripple(e); navigate('/games') }}
            className="ripple-wrap"
            style={{ flexShrink: 0, padding: '9px 12px', borderRadius: 12, background: game.accent, border: 'none', color: '#06251a', fontWeight: 800, fontSize: 12, display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer' }}
          >
            <Gamepad2 size={14} /> Play
          </button>
        </div>
      </section>

      {/* Compact analytics dashboard */}
      <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <MiniStat label="Sessions" value={stats.sessionsPlayed} icon={<BarChart3 size={11} />} />
        <MiniStat label="Best score" value={stats.bestScore.toLocaleString()} icon={<Crown size={11} />} />
        <MiniStat label="Rank" value={rankTierStyle(stats.recentRank).label} icon={<Trophy size={11} />} />
        <MiniStat label="Streak" value={stats.currentStreak} icon={<Flame size={11} />} />
      </section>

      {/* Period toggle */}
      <section style={{ display: 'flex', gap: 6, background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 12, padding: 4 }}>
        {PERIODS.map(p => (
          <button
            key={p}
            type="button"
            onClick={(e) => { ripple(e); setPeriod(p) }}
            style={{
              flex: 1, padding: '8px 0', borderRadius: 9, border: 'none', cursor: 'pointer',
              fontSize: 12, fontWeight: 800,
              background: period === p ? game.accent : 'transparent',
              color: period === p ? '#06251a' : 'var(--text-dim)',
              transition: 'background 0.15s ease',
            }}
          >
            {PERIOD_LABELS[p]}
          </button>
        ))}
      </section>

      {/* Leaderboard */}
      <section className="neu-card" style={{ padding: 18, overflow: 'hidden', position: 'relative' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <div>
            <h2 style={{ color: 'var(--text)', fontSize: 15.5, fontWeight: 850, margin: 0 }}>Top 25 · {PERIOD_LABELS[period]}</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 11.5, margin: '2px 0 0' }}>Sorted by best score, then XP and sessions played.</p>
          </div>
          {loading && <span style={{ color: 'var(--text-dim)', fontSize: 12 }}>Loading…</span>}
        </div>

        {error && <div style={{ color: 'var(--accent2)', fontSize: 13, marginBottom: 12 }}>{error}</div>}

        {!loading && leaders.length === 0 && (
          <div style={{ padding: '32px 16px', color: 'var(--text-dim)', textAlign: 'center' }}>
            <Trophy size={26} style={{ opacity: 0.4, marginBottom: 8 }} />
            <div>{period === 'alltime' ? 'No completed sessions yet for this game.' : `No sessions in the last ${period === 'daily' ? '24 hours' : '7 days'}.`}</div>
          </div>
        )}

        {leaders.length > 0 && (
          <>
            {showPodium && (
              <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 10, marginBottom: 24, padding: '0 4px' }}>
                {podiumOrder.map((entry, i) => {
                  const rankIdx = podiumRanks[i]
                  const medal = MEDALS[rankIdx]
                  const MedalIcon = medal.icon
                  const isYou = entry.userId === userId
                  return (
                    <div key={entry.userId} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, maxWidth: 150 }}>
                      <div style={{ position: 'relative', marginBottom: rankIdx === 0 ? 10 : 6 }}>
                        <div style={{
                          position: 'relative', padding: 3, borderRadius: '50%',
                          background: medal.ring,
                          boxShadow: `0 4px 14px ${medal.glow}55`,
                        }}>
                          <Avatar src={entry.avatar ?? undefined} name={entry.name} size={rankIdx === 0 ? 58 : 46} radius={999} ownerId={entry.userId} disabled style={{ border: '2px solid var(--surface)' }} />
                        </div>
                        <div style={{
                          position: 'absolute', bottom: -6, left: '50%', transform: 'translateX(-50%)',
                          width: 22, height: 22, borderRadius: '50%', background: medal.ring,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          border: '2px solid var(--surface)', boxShadow: `0 2px 6px ${medal.glow}66`,
                        }}>
                          <MedalIcon size={11} color="#1a1208" strokeWidth={2.5} />
                        </div>
                      </div>
                      <div style={{ fontWeight: 800, fontSize: 12, color: 'var(--text)', textAlign: 'center', maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {entry.name}{isYou ? ' (you)' : ''}
                      </div>
                      <div style={{ fontSize: 14, fontWeight: 900, color: game.accent, marginTop: 2 }}>{entry.bestScore.toLocaleString()}</div>
                      <div style={{
                        marginTop: 10, width: '100%', height: rankIdx === 0 ? 48 : rankIdx === 1 ? 32 : 20,
                        borderRadius: '10px 10px 0 0',
                        background: `linear-gradient(180deg, ${medal.glow}30, ${medal.glow}10)`,
                        border: `1px solid ${medal.glow}44`, borderBottom: 'none',
                        display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: 4,
                        color: medal.glow, fontWeight: 900, fontSize: 10.5,
                      }}>
                        {medal.label}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {listEntries.map((entry, i) => {
                const index = showPodium ? i + 3 : i
                return (
                  <LeaderboardRow key={entry.userId} entry={entry} index={index} isYou={entry.userId === userId} accent={game.accent} />
                )
              })}
            </div>

            {!viewerInTop25 && viewerPinned && (
              <>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '14px 0 10px', color: 'var(--text-dim)', fontSize: 10.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                  <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
                  Your rank
                  <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
                </div>
                <LeaderboardRow entry={viewerPinned.entry} index={viewerPinned.rank} isYou accent={game.accent} pinned />
              </>
            )}

            {!viewerInTop25 && !viewerPinned && viewerIndex === -1 && stats.sessionsPlayed === 0 && (
              <div style={{ marginTop: 14, textAlign: 'center', color: 'var(--text-dim)', fontSize: 12 }}>
                You haven't played {game.name} {period === 'alltime' ? 'yet' : `in the last ${period === 'daily' ? '24 hours' : '7 days'}`} — play a round to get ranked.
              </div>
            )}
          </>
        )}
      </section>

      <button
        type="button"
        onClick={(e) => { ripple(e); navigate('/leaderboards') }}
        className="neu-card ripple-wrap"
        style={{ padding: '12px 14px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, color: 'var(--text-dim)', fontSize: 12.5, fontWeight: 700, border: 'none', cursor: 'pointer' }}
      >
        Back to all leaderboards <ChevronRight size={14} />
      </button>
    </div>
  )
}
