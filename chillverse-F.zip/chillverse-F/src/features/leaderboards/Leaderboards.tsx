// src/features/leaderboards/Leaderboards.tsx
// Leaderboards hub — every game grouped by genre and shown as a horizontal
// bar. Tapping one navigates to /leaderboards/:gameId, which hosts that
// game's compact stats dashboard + its own leaderboard (see
// GameLeaderboardPage.tsx). Replaces the old single-game dropdown view.
import { useNavigate } from 'react-router-dom'
import { ChevronRight, Gamepad2, Trophy } from 'lucide-react'
import { getGamesByGenre } from '../games/games'
import { ripple } from '../../shared/lib/ripple'

export default function Leaderboards() {
  const navigate = useNavigate()
  const genreGroups = getGamesByGenre()

  return (
    <div className="flex flex-col max-w-[980px] mx-auto" style={{ gap: 18 }}>
      <section className="neu-card" style={{ padding: 22, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 'auto -50px -70px auto', width: 220, height: 220, borderRadius: '50%', background: 'radial-gradient(circle, #f5c54233 0%, transparent 68%)', pointerEvents: 'none' }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 18, alignItems: 'center', flexWrap: 'wrap' }}>
          <div>
            <div style={{ color: '#f5c542', fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Trophy size={13} /> Read-only rankings
            </div>
            <h1 style={{ color: 'var(--text)', fontSize: 26, fontWeight: 900, margin: '8px 0 6px' }}>Leaderboards</h1>
            <p style={{ color: 'var(--text-dim)', maxWidth: 560, fontSize: 12.5, lineHeight: 1.5 }}>
              Pick a game to see your stats and where you rank against everyone else.
            </p>
          </div>
          <button
            type="button"
            onClick={(e) => { ripple(e); navigate('/games') }}
            className="neu-card ripple-wrap"
            style={{ padding: '12px 14px', display: 'inline-flex', alignItems: 'center', gap: 10, color: 'var(--text)', background: 'transparent', border: 'none', cursor: 'pointer' }}
          >
            <Gamepad2 size={18} style={{ color: '#f5c542' }} /> Play games <ChevronRight size={16} />
          </button>
        </div>
      </section>

      {genreGroups.map(group => (
        <section key={group.category}>
          <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', margin: '0 0 10px', paddingLeft: 2 }}>{group.category}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {group.games.map(game => {
              const Icon = game.icon
              return (
                <div
                  key={game.id}
                  className="neu-card ripple-wrap"
                  onClick={(e) => { ripple(e); navigate(`/leaderboards/${game.id}`) }}
                  style={{
                    padding: '12px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                  }}
                >
                  <div style={{ width: 40, height: 40, borderRadius: 12, background: `${game.accent}18`, border: `1px solid ${game.accent}33`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon size={18} style={{ color: game.accent }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 13.5, fontWeight: 750, color: 'var(--text)', margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{game.name}</p>
                    <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{game.tagline}</p>
                  </div>
                  <ChevronRight size={16} style={{ color: 'var(--text-dim)', flexShrink: 0 }} />
                </div>
              )
            })}
          </div>
        </section>
      ))}
    </div>
  )
}
