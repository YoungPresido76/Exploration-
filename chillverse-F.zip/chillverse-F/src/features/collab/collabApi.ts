// src/features/collab/collabApi.ts
//
// The Lab → Collab wing's data layer. A collab is a Chillverse × <partner>
// drop: a name, one piece of key art, a status, a public like counter, and
// a set of mall_items tagged to it (mall_items.collab_id — see migration
// 0124).
//
// Reads go through get_collabs(), which returns the like total, whether
// the caller is among the likers, and the tagged-item count in one round
// trip, so the list screen never fans out a query per row.
import { supabase } from '../../shared/lib/supabase'
import type { MallItem } from '../../shared/types'

export type CollabStatus = 'active' | 'ended'

/** Falls back to this anywhere tint_color comes back empty (older rows,
 *  or a network hiccup) — matches the purple the whole wing shipped with,
 *  so an unset collab looks the way every collab used to look. */
export const DEFAULT_COLLAB_TINT = '#9b6dff'

export interface Collab {
  id: string
  name: string
  image_url: string | null
  status: CollabStatus
  likes_count: number
  liked_by_me: boolean
  item_count: number
  created_at: string
  /** Admin-set hex colour driving this collab's particles/accent tint. */
  tint_color: string
}

/** Admin view — includes drafts, which get_collabs() hides from players. */
export interface AdminCollab {
  id: string
  name: string
  image_url: string | null
  status: CollabStatus
  is_published: boolean
  likes_count: number
  sort_order: number
  item_count: number
  created_at: string
  tint_color: string
}

/** "Chillverse × Fable 5" — the one place this string is built, so the
 *  Collab page, the Mall item sheet and the admin preview can't drift. */
export function collabTitle(name: string): string {
  return `Chillverse × ${name}`
}

export async function fetchCollabs(): Promise<{ data: Collab[]; error: string | null }> {
  const { data, error } = await supabase.rpc('get_collabs')
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as Collab[], error: null }
}

/** Returns the authoritative post-toggle count so an optimistic UI can
 *  reconcile against a real number rather than its own guess. */
export async function toggleCollabLike(
  collabId: string,
): Promise<{ likesCount: number | null; liked: boolean | null; error: string | null }> {
  const { data, error } = await supabase.rpc('toggle_collab_like', { p_collab_id: collabId })
  if (error) return { likesCount: null, liked: null, error: error.message }
  const row = Array.isArray(data) ? data[0] : data
  return { likesCount: row?.likes_count ?? null, liked: row?.liked ?? null, error: null }
}

/** Every active item tagged to a collab. Same shape the Mall renders, so
 *  the collab screen can reuse the Mall's own item sheet. */
export async function fetchCollabItems(
  collabId: string,
): Promise<{ data: MallItem[]; error: string | null }> {
  const { data, error } = await supabase
    .from('mall_items')
    .select('*')
    .eq('collab_id', collabId)
    .eq('is_active', true)
    .order('rarity', { ascending: true })
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as MallItem[], error: null }
}

// ── Admin ──────────────────────────────────────────────────────────────

/** Strips the CV_ADMIN_* prefix the RPCs raise so the dashboard can show
 *  the message itself rather than a Postgres error string. */
function friendlyCollabError(message: string): string {
  const cleaned = message.replace(/^CV_ADMIN_(VALIDATION|FORBIDDEN):\s*/, '')
  if (/duplicate key value|collabs_name_lower_key/i.test(cleaned)) {
    return 'A collab with that name already exists.'
  }
  return cleaned || 'Something went wrong.'
}

export async function fetchAdminCollabs(): Promise<{ data: AdminCollab[]; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_list_collabs')
  if (error) return { data: [], error: friendlyCollabError(error.message) }
  return { data: (data ?? []) as AdminCollab[], error: null }
}

const COLLAB_IMAGES_BUCKET = 'collab-images'
const MAX_COLLAB_IMAGE_BYTES = 5 * 1024 * 1024

function extensionForImageFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

/** Uploads collab key art to the public `collab-images` bucket and returns
 *  its URL. Doesn't save anything — pass the URL to saveCollab. */
export async function uploadCollabImage(file: File): Promise<{ url: string | null; error: string | null }> {
  if (!file.type.startsWith('image/')) return { url: null, error: 'Please pick an image file.' }
  if (file.size > MAX_COLLAB_IMAGE_BYTES) return { url: null, error: 'Image is too large — please use a file under 5MB.' }

  const path = `${crypto.randomUUID()}.${extensionForImageFile(file)}`
  const { error } = await supabase.storage
    .from(COLLAB_IMAGES_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (error) return { url: null, error: `Failed to upload image: ${error.message}` }

  const { data } = supabase.storage.from(COLLAB_IMAGES_BUCKET).getPublicUrl(path)
  return { url: data.publicUrl, error: null }
}

/** Creates when `id` is null, updates that row otherwise. Publishing
 *  requires artwork — the server rejects a published collab with no key
 *  art, since it would render as an empty frame for players. */
export async function saveCollab(input: {
  id: string | null
  name: string
  imageUrl: string | null
  status: CollabStatus
  isPublished: boolean
  /** Hex colour for this collab's particles/accent. Omit or pass null on
   *  an update to leave the current colour untouched; a new collab with
   *  no colour picked falls back to DEFAULT_COLLAB_TINT server-side. */
  tintColor?: string | null
}): Promise<{ id: string | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_save_collab', {
    p_id: input.id,
    p_name: input.name,
    p_image_url: input.imageUrl,
    p_status: input.status,
    p_is_published: input.isPublished,
    p_tint_color: input.tintColor ?? null,
  })
  if (error) return { id: null, error: friendlyCollabError(error.message) }
  return { id: (data as string | null) ?? null, error: null }
}

export async function deleteCollab(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.rpc('admin_delete_collab', { p_id: id })
  if (error) return { error: friendlyCollabError(error.message) }
  return { error: null }
}

/** Tags an existing Mall item to a collab **by typed name**. The server
 *  resolves it case-insensitively against published collabs and refuses
 *  anything else, so a typo or a draft name fails loudly here rather than
 *  silently storing a tag players can't see. Pass null to clear the tag. */
export async function setItemCollab(
  itemId: string,
  collabName: string | null,
): Promise<{ collabId: string | null; collabName: string | null; error: string | null }> {
  const { data, error } = await supabase.rpc('admin_set_item_collab', {
    p_item_id: itemId,
    p_collab_name: collabName,
  })
  if (error) return { collabId: null, collabName: null, error: friendlyCollabError(error.message) }
  const row = Array.isArray(data) ? data[0] : data
  return { collabId: row?.collab_id ?? null, collabName: row?.collab_name ?? null, error: null }
}

/** Every item in the catalog, active or not, for the admin tagging list.
 *  Includes collab_id so the current tag shows without a second query. */
export async function fetchTaggableItems(): Promise<{ data: MallItem[]; error: string | null }> {
  const { data, error } = await supabase
    .from('mall_items')
    .select('*')
    .order('name', { ascending: true })
  if (error) return { data: [], error: error.message }
  return { data: (data ?? []) as MallItem[], error: null }
}
