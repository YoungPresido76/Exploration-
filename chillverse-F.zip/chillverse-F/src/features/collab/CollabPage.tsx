// src/features/collab/CollabPage.tsx
//
// /lab/collab — the collab list. Each row is a name plus its live status;
// tapping one expands it in place to reveal the key art, the
// "Chillverse × <name>" title beside it, the like button, and the Mall
// items tagged to that collab underneath.
//
// Expanding in place rather than pushing a detail route is deliberate:
// the whole point of the screen is to browse several drops, and an
// accordion keeps you where you were when you close one.
//
// Live likes work on two channels at once:
//   • the toggle RPC returns the authoritative count, so YOUR tap is
//     exact rather than optimistic-and-hoping;
//   • a Realtime subscription on public.collabs pushes everyone else's
//     taps in, so the number moves while you sit on the page.
// The count is the public total and always includes your own like — so a
// collab you just liked with nobody else on it reads "1", not "0".
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Flag, Heart, ChevronDown, Package, RefreshCw } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import Seo from '../../shared/components/Seo'
import Sparks from './Sparks'
import FeatureFlagGate from '../../shared/components/FeatureFlagGate'
import { fetchCollabs, fetchCollabItems, toggleCollabLike, collabTitle, type Collab } from './collabApi'
import type { MallItem, MallRarity } from '../../shared/types'

const RARITY_TINT: Record<MallRarity, string> = {
  Common: '#888899',
  Rare: '#4f8ef7',
  Epic: '#9b6dff',
  Mythic: '#f5c542',
}

function StatusPill({ status }: { status: Collab['status'] }) {
  const active = status === 'active'
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 5,
        padding: '3px 9px', borderRadius: 20, flexShrink: 0,
        fontSize: 9.5, fontWeight: 900, letterSpacing: 0.5, textTransform: 'uppercase',
        background: active ? 'rgba(62,207,142,0.10)' : 'var(--surface2)',
        border: `1px solid ${active ? 'rgba(62,207,142,0.28)' : 'var(--border)'}`,
        color: active ? '#3ecf8e' : 'var(--text-muted)',
      }}
    >
      <span
        style={{
          width: 5, height: 5, borderRadius: '50%',
          background: active ? '#3ecf8e' : 'var(--text-muted)',
          animation: active ? 'live-pulse 1.8s ease-in-out infinite' : undefined,
        }}
      />
      {active ? 'Active' : 'Ended'}
    </span>
  )
}

/** Read-only tile. Tapping hands off to the Mall's own item sheet via
 *  /mall?item=<id> rather than reimplementing the purchase flow here —
 *  one buy path, one set of lock/expiry/affordability rules.
 *
 *  Sized and styled to match the Mall's own COMPACT SquareCard (the
 *  4-across profile-pic grid): 7px padding, 13px radius, 10px thumb
 *  radius, 10.5px single-line name, price on its own row, no rarity
 *  badge. A collab's items should read as the same kind of object they
 *  are everywhere else in the app rather than as a second, chunkier
 *  card style. */
function CollabItemTile({ item, onOpen }: { item: MallItem; onOpen: () => void }) {
  const tint = RARITY_TINT[item.rarity] ?? RARITY_TINT.Common
  const art = item.image_url ?? item.animated_url
  const isMythic = item.rarity === 'Mythic'

  return (
    <button
      type="button"
      onClick={(e) => { ripple(e); onOpen() }}
      className="ripple-wrap"
      style={{
        display: 'block', padding: 7, textAlign: 'left', minWidth: 0, cursor: 'pointer',
        background: 'var(--surface)',
        border: isMythic
          ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)'
          : '1px solid rgba(255,255,255,0.05)',
        borderRadius: 13,
        boxShadow: isMythic
          ? '0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent),4px 4px 10px var(--neu-dark)'
          : '4px 4px 10px var(--neu-dark),-2px -2px 8px var(--neu-light)',
      }}
    >
      <span style={{
        position: 'relative', display: 'block', width: '100%', aspectRatio: '1 / 1',
        borderRadius: 10, marginBottom: 6, overflow: 'hidden', background: 'var(--surface2)',
      }}>
        {art
          ? <img src={art} alt="" loading="lazy" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
          : <span style={{ position: 'absolute', inset: 0, background: `linear-gradient(135deg, ${tint}22, transparent)` }} />}
      </span>
      <span style={{
        display: 'block', fontSize: 10.5, fontWeight: 700, color: 'var(--text)',
        lineHeight: 1.25, marginBottom: 3,
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>{item.name}</span>
      {item.price_gems != null && (
        <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 10, fontWeight: 700, color: 'var(--text)' }}>
          💎 {item.price_gems.toLocaleString()}
        </span>
      )}
    </button>
  )
}

function CollabRow({
  collab, expanded, onToggle, onLike, liking,
}: {
  collab: Collab
  expanded: boolean
  onToggle: () => void
  onLike: () => void
  liking: boolean
}) {
  const navigate = useNavigate()
  const [items, setItems] = useState<MallItem[] | null>(null)
  const [itemsError, setItemsError] = useState<string | null>(null)

  // Items load on first expand, not on mount: a page with eight collabs
  // shouldn't fire eight catalog queries for rows nobody opened. Cached
  // in row state afterwards, so re-opening is instant.
  useEffect(() => {
    if (!expanded || items !== null) return
    let alive = true
    fetchCollabItems(collab.id).then(({ data, error }) => {
      if (!alive) return
      setItems(data)
      setItemsError(error)
    })
    return () => { alive = false }
  }, [expanded, items, collab.id])

  return (
    <div
      className={expanded ? 'collab-row collab-row-open' : 'collab-row'}
      style={{ ['--place-tint' as string]: collab.tint_color || '#9b6dff' }}
    >
      <button
        type="button"
        onClick={(e) => { ripple(e); onToggle() }}
        aria-expanded={expanded}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 11,
          padding: '14px 14px', background: 'none', border: 'none',
          cursor: 'pointer', textAlign: 'left', minWidth: 0,
        }}
      >
        <span style={{
          width: 34, height: 34, borderRadius: 11, flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'color-mix(in srgb, var(--place-tint) 14%, transparent)',
          color: 'var(--place-tint)',
        }}>
          <Flag size={15} />
        </span>

        <span style={{ flex: 1, minWidth: 0 }}>
          <span style={{
            display: 'block', fontSize: 14, fontWeight: 800, color: 'var(--text)',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>{collab.name}</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 3 }}>
            <StatusPill status={collab.status} />
            <span style={{ fontSize: 10.5, color: 'var(--text-muted)', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 3 }}>
              <Package size={10} /> {collab.item_count} {collab.item_count === 1 ? 'item' : 'items'}
            </span>
          </span>
        </span>

        <ChevronDown
          size={16}
          aria-hidden="true"
          style={{
            flexShrink: 0, color: 'var(--text-muted)',
            transform: expanded ? 'rotate(180deg)' : 'none',
            transition: 'transform 0.22s ease',
          }}
        />
      </button>

      {expanded && (
        <div style={{ padding: '0 14px 16px' }}>
          {/* Key art + title + like, side by side on anything wider than a
              small phone and stacked below it — the art has to stay big
              enough to be worth looking at. */}
          <div className="collab-art-row">
            <div className="collab-art">
              {/* Boosted vs. the header's ambient field (count + intensity
                  both up) — opening a collab is the "someone's looking at
                  this" moment, so the shine inside its own card should
                  visibly read as brighter than the passive list state. */}
              <Sparks count={16} spread="full" intensity={1.6} />
              {collab.image_url
                ? <img src={collab.image_url} alt={collabTitle(collab.name)} loading="lazy" />
                : <div className="collab-art-empty">No artwork yet</div>}
            </div>

            <div className="collab-art-meta">
              <div style={{ fontSize: 10, fontWeight: 900, letterSpacing: 1, textTransform: 'uppercase', color: 'var(--place-tint)' }}>
                Collab
              </div>
              <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)', lineHeight: 1.35, margin: '4px 0 10px' }}>
                {collabTitle(collab.name)}
              </div>

              <button
                type="button"
                onClick={(e) => { ripple(e); onLike() }}
                disabled={liking}
                aria-pressed={collab.liked_by_me}
                aria-label={collab.liked_by_me ? 'Unlike this collab' : 'Like this collab'}
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 7,
                  padding: '8px 13px', borderRadius: 22, cursor: liking ? 'default' : 'pointer',
                  background: collab.liked_by_me ? 'rgba(255,77,139,0.12)' : 'var(--surface2)',
                  border: `1px solid ${collab.liked_by_me ? 'rgba(255,77,139,0.35)' : 'var(--border)'}`,
                  color: collab.liked_by_me ? '#ff4d8b' : 'var(--text-dim)',
                  fontSize: 12.5, fontWeight: 800,
                  transition: 'background 0.16s ease, border-color 0.16s ease, color 0.16s ease',
                }}
              >
                <Heart
                  size={14}
                  style={{
                    fill: collab.liked_by_me ? '#ff4d8b' : 'none',
                    transition: 'transform 0.18s ease',
                    transform: collab.liked_by_me ? 'scale(1.12)' : 'none',
                  }}
                />
                {collab.likes_count.toLocaleString()}
              </button>
            </div>
          </div>

          {/* Items tagged to this collab */}
          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 900, letterSpacing: 0.6, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 9 }}>
              From this collab
            </div>

            {items === null ? (
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading items…</div>
            ) : itemsError ? (
              <div style={{ fontSize: 12, color: 'var(--red)' }}>{itemsError}</div>
            ) : items.length === 0 ? (
              <div style={{
                padding: 14, borderRadius: 12, background: 'var(--surface2)',
                border: '1px solid var(--border)', fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.6,
              }}>
                Nothing from this collab is in the Mall yet.
              </div>
            ) : (
              <div className="collab-item-grid">
                {items.map(item => (
                  <CollabItemTile
                    key={item.id}
                    item={item}
                    onOpen={() => navigate(`/mall?item=${item.id}`)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default function CollabPage() {
  return (
    <FeatureFlagGate flagKey="system:lab">
      <CollabPageInner />
    </FeatureFlagGate>
  )
}

function CollabPageInner() {
  const navigate = useNavigate()
  // Preserves the original fixed back destination (/lab), not generic
  // browser-back.
  usePageHeader({ title: 'Collab', onBack: () => navigate('/lab') })
  const [collabs, setCollabs] = useState<Collab[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [openId, setOpenId] = useState<string | null>(null)
  const [likingId, setLikingId] = useState<string | null>(null)

  // Guards the Realtime handler from clobbering the count the toggle RPC
  // just returned: our own UPDATE echoes back, and if it arrived while a
  // second tap was mid-flight it could overwrite a newer local value.
  const inFlight = useRef<Set<string>>(new Set())

  const load = useCallback(async () => {
    setLoading(true)
    const { data, error: err } = await fetchCollabs()
    setCollabs(data)
    setError(err)
    setLoading(false)
  }, [])

  useEffect(() => { load() }, [load])

  // Live counts. public.collabs is in the supabase_realtime publication
  // with replica identity full (migration 0124), so the payload carries
  // likes_count directly — no refetch per event.
  useEffect(() => {
    const channel = supabase
      .channel('collab-likes-live')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'collabs' },
        (payload) => {
          const row = payload.new as { id?: string; likes_count?: number; status?: string } | null
          if (!row?.id || typeof row.likes_count !== 'number') return
          if (inFlight.current.has(row.id)) return
          setCollabs(prev => prev.map(c => (
            c.id === row.id
              ? { ...c, likes_count: row.likes_count as number, status: (row.status as Collab['status']) ?? c.status }
              : c
          )))
        },
      )
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [])

  const handleLike = useCallback(async (collab: Collab) => {
    if (likingId) return
    setLikingId(collab.id)
    inFlight.current.add(collab.id)

    // Optimistic: the heart fills and the number moves on the tap, then
    // reconciles against the server's own total a moment later.
    const optimisticLiked = !collab.liked_by_me
    setCollabs(prev => prev.map(c => (
      c.id === collab.id
        ? { ...c, liked_by_me: optimisticLiked, likes_count: Math.max(0, c.likes_count + (optimisticLiked ? 1 : -1)) }
        : c
    )))

    const { likesCount, liked, error: err } = await toggleCollabLike(collab.id)

    setCollabs(prev => prev.map(c => {
      if (c.id !== collab.id) return c
      if (err || likesCount == null) {
        // Roll the optimistic change back — a failed like that keeps
        // showing as liked is worse than one that visibly didn't take.
        return { ...c, liked_by_me: collab.liked_by_me, likes_count: collab.likes_count }
      }
      return { ...c, likes_count: likesCount, liked_by_me: liked ?? optimisticLiked }
    }))

    inFlight.current.delete(collab.id)
    setLikingId(null)
  }, [likingId])

  const empty = !loading && !error && collabs.length === 0
  const activeCount = useMemo(() => collabs.filter(c => c.status === 'active').length, [collabs])

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', paddingBottom: 56 }}>
      <Seo
        title="Collab"
        description="Chillverse collabs — every drop we've made with the worlds we team up with."
        path="/lab/collab"
        noindex
      />

      {/* Header carries the ambient spark field too, so the wing feels
          continuous with the card you tapped to get here. */}
      <div className="collab-header">
        {/* Page-level field: mostly a downward current, with a thin
            trickle rising back up so it doesn't read as one-directional
            rain — see the 'mostly-down' comment in Sparks.tsx. */}
        <Sparks count={14} spread="full" direction="mostly-down" />
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 12 }}>
          <p style={{ flex: 1, minWidth: 0, fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>
            {loading
              ? 'Loading the drops…'
              : `${collabs.length} ${collabs.length === 1 ? 'collab' : 'collabs'}${activeCount ? ` · ${activeCount} running now` : ''}`}
          </p>
          <button
            type="button"
            onClick={(e) => { ripple(e); load() }}
            disabled={loading}
            aria-label="Refresh"
            style={{
              width: 34, height: 34, borderRadius: 11, flexShrink: 0,
              background: 'var(--surface)', border: '1px solid var(--border)',
              color: 'var(--text-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.5 : 1,
            }}
          >
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      <div style={{ padding: '0 20px', display: 'grid', gap: 12 }}>
        {error && (
          <div style={{ padding: 14, borderRadius: 14, background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--red)', fontSize: 12.5 }}>
            {error}
          </div>
        )}

        {loading && collabs.length === 0 && (
          <div style={{ padding: 20, borderRadius: 14, background: 'var(--surface)', border: '1px solid var(--border)', textAlign: 'center', color: 'var(--text-dim)', fontSize: 12.5 }}>
            Loading collabs…
          </div>
        )}

        {empty && (
          <div style={{ padding: '26px 18px', borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--border)', textAlign: 'center' }}>
            <div style={{
              width: 44, height: 44, borderRadius: 14, margin: '0 auto 12px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'rgba(155,109,255,0.12)', color: '#9b6dff',
            }}>
              <Flag size={19} />
            </div>
            <div style={{ fontSize: 14.5, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>No collabs yet</div>
            <div style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.6 }}>
              When Chillverse teams up with someone, the drop shows up here.
            </div>
          </div>
        )}

        {collabs.map(collab => (
          <CollabRow
            key={collab.id}
            collab={collab}
            expanded={openId === collab.id}
            onToggle={() => setOpenId(id => (id === collab.id ? null : collab.id))}
            onLike={() => handleLike(collab)}
            liking={likingId === collab.id}
          />
        ))}
      </div>
    </div>
  )
}
