// src/features/collab/Lab.tsx
//
// The Lab — reached from the Social tab's second story (BottomDock). A hub
// of "places", each one its own wing. Only Collab exists so far, so the
// grid is deliberately built as a list of PLACES rather than hardcoded
// around one card: adding the next place is one entry, not a layout
// rewrite.
//
// The card carries the ambient spark treatment (.collab-sparks in
// index.css) — CSS-only, transform/opacity only, so it composites on the
// GPU and costs nothing on a mid-range phone. It's suppressed entirely
// under prefers-reduced-motion.
import { useNavigate } from 'react-router-dom'
import type { LucideIcon } from 'lucide-react'
import { Flag, ChevronRight } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import Seo from '../../shared/components/Seo'
import FeatureFlagGate from '../../shared/components/FeatureFlagGate'
import Sparks from './Sparks'

interface Place {
  id: string
  label: string
  blurb: string
  to: string
  icon: LucideIcon
  /** Accent the card's glow and icon are tinted with. */
  tint: string
  /** Ambient sparks + gradient frame. Reserved for the flagship place. */
  glorious?: boolean
}

const PLACES: Place[] = [
  {
    id: 'collab',
    label: 'Collab',
    blurb: 'Chillverse × the worlds we team up with',
    to: '/lab/collab',
    icon: Flag,
    tint: '#9b6dff',
    glorious: true,
  },
]

function PlaceCard({ place, onOpen }: { place: Place; onOpen: () => void }) {
  const Icon = place.icon

  return (
    <button
      type="button"
      onClick={(e) => { ripple(e); onOpen() }}
      className={place.glorious ? 'collab-place collab-place-glorious' : 'collab-place'}
      style={{
        // Both the frame gradient and the inner glow read this, so a new
        // place only needs its tint set above.
        ['--place-tint' as string]: place.tint,
      }}
    >
      {place.glorious && <Sparks count={12} />}

      <span className="collab-place-inner">
        <span className="collab-place-icon" aria-hidden="true">
          <Icon size={20} />
        </span>
        <span className="collab-place-text">
          <span className="collab-place-label">{place.label}</span>
          <span className="collab-place-blurb">{place.blurb}</span>
        </span>
        <ChevronRight size={16} className="collab-place-chev" aria-hidden="true" />
      </span>
    </button>
  )
}

export default function Lab() {
  return (
    <FeatureFlagGate flagKey="system:lab">
      <LabInner />
    </FeatureFlagGate>
  )
}

function LabInner() {
  const navigate = useNavigate()
  // Preserves the original fixed back destination (/feed), not generic
  // browser-back.
  usePageHeader({ title: 'Lab', onBack: () => navigate('/feed') })

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', paddingBottom: 56 }}>
      <Seo
        title="The Lab"
        description="Chillverse collabs, experiments and drops."
        path="/lab"
        noindex
      />

      <div style={{ padding: '4px 20px 0', marginBottom: 18 }}>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>
          Where things get built before they get everywhere
        </p>
      </div>

      <div style={{ padding: '0 20px', display: 'grid', gap: 14 }}>
        {PLACES.map(place => (
          <PlaceCard key={place.id} place={place} onOpen={() => navigate(place.to)} />
        ))}
      </div>
    </div>
  )
}
