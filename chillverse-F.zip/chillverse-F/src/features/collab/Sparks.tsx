// src/features/collab/Sparks.tsx
//
// The little shiny dots that glow in from the sides and float up. Purely
// decorative, so: aria-hidden, pointer-events none, and animated with
// transform/opacity only — those two are the only properties a browser can
// composite without re-laying out or repainting the page, which is what
// keeps a dozen of these free on a mid-range phone.
//
// Positions are computed once (useMemo, seeded off the count) rather than
// per render, so a parent re-render — a like landing, a list expanding —
// never makes the field jump. Motion is suppressed wholesale by the
// prefers-reduced-motion rule on .collab-sparks in index.css.
import { useMemo } from 'react'

interface SparksProps {
  /** Kept low on purpose — 12 is plenty for the effect and cheap enough
   *  to run on two cards at once. */
  count?: number
  /** Dots rise from the bottom edge of both side gutters by default;
   *  'full' spreads them across the whole width for header treatments. */
  spread?: 'sides' | 'full'
  /** 'up' (default): every dot rises from the bottom, as before.
   *  'down': every dot falls from the top.
   *  'mostly-down': falling stars with just a thin trickle rising back up
   *  from the bottom — used on the collab page header so the field reads
   *  as one coherent current rather than dots going both ways evenly. */
  direction?: 'up' | 'down' | 'mostly-down'
  /** Multiplies peak opacity and glow — the "someone's looking at this"
   *  boost applied while a collab card is expanded, so the shine visibly
   *  brightens on view instead of running at the same strength always. */
  intensity?: number
}

interface Spark {
  left: number
  size: number
  delay: number
  duration: number
  drift: number
  rise: number
  opacity: number
  falling: boolean
}

/** Deterministic pseudo-random so the layout is stable across renders and
 *  across a remount, without pulling in a seeded-RNG dependency. */
function hash(n: number): number {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453
  return x - Math.floor(x)
}

function buildSparks(count: number, spread: 'sides' | 'full', direction: 'up' | 'down' | 'mostly-down'): Spark[] {
  return Array.from({ length: count }, (_, i) => {
    const r1 = hash(i + 1)
    const r2 = hash(i + 41)
    const r3 = hash(i + 97)
    const r4 = hash(i + 173)
    const r5 = hash(i + 211)

    // 'sides': keep the middle clear so the dots frame the content
    // instead of drifting across the label text.
    const left = spread === 'full'
      ? 3 + r1 * 94
      : (i % 2 === 0 ? 1 + r1 * 22 : 77 + r1 * 22)

    // 'mostly-down' is a current, not a coin flip: ~85% of dots fall,
    // the rest rise as a thin counter-glint — reads as one direction of
    // travel with a little life against it, not two even streams.
    const falling = direction === 'down'
      ? true
      : direction === 'up'
        ? false
        : r5 > 0.15

    return {
      left,
      size: 2 + r2 * 2.6,
      delay: r3 * 6,
      duration: 5.5 + r4 * 4.5,
      drift: (r2 - 0.5) * 26,
      rise: 58 + r3 * 42,
      opacity: 0.45 + r4 * 0.5,
      falling,
    }
  })
}

export default function Sparks({ count = 12, spread = 'sides', direction = 'up', intensity = 1 }: SparksProps) {
  const sparks = useMemo(() => buildSparks(count, spread, direction), [count, spread, direction])

  return (
    <span className="collab-sparks" aria-hidden="true">
      {sparks.map((s, i) => (
        <i
          key={i}
          className={s.falling ? 'collab-spark collab-spark-down' : 'collab-spark'}
          style={{
            left: `${s.left}%`,
            width: s.size * (intensity > 1 ? 1 + (intensity - 1) * 0.35 : 1),
            height: s.size * (intensity > 1 ? 1 + (intensity - 1) * 0.35 : 1),
            animationDelay: `${s.delay}s`,
            animationDuration: `${s.duration}s`,
            ['--spark-drift' as string]: `${s.drift}px`,
            ['--spark-rise' as string]: `${s.rise}px`,
            ['--spark-peak' as string]: `${Math.min(1, s.opacity * intensity)}`,
          }}
        />
      ))}
    </span>
  )
}
