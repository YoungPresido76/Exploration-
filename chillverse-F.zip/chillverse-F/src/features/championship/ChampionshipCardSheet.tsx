// src/features/championship/ChampionshipCardSheet.tsx
//
// Card detail bottom sheet — opens on tap from the pool grid or an
// equipped slot, mirrors Mall's ItemModal chrome (backdrop, drag-to-dismiss,
// rounded sheet) via the same useSheetDrag/useRealViewportHeight hooks, but
// with Championship content: big art, tier, standardized stats, and an
// Equip/Remove action in place of a Buy button.
//
// Selection state lives one level up in LoadoutBuilder — this sheet only
// calls onToggle, it never mutates the loadout array itself. Once the
// loadout is locked, onToggle is simply not passed at all rather than
// passed-but-guarded, so there is no code path here that can look like a
// working button and silently no-op.
import { useEffect } from 'react'
import { X, Lock, Swords, Shield as ShieldIcon } from 'lucide-react'
import { useRealViewportHeight, useSheetDrag } from '../../shared/hooks/useBottomSheet'
import { ripple } from '../../shared/lib/ripple'
import type { ChampionshipCard } from './championship'

const SHEET_HEIGHT_VH = 72

function cooldownLabel(card: ChampionshipCard): string | null {
  if (card.cooldown_minutes) {
    const hours = card.cooldown_minutes / 60
    return `${hours % 1 === 0 ? hours : hours.toFixed(1)}h cooldown`
  }
  if (card.max_uses_per_match) return '1 use per match'
  return null
}

function effectLabel(card: ChampionshipCard): string | null {
  switch (card.effect_type) {
    case 'burn': return 'Deals its damage as a burn on impact.'
    case 'petrify': return 'Briefly stuns the target on a hit.'
    case 'corrupt': return 'Corrupts the target, weakening their next stretch.'
    case 'lifesteal': return `Heals you for ${card.effect_magnitude}% of the damage dealt.`
    case 'heal': return `Restores ${card.effect_magnitude} HP, capped at 500.`
    case 'shield': return `Reduces your next incoming hit by ${card.effect_magnitude}%.`
    case 'shield_break': return 'Strips the opponent\u2019s active Shield outright.'
    case 'cooldown_reset': return 'Instantly resets one of your battle cards\u2019 cooldown.'
    default: return null
  }
}

export default function ChampionshipCardSheet({
  card, isSelected, isLocked, canAddMore, onClose, onToggle,
}: {
  card: ChampionshipCard
  isSelected: boolean
  isLocked: boolean
  /** Only relevant when !isSelected — whether there's a free slot to add into. */
  canAddMore: boolean
  onClose: () => void
  onToggle: () => void
}) {
  const realVh = useRealViewportHeight()
  const sheetHeightPx = Math.round(realVh * (SHEET_HEIGHT_VH / 100))
  const { dragY, dragging, dragHandleProps, sheetProps } = useSheetDrag(onClose)

  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  const effect = effectLabel(card)
  const cooldown = cooldownLabel(card)

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{
        position: 'fixed', inset: 0, zIndex: 800, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      <div {...sheetProps} style={{
        background: 'var(--surface)', borderRadius: '20px 20px 0 0', width: '100%', maxWidth: 460,
        border: '1px solid var(--border)', borderBottom: 'none', boxShadow: '0 -12px 40px -12px rgba(0,0,0,0.5)',
        position: 'relative', height: sheetHeightPx, maxHeight: sheetHeightPx, overflowY: 'auto', overscrollBehavior: 'contain',
        display: 'flex', flexDirection: 'column',
        transform: `translateY(${dragY}px)`,
        transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.16,1,0.3,1)',
        animation: dragging ? undefined : 'slideUp 0.28s cubic-bezier(0.16,1,0.3,1) both',
      }}>
        <div
          {...dragHandleProps}
          style={{ ...dragHandleProps.style, padding: '10px 0 8px', margin: '0 auto', flexShrink: 0, display: 'flex', justifyContent: 'center', width: '100%' }}
        >
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        <div style={{
          margin: '0 20px', borderRadius: 16, height: 200, flexShrink: 0, position: 'relative', overflow: 'hidden',
          background: card.image_url
            ? `linear-gradient(180deg, rgba(15,9,26,0.05) 0%, rgba(15,9,26,0.75) 100%), url(${card.image_url}) center/cover`
            : 'linear-gradient(160deg, #241934, #0d0818)',
        }}>
          <button onClick={(e) => { ripple(e); onClose() }} className="ripple-wrap" style={{
            position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: '50%', border: 'none',
            background: 'rgba(0,0,0,0.45)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
          }}>
            <X size={15} />
          </button>
          <div style={{ position: 'absolute', left: 14, bottom: 12 }}>
            <span style={{
              fontSize: 9.5, fontWeight: 700, padding: '3px 9px', borderRadius: 20,
              background: card.source_catalog_name ? 'rgba(79,142,247,0.22)' : 'rgba(245,197,66,0.24)',
              color: card.source_catalog_name ? '#7fb0ff' : '#ffd88a',
            }}>
              {card.source_catalog_name ? (card.tier === 'tactical' ? 'Tactical' : 'Core') : 'Championship exclusive'}
            </span>
          </div>
        </div>

        <div style={{ padding: '16px 20px 24px' }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text)' }}>{card.display_name}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>
            {card.source_catalog_name ? `Based on ${card.source_catalog_name}, with Championship-standardized stats.` : 'Built exclusively for the Championship.'}
          </div>

          <div className="neu-card" style={{ display: 'flex', marginTop: 16, padding: 4 }}>
            <div style={{ flex: 1, textAlign: 'center', padding: '10px 6px' }}>
              <Swords size={14} color="var(--text-muted)" style={{ marginBottom: 4 }} />
              <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)' }}>{card.damage > 0 ? card.damage : '\u2014'}</div>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', marginTop: 2 }}>Damage</div>
            </div>
            <div style={{ flex: 1, textAlign: 'center', padding: '10px 6px', borderLeft: '1px solid var(--border)' }}>
              <ShieldIcon size={14} color="var(--text-muted)" style={{ marginBottom: 4 }} />
              <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)' }}>{cooldown ?? '\u2014'}</div>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', marginTop: 2 }}>Pacing</div>
            </div>
          </div>

          {effect && (
            <div className="neu-card" style={{ marginTop: 10, padding: '11px 13px', fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
              {effect}
            </div>
          )}

          {isLocked ? (
            <div style={{
              marginTop: 18, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              borderRadius: 12, padding: 14, fontSize: 13.5, fontWeight: 800, background: 'var(--surface2)', color: 'var(--text-muted)',
            }}>
              <Lock size={14} /> Locked for the current round
            </div>
          ) : (
            <button
              onClick={(e) => { ripple(e); if (isSelected || canAddMore) onToggle() }}
              disabled={!isSelected && !canAddMore}
              className="ripple-wrap"
              style={{
                marginTop: 18, width: '100%', border: 'none', borderRadius: 12, padding: 14, fontSize: 13.5, fontWeight: 800,
                position: 'relative', overflow: 'hidden', cursor: !isSelected && !canAddMore ? 'default' : 'pointer',
                background: isSelected ? 'var(--surface2)' : !canAddMore ? 'var(--surface2)' : 'linear-gradient(135deg,#f5c542,#ff9a3c)',
                color: isSelected ? 'var(--danger, #ff4d6d)' : !canAddMore ? 'var(--text-muted)' : '#241934',
              }}
            >
              {isSelected ? 'Remove from loadout' : canAddMore ? 'Equip this card' : 'No free slots left'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
