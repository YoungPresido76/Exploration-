// src/features/championship/ChampionshipSpectateSheet.tsx
//
// /championship/spectate/:matchId — live-updating view for anyone watching
// a Semifinal/Final match, not just its two participants. Genuinely
// separate from ChampionshipMatchSheet.tsx, not that screen with buttons
// hidden: no action buttons exist here at all, there's no "your card"
// concept, and its whole lifecycle is read-only. Live data comes from
// useSpectateMatch, which reuses the reconnect-with-backoff pattern this
// codebase already built for useRoom.ts rather than a naive subscription.
import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Swords, Radio, Crown, ShieldCheck, Hourglass } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { useSpectateMatch } from './useSpectateMatch'
import { useChampionshipFxChannel } from './useChampionshipFxChannel'
import ChampionshipEffectOverlay, { type ChampionshipFxEvent } from './ChampionshipEffectOverlay'
import './championship-arena.css'
import {
  getCurrentSeason, getProfilesByIds,
  type ChampionshipSeason, type ChampionshipProfileLite,
} from './championship'

const DEFAULT_LIVE_HP = 750

function formatDuration(ms: number): string {
  const h = Math.floor(ms / 3_600_000)
  const m = Math.floor((ms % 3_600_000) / 60_000)
  const s = Math.floor((ms % 60_000) / 1000)
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

export default function ChampionshipSpectateSheet() {
  const navigate = useNavigate()
  const { matchId } = useParams<{ matchId: string }>()
  const { match, log, loading, error } = useSpectateMatch(matchId ?? null)

  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [profiles, setProfiles] = useState<Map<string, ChampionshipProfileLite>>(new Map())
  const [now, setNow] = useState(() => Date.now())
  const [fxEvent, setFxEvent] = useState<ChampionshipFxEvent | null>(null)
  const fxSeq = useRef(0)

  // Spectating only ever exists for Semifinal/Final matches (guarded
  // below), so this channel is always relevant here — no round-tier
  // gate needed the way ChampionshipMatchSheet has one.
  useChampionshipFxChannel(matchId ?? null, (msg) => {
    const attackerIsA = msg.attackerId === match?.player_a
    const attackerId = attackerIsA ? match?.player_a : match?.player_b
    const attackerProfile = attackerId ? profiles.get(attackerId) : null
    fxSeq.current += 1
    setFxEvent({
      id: `spectate-${fxSeq.current}`,
      animationKeys: msg.animationKeys,
      damage: msg.damage,
      incoming: true,
      attackerName: attackerProfile?.display_name || attackerProfile?.username || 'A fighter',
      selfBuff: msg.selfBuff,
      healed: msg.healed,
    })
  })

  usePageHeader({ title: 'Spectate', onBack: () => navigate('/championship/bracket') })

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const s = await getCurrentSeason()
      if (!cancelled) setSeason(s)
    })()
    return () => { cancelled = true }
  }, [])

  useEffect(() => {
    if (!match) return
    let cancelled = false
    ;(async () => {
      const ids = [match.player_a, match.player_b].filter((v): v is string => !!v)
      const p = await getProfilesByIds(ids)
      if (!cancelled) setProfiles(p)
    })()
    return () => { cancelled = true }
  }, [match?.player_a, match?.player_b])

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(id)
  }, [])

  const isLiveRound = useMemo(() => {
    if (!match || !season?.round_count) return true
    return match.round_number >= season.round_count - 1
  }, [match, season])

  const maxHp = useMemo(() => {
    if (isLiveRound) return season?.ruleset.live_round_hp ?? DEFAULT_LIVE_HP
    return season?.ruleset.match_hp ?? 500
  }, [isLiveRound, season])

  if (loading) {
    return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>
  }
  if (error) {
    return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>{error}</div>
  }
  if (!match) {
    return (
      <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center' }}>
        <Swords size={24} color="var(--text-muted)" style={{ marginBottom: 8 }} />
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>This match isn't available to spectate.</div>
      </div>
    )
  }
  if (!isLiveRound) {
    return (
      <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center' }}>
        <Swords size={24} color="var(--text-muted)" style={{ marginBottom: 8 }} />
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>Live spectating is only open for the Semifinal and Final.</div>
      </div>
    )
  }

  const aProfile = match.player_a ? profiles.get(match.player_a) : null
  const bProfile = match.player_b ? profiles.get(match.player_b) : null
  const aName = aProfile?.display_name || aProfile?.username || 'Player A'
  const bName = bProfile?.display_name || bProfile?.username || 'Player B'
  const isLive = match.status === 'active'
  const isDone = match.status === 'completed'
  const msLeft = match.round_ends_at ? Math.max(0, new Date(match.round_ends_at).getTime() - now) : 0
  const winnerName = match.winner_id
    ? (match.winner_id === match.player_a ? aName : bName)
    : null
  const effects = match.status_effects as Record<string, unknown> | null
  const aShielded = !!effects?.shield_a
  const bShielded = !!effects?.shield_b
  // Read-only for spectators — no claim button, since only a participant
  // can call championshipClaimDefaultWin. Shown mainly for context (why one
  // side isn't attacking); in practice a live round's 2h window almost
  // always closes the match before this 7h clock ever matters here.
  const turnName = match.turn === 'a' ? aName : match.turn === 'b' ? bName : null
  const turnMsLeft = match.turn_deadline_at ? Math.max(0, new Date(match.turn_deadline_at).getTime() - now) : null

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 16px 48px' }}>
      {isLive && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, margin: '10px 0 4px' }}>
          <Radio size={12} color="var(--danger, #ff4d6d)" />
          <span style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--danger, #ff4d6d)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            Live
          </span>
        </div>
      )}

      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, padding: '10px 0 4px' }}>
        <SpectateFighter name={aName} avatar={aProfile?.avatar ?? null} hp={match.hp_a} maxHp={maxHp} color="var(--accent)" align="left" shielded={aShielded} active={isLive && match.turn === 'a'} />
        <div style={{ textAlign: 'center', flexShrink: 0, paddingTop: 18 }}>
          <div style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--text-muted)' }}>VS</div>
          {isLive && <div style={{ fontSize: 9.5, color: 'var(--gold)', marginTop: 2, fontWeight: 700 }}>{formatDuration(msLeft)}</div>}
        </div>
        <SpectateFighter name={bName} avatar={bProfile?.avatar ?? null} hp={match.hp_b} maxHp={maxHp} color="var(--danger, #ff4d6d)" align="right" shielded={bShielded} active={isLive && match.turn === 'b'} />
      </div>

      <div className="cv-turn-banner" style={{ marginTop: 6 }}>
        <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Attacks used</span>
        <b style={{ fontSize: 11, color: 'var(--text)' }}>{aName}: {match.attacks_used_a} · {bName}: {match.attacks_used_b}</b>
      </div>

      {isLive && turnName && (
        <div className="cv-turn-banner" style={{ marginTop: 6 }}>
          <span style={{ fontSize: 11, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Hourglass size={12} color="var(--text-muted)" /> Waiting on <b style={{ color: 'var(--text)' }}>{turnName}</b>
          </span>
          <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 700 }}>{turnMsLeft !== null ? `${formatDuration(turnMsLeft)} left` : ''}</span>
        </div>
      )}

      {isDone && (
        <div className="neu-card" style={{ padding: 16, textAlign: 'center', marginTop: 12 }}>
          {winnerName ? (
            <div className="cv-disc cv-disc--active" style={{ width: 56, height: 56, margin: '0 auto 8px' }}>
              <Crown size={22} color="var(--gold)" />
            </div>
          ) : (
            <Crown size={20} color="var(--text-muted)" style={{ marginBottom: 6 }} />
          )}
          <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)' }}>
            {winnerName ? `${winnerName} takes it` : 'Double no-show — both eliminated'}
          </div>
        </div>
      )}

      <div className="neu-card" style={{ marginTop: 16, padding: '11px 13px' }}>
        <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 7 }}>
          Battle log
        </div>
        {log.length === 0 && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>No attacks yet.</div>}
        {log.slice(0, 12).map(l => {
          const attackerIsA = l.attacker_id === match.player_a
          const attackerName = attackerIsA ? aName : bName
          return (
            <div key={l.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, padding: '4px 0', borderTop: '1px solid var(--border)' }}>
              <span style={{ color: 'var(--text-secondary)' }}>
                {attackerName} used {l.card_key.replace(/_/g, ' ')}{l.is_combo ? ' (combo)' : ''}
              </span>
              {l.damage > 0 && <b style={{ color: attackerIsA ? 'var(--gold)' : 'var(--danger, #ff4d6d)' }}>-{l.damage}</b>}
            </div>
          )
        })}
      </div>

      <ChampionshipEffectOverlay event={fxEvent} onDone={() => setFxEvent(null)} />
    </div>
  )
}

function SpectateFighter({ name, avatar, hp, maxHp, color, align, shielded, active }: { name: string; avatar?: string | null; hp: number; maxHp: number; color: string; align: 'left' | 'right'; shielded?: boolean; active?: boolean }) {
  const pct = maxHp > 0 ? Math.max(0, Math.min(100, (hp / maxHp) * 100)) : 0
  const mine = align === 'left'
  const initial = name.trim().charAt(0).toUpperCase() || '?'
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: mine ? 'row' : 'row-reverse', alignItems: 'center', gap: 8 }}>
      <div
        className={`cv-disc ${active ? 'cv-disc--active' : 'cv-disc--waiting'}`}
        style={avatar ? { backgroundImage: `url(${avatar})`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined}
      >
        {!avatar && <span style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)' }}>{initial}</span>}
      </div>
      <div style={{ flex: 1, textAlign: align }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, justifyContent: align === 'left' ? 'flex-start' : 'flex-end', flexWrap: 'wrap' }}>
          <div style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text)' }}>{name}</div>
          {shielded && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 3, padding: '2px 6px', borderRadius: 20,
              fontSize: 8.5, fontWeight: 800, color: 'var(--gold)', background: 'color-mix(in srgb, var(--gold) 16%, transparent)',
              border: '1px solid color-mix(in srgb, var(--gold) 35%, transparent)',
            }}>
              <ShieldCheck size={9} /> Shielded
            </span>
          )}
        </div>
        <div style={{ height: 8, borderRadius: 4, background: 'var(--surface2)', border: '1px solid var(--border)', overflow: 'hidden', marginTop: 6 }}>
          <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 4, marginLeft: align === 'left' ? 0 : 'auto', transition: 'width 0.4s ease' }} />
        </div>
        <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 3, fontWeight: 700 }}>{hp} / {maxHp}</div>
      </div>
    </div>
  )
}
