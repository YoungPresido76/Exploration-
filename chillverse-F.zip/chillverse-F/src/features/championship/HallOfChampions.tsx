// src/features/championship/HallOfChampions.tsx
//
// /championship/hall-of-champions — permanent record of every completed
// season (reachable any time via the Championship hub's tab strip, not
// gated on whether a season is currently running). The most recent season
// leads as a full podium moment; every prior season is a compact row.
//
// Runner-up/3rd place are derived from match data (see getSeasonPlacements)
// rather than stored directly, so a season can legitimately have either
// slot come back empty — e.g. Season 1's field was so sparse it resolved
// entirely by byes, with no real Final ever played. That's rendered as an
// explicit "Unclaimed" slot, not hidden — it's an accurate record of what
// happened, not a bug.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Trophy } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { getSeasonPlacements, getProfilesByIds, type SeasonPlacements, type ChampionshipProfileLite } from './championship'
import { championshipBadgeSrc } from '../badges/ChampionshipBadge'

function placementName(userId: string | null, profiles: Map<string, ChampionshipProfileLite>): string {
  if (!userId) return 'Unclaimed'
  const p = profiles.get(userId)
  return p?.display_name || p?.username || 'Unknown'
}

function PodiumAvatar({ userId, profiles, size, crestSrc, ringColor }: {
  userId: string | null
  profiles: Map<string, ChampionshipProfileLite>
  size: number
  crestSrc: string | null
  ringColor: string
}) {
  const profile = userId ? profiles.get(userId) : null
  const initial = (profile?.display_name || profile?.username || '?').charAt(0).toUpperCase()

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, width: size + 20 }}>
      <div
        style={{
          width: size, height: size, borderRadius: '50%', flexShrink: 0,
          border: `2px solid ${userId ? ringColor : 'var(--surface2)'}`,
          background: profile?.avatar ? `url(${profile.avatar})` : 'var(--surface2)',
          backgroundSize: 'cover', backgroundPosition: 'center',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          opacity: userId ? 1 : 0.5,
        }}
      >
        {!profile?.avatar && (
          <span style={{ fontSize: size * 0.36, fontWeight: 800, color: userId ? 'var(--text)' : 'var(--text-muted)' }}>
            {userId ? initial : '—'}
          </span>
        )}
      </div>
      {crestSrc && <img src={crestSrc} alt="" width={size * 0.62} style={{ display: 'block', objectFit: 'contain', opacity: userId ? 1 : 0.35 }} />}
      <div style={{ fontSize: 11, fontWeight: 700, color: userId ? 'var(--text)' : 'var(--text-muted)', textAlign: 'center', lineHeight: 1.2, maxWidth: size + 30 }}>
        {placementName(userId, profiles)}
      </div>
    </div>
  )
}

export default function HallOfChampions() {
  const navigate = useNavigate()
  const [entries, setEntries] = useState<SeasonPlacements[]>([])
  const [profiles, setProfiles] = useState<Map<string, ChampionshipProfileLite>>(new Map())
  const [loading, setLoading] = useState(true)

  usePageHeader({ title: 'Hall of Champions', onBack: () => navigate('/championship') })

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const rows = await getSeasonPlacements()
        if (cancelled) return
        const ids = rows.flatMap(r => [r.champion_user_id, r.runner_up_user_id, r.third_place_user_id]).filter((id): id is string => !!id)
        const p = await getProfilesByIds(ids)
        if (cancelled) return
        setEntries(rows); setProfiles(p)
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => { cancelled = true }
  }, [])

  if (loading) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>

  if (entries.length === 0) {
    return (
      <div className="neu-card" style={{ margin: 16, padding: 28, textAlign: 'center' }}>
        <Trophy size={26} color="var(--text-muted)" style={{ marginBottom: 8 }} />
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>No champion crowned yet — be the first.</div>
      </div>
    )
  }

  const [latest, ...rest] = entries
  const championSrc = championshipBadgeSrc('championship_champion')
  const runnerUpSrc = championshipBadgeSrc('championship_runnerup')
  const thirdSrc = championshipBadgeSrc('championship_third_place')

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 16px 48px' }}>
      <div style={{
        marginTop: 12, padding: '28px 14px 22px', textAlign: 'center', position: 'relative', overflow: 'hidden', borderRadius: 20,
        background: 'linear-gradient(160deg, #241934, #0d0818)',
      }}>
        <div style={{
          position: 'absolute', top: -60, left: '50%', transform: 'translateX(-50%)', width: 220, height: 220, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(245,197,66,0.32) 0%, transparent 70%)',
        }} />
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--gold)', marginBottom: 16 }}>
            {latest.series_name} · Season {latest.season_number}
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 6 }}>
            <PodiumAvatar userId={latest.runner_up_user_id} profiles={profiles} size={56} crestSrc={runnerUpSrc} ringColor="#c7cad1" />
            <PodiumAvatar userId={latest.champion_user_id} profiles={profiles} size={76} crestSrc={championSrc} ringColor="#f5c542" />
            <PodiumAvatar userId={latest.third_place_user_id} profiles={profiles} size={56} crestSrc={thirdSrc} ringColor="#c8804f" />
          </div>
        </div>
      </div>

      {rest.length > 0 && (
        <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {rest.map(entry => (
            <div key={entry.season_id} className="neu-card" style={{ padding: '12px 14px' }}>
              <div style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8 }}>
                {entry.series_name} · Season {entry.season_number}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <PodiumAvatar userId={entry.champion_user_id} profiles={profiles} size={40} crestSrc={championSrc} ringColor="#f5c542" />
                <PodiumAvatar userId={entry.runner_up_user_id} profiles={profiles} size={36} crestSrc={runnerUpSrc} ringColor="#c7cad1" />
                <PodiumAvatar userId={entry.third_place_user_id} profiles={profiles} size={36} crestSrc={thirdSrc} ringColor="#c8804f" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
