// src/features/championship/ChampionshipHub.tsx
//
// Entry point for /championship — the Overview tab. Shows whichever state
// the current season is actually in (no season scheduled / registration
// open / tournament live / season completed) rather than assuming
// registration is always the active phase.
//
// The tab strip here is the mobile port of the reference dashboard's
// left-nav destinations (Overview / Bracket / My match / Rules / Hall of
// champions) — see the blueprint. Only Overview is wired so far; the rest
// route through as each screen gets built.
import { useEffect, useMemo, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Trophy, Swords, BookOpen, Crown, Users } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { useAuth } from '../auth/useAuth'
import { ripple } from '../../shared/lib/ripple'
import Toast, { useToast } from '../../shared/components/Toast'
import {
  getCurrentSeason, getRegistrationCount, isRegistered, registerForChampionship,
  championshipErrorMessage, type ChampionshipSeason,
} from './championship'

type TabKey = 'overview' | 'bracket' | 'my-match' | 'rules' | 'hall-of-champions'

const TABS: { key: TabKey; label: string; path: string }[] = [
  { key: 'overview', label: 'Overview', path: '/championship' },
  { key: 'bracket', label: 'Bracket', path: '/championship/bracket' },
  { key: 'my-match', label: 'My match', path: '/championship/my-match' },
  { key: 'rules', label: 'Rules', path: '/championship/rules' },
  { key: 'hall-of-champions', label: 'Hall of champions', path: '/championship/hall-of-champions' },
]

/** Days/hours/minutes remaining until `iso`, floored at zero. */
function useCountdown(iso: string | null) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    if (!iso) return
    const id = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(id)
  }, [iso])

  return useMemo(() => {
    if (!iso) return null
    const remainingMs = Math.max(0, new Date(iso).getTime() - now)
    const days = Math.floor(remainingMs / 86_400_000)
    const hours = Math.floor((remainingMs % 86_400_000) / 3_600_000)
    const minutes = Math.floor((remainingMs % 3_600_000) / 60_000)
    return { days, hours, minutes, expired: remainingMs <= 0 }
  }, [iso, now])
}

export default function ChampionshipHub() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast, showToast } = useToast()

  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [regCount, setRegCount] = useState(0)
  const [registered, setRegistered] = useState(false)
  const [loading, setLoading] = useState(true)
  const [registering, setRegistering] = useState(false)

  usePageHeader({ title: 'Championship', onBack: () => navigate('/dashboard') })

  const load = useCallback(async () => {
    try {
      const s = await getCurrentSeason()
      setSeason(s)
      if (s) {
        const [count, mine] = await Promise.all([
          getRegistrationCount(s.id),
          user ? isRegistered(s.id, user.id) : Promise.resolve(false),
        ])
        setRegCount(count)
        setRegistered(mine)
      }
    } catch {
      showToast({ message: 'Couldn’t load the Championship. Pull to refresh.', icon: Trophy })
    } finally {
      setLoading(false)
    }
  }, [user, showToast])

  useEffect(() => { load() }, [load])

  const countdown = useCountdown(season?.status === 'registration' ? season.registration_ends_at : null)

  async function handleRegister() {
    if (!season || registering) return
    setRegistering(true)
    try {
      await registerForChampionship(season.id)
      setRegistered(true)
      setRegCount(c => c + 1)
      showToast({ message: 'You’re in. Good luck out there.', icon: Trophy, iconColor: 'var(--gold)' })
    } catch (err) {
      showToast({ message: championshipErrorMessage(err), icon: Trophy })
    } finally {
      setRegistering(false)
    }
  }

  const eclipseCardStyle: React.CSSProperties = {
    borderRadius: 20, padding: '24px 18px', textAlign: 'center', position: 'relative', overflow: 'hidden',
    background: 'linear-gradient(150deg, #241934 0%, #180f2b 55%, #0d0818 100%)',
    boxShadow: '0 14px 34px -10px rgba(20,8,40,0.6)',
  }

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', paddingBottom: 48 }}>
      {/* Tab strip — mobile port of the reference's left-nav destinations */}
      <div style={{ display: 'flex', gap: 6, overflowX: 'auto', padding: '2px 2px 16px', WebkitOverflowScrolling: 'touch' }}>
        {TABS.map(tab => {
          const active = tab.key === 'overview'
          return (
            <button
              key={tab.key}
              onClick={(e) => { ripple(e); navigate(tab.path) }}
              className="ripple-wrap"
              style={{
                flexShrink: 0, fontSize: 12.5, fontWeight: 700, padding: '8px 14px', borderRadius: 20,
                border: 'none', whiteSpace: 'nowrap', position: 'relative', overflow: 'hidden',
                background: active ? 'linear-gradient(135deg, var(--accent), var(--brand-violet-soft))' : 'var(--surface2)',
                color: active ? '#fff' : 'var(--text-secondary)',
              }}
            >
              {tab.label}
            </button>
          )
        })}
      </div>

      {loading && (
        <div className="neu-card" style={{ padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>
          Loading Championship…
        </div>
      )}

      {!loading && !season && (
        <div className="neu-card" style={{ padding: '28px 20px', textAlign: 'center' }}>
          <Trophy size={28} color="var(--text-muted)" style={{ marginBottom: 10 }} />
          <div style={{ fontWeight: 800, fontSize: 15, color: 'var(--text)' }}>No Championship scheduled</div>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 4 }}>
            Check back soon — a new season opens twice a month.
          </div>
        </div>
      )}

      {!loading && season?.status === 'registration' && (
        <div style={{
          borderRadius: 20, position: 'relative', overflow: 'hidden', minHeight: 460,
          boxShadow: '0 14px 34px -10px rgba(20,8,40,0.6)',
          backgroundImage: 'url(https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/event-images/e2a08967-976b-4abe-8e0f-df87ffbf5a18/file_00000000bd788243b3ca978811b7faad.png)',
          backgroundSize: 'cover', backgroundPosition: 'top center',
          display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
        }}>
          {/* The key art already carries the full lockup (logo, title,
              "Registration open now", tagline) — no need to duplicate any
              of that in code. This overlay only carries the parts that are
              actually dynamic: countdown, live registered count, the button. */}
          <div style={{
            position: 'relative', zIndex: 1, padding: '18px 18px 20px',
            background: 'linear-gradient(180deg, transparent 0%, rgba(13,8,24,0.55) 35%, rgba(13,8,24,0.94) 100%)',
          }}>
            {countdown && !countdown.expired && (
              <div style={{ display: 'flex', justifyContent: 'center', gap: 8, margin: '0 0 4px' }}>
                {[['day', countdown.days], ['hr', countdown.hours], ['min', countdown.minutes]].map(([lbl, val]) => (
                  <div key={lbl as string} style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(245,197,66,0.3)', borderRadius: 11, padding: '9px 12px', minWidth: 50 }}>
                    <div style={{ fontSize: 17, fontWeight: 800, color: '#fbf6ff' }}>{val}</div>
                    <div style={{ fontSize: 9, color: '#9d8cc4', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{lbl}</div>
                  </div>
                ))}
              </div>
            )}

            <div style={{ fontSize: 11.5, color: '#c9bce6', marginTop: 10, textAlign: 'center' }}>
              {regCount} registered · bracket locks when the window closes
            </div>

            <button
              onClick={(e) => { ripple(e); registered ? navigate('/championship/loadout') : handleRegister() }}
              disabled={registering}
              className="ripple-wrap"
              style={{
                marginTop: 14, width: '100%', border: 'none', borderRadius: 11, padding: 13, fontSize: 13.5, fontWeight: 800,
                position: 'relative', overflow: 'hidden', cursor: registering ? 'default' : 'pointer',
                background: registered ? 'rgba(255,255,255,0.1)' : 'linear-gradient(135deg,#f5c542,#ff9a3c)',
                color: registered ? '#fbf6ff' : '#241934',
              }}
            >
              {registering ? 'Registering…' : registered ? 'You’re registered — build your loadout' : 'Register now'}
            </button>
          </div>
        </div>
      )}

      {!loading && season?.status === 'active' && (
        <div style={eclipseCardStyle}>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <Swords size={26} color="var(--gold)" style={{ marginBottom: 6 }} />
            <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 6 }}>
              Tournament live · Round {season.current_round} of {season.round_count}
            </div>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#fbf6ff' }}>
              CHILLVERSE CHAMPIONSHIP
              <span style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#b79bff', letterSpacing: '0.08em', marginTop: 4 }}>
                {'— ' + season.series_name.toUpperCase()}
              </span>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
              <button onClick={(e) => { ripple(e); navigate('/championship/my-match') }} className="ripple-wrap"
                style={{ flex: 1, border: 'none', borderRadius: 11, padding: 12, fontSize: 12.5, fontWeight: 800, position: 'relative', overflow: 'hidden',
                  background: 'linear-gradient(135deg,#f5c542,#ff9a3c)', color: '#241934' }}>
                My match
              </button>
              <button onClick={(e) => { ripple(e); navigate('/championship/loadout') }} className="ripple-wrap"
                style={{ flex: 1, border: '1px solid rgba(245,197,66,0.3)', borderRadius: 11, padding: 12, fontSize: 12.5, fontWeight: 800, position: 'relative', overflow: 'hidden',
                  background: 'rgba(255,255,255,0.06)', color: '#fbf6ff' }}>
                Loadout
              </button>
              <button onClick={(e) => { ripple(e); navigate('/championship/bracket') }} className="ripple-wrap"
                style={{ flex: 1, border: '1px solid rgba(245,197,66,0.3)', borderRadius: 11, padding: 12, fontSize: 12.5, fontWeight: 800, position: 'relative', overflow: 'hidden',
                  background: 'rgba(255,255,255,0.06)', color: '#fbf6ff' }}>
                Bracket
              </button>
            </div>
          </div>
        </div>
      )}

      {!loading && season?.status === 'completed' && (
        <div className="neu-card" style={{ padding: '24px 18px', textAlign: 'center' }}>
          <Crown size={28} color="var(--gold)" style={{ marginBottom: 8 }} />
          <div style={{ fontWeight: 800, fontSize: 15, color: 'var(--text)' }}>{season.series_name} — Season {season.season_number} is complete</div>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 4 }}>The next season opens soon.</div>
          <button onClick={(e) => { ripple(e); navigate('/championship/hall-of-champions') }} className="neu-card ripple-wrap"
            style={{ marginTop: 14, border: 'none', borderRadius: 11, padding: '10px 18px', fontSize: 12.5, fontWeight: 700, color: 'var(--accent)', cursor: 'pointer', position: 'relative', overflow: 'hidden' }}>
            View Hall of Champions
          </button>
        </div>
      )}

      {!loading && season && (
        <div className="neu-card" style={{ display: 'flex', padding: 4, marginTop: 12 }}>
          {[
            { icon: Users, num: regCount, label: 'Registered' },
            { icon: Swords, num: season.bracket_size ?? '—', label: 'Bracket size' },
            { icon: BookOpen, num: season.round_count ?? '—', label: 'Rounds' },
          ].map(({ icon: Icon, num, label }) => (
            <div key={label} style={{ flex: 1, textAlign: 'center', padding: '10px 8px' }}>
              <Icon size={14} color="var(--text-muted)" style={{ marginBottom: 4 }} />
              <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)' }}>{num}</div>
              <div style={{ fontSize: 9.5, color: 'var(--text-muted)', marginTop: 2 }}>{label}</div>
            </div>
          ))}
        </div>
      )}

      <Toast toast={toast} />
    </div>
  )
}
