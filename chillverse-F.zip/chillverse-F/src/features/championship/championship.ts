// src/features/championship/championship.ts
//
// Types and API wrappers for the Chillverse Championship — the biweekly
// single-elimination PvP tournament. Every shape here mirrors an RPC
// defined in the championship_* migrations. If you change a `returns
// jsonb` shape in SQL, change the matching interface here — Postgres
// will not warn you, the field will just arrive as undefined at runtime.
//
// Combat is isolated from live PvP: match HP, cooldowns, and card stats
// are all Championship-standardized (card level grants zero edge — see
// championship_card_pool). The client never computes damage; every
// figure comes back from the server.
import { supabase } from '../../shared/lib/supabase'

// ── Vocabulary (mirrors the SQL check constraints) ──────────────────────

export type ChampionshipSeasonStatus = 'registration' | 'group_stage' | 'active' | 'completed' | 'cancelled'
export type ChampionshipMatchStatus = 'pending' | 'active' | 'completed' | 'bye'
export type ChampionshipFormat = 'knockout' | 'group_knockout'
export type ChampionshipMatchStage = 'group' | 'knockout' | 'third_place'

/** slot_type on championship_card_pool — which loadout slot a card fills. */
export type ChampionshipSlotType = 'battle' | 'consumable'

/** tier on championship_card_pool — 'tactical' cards are admin-curated per season. */
export type ChampionshipCardTier = 'core' | 'tactical' | 'consumable'

// ── Shapes ──────────────────────────────────────────────────────────────

export interface ChampionshipSeason {
  id: string
  season_number: number
  series_name: string
  status: ChampionshipSeasonStatus
  registration_starts_at: string
  registration_ends_at: string
  bracket_size: number | null
  round_count: number | null
  current_round: number
  ruleset: {
    allowed_card_keys: string[]
    match_hp: number
    max_attacks_per_match: number
    combo_bonus_pct: number
    prep_hours: number
    fight_hours: number
    /** Semifinal/Final HP override (Live Event addendum). Falls back to 750 server-side if unset. */
    live_round_hp?: number
    /** Semifinal/Final match window override, in hours (Live Event addendum). Falls back to 2 server-side if unset. */
    live_round_fight_hours?: number
  }
  champion_user_id: string | null
  /** 'knockout' for fields of 32 or fewer (drawn straight from registration);
   *  'group_knockout' once the field is big enough to need a Group Stage
   *  first — see _championship_draw_group_stage. */
  format: ChampionshipFormat
  /** Target group size for a group_knockout season (default 4). Actual
   *  group sizes vary by at most 1 to keep things balanced — see
   *  _championship_draw_group_stage. */
  group_size: number
  /** How many round-robin matchdays the group stage needs (the largest
   *  group's own round-robin length). Null for a pure-knockout season. */
  group_stage_round_count: number | null
}

export interface ChampionshipCard {
  card_key: string
  display_name: string
  slot_type: ChampionshipSlotType
  tier: ChampionshipCardTier
  damage: number
  cooldown_minutes: number | null
  max_uses_per_match: number | null
  effect_type: string | null
  effect_magnitude: number | null
  effect_minutes: number | null
  requires_admin_curation: boolean
  /** Reference to the live Mall card this is based on — flavor/attribution only, not an ownership gate. */
  source_catalog_name: string | null
  /** Card art. Null for newly-created Championship-exclusive cards until art is provided — render a fallback tile. */
  image_url: string | null
  is_active: boolean
}

export interface ChampionshipMatch {
  id: string
  season_id: string
  round_number: number
  seed_a: number | null
  seed_b: number | null
  player_a: string
  /** null = this seed drew a bye and auto-advanced. */
  player_b: string | null
  hp_a: number
  hp_b: number
  attacks_used_a: number
  attacks_used_b: number
  combo_used_a: boolean
  combo_used_b: boolean
  winner_id: string | null
  status: ChampionshipMatchStatus
  round_starts_at: string | null
  round_ends_at: string | null
  status_effects: Record<string, unknown>
  /** Whose turn it is to attack — 'a' or 'b'. Null on matches from before the
   *  turn system (or a bye), meaning either side may act. */
  turn: 'a' | 'b' | null
  /** When the current turn's 7h window expires — the non-turn side can call
   *  championshipClaimDefaultWin() once this has passed. */
  turn_deadline_at: string | null
  /** Set once the 1h-remaining reminder has fired for the current turn; null again after each turn handoff. */
  turn_reminder_sent_at: string | null
  /** Set once the halfway-point mid-round nudge has fired for this match (never resets — one nudge per match). */
  mid_round_nudge_sent_at: string | null
  /** Map of user_id -> ISO timestamp of when THAT user dismissed the persistent nudge banner in their own match screen.
   *  Keyed per-user so dismissing it doesn't hide it for the opponent. */
  banner_dismissed_by: Record<string, string>
  /** 'group' for a group-stage fixture, 'third_place' for the new 3rd-place
   *  match, 'knockout' for everything else (the default, including every
   *  match in a pure-knockout season). */
  stage: ChampionshipMatchStage
  /** Set only for stage='group' matches. */
  group_id: string | null
  /** Matchday number within the group stage (1, 2, 3, ...). Null outside stage='group'. */
  matchday: number | null
}

export interface ChampionshipGroup {
  id: string
  season_id: string
  group_number: number
  size: number
}

export interface ChampionshipGroupMember {
  group_id: string
  user_id: string
  seed: number
  points: number
  matches_played: number
  total_damage: number
}

export interface ChampionshipLoadout {
  season_id: string
  user_id: string
  card_keys: string[]
  consumable_keys: string[]
  /** Opponent loadouts are only visible to you once this is set — see RLS. */
  locked_at: string | null
}

export interface ChampionshipAttackLogRow {
  id: string
  match_id: string
  attacker_id: string
  card_key: string
  damage: number
  effect_applied: string | null
  is_combo: boolean
  created_at: string
}

export interface ChampionshipAttackResult {
  damage_dealt: number
  hp_a: number
  hp_b: number
  match_status: ChampionshipMatchStatus
  winner_id: string | null
  /** Which card_effects.ts BUILD key(s) to play, in order — see ChampionshipEffectOverlay. */
  animation_keys: string[]
}

export interface ChampionshipComboResult {
  combo_damage: number
  hp_a: number
  hp_b: number
  match_status: ChampionshipMatchStatus
  /** Per-card breakdown so the combo can play all three cards' effects in
   *  sequence — combo_damage alone doesn't carry which cards were used. */
  attacks: { card_key: string; damage: number; animation_keys: string[] }[]
}

/**
 * The RPCs raise bare lowercase codes (`raise exception 'card_on_cooldown'`),
 * which arrive in PostgrestError.message. Map them here rather than showing
 * the raw string — supabase-js surfaces it with a `P0001` prefix and no
 * capitalisation.
 */
export const CHAMPIONSHIP_ERRORS: Record<string, string> = {
  season_not_found:        'This championship no longer exists.',
  registration_not_open:   'Registration isn’t open for this championship.',
  registration_closed:     'The registration window has closed.',
  championship_full:       'This championship is full (32/32).',
  not_registered:          'You need to register before setting a loadout.',
  loadout_locked:          'Your loadout is locked for the current round.',
  loadout_changes_closed:  'This championship isn’t accepting loadout changes right now.',
  invalid_card_count:      'Choose exactly 3 unique battle cards.',
  too_many_consumables:    'You can bring at most 2 consumables.',
  duplicate_consumable:    'Choose two different consumables.',
  card_not_legal:          'That card isn’t legal for the Championship.',
  card_not_in_pool:        'That card isn’t in this season’s legal pool.',
  card_not_owned:          'You don’t own that card.',
  match_not_found:         'This match no longer exists.',
  match_not_active:        'This match isn’t active.',
  round_closed:            'This round’s window has closed.',
  not_a_participant:       'You’re not a participant in this match.',
  loadout_not_locked:      'Your loadout isn’t locked in for this match yet.',
  card_not_attackable:     'That card can’t be used to attack.',
  card_not_in_loadout:     'That card isn’t in your loadout.',
  attack_cap_reached:      'You’ve used all 6 attacks for this match.',
  card_on_cooldown:        'That card is still on cooldown.',
  consumable_already_used: 'You’ve already used that this match.',
  invalid_consumable:      'That consumable can’t be used this way.',
  consumable_not_in_loadout: 'That consumable isn’t in your loadout.',
  surge_target_required:   'Pick a battle card for Surge to reset.',
  combo_already_used:      'Your combo has already been used this match.',
  combo_attack_budget:     'Not enough attacks left in your budget for a combo.',
  combo_needs_two_distinct_cards: 'Pick two different cards for a 2-card combo.',
  not_your_turn:           'It’s not your turn — wait for your opponent to attack.',
  not_stalling:            'Your opponent is still on the clock — you can’t claim a default win yet.',
  turn_not_expired:        'Your opponent still has time left to attack.',
  not_authorized:          'You need to be signed in.',
  season_not_active:       'This championship isn’t active right now.',
}

const CHAMPIONSHIP_ERROR_KEYS = Object.keys(CHAMPIONSHIP_ERRORS).sort((a, b) => b.length - a.length)

export function championshipErrorMessage(err: unknown): string {
  const raw = (err as { message?: string } | null)?.message ?? ''
  for (const code of CHAMPIONSHIP_ERROR_KEYS) {
    if (raw.includes(code)) return CHAMPIONSHIP_ERRORS[code]
  }
  return 'Something went wrong. Try again.'
}

// ── API ─────────────────────────────────────────────────────────────────

/** The current season for a series, whatever its status — registration, active, or completed. */
// Every caller in the app uses the no-arg form to mean "whatever season is
// currently running" — season_number is scoped PER series_name (see
// admin_open_championship_season), so filtering to one hardcoded series and
// sorting by season_number would silently return nothing, or the wrong
// season, the moment a season is opened under a different name. Sorting by
// created_at across all series is what "current" actually means here.
export async function getCurrentSeason(seriesName?: string): Promise<ChampionshipSeason | null> {
  let query = supabase
    .from('championship_seasons')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(1)
  if (seriesName) query = query.eq('series_name', seriesName)
  const { data, error } = await query.maybeSingle()
  if (error) throw error
  return data as ChampionshipSeason | null
}

export async function getRegistrationCount(seasonId: string): Promise<number> {
  const { count, error } = await supabase
    .from('championship_registrations')
    .select('*', { count: 'exact', head: true })
    .eq('season_id', seasonId)
  if (error) throw error
  return count ?? 0
}

export async function isRegistered(seasonId: string, userId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('championship_registrations')
    .select('id')
    .eq('season_id', seasonId)
    .eq('user_id', userId)
    .maybeSingle()
  if (error) throw error
  return !!data
}

export async function registerForChampionship(seasonId: string): Promise<void> {
  const { error } = await supabase.rpc('register_for_championship', { p_season_id: seasonId })
  if (error) throw error
}

export async function getChampionshipCardPool(): Promise<ChampionshipCard[]> {
  const { data, error } = await supabase.from('championship_card_pool').select('*').eq('is_active', true)
  if (error) throw error
  return (data as ChampionshipCard[] | null) ?? []
}

export async function getMyLoadout(seasonId: string, userId: string): Promise<ChampionshipLoadout | null> {
  const { data, error } = await supabase
    .from('championship_loadouts')
    .select('*')
    .eq('season_id', seasonId)
    .eq('user_id', userId)
    .maybeSingle()
  if (error) throw error
  return data as ChampionshipLoadout | null
}

export async function setChampionshipLoadout(
  seasonId: string, cardKeys: string[], consumableKeys: string[]
): Promise<void> {
  const { error } = await supabase.rpc('set_championship_loadout', {
    p_season_id: seasonId, p_card_keys: cardKeys, p_consumable_keys: consumableKeys,
  })
  if (error) throw error
}

// Group-stage fixtures share this table now (see the migration comment on
// championship_matches.stage) but were never part of what "the bracket"
// means — a caller asking for the bracket wants the knockout tree (plus the
// 3rd-place side match), not the round-robin group games.
export async function getBracket(seasonId: string): Promise<ChampionshipMatch[]> {
  const { data, error } = await supabase
    .from('championship_matches')
    .select('*')
    .eq('season_id', seasonId)
    .in('stage', ['knockout', 'third_place'])
    .order('round_number', { ascending: true })
    .order('seed_a', { ascending: true })
  if (error) throw error
  return (data as ChampionshipMatch[] | null) ?? []
}

export async function getGroups(seasonId: string): Promise<ChampionshipGroup[]> {
  const { data, error } = await supabase
    .from('championship_groups')
    .select('*')
    .eq('season_id', seasonId)
    .order('group_number', { ascending: true })
  if (error) throw error
  return (data as ChampionshipGroup[] | null) ?? []
}

export async function getGroupMembers(groupIds: string[]): Promise<ChampionshipGroupMember[]> {
  if (groupIds.length === 0) return []
  const { data, error } = await supabase
    .from('championship_group_members')
    .select('*')
    .in('group_id', groupIds)
  if (error) throw error
  return (data as ChampionshipGroupMember[] | null) ?? []
}

/** Every group-stage match across every group for a season — used to derive
 *  each group's W/L record client-side rather than adding yet another RPC. */
export async function getGroupMatches(seasonId: string): Promise<ChampionshipMatch[]> {
  const { data, error } = await supabase
    .from('championship_matches')
    .select('*')
    .eq('season_id', seasonId)
    .eq('stage', 'group')
    .order('matchday', { ascending: true })
  if (error) throw error
  return (data as ChampionshipMatch[] | null) ?? []
}

/** The caller's own match for the season's current round, if one exists. */
export async function getMyCurrentMatch(seasonId: string, round: number, userId: string): Promise<ChampionshipMatch | null> {
  const { data, error } = await supabase
    .from('championship_matches')
    .select('*')
    .eq('season_id', seasonId)
    .eq('round_number', round)
    .or(`player_a.eq.${userId},player_b.eq.${userId}`)
    .maybeSingle()
  if (error) throw error
  return data as ChampionshipMatch | null
}

/** A single match by id — used by the spectator view to fetch and reconcile one match, not a whole bracket. */
export async function getMatchById(matchId: string): Promise<ChampionshipMatch | null> {
  const { data, error } = await supabase
    .from('championship_matches')
    .select('*')
    .eq('id', matchId)
    .maybeSingle()
  if (error) throw error
  return data as ChampionshipMatch | null
}

export async function getBattleLog(matchId: string): Promise<ChampionshipAttackLogRow[]> {
  const { data, error } = await supabase
    .from('championship_attacks')
    .select('*')
    .eq('match_id', matchId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data as ChampionshipAttackLogRow[] | null) ?? []
}

export async function championshipAttack(matchId: string, cardKey: string): Promise<ChampionshipAttackResult> {
  const { data, error } = await supabase.rpc('championship_attack', { p_match_id: matchId, p_card_key: cardKey })
  if (error) throw error
  return data as ChampionshipAttackResult
}

export async function championshipUseConsumable(
  matchId: string, consumableKey: 'second_wind' | 'shield' | 'surge', targetCardKey?: string
): Promise<{ used: string; hp_a: number; hp_b: number; animation_keys: string[] }> {
  const { data, error } = await supabase.rpc('championship_use_consumable', {
    p_match_id: matchId, p_consumable_key: consumableKey, p_target_card_key: targetCardKey ?? null,
  })
  if (error) throw error
  return data as { used: string; hp_a: number; hp_b: number; animation_keys: string[] }
}

export async function championshipComboAttack(matchId: string): Promise<ChampionshipComboResult> {
  const { data, error } = await supabase.rpc('championship_combo_attack', { p_match_id: matchId })
  if (error) throw error
  return data as ChampionshipComboResult
}

/** The 2-card combo: plain additive damage, no bonus %, no extra cooldown —
 *  just two of your cards submitted as one Attack tap. Distinct from the
 *  3-card combo, which stays gated by combo_used_a/b. */
export async function championshipComboAttack2(matchId: string, cardKeyA: string, cardKeyB: string): Promise<ChampionshipComboResult> {
  const { data, error } = await supabase.rpc('championship_combo_attack_2', {
    p_match_id: matchId, p_card_key_a: cardKeyA, p_card_key_b: cardKeyB,
  })
  if (error) throw error
  return data as ChampionshipComboResult
}

/** Callable once the opponent's turn_deadline_at has passed while it's still
 *  their turn — ends the match immediately in the caller's favor rather than
 *  waiting for the round's own round_ends_at to close it. */
export async function championshipClaimDefaultWin(matchId: string): Promise<{ match_status: ChampionshipMatchStatus; winner_id: string }> {
  const { data, error } = await supabase.rpc('championship_claim_default_win', { p_match_id: matchId })
  if (error) throw error
  return data as { match_status: ChampionshipMatchStatus; winner_id: string }
}

/** Permanently dismisses the mid-round nudge banner for the caller only —
 *  the opponent still sees their own copy until they dismiss it too. */
export async function championshipDismissMatchBanner(matchId: string): Promise<void> {
  const { error } = await supabase.rpc('championship_dismiss_match_banner', { p_match_id: matchId })
  if (error) throw error
}

export interface SeasonPlacements {
  season_id: string
  season_number: number
  series_name: string
  completed_at: string
  champion_user_id: string | null
  /** null when the season never actually produced a real Final (e.g. a
   *  field so small/empty it resolved entirely by byes — see below). */
  runner_up_user_id: string | null
  /** null when there was no 3rd-place match, or it ended in a double
   *  no-show (see stage='third_place' handling in _championship_advance_core). */
  third_place_user_id: string | null
}

// Runner-up and 3rd place aren't columns anywhere (only champion_user_id
// is, set directly when the season closes) — they're derived here from
// championship_matches: the Final is specifically the knockout match at
// round_number = round_count, and the loser of THAT match is the
// runner-up; 3rd place is whoever won the stage='third_place' match.
//
// Deliberately keyed off round_count rather than "the highest-round match
// with two real players" — a small/empty season (see Season 1) can have
// its only real 2-player match in an early round with everything after it
// resolved by byes. That round-1 loser was eliminated, not a runner-up;
// checking the actual designated Final round is what tells the two apart.
// Same reasoning for 3rd place: a bye or a double no-show there means the
// slot genuinely wasn't decided, not a bug to paper over — it surfaces as
// null and callers should render that as an empty/unclaimed slot.
export async function getSeasonPlacements(seriesName?: string): Promise<SeasonPlacements[]> {
  let query = supabase
    .from('championship_seasons')
    .select('id, season_number, series_name, champion_user_id, round_count, updated_at')
    .eq('status', 'completed')
    .not('champion_user_id', 'is', null)
    .order('season_number', { ascending: false })
  if (seriesName) query = query.eq('series_name', seriesName)
  const { data, error } = await query
  if (error) throw error
  const seasons = (data as {
    id: string; season_number: number; series_name: string
    champion_user_id: string | null; round_count: number | null; updated_at: string
  }[] | null) ?? []
  if (seasons.length === 0) return []

  const seasonIds = seasons.map(s => s.id)
  const { data: matchData, error: matchErr } = await supabase
    .from('championship_matches')
    .select('season_id, round_number, stage, player_a, player_b, winner_id')
    .in('season_id', seasonIds)
    .in('stage', ['knockout', 'third_place'])
  if (matchErr) throw matchErr
  const matches = (matchData as {
    season_id: string; round_number: number; stage: string
    player_a: string; player_b: string | null; winner_id: string | null
  }[] | null) ?? []

  return seasons.map(season => {
    const seasonMatches = matches.filter(m => m.season_id === season.id)

    const finalMatch = seasonMatches.find(m => m.stage === 'knockout' && m.round_number === season.round_count)
    const runnerUp = (finalMatch && finalMatch.player_b && finalMatch.winner_id)
      ? (finalMatch.winner_id === finalMatch.player_a ? finalMatch.player_b : finalMatch.player_a)
      : null

    const thirdMatch = seasonMatches.find(m => m.stage === 'third_place' && m.winner_id !== null)

    return {
      season_id: season.id, season_number: season.season_number, series_name: season.series_name,
      completed_at: season.updated_at, champion_user_id: season.champion_user_id,
      runner_up_user_id: runnerUp, third_place_user_id: thirdMatch?.winner_id ?? null,
    }
  })
}

export interface ChampionshipProfileLite {
  id: string
  username: string
  display_name: string | null
  avatar: string | null
}

/** Batch profile lookup for bracket rows, battle log entries, Hall of Champions. */
export async function getProfilesByIds(ids: string[]): Promise<Map<string, ChampionshipProfileLite>> {
  const unique = Array.from(new Set(ids.filter(Boolean)))
  if (unique.length === 0) return new Map()
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, display_name, avatar')
    .in('id', unique)
  if (error) throw error
  const map = new Map<string, ChampionshipProfileLite>()
  for (const row of (data as ChampionshipProfileLite[] | null) ?? []) map.set(row.id, row)
  return map
}

// ── Admin ───────────────────────────────────────────────────────────────

// No default series name here either — passing undefined lets the DB fall
// through to "Season N" (see admin_open_championship_season). Only pass a
// name when deliberately tying the season to a named event.
export async function adminOpenChampionshipSeason(
  seriesName?: string, registrationHours = 72, allowedCardKeys?: string[]
): Promise<{ season_id: string; season_number: number; series_name: string }> {
  const { data, error } = await supabase.rpc('admin_open_championship_season', {
    p_series_name: seriesName ?? null, p_registration_hours: registrationHours, p_allowed_card_keys: allowedCardKeys ?? null,
  })
  if (error) throw error
  return data as { season_id: string; season_number: number; series_name: string }
}

export async function adminAdvanceChampionshipRound(seasonId: string): Promise<Record<string, unknown>> {
  const { data, error } = await supabase.rpc('admin_advance_championship_round', { p_season_id: seasonId })
  if (error) throw error
  return data as Record<string, unknown>
}
