// src/features/championship/BracketView.tsx
//
// /championship/bracket — shows whichever stage(s) this season actually
// has. A pure-knockout season (<=32 registrants) only ever shows the
// Knockout tab; a group_knockout season (>32) gets both a Group Stage tab
// and a Knockout tab, mirroring the football group-stage-then-knockout
// format from the plan.
//
// Two deliberate scale decisions carried over from the original version,
// now sharpened:
//  - Group Stage never renders every group at once — you get your own
//    group's table by default, with an "All Groups" list you expand
//    yourself. At 2,000 registrants that's ~500 groups; nothing forces all
//    of them onto the screen simultaneously.
//  - Knockout only renders a literal bracket-tree once the field still in
//    play is small enough to actually fit one (<=8 players — Quarterfinal
//    onward). Anything bigger than that renders as the old flat seeded-row
//    list, but ONLY for the current round — completed earlier rounds move
//    into a collapsed "Earlier rounds" section instead of always being on
//    screen, which is what actually fixes the "what if we had 2,000 users"
//    problem: the heaviest rounds are the ones most likely to already be
//    history by the time anyone's looking.
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Swords, Radio, Trophy, ChevronDown, ChevronUp, Users } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { useAuth } from '../auth/useAuth'
import {
  getCurrentSeason, getBracket, getGroups, getGroupMembers, getGroupMatches, getProfilesByIds,
  type ChampionshipSeason, type ChampionshipMatch, type ChampionshipProfileLite,
  type ChampionshipGroup, type ChampionshipGroupMember,
} from './championship'

const TREE_ELIGIBLE_MAX_SURVIVORS = 8

function roundLabel(round: number, roundCount: number, survivorCount: number): string {
  const fromFinal = roundCount - round
  if (fromFinal === 0) return 'Final'
  if (fromFinal === 1) return 'Semifinal'
  if (fromFinal === 2) return 'Quarterfinal'
  return `Round of ${survivorCount}`
}

function nameFor(id: string | null, profiles: Map<string, ChampionshipProfileLite>): string {
  if (!id) return 'TBD'
  const p = profiles.get(id)
  return p?.display_name || p?.username || 'Player'
}

type Tab = 'group' | 'knockout'

export default function BracketView() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [matches, setMatches] = useState<ChampionshipMatch[]>([])
  const [groups, setGroups] = useState<ChampionshipGroup[]>([])
  const [groupMembers, setGroupMembers] = useState<ChampionshipGroupMember[]>([])
  const [groupMatches, setGroupMatches] = useState<ChampionshipMatch[]>([])
  const [profiles, setProfiles] = useState<Map<string, ChampionshipProfileLite>>(new Map())
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<Tab>('knockout')
  const [showAllGroups, setShowAllGroups] = useState(false)
  const [expandedGroupId, setExpandedGroupId] = useState<string | null>(null)
  const [showEarlierRounds, setShowEarlierRounds] = useState(false)

  usePageHeader({ title: 'Bracket', onBack: () => navigate('/championship') })

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const s = await getCurrentSeason()
        if (!s || cancelled) { setLoading(false); return }

        const isGroupFormat = s.format === 'group_knockout'
        const [m, gs, gmatches] = await Promise.all([
          getBracket(s.id),
          isGroupFormat ? getGroups(s.id) : Promise.resolve([]),
          isGroupFormat ? getGroupMatches(s.id) : Promise.resolve([]),
        ])
        if (cancelled) return

        const members = gs.length > 0 ? await getGroupMembers(gs.map(g => g.id)) : []
        if (cancelled) return

        const ids = [
          ...m.flatMap(row => [row.player_a, row.player_b]),
          ...members.map(mm => mm.user_id),
        ].filter((v): v is string => !!v)
        const p = await getProfilesByIds(ids)
        if (cancelled) return

        setSeason(s); setMatches(m); setGroups(gs); setGroupMembers(members); setGroupMatches(gmatches); setProfiles(p)
        setTab(isGroupFormat && s.status === 'group_stage' ? 'group' : 'knockout')
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => { cancelled = true }
  }, [])

  const myGroupId = useMemo(
    () => (user ? groupMembers.find(m => m.user_id === user.id)?.group_id ?? null : null),
    [groupMembers, user]
  )

  if (loading) {
    return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>Loading bracket…</div>
  }
  if (!season) {
    return (
      <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center' }}>
        <Swords size={24} color="var(--text-muted)" style={{ marginBottom: 8 }} />
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>No bracket drawn yet.</div>
      </div>
    )
  }

  const isGroupFormat = season.format === 'group_knockout'

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 16px 48px' }}>
      {isGroupFormat && (
        <div style={{ display: 'flex', gap: 6, padding: '12px 0 4px' }}>
          {(['group', 'knockout'] as Tab[]).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="ripple-wrap"
              style={{
                flex: 1, border: 'none', borderRadius: 10, padding: '9px 0', fontSize: 11.5, fontWeight: 800,
                cursor: 'pointer', position: 'relative', overflow: 'hidden',
                background: tab === t ? 'var(--accent)' : 'var(--surface2)',
                color: tab === t ? '#fff' : 'var(--text-muted)',
              }}
            >
              {t === 'group' ? 'Group Stage' : 'Knockout'}
            </button>
          ))}
        </div>
      )}

      {tab === 'group' && isGroupFormat && (
        <GroupStageView
          season={season} groups={groups} groupMembers={groupMembers} groupMatches={groupMatches}
          profiles={profiles} myGroupId={myGroupId}
          showAllGroups={showAllGroups} setShowAllGroups={setShowAllGroups}
          expandedGroupId={expandedGroupId} setExpandedGroupId={setExpandedGroupId}
        />
      )}

      {tab === 'knockout' && (
        <KnockoutView
          season={season} matches={matches} profiles={profiles} navigate={navigate}
          showEarlierRounds={showEarlierRounds} setShowEarlierRounds={setShowEarlierRounds}
        />
      )}
    </div>
  )
}

// ── Group Stage ─────────────────────────────────────────────────────────

function winsLossesFor(m: ChampionshipGroupMember): { w: number; l: number } {
  const w = Math.round(m.points / 3)
  const l = Math.max(0, m.matches_played - w)
  return { w, l }
}

function sortedGroupMembers(members: ChampionshipGroupMember[]): ChampionshipGroupMember[] {
  return [...members].sort((a, b) => b.points - a.points || b.total_damage - a.total_damage)
}

function GroupMiniTable({
  members, profiles, qualifyCount = 2,
}: {
  members: ChampionshipGroupMember[]; profiles: Map<string, ChampionshipProfileLite>; qualifyCount?: number
}) {
  const sorted = sortedGroupMembers(members)
  return (
    <div>
      {sorted.map((m, i) => {
        const { w, l } = winsLossesFor(m)
        const qualifying = i < qualifyCount
        return (
          <div key={m.user_id} style={{
            display: 'flex', alignItems: 'center', gap: 9, padding: '8px 11px', borderRadius: 10,
            background: qualifying ? 'rgba(122,92,255,0.1)' : 'transparent',
          }}>
            <span style={{ width: 16, fontSize: 10, fontWeight: 800, color: qualifying ? 'var(--accent)' : 'var(--text-muted)', flexShrink: 0 }}>{i + 1}</span>
            <span style={{ flex: 1, fontSize: 11.5, fontWeight: 700, color: 'var(--text)' }}>{nameFor(m.user_id, profiles)}</span>
            <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)' }}>{w}-{l}</span>
            <span style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--text)', width: 26, textAlign: 'right' }}>{m.points}</span>
          </div>
        )
      })}
    </div>
  )
}

function GroupStageView({
  season, groups, groupMembers, groupMatches, profiles, myGroupId,
  showAllGroups, setShowAllGroups, expandedGroupId, setExpandedGroupId,
}: {
  season: ChampionshipSeason; groups: ChampionshipGroup[]; groupMembers: ChampionshipGroupMember[]
  groupMatches: ChampionshipMatch[]; profiles: Map<string, ChampionshipProfileLite>; myGroupId: string | null
  showAllGroups: boolean; setShowAllGroups: (v: boolean) => void
  expandedGroupId: string | null; setExpandedGroupId: (v: string | null) => void
}) {
  const membersByGroup = useMemo(() => {
    const map = new Map<string, ChampionshipGroupMember[]>()
    for (const m of groupMembers) {
      const arr = map.get(m.group_id) ?? []
      arr.push(m)
      map.set(m.group_id, arr)
    }
    return map
  }, [groupMembers])

  const myGroup = groups.find(g => g.id === myGroupId)
  const matchdayCount = season.group_stage_round_count ?? 3
  const completedMatchdays = groupMatches.length > 0
    ? Math.max(0, ...groupMatches.filter(m => m.status === 'completed').map(m => m.matchday ?? 0))
    : 0

  return (
    <div style={{ paddingTop: 8 }}>
      <div style={{ textAlign: 'center', fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', padding: '2px 0 12px' }}>
        {groups.length} groups of {season.group_size} · Matchday {Math.min(completedMatchdays + 1, matchdayCount)} of {matchdayCount} · Top 2 advance
      </div>

      {myGroup ? (
        <div className="neu-card" style={{ padding: '6px 0', marginBottom: 14 }}>
          <div style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--text-muted)', padding: '8px 11px 2px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            Your group · Group {myGroup.group_number}
          </div>
          <GroupMiniTable members={membersByGroup.get(myGroup.id) ?? []} profiles={profiles} />
        </div>
      ) : (
        <div className="neu-card" style={{ padding: 16, marginBottom: 14, textAlign: 'center' }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>You're not in the group stage this season.</div>
        </div>
      )}

      <button
        onClick={() => setShowAllGroups(!showAllGroups)}
        className="ripple-wrap"
        style={{
          width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          padding: '10px 0', background: 'transparent', border: 'none', cursor: 'pointer', position: 'relative', overflow: 'hidden',
          fontSize: 11, fontWeight: 800, color: 'var(--text-secondary)',
        }}
      >
        <Users size={13} />
        All Groups ({groups.length})
        {showAllGroups ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
      </button>

      {showAllGroups && (
        <div style={{ marginTop: 6 }}>
          {groups.map(g => {
            const expanded = expandedGroupId === g.id
            const members = sortedGroupMembers(membersByGroup.get(g.id) ?? [])
            const leader = members[0]
            return (
              <div key={g.id} className="neu-card" style={{ padding: 0, marginBottom: 6, overflow: 'hidden' }}>
                <button
                  onClick={() => setExpandedGroupId(expanded ? null : g.id)}
                  style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '9px 11px',
                    background: g.id === myGroupId ? 'rgba(122,92,255,0.08)' : 'transparent', border: 'none', cursor: 'pointer',
                  }}
                >
                  <span style={{ fontSize: 11, fontWeight: 800, color: 'var(--text)', flexShrink: 0 }}>Group {g.group_number}</span>
                  <span style={{ flex: 1, fontSize: 10.5, color: 'var(--text-muted)', textAlign: 'left' }}>
                    {leader ? `Leading: ${nameFor(leader.user_id, profiles)}` : ''}
                  </span>
                  {expanded ? <ChevronUp size={13} color="var(--text-muted)" /> : <ChevronDown size={13} color="var(--text-muted)" />}
                </button>
                {expanded && (
                  <>
                    <div style={{ height: 1, background: 'var(--border)' }} />
                    <GroupMiniTable members={members} profiles={profiles} />
                  </>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ── Knockout ────────────────────────────────────────────────────────────

function survivorCountForRound(roundMatches: ChampionshipMatch[]): number {
  return roundMatches.reduce((sum, m) => sum + (m.player_b ? 2 : 1), 0)
}

function MatchRow({ name, seed, won, lost, live }: { name: string; seed: number | null; won: boolean; lost: boolean; live: boolean }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 9, padding: '9px 11px', borderRadius: 10,
      background: won ? 'rgba(122,92,255,0.1)' : live ? 'rgba(255,77,109,0.08)' : 'transparent',
    }}>
      {seed != null && (
        <span style={{ width: 18, height: 18, borderRadius: 5, background: 'var(--surface2)', color: 'var(--text-muted)', fontSize: 9, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          {seed}
        </span>
      )}
      <span style={{
        flex: 1, fontSize: 11.5, fontWeight: 700,
        color: lost ? 'var(--text-muted)' : 'var(--text)',
        textDecoration: lost ? 'line-through' : 'none',
      }}>
        {name}
      </span>
      {won && <span style={{ fontSize: 9, fontWeight: 700, color: 'var(--accent)' }}>Won</span>}
      {live && <span style={{ fontSize: 9, fontWeight: 700, color: 'var(--danger, #ff4d6d)', display: 'flex', alignItems: 'center', gap: 4 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--danger, #ff4d6d)' }} />Live
      </span>}
    </div>
  )
}

function MatchCard({
  m, profiles, canSpectate, navigate,
}: {
  m: ChampionshipMatch; profiles: Map<string, ChampionshipProfileLite>; canSpectate: boolean
  navigate: ReturnType<typeof useNavigate>
}) {
  const isLive = m.status === 'active'
  const isBye = m.status === 'bye'
  const aWon = !!m.winner_id && m.winner_id === m.player_a
  const bWon = !!m.winner_id && m.winner_id === m.player_b
  return (
    <div className="neu-card" style={{ padding: 4, marginBottom: 8, overflow: 'hidden' }}>
      <MatchRow name={nameFor(m.player_a, profiles)} seed={m.seed_a} won={aWon} lost={!!m.winner_id && !aWon} live={isLive} />
      <div style={{ height: 1, background: 'var(--border)' }} />
      {isBye ? (
        <div style={{ padding: '7px 9px', fontSize: 10.5, color: 'var(--text-muted)', fontStyle: 'italic' }}>Bye</div>
      ) : (
        <MatchRow name={nameFor(m.player_b, profiles)} seed={m.seed_b} won={bWon} lost={!!m.winner_id && !bWon} live={isLive} />
      )}
      {canSpectate && (
        <>
          <div style={{ height: 1, background: 'var(--border)' }} />
          <button
            onClick={() => navigate(`/championship/spectate/${m.id}`)}
            style={{
              width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              padding: '8px 11px', background: 'transparent', border: 'none', cursor: 'pointer',
              fontSize: 10.5, fontWeight: 800, color: 'var(--danger, #ff4d6d)', letterSpacing: '0.02em',
            }}
          >
            <Radio size={11} />
            Watch live
          </button>
        </>
      )}
    </div>
  )
}

function KnockoutView({
  season, matches, profiles, navigate, showEarlierRounds, setShowEarlierRounds,
}: {
  season: ChampionshipSeason; matches: ChampionshipMatch[]; profiles: Map<string, ChampionshipProfileLite>
  navigate: ReturnType<typeof useNavigate>
  showEarlierRounds: boolean; setShowEarlierRounds: (v: boolean) => void
}) {
  if (matches.length === 0) {
    return (
      <div className="neu-card" style={{ padding: 24, marginTop: 12, textAlign: 'center' }}>
        <Trophy size={22} color="var(--text-muted)" style={{ marginBottom: 8 }} />
        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
          {season.format === 'group_knockout' && season.status === 'group_stage'
            ? "The Knockout Stage opens once the group stage wraps up."
            : 'No bracket drawn yet.'}
        </div>
      </div>
    )
  }

  const roundCount = season.round_count ?? Math.max(...matches.map(m => m.round_number))
  const knockoutMatches = matches.filter(m => m.stage === 'knockout')
  const thirdPlaceMatch = matches.find(m => m.stage === 'third_place') ?? null
  const rounds = Array.from(new Set(knockoutMatches.map(m => m.round_number))).sort((a, b) => a - b)

  const roundsById = rounds.map(round => {
    const roundMatches = knockoutMatches.filter(m => m.round_number === round).sort((a, b) => (a.seed_a ?? 0) - (b.seed_a ?? 0))
    return { round, roundMatches, survivorCount: survivorCountForRound(roundMatches) }
  })

  const treeRounds = roundsById.filter(r => r.survivorCount <= TREE_ELIGIBLE_MAX_SURVIVORS)
  const earlierRounds = roundsById.filter(r => r.survivorCount > TREE_ELIGIBLE_MAX_SURVIVORS)

  // The round to headline at the top: whichever tree round is still being
  // decided, or the last one if the whole thing's done.
  const focusRound = treeRounds.find(r => r.roundMatches.some(m => m.status === 'pending' || m.status === 'active')) ?? treeRounds[treeRounds.length - 1]
  const focusDecided = focusRound ? focusRound.roundMatches.filter(m => m.status === 'completed' || m.status === 'bye').length : 0
  const focusTotal = focusRound ? focusRound.roundMatches.length : 0

  const isLiveTierRound = (round: number) => round >= roundCount - 1

  return (
    <div style={{ paddingTop: 12 }}>
      {focusRound && (
        <div style={{ textAlign: 'center', padding: '4px 0 18px' }}>
          <Trophy size={40} color="var(--gold)" style={{ marginBottom: 8 }} />
          <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text)' }}>
            {roundLabel(focusRound.round, roundCount, focusRound.survivorCount)}
          </div>
          <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', marginTop: 2 }}>
            {focusDecided} / {focusTotal} decided
          </div>
        </div>
      )}

      {earlierRounds.length > 0 && (
        <>
          <button
            onClick={() => setShowEarlierRounds(!showEarlierRounds)}
            className="ripple-wrap"
            style={{
              width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              padding: '8px 0 14px', background: 'transparent', border: 'none', cursor: 'pointer', position: 'relative', overflow: 'hidden',
              fontSize: 11, fontWeight: 800, color: 'var(--text-secondary)',
            }}
          >
            Earlier rounds
            {showEarlierRounds ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
          </button>
          {showEarlierRounds && earlierRounds.map(({ round, roundMatches, survivorCount }) => (
            <div key={round} style={{ marginBottom: 18 }}>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', margin: '14px 0 8px' }}>
                {roundLabel(round, roundCount, survivorCount)}
              </div>
              {roundMatches.map(m => (
                <MatchCard key={m.id} m={m} profiles={profiles}
                  canSpectate={m.status === 'active' && isLiveTierRound(round)} navigate={navigate} />
              ))}
            </div>
          ))}
        </>
      )}

      {treeRounds.map(({ round, roundMatches, survivorCount }, i) => (
        <div key={round}>
          <div style={{ fontSize: 10.5, fontWeight: 800, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', textAlign: 'center', margin: '4px 0 8px' }}>
            {roundLabel(round, roundCount, survivorCount)}
          </div>
          {roundMatches.map(m => (
            <MatchCard key={m.id} m={m} profiles={profiles}
              canSpectate={m.status === 'active' && isLiveTierRound(round)} navigate={navigate} />
          ))}
          {i < treeRounds.length - 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '2px 0 12px' }}>
              <ChevronDown size={16} color="var(--text-muted)" />
            </div>
          )}
        </div>
      ))}

      {thirdPlaceMatch && (
        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', textAlign: 'center', margin: '4px 0 8px' }}>
            🥉 3rd Place Match
          </div>
          <div style={{ maxWidth: 320, margin: '0 auto' }}>
            <MatchCard
              m={thirdPlaceMatch} profiles={profiles}
              canSpectate={thirdPlaceMatch.status === 'active'} navigate={navigate}
            />
          </div>
        </div>
      )}
    </div>
  )
}
