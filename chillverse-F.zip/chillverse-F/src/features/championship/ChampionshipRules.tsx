// src/features/championship/ChampionshipRules.tsx
//
// /championship/rules — reads the live season ruleset rather than hardcoding
// numbers, so if an admin ever tunes match_hp or the attack cap for a
// season, this screen is automatically correct instead of quietly stale.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Swords } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { getCurrentSeason, getChampionshipCardPool, type ChampionshipSeason, type ChampionshipCard } from './championship'

const RULE_ROWS = (s: ChampionshipSeason): [string, string][] => [
  ['Starting HP', `${s.ruleset.match_hp}`],
  ['Loadout', '3 battle cards + up to 2 consumables'],
  ['Max attacks', `${s.ruleset.max_attacks_per_match} per player per match`],
  ['3-card combo', `Once per match · +${s.ruleset.combo_bonus_pct}% damage`],
  ['Match window', `${s.ruleset.fight_hours}h per round`],
  ['Prep window', `${s.ruleset.prep_hours}h between rounds — loadout edits open, then lock`],
  ['Timeout resolution', 'Most damage dealt → remaining HP → deterministic tiebreak'],
  ['No-show', 'Neither side attacks: both eliminated. One side attacks: they advance.'],
]

export default function ChampionshipRules() {
  const navigate = useNavigate()
  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [pool, setPool] = useState<ChampionshipCard[]>([])
  const [loading, setLoading] = useState(true)

  usePageHeader({ title: 'Rules', onBack: () => navigate('/championship') })

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const [s, p] = await Promise.all([getCurrentSeason(), getChampionshipCardPool()])
      if (!cancelled) { setSeason(s); setPool(p); setLoading(false) }
    })()
    return () => { cancelled = true }
  }, [])

  if (loading) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>
  if (!season) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>No championship to show rules for right now.</div>

  const legalPool = pool.filter(c => season.ruleset.allowed_card_keys?.includes(c.card_key))
  const battle = legalPool.filter(c => c.slot_type === 'battle')
  const consumable = legalPool.filter(c => c.slot_type === 'consumable')

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 16px 48px' }}>
      <div className="neu-card" style={{ marginTop: 12, padding: 4 }}>
        {RULE_ROWS(season).map(([label, value], i) => (
          <div key={label} style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '10px 12px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
            <span style={{ fontSize: 11.5, color: 'var(--text-secondary)', flexShrink: 0 }}>{label}</span>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text)', textAlign: 'right' }}>{value}</span>
          </div>
        ))}
      </div>

      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', margin: '18px 0 8px' }}>Legal battle cards this season</div>
      <div className="neu-card" style={{ padding: 4 }}>
        {battle.map((c, i) => (
          <div key={c.card_key} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
            <Swords size={12} color="var(--text-muted)" />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text)', flex: 1 }}>{c.display_name}</span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{c.damage} dmg</span>
          </div>
        ))}
      </div>

      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', margin: '18px 0 8px' }}>Legal consumables this season</div>
      <div className="neu-card" style={{ padding: 4 }}>
        {consumable.map((c, i) => (
          <div key={c.card_key} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text)', flex: 1 }}>{c.display_name}</span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>1 use / match</span>
          </div>
        ))}
      </div>
    </div>
  )
}
