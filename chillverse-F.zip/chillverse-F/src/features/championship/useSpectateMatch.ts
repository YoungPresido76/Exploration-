// src/features/championship/useSpectateMatch.ts
//
// Read-only live feed for spectating a Semifinal/Final Championship match:
// the match row (HP, status, winner) and its attack log. This deliberately
// mirrors the reconnect logic in src/features/multiplayer/useRoom.ts rather
// than reinventing it — `postgres_changes` has no replay, so a socket that
// drops for even a moment (tab backgrounded, wifi hands off to cellular)
// silently loses whatever fired while it was down. The fix isn't just
// resubscribing on reconnect, it's treating the realtime push as the fast
// path and reconciling with a fresh fetch on: successful (re)subscribe, tab
// foreground, network-back-online, and a short visible-tab poll as a pure
// backstop. See useRoom.ts's header comment for the full rationale.
import { useCallback, useEffect, useRef, useState } from 'react'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from '../../shared/lib/supabase'
import { getMatchById, getBattleLog, type ChampionshipMatch, type ChampionshipAttackLogRow } from './championship'

const RECONCILE_MS = 2500
const RETRY_MS_START = 1000
const RETRY_MS_MAX = 10000

/** Cheap identity check so a reconcile fetch that found nothing new doesn't force a re-render. */
function fingerprint(match: ChampionshipMatch | null): string {
  if (!match) return ''
  return `${match.status}|${match.hp_a}|${match.hp_b}|${match.attacks_used_a}|${match.attacks_used_b}|${match.combo_used_a}|${match.combo_used_b}|${match.winner_id ?? ''}`
}

export function useSpectateMatch(matchId: string | null) {
  const [match, setMatch] = useState<ChampionshipMatch | null>(null)
  const [log, setLog] = useState<ChampionshipAttackLogRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fingerprintRef = useRef('')
  const logCountRef = useRef(0)

  const applyMatch = useCallback((next: ChampionshipMatch | null) => {
    fingerprintRef.current = fingerprint(next)
    setMatch(next)
  }, [])

  const reloadLog = useCallback(async (id: string) => {
    try {
      const rows = await getBattleLog(id)
      // Skip the state update when the count hasn't moved — this runs on
      // every reconcile tick, so it needs to be cheap when the log is idle.
      if (rows.length !== logCountRef.current) {
        logCountRef.current = rows.length
        setLog(rows)
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load battle log')
    }
  }, [])

  const refetchMatch = useCallback(async (id: string) => {
    try {
      const m = await getMatchById(id)
      if (fingerprint(m) !== fingerprintRef.current) applyMatch(m)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load match')
    }
  }, [applyMatch])

  const reconcile = useCallback((id: string) => {
    void refetchMatch(id)
    void reloadLog(id)
  }, [refetchMatch, reloadLog])

  useEffect(() => {
    if (!matchId) { applyMatch(null); setLog([]); logCountRef.current = 0; setLoading(false); return }
    const id = matchId
    let cancelled = false
    let channel: RealtimeChannel | null = null
    let retryTimer: ReturnType<typeof setTimeout> | null = null
    let retryDelay = RETRY_MS_START

    setLoading(true)
    setError(null)

    Promise.all([getMatchById(id), getBattleLog(id)])
      .then(([m, rows]) => {
        if (cancelled) return
        applyMatch(m)
        logCountRef.current = rows.length
        setLog(rows)
      })
      .catch((e: unknown) => { if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load match') })
      .finally(() => { if (!cancelled) setLoading(false) })

    function clearRetryTimer() {
      if (retryTimer) { clearTimeout(retryTimer); retryTimer = null }
    }

    function subscribe() {
      if (cancelled) return
      const ch = supabase
        .channel(`championship-spectate:${id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'championship_matches', filter: `id=eq.${id}` }, (payload) => {
          if (payload.eventType === 'DELETE') { applyMatch(null); return }
          applyMatch(payload.new as ChampionshipMatch)
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'championship_attacks', filter: `match_id=eq.${id}` }, () => {
          void reloadLog(id)
        })
        .subscribe((status) => {
          if (cancelled) return
          if (status === 'SUBSCRIBED') {
            retryDelay = RETRY_MS_START
            // Catch up on anything that landed while this socket was
            // (re)connecting — postgres_changes has no replay, so this
            // fetch is what actually closes the gap, not the subscribe call.
            reconcile(id)
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
            clearRetryTimer()
            const delay = retryDelay
            retryDelay = Math.min(retryDelay * 2, RETRY_MS_MAX)
            retryTimer = setTimeout(() => {
              if (cancelled) return
              supabase.removeChannel(ch)
              subscribe()
            }, delay)
          }
        })
      channel = ch
    }

    subscribe()

    function handleVisible() {
      if (document.visibilityState === 'visible') reconcile(id)
    }
    function handleOnline() {
      reconcile(id)
    }
    document.addEventListener('visibilitychange', handleVisible)
    window.addEventListener('online', handleOnline)

    const pollTimer = setInterval(() => {
      if (document.visibilityState === 'visible') reconcile(id)
    }, RECONCILE_MS)

    return () => {
      cancelled = true
      clearRetryTimer()
      clearInterval(pollTimer)
      document.removeEventListener('visibilitychange', handleVisible)
      window.removeEventListener('online', handleOnline)
      if (channel) supabase.removeChannel(channel)
    }
  }, [matchId, reloadLog, refetchMatch, reconcile, applyMatch])

  return { match, log, loading, error }
}
