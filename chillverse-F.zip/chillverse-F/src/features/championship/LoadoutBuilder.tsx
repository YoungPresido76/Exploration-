// src/features/championship/LoadoutBuilder.tsx
//
// /championship/loadout — pick exactly 3 unique battle cards and up to 2
// consumables from the season's legal pool. Everyone registered has equal
// access to the whole pool for the season — Championship stats are fully
// standardized already, so gating by Mall ownership on top of that would
// be inconsistent.
//
// Tapping a card (pool grid or an equipped slot) opens ChampionshipCardSheet
// — details plus the actual Equip/Remove action — rather than toggling
// selection instantly on tap, matching how Mall's ItemModal works. Once
// the loadout is locked, the sheet renders a static "Locked" state with
// no action at all: there is no code path in the locked branch that calls
// onToggle, so there's nothing that can look tappable and silently no-op.
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, Lock } from 'lucide-react'
import { usePageHeader } from '../../context/PageHeader'
import { useAuth } from '../auth/useAuth'
import { ripple } from '../../shared/lib/ripple'
import Toast, { useToast } from '../../shared/components/Toast'
import ChampionshipCardSheet from './ChampionshipCardSheet'
import {
  getCurrentSeason, getChampionshipCardPool, getMyLoadout, setChampionshipLoadout,
  championshipErrorMessage, type ChampionshipSeason, type ChampionshipCard,
} from './championship'

function cardBackground(card: ChampionshipCard): React.CSSProperties {
  if (!card.image_url) return {}
  return {
    backgroundImage: `linear-gradient(180deg, rgba(15,9,26,0.15) 0%, rgba(15,9,26,0.88) 78%), url(${card.image_url})`,
    backgroundSize: 'cover', backgroundPosition: 'center',
  }
}

export default function LoadoutBuilder() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast, showToast } = useToast()

  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [pool, setPool] = useState<ChampionshipCard[]>([])
  const [selectedCards, setSelectedCards] = useState<string[]>([])
  const [selectedConsumables, setSelectedConsumables] = useState<string[]>([])
  const [locked, setLocked] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [tab, setTab] = useState<'battle' | 'consumable'>('battle')
  const [openCardKey, setOpenCardKey] = useState<string | null>(null)

  usePageHeader({ title: 'Build loadout', onBack: () => navigate('/championship') })

  useEffect(() => {
    if (!user) return
    let cancelled = false
    ;(async () => {
      try {
        const s = await getCurrentSeason()
        if (!s || cancelled) { setLoading(false); return }
        const [cardPool, existing] = await Promise.all([
          getChampionshipCardPool(),
          getMyLoadout(s.id, user.id),
        ])
        if (cancelled) return
        setSeason(s)
        setPool(cardPool.filter(c => s.ruleset.allowed_card_keys?.includes(c.card_key)))
        if (existing) {
          setSelectedCards(existing.card_keys)
          setSelectedConsumables(existing.consumable_keys)
          setLocked(!!existing.locked_at)
        }
      } catch {
        showToast({ message: 'Couldn\u2019t load your loadout options.', icon: Lock })
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => { cancelled = true }
  }, [user, showToast])

  const battleCards = useMemo(() => pool.filter(c => c.slot_type === 'battle'), [pool])
  const consumables = useMemo(() => pool.filter(c => c.slot_type === 'consumable'), [pool])
  const cardByKey = useMemo(() => new Map(pool.map(c => [c.card_key, c])), [pool])
  const openCard = openCardKey ? cardByKey.get(openCardKey) : null

  function toggleCard(key: string) {
    if (locked) return
    setSelectedCards(prev => {
      if (prev.includes(key)) return prev.filter(k => k !== key)
      if (prev.length >= 3) { showToast({ message: 'You can only carry 3 battle cards.', icon: Lock }); return prev }
      return [...prev, key]
    })
  }

  function toggleConsumable(key: string) {
    if (locked) return
    setSelectedConsumables(prev => {
      if (prev.includes(key)) return prev.filter(k => k !== key)
      if (prev.length >= 2) { showToast({ message: 'You can only carry 2 consumables.', icon: Lock }); return prev }
      return [...prev, key]
    })
  }

  async function handleLockIn() {
    if (!season || saving) return
    if (selectedCards.length !== 3) { showToast({ message: 'Choose exactly 3 battle cards.', icon: Lock }); return }
    setSaving(true)
    try {
      await setChampionshipLoadout(season.id, selectedCards, selectedConsumables)
      showToast({ message: 'Loadout saved.', icon: Check, iconColor: 'var(--accent)' })
      navigate('/championship')
    } catch (err) {
      showToast({ message: championshipErrorMessage(err), icon: Lock })
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>Loading\u2026</div>
  if (!season) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>No championship to build a loadout for right now.</div>

  const activeList = tab === 'battle' ? battleCards : consumables
  const selectedList = tab === 'battle' ? selectedCards : selectedConsumables

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 16px 100px' }}>
      {locked && (
        <div className="neu-card" style={{ padding: 12, marginTop: 12, display: 'flex', alignItems: 'center', gap: 8, color: 'var(--gold)' }}>
          <Lock size={14} />
          <span style={{ fontSize: 12, fontWeight: 700 }}>Locked in for the current round \u2014 changes open again in the next prep window.</span>
        </div>
      )}

      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', margin: '16px 0 8px' }}>Battle cards ({selectedCards.length}/3)</div>
      <div style={{ display: 'flex', gap: 7 }}>
        {[0, 1, 2].map(i => {
          const key = selectedCards[i]
          const card = key ? cardByKey.get(key) : null
          return <SlotTile key={i} card={card} accentVar="--accent" locked={locked} onClick={() => key && setOpenCardKey(key)} />
        })}
      </div>

      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', margin: '16px 0 8px' }}>Consumables ({selectedConsumables.length}/2)</div>
      <div style={{ display: 'flex', gap: 7 }}>
        {[0, 1].map(i => {
          const key = selectedConsumables[i]
          const card = key ? cardByKey.get(key) : null
          return <SlotTile key={i} card={card} accentVar="--blue" locked={locked} onClick={() => key && setOpenCardKey(key)} />
        })}
      </div>

      <div style={{ display: 'flex', gap: 6, margin: '20px 0 12px' }}>
        <button onClick={(e) => { ripple(e); setTab('battle') }} className="ripple-wrap" style={pillStyle(tab === 'battle')}>Battle cards</button>
        <button onClick={(e) => { ripple(e); setTab('consumable') }} className="ripple-wrap" style={pillStyle(tab === 'consumable')}>Consumables</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {activeList.map(card => {
          const selected = selectedList.includes(card.card_key)
          return (
            <div
              key={card.card_key}
              onClick={(e) => { ripple(e); setOpenCardKey(card.card_key) }}
              className="neu-card ripple-wrap"
              style={{
                padding: 11, position: 'relative', overflow: 'hidden', cursor: 'pointer',
                border: selected ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                opacity: locked ? 0.55 : 1, filter: locked ? 'grayscale(0.6)' : 'none',
                ...cardBackground(card),
              }}
            >
              <div style={{ fontSize: 11.5, fontWeight: 700, color: card.image_url ? '#fbf6ff' : 'var(--text)' }}>{card.display_name}</div>
              <span style={{
                display: 'inline-block', marginTop: 5, fontSize: 8.5, fontWeight: 700, padding: '2px 7px', borderRadius: 20,
                background: card.source_catalog_name ? 'rgba(79,142,247,0.16)' : 'rgba(245,197,66,0.2)',
                color: card.source_catalog_name ? '#7fb0ff' : '#ffd88a',
              }}>
                {card.source_catalog_name ? card.tier === 'tactical' ? 'Tactical' : 'Core' : 'Championship exclusive'}
              </span>
              <div style={{ fontSize: 9.5, color: card.image_url ? '#c3b6e0' : 'var(--text-muted)', marginTop: 6 }}>
                {card.damage > 0 ? `${card.damage} dmg` : card.effect_type}
                {card.cooldown_minutes ? ` \u00b7 ${(card.cooldown_minutes / 60).toFixed(card.cooldown_minutes % 60 ? 1 : 0)}h cooldown` : ''}
                {card.max_uses_per_match ? ' \u00b7 1 use/match' : ''}
              </div>
              {locked ? (
                <div style={{ position: 'absolute', top: 8, right: 8, width: 18, height: 18, borderRadius: '50%', background: 'rgba(20,14,32,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Lock size={10} color="var(--gold)" />
                </div>
              ) : selected && (
                <div style={{ position: 'absolute', top: 8, right: 8, width: 18, height: 18, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Check size={11} color="#fff" />
                </div>
              )}
            </div>
          )
        })}
      </div>

      {!locked && (
        <div style={{ position: 'fixed', left: 0, right: 0, bottom: 'var(--dock-space, 0px)', padding: 16, background: 'var(--bg)', borderTop: '1px solid var(--border)', maxWidth: 560, margin: '0 auto' }}>
          <button
            onClick={(e) => { ripple(e); handleLockIn() }}
            disabled={saving || selectedCards.length !== 3}
            className="ripple-wrap"
            style={{
              width: '100%', border: 'none', borderRadius: 12, padding: 14, fontSize: 14, fontWeight: 800, position: 'relative', overflow: 'hidden',
              background: selectedCards.length === 3 ? 'linear-gradient(135deg,#f5c542,#ff9a3c)' : 'var(--surface2)',
              color: selectedCards.length === 3 ? '#241934' : 'var(--text-muted)',
              cursor: selectedCards.length === 3 && !saving ? 'pointer' : 'default',
            }}
          >
            {saving ? 'Saving\u2026' : 'Lock in loadout'}
          </button>
        </div>
      )}

      {openCard && (
        <ChampionshipCardSheet
          card={openCard}
          isLocked={locked}
          isSelected={openCard.slot_type === 'battle' ? selectedCards.includes(openCard.card_key) : selectedConsumables.includes(openCard.card_key)}
          canAddMore={openCard.slot_type === 'battle' ? selectedCards.length < 3 : selectedConsumables.length < 2}
          onClose={() => setOpenCardKey(null)}
          onToggle={() => {
            openCard.slot_type === 'battle' ? toggleCard(openCard.card_key) : toggleConsumable(openCard.card_key)
            setOpenCardKey(null)
          }}
        />
      )}

      <Toast toast={toast} />
    </div>
  )
}

function pillStyle(active: boolean): React.CSSProperties {
  return {
    fontSize: 11, fontWeight: 700, padding: '7px 13px', borderRadius: 20, border: 'none',
    background: active ? 'linear-gradient(135deg, var(--accent), var(--brand-violet-soft))' : 'var(--surface2)',
    color: active ? '#fff' : 'var(--text-secondary)',
  }
}

function SlotTile({ card, accentVar, locked, onClick }: { card: ChampionshipCard | null | undefined; accentVar: string; locked?: boolean; onClick: () => void }) {
  return (
    <div
      onClick={onClick}
      style={{
        flex: 1, aspectRatio: '1', borderRadius: 11, display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', textAlign: 'center', padding: 4, cursor: card ? 'pointer' : 'default', overflow: 'hidden',
        position: 'relative',
        border: card ? `1.5px solid var(${accentVar})` : '1.5px dashed var(--border-strong)',
        background: card ? 'var(--surface)' : 'var(--surface2)',
        opacity: locked && card ? 0.55 : 1, filter: locked && card ? 'grayscale(0.6)' : 'none',
        ...(card ? cardBackground(card) : {}),
      }}
    >
      {card ? (
        <>
          <div style={{ fontSize: 9, fontWeight: 700, color: card.image_url ? '#fbf6ff' : 'var(--text)' }}>{card.display_name}</div>
          {card.damage > 0 && <div style={{ fontSize: 8.5, color: card.image_url ? '#fbf6ff' : `var(${accentVar})`, fontWeight: 600 }}>{card.damage} dmg</div>}
          {locked && (
            <div style={{ position: 'absolute', top: 4, right: 4, width: 15, height: 15, borderRadius: '50%', background: 'rgba(20,14,32,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Lock size={8} color="var(--gold)" />
            </div>
          )}
        </>
      ) : (
        <span style={{ fontSize: 9, color: 'var(--text-muted)' }}>Empty</span>
      )}
    </div>
  )
}
