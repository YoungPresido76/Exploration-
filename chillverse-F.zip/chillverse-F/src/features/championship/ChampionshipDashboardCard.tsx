// src/features/championship/ChampionshipDashboardCard.tsx
//
// Dashboard entry point for the Championship. Deliberately heavier than a
// Quick Actions tile — modeled on EliminationDashboardCard's "this is a
// scheduled event, not a daily feature" weight, but eclipse-dark so it
// visually breaks from the light dashboard around it. Draws nothing until
// the season has loaded, and nothing at all once a season is completed —
// the Dashboard isn't where a finished season's story gets told, the Hub
// and Hall of Champions are.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Trophy } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { getCurrentSeason, getRegistrationCount, type ChampionshipSeason } from './championship'

function timeLeftLabel(iso: string): string {
  const ms = Math.max(0, new Date(iso).getTime() - Date.now())
  const days = Math.floor(ms / 86_400_000)
  const hours = Math.floor((ms % 86_400_000) / 3_600_000)
  if (days > 0) return `${days}d ${hours}h`
  const minutes = Math.floor((ms % 3_600_000) / 60_000)
  return `${hours}h ${minutes}m`
}

export default function ChampionshipDashboardCard() {
  const navigate = useNavigate()
  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [regCount, setRegCount] = useState(0)

  useEffect(() => {
    let cancelled = false
    getCurrentSeason().then(async s => {
      if (cancelled || !s || s.status === 'completed' || s.status === 'cancelled') return
      const count = await getRegistrationCount(s.id)
      if (!cancelled) { setSeason(s); setRegCount(count) }
    }).catch(() => {})
    return () => { cancelled = true }
  }, [])

  if (!season) return null

  const isRegistration = season.status === 'registration'

  return (
    <div
      onClick={(e) => { ripple(e); navigate('/championship') }}
      className="ripple-wrap"
      style={{
        marginTop: 12, padding: 16, position: 'relative', overflow: 'hidden', borderRadius: 16, cursor: 'pointer',
        backgroundImage: 'linear-gradient(140deg, rgba(36,25,52,0.88) 0%, rgba(24,15,43,0.92) 55%, rgba(13,8,24,0.96) 100%), url(https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/event-images/e2a08967-976b-4abe-8e0f-df87ffbf5a18/file_00000000bd788243b3ca978811b7faad.png)',
        backgroundSize: 'cover', backgroundPosition: 'top center',
        border: '1px solid rgba(245,197,66,0.35)',
        boxShadow: '0 10px 28px -8px rgba(20,8,40,0.55), inset 0 1px 0 rgba(255,255,255,0.06)',
      }}
    >
      <div style={{
        position: 'absolute', top: -60, right: -40, width: 180, height: 180, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(245,197,66,0.35) 0%, rgba(122,92,255,0.18) 45%, transparent 72%)',
      }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, position: 'relative', zIndex: 1 }}>
        <div style={{
          width: 48, height: 48, borderRadius: 14, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'linear-gradient(135deg, #f5c542, #ff9a3c)', boxShadow: '0 4px 14px rgba(245,197,66,0.35)',
        }}>
          <Trophy size={21} color="#241934" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 2 }}>
            <span style={{ fontSize: 14.5, fontWeight: 800, color: '#fbf6ff', letterSpacing: '-0.01em' }}>Chillverse Championship</span>
            <span style={{
              fontSize: 8, fontWeight: 900, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--gold)',
              padding: '2px 6px', borderRadius: 6, background: 'rgba(245,197,66,0.16)', border: '1px solid rgba(245,197,66,0.4)',
            }}>
              {isRegistration ? 'Open' : 'Live'}
            </span>
          </div>
          <div style={{ fontSize: 11.5, color: '#b9a9e0', fontWeight: 500 }}>
            {season.series_name}
            {isRegistration ? ` · Sign-ups close in ${timeLeftLabel(season.registration_ends_at)}` : ` · Round ${season.current_round} of ${season.round_count}`}
          </div>
        </div>
      </div>
      <div style={{ marginTop: 12, paddingTop: 10, borderTop: '1px solid rgba(245,197,66,0.18)', fontSize: 11, fontWeight: 700, color: 'var(--gold)', position: 'relative', zIndex: 1 }}>
        {isRegistration ? `👑 ${regCount} players registered · bracket draws soon` : '⚔️ The bracket is live — tap in to check your match'}
      </div>
    </div>
  )
}
