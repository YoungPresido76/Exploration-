// src/features/championship/ChampionshipEffectOverlay.tsx
//
// Full-screen card-effect playback for Championship matches — mounted
// locally by ChampionshipMatchSheet and ChampionshipSpectateSheet
// (unlike PvpEffectOverlay, which mounts once globally in AppLayout: a
// championship effect only ever makes sense while you're looking at
// that specific match, so it doesn't need a global always-on bus).
//
// Reuses the same particle markup and stylesheet as pvp
// (src/shared/effects/cardEffectBuild.ts + pvp-effects.css) so the 8
// championship cards that share a name with a pvp card play the exact
// same effect, pixel for pixel, rather than a redrawn copy that could
// drift. Only the copy underneath (no combo stamps, no kill streaks,
// no revenge/first-blood — none of that exists in a tournament bracket)
// and the queue are championship's own, because those semantics
// genuinely differ from pvp's.
import { useCallback, useEffect, useRef, useState } from 'react'
import { BUILD, FALLBACK } from '../../shared/effects/cardEffectBuild'
import '../pvp/pvp-effects.css'

export interface ChampionshipFxEvent {
  /** Stable-ish key so the same event object played twice (e.g. a re-render
   *  before the timer clears) doesn't restart the animation from scratch. */
  id: string
  animationKeys: string[]
  damage: number
  /** True when this is the opponent's attack landing on the viewer (or, on
   *  the spectate screen, simply "not the left-hand player's own action"). */
  incoming: boolean
  attackerName?: string
  selfBuff?: boolean
  healed?: number
}

export default function ChampionshipEffectOverlay({ event, onDone }: { event: ChampionshipFxEvent | null; onDone: () => void }) {
  const fxRef = useRef<HTMLDivElement>(null)
  const [phase, setPhase] = useState<'idle' | 'playing'>('idle')
  const playingId = useRef<string | null>(null)

  const reduced = typeof window !== 'undefined'
    && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

  const finish = useCallback(() => {
    setPhase('idle')
    onDone()
  }, [onDone])

  useEffect(() => {
    if (!event || !fxRef.current || playingId.current === event.id) return
    playingId.current = event.id

    const node = fxRef.current
    const keys = event.animationKeys.length ? event.animationKeys : ['buster_crack']
    const per = Math.max(600, 1400 / keys.length)
    let cancelled = false
    const timers: number[] = []

    setPhase('playing')

    keys.forEach((key, i) => {
      timers.push(window.setTimeout(() => {
        if (cancelled) return
        node.innerHTML = (BUILD[key] ?? FALLBACK)()
        node.classList.remove('pvpfx-go')
        void node.offsetWidth
        node.classList.add('pvpfx-go')
      }, i * per))
    })

    timers.push(window.setTimeout(() => {
      if (cancelled) return
      node.classList.remove('pvpfx-go')
      node.innerHTML = ''
      playingId.current = null
      finish()
    }, keys.length * per + 300))

    return () => {
      cancelled = true
      for (const t of timers) window.clearTimeout(t)
    }
  }, [event, finish])

  if (!event) return null

  const speed = reduced ? 0.6 : 1

  return (
    <div
      className="pvp-overlay"
      data-reduced={reduced ? 'true' : 'false'}
      data-juice={reduced ? 'false' : 'true'}
      style={{ ['--pvp-speed' as string]: speed }}
      aria-live="polite"
    >
      <div className="pvpfx-fx" ref={fxRef} />

      {phase === 'playing' && (
        <div style={{ position: 'absolute', left: 0, right: 0, top: '18%', textAlign: 'center', pointerEvents: 'none' }}>
          <p style={{ fontSize: 13, fontWeight: 700, letterSpacing: 0.4, color: 'rgba(255,255,255,0.82)', textShadow: '0 2px 14px rgba(0,0,0,0.8)' }}>
            {event.selfBuff
              ? 'Card played'
              : event.incoming
                ? `${event.attackerName ?? 'Opponent'} attacked`
                : 'Attack landed'}
          </p>
          {event.selfBuff && typeof event.healed === 'number' && event.healed > 0 && (
            <p style={{ fontSize: 46, fontWeight: 800, marginTop: 4, color: '#5ce39b', textShadow: '0 3px 22px rgba(0,0,0,0.8)' }}>
              +{event.healed}
            </p>
          )}
          {!event.selfBuff && event.damage > 0 && (
            <p style={{ fontSize: 46, fontWeight: 800, marginTop: 4, color: event.incoming ? '#ff6b85' : '#fff', textShadow: '0 3px 22px rgba(0,0,0,0.8)' }}>
              −{event.damage}
            </p>
          )}
        </div>
      )}
    </div>
  )
}
