// src/features/championship/ChampionshipMatchSheet.tsx
//
// /championship/my-match — the actual fight screen. Every number here
// (damage, cooldown remaining, HP) comes back from the server on each
// action; this component never computes combat math itself, it just
// renders whatever championship_attack / championship_use_consumable /
// championship_combo_attack returns and re-derives cooldown countdowns
// from the battle log between actions.
//
// Match/log state comes from useSpectateMatch — the same realtime hook
// ChampionshipSpectateSheet uses — rather than a one-shot fetch. This
// used to only refetch after your OWN action, which meant an opponent's
// move was invisible on your screen until you left and came back. Reusing
// the hook fixes that for both players, not just for spectators.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Swords, Shield as ShieldIcon, ShieldCheck, Zap, Crown, Hourglass, Check, X } from 'lucide-react'
import { playPvpAttack } from '../games/sfx'
import { usePageHeader } from '../../context/PageHeader'
import { useAuth } from '../auth/useAuth'
import { ripple } from '../../shared/lib/ripple'
import Toast, { useToast } from '../../shared/components/Toast'
import { useSpectateMatch } from './useSpectateMatch'
import { useChampionshipFxChannel } from './useChampionshipFxChannel'
import ChampionshipEffectOverlay, { type ChampionshipFxEvent } from './ChampionshipEffectOverlay'
import './championship-arena.css'
import {
  getCurrentSeason, getMyCurrentMatch, getMyLoadout, getChampionshipCardPool, getProfilesByIds,
  championshipAttack, championshipUseConsumable, championshipComboAttack, championshipComboAttack2,
  championshipClaimDefaultWin, championshipDismissMatchBanner, championshipErrorMessage,
  type ChampionshipSeason, type ChampionshipLoadout, type ChampionshipCard, type ChampionshipAttackLogRow,
  type ChampionshipProfileLite,
} from './championship'

const DEFAULT_LIVE_HP = 750

function cooldownRemaining(card: ChampionshipCard, log: ChampionshipAttackLogRow[], myId: string): number {
  if (!card.cooldown_minutes) return 0
  // Was `&& !l.is_combo` — that silently ignored the three attack rows a
  // Combo writes (one per card, see championship_combo_attack), so every
  // card in a just-used combo showed "Ready" here while the server's own
  // cooldown check (max(created_at) across ALL championship_attacks rows
  // for that card, combo or not) correctly still blocked it. Matching the
  // server means counting every row, same as a single attack does.
  const last = log.find(l => l.attacker_id === myId && l.card_key === card.card_key)
  if (!last) return 0
  const readyAt = new Date(last.created_at).getTime() + card.cooldown_minutes * 60_000
  return Math.max(0, readyAt - Date.now())
}

function formatDuration(ms: number): string {
  const h = Math.floor(ms / 3_600_000)
  const m = Math.floor((ms % 3_600_000) / 60_000)
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m`
  return 'a moment'
}

// Fans the hand like you'd hold real cards: the middle card sits highest and
// upright, the outer ones angle away and drop slightly. Computed rather than
// fixed CSS classes so it still centers correctly with 1 or 2 cards, not
// just the usual 3.
function fanTransform(i: number, total: number): { rotate: number; lift: number } {
  const mid = (total - 1) / 2
  const offset = i - mid
  return { rotate: offset * 7, lift: Math.abs(offset) * 9 }
}

export default function ChampionshipMatchSheet() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast, showToast } = useToast()

  const [season, setSeason] = useState<ChampionshipSeason | null>(null)
  const [matchId, setMatchId] = useState<string | null>(null)
  const [loadout, setLoadout] = useState<ChampionshipLoadout | null>(null)
  const [pool, setPool] = useState<ChampionshipCard[]>([])
  const [profiles, setProfiles] = useState<Map<string, ChampionshipProfileLite>>(new Map())
  const [loading, setLoading] = useState(true)
  const [noMatch, setNoMatch] = useState(false)
  const [acting, setActing] = useState<string | null>(null)
  const [now, setNow] = useState(() => Date.now())
  const [fxEvent, setFxEvent] = useState<ChampionshipFxEvent | null>(null)
  const fxSeq = useRef(0)
  // Brief "Surged" flash on the card whose cooldown Surge just cleared —
  // cleared automatically after a couple seconds. Card key, not a boolean,
  // since it has to land on the specific card, not just "something surged".
  const [surgedFlash, setSurgedFlash] = useState<string | null>(null)
  // Which of your OWN ready cards are picked for the next attack — 1 selected
  // is a plain hit, 2 is the plain-additive combo, 3 is the once-per-match
  // bonus combo. Cleared on every successful/failed submit and whenever the
  // turn flips away from you (see the effect below).
  const [selectedCards, setSelectedCards] = useState<string[]>([])
  const [claiming, setClaiming] = useState(false)
  // Optimistic hide the instant the user taps dismiss — banner_dismissed_by
  // will also reflect this once the RPC round-trips, but there's no reason
  // to wait on that for the UI to respond.
  const [nudgeLocallyDismissed, setNudgeLocallyDismissed] = useState(false)

  const { match, log } = useSpectateMatch(matchId)

  usePageHeader({ title: 'Your match', onBack: () => navigate('/championship') })

  const load = useCallback(async () => {
    if (!user) return
    const s = await getCurrentSeason()
    if (!s) { setLoading(false); return }
    const m = await getMyCurrentMatch(s.id, s.current_round, user.id)
    setSeason(s)
    if (!m) { setNoMatch(true); setLoading(false); return }
    const [lo, cardPool, profileMap] = await Promise.all([
      getMyLoadout(s.id, user.id),
      getChampionshipCardPool(),
      getProfilesByIds([m.player_a, m.player_b].filter((v): v is string => !!v)),
    ])
    setMatchId(m.id); setLoadout(lo); setPool(cardPool); setProfiles(profileMap)
    setLoading(false)
  }, [user])

  useEffect(() => { load() }, [load])
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id) }, [])
  useEffect(() => { setNudgeLocallyDismissed(false) }, [matchId])

  const mySide: 'a' | 'b' | null = useMemo(() => {
    if (!match || !user) return null
    if (match.player_a === user.id) return 'a'
    if (match.player_b === user.id) return 'b'
    return null
  }, [match, user])

  // A null match.turn (pre-turn-system rows, or a bye) means either side may
  // act — see the ChampionshipMatch.turn doc comment in championship.ts.
  const myTurn = useMemo(() => !match || match.turn === null || match.turn === mySide, [match, mySide])
  const turnDeadlineMs = match?.turn_deadline_at ? new Date(match.turn_deadline_at).getTime() : null
  const canClaimDefault = !!match && !myTurn && turnDeadlineMs !== null && now >= turnDeadlineMs

  // If the turn flips away from you (opponent's move landed, or the match
  // otherwise moved on) drop whatever you had half-picked — the selection
  // is no longer actionable and would just silently fail with not_your_turn.
  useEffect(() => { if (!myTurn) setSelectedCards([]) }, [myTurn])

  const isLiveRound = useMemo(() => {
    if (!match || !season?.round_count) return false
    return match.round_number >= season.round_count - 1
  }, [match, season])

  const maxHp = useMemo(() => {
    if (isLiveRound) return season?.ruleset.live_round_hp ?? DEFAULT_LIVE_HP
    return season?.ruleset.match_hp ?? 500
  }, [isLiveRound, season])

  // Genuinely-live sync — only wired up for Semifinal/Final (see the
  // hook's own header comment for why earlier rounds don't get this).
  const { broadcastAttack } = useChampionshipFxChannel(isLiveRound ? matchId : null, (msg) => {
    if (!match || msg.attackerId === user?.id) return
    const oppId = mySide === 'a' ? match.player_b : match.player_a
    const oppProfile = oppId ? profiles.get(oppId) : null
    fxSeq.current += 1
    setFxEvent({
      id: `live-${fxSeq.current}`,
      animationKeys: msg.animationKeys,
      damage: msg.damage,
      incoming: true,
      attackerName: oppProfile?.display_name || oppProfile?.username || 'Opponent',
      selfBuff: msg.selfBuff,
      healed: msg.healed,
    })
  })

  const myCards = useMemo(
    () => (loadout?.card_keys ?? []).map(k => pool.find(c => c.card_key === k)).filter((c): c is ChampionshipCard => !!c),
    [loadout, pool]
  )
  const myConsumables = useMemo(
    () => (loadout?.consumable_keys ?? []).map(k => pool.find(c => c.card_key === k)).filter((c): c is ChampionshipCard => !!c),
    [loadout, pool]
  )
  const usedThisMatch = useMemo(() => new Set(log.filter(l => l.attacker_id === user?.id).map(l => l.card_key)), [log, user])

  async function runAction(
    key: string,
    fn: () => Promise<
      | { animation_keys: string[]; damage_dealt?: number }
      | { used: string; animation_keys: string[] }
      | { combo_damage: number; attacks: { animation_keys: string[] }[] }
    >,
    // Only set for the Surge consumable — which OTHER card on your board
    // just had its cooldown cleared. runAction only knows the action key
    // ('surge'), not which card it was aimed at, so the click handler
    // passes it through explicitly.
    surgeTargetKey?: string,
  ) {
    if (acting || !match) return
    setActing(key)
    try {
      const result = await fn()
      const isCombo = 'attacks' in result
      const animationKeys = isCombo ? result.attacks.flatMap(a => a.animation_keys) : result.animation_keys
      const damage = isCombo ? result.combo_damage : ('damage_dealt' in result ? result.damage_dealt ?? 0 : 0)
      // Second Wind / Shield / Surge are self-targeted — they never deal
      // damage to the opponent, so they play as a "buff" locally rather
      // than an "attack". Shield Buster is NOT in this list: it occupies
      // a consumable slot but is a real damage-dealing attack card
      // server-side (see the button handler below), so it broadcasts and
      // renders exactly like any other attack card.
      const selfBuff = key === 'second_wind' || key === 'shield' || key === 'surge'
      const healed = key === 'second_wind' ? 100 : undefined
      // Mirrors AttackSheet.tsx's playPvpAttack() call on the attacker's
      // own action — PvP plays this for every resolved card, buffs
      // included, not just damage-dealing ones, and Championship had
      // nothing here at all.
      playPvpAttack()
      fxSeq.current += 1
      setFxEvent({
        id: `mine-${fxSeq.current}`,
        animationKeys: animationKeys.length ? animationKeys : ['buster_crack'],
        damage,
        incoming: false,
        selfBuff,
        healed,
      })
      // Everyone watching live (opponent + spectators) sees the same play,
      // in sync — see useChampionshipFxChannel's header comment for why
      // this travels separately from the HP/log realtime data. Self-buffs
      // now broadcast too: a Shield going up is exactly the kind of thing
      // an opponent needs to see land, the same way PvP's Shielded status
      // is visible to everyone, not just the person holding it.
      if (isLiveRound) {
        broadcastAttack({ attackerId: user!.id, animationKeys, damage, selfBuff, healed })
      }
      if (surgeTargetKey) {
        setSurgedFlash(surgeTargetKey)
        window.setTimeout(() => setSurgedFlash(cur => (cur === surgeTargetKey ? null : cur)), 2500)
      }
    } catch (err) {
      showToast({ message: championshipErrorMessage(err), icon: Swords })
    } finally {
      setActing(null)
    }
  }

  // Routes the current selection to the right RPC: 1 card is a plain attack,
  // 2 is the plain-additive combo, 3 is the once-per-match bonus combo.
  function submitAttack() {
    if (!match || selectedCards.length === 0 || acting) return
    const cards = selectedCards
    const key = cards.join('+')
    setSelectedCards([])
    if (cards.length === 1) {
      runAction(key, () => championshipAttack(match.id, cards[0]))
    } else if (cards.length === 2) {
      runAction(key, () => championshipComboAttack2(match.id, cards[0], cards[1]))
    } else {
      runAction(key, () => championshipComboAttack(match.id))
    }
  }

  function toggleCardSelection(cardKey: string, comboUsed: boolean) {
    setSelectedCards(cur => {
      if (cur.includes(cardKey)) return cur.filter(k => k !== cardKey)
      const maxPick = comboUsed ? 2 : 3
      if (cur.length >= maxPick) return cur
      return [...cur, cardKey]
    })
  }

  async function claimDefaultWin() {
    if (!match || claiming) return
    setClaiming(true)
    try {
      await championshipClaimDefaultWin(match.id)
    } catch (err) {
      showToast({ message: championshipErrorMessage(err), icon: Hourglass })
    } finally {
      setClaiming(false)
    }
  }

  // Best-effort: the banner hides immediately regardless of whether the RPC
  // succeeds, since re-showing a dismissed nudge on a network blip would be
  // more annoying than the rare case of it reappearing after a refresh.
  function dismissNudgeBanner() {
    if (!match) return
    setNudgeLocallyDismissed(true)
    void championshipDismissMatchBanner(match.id).catch(() => {})
  }

  if (loading) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>
  if (!season || season.status !== 'active') return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>No live match right now.</div>
  if (noMatch || !match || !mySide) return <div className="neu-card" style={{ margin: 16, padding: 24, textAlign: 'center', color: 'var(--text-muted)' }}>You don’t have a match this round.</div>

  const myHp = mySide === 'a' ? match.hp_a : match.hp_b
  const oppHp = mySide === 'a' ? match.hp_b : match.hp_a
  const myAttacksUsed = mySide === 'a' ? match.attacks_used_a : match.attacks_used_b
  const comboUsed = mySide === 'a' ? match.combo_used_a : match.combo_used_b
  const oppId = mySide === 'a' ? match.player_b : match.player_a
  const myId = mySide === 'a' ? match.player_a : match.player_b
  const myProfile = myId ? profiles.get(myId) : null
  const oppProfile = oppId ? profiles.get(oppId) : null
  // Shield is the one Championship effect that's actually mechanically
  // real (see championship_attack/championship_use_consumable) but had no
  // visual anywhere — status_effects.shield_a / shield_b is set the moment
  // the consumable is used and cleared the moment it absorbs a hit (or
  // gets stripped by Shield Buster), so reading it live is enough; no
  // separate expiry countdown to track.
  const effects = match.status_effects as Record<string, unknown> | null
  const myShielded = !!effects?.[`shield_${mySide}`]
  const oppShielded = !!effects?.[`shield_${mySide === 'a' ? 'b' : 'a'}`]

  if (match.status === 'completed') {
    const won = match.winner_id === user?.id
    return (
      <div style={{ maxWidth: 560, margin: '0 auto', padding: 16 }}>
        <div className="neu-card" style={{ padding: 28, textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
          {won && (
            <div className="cv-disc cv-disc--active" style={{ width: 72, height: 72, margin: '0 auto 14px' }}>
              <Crown size={30} color="var(--gold)" />
            </div>
          )}
          {!won && <Swords size={32} color="var(--text-muted)" style={{ marginBottom: 10 }} />}
          <div style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)' }}>{won ? 'You won this round' : match.winner_id ? 'Eliminated' : 'Double no-show — both eliminated'}</div>
          <button onClick={(e) => { ripple(e); navigate('/championship') }} className="ripple-wrap" style={{ marginTop: 16, border: 'none', borderRadius: 11, padding: '10px 18px', fontSize: 12.5, fontWeight: 700, color: '#fff', background: 'var(--accent)', cursor: 'pointer', position: 'relative', overflow: 'hidden' }}>
            Back to Championship
          </button>
        </div>
      </div>
    )
  }

  const msLeft = match.round_ends_at ? Math.max(0, new Date(match.round_ends_at).getTime() - now) : 0

  // Whether *I* had thrown an attack by the time the halfway-point nudge
  // fired decides which framing I get — see mid_round_nudge_idle/active in
  // the copy bank. Kept purely client-side (rather than reading the exact
  // notification row) so it stays in sync with the log realtime already
  // driving the rest of this screen.
  const iHadAttacked = log.some(l => l.attacker_id === myId)
  const nudgeDismissedByMe = !!(myId && match.banner_dismissed_by?.[myId])
  const showNudgeBanner = !!match.mid_round_nudge_sent_at && !nudgeDismissedByMe && !nudgeLocallyDismissed

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 16px 48px' }}>
      <div style={{ textAlign: 'center', fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', padding: '10px 0 2px' }}>
        Round {match.round_number} · ends in {formatDuration(msLeft)}
      </div>

      {showNudgeBanner && (
        <div
          className="cv-turn-banner"
          style={{
            marginTop: 8,
            background: iHadAttacked ? 'rgba(255,255,255,0.04)' : 'linear-gradient(135deg,rgba(255,77,109,0.16),rgba(255,154,60,0.12))',
            border: iHadAttacked ? undefined : '1px solid rgba(255,77,109,0.35)',
          }}
        >
          <span style={{ fontSize: 11.5, fontWeight: 800, color: iHadAttacked ? 'var(--text-secondary)' : 'var(--danger, #ff4d6d)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Hourglass size={13} />
            {iHadAttacked ? "Keep the pressure on — the clock's still running on both of you." : "Half the clock's gone and you haven't thrown a punch. Attack now."}
          </span>
          <button
            onClick={(e) => { ripple(e); dismissNudgeBanner() }}
            aria-label="Dismiss"
            className="ripple-wrap"
            style={{ border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', padding: 4, position: 'relative', overflow: 'hidden', flexShrink: 0 }}
          >
            <X size={14} />
          </button>
        </div>
      )}

      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, padding: '10px 0 4px' }}>
        <DuelFighter
          name={myProfile?.display_name || myProfile?.username || 'You'} avatar={myProfile?.avatar ?? null}
          hp={myHp} maxHp={maxHp} color="var(--accent)" mine active={myTurn} shielded={myShielded}
        />
        <div style={{ paddingTop: 18, fontSize: 10.5, fontWeight: 800, color: 'var(--text-muted)', flexShrink: 0 }}>VS</div>
        <DuelFighter
          name={oppProfile?.display_name || oppProfile?.username || 'Opponent'} avatar={oppProfile?.avatar ?? null}
          hp={oppHp} maxHp={maxHp} color="var(--danger, #ff4d6d)" active={!myTurn} shielded={oppShielded}
        />
      </div>

      <div className={`cv-turn-banner ${canClaimDefault ? 'cv-turn-banner--claim' : myTurn ? 'cv-turn-banner--yours' : ''}`} style={{ marginTop: 10 }}>
        {canClaimDefault ? (
          <>
            <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Opponent never attacked back</span>
            <button
              onClick={(e) => { ripple(e); claimDefaultWin() }}
              disabled={claiming}
              className="ripple-wrap"
              style={{ border: 'none', borderRadius: 20, padding: '7px 13px', fontSize: 10.5, fontWeight: 800, color: '#241934', background: 'linear-gradient(135deg,var(--gold),#ff9a3c)', cursor: claiming ? 'default' : 'pointer', position: 'relative', overflow: 'hidden', flexShrink: 0 }}
            >
              {claiming ? '…' : 'Claim win by default'}
            </button>
          </>
        ) : myTurn ? (
          <>
            <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--gold)', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Swords size={13} /> Your move
            </span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 700 }}>{myAttacksUsed}/{season.ruleset.max_attacks_per_match} attacks used</span>
          </>
        ) : (
          <>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Hourglass size={12} color="var(--text-muted)" /> Waiting on opponent
            </span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 700 }}>{turnDeadlineMs ? `${formatDuration(Math.max(0, turnDeadlineMs - now))} left` : ''}</span>
          </>
        )}
      </div>

      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', margin: '18px 0 4px' }}>
        Your hand {selectedCards.length > 0 && `· ${selectedCards.length} staged`}
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 6, padding: '10px 4px 4px' }}>
        {myCards.map((card, i) => {
          const remaining = cooldownRemaining(card, log, user!.id)
          const ready = remaining === 0
          const justSurged = surgedFlash === card.card_key
          const selected = selectedCards.includes(card.card_key)
          const selectable = ready && myTurn && acting === null
          const { rotate, lift } = fanTransform(i, myCards.length)
          return (
            <button
              key={card.card_key}
              onClick={(e) => { if (selectable) { ripple(e); toggleCardSelection(card.card_key, comboUsed) } }}
              disabled={!selectable}
              className={`neu-card ripple-wrap cv-hand-card ${selected ? 'cv-hand-card--selected' : ''}`}
              style={{
                padding: '12px 7px', textAlign: 'center', width: 92, flexShrink: 0,
                transform: selected ? undefined : `rotate(${rotate}deg) translateY(${lift}px)`,
                transformOrigin: 'bottom center', zIndex: selected ? 5 : 10 - Math.abs(i - (myCards.length - 1) / 2),
                border: selected ? '1.5px solid var(--gold)' : justSurged ? '1.5px solid #4f8ef7' : ready ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                boxShadow: selected ? '0 6px 20px -4px color-mix(in srgb, var(--gold) 45%, transparent)' : justSurged ? '0 0 0 1px rgba(79,142,247,0.4), 0 0 16px rgba(79,142,247,0.35)' : undefined,
                opacity: ready ? 1 : 0.6, cursor: selectable ? 'pointer' : 'default', position: 'relative', overflow: 'hidden',
                ...(card.image_url ? {
                  backgroundImage: `linear-gradient(180deg, rgba(15,9,26,0.1) 0%, rgba(15,9,26,0.85) 75%), url(${card.image_url})`,
                  backgroundSize: 'cover', backgroundPosition: 'center',
                } : {}),
              }}
            >
              {selected && (
                <span style={{
                  position: 'absolute', top: 4, left: 4, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  width: 15, height: 15, borderRadius: '50%', background: 'var(--gold)', color: '#241934',
                }}>
                  <Check size={10} strokeWidth={3} />
                </span>
              )}
              {justSurged && (
                <span style={{
                  position: 'absolute', top: 4, right: 4, display: 'flex', alignItems: 'center', gap: 2,
                  fontSize: 7.5, fontWeight: 800, color: '#fff', background: '#4f8ef7', padding: '2px 5px', borderRadius: 8,
                }}>
                  <Zap size={8} /> Surged
                </span>
              )}
              <div style={{ fontSize: 10.5, fontWeight: 700, color: card.image_url ? '#fbf6ff' : 'var(--text)' }}>{card.display_name}</div>
              <div style={{ fontSize: 9, color: ready ? 'var(--green, #3ecf8e)' : 'var(--text-muted)', marginTop: 4, fontWeight: 700 }}>
                {ready ? (selected ? 'Staged' : 'Ready') : formatDuration(remaining)}
              </div>
              <div style={{ fontSize: 8.5, color: card.image_url ? '#c3b6e0' : 'var(--text-muted)', marginTop: 2 }}>{card.damage} dmg</div>
            </button>
          )
        })}
      </div>

      {selectedCards.length > 0 && (
        <button
          onClick={(e) => { ripple(e); submitAttack() }}
          disabled={acting !== null}
          className={`ripple-wrap cv-attack-btn ${acting === null ? 'cv-attack-btn--armed' : ''}`}
          style={{
            width: '100%', marginTop: 14, padding: '13px 15px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            borderRadius: 12, border: '1px solid color-mix(in srgb, var(--gold) 35%, transparent)',
            background: 'linear-gradient(120deg, color-mix(in srgb, var(--gold) 16%, var(--surface)), color-mix(in srgb, var(--accent) 12%, var(--surface)))',
            cursor: acting ? 'default' : 'pointer', position: 'relative', overflow: 'hidden',
          }}
        >
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--gold)' }}>
              {selectedCards.length === 1 ? 'Single attack' : selectedCards.length === 2 ? '2-card combo' : '3-card combo'}
            </div>
            <div style={{ fontSize: 9.5, color: 'var(--text-secondary)' }}>
              {selectedCards.length === 3 ? `Once per match · +${season.ruleset.combo_bonus_pct}% damage` : selectedCards.length === 2 ? 'Damage adds up · no bonus, no combo cooldown' : 'Normal per-card cooldown applies'}
            </div>
          </div>
          <span style={{ fontSize: 10.5, fontWeight: 800, background: 'linear-gradient(135deg,var(--gold),#ff9a3c)', color: '#241934', padding: '8px 15px', borderRadius: 20, flexShrink: 0 }}>
            {acting !== null ? '…' : 'Commit'}
          </span>
        </button>
      )}

      {myConsumables.length > 0 && (
        <>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', margin: '16px 0 8px' }}>Consumables</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            {myConsumables.map(card => {
              const used = usedThisMatch.has(card.card_key)
              // shield_buster is the one consumable that's actually a
              // damage-dealing attack under the hood (championship_attack),
              // so unlike second_wind/shield/surge it IS subject to the turn
              // check — using it off-turn would just bounce off the server.
              const turnLocked = card.card_key === 'shield_buster' && !myTurn
              const disabled = used || turnLocked || acting !== null
              return (
                <button
                  key={card.card_key}
                  onClick={(e) => {
                    if (disabled) return
                    ripple(e)
                    if (card.card_key === 'surge') {
                      const target = myCards.find(c => cooldownRemaining(c, log, user!.id) > 0)
                      if (!target) { showToast({ message: 'None of your cards are on cooldown right now.', icon: Zap }); return }
                      runAction('surge', () => championshipUseConsumable(match.id, 'surge', target.card_key), target.card_key)
                    } else if (card.card_key === 'shield_buster') {
                      // Shield Buster occupies a consumable slot, but it's a real
                      // damage-dealing attack card server-side (championship_attack
                      // has a dedicated shield-strip branch for it) and counts
                      // against the match's attack budget like any other card.
                      // championship_use_consumable's allow-list never included it
                      // — routing it there always threw invalid_consumable.
                      runAction(card.card_key, () => championshipAttack(match.id, 'shield_buster'))
                    } else {
                      runAction(card.card_key, () => championshipUseConsumable(match.id, card.card_key as 'second_wind' | 'shield'))
                    }
                  }}
                  disabled={disabled}
                  className="neu-card ripple-wrap"
                  style={{ padding: '10px 6px', textAlign: 'center', opacity: disabled ? 0.5 : 1, cursor: disabled ? 'default' : 'pointer', position: 'relative', overflow: 'hidden' }}
                >
                  <ShieldIcon size={14} color="var(--blue)" style={{ marginBottom: 4 }} />
                  <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text)' }}>{card.display_name}</div>
                  <div style={{ fontSize: 8.5, color: used ? 'var(--text-muted)' : 'var(--green, #3ecf8e)', marginTop: 3, fontWeight: 700 }}>
                    {acting === card.card_key ? '…' : used ? 'Used' : turnLocked ? 'Not your turn' : 'Ready · 1 use'}
                  </div>
                </button>
              )
            })}
          </div>
        </>
      )}

      <div className="neu-card" style={{ marginTop: 16, padding: '11px 13px' }}>
        <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 7 }}>Battle log</div>
        {log.length === 0 && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>No attacks yet.</div>}
        {log.slice(0, 8).map(l => {
          const mine = l.attacker_id === user?.id
          return (
            <div key={l.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, padding: '4px 0', borderTop: '1px solid var(--border)' }}>
              <span style={{ color: 'var(--text-secondary)' }}>
                {mine ? 'You' : (oppProfile?.display_name || oppProfile?.username || 'Opponent')} used {l.card_key.replace(/_/g, ' ')}{l.is_combo ? ' (combo)' : ''}
              </span>
              {l.damage > 0 && <b style={{ color: mine ? 'var(--gold)' : 'var(--danger, #ff4d6d)' }}>-{l.damage}</b>}
            </div>
          )
        })}
      </div>

      <Toast toast={toast} />
      <ChampionshipEffectOverlay event={fxEvent} onDone={() => setFxEvent(null)} />
    </div>
  )
}

function DuelFighter({ name, avatar, hp, maxHp, color, mine, shielded, active }: { name: string; avatar?: string | null; hp: number; maxHp: number; color: string; mine?: boolean; shielded?: boolean; active?: boolean }) {
  const pct = maxHp > 0 ? Math.max(0, Math.min(100, (hp / maxHp) * 100)) : 0
  const initial = name.trim().charAt(0).toUpperCase() || '?'
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: mine ? 'row' : 'row-reverse', alignItems: 'center', gap: 8 }}>
      <div
        className={`cv-disc ${active ? 'cv-disc--active' : 'cv-disc--waiting'}`}
        style={avatar ? { backgroundImage: `url(${avatar})`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined}
      >
        {!avatar && <span style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)' }}>{initial}</span>}
      </div>
      <div style={{ flex: 1, textAlign: mine ? 'left' : 'right' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, justifyContent: mine ? 'flex-start' : 'flex-end', flexWrap: 'wrap' }}>
          <div style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text)' }}>{name}</div>
          {shielded && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 3, padding: '2px 6px', borderRadius: 20,
              fontSize: 8.5, fontWeight: 800, color: 'var(--gold)', background: 'color-mix(in srgb, var(--gold) 16%, transparent)',
              border: '1px solid color-mix(in srgb, var(--gold) 35%, transparent)',
            }}>
              <ShieldCheck size={9} /> Shielded
            </span>
          )}
        </div>
        <div style={{ height: 8, borderRadius: 4, background: 'var(--surface2)', border: '1px solid var(--border)', overflow: 'hidden', marginTop: 6 }}>
          <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 4, marginLeft: mine ? 0 : 'auto', transition: 'width 0.4s ease' }} />
        </div>
        <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 3, fontWeight: 700 }}>{hp} / {maxHp}</div>
      </div>
    </div>
  )
}
