// src/features/championship/useChampionshipFxChannel.ts
//
// Genuinely-live attack-effect sync for Semifinal/Final matches — the
// piece that makes an incoming hit show up on the opponent's (and any
// spectator's) screen the instant it happens, rather than "next time
// they refresh". This is deliberately NOT built on the championship_attacks
// realtime subscription already used elsewhere (useSpectateMatch): that
// path exists to keep HP/log data correct, which is a "table changed"
// fact worth persisting and worth catching up on later. A one-shot
// full-screen particle effect is neither — nobody needs to be told
// "you missed watching an explosion" on reconnect — so it travels over
// an ephemeral Realtime broadcast channel instead, same idiom as
// impostor/breath.ts's card-flip sync.
//
// Only wired up for Semifinal/Final rounds (see ChampionshipMatchSheet /
// ChampionshipSpectateSheet): earlier rounds resolve asynchronously over
// hours with no one watching live, so there's nothing for a broadcast
// channel to usefully do there.
import { useEffect, useRef } from 'react'
import { supabase } from '../../shared/lib/supabase'

export interface ChampionshipFxMessage {
  attackerId: string
  animationKeys: string[]
  damage: number
  selfBuff?: boolean
  healed?: number
}

export function useChampionshipFxChannel(matchId: string | null, onAttack: (msg: ChampionshipFxMessage) => void) {
  const onAttackRef = useRef(onAttack)
  onAttackRef.current = onAttack

  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)

  useEffect(() => {
    if (!matchId) return
    const ch = supabase
      .channel(`championship-fx:${matchId}`, { config: { broadcast: { self: false } } })
      .on('broadcast', { event: 'attack' }, ({ payload }) => {
        onAttackRef.current(payload as ChampionshipFxMessage)
      })
      .subscribe()
    channelRef.current = ch
    return () => {
      supabase.removeChannel(ch)
      channelRef.current = null
    }
  }, [matchId])

  function broadcastAttack(msg: ChampionshipFxMessage) {
    channelRef.current?.send({ type: 'broadcast', event: 'attack', payload: msg })
  }

  return { broadcastAttack }
}
