// src/features/badges/ChampionshipBadgeModal.tsx
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'
import { badgeDisplayTitle, type BadgeDef } from './badges'
import { championshipBadgeSrc } from './ChampionshipBadge'

function formatUnlockedDate(iso: string): string {
  return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
}

// Opened by tapping a badge in the profile's Championship trophy case
// (Profile.tsx / ProfilePreviewModal.tsx) — shows just THIS badge, big,
// with no card/banner behind the artwork itself. Deliberately not the
// full BadgesModal catalog: championship badges are special and don't
// live alongside the regular collection (see isChampionshipBadge in
// badges.ts), so there's nothing else to browse to from here.
export default function ChampionshipBadgeModal({
  def, unlockedAt, seasonNumber, originalUsername, onClose,
}: {
  def: BadgeDef
  unlockedAt: string | null
  seasonNumber?: number | null
  originalUsername: string
  onClose: () => void
}) {
  const src = championshipBadgeSrc(def.id)

  return createPortal(
    <div
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 20200, padding: 20 }}
      onClick={onClose}
    >
      <div className="neu-card" style={{ width: '100%', maxWidth: 320, padding: '28px 20px 22px', position: 'relative', textAlign: 'center' }} onClick={e => e.stopPropagation()}>
        <button
          type="button"
          onClick={onClose}
          style={{ position: 'absolute', top: 12, right: 12, background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer' }}
        >
          <X size={16} />
        </button>

        {src && (
          <img src={src} alt={def.title} width={200} height={138} style={{ display: 'block', margin: '0 auto 14px', objectFit: 'contain' }} />
        )}

        <p style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>
          {badgeDisplayTitle(def, originalUsername)}
        </p>
        {seasonNumber != null && (
          <p style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--gold, #f5c542)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.4 }}>
            Season {seasonNumber}
          </p>
        )}
        {unlockedAt && (
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-dim)', marginBottom: def.description ? 14 : 0 }}>
            Unlocked {formatUnlockedDate(unlockedAt)}
          </p>
        )}
        {def.description && (
          <p style={{ fontSize: 12.5, color: 'var(--text-dim)', lineHeight: 1.5 }}>{def.description}</p>
        )}
      </div>
    </div>,
    document.body,
  )
}
