// src/features/badges/ChampionshipBadge.tsx
//
// The Championship Champion/Runner-Up/3rd-Place badges use real artwork
// rather than a generic Lucide glyph, same reasoning and same pattern as
// the Orbit/Void loyalty badge in ProBadge.tsx: the `badges` table still
// carries ordinary catalog rows for these ids ('championship_champion' /
// 'championship_runnerup' / 'championship_third_place') so they work
// everywhere a normal badge does (BadgeRow, BadgesDex, BadgesModal,
// BadgeQuickSheet, player_badges FK) — but any place that renders one by
// id should check championshipBadgeSrc() FIRST and use the real artwork
// instead of the generic per-badge icon glyph. See ProBadge.tsx's header
// comment for the fuller rationale; this mirrors it exactly rather than
// inventing a second convention.
//
// All three now have real art — the Season 01 Champion/Runner-Up/3rd-Place
// shields the co-founder provided. The Runner-Up and 3rd-Place assets were
// originally flat black-background renders; they've been background-removed
// (flood-fill from the image borders, preserving the artwork's own internal
// dark plate/texture — see the processing note below) and re-exported as
// optimized transparent webp at the same ~512px height as the Champion art.
export function championshipBadgeSrc(badgeId: string): string | null {
  if (badgeId === 'championship_champion') return '/championship-badges/champion.webp'
  if (badgeId === 'championship_runnerup') return '/championship-badges/runnerup.webp'
  if (badgeId === 'championship_third_place') return '/championship-badges/thirdplace.webp'
  return null
}
