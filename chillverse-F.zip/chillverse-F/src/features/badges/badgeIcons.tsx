// src/features/badges/badgeIcons.tsx
import {
  Laptop, Gift, Target, Compass, UserCircle2, Sparkles,
  Shield, Star, Crown, BadgeCheck, Megaphone, Orbit, Moon, Gem,
  HandMetal, Anchor, Medal, Skull } from 'lucide-react'
import type React from 'react'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type LucideIcon = React.ComponentType<any>

/**
 * A real clenched fist, drawn here rather than imported.
 *
 * lucide gained `hand-fist` in 1.x and this project is pinned to 0.487,
 * where it does not exist — so the 'hand-fist' key below used to alias
 * HandMetal, meaning any badge on that key rendered as rock-horns 🤘
 * instead of a fist. Upgrading lucide for one glyph would touch ~200
 * imports across the app, so the node is inlined instead. Paths are
 * lucide's own (ISC), and the stroke props match every other icon in the
 * set so it sits correctly beside them at any size.
 */
function HandFist({ size = 16, ...rest }: { size?: number } & React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth={2}
      strokeLinecap="round" strokeLinejoin="round"
      {...rest}
    >
      <path d="M12.035 17.012a3 3 0 0 0-3-3l-.311-.002a.72.72 0 0 1-.505-1.229l1.195-1.195A2 2 0 0 1 10.828 11H12a2 2 0 0 0 0-4H9.243a3 3 0 0 0-2.122.879l-2.707 2.707A4.83 4.83 0 0 0 3 14a8 8 0 0 0 8 8h2a8 8 0 0 0 8-8V7a2 2 0 1 0-4 0v2a2 2 0 1 0 4 0" />
      <path d="M13.888 9.662A2 2 0 0 0 17 8V5A2 2 0 1 0 13 5" />
      <path d="M9 5A2 2 0 1 0 5 5V10" />
      <path d="M9 7V4A2 2 0 1 1 13 4V7.268" />
    </svg>
  )
}

// Map icon key strings (stored in badges.icon) → Lucide components.
// Add new keys here whenever a new badge is introduced.
export const BADGE_ICON_MAP: Record<string, LucideIcon> = {
  'laptop': Laptop,
  'gift': Gift,
  'target': Target,
  'compass': Compass,
  'user-circle': UserCircle2,
  // Reserved for future manually-assigned badges (Admin, Founder, Verified, etc.)
  'shield': Shield,
  'star': Star,
  'crown': Crown,
  'badge-check': BadgeCheck,
  'megaphone': Megaphone,
  'orbit': Orbit,
  'moon': Moon,
  'gem': Gem,
  // Leaderboard / artifacts badges
  'hand-metal': HandMetal,
  'hand-fist': HandFist,  // real fist, inlined above — lucide 0.487 has none
  'anchor': Anchor,
  'sailboat': Anchor, // ditto — no sailboat icon in this lucide version
  'medal': Medal,
  // PvP Boss. This map is the badge-side twin of the two notification icon
  // maps: a badge whose icon key is missing here renders as Sparkles and
  // looks like somebody else's badge.
  'skull': Skull,
}

export function BadgeIcon({ iconKey, size = 16, color }: { iconKey: string; size?: number; color?: string }) {
  const Icon = BADGE_ICON_MAP[iconKey] ?? Sparkles
  return <Icon size={size} style={color ? { color } : undefined} />
}
