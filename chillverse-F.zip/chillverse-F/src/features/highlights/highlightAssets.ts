// src/features/highlights/highlightAssets.ts
//
// Custom Duolingo-style celebratory art, one per highlight kind that uses
// one. Transparent background, sized down to a restrained "sticker" size in
// the card (see HighlightCard.tsx) rather than shown full-bleed.
//
// map_complete uses the author's own profile pic (<Avatar>) instead, and
// leaderboard_badge uses the badge's own icon (<BadgeIcon>) — neither needs
// an entry here.
import furnaceFlame from '../../assets/streak-furnace.png'
import { MINO_SHARE_PNG } from '../mino/minoConfig'
import type { HighlightKind } from './types'

export const HIGHLIGHT_ILLUSTRATIONS: Partial<Record<HighlightKind, string>> = {
  xp_milestone: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Untitled%20folder/rocket_transparent.png',
  personal_best: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Untitled%20folder/target_transparent.png',
  streak_milestone: furnaceFlame,
  leaderboard_rank: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Untitled%20folder/trophy_transparent.png',
  mino_stage: MINO_SHARE_PNG,
}

// ─── Per-game overrides ───────────────────────────────────────
// Keyed by a game's dbKey (see games.ts). When a highlight carries a
// game_key that appears here, this art wins over the kind-based map
// above — so every highlight about that game (personal best, XP
// milestone, leaderboard rank, shared win) uses the game's own custom
// PNG instead of the generic rocket/target/trophy.
export const GAME_HIGHLIGHT_ILLUSTRATIONS: Record<string, string> = {
  the_last_samurai: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/file_00000000ec3c824390a3500b546304b2.png',
  elementa: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/Elementa.png',
  plunder: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/Pirate.png',
  word_blitz: 'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/WordBlitz.png',
}

/** The art to draw for a highlight — the game override first, then the
 *  kind-based default. Shared by HighlightCard and the share-card canvas
 *  so the in-app card and the exported PNG never disagree. */
export function highlightIllustration(kind: HighlightKind, gameKey?: string | null): string | undefined {
  if (gameKey && GAME_HIGHLIGHT_ILLUSTRATIONS[gameKey]) return GAME_HIGHLIGHT_ILLUSTRATIONS[gameKey]
  return HIGHLIGHT_ILLUSTRATIONS[kind]
}

// Kinds whose illustration should bounce in place (matches the "bob"
// animation used for the flame marker on the streak-card-furnace design:
// a gentle rise + tilt, looping every 2.4s).
export const BOUNCING_ILLUSTRATION_KINDS: Partial<Record<HighlightKind, boolean>> = {
  streak_milestone: true,
}
