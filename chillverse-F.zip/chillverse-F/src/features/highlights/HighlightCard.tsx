// src/features/highlights/HighlightCard.tsx
import { useState, type MouseEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Heart, Share2, Check } from 'lucide-react'
import haloMascot from '../../assets/halo-mascot.png'
import { useAuth } from '../auth/useAuth'
import { toggleHighlightLike } from './highlights'
import { shareHighlight } from './shareHighlight'
import { updateMissionProgress } from '../missions/weeklyMissions'
import { highlightIllustration, BOUNCING_ILLUSTRATION_KINDS } from './highlightAssets'
import { BadgeIcon } from '../badges/badgeIcons'
import { AchIcon, RARITY_COLOR } from '../achievements/Achievements'
import { getGameMeta } from '../games/games'
import Avatar from '../../shared/components/Avatar'
import type { Highlight } from './types'
import groveSeedMound from '../games/play/grove-assets/seed-mound.webp'
import groveThinSprout from '../games/play/grove-assets/thin-sprout.webp'
import groveSapling from '../games/play/grove-assets/sapling.webp'
import groveYoungTree from '../games/play/grove-assets/young-tree.webp'
import groveMatureFull from '../games/play/grove-assets/mature-full.webp'
import groveAncientElder from '../games/play/grove-assets/ancient-elder.webp'

const GROVE_STAGE_IMAGES = [groveSeedMound, groveThinSprout, groveSapling, groveYoungTree, groveMatureFull, groveAncientElder]
const GROVE_STAGE_NAMES = ['Seed', 'Sprout', 'Sapling', 'Young Tree', 'Mature Tree', 'Ancient Elder']

export default function HighlightCard({ highlight }: { highlight: Highlight }) {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [liked, setLiked] = useState(highlight.liked_by_me ?? false)
  const [likesCount, setLikesCount] = useState(highlight.likes_count)
  const [shared, setShared] = useState(false)

  const author = highlight.author
  const authorName = author?.display_name || author?.username || 'Someone'
  const isOwn = highlight.author_id === user?.id

  async function handleLike() {
    if (!user) return
    const next = !liked
    setLiked(next)
    setLikesCount(c => c + (next ? 1 : -1))
    const ok = await toggleHighlightLike(highlight.id, user.id, liked)
    if (!ok) {
      setLiked(!next)
      setLikesCount(c => c + (next ? -1 : 1))
    }
  }

  async function handleShare() {
    setShared(true)
    try {
      const didShare = await shareHighlight(highlight, authorName)
      // Any highlight counts, not just the viewer's own — the mission
      // ("Share a highlight") has no ownership requirement, and this feed
      // shows everyone's highlights, so gating on isOwn silently dropped
      // credit for the vast majority of real shares.
      if (user && didShare) updateMissionProgress(user.id, 'highlights_shared', 1).catch(console.error)
    } finally {
      setTimeout(() => setShared(false), 1600)
    }
  }

  function goToAuthor(e: MouseEvent) {
    e.stopPropagation()
    if (!highlight.author_id) return
    navigate(highlight.author_id === user?.id ? '/profile' : `/profile/${highlight.author_id}`)
  }

  const isGroveStageUp = highlight.kind === 'grove_stage_up'
  function goToGroveStage() {
    if (!isGroveStageUp) return
    navigate(`/grove/stage/${highlight.value ?? 0}`)
  }

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', gap: 10, padding: '18px 4px',
      borderBottom: '1px solid var(--border)',
    }}>
      <div
        onClick={isGroveStageUp ? goToGroveStage : undefined}
        style={{ display: 'flex', alignItems: 'flex-start', gap: 14, cursor: isGroveStageUp ? 'pointer' : undefined }}
      >
        {/* -- Left: name, caption -- */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div onClick={goToAuthor} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', marginBottom: 6 }}>
            <Avatar src={author?.avatar} name={authorName} size={26} />
            <span style={{ fontSize: 14.5, fontWeight: 800, color: 'var(--text)' }}>{authorName}</span>
          </div>

          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-dim)', margin: 0, lineHeight: 1.35 }}>
            {highlight.body}
          </p>
        </div>

        {/* -- Right: the art -- illustration / badge icon / profile pic -- */}
        <HighlightArt highlight={highlight} authorName={authorName} />
      </div>

      {/* -- Actions row: pill-style like/share buttons, Duolingo-feed style -- */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button
          type="button"
          onClick={handleLike}
          disabled={!user}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            background: 'none',
            border: `1.5px solid ${liked ? 'var(--green, #58cc02)' : 'rgba(255,255,255,0.14)'}`,
            borderRadius: 999, padding: '6px 14px',
            cursor: user ? 'pointer' : 'default',
            color: liked ? 'var(--green, #58cc02)' : 'var(--text-muted)',
          }}
        >
          <Heart size={14} fill={liked ? 'currentColor' : 'none'} />
          <span style={{ fontSize: 12.5, fontWeight: 800 }}>{likesCount}</span>
        </button>

        {/* Sharing is only available on your OWN highlight -- you can like anyone's, but not re-share it. */}
        {isOwn && (
          <button
            type="button"
            onClick={handleShare}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: 'none',
              border: `1.5px solid ${shared ? 'var(--gold, #f5c542)' : 'rgba(255,255,255,0.14)'}`,
              borderRadius: 999, padding: '6px 14px',
              cursor: 'pointer',
              color: shared ? 'var(--gold, #f5c542)' : 'var(--text-muted)',
            }}
          >
            {shared ? <Check size={13} /> : <Share2 size={13} />}
            <span style={{ fontSize: 12.5, fontWeight: 800 }}>{shared ? 'Shared' : 'Share'}</span>
          </button>
        )}
      </div>
    </div>
  )
}

function HighlightArt({ highlight, authorName }: { highlight: Highlight; authorName: string }) {
  const size = 68

  if (highlight.kind === 'map_complete') {
    return (
      <div style={{ flexShrink: 0 }}>
        <Avatar src={highlight.author?.avatar} name={authorName} userId={highlight.author_id} size={size} radius={size * 0.3} />
      </div>
    )
  }

  if (highlight.kind === 'lucky_user') {
    // Halo's own mascot art announces the win, rather than a generic icon —
    // this is Halo picking the winner, so Halo's face is the art.
    return (
      <div style={{
        width: size, height: size, borderRadius: size * 0.3, flexShrink: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center', background: '#f5c5421f',
        filter: 'drop-shadow(0 0 8px rgba(245,197,66,0.35))',
      }}>
        <img src={haloMascot} alt="Halo" style={{ width: '78%', height: '78%', objectFit: 'contain' }} />
      </div>
    )
  }

  if (highlight.kind === 'random_surprise') {
    // Same Halo mascot as lucky_user (it's Halo's other currency-granting
    // moment) but a distinct cyan tint so the two don't read as identical
    // at a glance in the feed.
    return (
      <div style={{
        width: size, height: size, borderRadius: size * 0.3, flexShrink: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center', background: '#4fd1ff1f',
        filter: 'drop-shadow(0 0 8px rgba(79,209,255,0.35))',
      }}>
        <img src={haloMascot} alt="Halo" style={{ width: '78%', height: '78%', objectFit: 'contain' }} />
      </div>
    )
  }

  if (highlight.kind === 'grove_stage_up') {
    const stageIdx = Math.max(0, Math.min(GROVE_STAGE_IMAGES.length - 1, highlight.value ?? 0))
    return (
      <div style={{
        width: size, height: size, borderRadius: size * 0.3, flexShrink: 0, overflow: 'hidden',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        background: 'color-mix(in srgb, #3f9e2a 16%, transparent)',
      }}>
        <img
          src={GROVE_STAGE_IMAGES[stageIdx]}
          alt={GROVE_STAGE_NAMES[stageIdx]}
          style={{ width: '82%', height: '82%', objectFit: 'contain' }}
        />
      </div>
    )
  }

  if (highlight.kind === 'leaderboard_badge') {
    const accent = highlight.badge_id === 'leaderboard_legend' ? '#f5c542' : '#9b6dff'
    return (
      <div style={{
        width: size, height: size, borderRadius: size * 0.3, flexShrink: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center', background: `${accent}1f`,
      }}>
        <BadgeIcon iconKey={highlight.badge?.icon ?? 'hand-metal'} size={size * 0.5} color={accent} />
      </div>
    )
  }

  // Checked before the game_result branch below on purpose: a game with
  // its own art should use it for the shared-win card too, not fall
  // through to the generic lucide icon in a tinted circle.
  const src = highlightIllustration(highlight.kind, highlight.game_key)
  if (src) {
    const bouncy = !!BOUNCING_ILLUSTRATION_KINDS[highlight.kind]
    return (
      <>
        {bouncy && (
          <style>{`@keyframes highlightBob { 0%,100% { transform: translateY(0) rotate(0deg); } 50% { transform: translateY(-4px) rotate(3deg); } }`}</style>
        )}
        <img
          src={src}
          alt=""
          style={{
            width: size,
            height: size,
            objectFit: 'contain',
            flexShrink: 0,
            animation: bouncy ? 'highlightBob 2.4s ease-in-out infinite' : undefined,
          }}
        />
      </>
    )
  }

  // game_result -- "share your win" from the game-over screen. Use that
  // game's own icon + accent colour (same catalog Games.tsx/GameShell use)
  // instead of a blank circle.
  if (highlight.kind === 'game_result') {
    const game = highlight.game_key ? getGameMeta(highlight.game_key) : undefined
    const accent = game?.accent ?? 'var(--accent)'
    const GameIcon = game?.icon
    return (
      <div style={{
        width: size, height: size, borderRadius: size * 0.3, flexShrink: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center', background: `${accent}1f`,
      }}>
        {GameIcon && <GameIcon size={size * 0.46} color={accent} />}
      </div>
    )
  }

  // achievement -- the unlocked achievement's own icon, tinted by its
  // rarity (same colours as the Achievements page). Older highlights
  // created before achievement_id existed (migration 0114) or a grouped
  // "unlocked N achievements" toast have no single achievement to point
  // at, so those fall back to a plain trophy in a brand-colour squircle.
  if (highlight.kind === 'achievement') {
    const rarity = highlight.achievement?.rarity
    // RARITY_COLOR only covers the four known rarities -- fall back to the
    // same gold used for the trophy icon default elsewhere (AchievementToast)
    // rather than a CSS var, since this gets concatenated into a hex+alpha string below.
    const accent = (rarity && RARITY_COLOR[rarity]) || '#f5c542'
    return (
      <div style={{
        width: size, height: size, borderRadius: size * 0.3, flexShrink: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center', background: `${accent}1f`,
      }}>
        <AchIcon iconKey={highlight.achievement?.icon ?? 'trophy'} size={size * 0.46} color={accent} />
      </div>
    )
  }

  // Fallback for any future/unhandled kind -- soft brand-colour squircle
  // rather than showing nothing.
  return (
    <div style={{
      width: size, height: size, borderRadius: size * 0.3, flexShrink: 0,
      background: 'color-mix(in srgb, var(--accent) 12%, transparent)',
    }} />
  )
}
