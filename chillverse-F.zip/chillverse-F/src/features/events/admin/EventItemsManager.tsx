// src/features/events/admin/EventItemsManager.tsx
import { useEffect, useRef, useState } from 'react'
import { UploadCloud, Trash2, ChevronUp, ChevronDown, Loader2, ImageOff, Link2, X } from 'lucide-react'
import { ripple } from '../../../shared/lib/ripple'
import {
  fetchEventItems, uploadEventImage, createEventItem, updateEventItem, deleteEventItem, reorderEventItems,
} from '../api'
import type { EventItem, EventLinkType, EventSection } from '../types'
import { inputStyle, rowStyle, iconButtonStyle, primaryButtonStyle, errorBoxStyle } from './styles'

function EditLinkForm({ item, onSave, onCancel }: {
  item: EventItem
  onSave: (updates: Partial<Pick<EventItem, 'title' | 'link_type' | 'link_value' | 'expires_at'>>) => void
  onCancel: () => void
}) {
  const [title, setTitle] = useState(item.title || '')
  const [linkType, setLinkType] = useState<EventLinkType>(item.link_type)
  const [linkValue, setLinkValue] = useState(item.link_value || '')
  const [expiresAt, setExpiresAt] = useState(item.expires_at ? item.expires_at.slice(0, 16) : '')

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, width: '100%' }}>
      <input style={inputStyle} placeholder="Label shown on the card (optional)" value={title} onChange={e => setTitle(e.target.value)} maxLength={80} />
      <div style={{ display: 'flex', gap: 6 }}>
        {(['none', 'internal', 'external'] as const).map(t => (
          <button
            key={t} type="button" onClick={(e) => { ripple(e); setLinkType(t) }} className="ripple-wrap"
            style={{
              flex: 1, fontSize: 11.5, fontWeight: 700, textTransform: 'capitalize', cursor: 'pointer', padding: '7px 0', borderRadius: 8,
              background: linkType === t ? 'var(--accent)' : 'var(--surface2)', color: linkType === t ? '#fff' : 'var(--text-dim)', border: 'none',
            }}
          >
            {t === 'none' ? 'No link' : t}
          </button>
        ))}
      </div>
      {linkType !== 'none' && (
        <input
          style={inputStyle}
          placeholder={linkType === 'internal' ? '/mall or /blog/some-post' : 'https://example.com'}
          value={linkValue}
          onChange={e => setLinkValue(e.target.value)}
        />
      )}
      <div>
        <label style={{ fontSize: 10.5, color: 'var(--text-muted)', fontWeight: 700, display: 'block', marginBottom: 4 }}>Countdown ends (optional)</label>
        <input type="datetime-local" style={inputStyle} value={expiresAt} onChange={e => setExpiresAt(e.target.value)} />
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 2 }}>
        <button
          type="button" onClick={(e) => { ripple(e); onSave({ title: title.trim() || null, link_type: linkType, link_value: linkType === 'none' ? null : linkValue.trim() || null, expires_at: expiresAt ? new Date(expiresAt).toISOString() : null }) }}
          className="ripple-wrap" style={{ ...primaryButtonStyle, flex: 1, padding: '8px 0' }}
        >
          Save
        </button>
        <button type="button" onClick={(e) => { ripple(e); onCancel() }} className="ripple-wrap" style={{ ...iconButtonStyle, width: 36, height: 36 }}>
          <X size={15} />
        </button>
      </div>
    </div>
  )
}

export default function EventItemsManager({ section, currentUserId }: { section: EventSection; currentUserId: string | null }) {
  const [items, setItems] = useState<EventItem[]>([])
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  function load() {
    setLoading(true)
    fetchEventItems(section.id)
      .then(setItems)
      .catch(() => setItems([]))
      .finally(() => setLoading(false))
  }
  useEffect(load, [section.id])

  async function handleFiles(files: FileList | null) {
    if (!files || !files[0] || !currentUserId) return
    setUploading(true)
    setUploadError(null)
    try {
      const { url, path } = await uploadEventImage(currentUserId, files[0])
      const created = await createEventItem({
        sectionId: section.id, imageUrl: url, imagePath: path, linkType: 'none', createdBy: currentUserId,
      })
      setItems(prev => [...prev, created])
      setEditingId(created.id)
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Upload failed.')
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  async function handleDelete(item: EventItem) {
    if (!window.confirm('Delete this image? This can\'t be undone.')) return
    try {
      await deleteEventItem(item)
      setItems(prev => prev.filter(i => i.id !== item.id))
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Could not delete this image.')
    }
  }

  async function handleSaveEdit(item: EventItem, updates: Partial<Pick<EventItem, 'title' | 'link_type' | 'link_value' | 'expires_at'>>) {
    try {
      await updateEventItem(item.id, updates)
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, ...updates } : i))
      setEditingId(null)
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Could not save.')
    }
  }

  async function move(index: number, dir: -1 | 1) {
    const next = [...items]
    const target = index + dir
    if (target < 0 || target >= next.length) return
    ;[next[index], next[target]] = [next[target], next[index]]
    setItems(next)
    await reorderEventItems(next.map(i => i.id))
  }

  if (loading) return <div style={{ textAlign: 'center', padding: 30, color: 'var(--text-dim)', fontSize: 13 }}>Loading images…</div>

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {uploadError && <div style={errorBoxStyle}>{uploadError}</div>}

      <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFiles(e.target.files)} />
      <button
        type="button"
        onClick={(e) => { ripple(e); fileInputRef.current?.click() }}
        disabled={uploading}
        className="ripple-wrap"
        style={{ ...primaryButtonStyle, alignSelf: 'flex-start' }}
      >
        {uploading ? <Loader2 size={14} className="animate-spin" /> : <UploadCloud size={14} />}
        {uploading ? 'Uploading…' : 'Add image'}
      </button>

      {items.length === 0 ? (
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', padding: '10px 2px' }}>No images in this section yet.</p>
      ) : (
        items.map((item, i) => (
          <div key={item.id} style={{ ...rowStyle, alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', gap: 12, width: '100%' }}>
              <div style={{ width: 76, height: 40, borderRadius: 10, overflow: 'hidden', flexShrink: 0, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {item.image_url
                  ? <img src={item.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <ImageOff size={16} color="var(--text-muted)" />}
              </div>

              {editingId === item.id ? (
                <EditLinkForm item={item} onSave={(updates) => handleSaveEdit(item, updates)} onCancel={() => setEditingId(null)} />
              ) : (
                <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{item.title || 'Untitled'}</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11.5, color: 'var(--text-muted)' }}>
                    <Link2 size={11} />
                    {item.link_type === 'none' ? 'No link' : `${item.link_type} → ${item.link_value || '—'}`}
                  </div>
                  {item.expires_at && (
                    <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>Ends {new Date(item.expires_at).toLocaleString()}</p>
                  )}
                  <button
                    type="button" onClick={(e) => { ripple(e); setEditingId(item.id) }} className="ripple-wrap"
                    style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--accent)', cursor: 'pointer', background: 'none', border: 'none', padding: 0, alignSelf: 'flex-start', marginTop: 2 }}
                  >
                    Edit label & link
                  </button>
                </div>
              )}

              {editingId !== item.id && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flexShrink: 0 }}>
                  <button type="button" onClick={(e) => { ripple(e); move(i, -1) }} disabled={i === 0} className="ripple-wrap" style={{ ...iconButtonStyle, opacity: i === 0 ? 0.3 : 1 }}><ChevronUp size={14} /></button>
                  <button type="button" onClick={(e) => { ripple(e); move(i, 1) }} disabled={i === items.length - 1} className="ripple-wrap" style={{ ...iconButtonStyle, opacity: i === items.length - 1 ? 0.3 : 1 }}><ChevronDown size={14} /></button>
                  <button type="button" onClick={(e) => { ripple(e); handleDelete(item) }} className="ripple-wrap" style={{ ...iconButtonStyle, color: '#ff8080' }}><Trash2 size={14} /></button>
                </div>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  )
}
