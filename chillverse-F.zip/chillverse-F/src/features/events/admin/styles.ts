// src/features/events/admin/styles.ts
import type { CSSProperties } from 'react'

export const inputStyle: CSSProperties = {
  width: '100%', padding: '10px 12px', borderRadius: 10,
  background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text)',
  fontSize: 13, fontWeight: 400, outline: 'none', fontFamily: 'inherit',
}

export const rowStyle: CSSProperties = {
  display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
  background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14,
  padding: '13px 16px',
}

export const iconButtonStyle: CSSProperties = {
  width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
  background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 9,
}

export const primaryButtonStyle: CSSProperties = {
  fontSize: 13, fontWeight: 700, color: '#fff', cursor: 'pointer',
  background: 'var(--accent)', border: 'none', borderRadius: 10, padding: '10px 18px',
  display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'center',
}

export const secondaryButtonStyle: CSSProperties = {
  fontSize: 13, fontWeight: 700, color: 'var(--text-dim)', cursor: 'pointer',
  background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 10, padding: '10px 18px',
  display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'center',
}

export const errorBoxStyle: CSSProperties = {
  background: 'rgba(255,79,79,0.08)', border: '1px solid rgba(255,79,79,0.25)', borderRadius: 12,
  padding: '12px 16px', color: '#ff8080', fontSize: 13, marginBottom: 16,
}
