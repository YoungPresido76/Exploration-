// src/features/events/admin/EventsAdminShell.tsx
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  ChevronLeft, ShieldAlert, Plus, Pencil, Trash2, ChevronUp, ChevronDown,
  ChevronRight, X, Check, Lock,
} from 'lucide-react'
import { ripple } from '../../../shared/lib/ripple'
import { useAuth } from '../../auth/useAuth'
import { useModRole } from '../../moderation/useModRole'
import { fetchAllEventSections, createEventSection, updateEventSection, deleteEventSection, reorderEventSections } from '../api'
import { getEventIconComponent, EVENT_ICON_OPTIONS } from '../icons'
import type { EventSection } from '../types'
import { inputStyle, rowStyle, iconButtonStyle, primaryButtonStyle, secondaryButtonStyle, errorBoxStyle } from './styles'
import EventItemsManager from './EventItemsManager'

function SectionForm({ initial, onSave, onCancel }: {
  initial?: EventSection
  onSave: (input: { title: string; subtitle: string; icon: string }) => Promise<void>
  onCancel: () => void
}) {
  const [title, setTitle] = useState(initial?.title || '')
  const [subtitle, setSubtitle] = useState(initial?.subtitle || '')
  const [icon, setIcon] = useState(initial?.icon || 'sparkles')
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function submit() {
    if (!title.trim()) { setErr('Give this section a name.'); return }
    setSaving(true)
    setErr(null)
    try {
      await onSave({ title: title.trim(), subtitle: subtitle.trim(), icon })
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Could not save.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div style={{ ...rowStyle, flexDirection: 'column', alignItems: 'stretch', gap: 10 }}>
      {err && <div style={errorBoxStyle}>{err}</div>}
      <input style={inputStyle} placeholder="Section name (e.g. Summer Trip Deals)" value={title} onChange={e => setTitle(e.target.value)} maxLength={40} autoFocus />
      <input style={inputStyle} placeholder="Subtitle shown under the tabs (optional)" value={subtitle} onChange={e => setSubtitle(e.target.value)} maxLength={80} />
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {EVENT_ICON_OPTIONS.map(opt => (
          <button
            key={opt.name} type="button" onClick={(e) => { ripple(e); setIcon(opt.name) }} className="ripple-wrap"
            style={{
              width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 9, cursor: 'pointer',
              background: icon === opt.name ? 'var(--accent)' : 'var(--surface2)', color: icon === opt.name ? '#fff' : 'var(--text-dim)', border: 'none',
            }}
          >
            <opt.icon size={15} />
          </button>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button type="button" onClick={(e) => { ripple(e); submit() }} disabled={saving} className="ripple-wrap" style={{ ...primaryButtonStyle, flex: 1 }}>
          <Check size={14} /> {saving ? 'Saving…' : 'Save section'}
        </button>
        <button type="button" onClick={(e) => { ripple(e); onCancel() }} className="ripple-wrap" style={secondaryButtonStyle}>
          Cancel
        </button>
      </div>
    </div>
  )
}

export default function EventsAdminShell() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { isStaff, loading: roleLoading } = useModRole()

  const [sections, setSections] = useState<EventSection[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  function load() {
    setLoading(true)
    fetchAllEventSections()
      .then(rows => { setSections(rows); setError(null) })
      .catch((err: Error) => setError(err.message || 'Could not load event sections.'))
      .finally(() => setLoading(false))
  }
  useEffect(() => { if (isStaff) load() }, [isStaff])

  if (roleLoading) {
    return <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-dim)', fontSize: 13.5 }}>Loading…</div>
  }

  if (!isStaff) {
    return (
      <div style={{ maxWidth: 480, margin: '60px auto', textAlign: 'center' }}>
        <ShieldAlert size={32} color="var(--text-muted)" style={{ marginBottom: 12 }} />
        <h1 style={{ fontSize: 18, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>Staff only</h1>
        <p style={{ fontSize: 13.5, color: 'var(--text-dim)' }}>This page is for Chillverse staff, moderators, and admins.</p>
      </div>
    )
  }

  async function handleCreate(input: { title: string; subtitle: string; icon: string }) {
    const created = await createEventSection({ title: input.title, subtitle: input.subtitle || null, icon: input.icon, createdBy: user?.id ?? null })
    setSections(prev => [...prev, created])
    setCreating(false)
  }

  async function handleEdit(section: EventSection, input: { title: string; subtitle: string; icon: string }) {
    await updateEventSection(section.id, { title: input.title, subtitle: input.subtitle || null, icon: input.icon })
    setSections(prev => prev.map(s => s.id === section.id ? { ...s, title: input.title, subtitle: input.subtitle || null, icon: input.icon } : s))
    setEditingId(null)
  }

  async function handleDelete(section: EventSection) {
    if (section.is_system) return
    if (!window.confirm(`Delete "${section.title}"? Its images will be removed too.`)) return
    try {
      await deleteEventSection(section.id)
      setSections(prev => prev.filter(s => s.id !== section.id))
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Could not delete this section.')
    }
  }

  async function handleToggleActive(section: EventSection) {
    const next = !section.is_active
    await updateEventSection(section.id, { is_active: next })
    setSections(prev => prev.map(s => s.id === section.id ? { ...s, is_active: next } : s))
  }

  async function move(index: number, dir: -1 | 1) {
    const next = [...sections]
    const target = index + dir
    if (target < 0 || target >= next.length) return
    ;[next[index], next[target]] = [next[target], next[index]]
    setSections(next)
    await reorderEventSections(next.map(s => s.id))
  }

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }}>
      <button
        type="button"
        onClick={(e) => { ripple(e); navigate('/events') }}
        className="ripple-wrap"
        style={{ display: 'inline-flex', alignItems: 'center', gap: 4, cursor: 'pointer', fontSize: 12.5, fontWeight: 700, color: 'var(--text-dim)', marginBottom: 14 }}
      >
        <ChevronLeft size={15} /> Back to Events
      </button>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18, flexWrap: 'wrap', gap: 10 }}>
        <div>
          <h1 style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0 }}>Events Admin</h1>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '2px 0 0' }}>Manage tabs and their banner images.</p>
        </div>
        {!creating && (
          <button type="button" onClick={(e) => { ripple(e); setCreating(true); setEditingId(null) }} className="ripple-wrap" style={primaryButtonStyle}>
            <Plus size={14} /> New section
          </button>
        )}
      </div>

      {error && <div style={errorBoxStyle}>{error}</div>}

      {creating && (
        <div style={{ marginBottom: 12 }}>
          <SectionForm onSave={handleCreate} onCancel={() => setCreating(false)} />
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-dim)', fontSize: 13.5 }}>Loading…</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {sections.map((s, i) => {
            const Icon = getEventIconComponent(s.icon)
            const isExpanded = expandedId === s.id

            if (editingId === s.id) {
              return <SectionForm key={s.id} initial={s} onSave={(input) => handleEdit(s, input)} onCancel={() => setEditingId(null)} />
            }

            return (
              <div key={s.id} style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={rowStyle}>
                  <div
                    onClick={() => setExpandedId(isExpanded ? null : s.id)}
                    style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0, cursor: 'pointer', flex: 1 }}
                  >
                    <div style={{ width: 30, height: 30, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--surface2)', color: 'var(--accent)', flexShrink: 0 }}>
                      <Icon size={14} />
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <p style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.title}</p>
                        {s.is_system && <Lock size={11} color="var(--text-muted)" />}
                        {!s.is_active && (
                          <span style={{ fontSize: 9.5, fontWeight: 800, color: 'var(--text-muted)', background: 'var(--surface2)', borderRadius: 999, padding: '2px 6px', textTransform: 'uppercase' }}>Hidden</span>
                        )}
                      </div>
                      {s.subtitle && <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{s.subtitle}</p>}
                    </div>
                    <ChevronRight size={14} color="var(--text-muted)" style={{ marginLeft: 'auto', transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s', flexShrink: 0 }} />
                  </div>

                  <div style={{ display: 'flex', gap: 4, flexShrink: 0, marginLeft: 8 }}>
                    <button type="button" onClick={(e) => { ripple(e); move(i, -1) }} disabled={i === 0} className="ripple-wrap" style={{ ...iconButtonStyle, opacity: i === 0 ? 0.3 : 1 }}><ChevronUp size={13} /></button>
                    <button type="button" onClick={(e) => { ripple(e); move(i, 1) }} disabled={i === sections.length - 1} className="ripple-wrap" style={{ ...iconButtonStyle, opacity: i === sections.length - 1 ? 0.3 : 1 }}><ChevronDown size={13} /></button>
                    <button type="button" onClick={(e) => { ripple(e); handleToggleActive(s) }} className="ripple-wrap" style={iconButtonStyle} title={s.is_active ? 'Hide from players' : 'Show to players'}>
                      {s.is_active ? <Check size={13} /> : <X size={13} />}
                    </button>
                    <button type="button" onClick={(e) => { ripple(e); setEditingId(s.id); setCreating(false) }} className="ripple-wrap" style={iconButtonStyle}><Pencil size={13} /></button>
                    {!s.is_system && (
                      <button type="button" onClick={(e) => { ripple(e); handleDelete(s) }} className="ripple-wrap" style={{ ...iconButtonStyle, color: '#ff8080' }}><Trash2 size={13} /></button>
                    )}
                  </div>
                </div>

                {isExpanded && (
                  <div style={{ margin: '4px 0 4px 8px' }}>
                    <EventItemsManager section={s} currentUserId={user?.id ?? null} />
                  </div>
                )}
              </div>
            )
          })}

          {sections.length === 0 && !creating && (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: 30 }}>No sections yet — create one to get started.</p>
          )}
        </div>
      )}
    </div>
  )
}
