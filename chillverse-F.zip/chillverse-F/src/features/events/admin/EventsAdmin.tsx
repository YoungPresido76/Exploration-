// src/features/events/admin/EventsAdmin.tsx
import EventsAdminShell from './EventsAdminShell'

export default function EventsAdmin() {
  return <EventsAdminShell />
}
