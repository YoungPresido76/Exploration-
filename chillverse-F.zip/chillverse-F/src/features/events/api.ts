// src/features/events/api.ts
import { supabase } from '../../shared/lib/supabase'
import type { EventSection, EventItem, EventLinkType } from './types'

const EVENT_IMAGES_BUCKET = 'event-images'
const MAX_IMAGE_BYTES = 5 * 1024 * 1024 // 5MB

function extensionForFile(file: File): string {
  const fromName = file.name.split('.').pop()?.toLowerCase()
  if (fromName && /^(jpg|jpeg|png|gif|webp)$/.test(fromName)) return fromName
  if (file.type.includes('png')) return 'png'
  if (file.type.includes('gif')) return 'gif'
  if (file.type.includes('webp')) return 'webp'
  return 'jpg'
}

export function slugifyEventTitle(title: string): string {
  return title
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60)
}

// ── Sections ──────────────────────────────────────────────────────────────

/** Active sections only, for the player-facing tab strip. */
export async function fetchActiveEventSections(): Promise<EventSection[]> {
  const { data, error } = await supabase
    .from('event_sections')
    .select('*')
    .eq('is_active', true)
    .order('sort_order', { ascending: true })
  if (error) throw error
  return (data as EventSection[]) ?? []
}

/** Every section (active + inactive), for the admin panel. */
export async function fetchAllEventSections(): Promise<EventSection[]> {
  const { data, error } = await supabase
    .from('event_sections')
    .select('*')
    .order('sort_order', { ascending: true })
  if (error) throw error
  return (data as EventSection[]) ?? []
}

export async function createEventSection(input: {
  title: string
  subtitle?: string | null
  icon?: string
  createdBy: string | null
}): Promise<EventSection> {
  const baseSlug = slugifyEventTitle(input.title) || 'section'
  // Guard against a slug collision (e.g. two sections both titled "Summer").
  let slug = baseSlug
  let attempt = 0
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const { data: existing } = await supabase.from('event_sections').select('id').eq('slug', slug).maybeSingle()
    if (!existing) break
    attempt += 1
    slug = `${baseSlug}-${attempt + 1}`
  }

  const { count } = await supabase.from('event_sections').select('id', { count: 'exact', head: true })

  const { data, error } = await supabase
    .from('event_sections')
    .insert({
      slug,
      title: input.title.trim(),
      subtitle: input.subtitle?.trim() || null,
      icon: input.icon || 'sparkles',
      sort_order: count ?? 0,
      created_by: input.createdBy,
    })
    .select('*')
    .single()
  if (error) throw error
  return data as EventSection
}

export async function updateEventSection(id: string, updates: Partial<Pick<EventSection, 'title' | 'subtitle' | 'icon' | 'is_active'>>): Promise<void> {
  const { error } = await supabase.from('event_sections').update(updates).eq('id', id)
  if (error) throw error
}

export async function deleteEventSection(id: string): Promise<void> {
  const { error } = await supabase.from('event_sections').delete().eq('id', id)
  if (error) throw error
}

export async function reorderEventSections(orderedIds: string[]): Promise<void> {
  await Promise.all(orderedIds.map((id, i) => supabase.from('event_sections').update({ sort_order: i }).eq('id', id)))
}

// ── Items ─────────────────────────────────────────────────────────────────

/** True if any active section has an item that hasn't expired yet — drives
 *  the "something's live" glow on the Topbar calendar icon. */
export async function hasLiveEvent(): Promise<boolean> {
  const nowIso = new Date().toISOString()
  const { data, error } = await supabase
    .from('event_items')
    .select('id, event_sections!inner(is_active)')
    .eq('event_sections.is_active', true)
    .or(`expires_at.is.null,expires_at.gt.${nowIso}`)
    .limit(1)
  if (error) throw error
  return (data?.length ?? 0) > 0
}

export async function fetchEventItems(sectionId: string): Promise<EventItem[]> {
  const { data, error } = await supabase
    .from('event_items')
    .select('*')
    .eq('section_id', sectionId)
    .order('sort_order', { ascending: true })
  if (error) throw error
  return (data as EventItem[]) ?? []
}

/** Uploads a banner image to the public `event-images` bucket. Returns the
 *  public URL + storage path (the path is kept so the file can be cleaned
 *  up from storage when the item is deleted). */
export async function uploadEventImage(uploaderId: string, file: File): Promise<{ url: string; path: string }> {
  if (!file.type.startsWith('image/')) throw new Error('Only image files can be used here.')
  if (file.size > MAX_IMAGE_BYTES) throw new Error('Image is too large — please use a file under 5MB.')

  const path = `${uploaderId}/${crypto.randomUUID()}.${extensionForFile(file)}`
  const { error } = await supabase.storage
    .from(EVENT_IMAGES_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (error) throw new Error(`Failed to upload image: ${error.message}`)

  const { data } = supabase.storage.from(EVENT_IMAGES_BUCKET).getPublicUrl(path)
  return { url: data.publicUrl, path }
}

export async function createEventItem(input: {
  sectionId: string
  imageUrl: string
  imagePath: string
  title?: string | null
  linkType: EventLinkType
  linkValue?: string | null
  expiresAt?: string | null
  createdBy: string | null
}): Promise<EventItem> {
  const { count } = await supabase
    .from('event_items')
    .select('id', { count: 'exact', head: true })
    .eq('section_id', input.sectionId)

  const { data, error } = await supabase
    .from('event_items')
    .insert({
      section_id: input.sectionId,
      image_url: input.imageUrl,
      image_path: input.imagePath,
      title: input.title?.trim() || null,
      link_type: input.linkType,
      link_value: input.linkType === 'none' ? null : (input.linkValue?.trim() || null),
      expires_at: input.expiresAt || null,
      sort_order: count ?? 0,
      created_by: input.createdBy,
    })
    .select('*')
    .single()
  if (error) throw error
  return data as EventItem
}

export async function updateEventItem(id: string, updates: Partial<Pick<EventItem, 'title' | 'link_type' | 'link_value' | 'expires_at'>>): Promise<void> {
  const { error } = await supabase.from('event_items').update(updates).eq('id', id)
  if (error) throw error
}

export async function deleteEventItem(item: EventItem): Promise<void> {
  const { error: storageError } = await supabase.storage.from(EVENT_IMAGES_BUCKET).remove([item.image_path])
  if (storageError) throw new Error(`Failed to delete file: ${storageError.message}`)
  const { error } = await supabase.from('event_items').delete().eq('id', item.id)
  if (error) throw error
}

export async function reorderEventItems(orderedIds: string[]): Promise<void> {
  await Promise.all(orderedIds.map((id, i) => supabase.from('event_items').update({ sort_order: i }).eq('id', id)))
}
