// src/features/events/icons.ts
// Small, curated icon set for admin-managed event sections. Sections store
// the icon as a name string (event_sections.icon); this maps that name back
// to a component for both the player tab strip and the admin panel. Falls
// back to Sparkles for any unrecognized name.
import {
  Sparkles, Rocket, Gift, Trophy, CalendarDays, Zap, Star, Flame,
  ShoppingBag, Gamepad2, PartyPopper, Megaphone, Tag, Swords, Crown, Ticket,
  type LucideIcon,
} from 'lucide-react'

export const EVENT_ICON_OPTIONS: { name: string; icon: LucideIcon }[] = [
  { name: 'sparkles', icon: Sparkles },
  { name: 'rocket', icon: Rocket },
  { name: 'gift', icon: Gift },
  { name: 'trophy', icon: Trophy },
  { name: 'calendar-days', icon: CalendarDays },
  { name: 'zap', icon: Zap },
  { name: 'star', icon: Star },
  { name: 'flame', icon: Flame },
  { name: 'shopping-bag', icon: ShoppingBag },
  { name: 'gamepad', icon: Gamepad2 },
  { name: 'party', icon: PartyPopper },
  { name: 'megaphone', icon: Megaphone },
  { name: 'tag', icon: Tag },
  { name: 'swords', icon: Swords },
  { name: 'crown', icon: Crown },
  { name: 'ticket', icon: Ticket },
]

const ICON_MAP = new Map(EVENT_ICON_OPTIONS.map(o => [o.name, o.icon]))

export function getEventIconComponent(name: string | null | undefined): LucideIcon {
  return (name && ICON_MAP.get(name)) || Sparkles
}
