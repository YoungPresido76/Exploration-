// src/features/events/types.ts
export interface EventSection {
  id: string
  slug: string
  title: string
  subtitle: string | null
  icon: string
  sort_order: number
  is_active: boolean
  is_system: boolean
  created_by: string | null
  created_at: string
}

export type EventLinkType = 'none' | 'internal' | 'external'

export interface EventItem {
  id: string
  section_id: string
  image_url: string
  image_path: string
  title: string | null
  link_type: EventLinkType
  link_value: string | null
  sort_order: number
  expires_at: string | null
  created_by: string | null
  created_at: string
}
