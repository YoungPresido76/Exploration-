// src/features/events/Events.tsx
import { useEffect, useMemo, useState, type MouseEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { CalendarX, ImageOff } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { fetchActiveEventSections, fetchEventItems } from './api'
import { getEventIconComponent } from './icons'
import type { EventItem, EventSection } from './types'
import PageOnboarding from '../onboarding/PageOnboarding'

const SECTION_GRADIENTS = [
  'linear-gradient(135deg,#9b6dff,#4f8ef7)',
  'linear-gradient(135deg,var(--accent),var(--accent2))',
  'linear-gradient(135deg,#00e5ff,#4f8ef7)',
  'linear-gradient(135deg,#ff6b9d,#c86dff)',
  'linear-gradient(135deg,#ffb648,#ff6b6b)',
]

function gradientFor(index: number): string {
  return SECTION_GRADIENTS[index % SECTION_GRADIENTS.length]
}

/** "3d 5h" / "5h 12m" / "42m" style countdown, matching the compact badge
 *  format players already recognize from limited-time Mall items. */
function formatCountdown(expiresAt: string): string | null {
  const ms = new Date(expiresAt).getTime() - Date.now()
  if (ms <= 0) return null
  const mins = Math.floor(ms / 60000)
  const days = Math.floor(mins / 1440)
  const hours = Math.floor((mins % 1440) / 60)
  const remMins = mins % 60
  if (days > 0) return `${days}d ${hours}h`
  if (hours > 0) return `${hours}h ${remMins}m`
  return `${remMins}m`
}

function EventBannerCard({ item, gradient }: { item: EventItem; gradient: string }) {
  const navigate = useNavigate()
  const [broken, setBroken] = useState(false)
  const countdown = item.expires_at ? formatCountdown(item.expires_at) : null
  const clickable = item.link_type !== 'none'

  function handleTap(e: MouseEvent<HTMLDivElement>) {
    if (!clickable) return
    ripple(e)
    if (item.link_type === 'external' && item.link_value) {
      window.open(item.link_value, '_blank', 'noopener,noreferrer')
    } else if (item.link_type === 'internal' && item.link_value) {
      navigate(item.link_value)
    }
  }

  return (
    <div
      onClick={handleTap}
      className={clickable ? 'ripple-wrap' : undefined}
      style={{
        position: 'relative', borderRadius: 16, overflow: 'hidden', width: '100%', aspectRatio: '2.15 / 1',
        background: gradient, cursor: clickable ? 'pointer' : 'default',
        boxShadow: '0 8px 24px rgba(0,0,0,0.28)', border: '1px solid var(--border)',
      }}
    >
      {!broken ? (
        <img
          src={item.image_url}
          alt={item.title || ''}
          onError={() => setBroken(true)}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
        />
      ) : (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.5 }}>
          <ImageOff size={26} color="#fff" />
        </div>
      )}

      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(0,0,0,0.05) 40%, rgba(0,0,0,0.65) 100%)' }} />

      {countdown && (
        <div style={{
          position: 'absolute', top: 8, left: 8, display: 'flex', alignItems: 'center', gap: 4,
          background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)', borderRadius: 999,
          padding: '4px 9px', fontSize: 10.5, fontWeight: 800, color: '#fff', letterSpacing: '0.02em',
        }}>
          {countdown}
        </div>
      )}

      {item.title && (
        <div style={{ position: 'absolute', left: 12, right: 12, bottom: 10 }}>
          <p style={{
            fontSize: 13, fontWeight: 800, color: '#fff', lineHeight: 1.25,
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
            textShadow: '0 1px 4px rgba(0,0,0,0.5)',
          }}>
            {item.title}
          </p>
        </div>
      )}
    </div>
  )
}

export default function Events() {
  const [sections, setSections] = useState<EventSection[]>([])
  const [activeSlug, setActiveSlug] = useState<string | null>(null)
  const [items, setItems] = useState<EventItem[]>([])
  const [loadingSections, setLoadingSections] = useState(true)
  const [loadingItems, setLoadingItems] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    fetchActiveEventSections()
      .then(rows => {
        if (!active) return
        setSections(rows)
        setActiveSlug(rows[0]?.slug ?? null)
        setError(null)
      })
      .catch((err: Error) => { if (active) setError(err.message || 'Could not load Events.') })
      .finally(() => { if (active) setLoadingSections(false) })
    return () => { active = false }
  }, [])

  useEffect(() => {
    const section = sections.find(s => s.slug === activeSlug)
    if (!section) { setItems([]); setLoadingItems(false); return }
    let active = true
    setLoadingItems(true)

    fetchEventItems(section.id)
      .then(rows => { if (active) setItems(rows) })
      .catch(() => { if (active) setItems([]) })
      .finally(() => { if (active) setLoadingItems(false) })

    return () => { active = false }
  }, [activeSlug, sections])

  const activeIndex = useMemo(() => sections.findIndex(s => s.slug === activeSlug), [sections, activeSlug])

  if (loadingSections) {
    return <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-dim)', fontSize: 13.5 }}>Loading…</div>
  }

  if (error) {
    return <div className="neu-card p-8 text-center max-w-[800px] mx-auto mt-8" style={{ color: 'var(--text-dim)' }}>{error}</div>
  }

  if (sections.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-dim)' }}>
        <CalendarX size={30} style={{ marginBottom: 10, opacity: 0.6 }} />
        <p style={{ fontSize: 13.5 }}>Nothing running right now — check back soon.</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col max-w-[800px] mx-auto">
      <PageOnboarding pageKey="events" />

      <div style={{ marginBottom: 16 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)', marginBottom: 3 }}>Events</h1>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Limited drops, deals, and everything we've shipped.</p>
      </div>

      {/* Tab strip */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4, marginBottom: 16, scrollbarWidth: 'none' }}>
        {sections.map((s, i) => {
          const Icon = getEventIconComponent(s.icon)
          const isActive = s.slug === activeSlug
          return (
            <button
              key={s.id}
              type="button"
              onClick={(e) => { ripple(e); setActiveSlug(s.slug) }}
              className="ripple-wrap"
              style={{
                flexShrink: 0, display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap',
                fontSize: 12.5, fontWeight: 800, padding: '9px 14px', borderRadius: 12, cursor: 'pointer',
                background: isActive ? gradientFor(i) : 'var(--surface)',
                color: isActive ? '#fff' : 'var(--text-dim)',
                border: `1px solid ${isActive ? 'transparent' : 'var(--border)'}`,
                boxShadow: isActive ? '0 6px 16px rgba(0,0,0,0.25)' : 'none',
                transition: 'background 0.2s, color 0.2s',
              }}
            >
              <Icon size={14} /> {s.title}
            </button>
          )
        })}
      </div>

      {sections[activeIndex]?.subtitle && (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: -8, marginBottom: 14 }}>
          {sections[activeIndex].subtitle}
        </p>
      )}

      {/* Banner list */}
      {loadingItems ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[0, 1, 2].map(i => (
            <div key={i} style={{ width: '100%', aspectRatio: '2.15 / 1', borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--border)' }} />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '50px 20px', color: 'var(--text-dim)' }}>
          <CalendarX size={26} style={{ marginBottom: 8, opacity: 0.5 }} />
          <p style={{ fontSize: 13 }}>Nothing here yet.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {items.map(item => (
            <EventBannerCard key={item.id} item={item} gradient={gradientFor(activeIndex)} />
          ))}
        </div>
      )}
    </div>
  )
}
