// src/features/games/PlunderHatCard.tsx
// ─── The hat on offer ─────────────────────────────────────────────────
// Advertises the Plunder crown (see plunderCrown.ts) wherever a player is
// reading about the game before diving in.
//
// It lives in its own file rather than inside Plunder.tsx because the game
// detail sheet renders long before the game itself is loaded — importing it
// from Plunder.tsx would drag the whole game into the Games Zone bundle.
//
// The copy flips for whoever currently holds the crown: telling the
// reigning champion to go win the thing they're already wearing reads as a
// bug, and the holder's version is the more interesting line anyway.
import { usePlunderCrown } from './plunderCrown'
import { useAuth } from '../auth/useAuth'

const ACCENT = '#ffcc2b'

const HAT_SRC =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/Hat.png'

export default function PlunderHatCard({ style }: { style?: React.CSSProperties }) {
  const { session } = useAuth()
  const championId = usePlunderCrown()
  const wearsHat = !!session?.user?.id && session.user.id === championId

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      background: wearsHat
        ? `linear-gradient(120deg, ${ACCENT}20, var(--surface2))`
        : 'var(--surface2)',
      border: `1px solid ${wearsHat ? `${ACCENT}55` : 'var(--border)'}`,
      borderRadius: 14, padding: '12px 14px',
      ...style,
    }}>
      <img
        src={HAT_SRC}
        alt=""
        aria-hidden
        onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none' }}
        style={{
          width: 62, height: 40, objectFit: 'contain', flexShrink: 0,
          transform: 'rotate(-6deg)',
          filter: `drop-shadow(0 3px 6px rgba(0,0,0,0.5))${wearsHat ? ` drop-shadow(0 0 10px ${ACCENT}88)` : ''}`,
          opacity: wearsHat ? 1 : 0.85,
        }}
      />
      <div style={{ minWidth: 0 }}>
        <div style={{
          fontSize: 12, fontWeight: 900, letterSpacing: 0.4,
          color: wearsHat ? ACCENT : 'var(--text)', marginBottom: 3,
        }}>
          {wearsHat ? "She's yours, Cap'n." : 'Ahoy, matey!'}
        </div>
        <div style={{ fontSize: 11.5, lineHeight: 1.42, color: 'var(--text-dim)' }}>
          {wearsHat
            ? 'Ye be wearin\u2019 me hat. Hold the top o\u2019 the board or it sails to the next soul come mornin\u2019.'
            : 'Top the Plunder board and me hat rides on yer profile for a full day \u2014 even if some scallywag outscores ye.'}
        </div>
      </div>
    </div>
  )
}
