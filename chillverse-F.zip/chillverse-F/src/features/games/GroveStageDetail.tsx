// src/features/games/GroveStageDetail.tsx
// Reached from a "grove_stage_up" notification or highlight card. Deliberately
// NOT wrapped in ProRoute — anyone signed in can see how the community tree
// grew and who helped, without needing Void/Pro or an active game session.
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Droplet } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import Avatar from '../../shared/components/Avatar'
import { usePageHeader } from '../../context/PageHeader'

import seedMound from './play/grove-assets/seed-mound.webp'
import thinSprout from './play/grove-assets/thin-sprout.webp'
import sapling from './play/grove-assets/sapling.webp'
import youngTree from './play/grove-assets/young-tree.webp'
import matureFull from './play/grove-assets/mature-full.webp'
import ancientElder from './play/grove-assets/ancient-elder.webp'

const STAGE_IMAGES = [seedMound, thinSprout, sapling, youngTree, matureFull, ancientElder]
const STAGE_NAMES = ['Seed', 'Sprout', 'Sapling', 'Young Tree', 'Mature Tree', 'Ancient Elder']
const STAGE_COPY = [
  'just planted',
  'reaching for light',
  'finding its shape',
  'branches widening',
  'a real canopy now',
  'the grove remembers',
]

type Gardener = {
  user_id: string
  display_name: string | null
  username: string | null
  avatar: string | null
  contributed: number
}

export default function GroveStageDetail() {
  const { stageIndex: stageIndexParam } = useParams<{ stageIndex: string }>()
  const stageIndex = Math.max(0, Math.min(5, parseInt(stageIndexParam || '0', 10) || 0))

  const [gardeners, setGardeners] = useState<Gardener[] | null>(null)
  const [totalGrowth, setTotalGrowth] = useState<number | null>(null)

  usePageHeader({ title: 'The Grove' })

  useEffect(() => {
    let cancelled = false
    async function load() {
      const [{ data: top }, { data: state }] = await Promise.all([
        supabase.rpc('get_grove_top_gardeners', { p_limit: 3 }),
        supabase.from('grove_state').select('total_growth').eq('id', 1).single(),
      ])
      if (cancelled) return
      setGardeners(top ?? [])
      setTotalGrowth(state?.total_growth ?? null)
    }
    load()
    return () => { cancelled = true }
  }, [])

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', paddingBottom: 40 }}>
      <div style={{ maxWidth: 420, margin: '0 auto', padding: '24px 20px' }}>
        <div style={{ textAlign: 'center', marginBottom: 8 }}>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', color: 'var(--accent)', textTransform: 'uppercase' }}>
            Grove milestone
          </div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: 'var(--text)', margin: '4px 0 2px' }}>
            {STAGE_NAMES[stageIndex]}
          </h1>
          <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{STAGE_COPY[stageIndex]}</div>
        </div>

        <div style={{
          margin: '20px auto', width: '100%', maxWidth: 260, aspectRatio: '3 / 4',
          display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        }}>
          <img
            src={STAGE_IMAGES[stageIndex]}
            alt={STAGE_NAMES[stageIndex]}
            style={{ width: '100%', height: '100%', objectFit: 'contain' }}
          />
        </div>

        {totalGrowth !== null && (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            fontSize: 13, color: 'var(--text-muted)', marginBottom: 24,
          }}>
            <Droplet size={14} color="var(--water, #7DB8D9)" />
            {Math.floor(totalGrowth)} total growth, from everyone in the grove
          </div>
        )}

        <div style={{
          background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: '16px 16px 8px',
        }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', marginBottom: 12 }}>
            🌿 Top Gardeners
          </div>
          {gardeners === null && (
            <div style={{ fontSize: 12, color: 'var(--text-muted)', padding: '8px 0 16px' }}>Loading…</div>
          )}
          {gardeners !== null && gardeners.length === 0 && (
            <div style={{ fontSize: 12, color: 'var(--text-muted)', padding: '8px 0 16px' }}>No waterings yet.</div>
          )}
          {gardeners?.map((g, i) => (
            <div
              key={g.user_id}
              style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0',
                borderBottom: i < gardeners.length - 1 ? '1px solid var(--border)' : 'none',
              }}
            >
              <div style={{ width: 18, fontSize: 13, fontWeight: 800, color: 'var(--accent)' }}>{i + 1}</div>
              <Avatar userId={g.user_id} name={g.display_name || g.username || 'Gardener'} src={g.avatar} size={34} />
              <div style={{ flex: 1, minWidth: 0, fontSize: 13, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {g.display_name || g.username || 'a quiet gardener'}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{g.contributed} waterings</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
