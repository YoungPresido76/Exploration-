// src/features/games/CategoryPage.tsx
// Dedicated page per Categories chip (All/Board/Hard/Session Binge/Easy/
// Strategy/Pro) — big header, then the games that fall under it. Tapping a
// card deep-links into the Game Zone lobby via location.state.openGame
// (same mechanism Multiplayer's "Vs AI" already uses), so locking/session
// logic stays single-sourced in Games.tsx.
//
// Every chip (not just "All") groups its games under their genre (Puzzle,
// Trivia, etc.) and renders each group as a horizontally-scrolling row in
// the same visual language as Trending Now on the Game Zone landing page —
// so a filtered category still reads as organized, not a wall of cards.
import { groupGamesByGenre, getGamesForCategory, CATEGORIES, type CategoryKey, type GameId } from './games'
import { usePageHeader } from '../../context/PageHeader'
import TrendingGameCard from './TrendingGameCard'

export default function CategoryPage({
  category, onBack, onOpenGame,
}: {
  category: CategoryKey
  onBack: () => void
  onOpenGame: (id: GameId) => void
}) {
  const label = CATEGORIES.find(c => c.key === category)?.label ?? 'Games'

  usePageHeader({ title: label, onBack })

  const genreGroups = groupGamesByGenre(getGamesForCategory(category))

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', paddingBottom: 48 }}>
      {genreGroups.length === 0 ? (
        <div className="neu-card" style={{ padding: 28, textAlign: 'center' }}>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: 0 }}>
            No games in this category yet — check back soon.
          </p>
        </div>
      ) : (
        genreGroups.map(group => (
          <section key={group.category} style={{ marginBottom: 22 }}>
            <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', margin: '0 0 12px' }}>{group.category}</p>
            <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 4 }}>
              {group.games.map(g => (
                <TrendingGameCard
                  key={g.id}
                  name={g.name}
                  tag={g.category ?? 'Game'}
                  accent={g.accent}
                  icon={g.icon}
                  bannerUrl={g.bannerUrl}
                  locked={!!g.requiresPro}
                  onOpen={() => onOpenGame(g.id)}
                />
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  )
}
