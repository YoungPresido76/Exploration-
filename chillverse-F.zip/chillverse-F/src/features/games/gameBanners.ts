// src/features/games/gameBanners.ts
// Auto-attaches banner images to games straight from Supabase Storage —
// no code change needed to wire up a new banner. Drop an image into the
// `Adverts/Games` storage folder named (loosely) after the game — casing,
// spaces, and underscores don't matter, so "the_last_samurai.png",
// "The Last Samurai.png", and "TheLastSamurai.png" all resolve to the same
// game. It's matched against either the dbKey ("foodie") or the display
// name ("Foodie"), whichever fits, and becomes that game's banner on the
// next page load. A `bannerUrl` set by hand in games.ts always takes
// priority — this only fills in games that don't already have one.
import { useEffect, useReducer } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { GAMES } from './games'

const BANNER_BUCKET = 'Adverts'
const BANNER_FOLDER = 'Games'

function normalize(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, '')
}

const listeners = new Set<() => void>()
let loadPromise: Promise<void> | null = null

function notifyListeners() {
  for (const l of listeners) l()
}

function loadBanners(): Promise<void> {
  if (!loadPromise) {
    loadPromise = (async () => {
      const { data, error } = await supabase.storage.from(BANNER_BUCKET).list(BANNER_FOLDER, { limit: 200 })
      if (error || !data) return

      // If a game name somehow collides across two files, keep the one
      // uploaded/replaced most recently.
      const files = [...data].sort((a, b) => (a.updated_at ?? '').localeCompare(b.updated_at ?? ''))

      let changed = false
      for (const game of GAMES) {
        if (game.bannerUrl) continue // manual override in games.ts always wins
        const dbKeyNorm = normalize(game.dbKey)
        const nameNorm = normalize(game.name)
        const match = files.find(f => {
          const base = normalize(f.name.replace(/\.[^.]+$/, ''))
          return base === dbKeyNorm || base === nameNorm
        })
        if (match) {
          const { data: pub } = supabase.storage.from(BANNER_BUCKET).getPublicUrl(`${BANNER_FOLDER}/${match.name}`)
          game.bannerUrl = pub.publicUrl
          changed = true
        }
      }
      if (changed) notifyListeners()
    })()
  }
  return loadPromise
}

/**
 * Call once near the top of a Games Zone screen. Kicks off the storage
 * lookup (shared across every caller — only fetches once per page load)
 * and re-renders the calling component once banners resolve, which
 * cascades down to every child reading `game.bannerUrl` off the shared
 * GAMES catalog.
 */
export function useGameBanners() {
  const [, force] = useReducer((n: number) => n + 1, 0)
  useEffect(() => {
    listeners.add(force)
    loadBanners()
    return () => { listeners.delete(force) }
  }, [])
}
