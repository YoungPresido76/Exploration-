// src/features/games/SessionStatusBar.tsx
// Sits at the top of the Games page. Shows session usage as a colored
// percentage bar (blue → yellow → orange → red as it climbs — see
// usageTier.ts) instead of a raw "15/15" count, since the raw number
// swings per pro tier (15/19/25) while the percentage always reads the
// same. Once the limit is hit, this shows a plain "till <clock time>"
// line computed once from resetAt — no more live-ticking countdown.
import { Gamepad2, Clock } from 'lucide-react'
import { usageTierColor, formatResetClock } from '../../shared/lib/usageTier'
import UsageBar from '../../shared/components/UsageBar'

export default function SessionStatusBar({
  count, limit, limitReached, resetAt,
}: {
  count: number
  limit: number
  limitReached: boolean
  resetAt: number   // epoch ms, 0 if not applicable
}) {
  const pct = limit > 0 ? Math.min(100, Math.round((count / limit) * 100)) : 0
  const color = usageTierColor(pct)
  const resetLabel = resetAt ? formatResetClock(resetAt) : null

  return (
    <div className="neu-card" style={{ padding: '13px 16px', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
      {limitReached ? (
        <>
          <Clock size={18} style={{ color: '#9b6dff', flexShrink: 0 }} />
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: 0 }}>Limit reached</p>
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '2px 0 0' }}>
              {resetLabel ? `More sessions till ${resetLabel}` : 'More sessions soon'}
            </p>
          </div>
        </>
      ) : (
        <>
          <Gamepad2 size={18} style={{ color, flexShrink: 0 }} />
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: 0 }}>
              {pct}% used today
            </p>
            <div style={{ marginTop: 6 }}>
              <UsageBar pct={pct} />
            </div>
          </div>
        </>
      )}
    </div>
  )
}
