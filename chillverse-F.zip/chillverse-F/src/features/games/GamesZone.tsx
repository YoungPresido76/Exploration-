// src/features/games/GamesZone.tsx
// Games Home — entry point for the /games route. Hero slider up top, then
// Trending Now, today's session status, the Categories row, and Favorite
// (starred) Games. Deep links that carry location.state.openGame (game
// tags in posts, "Vs AI" from Multiplayer, etc.) skip straight past this
// landing screen into the game list, since that's an explicit "launch
// this game" intent rather than browsing.
import { useState, useEffect, useCallback } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { usePageHeader } from '../../context/PageHeader'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { isProActive, getSessionLimits } from '../../shared/lib/proPlans'
import { getGlobalSessionInfo } from './gameSession'
import { GAMES, CATEGORIES, type CategoryKey, type GameId } from './games'
import { fetchTrendingGames, type TrendingEntry } from './gamesHomeData'
import { useGameBanners } from './gameBanners'
import HeroSlider, { type SlideDef } from './HeroSlider'
import TrendingGameCard from './TrendingGameCard'
import SessionStatusBar from './SessionStatusBar'
import FavoriteGamesRow from './FavoriteGamesRow'
import CategoryPage from './CategoryPage'
import Toast, { useToast } from '../../shared/components/Toast'
import { useHaloDailyFlow } from '../halo-moments/useHaloDailyFlow'
import MysteryBoxModal from '../halo-moments/MysteryBoxModal'
import Games from './Games'
import ActivityGoals from './ActivityGoals'
import GameZoneFlashSale from './GameZoneFlashSale'
import FortuneVault from '../fortune/FortuneVault'
import { fetchFortuneVault, VAULT_FALLBACK, type FortuneVault as FortuneVaultRow } from '../fortune/fortuneVault'
import { useFeatureFlags } from '../../shared/lib/featureFlags'
import { useModRole } from '../moderation/useModRole'
import Impostor from '../impostor/Impostor'
import MinoEntry from '../mino/MinoEntry'
import { MINO_MODAL_IMAGE } from '../mino/minoConfig'

type ZoneView = 'landing' | 'games' | 'activity' | 'category' | 'fortune' | 'impostor'

const SLIDE_IMAGES = {
  diamond:    'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Onboarding/00d02f00d03fbbcb65ba14e97e509491.jpg',
  fortune:    'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Onboarding/0eda2173d4487db6bf6c7868e62a00a3.webp.jpg',
  leaderboard:'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/23bf1450a7fc18f82d6b22d0b7545a00.webp.jpg',
  goals:      'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Untitled%20folder/fb163cb2b77ad565dd6be458ddbdf3aa.jpg',
  multiplayer:'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Pics/file_000000000f2c71f4b5f22c29bcd8508b.png',
  exploration:'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Untitled%20folder/Explore.jpg',
  // Owed by the user. Until it lands in the bucket this slide renders with a
  // broken image, so upload before deploying the flag ON.
  impostor:   'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Games/Impostor.png',
}

export default function GamesZone() {
  const navigate = useNavigate()
  const location = useLocation()
  // Two kinds of deep link land here, and they mean different things.
  //
  //   • openGame    — launch it. Used by Multiplayer's "Vs AI" hub, which
  //                   has already shown its own pre-game sheet, so a second
  //                   confirmation would be a pointless extra tap.
  //   • previewGame — open the detail sheet first. Used by game tags in
  //                   feed posts, where the tap means "what's this game?"
  //                   rather than "start a round now". Launching straight
  //                   from a post would spend a session on someone who was
  //                   only reading.
  const deepLink = location.state as { openGame?: string; previewGame?: GameId } | null
  const hasDeepLink = !!(deepLink?.openGame || deepLink?.previewGame)

  const [view, setView] = useState<ZoneView>(hasDeepLink ? 'games' : 'landing')
  const [category, setCategory] = useState<CategoryKey>('all')
  const [pendingOpenGameId, setPendingOpenGameId] = useState<GameId | null>(deepLink?.previewGame ?? null)

  // Consume the preview link so backing out of the sheet and returning to
  // this page doesn't pop it open again. Only previewGame is cleared here —
  // Games.tsx clears openGame itself, once its session gate is ready.
  useEffect(() => {
    if (!deepLink?.previewGame) return
    navigate(location.pathname, { replace: true, state: null })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const { session } = useAuth()
  const userId = session?.user?.id ?? ''
  const { profile, refetch: refetchProfile } = useProfile()
  const sessionLimit = getSessionLimits(profile).limit

  // Resolves banner images for any game missing one, straight from the
  // Adverts/Games storage folder — see gameBanners.ts. Placed above the
  // view-dependent early returns below so it runs no matter which Games
  // Zone screen (landing/games/category) is active.
  useGameBanners()

  const [sessionInfo, setSessionInfo] = useState({ count: 0, limit: sessionLimit, limitReached: false, resetAt: 0, ok: false })
  const [trending, setTrending] = useState<TrendingEntry[] | null>(null)
  const [showMysteryBox, setShowMysteryBox] = useState(false)
  const [showMino, setShowMino] = useState(false)

  const { handleBoxOpened } = useHaloDailyFlow(userId || null)
  const { toast } = useToast()

  const refreshSessionInfo = useCallback(() => {
    if (!userId) return
    getGlobalSessionInfo(userId, sessionLimit).then(setSessionInfo)
  }, [userId, sessionLimit])

  useEffect(() => {
    refreshSessionInfo()
  }, [refreshSessionInfo])

  useEffect(() => {
    fetchTrendingGames().then(setTrending)
  }, [])

  // Fortune Vault — the slide only exists while a board is actually live, the
  // same way GameZoneFlashSale hides itself between sales. Staff keep the
  // slide when the flag is off so a locked feature can still be checked from
  // the inside; that matches the posture Games.tsx already takes on game flags.
  const [liveVault, setLiveVault] = useState<FortuneVaultRow | null>(null)
  const { isEnabled: flagEnabled, loading: flagsLoading } = useFeatureFlags()
  const { isStaff } = useModRole()
  const vaultOpen = !flagsLoading && (flagEnabled('fortune:vault') || isStaff)
  // Impostor and Mino carry the same kind of kill switch the Vault does: flag
  // off means the slide leaves the carousel entirely rather than opening onto
  // a gate screen. Staff keep both so a locked feature can still be checked
  // from the inside — the posture Games.tsx already takes on game flags.
  const impostorOpen = !flagsLoading && (flagEnabled('game:impostor') || isStaff)
  const minoOpen = !flagsLoading && (flagEnabled('game:mino') || isStaff)

  useEffect(() => {
    fetchFortuneVault().then(({ data }) => setLiveVault(data.vault))
  }, [])

  // Opens a game's detail sheet directly, staying on this page underneath
  // it — no more routing away to the old full-page game list first.
  const navigateToGame = useCallback((id: GameId) => {
    setPendingOpenGameId(id)
    setView('games')
  }, [])

  function openCategory(key: CategoryKey) {
    setCategory(key)
    setView('category')
  }

  function handleOpenTrendingEntry(entry: TrendingEntry) {
    navigateToGame(entry.meta.id)
  }

  const subTierLabel = isProActive(profile)
    ? (profile?.pro_tier === 'void' ? 'Void' : 'Orbit')
    : null

  // Only the landing screen owns the Topbar here — the games/activity/category
  // sub-views either register their own (CategoryPage, ActivityGoals) or sit
  // behind a fullscreen modal where it doesn't matter (Games).
  usePageHeader(
    view === 'landing' ? { title: 'Games', onBack: () => navigate('/dashboard') } : null
  )

  const favoriteGames = GAMES.filter(g => profile?.pinned_games?.includes(g.id))

  const slides: SlideDef[] = [
    // Sits first while it's running — it's the only slide with an expiry, so
    // burying it behind six evergreen ones would waste the window.
    ...(liveVault && vaultOpen ? [{
      img: liveVault.banner_url || SLIDE_IMAGES.fortune,
      // Admin-set per board, so a seasonal vault announces itself as the
      // event rather than as a generic prize board.
      tag: liveVault.tag || VAULT_FALLBACK.tag,
      header: liveVault.title || VAULT_FALLBACK.title,
      text: liveVault.subtitle || VAULT_FALLBACK.subtitle,
      buttonLabel: 'Open', onAction: () => setView('fortune'),
    } satisfies SlideDef] : []),
    ...(impostorOpen ? [{
      img: SLIDE_IMAGES.impostor, tag: 'Police vs Thieves', header: 'Impostor',
      text: 'Draw the torch or draw a mask. Three rounds, roles swap, and only one side walks away clean.',
      buttonLabel: 'Play', onAction: () => setView('impostor'),
    } satisfies SlideDef] : []),
    {
      img: SLIDE_IMAGES.diamond, tag: 'Welcome Bonus', header: 'Diamond Bonus',
      text: 'Top up in Chillverse for the first time and get a bonus amount back.',
      buttonLabel: 'Claim', onAction: () => navigate('/buy-diamonds'),
    },
    {
      img: SLIDE_IMAGES.fortune, tag: 'Fortune', header: 'Halo Moments',
      text: 'Daily claim on Chillverse Fortune — come back everyday for goodies.',
      buttonLabel: 'Claim Goodies', onAction: () => setShowMysteryBox(true),
    },
    {
      img: SLIDE_IMAGES.leaderboard, tag: 'Rank Up', header: 'Leaderboards',
      text: 'Check your position in all the games you have played so far.',
      buttonLabel: 'Check', onAction: () => navigate('/leaderboards'),
    },
    {
      img: SLIDE_IMAGES.goals, tag: 'Goals', header: 'Activity Goals',
      text: 'Play games, have fun, get rewarded instantly. Tap in to see your current goal progress.',
      buttonLabel: 'Goal', onAction: () => setView('activity'),
    },
    {
      img: SLIDE_IMAGES.multiplayer, tag: 'Versus Unlimited', header: 'Multiplayer',
      text: 'Play against AI, against other players, and explore other cooler games you have never tried before.',
      buttonLabel: 'Go', onAction: () => navigate('/multiplayer'),
    },
    {
      img: SLIDE_IMAGES.exploration, tag: 'Adventure', header: 'Exploration',
      text: 'Explore mysterious maps, uncover hidden artifacts, and discover secrets waiting to be found.',
      buttonLabel: 'Dive In', onAction: () => navigate('/exploration'),
    },
    ...(minoOpen ? [{
      img: MINO_MODAL_IMAGE, tag: 'Deadly games', header: 'Mino game',
      text: "Play a series of inspired deadly games from various events we've held. Locks in the morning.",
      buttonLabel: 'Dive in', onAction: () => setShowMino(true),
    } satisfies SlideDef] : []),
  ]

  if (view === 'games') return <Games onBack={() => { setView('landing'); setPendingOpenGameId(null); refreshSessionInfo() }} openGameId={pendingOpenGameId} onFavoritesChanged={refetchProfile} />
  if (view === 'activity') return <ActivityGoals onBack={() => setView('landing')} />
  if (view === 'fortune') return <FortuneVault onBack={() => setView('landing')} />
  if (view === 'impostor') return <Impostor onBack={() => { setView('landing'); refreshSessionInfo() }} />
  if (view === 'category') {
    return (
      <CategoryPage
        category={category}
        onBack={() => setView('landing')}
        onOpenGame={navigateToGame}
      />
    )
  }

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', paddingBottom: 48 }}>
      {subTierLabel && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
          <span style={{
            fontSize: 11, fontWeight: 800, letterSpacing: 0.4, textTransform: 'uppercase',
            color: subTierLabel === 'Void' ? 'var(--purple, #9b6dff)' : 'var(--blue, #4f8ef7)',
            background: subTierLabel === 'Void' ? 'rgba(155,109,255,0.12)' : 'rgba(79,142,247,0.12)',
            border: `1px solid ${subTierLabel === 'Void' ? 'rgba(155,109,255,0.3)' : 'rgba(79,142,247,0.3)'}`,
            borderRadius: 8, padding: '4px 10px',
          }}>
            {subTierLabel}
          </span>
        </div>
      )}

      {/* Hero slider */}
      <HeroSlider slides={slides} />

      {/* Mino Games — nightly elimination event. Owns its own modal/run
          handoff and renders nothing until opened. Mounted here rather than
          inside the slide so closing it returns to this page instead of
          unmounting the slider underneath it. */}
      <MinoEntry open={showMino} onClose={() => setShowMino(false)} />

      {/* Flash Sale — only rendered while a sale (Ops console: Flash Sale
          Schedule) is actually open; auto-hides itself the moment it closes. */}
      <GameZoneFlashSale />

      {/* Trending Now */}
      <section style={{ marginBottom: 22 }}>
        <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', margin: '0 0 12px' }}>🔥 Trending Now</p>
        {trending === null ? (
          <div style={{ display: 'flex', gap: 12 }}>
            {[0, 1, 2].map(i => (
              <div key={i} style={{ width: 148, aspectRatio: '1/1', borderRadius: 16, background: 'var(--surface2)', flexShrink: 0 }} />
            ))}
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 4 }}>
            {trending.map(entry => {
              const meta = entry.meta
              // Solo Pro titles (Uno, Colour Block) still open their detail
              // sheet on tap — which carries the Pro lock and an upgrade
              // CTA — but the padlock belongs on the card too.
              const locked = !!meta.requiresPro && !isProActive(profile)
              return (
                <TrendingGameCard
                  key={entry.key}
                  name={meta.name}
                  tag={meta.category ?? 'Game'}
                  accent={meta.accent}
                  icon={meta.icon}
                  bannerUrl={meta.bannerUrl}
                  isHot={entry.isHot}
                  isNew={entry.isNew}
                  locked={locked}
                  onOpen={() => handleOpenTrendingEntry(entry)}
                />
              )
            })}
          </div>
        )}
      </section>

      {/* Session status */}
      <SessionStatusBar {...sessionInfo} />

      {/* Categories */}
      <section style={{ marginBottom: 24 }}>
        <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', margin: '0 0 12px' }}>Categories</p>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
          {CATEGORIES.map(c => (
            <button
              key={c.key}
              type="button"
              onClick={(e) => { ripple(e); openCategory(c.key) }}
              style={{
                flexShrink: 0, fontSize: 12.5, fontWeight: 700, color: 'var(--text)',
                background: 'var(--surface)', border: '1px solid var(--border)',
                boxShadow: 'var(--elev-raise-sm)', borderRadius: 12, padding: '9px 16px',
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4,
              }}
            >
              {c.label} <ChevronRight size={12} style={{ color: 'var(--text-muted)' }} />
            </button>
          ))}
        </div>
      </section>

      {/* Favorite Games (was Hot Games — now shows starred games) */}
      <FavoriteGamesRow games={favoriteGames} onOpenGame={navigateToGame} />

      <MysteryBoxModal
        isOpen={showMysteryBox}
        onClose={() => setShowMysteryBox(false)}
        onOpened={handleBoxOpened}
      />
      <Toast toast={toast} />
    </div>
  )
}
