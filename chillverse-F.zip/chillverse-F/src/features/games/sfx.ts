// src/lib/sfx.ts
// Game SFX. Everything is a real audio file in public/sounds/, and everything
// respects the "Game sound" setting (default ON) from soundSettings.ts.
//
// One-shots are cloned on play so rapid re-triggering never cuts itself off.
// The timer tick is the exception — it's a single looping instance with an
// explicit start/stop, because a loop that nobody stops keeps ticking after
// you've left the game.

import { isGameSoundEnabled } from './soundSettings'

// ─── Real audio files ──────────────────────────────────────────────────────
const TREASURE_SRC = '/sounds/praise-treasure.wav'
const BLING_SRC = '/sounds/praise-bling.wav'
const GAME_OVER_SRC = '/sounds/game-over.mp3'
const WRONG_SRC = '/sounds/wrong-answer.mp3'
const BOMB_SRC = '/sounds/bomb.mp3'
const SAMURAI_INTRO_SRC = '/sounds/samurai-intro.mp3'
const LINE_CLEAR_SRC = '/sounds/line-clear.mp3'
const ELEMENTAL_CLEAR_SRC = '/sounds/elemental-clear.mp3'
const BLOCK_PLACE_SRC = '/sounds/block-place.mp3'
const VOICE_GREAT_SRC = '/sounds/voice-great.mp3'
const VOICE_AMAZING_SRC = '/sounds/voice-amazing.mp3'
const VOICE_EXCELLENT_SRC = '/sounds/voice-excellent.mp3'
const PVP_ATTACK_SRC = '/sounds/pvp-attack.mp3'
const TICK_SRC = '/sounds/tick.mp3'
const TILE_MATCH_SRC = '/sounds/tile-match.mp3'
const DIG_SRC = '/sounds/dig.mp3'
const COIN_SRC = '/sounds/coin.mp3'
const RUBY_SRC = '/sounds/crystal-chime.mp3'
const CURSE_SRC = '/sounds/curse.mp3'
const BANK_SRC = '/sounds/bank.mp3'
const LETTER_HIT_SRC = '/sounds/word-letter.mp3'
const LETTER_TRAP_SRC = '/sounds/word-trap.mp3'
const WORD_COMPLETE_SRC = '/sounds/word-complete.mp3'
const GUNSHOT_SRC = '/sounds/gunshot.mp3'

// Preload/cache Audio objects so repeated sounds don't re-fetch.
const audioCache = new Map<string, HTMLAudioElement>()
function getAudio(src: string): HTMLAudioElement {
  let el = audioCache.get(src)
  if (!el) {
    el = new Audio(src)
    el.preload = 'auto'
    audioCache.set(src, el)
  }
  return el
}

function playFile(src: string, volume = 0.7) {
  if (!isGameSoundEnabled()) return
  const el = getAudio(src)
  // Allow rapid re-triggering: clone so overlapping sounds don't cut off.
  const instance = el.cloneNode(true) as HTMLAudioElement
  instance.volume = volume
  instance.play().catch(() => {})
}

// Map each praise line to a sound "flavor" — bigger-feeling praise gets the
// bling/achievement sound, the rest get the lighter treasure blip.
const PRAISE_SOUND_MAP: Record<string, string> = {
  'Sharp eye!': TREASURE_SRC,
  'Locked in!': TREASURE_SRC,
  'Nailed it!': TREASURE_SRC,
  'Pattern King!': BLING_SRC,
  'Flawless!': BLING_SRC,
  'Unstoppable!': BLING_SRC,
}

/** Play the sound that matches a given praise line (e.g. "Nailed it!"). */
export function playPraiseSound(praiseText: string): void {
  const src = PRAISE_SOUND_MAP[praiseText] ?? TREASURE_SRC
  playFile(src)
}

/** Wrong tap / wrong answer — Pattern King, Colour Block, quiz games. */
export function playWrongCard(): void {
  playFile(WRONG_SRC, 0.6)
}

/** The run is over. Fires once from the result screen, every game. */
export function playGameOver(): void {
  playFile(GAME_OVER_SRC, 0.65)
}

/** The Last Samurai — tapping the bomb card. Harsher than a wrong tap. */
export function playBomb(): void {
  playFile(BOMB_SRC, 0.75)
}

// ─── The Last Samurai theme (looping — must be stopped explicitly) ─────
// Same shape as the tick below: one instance, explicit start/stop, so it
// can't outlive the game screen.
let samuraiTheme: HTMLAudioElement | null = null

/** Start the Samurai theme on a loop. Safe to call repeatedly. */
export function startSamuraiTheme(): void {
  if (!isGameSoundEnabled()) return
  if (samuraiTheme) return
  const el = new Audio(SAMURAI_INTRO_SRC)
  el.loop = true
  el.volume = 0.4 // sits under the SFX rather than competing with them
  samuraiTheme = el
  el.play().catch(() => {})
}

/** Stop the Samurai theme. Safe to call when nothing is playing. */
export function stopSamuraiTheme(): void {
  if (!samuraiTheme) return
  samuraiTheme.pause()
  samuraiTheme.currentTime = 0
  samuraiTheme = null
}

/** Elementa — a row or column clearing off the board. */
export function playLineClear(): void {
  playFile(LINE_CLEAR_SRC, 0.65)
}

/** Elementa — a clear where every cell shared one element. The payoff. */
export function playElementalClear(): void {
  playFile(ELEMENTAL_CLEAR_SRC, 0.75)
}

/** Elementa — a block landing on the board. Quiet: it fires constantly. */
export function playBlockPlace(): void {
  playFile(BLOCK_PLACE_SRC, 0.45)
}

/** Spoken praise for a combo tier. Louder than the SFX — it's the reward. */
export type PraiseTier = 'great' | 'amazing' | 'excellent'
const PRAISE_VOICE: Record<PraiseTier, string> = {
  great: VOICE_GREAT_SRC,
  amazing: VOICE_AMAZING_SRC,
  excellent: VOICE_EXCELLENT_SRC,
}
export function playPraiseVoice(tier: PraiseTier): void {
  playFile(PRAISE_VOICE[tier], 0.85)
}

/** Chill Link — a pair linking and clearing off the board. Quiet: it
 *  fires several times a second on a good run. */
export function playTileMatch(): void {
  playFile(TILE_MATCH_SRC, 0.5)
}

/** Chill Link — clearing a whole board. Deliberately NOT Elementa's
 *  elemental-clear file: the two games should not sound like each other.
 *  It's the same link sound played as a quick two-note flourish, louder —
 *  same voice as the match it caps off, but unmistakably bigger. */
export function playBoardClear(): void {
  if (!isGameSoundEnabled()) return
  playFile(TILE_MATCH_SRC, 0.8)
  window.setTimeout(() => playFile(TILE_MATCH_SRC, 0.7), 150)
}

// ─── Plunder ───────────────────────────────────────────────────────────
// Deliberately its own set rather than borrowing from Elementa, Chill Link
// or the Samurai — a dive should not sound like a tile puzzle. The dig and
// the coin fire together on every safe tile, so both are mixed low: the dig
// is the body of the sound and the coin is the sparkle on top of it.

/** Plunder — the spade going into the sand. Fires on every safe dig. */
export function playDig(): void {
  playFile(DIG_SRC, 0.45)
}

/** Plunder — the coin landing in the hold. Layered over playDig(). */
export function playCoin(): void {
  playFile(COIN_SRC, 0.5)
}

/** Plunder — the buried ruby. Rare, so it gets to be loud. */
export function playRuby(): void {
  playFile(RUBY_SRC, 0.8)
}

/** Plunder — a curse. The run just ended; this is the sting. */
export function playCurse(): void {
  playFile(CURSE_SRC, 0.8)
}

/** Plunder — banking the hold and dropping to the next depth. */
export function playBank(): void {
  playFile(BANK_SRC, 0.7)
}

/** Plunder — the "Naughty!" pop, fired when a player has stripped a depth
 *  down to its last safe tile without taking a curse. Borrows the bling
 *  from the praise set for now; swap the source here if a pirate-flavoured
 *  sting turns up. */
export function playNaughty(): void {
  playFile(BLING_SRC, 0.75)
}

// ─── Word Blitz ────────────────────────────────────────────────────────
// Also its own set — a falling-letter reaction game needs a brighter,
// twitchier palette than the tile/board games share. Letter hit and word
// complete are the two sounds a player hears constantly, so both are kept
// short and light; the trap buzz and perfect chime are rarer and get more
// headroom to stand out against them.

/** Word Blitz — a correct letter tapped. Fires on every successful tap,
 *  so it has to be short enough not to overlap itself during a fast run. */
export function playLetterHit(): void {
  playFile(LETTER_HIT_SRC, 0.32)
}

/** Word Blitz — tapped a letter while it was flashing red. Harsher than a
 *  normal wrong tap since it's a trap, not a misread. */
export function playLetterTrap(): void {
  playFile(LETTER_TRAP_SRC, 0.5)
}

/** Word Blitz — a word finished (imperfect is fine, just not empty-handed). */
export function playWordComplete(): void {
  playFile(WORD_COMPLETE_SRC, 0.42)
}

/** Word Blitz — a word finished Perfect, extending the Chain Combo. Same
 *  file as playWordComplete() but layered — two staggered hits instead of
 *  one, same trick as playBoardClear() — so Perfect reads as unmistakably
 *  bigger without needing a second source file. */
export function playWordPerfect(): void {
  if (!isGameSoundEnabled()) return
  playFile(WORD_COMPLETE_SRC, 0.5)
  window.setTimeout(() => playFile(WORD_COMPLETE_SRC, 0.36), 120)
}

/** PvP — an attack card actually firing at a target. */
export function playPvpAttack(): void {
  playFile(PVP_ATTACK_SRC, 0.7)
}

// ─── Timer tick (looping — must be stopped explicitly) ─────────────────────
// Deliberately NOT cloned: there is only ever one tick loop, so start/stop
// can always find and kill it. Quieter than the one-shots since it runs
// under whatever else is happening.
let tickInstance: HTMLAudioElement | null = null

/** Start the countdown tick. Safe to call repeatedly — only one loop runs. */
export function startTicking(): void {
  if (!isGameSoundEnabled()) return
  if (tickInstance) return
  const el = new Audio(TICK_SRC)
  el.loop = true
  el.volume = 0.35
  tickInstance = el
  el.play().catch(() => {})
}

/** Stop the countdown tick. Safe to call when nothing is ticking. */
export function stopTicking(): void {
  if (!tickInstance) return
  tickInstance.pause()
  tickInstance.currentTime = 0
  tickInstance = null
}

/** Impostor — the police taking a shot. Fires on every trigger pull, hit or
 *  miss, because the flinch it causes in whoever is hiding is half the point.
 *  Falls back to silence if the file isn't there yet (playFile swallows the
 *  rejected play()). */
export function playGunshot(): void {
  playFile(GUNSHOT_SRC, 0.55)
}
