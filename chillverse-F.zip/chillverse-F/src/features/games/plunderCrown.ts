// src/features/games/plunderCrown.ts
// ─── The Plunder crown ────────────────────────────────────────────────
// Whoever tops the Plunder leaderboard wears a pirate hat over their
// avatar everywhere in the app — chat, feed, leaderboard, profile — the
// way a Discord decoration sits over a profile picture.
//
// The 24-hour grace period is enforced entirely in the database (see
// migration 0139_plunder_crown.sql). This module only reads the answer,
// so there is no clock logic on the client to drift or be tampered with.
//
// One champion for the whole app means one row, fetched once and shared:
// a module-level store rather than a context, because Avatar renders in
// long lists and every instance needs the answer without a provider
// wrapping half the tree.
//
// Since 0181 there are TWO answers, and keeping them apart matters:
// HOLDING the crown is what Plunder's own copy talks about, and WEARING
// it is what puts the hat on an avatar. The hat is a drip now, so a
// champion who has taken it off still holds it. plunder_hat_state()
// returns both in the same single row — it has to be an RPC rather than a
// join from here, because the wearing lives in another player's
// equipped_drip, which the profiles read policy doesn't hand out.
import { useSyncExternalStore } from 'react'
import { supabase } from '../../shared/lib/supabase'

/** NOTE: must be a PNG with a real alpha channel — it is layered over the
 *  avatar, so a JPEG renders as an opaque rectangle across the face. */
export const PLUNDER_CROWN_SRC =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/Hat.png'

const GAME   = 'plunder'
const TTL_MS = 5 * 60_000

let championId: string | null = null
let wearerId: string | null = null
let fetchedAt = 0
let inflight: Promise<void> | null = null
const listeners = new Set<() => void>()

function load(force = false): Promise<void> {
  if (!force && Date.now() - fetchedAt < TTL_MS) return Promise.resolve()
  if (inflight) return inflight

  const pending = (async () => {
    try {
      const { data } = await supabase
        .rpc('plunder_hat_state')
        .maybeSingle<{ user_id: string | null; worn: boolean }>()

      const nextChampion = data?.user_id ?? null
      const nextWearer = data?.worn ? nextChampion : null
      if (nextChampion !== championId || nextWearer !== wearerId) {
        championId = nextChampion
        wearerId = nextWearer
        listeners.forEach(l => l())
      }
    } catch {
      // A failed read leaves the last known answer in place rather than
      // yanking the hat off someone's avatar mid-scroll.
    } finally {
      fetchedAt = Date.now()
    }
  })().finally(() => { inflight = null })

  inflight = pending
  return pending
}

function subscribe(cb: () => void): () => void {
  listeners.add(cb)
  void load()
  return () => { listeners.delete(cb) }
}

function championSnapshot(): string | null { return championId }
function wearerSnapshot(): string | null { return wearerId }

/**
 * The user id who currently HOLDS the Plunder crown, or null.
 *
 * Holding it is not the same as showing it — this is the one to ask when
 * the question is "did they win", not "is the hat on".
 */
export function usePlunderCrown(): string | null {
  return useSyncExternalStore(subscribe, championSnapshot, championSnapshot)
}

/**
 * The user id currently WEARING the hat, or null — which includes null
 * when the champion holds it but has equipped something else, or nothing.
 * This is the one that decides whether an avatar gets a hat drawn on it.
 */
export function usePlunderHatWearer(): string | null {
  return useSyncExternalStore(subscribe, wearerSnapshot, wearerSnapshot)
}

/** Pull the wearing state again after the player changes their drip, so
 *  the hat appears or vanishes on their own avatar without a reload. */
export function refreshPlunderHat(): void {
  void load(true)
}

/** Ask the server to re-evaluate the crown, then pull the fresh answer.
 *  Fire-and-forget — called after a Plunder run is banked. */
export function refreshPlunderCrown(): void {
  supabase
    .rpc('refresh_game_crown', { p_game: GAME })
    .then(() => load(true), () => {})
}
