// src/features/games/GameZoneFlashSale.tsx
//
// The Flash Sale card + modal for the Games Home landing screen. Renders
// nothing while no flash sale is active (weekly_special / monthly_mega,
// migration 0097, edited on the Ops console's dedicated Flash Sales page —
// AdminFlashSalePage.tsx) and appears/disappears on its own as the sale
// window opens or closes, via the same useActiveFlashSale() poll BuyDiamonds
// uses — so this and the Buy Diamonds page always agree on what's live.
//
// The modal does a real purchase (Paystack checkout via the shared
// useDiamondPurchase hook), not a link out to another page — a Game Zone
// visitor buys without leaving the Game Zone.
import { useState } from 'react'
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { useDiamondPurchase, useIsFirstPurchase } from '../economy/useDiamondPurchase'
import PurchaseResultModal from '../economy/PurchaseResultModal'
import {
  useActiveFlashSale, formatNaira, formatFlashCountdown, formatFlashDurationTag,
} from '../economy/flashSale'

export default function GameZoneFlashSale() {
  const { flashSale, tick } = useActiveFlashSale()
  const [open, setOpen] = useState(false)
  const isFirstPurchase = useIsFirstPurchase()
  const { loading, modal, activeItem, purchase, retry, closeModal } = useDiamondPurchase()
  const [cardImgFailed, setCardImgFailed] = useState(false)
  const [modalImgFailed, setModalImgFailed] = useState(false)

  // Nothing live right now — card and modal both stay off the page
  // entirely (not just visually hidden) until a schedule opens again.
  if (!flashSale || flashSale.items.length === 0) return null

  const durationTag = formatFlashDurationTag(flashSale.starts_at, flashSale.ends_at)

  return (
    <>
      <section style={{ marginBottom: 22 }}>
        <button
          type="button"
          onClick={(e) => { ripple(e); setOpen(true) }}
          style={{
            width: '100%', textAlign: 'left', cursor: 'pointer', padding: 0,
            border: '1px solid var(--border)', borderRadius: 18, overflow: 'hidden',
            background: 'var(--surface2)', boxShadow: 'var(--elev-raise-sm)', position: 'relative',
          }}
        >
          {flashSale.image_url && !cardImgFailed && (
            <div style={{ position: 'relative', width: '100%', height: 120 }}>
              <img
                src={flashSale.image_url}
                alt=""
                onError={() => setCardImgFailed(true)}
                style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
              />
              <div style={{
                position: 'absolute', inset: 0,
                background: 'linear-gradient(180deg, rgba(0,0,0,0) 40%, rgba(0,0,0,0.55) 100%)',
              }} />
            </div>
          )}
          <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <span style={{
                display: 'inline-block', fontSize: 10, fontWeight: 800, letterSpacing: 0.3,
                color: 'var(--accent)', background: 'color-mix(in srgb, var(--accent) 15%, transparent)',
                borderRadius: 6, padding: '3px 7px', marginBottom: 6,
              }}>
                ⚡ FLASH SALE
              </span>
              <p style={{
                fontSize: 15, fontWeight: 800, color: 'var(--text)', margin: 0,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>
                {flashSale.title}
              </p>
            </div>
            <span style={{
              flexShrink: 0, fontSize: 12.5, fontWeight: 800, color: '#fff',
              background: 'linear-gradient(135deg,var(--accent),#f5c542)',
              borderRadius: 10, padding: '8px 16px',
              boxShadow: '0 4px 14px color-mix(in srgb, var(--accent) 35%, transparent)',
            }}>
              Check
            </span>
          </div>
        </button>
      </section>

      {open && createPortal(
        <div
          onClick={(e) => { if (e.target === e.currentTarget) setOpen(false) }}
          style={{
            position: 'fixed', inset: 0, zIndex: 9998, background: 'rgba(0,0,0,0.72)',
            backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center',
            justifyContent: 'center', padding: 20, animation: 'fsFadeIn 0.2s ease both',
          }}
        >
          <div style={{
            width: '100%', maxWidth: 380, maxHeight: '85dvh', overflowY: 'auto',
            background: 'var(--surface2)', borderRadius: 24, border: '1px solid var(--border)',
            boxShadow: 'var(--elev-popover)', position: 'relative',
            animation: 'fsPopIn 0.32s cubic-bezier(0.34,1.56,0.64,1) both',
          }}>
            <button
              onClick={() => setOpen(false)}
              aria-label="Close"
              style={{
                position: 'absolute', top: 14, right: 14, width: 28, height: 28, borderRadius: 8,
                background: 'rgba(0,0,0,0.35)', border: 'none', cursor: 'pointer', color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10,
              }}
            >
              <X size={13} />
            </button>

            {flashSale.image_url && !modalImgFailed && (
              <img
                src={flashSale.image_url} alt=""
                onError={() => setModalImgFailed(true)}
                style={{ width: '100%', height: 150, objectFit: 'cover', display: 'block', borderRadius: '24px 24px 0 0' }}
              />
            )}

            <div style={{ padding: '18px 18px 20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
                <span style={{
                  fontSize: 10, fontWeight: 800, letterSpacing: 0.3, color: 'var(--accent)',
                  background: 'color-mix(in srgb, var(--accent) 15%, transparent)',
                  borderRadius: 6, padding: '3px 7px',
                }}>
                  ⚡ FLASH SALE
                </span>
                <span style={{
                  fontSize: 10, fontWeight: 800, color: 'var(--text-dim)',
                  background: 'var(--surface3)', border: '1px solid var(--border)',
                  borderRadius: 6, padding: '3px 7px',
                }}>
                  {durationTag}
                </span>
                <span key={tick} style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--text-muted)', marginLeft: 'auto' }}>
                  {formatFlashCountdown(flashSale.ends_at)}
                </span>
              </div>

              <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)', margin: '0 0 3px' }}>{flashSale.title}</p>
              {flashSale.subtitle && (
                <p style={{ fontSize: 12, color: 'var(--text-dim)', margin: '0 0 14px', lineHeight: 1.5 }}>{flashSale.subtitle}</p>
              )}

              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {flashSale.items.map(item => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
                      padding: '10px 12px', borderRadius: 14, background: 'var(--surface3)', border: '1px solid var(--border)',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                      <div style={{
                        width: 34, height: 34, borderRadius: 10,
                        background: 'color-mix(in srgb, var(--accent) 10%, transparent)',
                        border: '1px solid color-mix(in srgb, var(--accent) 20%, transparent)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0,
                      }}>
                        ⚡
                      </div>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
                          {item.diamonds.toLocaleString()} 💎
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 1 }}>
                          <span style={{ fontSize: 11, color: 'var(--text-muted)', textDecoration: 'line-through' }}>
                            {formatNaira(item.original_price_cents)}
                          </span>
                          <span style={{ fontSize: 9.5, fontWeight: 800, color: 'var(--accent)' }}>
                            -{Math.round(item.discount_pct)}%
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => { ripple(e); purchase(item, { isFirstPurchase, missionKey: 'diamond_packs_bought' }) }}
                      disabled={loading}
                      className="ripple-wrap"
                      style={{
                        padding: '9px 16px', borderRadius: 11, border: 'none',
                        cursor: loading ? 'not-allowed' : 'pointer',
                        background: loading ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),#f5c542)',
                        color: '#fff', fontSize: 13, fontWeight: 800, fontFamily: 'inherit', flexShrink: 0,
                        boxShadow: loading ? 'none' : '0 4px 14px color-mix(in srgb, var(--accent) 35%, transparent)',
                      }}
                    >
                      {formatNaira(item.sale_price_cents)}
                    </button>
                  </div>
                ))}
              </div>

              <p style={{ fontSize: 10.5, color: 'var(--text-muted)', textAlign: 'center', margin: '14px 0 0', lineHeight: 1.5 }}>
                Payments are processed securely by Paystack. Diamonds are non-refundable.
              </p>
            </div>
          </div>

          <style>{`
            @keyframes fsFadeIn { from{opacity:0} to{opacity:1} }
            @keyframes fsPopIn { from{opacity:0; transform:scale(0.94)} to{opacity:1; transform:scale(1)} }
          `}</style>
        </div>,
        document.body,
      )}

      {modal && (
        <PurchaseResultModal
          kind={modal}
          item={activeItem}
          onClose={closeModal}
          onRetry={modal === 'cancelled' || modal === 'error' ? retry : undefined}
        />
      )}
    </>
  )
}
