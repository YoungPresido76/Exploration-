// src/lib/gameSession.ts
import { supabase } from '../../shared/lib/supabase'
import { updateMissionProgress } from '../missions/weeklyMissions'
import {
  checkXpMilestoneHighlight,
  checkPersonalBestHighlight,
  checkLeaderboardRankHighlight,
} from '../highlights/highlightTriggers'
import { checkForLevelUp } from '../levelup/levelUpDetector'
import { recordDuoPlay } from '../duo/duo'
import { markDuoPlayPending, publishDuoPlay } from '../duo/duoBus'
import { refreshPlunderCrown } from './plunderCrown'
import type { GameRank } from './play/types'

export type GameKey =
  | 'arrow_dash'
  | 'pattern_memory'
  | 'rapid_sort'
  | 'trivia_clash'
  | 'tac_zone'
  | 'two_truths'
  | 'speed_math'
  | 'liars_grid'
  | 'hangman'
  | 'close_call'
  | 'pattern_king'
  | 'uno'
  | 'colour_block'
  | 'tile_merge'
  | 'foodie'
  | 'the_last_samurai'
  | 'elementa'
  | 'chill_link'
  | 'plunder'
  | 'word_blitz'
  // Impostor writes its own game_sessions row from the server (see
  // _impostor_finish), so this key exists for reads — leaderboards, play
  // counts, highlights — rather than for saveGameSession.
  | 'impostor'

export interface SessionInput {
  game: GameKey
  score: number
  xpEarned: number
  durationSec: number
  rank?: GameRank
  streak?: number
  metadata?: Record<string, unknown>
}

export interface PlayerRankRow {
  user_id: string
  game: GameKey
  rank: GameRank
  current_streak: number
  all_time_streak: number
  updated_at: string
}

// ─── Global session limit (server-side, via Supabase) ─────────
// Previously stored in localStorage — trivially bypassed by clearing
// site data or switching browsers. Now backed by the `session_limits`
// table + RPCs (see migration 0006_session_limits.sql) so the limit
// is enforced server-side and resettable via SQL.
const GLOBAL_LIMIT         = 15
const SESSION_COOLDOWN_HRS = 4.5 // lock duration once all 15 are burned

interface SessionInfoRow {
  count: number
  reset_at: string | null
}

interface IncrementSessionRow {
  count: number
  reset_at: string | null
  limit_reached: boolean
}

export interface GlobalSessionInfo {
  count: number
  limit: number
  limitReached: boolean
  resetAt: number
  /** False when the read failed. The zeroes below are a placeholder in that
   *  case, NOT a real "0 of 15 used" — anything gating play on this must
   *  check `ok` first, or a dropped request reads as a full allowance. */
  ok: boolean
}

export async function getGlobalSessionInfo(userId: string, limit: number = GLOBAL_LIMIT): Promise<GlobalSessionInfo> {
  const { data, error } = await supabase
    .rpc('get_session_info', { p_user_id: userId })
    .maybeSingle<SessionInfoRow>()

  if (error || !data) {
    console.error('getGlobalSessionInfo error:', error)
    return { count: 0, limit, limitReached: false, resetAt: 0, ok: false }
  }

  const resetAt = data.reset_at ? new Date(data.reset_at).getTime() : 0
  return {
    count: data.count,
    limit,
    limitReached: data.count >= limit,
    resetAt,
    ok: true,
  }
}

export async function incrementGlobalSession(
  userId: string,
  by = 1,
  limit: number = GLOBAL_LIMIT,
  cooldownHours: number = SESSION_COOLDOWN_HRS,
) {
  const { data, error } = await supabase
    .rpc('increment_session_count', {
      p_user_id: userId,
      p_by: by,
      p_limit: limit,
      p_cooldown_hours: cooldownHours,
    })
    .maybeSingle<IncrementSessionRow>()

  if (error) {
    console.error('incrementGlobalSession error:', error)
    return null
  }
  if (!data) return null

  const resetAt = data.reset_at ? new Date(data.reset_at).getTime() : 0
  return { count: data.count, resetAt, limitReached: data.limit_reached }
}

interface TryConsumeSessionRow {
  allowed: boolean
  count: number
  reset_at: string | null
  limit_reached: boolean
}

export interface ConsumeSessionResult {
  /** False means the server refused — the allowance was already gone and
   *  nothing was consumed. Whatever the run produced must not be banked. */
  allowed: boolean
  count: number
  resetAt: number
  limitReached: boolean
}

/**
 * Reserves `by` sessions, atomically, and tells you whether it worked.
 *
 * The difference from incrementGlobalSession above is that this one can say
 * no: if the allowance is spent, it leaves the counter alone and returns
 * allowed = false. That's the enforcement point — the limit used to live
 * only in the client's Play button, so any run that got started before the
 * count had loaded ran to completion and banked its XP anyway.
 *
 * See supabase/migrations/0105_session_limit_enforcement.sql.
 *
 * Returns null if the call failed outright (offline, etc.) — that's
 * "unknown", not "denied", so callers shouldn't treat it as a refusal.
 */
export async function tryConsumeSession(
  userId: string,
  by = 1,
  limit: number = GLOBAL_LIMIT,
  cooldownHours: number = SESSION_COOLDOWN_HRS,
): Promise<ConsumeSessionResult | null> {
  const { data, error } = await supabase
    .rpc('try_consume_session', {
      p_user_id: userId,
      p_by: by,
      p_limit: limit,
      p_cooldown_hours: cooldownHours,
    })
    .maybeSingle<TryConsumeSessionRow>()

  if (error) {
    // Migration 0105 not applied to this environment yet, so the function
    // isn't in PostgREST's schema cache. Degrade to the old always-succeeds
    // RPC rather than blocking every result — the client-side gate in
    // Games.tsx still applies, we just lose the server-side backstop until
    // the migration lands.
    const missing = error.code === 'PGRST202' || /does not exist|not find the function/i.test(error.message ?? '')
    if (missing) {
      const legacy = await incrementGlobalSession(userId, by, limit, cooldownHours)
      if (!legacy) return null
      return { allowed: true, count: legacy.count, resetAt: legacy.resetAt, limitReached: legacy.limitReached }
    }
    console.error('tryConsumeSession error:', error)
    return null
  }
  if (!data) return null

  return {
    allowed: data.allowed,
    count: data.count,
    resetAt: data.reset_at ? new Date(data.reset_at).getTime() : 0,
    limitReached: data.limit_reached,
  }
}

export async function saveGameSession(userId: string, input: SessionInput) {
  // Captured BEFORE the insert below, so it reflects the best score set by
  // every session prior to this one — needed to detect a genuine personal
  // best (see checkPersonalBestHighlight) rather than comparing a score
  // against itself.
  const { data: bestBeforeRow } = await supabase
    .from('game_sessions')
    .select('score')
    .eq('user_id', userId)
    .eq('game', input.game)
    .order('score', { ascending: false })
    .limit(1)
    .maybeSingle<{ score: number | null }>()
  const previousBest = Number(bestBeforeRow?.score) || 0

  const { error: sessionError } = await supabase
    .from('game_sessions')
    .insert({
      user_id:      userId,
      game:         input.game,
      score:        input.score,
      xp_earned:    input.xpEarned,
      duration_sec: input.durationSec,
      metadata:     input.metadata ?? {},
      result:       'completed',
    })

  if (sessionError) {
    console.error('gameSession insert error:', sessionError)
    return { error: sessionError }
  }

  // XP award
  const { error: xpError } = await supabase
    .rpc('award_xp', { p_user_id: userId, p_xp: input.xpEarned })

  if (xpError) console.error('award_xp error:', xpError)

  // Detect a level-up straight away so the celebration is already queued
  // by the time the player leaves the result screen. It won't render
  // while they're still in the game — Games.tsx holds a celebration
  // block for that. See src/features/levelup/levelUpBus.ts.
  if (!xpError) checkForLevelUp(userId)

  // ── Dynamic Duo ──────────────────────────────────────────────
  // Mints the shared bonus for BOTH partners and, if this play completed
  // the day for the pair, levels them up. Fired here rather than from the
  // game component so it can only ever run on a run that was actually
  // banked. The ResultScreen picks the answer up off duoBus.
  markDuoPlayPending()
  recordDuoPlay(input.xpEarned ?? 0)
    .then(publishDuoPlay)
    .catch(err => { console.error('recordDuoPlay error:', err); publishDuoPlay(null) })

  // ── Highlight checks (Duolingo-style) — fire-and-forget, never block ──
  // the session save on these. All three re-verify from the DB themselves.
  checkPersonalBestHighlight(userId, input.game, input.score, previousBest).catch(console.error)
  checkXpMilestoneHighlight(userId, input.game).catch(console.error)
  checkLeaderboardRankHighlight(userId, input.game).catch(console.error)

  // ── Plunder crown ────────────────────────────────────────────
  // Server-side no-op while the reigning champion is still inside their
  // 24h grace window, so calling it on every run is cheap and correct.
  if (input.game === 'plunder') refreshPlunderCrown()

  // ── Activity Goals (Games Zone) ──────────────────────────────
  // Advances the live game-goal cycle's games-played counter by 1 for this
  // completed session. No-ops server-side if no cycle is currently live.
  supabase.rpc('record_game_goal_progress', { p_increment: 1 }).then(({ error }) => {
    if (error) console.error('record_game_goal_progress error:', error)
  })

  // ── Weekly mission hooks ─────────────────────────────────────
  // xp_days: track days where XP was earned (1 per calendar day, de-duped by absolute mode)
  // We use the date string as a proxy — absolute=true means we only advance, never regress
  if ((input.xpEarned ?? 0) > 0) {
    updateMissionProgress(userId, 'xp_days', 1).catch(console.error)
  }

  // levels_gained: compare level before and after the XP award
  if ((input.xpEarned ?? 0) > 0) {
    const { data: freshProfile } = await supabase
      .from('profiles')
      .select('level')
      .eq('id', userId)
      .single()

    const { data: prevSession } = await supabase
      .from('game_sessions')
      .select('id')
      .eq('user_id', userId)
      .order('played_at', { ascending: false })
      .limit(2)

    // If this is not the first ever session, check for a level gained
    if (freshProfile && prevSession && prevSession.length >= 1) {
      // We detect level-up by comparing: if a notification of type level_up
      // was inserted for this user in the last 30s (inserted by the award_xp trigger),
      // increment levels_gained. We do this lightweight check to avoid a second RPC.
      const since = new Date(Date.now() - 30_000).toISOString()
      const { count: levelUpCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('type', 'level_up')
        .gte('created_at', since)

      if ((levelUpCount ?? 0) > 0) {
        updateMissionProgress(userId, 'levels_gained', 1).catch(console.error)
      }
    }
  }

  return { error: xpError ?? null }
}

export async function getPlayerRank(userId: string, game: GameKey): Promise<PlayerRankRow | null> {
  const { data, error } = await supabase
    .from('player_game_ranks')
    .select('*')
    .eq('user_id', userId)
    .eq('game', game)
    .maybeSingle()
  if (error) { console.error('getPlayerRank error:', error); return null }
  return data as PlayerRankRow | null
}

export async function savePlayerRank(
  userId: string, game: GameKey, newRank: GameRank,
  currentStreak: number, allTimeStreak: number,
): Promise<void> {
  const RANK_ORDER: GameRank[] = ['beginner', 'intermediate', 'advanced', 'master']
  const existing = await getPlayerRank(userId, game)
  const existingRankIdx = existing ? RANK_ORDER.indexOf(existing.rank) : 0
  const newRankIdx      = RANK_ORDER.indexOf(newRank)
  const finalRank: GameRank = newRankIdx >= existingRankIdx ? newRank : (existing?.rank ?? 'beginner')
  const finalAllTime = Math.max(allTimeStreak, existing?.all_time_streak ?? 0)

  const { error } = await supabase
    .from('player_game_ranks')
    .upsert({
      user_id: userId, game, rank: finalRank,
      current_streak: currentStreak, all_time_streak: finalAllTime,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'user_id,game' })

  if (error) console.error('savePlayerRank error:', error)
}

export async function getPlaysToday(userId: string, game: GameKey): Promise<number> {
  const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0)
  const { count, error } = await supabase
    .from('game_sessions')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('game', game)
    .gte('played_at', startOfDay.toISOString())
  if (error) return 0
  return count ?? 0
}

export async function getRecentSessions(userId: string, limit = 10) {
  const { data, error } = await supabase
    .from('game_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('played_at', { ascending: false })
    .limit(limit)
  return { data: data ?? [], error }
}

export async function getAllPlayerRanks(userId: string): Promise<Partial<Record<GameKey, PlayerRankRow>>> {
  const { data, error } = await supabase
    .from('player_game_ranks')
    .select('*')
    .eq('user_id', userId)
  if (error || !data) return {}
  const map: Partial<Record<GameKey, PlayerRankRow>> = {}
  for (const row of data as PlayerRankRow[]) { map[row.game] = row }
  return map
}

interface RefundSessionRow {
  count: number
  reset_at: string | null
}

/**
 * Gives sessions back for a run that was charged but never happened.
 *
 * Only Impostor needs this today: its lobby can expire without a match if
 * three real players don't turn up, and the sessions are taken up front at
 * Play. Never call it after a game has actually been played.
 *
 * Also clears the cooldown stamp when the refund drops the count back under
 * the limit — refunding the number while leaving the lockout in place would
 * be worse than not refunding at all.
 */
export async function refundSession(
  userId: string,
  by = 1,
  limit: number = GLOBAL_LIMIT,
): Promise<{ count: number; resetAt: number } | null> {
  const { data, error } = await supabase
    .rpc('refund_session', { p_user_id: userId, p_by: by, p_limit: limit })
    .maybeSingle<RefundSessionRow>()

  if (error) {
    console.error('refundSession error:', error)
    return null
  }
  if (!data) return null
  return { count: data.count, resetAt: data.reset_at ? new Date(data.reset_at).getTime() : 0 }
}
