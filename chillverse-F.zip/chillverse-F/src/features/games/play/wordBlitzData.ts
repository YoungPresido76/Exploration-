// src/pages/games/wordBlitzData.ts
// Curated word pool for Word Blitz. No obscure dictionary words, no proper
// nouns, no spaces/hyphens/apostrophes/numbers — every word here is meant
// to be instantly recognizable so a loss always feels like a reaction-speed
// failure, never a vocabulary quiz.

export type WordTier = 'easy' | 'medium' | 'hard'

export interface WordEntry {
  word: string   // always uppercase
  tier: WordTier
}

// ─── Easy (3–4 letters) — the onboarding tier, first words of every run ──
const EASY: string[] = [
  'SUN', 'FIRE', 'MOON', 'STAR', 'WAVE', 'BLUE', 'DARK', 'PLAY',
  'RAIN', 'SNOW', 'WIND', 'LEAF', 'TREE', 'ROCK', 'SAND', 'GOLD',
  'BLAZE', 'GLOW', 'SPIN', 'JUMP', 'RUSH', 'DASH', 'BOLT', 'ZOOM',
  'COOL', 'WARM', 'FAST', 'SLOW', 'LOUD', 'CALM', 'BOLD', 'PURE',
  'KING', 'RING', 'WING', 'SONG', 'BEAT', 'DRUM', 'BELL', 'HORN',
  'LAKE', 'RIVER', 'HILL', 'CAVE', 'PEAK', 'CLIFF', 'REEF', 'ISLE',
  'GAME', 'TEAM', 'RACE', 'GOAL', 'WIN', 'LOSS', 'DRAW', 'RUN',
  'RED', 'PINK', 'GRAY', 'TEAL', 'MINT', 'JADE', 'RUBY', 'ONYX',
  'CAT', 'DOG', 'FOX', 'WOLF', 'BEAR', 'LION', 'HAWK', 'CROW',
  'CAKE', 'MILK', 'HONEY', 'BREAD', 'SALT', 'SPICE', 'LIME', 'PLUM',
]

// ─── Medium (5–7 letters) ─────────────────────────────────────────────
const MEDIUM: string[] = [
  'COSMIC', 'GALAXY', 'PLANET', 'PIXELS', 'NEBULA', 'THUNDER', 'SHADOW', 'MYSTIC',
  'ROCKET', 'ORBIT', 'COMET', 'METEOR', 'ECLIPSE', 'STARDUST', 'SATURN', 'VENUS',
  'FOREST', 'JUNGLE', 'DESERT', 'GLACIER', 'VOLCANO', 'TORNADO', 'BLIZZARD', 'MONSOON',
  'DRAGON', 'PHOENIX', 'GRIFFIN', 'WIZARD', 'KNIGHT', 'CASTLE', 'DUNGEON', 'ARMOR',
  'SPIRIT', 'ENERGY', 'CRYSTAL', 'AMBER', 'QUARTZ', 'EMBER', 'FLAME', 'FROST',
  'RHYTHM', 'MELODY', 'ECHO', 'HARMONY', 'CHORUS', 'GUITAR', 'PIANO', 'VIOLIN',
  'PUZZLE', 'RIDDLE', 'CIPHER', 'SECRET', 'LEGEND', 'MYTH', 'ORACLE', 'PORTAL',
  'ROCKET', 'ENGINE', 'CIRCUIT', 'REACTOR', 'SIGNAL', 'BEACON', 'RADAR', 'LASER',
  'SPRINT', 'VELOCITY', 'MOTION', 'IMPACT', 'TRIGGER', 'SURGE', 'PULSE', 'BURST',
  'CANYON', 'HORIZON', 'VALLEY', 'SUMMIT', 'TUNDRA', 'PRAIRIE', 'LAGOON', 'HARBOR',
]

// ─── Hard (7–8 letters) — capped at 8 per the V1 word-length rule ─────
const HARD: string[] = [
  'QUANTUM', 'ECLIPSE', 'CRYSTAL', 'GRAVITY', 'UNIVERSE', 'PARADOX', 'CATALYST', 'SPECTRUM',
  'ASTEROID', 'MAGNETIC', 'ELECTRIC', 'ATOMIC', 'PHOTON', 'FORTRESS', 'CITADEL', 'KINGDOM',
  'EMPEROR', 'WARRIOR', 'CHAMPION', 'CYCLONE', 'TSUNAMI', 'WILDFIRE', 'DROUGHT', 'MIRAGE',
  'OASIS', 'CADENCE', 'SYMPHONY', 'TEMPO', 'CHORDS', 'MYSTERY', 'ENIGMA', 'PHANTOM',
  'SPECTER', 'ILLUSION', 'ANOMALY', 'VELOCITY', 'MOMENTUM', 'IMPULSE', 'FRICTION', 'TENSION',
  'PRESSURE', 'DENSITY',
]

export const WORD_POOL: WordEntry[] = [
  ...EASY.map(word => ({ word, tier: 'easy' as const })),
  ...MEDIUM.map(word => ({ word, tier: 'medium' as const })),
  ...HARD.map(word => ({ word, tier: 'hard' as const })),
]

// ─── Fixed onboarding sequence — first three words of every run ──────
// No tutorial needed: STAR → MOON → FIRE teaches "tap letters in order"
// through pure repetition of easy, familiar words.
export const ONBOARDING_WORDS = ['STAR', 'MOON', 'FIRE']

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

/**
 * Pick a random word within a target letter-length band, preferring the
 * tier that best matches the current difficulty tier. Falls back across
 * tiers if the length band is too narrow for the requested tier's pool.
 */
export function pickWord(minLen: number, maxLen: number, preferTier: WordTier, exclude?: string): string {
  const tierOrder: WordTier[] = preferTier === 'hard'
    ? ['hard', 'medium', 'easy']
    : preferTier === 'medium'
      ? ['medium', 'hard', 'easy']
      : ['easy', 'medium', 'hard']

  for (const tier of tierOrder) {
    const candidates = WORD_POOL.filter(e =>
      e.tier === tier && e.word.length >= minLen && e.word.length <= maxLen && e.word !== exclude
    )
    if (candidates.length > 0) return pick(candidates).word
  }

  // Absolute fallback — any word in the length band, any tier.
  const anyMatch = WORD_POOL.filter(e => e.word.length >= minLen && e.word.length <= maxLen && e.word !== exclude)
  if (anyMatch.length > 0) return pick(anyMatch).word

  return pick(WORD_POOL).word
}
