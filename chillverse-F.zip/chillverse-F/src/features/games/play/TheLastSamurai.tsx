// src/features/games/play/TheLastSamurai.tsx
// ─── The Last Samurai ─────────────────────────────────────────
// Remember. Track. Survive.
//
// Loop: a target emoji is shown → the grid flashes face-up → cards flip
// down → they physically shuffle → the player taps to find the target.
// One bomb ends the run instantly. Deliberately small: no lives, no
// currencies, no progression beyond score/combo/rank streak.
//
// Every phase transition is driven by a `useEffect` keyed on the phase
// rather than by a chain of setTimeouts held in refs. That matters:
// React StrictMode (which main.tsx turns on) mounts, unmounts and
// remounts on the first render, and a ref-held timer chain gets wiped by
// the unmount cleanup and never restarts — the round freezes on the
// reveal forever. Effects simply re-run, so the chain heals itself.
import { useState, useRef, useEffect } from 'react'
import { Swords } from 'lucide-react'
import type { GameRank, GameEndPayload } from './types'
import { getRankConfig } from './types'
import { useGamePresence } from '../useGamePresence'
import { useAuth } from '../../auth/useAuth'
import { supabase } from '../../../shared/lib/supabase'
import { PreGameModal, GameHUD, StatChip, ResultScreen, QuitModal, useRankStreak } from './GameShell'
import { playPraiseSound, playBomb, startSamuraiTheme, stopSamuraiTheme } from '../sfx'

const GAME_ID   = 'the-last-samurai' as const
const GAME_NAME = 'The Last Samurai'
const ACCENT    = '#e63946'
const GOLD      = '#f5c542'

// ─── Emoji pool ───────────────────────────────────────────────
// Duplicates are allowed among the decoys. Each target emoji is seeded
// exactly once, so a target card is never ambiguous with a decoy.
const EMOJI_POOL = ['🔥', '🌊', '🍃', '⚔️', '🥷', '🌑', '👁️', '🍂', '⛩️', '🏯', '🐉', '🌸', '🎋', '🗡️', '🎌', '🪭']
const BOMB = '💣'

interface Card {
  id: number
  emoji: string
  isBomb: boolean
  isTarget: boolean
  slot: number      // which grid position it currently occupies
  revealed: boolean // face-up during the reveal phase, or tapped by the player
}

// ─── Difficulty curve ─────────────────────────────────────────
// The ramp lives in card count and shuffle speed — never in making the
// swaps unreadable, so the target stays trackable at every stage.
function cardsForRound(r: number): number {
  if (r <= 2) return 6
  if (r <= 4) return 9
  if (r <= 7) return 12
  if (r <= 11) return 16
  return 20
}
function bombsForRound(r: number, cardCount: number): number {
  const base = r <= 1 ? 0 : r <= 4 ? 1 : r <= 9 ? 2 : r <= 15 ? 3 : 4
  // Never let bombs crowd the board past a quarter of the cards.
  return Math.min(base, Math.max(0, Math.floor(cardCount / 4)))
}
function revealMsForRound(r: number): number {
  return Math.max(700, 2000 - (r - 1) * 90)
}
function swapsForRound(r: number): number {
  return Math.min(11, 3 + Math.floor(r / 2))
}
function swapMsForRound(r: number): number {
  return Math.max(170, 420 - (r - 1) * 18)
}
function colsFor(count: number): number {
  return count <= 9 ? 3 : 4
}

// ─── Intermediate rules ───────────────────────────────────────
// From intermediate up the game changes shape rather than just speeding
// up: TWO targets are shown instead of one (tapping either banks the
// round), and a wrong tap ends the run the same way a bomb does. Two
// emojis to hold through the shuffle plus no free wrong guesses is where
// the difficulty actually comes from.
const HARD_RANKS: GameRank[] = ['intermediate', 'advanced', 'master']
function isHardRank(rank: GameRank): boolean { return HARD_RANKS.includes(rank) }
function targetsForRank(rank: GameRank): number { return isHardRank(rank) ? 2 : 1 }

// ─── Rank offset ──────────────────────────────────────────────
// Higher ranks start further along the same curve instead of getting a
// separate one, so the tuning above only has to hold in one place.
const RANK_OFFSET: Record<GameRank, number> = {
  beginner: 0, intermediate: 2, advanced: 4, master: 6,
}

// ─── XP ───────────────────────────────────────────────────────
// Deliberately more generous than the older games — this one is meant to
// pull players in. Still capped so a long run can't run away with the
// XP ladder.
const XP_CAP = 250
function xpForRounds(roundsCleared: number): number {
  if (roundsCleared <= 0) return 0
  return Math.min(XP_CAP, roundsCleared * 12 + Math.floor(roundsCleared / 5) * 15)
}

const PRAISE = ['Found it!', 'Sharp eyes!', 'Tracked it!', 'Clean read!', 'Never lost it!']

// The intermediate rules change is big enough that dropping a player into
// it unannounced would read as the game breaking. Shown once ever, then
// remembered — the pre-game rules list carries it from then on.
const HARD_BRIEF_KEY = 'chillverse:tls-hard-brief-seen'
function hasSeenHardBrief(): boolean {
  if (typeof window === 'undefined') return true
  try { return window.localStorage.getItem(HARD_BRIEF_KEY) === '1' } catch { return true }
}
function markHardBriefSeen(): void {
  if (typeof window === 'undefined') return
  try { window.localStorage.setItem(HARD_BRIEF_KEY, '1') } catch { /* private mode — show it again, no harm */ }
}

function shuffleArr<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

function buildRound(diffRound: number, targetCount: number): { cards: Card[]; targets: string[] } {
  const count   = cardsForRound(diffRound)
  const bombs   = bombsForRound(diffRound, count)
  const pool    = shuffleArr(EMOJI_POOL)
  const targets = pool.slice(0, targetCount)
  const decoys  = EMOJI_POOL.filter(e => !targets.includes(e))

  const faces: { emoji: string; isBomb: boolean; isTarget: boolean }[] =
    targets.map(t => ({ emoji: t, isBomb: false, isTarget: true }))
  for (let i = 0; i < bombs; i++) faces.push({ emoji: BOMB, isBomb: true, isTarget: false })
  while (faces.length < count) {
    faces.push({ emoji: decoys[Math.floor(Math.random() * decoys.length)], isBomb: false, isTarget: false })
  }

  const slots = shuffleArr(faces.map((_, i) => i))
  return { cards: faces.map((f, i) => ({ ...f, id: i, slot: slots[i], revealed: true })), targets }
}

/** One positional swap between two cards — a real exchange of slots, so
 *  the player can follow a card across the board instead of watching the
 *  whole grid teleport.
 *
 *  `anchor` forces one side of the swap to be that card. Picking both
 *  sides at random meant a target could sit still through an entire
 *  shuffle while only decoys moved — with 6 cards and 4 swaps that
 *  happened often, and the round read as broken rather than easy. */
function swapTwo(prev: Card[], anchor?: number): Card[] {
  if (prev.length < 2) return prev
  const anchorIdx = anchor === undefined ? -1 : prev.findIndex(c => c.id === anchor)
  const a = anchorIdx >= 0 ? anchorIdx : Math.floor(Math.random() * prev.length)
  let b = Math.floor(Math.random() * prev.length)
  if (b === a) b = (a + 1 + Math.floor(Math.random() * (prev.length - 1))) % prev.length
  const next = prev.map(c => ({ ...c }))
  const tmp = next[a].slot
  next[a].slot = next[b].slot
  next[b].slot = tmp
  return next
}

// ─── Card ─────────────────────────────────────────────────────
function CardTile({
  card, cell, gap, cols, faceUp, onTap, tappable, swapMs, bombHit,
}: {
  card: Card; cell: number; gap: number; cols: number
  faceUp: boolean; onTap: () => void; tappable: boolean
  swapMs: number; bombHit: boolean
}) {
  const col = card.slot % cols
  const row = Math.floor(card.slot / cols)
  const targetGlow = faceUp && card.isTarget
  const bombFace   = faceUp && card.isBomb

  return (
    <button
      type="button"
      onClick={tappable ? onTap : undefined}
      aria-label={faceUp ? card.emoji : 'Hidden card'}
      style={{
        position: 'absolute',
        width: cell, height: cell, left: 0, top: 0,
        transform: `translate(${col * (cell + gap)}px, ${row * (cell + gap)}px)`,
        transition: `transform ${swapMs}ms cubic-bezier(0.4, 0, 0.2, 1)`,
        padding: 0, border: 'none', background: 'transparent',
        cursor: tappable ? 'pointer' : 'default',
        perspective: 600,
        WebkitTapHighlightColor: 'transparent',
      }}
    >
      <div style={{
        position: 'relative', width: '100%', height: '100%',
        transformStyle: 'preserve-3d',
        transform: faceUp ? 'rotateY(180deg)' : 'rotateY(0deg)',
        transition: 'transform 0.32s ease',
      }}>
        {/* Back */}
        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden', borderRadius: 14,
          background: 'linear-gradient(160deg, rgba(28,32,46,0.95), rgba(12,14,22,0.95))',
          border: '1px solid rgba(255,255,255,0.09)',
          boxShadow: '0 4px 14px rgba(0,0,0,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: Math.max(16, cell * 0.34), fontWeight: 800,
          color: 'rgba(255,255,255,0.22)',
        }}>?</div>

        {/* Face */}
        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden',
          transform: 'rotateY(180deg)', borderRadius: 14,
          background: bombFace
            ? 'linear-gradient(160deg, rgba(120,20,26,0.95), rgba(50,8,12,0.95))'
            : 'linear-gradient(160deg, rgba(30,34,48,0.95), rgba(14,16,25,0.95))',
          border: targetGlow ? `1.5px solid ${GOLD}`
            : bombFace ? `1.5px solid ${ACCENT}` : '1px solid rgba(255,255,255,0.09)',
          boxShadow: targetGlow ? `0 0 18px ${GOLD}88, inset 0 0 14px ${GOLD}22`
            : bombFace ? `0 0 22px ${ACCENT}bb` : '0 4px 14px rgba(0,0,0,0.45)',
          animation: bombHit ? 'tls-bomb-pulse 0.4s ease-in-out 2' : undefined,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: Math.max(18, cell * 0.44), lineHeight: 1,
        }}>{card.emoji}</div>
      </div>
    </button>
  )
}

interface Props {
  rank: GameRank
  streak?: number
  onEnd: (payload: GameEndPayload) => void
  onBack: () => void
  sessionsLeft?: number
  sessionCost?: number
  skipIntro?: boolean
}

// 'cleared' and 'bomb' are the short beats after a tap resolves, before
// the next round starts / the result screen shows.
type Phase = 'info' | 'target' | 'reveal' | 'shuffle' | 'pick' | 'cleared' | 'bomb' | 'paused' | 'result'

export default function TheLastSamurai({
  rank: initialRank, streak: initialStreak = 0, onEnd, onBack, sessionsLeft = 99, sessionCost = 2, skipIntro,
}: Props) {
  const [phase, setPhase] = useState<Phase>('info')
  useGamePresence(GAME_ID)
  // Theme loops for the whole run and cuts out the moment it ends, so the
  // bomb hit and the game-over sting land in silence instead of over music.
  // Replaying restarts it, since `start()` moves the phase back off result.
  useEffect(() => {
    if (phase === 'result' || phase === 'bomb') stopSamuraiTheme()
    else startSamuraiTheme()
  }, [phase])
  useEffect(() => stopSamuraiTheme, [])
  const { rankState, onCorrect, onWrong } = useRankStreak(GAME_ID, initialRank, initialStreak)
  const { session } = useAuth()

  const [cards, setCards]   = useState<Card[]>([])
  const [targets, setTargets] = useState<string[]>(['🔥'])
  const [round, setRound]   = useState(1)
  const [score, setScore]   = useState(0)
  const [combo, setCombo]   = useState(1)
  const [best, setBest]     = useState(0)
  const [banner, setBanner] = useState('')
  const [praise, setPraise] = useState<{ text: string; key: number } | null>(null)
  const [floatScore, setFloatScore] = useState<{ text: string; key: number } | null>(null)
  const [bombHitId, setBombHitId]   = useState<number | null>(null)
  const [promoted, setPromoted]     = useState<GameRank | null>(null)
  const [result, setResult]         = useState<GameEndPayload | null>(null)
  const [swapMs, setSwapMs]         = useState(400)
  const [hardBrief, setHardBrief]   = useState(false)
  const [boardW, setBoardW]         = useState(320)

  const scoreRef     = useRef(0)
  const comboRef     = useRef(1)
  const bestComboRef = useRef(1)
  const clearedRef   = useRef(0)
  const pickStartRef = useRef(Date.now())
  const startRef     = useRef(Date.now())
  const endedRef     = useRef(false)
  const boardRef     = useRef<HTMLDivElement | null>(null)

  const diffRound = round + RANK_OFFSET[rankState.rank]

  // ── Board sizing — cards are absolutely positioned so they can slide,
  //    which means the cell size has to be a real pixel value, not a % ──
  useEffect(() => {
    const el = boardRef.current
    if (!el) return
    const measure = () => setBoardW(el.clientWidth)
    measure()
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', measure)
      return () => window.removeEventListener('resize', measure)
    }
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [phase])

  // ── Personal best, for the HUD and the game-over card ──
  useEffect(() => {
    const uid = session?.user?.id
    if (!uid) return
    supabase
      .from('game_sessions')
      .select('score')
      .eq('user_id', uid)
      .eq('game', 'the_last_samurai')
      .order('score', { ascending: false })
      .limit(1)
      .maybeSingle<{ score: number }>()
      .then(({ data }) => { if (data?.score) setBest(data.score) }, () => {})
  }, [session?.user?.id])

  // ── Phase chain ─────────────────────────────────────────────
  // target → reveal → shuffle → pick, each step a self-cleaning effect.

  useEffect(() => {
    if (phase !== 'target') return
    setBanner('Memorize the target')
    const t = setTimeout(() => setPhase('reveal'), 650)
    return () => clearTimeout(t)
  }, [phase, round])

  useEffect(() => {
    if (phase !== 'reveal') return
    setBanner('Watch carefully…')
    const t = setTimeout(() => {
      setCards(prev => prev.map(c => ({ ...c, revealed: false })))
      setPhase('shuffle')
    }, revealMsForRound(diffRound))
    return () => clearTimeout(t)
  }, [phase, round, diffRound])

  useEffect(() => {
    if (phase !== 'shuffle') return
    setBanner('Track it!')
    const ms = swapMsForRound(diffRound)
    const total = swapsForRound(diffRound)
    setSwapMs(ms)

    // Where each card sits before the shuffle starts, so `finish` can tell
    // whether a target actually ended up somewhere new.
    const startSlots = new Map(cards.map(c => [c.id, c.slot]))

    let cancelled = false
    let done = 0
    let handle: ReturnType<typeof setTimeout>

    // Rotate the targets through the swaps so each one is guaranteed to
    // move, and repeatedly — a target that never leaves its slot is the
    // single worst thing this game can do.
    const targetIds = cards.filter(c => c.isTarget).map(c => c.id)

    function step() {
      if (cancelled) return
      // Every other swap is anchored to a target, the rest are free, so
      // the board still churns instead of just orbiting the targets.
      const anchor = done % 2 === 0 && targetIds.length > 0
        ? targetIds[Math.floor(done / 2) % targetIds.length]
        : undefined
      setCards(prev => swapTwo(prev, anchor))
      done++
      handle = setTimeout(done < total ? step : finish, ms)
    }
    function finish() {
      if (cancelled) return
      // Belt and braces: if a target somehow landed back where it started,
      // move it once more before the player is asked to find it.
      setCards(prev => {
        let next = prev
        for (const id of targetIds) {
          const card = next.find(c => c.id === id)
          const origin = startSlots.get(id)
          if (card && origin !== undefined && card.slot === origin) next = swapTwo(next, id)
        }
        return next
      })
      pickStartRef.current = Date.now()
      setPhase('pick')
    }
    // Small beat after the flip-down so the board settles before it moves.
    handle = setTimeout(step, 340)
    return () => { cancelled = true; clearTimeout(handle) }
    // `cards` is read once, at the top of the shuffle, to snapshot the
    // target ids and their starting slots. It is deliberately NOT a
    // dependency — it changes on every swap, and listing it would restart
    // the shuffle endlessly.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, round, diffRound])

  useEffect(() => {
    if (phase !== 'pick') return
    setBanner('Find the target')
  }, [phase, round])

  // Round cleared → short celebration beat → next round.
  useEffect(() => {
    if (phase !== 'cleared') return
    const t = setTimeout(() => {
      const next = round + 1
      setRound(next)
      const built = buildRound(next + RANK_OFFSET[rankState.rank], targetsForRank(rankState.rank))
      setCards(built.cards)
      setTargets(built.targets)
      setPraise(null)
      setFloatScore(null)
      setPhase('target')
    }, 900)
    return () => clearTimeout(t)
  }, [phase, round, rankState.rank])

  // Bomb → let the red flash land → result screen.
  useEffect(() => {
    if (phase !== 'bomb') return
    const t = setTimeout(() => finishRun(), 950)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase])

  function newRound(r: number) {
    const built = buildRound(r + RANK_OFFSET[rankState.rank], targetsForRank(rankState.rank))
    setCards(built.cards)
    setTargets(built.targets)
    setPraise(null)
    setFloatScore(null)
    setBombHitId(null)
    setPhase('target')
  }

  // Entering intermediate for the first time gets the briefing before the
  // first round, not after a run has already ended on a rule nobody told
  // them about.
  function start() {
    if (isHardRank(rankState.rank) && !hasSeenHardBrief()) {
      setHardBrief(true)
      return
    }
    beginRun()
  }

  function beginRun() {
    endedRef.current = false
    scoreRef.current = 0
    comboRef.current = 1
    bestComboRef.current = 1
    clearedRef.current = 0
    startRef.current = Date.now()
    setRound(1)
    setScore(0)
    setCombo(1)
    setPromoted(null)
    setResult(null)
    newRound(1)
  }

  // Quitting pauses the run outright rather than letting the reveal and
  // shuffle keep running behind the modal. Cancelling replays the current
  // round from the top, so nobody comes back to a board they never saw.
  function openQuit() {
    if (phase === 'result' || phase === 'bomb') return
    setPhase('paused')
  }
  function resumeFromQuit() {
    newRound(round)
  }

  function onCardTap(id: number) {
    if (phase !== 'pick') return
    const card = cards.find(c => c.id === id)
    if (!card || card.revealed) return

    // ── Bomb: instant loss ──
    if (card.isBomb) {
      playBomb()
      setBombHitId(id)
      setCards(prev => prev.map(c => (c.id === id ? { ...c, revealed: true } : c)))
      setBanner('')
      setPhase('bomb')
      return
    }

    // ── Target: bank the round ──
    if (card.isTarget) {
      const elapsed = (Date.now() - pickStartRef.current) / 1000
      const speedBonus = Math.max(0, Math.round(50 - elapsed * 12))
      const gained = (100 + speedBonus) * comboRef.current

      scoreRef.current += gained
      clearedRef.current += 1
      setScore(scoreRef.current)
      setCards(prev => prev.map(c => (c.id === id ? { ...c, revealed: true } : c)))

      const text = PRAISE[Math.floor(Math.random() * PRAISE.length)]
      playPraiseSound(text)
      setPraise({ text, key: Date.now() })
      setFloatScore({ text: `+${gained.toLocaleString()}`, key: Date.now() })
      setBanner('')

      comboRef.current += 1
      bestComboRef.current = Math.max(bestComboRef.current, comboRef.current - 1)
      setCombo(comboRef.current)
      setPhase('cleared')
      return
    }

    // ── Decoy ──
    // Beginner: it stays face-up, the combo resets, the search continues.
    // Intermediate and up: a wrong tap ends the run, same as a bomb.
    if (isHardRank(rankState.rank)) {
      playBomb()
      setBombHitId(id)
      setCards(prev => prev.map(c => (c.id === id ? { ...c, revealed: true } : c)))
      setBanner('')
      setPhase('bomb')
      return
    }

    comboRef.current = 1
    setCombo(1)
    setCards(prev => prev.map(c => (c.id === id ? { ...c, revealed: true } : c)))
    setBanner('Keep looking…')
  }

  function finishRun() {
    if (endedRef.current) return
    endedRef.current = true

    const dur = Math.floor((Date.now() - startRef.current) / 1000)
    const cleared = clearedRef.current
    const finalScore = scoreRef.current
    const xp = xpForRounds(cleared)
    const newBest = Math.max(best, finalScore)
    if (finalScore > best) setBest(finalScore)

    const payload: GameEndPayload = {
      gameId: GAME_ID,
      gameName: GAME_NAME,
      rank: rankState.rank,
      score: finalScore,
      xpEarned: xp,
      durationSec: dur,
      streak: rankState.bestStreak,
      correct: cleared,
      total: Math.max(cleared, round),
      detail: {
        'Rounds Survived': cleared,
        'Best Combo': `×${bestComboRef.current}`,
        'Personal Best': newBest.toLocaleString(),
      },
    }

    if (cleared >= 3) {
      const { promoted: promo } = onCorrect(getRankConfig(rankState.rank).streakRequired)
      if (promo) setPromoted(promo)
    } else {
      onWrong()
    }

    setResult(payload)
    setPhase('result')
    onEnd(payload)
  }

  // ── Render ──
  const rankCfg = getRankConfig(rankState.rank)
  const rules = [
    { icon: '🎯', text: 'A target emoji is shown — memorize it' },
    { icon: '👁', text: 'Every card flashes face-up, then flips back down' },
    { icon: '🔀', text: 'The cards shuffle across the board — follow the target' },
    { icon: '🖐', text: 'Tap to find it. Wrong cards stay open and break your combo' },
    { icon: '💣', text: 'Tap a bomb and the run ends instantly' },
    { icon: '🔥', text: 'From Intermediate: TWO targets to track, and one wrong tap ends the run' },
  ]

  if (hardBrief) return (
    <HardModeBrief onStart={() => { markHardBriefSeen(); setHardBrief(false); beginRun() }} onBack={onBack} />
  )

  if (phase === 'info') return (
    <PreGameModal
      gameName={GAME_NAME}
      tagline="Remember. Track. Survive."
      accent={ACCENT}
      icon={<Swords size={40} />}
      rules={rules}
      rankState={rankState}
      streakRequired={rankCfg.streakRequired}
      onStart={start}
      onClose={onBack}
      autoStart={skipIntro}
    />
  )

  if (phase === 'result' && result) return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <ResultScreen
        payload={result}
        accent={ACCENT}
        onReplay={() => { setResult(null); start() }}
        onBack={onBack}
        promoted={promoted}
        sessionsLeft={sessionsLeft}
        sessionCost={sessionCost}
      />
    </div>
  )

  const cols = colsFor(cards.length || 6)
  const rows = Math.ceil((cards.length || 6) / cols)
  const gap  = cards.length > 12 ? 8 : 10
  const cell = Math.max(44, Math.floor((boardW - gap * (cols - 1)) / cols))
  const faceUpAll = phase === 'target' || phase === 'reveal'

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', flex: 1, position: 'relative', overflow: 'hidden',
      background: 'linear-gradient(180deg, #090b12 0%, #0d1020 55%, #120a0e 100%)',
    }}>
      <style>{`
        @keyframes tls-bomb-pulse { 0%,100% { box-shadow: 0 0 22px ${ACCENT}bb } 50% { box-shadow: 0 0 46px ${ACCENT} } }
        @keyframes tls-fall { 0% { transform: translateY(-10vh) rotate(0deg); opacity: 0 } 10% { opacity: .5 } 100% { transform: translateY(105vh) rotate(320deg); opacity: 0 } }
        @keyframes tls-rise { 0% { transform: translate(-50%, 0) scale(.9); opacity: 0 } 20% { opacity: 1 } 100% { transform: translate(-50%, -46px) scale(1.1); opacity: 0 } }
        @keyframes tls-pop { 0% { transform: scale(.7); opacity: 0 } 30% { transform: scale(1.05); opacity: 1 } 100% { transform: scale(1); opacity: 1 } }
      `}</style>

      {/* Blood moon */}
      <div style={{
        position: 'absolute', top: '6%', left: '50%', transform: 'translateX(-50%)',
        width: 200, height: 200, borderRadius: '50%',
        background: `radial-gradient(circle, ${ACCENT}55, transparent 68%)`,
        filter: 'blur(18px)', pointerEvents: 'none',
      }} />

      {/* Temple / torii silhouette */}
      <svg viewBox="0 0 400 130" preserveAspectRatio="none" aria-hidden style={{
        position: 'absolute', bottom: 0, left: 0, width: '100%', height: 150,
        opacity: 0.75, pointerEvents: 'none',
      }}>
        <path d="M0 130 L0 96 L40 96 L40 130 Z M360 130 L360 96 L400 96 L400 130 Z" fill="#05070c" />
        <path d="M60 130 V60 h12 v70 z M328 130 V60 h12 v70 z M44 52 h312 v9 H44 z M52 40 h296 v8 H52 z M56 72 h288 v7 H56 z" fill="#05070c" />
        <path d="M120 130 V104 h160 v26 z M132 100 l68 -26 l68 26 z" fill="#070a11" />
      </svg>

      {/* Drifting leaves */}
      {[0, 1, 2, 3, 4].map(i => (
        <span key={i} aria-hidden style={{
          position: 'absolute', top: 0, left: `${8 + i * 21}%`, fontSize: 13,
          animation: `tls-fall ${9 + i * 2.4}s linear ${i * 2.1}s infinite`,
          pointerEvents: 'none', opacity: 0.45,
        }}>🍂</span>
      ))}

      <GameHUD
        gameName={GAME_NAME}
        accent={ACCENT}
        icon={<Swords size={14} />}
        streak={rankState.currentStreak}
        onQuit={openQuit}
        extraRight={
          <div style={{ display: 'flex', gap: 6 }}>
            <StatChip label="Round" value={round} accent={ACCENT} />
            <StatChip label="Score" value={score.toLocaleString()} accent={GOLD} />
          </div>
        }
      />

      {/* Target strip */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12,
        padding: '14px 16px 8px', position: 'relative', zIndex: 1,
      }}>
        <span style={{
          fontSize: 11, fontWeight: 800, letterSpacing: 1.6,
          color: 'rgba(255,255,255,0.55)', textTransform: 'uppercase',
        }}>{targets.length > 1 ? 'Find either' : 'Find'}</span>
        {targets.map(t => (
          <span key={t} style={{
            fontSize: 34, lineHeight: 1, filter: `drop-shadow(0 0 12px ${GOLD}aa)`,
            animation: 'tls-pop 0.35s ease',
          }}>{t}</span>
        ))}
        <span style={{
          fontSize: 11, fontWeight: 800, letterSpacing: 1.2,
          color: combo > 1 ? GOLD : 'rgba(255,255,255,0.35)',
        }}>COMBO ×{combo}</span>
      </div>

      {/* Banner / praise */}
      <div style={{
        height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', zIndex: 1,
      }}>
        {praise ? (
          <span key={praise.key} style={{ fontSize: 13, fontWeight: 800, color: GOLD, animation: 'tls-pop 0.3s ease' }}>
            {praise.text}
          </span>
        ) : (
          <span style={{ fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.42)' }}>{banner}</span>
        )}
      </div>

      {/* Board */}
      <div style={{
        flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '14px 16px 28px', position: 'relative', zIndex: 1,
      }}>
        <div style={{ width: '100%', maxWidth: 380, position: 'relative' }}>
          <div ref={boardRef} style={{ position: 'relative', width: '100%', height: rows * cell + (rows - 1) * gap }}>
            {cards.map(c => (
              <CardTile
                key={c.id}
                card={c}
                cell={cell}
                gap={gap}
                cols={cols}
                faceUp={faceUpAll || c.revealed}
                tappable={phase === 'pick' && !c.revealed}
                onTap={() => onCardTap(c.id)}
                swapMs={swapMs}
                bombHit={bombHitId === c.id}
              />
            ))}
          </div>

          {floatScore && (
            <span key={floatScore.key} style={{
              position: 'absolute', top: '38%', left: '50%', transform: 'translate(-50%, 0)',
              fontSize: 26, fontWeight: 900, color: GOLD, pointerEvents: 'none',
              textShadow: `0 0 18px ${GOLD}88`, animation: 'tls-rise 0.9s ease-out forwards',
            }}>{floatScore.text}</span>
          )}
        </div>
      </div>

      {best > 0 && (
        <div style={{
          textAlign: 'center', paddingBottom: 14, position: 'relative', zIndex: 1,
          fontSize: 10, fontWeight: 700, letterSpacing: 1.2,
          color: 'rgba(255,255,255,0.32)', textTransform: 'uppercase',
        }}>
          Best {best.toLocaleString()}
        </div>
      )}

      {phase === 'paused' && <QuitModal onConfirm={onBack} onCancel={resumeFromQuit} />}
    </div>
  )
}

// ─── Intermediate briefing ────────────────────────────────────
// A full-screen notice rather than a toast: the two rules it carries
// change how the game is played, so it has to be read, not glanced at.
function HardModeBrief({ onStart, onBack }: { onStart: () => void; onBack: () => void }) {
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 18, padding: '32px 24px', background: 'var(--bg)', textAlign: 'center',
    }}>
      <div style={{
        width: 72, height: 72, borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: `linear-gradient(160deg, ${ACCENT}44, rgba(12,14,22,0.9))`,
        border: `1.5px solid ${ACCENT}`, boxShadow: `0 0 28px ${ACCENT}66`, fontSize: 34,
      }}>⚔️</div>

      <div>
        <p style={{
          fontSize: 11, fontWeight: 800, letterSpacing: 1.8, textTransform: 'uppercase',
          color: ACCENT, marginBottom: 6,
        }}>Intermediate unlocked</p>
        <h2 style={{ fontSize: 22, fontWeight: 900, color: 'var(--text)' }}>The rules just changed</h2>
      </div>

      <div style={{
        display: 'flex', flexDirection: 'column', gap: 14, width: '100%', maxWidth: 340,
        padding: 18, borderRadius: 16,
        background: 'var(--surface2)', border: '1px solid var(--border)',
      }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', textAlign: 'left' }}>
          <span style={{ fontSize: 22, lineHeight: 1.1 }}>💣</span>
          <p style={{ fontSize: 13, color: 'var(--text-dim)', lineHeight: 1.45 }}>
            Do not tap the bomb. It ends your run on the spot — that hasn’t changed.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', textAlign: 'left' }}>
          <span style={{ fontSize: 22, lineHeight: 1.1 }}>❌</span>
          <p style={{ fontSize: 13, color: 'var(--text-dim)', lineHeight: 1.45 }}>
            <strong style={{ color: 'var(--text)' }}>One wrong tap now ends it too.</strong> No more
            free guesses — open the wrong card and the run is over.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', textAlign: 'left' }}>
          <span style={{ fontSize: 22, lineHeight: 1.1 }}>🎯</span>
          <p style={{ fontSize: 13, color: 'var(--text-dim)', lineHeight: 1.45 }}>
            <strong style={{ color: 'var(--text)' }}>Two targets now, not one.</strong> Track both
            through the shuffle — tap either one to clear the round, your choice.
          </p>
        </div>
      </div>

      <button type="button" onClick={onStart} style={{
        width: '100%', maxWidth: 340, padding: '14px 20px', borderRadius: 14, border: 'none',
        background: ACCENT, color: '#fff', fontSize: 15, fontWeight: 800, cursor: 'pointer',
        boxShadow: `0 8px 24px ${ACCENT}55`,
      }}>I’m ready</button>

      <button type="button" onClick={onBack} style={{
        background: 'none', border: 'none', color: 'var(--text-muted)',
        fontSize: 12, fontWeight: 700, cursor: 'pointer',
      }}>Back</button>
    </div>
  )
}
