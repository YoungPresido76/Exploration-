// src/features/games/play/Elementa.tsx
// "Elementa" — an 8x8 elemental block puzzle.
//
// You're handed three element blocks at a time (shapes made of 1–9 cells,
// each carrying one of six elements: ice, fire, water, leaf, storm, sun).
// Drag a block onto the board to place it — blocks never rotate and never
// fall, they sit exactly where you drop them. Fill a whole row or column
// and it clears. Clear a row/column where every single cell is the SAME
// element and it counts as an Elemental Clear — extra score, extra XP.
//
// Clearing more than one line in the same drop multiplies the payout, so
// setting up a double or triple clear is worth far more than dripping out
// single lines.
//
// Game over: none of the three blocks in your tray fits anywhere on the
// board. There is no timer — the board itself is the pressure.
import { useState, useRef, useMemo, useEffect } from 'react'
import type { PointerEvent as ReactPointerEvent, MouseEvent as ReactMouseEvent } from 'react'
import { Puzzle, Snowflake, Flame, Droplet, Leaf, Zap, Sun, type LucideIcon } from 'lucide-react'
import type { GameRank, GameEndPayload } from './types'
import { PreGameModal, GameHUD, StatChip, ResultScreen, QuitModal, useRankStreak } from './GameShell'
import { useGamePresence } from '../useGamePresence'
import { ripple } from '../../../shared/lib/ripple'
import { playLineClear, playElementalClear, playBlockPlace, playPraiseVoice, type PraiseTier } from '../sfx'

const ACCENT = '#2dd4bf'
const GAME_ID = 'elementa' as const
const GRID = 8
const CELLS = GRID * GRID

// Board geometry. Cells are absolutely positioned while dragging, so the
// size has to be a real pixel value rather than a percentage — it's
// measured from the available width instead of hardcoded, otherwise the
// board stays phone-sized on a laptop and looks lost in the viewport.
const MIN_CELL = 34   // phones
const MAX_CELL = 64   // desktop — past this the board dominates the screen
const GAP = 4
const PAD = 8

/** Largest cell size that fits the available width, within the bounds. */
function cellForWidth(width: number): number {
  if (!width) return MIN_CELL
  const usable = width - PAD * 2 - GAP * (GRID - 1)
  return Math.max(MIN_CELL, Math.min(MAX_CELL, Math.floor(usable / GRID)))
}

// How far ABOVE the pointer the dragged block floats, so a thumb never
// covers the cells you're aiming at. Scaled with the cell so it stays
// proportional on a big screen.
function liftForCell(cell: number): number { return Math.round(cell * 1.45) }

// XP is banked per cleared line. No session ceiling — the board itself
// (piece fit running out) is what ends the run, so XP is uncapped.
const LINE_XP = 5
const ELEMENTAL_XP = 8

// ─── Combo ladder ─────────────────────────────────────────────
// The combo is consecutive DROPS that cleared something — miss once and
// it's gone. Text pops on every combo, but the spoken line is rationed:
// tier entry (3 / 6 / 10) and then only every fifth combo after that, so
// a long run doesn't turn into a voice shouting over itself.
const COMBO_GREAT = 3
const COMBO_AMAZING = 6
const COMBO_EXCELLENT = 10
const VOICE_EVERY_AFTER = 5

function comboWord(combo: number): string | null {
  if (combo >= COMBO_EXCELLENT) return 'EXCELLENT'
  if (combo >= COMBO_AMAZING) return 'AMAZING'
  if (combo >= COMBO_GREAT) return 'GREAT'
  return null
}

function comboVoice(combo: number): PraiseTier | null {
  if (combo === COMBO_GREAT) return 'great'
  if (combo === COMBO_AMAZING) return 'amazing'
  if (combo === COMBO_EXCELLENT) return 'excellent'
  if (combo > COMBO_EXCELLENT && (combo - COMBO_EXCELLENT) % VOICE_EVERY_AFTER === 0) return 'excellent'
  return null
}

type Element = 'ice' | 'fire' | 'water' | 'leaf' | 'storm' | 'sun'

const ELEMENTS: Element[] = ['ice', 'fire', 'water', 'leaf', 'storm', 'sun']

const ELEMENT_META: Record<Element, { base: string; light: string; Icon: LucideIcon; label: string }> = {
  ice:   { base: '#38bdf8', light: '#a5f3fc', Icon: Snowflake, label: 'Ice' },
  fire:  { base: '#f43f5e', light: '#fda4af', Icon: Flame,     label: 'Fire' },
  water: { base: '#3b82f6', light: '#93c5fd', Icon: Droplet,   label: 'Water' },
  leaf:  { base: '#22c55e', light: '#86efac', Icon: Leaf,      label: 'Leaf' },
  storm: { base: '#a855f7', light: '#d8b4fe', Icon: Zap,       label: 'Storm' },
  sun:   { base: '#f59e0b', light: '#fcd34d', Icon: Sun,       label: 'Sun' },
}

type Cell = Element | null

// Shapes are lists of [row, col] offsets, already normalized to 0,0.
// Blocks never rotate — the rotations you'd want are separate entries,
// which is what makes the tray feel varied without any rotate control.
type Shape = [number, number][]

const SHAPES: Shape[] = [
  [[0, 0]],                                                   // dot
  [[0, 0], [0, 1]],                                           // 2 across
  [[0, 0], [1, 0]],                                           // 2 down
  [[0, 0], [0, 1], [0, 2]],                                   // 3 across
  [[0, 0], [1, 0], [2, 0]],                                   // 3 down
  [[0, 0], [0, 1], [0, 2], [0, 3]],                           // 4 across
  [[0, 0], [1, 0], [2, 0], [3, 0]],                           // 4 down
  [[0, 0], [0, 1], [1, 0], [1, 1]],                           // 2x2
  [[0, 0], [0, 1], [1, 0]],                                   // corner ↖
  [[0, 0], [0, 1], [1, 1]],                                   // corner ↗
  [[0, 1], [1, 0], [1, 1]],                                   // corner ↘
  [[0, 0], [1, 0], [1, 1]],                                   // corner ↙
  [[0, 0], [1, 0], [2, 0], [2, 1]],                           // J
  [[0, 1], [1, 1], [2, 0], [2, 1]],                           // L
  [[0, 0], [0, 1], [0, 2], [1, 1]],                           // T
  [[0, 1], [0, 2], [1, 0], [1, 1]],                           // S
  [[0, 0], [0, 1], [1, 1], [1, 2]],                           // Z
  [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2]],           // 2x3
  [[0, 0], [0, 1], [1, 0], [1, 1], [2, 0], [2, 1]],           // 3x2
  [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]], // 3x3
]

// Big blocks are the ones that end runs, so they're drawn less often than
// the small filler shapes rather than uniformly at random.
const WEIGHTS = [3, 6, 6, 6, 6, 4, 4, 5, 6, 6, 6, 6, 4, 4, 4, 4, 4, 2, 2, 1]

interface Piece {
  id: number
  shape: Shape
  element: Element
}

let pieceSeq = 0

function randomPiece(): Piece {
  const total = WEIGHTS.reduce((a, b) => a + b, 0)
  let roll = Math.random() * total
  let idx = 0
  for (let i = 0; i < WEIGHTS.length; i++) {
    roll -= WEIGHTS[i]
    if (roll <= 0) { idx = i; break }
  }
  return {
    id: ++pieceSeq,
    shape: SHAPES[idx],
    element: ELEMENTS[Math.floor(Math.random() * ELEMENTS.length)],
  }
}

function newTray(): Piece[] {
  return [randomPiece(), randomPiece(), randomPiece()]
}

function shapeW(shape: Shape) { return Math.max(...shape.map(s => s[1])) + 1 }
function shapeH(shape: Shape) { return Math.max(...shape.map(s => s[0])) + 1 }

function canPlace(board: Cell[], shape: Shape, r: number, c: number): boolean {
  for (const [dr, dc] of shape) {
    const rr = r + dr
    const cc = c + dc
    if (rr < 0 || rr >= GRID || cc < 0 || cc >= GRID) return false
    if (board[rr * GRID + cc] !== null) return false
  }
  return true
}

function fits(board: Cell[], shape: Shape): boolean {
  for (let r = 0; r < GRID; r++)
    for (let c = 0; c < GRID; c++)
      if (canPlace(board, shape, r, c)) return true
  return false
}

/** Cells that a candidate placement would clear, for the drag preview.
 *  Same completion rule as clearLines, run against a hypothetical board so
 *  the player can see the payoff before committing the block. */
function cellsClearedBy(board: Cell[], shape: Shape, r: number, c: number): Set<number> {
  const hypothetical = board.slice()
  for (const [dr, dc] of shape) hypothetical[(r + dr) * GRID + (c + dc)] = 'ice'

  const out = new Set<number>()
  for (let row = 0; row < GRID; row++) {
    let full = true
    for (let col = 0; col < GRID; col++) if (hypothetical[row * GRID + col] === null) { full = false; break }
    if (full) for (let col = 0; col < GRID; col++) out.add(row * GRID + col)
  }
  for (let col = 0; col < GRID; col++) {
    let full = true
    for (let row = 0; row < GRID; row++) if (hypothetical[row * GRID + col] === null) { full = false; break }
    if (full) for (let row = 0; row < GRID; row++) out.add(row * GRID + col)
  }
  return out
}

interface ClearResult {
  board: Cell[]
  cleared: number[]      // cell indices that were cleared (for the flash)
  lines: number          // how many rows + columns went at once
  elementalLines: number // of those, how many were single-element
}

function clearLines(board: Cell[]): ClearResult {
  const fullRows: number[] = []
  const fullCols: number[] = []

  for (let r = 0; r < GRID; r++) {
    let full = true
    for (let c = 0; c < GRID; c++) if (board[r * GRID + c] === null) { full = false; break }
    if (full) fullRows.push(r)
  }
  for (let c = 0; c < GRID; c++) {
    let full = true
    for (let r = 0; r < GRID; r++) if (board[r * GRID + c] === null) { full = false; break }
    if (full) fullCols.push(c)
  }

  if (fullRows.length === 0 && fullCols.length === 0) {
    return { board, cleared: [], lines: 0, elementalLines: 0 }
  }

  let elementalLines = 0
  const cleared = new Set<number>()

  for (const r of fullRows) {
    const line: number[] = []
    for (let c = 0; c < GRID; c++) line.push(r * GRID + c)
    if (line.every(i => board[i] === board[line[0]])) elementalLines++
    line.forEach(i => cleared.add(i))
  }
  for (const c of fullCols) {
    const line: number[] = []
    for (let r = 0; r < GRID; r++) line.push(r * GRID + c)
    if (line.every(i => board[i] === board[line[0]])) elementalLines++
    line.forEach(i => cleared.add(i))
  }

  const nb = board.slice()
  cleared.forEach(i => { nb[i] = null })

  return {
    board: nb,
    cleared: [...cleared],
    lines: fullRows.length + fullCols.length,
    elementalLines,
  }
}

interface Props {
  rank: GameRank
  streak?: number
  onEnd: (payload: GameEndPayload) => void
  onBack: () => void
  sessionsLeft?: number
  sessionCost?: number
  skipIntro?: boolean
}

export default function Elementa({ rank: initialRank, streak: initialStreak = 0, onEnd, onBack, sessionsLeft = 99, sessionCost = 2, skipIntro }: Props) {
  const [phase, setPhase] = useState<'info' | 'play' | 'result' | 'quit'>('info')
  useGamePresence(GAME_ID)
  const { rankState } = useRankStreak(GAME_ID, initialRank, initialStreak)

  const [board, setBoard] = useState<Cell[]>(() => Array.from({ length: CELLS }, () => null))
  const [tray, setTray] = useState<Piece[]>(() => newTray())
  const [score, setScore] = useState(0)
  const [lines, setLines] = useState(0)
  const [elemental, setElemental] = useState(0)
  const [combo, setCombo] = useState(0)          // consecutive clearing drops
  const [bestCombo, setBestCombo] = useState(0)  // longest such run this session
  const [xp, setXp] = useState(0)
  const [flash, setFlash] = useState<number[]>([])
  const [burst, setBurst] = useState<{ word: string | null; detail: string; key: number } | null>(null)
  const [result, setResult] = useState<GameEndPayload | null>(null)

  // Drag state — which tray slot is in hand and where the finger is.
  const [cell, setCell] = useState(MIN_CELL)
  const step = cell + GAP
  const lift = liftForCell(cell)

  const [drag, setDrag] = useState<{ slot: number; x: number; y: number } | null>(null)
  // Tap-to-place fallback for when a drag doesn't register (some browsers
  // swallow pointer capture inside scroll containers): tap a block to arm
  // it, then tap the cell you want its top-left corner to land on.
  const [armed, setArmed] = useState<number | null>(null)

  const boardRef = useRef<HTMLDivElement | null>(null)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const startRef = useRef(Date.now())
  const downRef = useRef<{ x: number; y: number } | null>(null)
  const movedRef = useRef(false)

  // Resize to whatever room the screen gives us: phone-sized cells on a
  // phone, up to MAX_CELL on a laptop or tablet.
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const measure = () => setCell(cellForWidth(el.clientWidth))
    measure()
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', measure)
      return () => window.removeEventListener('resize', measure)
    }
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [phase])

  // Where the dragged block would land right now, and whether that's legal.
  const target = useMemo(() => {
    if (!drag || !boardRef.current) return null
    const piece = tray[drag.slot]
    if (!piece) return null
    const rect = boardRef.current.getBoundingClientRect()
    const w = shapeW(piece.shape) * step - GAP
    const h = shapeH(piece.shape) * step - GAP
    const originX = drag.x - w / 2
    const originY = drag.y - lift - h / 2
    const c = Math.round((originX - rect.left - PAD) / step)
    const r = Math.round((originY - rect.top - PAD) / step)
    return { r, c, ok: canPlace(board, piece.shape, r, c) }
  }, [drag, tray, board, step, lift])

  // Cells that the current drag would clear outright. This is the tell
  // the game was missing — you could line up a clear and get no feedback
  // until after committing the block.
  const clearingCells = useMemo(() => {
    if (!target || !target.ok || !drag) return new Set<number>()
    const piece = tray[drag.slot]
    if (!piece) return new Set<number>()
    return cellsClearedBy(board, piece.shape, target.r, target.c)
  }, [target, drag, tray, board])

  const previewCells = useMemo(() => {
    if (!target || !target.ok || !drag) return new Set<number>()
    const piece = tray[drag.slot]
    if (!piece) return new Set<number>()
    return new Set(piece.shape.map(([dr, dc]) => (target.r + dr) * GRID + (target.c + dc)))
  }, [target, drag, tray])

  function start() {
    setBoard(Array.from({ length: CELLS }, () => null))
    setTray(newTray())
    setScore(0)
    setLines(0)
    setElemental(0)
    setCombo(0)
    setBestCombo(0)
    setXp(0)
    setFlash([])
    setBurst(null)
    setDrag(null)
    setArmed(null)
    setResult(null)
    startRef.current = Date.now()
    setPhase('play')
  }

  function finish(finalScore: number, finalLines: number, finalElemental: number, finalCombo: number, finalXp: number, reason: string) {
    const dur = Math.floor((Date.now() - startRef.current) / 1000)
    const payload: GameEndPayload = {
      gameId: GAME_ID,
      gameName: 'Elementa',
      rank: 'beginner', // Elementa is exempt from the rank system, like Chill Merge
      score: finalScore,
      xpEarned: finalXp,
      durationSec: dur,
      streak: finalCombo,
      correct: finalLines,
      total: finalLines,
      detail: {
        'Lines Cleared': finalLines,
        'Elemental Clears': finalElemental,
        'Best Combo': `×${finalCombo}`,
        'Result': reason,
      },
    }
    setResult(payload)
    setPhase('result')
    onEnd(payload)
  }

  // The one place the board actually changes: drop a block, clear whatever
  // that completes, refill the tray when it empties, then check whether
  // anything still fits.
  function commitPlacement(slot: number, r: number, c: number) {
    const piece = tray[slot]
    if (!piece || !canPlace(board, piece.shape, r, c)) return

    const placed = board.slice()
    for (const [dr, dc] of piece.shape) placed[(r + dr) * GRID + (c + dc)] = piece.element

    playBlockPlace()

    const res = clearLines(placed)

    // A drop that clears nothing breaks the combo. That's the whole
    // tension of the ladder — it has to be cheap to lose.
    const newCombo = res.lines > 0 ? combo + 1 : 0
    const word = res.lines > 0 ? comboWord(newCombo) : null
    const voice = res.lines > 0 ? comboVoice(newCombo) : null

    // Score: 1 per cell placed, then 8 per line squared by how many lines
    // went at once (a double is worth 4x a single), plus 25 an elemental,
    // plus a combo bonus that grows with the streak.
    let gained = piece.shape.length
    if (res.lines > 0) gained += 8 * res.lines * res.lines
    gained += res.elementalLines * 25
    if (newCombo >= 2) gained += 10 * (newCombo - 1)

    const gainedXp = res.lines * LINE_XP + res.elementalLines * ELEMENTAL_XP
    const newXp = xp + gainedXp
    const newScore = score + gained
    const newLines = lines + res.lines
    const newElemental = elemental + res.elementalLines
    const newBestCombo = Math.max(bestCombo, newCombo)

    let nextTray = tray.filter((_, i) => i !== slot)
    if (nextTray.length === 0) nextTray = newTray()

    setBoard(res.board)
    setTray(nextTray)
    setScore(newScore)
    setLines(newLines)
    setElemental(newElemental)
    setCombo(newCombo)
    setBestCombo(newBestCombo)
    setXp(newXp)

    if (res.cleared.length > 0) {
      // An elemental clear gets its own payoff sound instead of the plain
      // one — it's the whole point of the mechanic, so it shouldn't sound
      // like any other line going out.
      if (res.elementalLines > 0) playElementalClear()
      else playLineClear()
      if (voice) playPraiseVoice(voice)

      setFlash(res.cleared)
      const detail = res.elementalLines > 0
        ? `ELEMENTAL CLEAR  +${gained}`
        : res.lines > 1
          ? `${res.lines} LINES  +${gained}`
          : `+${gained}`
      setBurst({ word: newCombo >= 2 ? (word ?? `COMBO ×${newCombo}`) : null, detail, key: Date.now() })
      // Cosmetic only — both the flash and the burst fade out via CSS, so
      // a dropped timer leaves nothing visible behind.
      setTimeout(() => { setFlash([]); setBurst(null) }, 1000)
    }

    if (!nextTray.some(p => fits(res.board, p.shape))) {
      finish(newScore, newLines, newElemental, newBestCombo, newXp, 'No block left that fits')
    }
  }

  // ─── Drag handlers (tray → board) ─────────────────────────────
  function onPieceDown(e: ReactPointerEvent<HTMLDivElement>, slot: number) {
    if (phase !== 'play') return
    e.currentTarget.setPointerCapture(e.pointerId)
    downRef.current = { x: e.clientX, y: e.clientY }
    movedRef.current = false
    setArmed(null)
    setDrag({ slot, x: e.clientX, y: e.clientY })
  }

  function onPieceMove(e: ReactPointerEvent<HTMLDivElement>) {
    if (!drag) return
    // A few px of thumb wobble shouldn't turn a tap into a drop — only
    // past this threshold does the gesture count as a drag.
    const d = downRef.current
    if (d && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 8) movedRef.current = true
    setDrag(d => (d ? { ...d, x: e.clientX, y: e.clientY } : d))
  }

  function onPieceUp(e: ReactPointerEvent<HTMLDivElement>, slot: number) {
    if (!drag) return
    if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId)
    const t = target
    setDrag(null)
    if (!movedRef.current) {
      // Treated as a tap — arm the block for tap-to-place instead.
      setArmed(prev => (prev === slot ? null : slot))
      return
    }
    if (t && t.ok) commitPlacement(slot, t.r, t.c)
  }

  function onCellClick(e: ReactMouseEvent<HTMLDivElement>, i: number) {
    if (phase !== 'play' || armed === null) return
    const piece = tray[armed]
    if (!piece) return
    const r = Math.floor(i / GRID)
    const c = i % GRID
    if (!canPlace(board, piece.shape, r, c)) return
    ripple(e)
    const slot = armed
    setArmed(null)
    commitPlacement(slot, r, c)
  }

  function endSessionEarly() {
    finish(score, lines, elemental, bestCombo, xp, 'Ended early')
  }

  const filled = useMemo(() => board.filter(c => c !== null).length, [board])
  const armedPiece = armed !== null ? tray[armed] : null

  const rules = [
    { icon: '🧩', text: 'Drag a block from the tray onto the 8x8 board — blocks never rotate' },
    { icon: '👆', text: 'Or tap a block to arm it, then tap the cell where its top-left corner goes' },
    { icon: '🧹', text: 'Fill a full row or column and it clears off the board' },
    { icon: '🔥', text: 'Clear a line where every cell is the SAME element for an Elemental Clear — big score bonus' },
    { icon: '⚡', text: `+${LINE_XP} XP per line, +${ELEMENTAL_XP} more per Elemental Clear — no session cap` },
    { icon: '💀', text: 'When none of your three blocks fits anywhere, the run is over' },
    { icon: '🔒', text: `Costs ${sessionCost} sessions per play` },
  ]

  if (phase === 'info') return (
    <PreGameModal
      gameName="Elementa"
      tagline="Drop the elements. Clear the lines. Don't get boxed in."
      accent={ACCENT}
      icon={<Puzzle size={40} />}
      rules={rules}
      rankState={rankState}
      streakRequired={0}
      onStart={start}
      onClose={onBack}
      autoStart={skipIntro}
    />
  )

  if (phase === 'result' && result) return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <ResultScreen payload={result} accent={ACCENT} onReplay={() => { setResult(null); start() }} onBack={onBack} sessionsLeft={sessionsLeft} sessionCost={sessionCost} />
    </div>
  )

  const draggedPiece = drag ? tray[drag.slot] : null

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--bg)', position: 'relative', touchAction: drag ? 'none' : 'auto' }}>
      <div style={{ position: 'absolute', width: 220, height: 220, borderRadius: '50%', filter: 'blur(80px)', opacity: 0.08, background: ACCENT, top: '10%', right: '-8%', pointerEvents: 'none' }} />

      <GameHUD
        gameName="Elementa"
        accent={ACCENT}
        icon={<Puzzle size={14} />}
        streak={bestCombo}
        onQuit={() => setPhase('quit')}
        extraRight={
          <div style={{ display: 'flex', gap: 6 }}>
            <StatChip label="SCORE" value={score} accent={ACCENT} />
            <StatChip label="LINES" value={lines} accent="var(--gold)" />
          </div>
        }
      />

      <div style={{ display: 'flex', flexDirection: 'column', flex: 1, alignItems: 'center', padding: '12px 16px 20px', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-dim)' }}>{filled}/{CELLS} cells filled</span>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-dim)' }}>{elemental} elemental</span>
          {combo >= 2 && (
            <span style={{
              fontFamily: '"Bangers", "Poppins", sans-serif', fontSize: 15, letterSpacing: 1,
              color: '#fff', textShadow: `0 0 10px ${ACCENT}, 0 0 20px ${ACCENT}`,
            }}>COMBO ×{combo}</span>
          )}
          <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>
            Session XP: <span style={{ color: 'var(--accent)', fontWeight: 700 }}>+{xp}</span>
          </span>
        </div>

        {/* Board — the wrapper spans the full available width and is what
            the cell size is measured against; the board itself centres in it. */}
        <div ref={wrapRef} style={{ position: 'relative', width: '100%', display: 'flex', justifyContent: 'center' }}>
          <div
            ref={boardRef}
            style={{
              display: 'grid',
              gridTemplateColumns: `repeat(${GRID}, ${cell}px)`,
              gridTemplateRows: `repeat(${GRID}, ${cell}px)`,
              gap: GAP, padding: PAD, borderRadius: 18,
              background: 'var(--surface2)', boxShadow: 'var(--elev-inset)',
            }}>
            {board.map((value, i) => {
              const meta = value ? ELEMENT_META[value] : null
              const Icon = meta?.Icon
              const isPreview = previewCells.has(i)
              const isClearing = clearingCells.has(i)
              const isFlash = flash.includes(i)
              const previewMeta = draggedPiece ? ELEMENT_META[draggedPiece.element] : null

              return (
                <div key={i}
                  onClick={e => onCellClick(e, i)}
                  style={{
                    width: cell, height: cell, borderRadius: Math.round(cell * 0.25),
                    background: value && meta
                      ? `linear-gradient(135deg, ${meta.light}, ${meta.base})`
                      : isPreview && previewMeta
                        ? `${previewMeta.base}55`
                        : 'var(--surface)',
                    border: isClearing
                      ? '2px solid rgba(255,255,255,0.9)'
                      : isPreview && previewMeta ? `2px dashed ${previewMeta.light}` : '1px solid var(--border)',
                    boxShadow: isClearing
                      ? '0 0 16px rgba(255,255,255,0.75), 0 0 26px rgba(45,212,191,0.6)'
                      : value && meta
                        ? `0 0 10px ${meta.base}44, 2px 2px 6px var(--neu-dark)`
                        : '2px 2px 6px var(--neu-dark), -1px -1px 4px var(--neu-light)',
                    zIndex: isClearing ? 2 : undefined,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    position: 'relative', overflow: 'hidden',
                    cursor: armedPiece ? 'pointer' : 'default',
                    transition: 'background 0.15s, box-shadow 0.15s, border-color 0.15s',
                    animation: isFlash
                      ? 'el-flash 0.6s ease-out forwards'
                      : isClearing ? 'el-rainbow 1.1s linear infinite' : undefined,
                  }}>
                  {value && Icon && (
                    <Icon size={Math.round(cell * 0.45)} style={{ color: 'rgba(255,255,255,0.9)' }} />
                  )}
                </div>
              )
            })}
          </div>

          {burst && (
            <div key={burst.key} style={{
              position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 2,
              pointerEvents: 'none', animation: 'el-burst 1s ease-out forwards',
            }}>
              {burst.word && (
                <span style={{
                  // Bangers is already loaded app-wide — an arcade face is
                  // what this moment wants, not the UI's Inter.
                  fontFamily: '"Bangers", "Poppins", sans-serif',
                  fontSize: Math.round(cell * 1.15), letterSpacing: 2, lineHeight: 1,
                  color: '#fff',
                  textShadow: `0 0 8px #fff, 0 0 22px ${ACCENT}, 0 0 42px ${ACCENT}, 0 4px 10px rgba(0,0,0,0.6)`,
                  transform: 'rotate(-4deg)',
                }}>{burst.word}</span>
              )}
              <span style={{
                fontFamily: '"Bangers", "Poppins", sans-serif',
                fontSize: Math.round(cell * 0.6), letterSpacing: 1.5, lineHeight: 1,
                color: 'var(--gold)',
                textShadow: '0 0 12px rgba(245,197,66,0.9), 0 2px 6px rgba(0,0,0,0.6)',
              }}>{burst.detail}</span>
            </div>
          )}
        </div>

        <p style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: 'center', minHeight: 15 }}>
          {armedPiece
            ? 'Tap a cell — that cell becomes the block’s top-left corner'
            : 'Drag a block onto the board, or tap one to arm it'}
        </p>

        {/* Tray */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14,
          padding: '12px 10px', borderRadius: 18, minHeight: Math.max(96, Math.round(cell * 2.6)),
          background: 'var(--surface2)', border: '1px solid var(--border)', width: GRID * step - GAP + PAD * 2,
        }}>
          {tray.map((piece, slot) => {
            const dead = !fits(board, piece.shape)
            const inHand = drag?.slot === slot
            return (
              <div key={piece.id}
                onPointerDown={e => onPieceDown(e, slot)}
                onPointerMove={onPieceMove}
                onPointerUp={e => onPieceUp(e, slot)}
                onPointerCancel={() => setDrag(null)}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  padding: 6, borderRadius: 12, touchAction: 'none', cursor: 'grab',
                  opacity: inHand ? 0.25 : dead ? 0.4 : 1,
                  filter: dead ? 'grayscale(0.7)' : 'none',
                  border: armed === slot ? `2px solid ${ACCENT}` : '2px solid transparent',
                  background: armed === slot ? `${ACCENT}18` : 'transparent',
                  transition: 'opacity 0.15s, border-color 0.15s, background 0.15s',
                }}>
                <MiniPiece piece={piece} mini={Math.max(12, Math.min(26, Math.round(cell * 0.42)))} />
              </div>
            )
          })}
        </div>

        <button type="button" onClick={endSessionEarly}
          style={{ padding: '9px 18px', borderRadius: 12, background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text-dim)', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>
          End Session Early
        </button>
      </div>

      {/* Floating block that follows the finger while dragging */}
      {drag && draggedPiece && (() => {
        const w = shapeW(draggedPiece.shape) * step - GAP
        const h = shapeH(draggedPiece.shape) * step - GAP
        const meta = ELEMENT_META[draggedPiece.element]
        const Icon = meta.Icon
        return (
          <div style={{
            position: 'fixed', left: drag.x - w / 2, top: drag.y - lift - h / 2,
            width: w, height: h, pointerEvents: 'none', zIndex: 60,
            opacity: target?.ok ? 1 : 0.65,
          }}>
            {draggedPiece.shape.map(([dr, dc], k) => (
              <div key={k} style={{
                position: 'absolute', left: dc * step, top: dr * step,
                width: cell, height: cell, borderRadius: Math.round(cell * 0.25),
                background: `linear-gradient(135deg, ${meta.light}, ${meta.base})`,
                boxShadow: `0 0 14px ${meta.base}66`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon size={Math.round(cell * 0.45)} style={{ color: 'rgba(255,255,255,0.9)' }} />
              </div>
            ))}
          </div>
        )
      })()}

      {phase === 'quit' && <QuitModal onConfirm={onBack} onCancel={() => setPhase('play')} />}

      <style>{`
        @keyframes el-flash {
          0%   { background: #fff; box-shadow: 0 0 24px #fff; }
          100% { background: var(--surface); box-shadow: 2px 2px 6px var(--neu-dark); }
        }
        @keyframes el-burst {
          0%   { opacity: 0; transform: scale(0.6) rotate(-2deg); }
          20%  { opacity: 1; transform: scale(1.14) rotate(1deg); }
          32%  { transform: scale(0.98) rotate(-1deg); }
          44%  { transform: scale(1.04) rotate(0deg); }
          78%  { opacity: 1; transform: scale(1) translateY(0); }
          100% { opacity: 0; transform: scale(1.06) translateY(-22px); }
        }
        /* The would-clear glow cycles hue so it reads as "this is the one"
           at a glance, rather than as just another highlighted cell. */
        @keyframes el-rainbow {
          0%   { filter: hue-rotate(0deg)   brightness(1.25); }
          50%  { filter: hue-rotate(180deg) brightness(1.45); }
          100% { filter: hue-rotate(360deg) brightness(1.25); }
        }
      `}</style>
    </div>
  )
}

// The tray preview — same shape, drawn small so three blocks fit a phone.
function MiniPiece({ piece, mini }: { piece: Piece; mini: number }) {
  const meta = ELEMENT_META[piece.element]
  const Icon = meta.Icon
  const gap = 2
  const step = mini + gap
  const w = shapeW(piece.shape) * step - gap
  const h = shapeH(piece.shape) * step - gap
  return (
    <div style={{ position: 'relative', width: w, height: h }}>
      {piece.shape.map(([dr, dc], k) => (
        <div key={k} style={{
          position: 'absolute', left: dc * step, top: dr * step,
          width: mini, height: mini, borderRadius: Math.round(mini * 0.28),
          background: `linear-gradient(135deg, ${meta.light}, ${meta.base})`,
          boxShadow: `0 0 6px ${meta.base}55`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon size={Math.round(mini * 0.55)} style={{ color: 'rgba(255,255,255,0.9)' }} />
        </div>
      ))}
    </div>
  )
}
