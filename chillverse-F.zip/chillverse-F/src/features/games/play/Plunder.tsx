// src/features/games/play/Plunder.tsx
// ─── Plunder ──────────────────────────────────────────────────
// Dig deep. Bank early. Nobody does both.
//
// A press-your-luck dive. Every depth is a grid of buried tiles, and you
// are told exactly how many of them are cursed. Tap a tile to dig it:
// safe tiles pay doubloons into your hold and push your depth multiplier
// up, a curse ends the dive and everything still in the hold goes with
// it. At any point you can bank what you're holding and drop to the next
// depth — bigger grid, more curses, richer loot.
//
// The dive bottoms out at depth 8. That bound is deliberate: an endless
// version has a degenerate strategy (dig the minimum, bank, repeat, never
// risk anything) that a simulation of the loop found immediately, and a
// finish line turns the run into a shape — how deep, and how rich — rather
// than a grind.
//
// The whole game is one decision asked over and over: one more, or bank?
// There is no clock, because a clock would answer it for you.
//
// Every timed transition is driven by a `useEffect` keyed on the phase
// rather than a chain of setTimeouts held in refs. React StrictMode
// (which main.tsx turns on) mounts, unmounts and remounts on the first
// render, and a ref-held timer chain gets wiped by the unmount cleanup
// and never restarts. Effects simply re-run, so the chain heals itself.
import { useState, useRef, useEffect, useCallback } from 'react'
import type { CSSProperties } from 'react'
import { Skull, Coins, Anchor, Gem } from 'lucide-react'
import type { GameRank, GameEndPayload } from './types'
import { getRankConfig } from './types'
import { useGamePresence } from '../useGamePresence'
import { useAuth } from '../../auth/useAuth'
import { supabase } from '../../../shared/lib/supabase'
import { PreGameModal, GameHUD, StatChip, ResultScreen, QuitModal, useRankStreak } from './GameShell'
import PlunderHatCard from '../PlunderHatCard'
import { playDig, playCoin, playRuby, playCurse, playBank, playWrongCard, playNaughty } from '../sfx'

const GAME_ID   = 'plunder' as const
const GAME_NAME = 'Plunder'
const ACCENT    = '#ffcc2b'   // doubloon gold
const DANGER    = '#ff3b52'   // the curse
const RUBY      = '#ff4d8b'   // the jackpot tile

// ─── Depth curve ──────────────────────────────────────────────
// Grids stay at or under 5 columns so a tile is never smaller than a
// comfortable tap target on a phone. The difficulty lives in the ratio
// of curses to tiles, not in the size of the board.
const MAX_DEPTH = 8   // the wreck floor — bank here and you surface rich

interface DepthSpec { cols: number; rows: number; curses: number }
function depthSpec(d: number): DepthSpec {
  if (d <= 1) return { cols: 4, rows: 4, curses: 1 }  // 6%
  if (d === 2) return { cols: 4, rows: 4, curses: 2 } // 12%
  if (d === 3) return { cols: 5, rows: 4, curses: 3 } // 15%
  if (d === 4) return { cols: 5, rows: 5, curses: 4 } // 16%
  if (d === 5) return { cols: 5, rows: 5, curses: 5 } // 20%
  if (d === 6) return { cols: 5, rows: 5, curses: 6 } // 24%
  return { cols: 5, rows: 5, curses: Math.min(9, 6 + (d - 6)) }
}

// You must dig this many tiles at a depth before the bank unlocks. Without
// it the first-dig mercy below hands out a free, risk-free bank at every
// depth, and the optimal run becomes "dig once, bank, repeat" forever.
//
// The quota climbs with depth so that descending costs real exposure rather
// than one extra tap: at the wreck floor you must turn over six tiles with
// eight curses buried under them. Tuned by simulating 40k runs of the
// dig-the-minimum-and-bank strategy this rule exists to punish — a flat 2/3
// let 35% of beginner runs reach the floor, while ramping all the way to 7
// dropped it to 1.6% and made the surface bonus dead content. This curve
// lands at 4.7%: rare enough to be a trophy, common enough to chase.
const MIN_DIGS = [2, 2, 3, 3, 4, 4, 5, 6]
function minDigs(depth: number): number {
  return MIN_DIGS[Math.min(Math.max(depth, 1), MAX_DEPTH) - 1]
}

// Higher ranks start further along the same curve instead of getting a
// separate one, so the tuning above only has to hold in one place.
const RANK_OFFSET: Record<GameRank, number> = {
  beginner: 0, intermediate: 1, advanced: 2, master: 3,
}

// Charms eat a curse outright. They're the difference between a rank that
// forgives one bad read and one that doesn't, and they're the main lever
// that keeps a bad early dive from being a wasted session.
function charmsForRank(rank: GameRank): number {
  if (rank === 'beginner') return 2
  if (rank === 'master') return 0
  return 1
}

// ─── Loot ─────────────────────────────────────────────────────
// The unit climbs with depth so descending is worth the extra curses.
function lootUnit(d: number): number { return 20 + (d - 1) * 14 }
const LOOT_TIERS = [1, 1, 1, 1, 2, 2, 3]
const RUBY_MULT  = 9

// The multiplier is the real reason to keep digging: it only applies to
// what you bank, and it resets to ×1 the moment you drop to a new depth.
const MULT_STEP = 0.25
const MULT_CAP  = 3.5

// Clearing every safe tile in a depth pays a bonus on top of the bank.
function clearBonus(d: number): number { return 120 * d }

// Banking the wreck floor ends the run on your own terms. It's the only
// way out that isn't a curse, so it's worth more than any single depth.
const SURFACE_BONUS = 1500

// ─── XP ───────────────────────────────────────────────────────
// Sits with Elementa and The Last Samurai at 2 sessions a run, so the
// ceiling matches theirs rather than Chill Link's.
const XP_CAP = 150
function xpForRun(chests: number, digs: number, surfaced: boolean): number {
  if (digs <= 0) return 0
  return Math.min(XP_CAP, chests * 16 + digs * 2 + (surfaced ? 35 : 0))
}

const PRAISE = ['Nice haul!', 'Gold!', 'Keep digging!', 'Rich seam!', 'Loaded!']

// ─── Particle directions ──────────────────────────────────────
// Fixed rather than random: a dig should look the same every time so the
// board reads as a set of physical objects, and it keeps the animation off
// the render path. Fed to the keyframes as CSS custom properties.
const BURST: Array<[number, number]> = [
  [-19, -21], [0, -27], [19, -21], [25, -3], [-25, -3], [-13, 14], [13, 14],
]
const COIN_FLY: Array<[number, number]> = [
  [-96, -150], [-52, -186], [-14, -164], [22, -192], [64, -158], [104, -142],
  [-72, -122], [46, -128], [-24, -206], [82, -178], [-110, -168], [10, -138],
]

// The Naughty pop. Same art as the Plunder run highlight, reused here
// deliberately — it's the game's face, and a player should recognise it.
const PIRATE_SRC =
  'https://gnobzfxtxrtcxfhhfjni.supabase.co/storage/v1/object/public/Adverts/Landing/Pirate.png'

type TileKind = 'coin' | 'ruby' | 'curse'
interface Tile {
  id: number
  kind: TileKind
  value: number
  revealed: boolean
  /** A curse that a charm ate — shown blue-green and struck through
   *  rather than red, so the save reads as a save. */
  warded?: boolean
}

function shuffleArr<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/** Build one depth: curses, exactly one ruby if there's room for it, and
 *  coins for everything else, then scattered across the grid. */
function buildDepth(d: number): { tiles: Tile[]; spec: DepthSpec } {
  const spec  = depthSpec(d)
  const cells = spec.cols * spec.rows
  const unit  = lootUnit(d)
  const safe  = cells - spec.curses

  const kinds: Omit<Tile, 'id' | 'revealed'>[] = []
  for (let i = 0; i < spec.curses; i++) kinds.push({ kind: 'curse', value: 0 })
  if (safe >= 6) kinds.push({ kind: 'ruby', value: unit * RUBY_MULT })
  while (kinds.length < cells) {
    const tier = LOOT_TIERS[Math.floor(Math.random() * LOOT_TIERS.length)]
    kinds.push({ kind: 'coin', value: unit * tier })
  }

  return {
    spec,
    tiles: shuffleArr(kinds).map((k, i) => ({ ...k, id: i, revealed: false })),
  }
}

interface Props {
  rank: GameRank
  streak?: number
  onEnd: (payload: GameEndPayload) => void
  onBack: () => void
  sessionsLeft?: number
  sessionCost?: number
  skipIntro?: boolean
}

type Phase = 'info' | 'play' | 'banking' | 'surfaced' | 'busted' | 'paused' | 'result'

export default function Plunder({
  rank: initialRank, streak: initialStreak = 0, onEnd, onBack, sessionsLeft = 99, sessionCost = 2, skipIntro,
}: Props) {
  const [phase, setPhase] = useState<Phase>('info')
  useGamePresence(GAME_ID)
  const { rankState, onCorrect, onWrong } = useRankStreak(GAME_ID, initialRank, initialStreak)
  const { session } = useAuth()

  const [tiles, setTiles]   = useState<Tile[]>([])
  const [spec, setSpec]     = useState<DepthSpec>(depthSpec(1))
  const [depth, setDepth]   = useState(1)
  const [hold, setHold]     = useState(0)
  const [mult, setMult]     = useState(1)
  const [total, setTotal]   = useState(0)
  const [shownTotal, setShownTotal] = useState(0)
  const [charms, setCharms] = useState(0)
  const [dugHere, setDugHere] = useState(0)
  const [best, setBest]     = useState(0)
  const [banner, setBanner] = useState('')
  const [praise, setPraise] = useState<{ text: string; key: number } | null>(null)
  const [float, setFloat]   = useState<{ text: string; key: number; color: string } | null>(null)
  const [flash, setFlash]   = useState<{ key: number; color: string } | null>(null)
  const [naughty, setNaughty]   = useState<number | null>(null)
  const [showerKey, setShowerKey] = useState(0)
  const [descendKey, setDescendKey] = useState(0)
  const [promoted, setPromoted]     = useState<GameRank | null>(null)
  const [result, setResult]         = useState<GameEndPayload | null>(null)

  const totalRef   = useRef(0)
  const chestsRef  = useRef(0)
  const digsRef    = useRef(0)
  const streakRef  = useRef(0)
  const bestStreakRef = useRef(0)
  const bestMultRef   = useRef(1)
  const depthRef   = useRef(1)
  const surfacedRef = useRef(false)
  const startRef   = useRef(Date.now())
  const endedRef   = useRef(false)
  /** A charm was spent at the current depth — the dive survived, but it
   *  wasn't clean, so the Naughty pop is off the table for this depth. */
  const wardedHereRef  = useRef(false)
  /** The depth the Naughty pop has already fired at, so it can't repeat. */
  const naughtyDepthRef = useRef(0)

  // ── Personal best, for the HUD and the game-over card ──
  useEffect(() => {
    const uid = session?.user?.id
    if (!uid) return
    supabase
      .from('game_sessions')
      .select('score')
      .eq('user_id', uid)
      .eq('game', 'plunder')
      .order('score', { ascending: false })
      .limit(1)
      .maybeSingle<{ score: number }>()
      .then(({ data }) => { if (data?.score) setBest(data.score) }, () => {})
  }, [session?.user?.id])

  // ── The doubloon counter rolls up rather than snapping ──
  // Self-healing chain: each tick schedules the next from an effect, so a
  // StrictMode remount just restarts it instead of stranding it.
  useEffect(() => {
    if (shownTotal === total) return
    const step = Math.max(1, Math.ceil(Math.abs(total - shownTotal) / 10))
    const id = setTimeout(() => {
      setShownTotal(v => (v < total ? Math.min(total, v + step) : total))
    }, 28)
    return () => clearTimeout(id)
  }, [shownTotal, total])

  const finishRun = useCallback((reason: string) => {
    if (endedRef.current) return
    endedRef.current = true

    const dur    = Math.floor((Date.now() - startRef.current) / 1000)
    const final  = totalRef.current
    const chests = chestsRef.current
    const digs   = digsRef.current
    const xp     = xpForRun(chests, digs, surfacedRef.current)
    const newBest = Math.max(best, final)
    if (final > best) setBest(final)

    const payload: GameEndPayload = {
      gameId: GAME_ID,
      gameName: GAME_NAME,
      rank: rankState.rank,
      score: final,
      xpEarned: xp,
      durationSec: dur,
      streak: rankState.bestStreak,
      correct: digs,
      total: Math.max(digs, 1),
      detail: {
        'Depth Reached': `${depthRef.current} / ${MAX_DEPTH}`,
        'Chests Banked': chests,
        'Best Multiplier': `×${bestMultRef.current.toFixed(2)}`,
        'Longest Dig Streak': bestStreakRef.current,
        'Personal Best': newBest.toLocaleString(),
        'Ended By': reason,
      },
    }

    // Two banked chests is the bar for "that was a real dive" — busting
    // out on depth one shouldn't count toward a promotion.
    if (chests >= 2) {
      const { promoted: promo } = onCorrect(getRankConfig(rankState.rank).streakRequired)
      if (promo) setPromoted(promo)
    } else {
      onWrong()
    }

    setResult(payload)
    setPhase('result')
    onEnd(payload)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [best, rankState.rank, rankState.bestStreak])

  // ── Banked → beat → descend to the next depth ──
  useEffect(() => {
    if (phase !== 'banking') return
    const t = setTimeout(() => {
      const next = depth + 1
      setDepth(next)
      depthRef.current = next
      const built = buildDepth(next + RANK_OFFSET[rankState.rank])
      setTiles(built.tiles)
      setSpec(built.spec)
      setHold(0)
      setMult(1)
      setDugHere(0)
      setFloat(null)
      setPraise(null)
      setNaughty(null)
      wardedHereRef.current = false
      setDescendKey(k => k + 1)
      setBanner(`Depth ${next} — ${built.spec.curses} curses down here`)
      setPhase('play')
    }, 1150)
    return () => clearTimeout(t)
  }, [phase, depth, rankState.rank])

  // ── Surfaced → let the celebration land → result ──
  useEffect(() => {
    if (phase !== 'surfaced') return
    const t = setTimeout(() => finishRun('Surfaced'), 1900)
    return () => clearTimeout(t)
  }, [phase, finishRun])

  // ── Busted → let the board finish showing itself → result ──
  useEffect(() => {
    if (phase !== 'busted') return
    const t = setTimeout(() => finishRun('Cursed'), 1700)
    return () => clearTimeout(t)
  }, [phase, finishRun])

  // ── Transient bits clear themselves ──
  useEffect(() => {
    if (!praise) return
    const t = setTimeout(() => setPraise(null), 900)
    return () => clearTimeout(t)
  }, [praise])

  useEffect(() => {
    if (!flash) return
    const t = setTimeout(() => setFlash(null), 700)
    return () => clearTimeout(t)
  }, [flash])

  // The Naughty pop clears itself. Matches the animation length below, so
  // it unmounts exactly as it finishes fading rather than snapping away.
  useEffect(() => {
    if (!naughty) return
    const t = setTimeout(() => setNaughty(null), 1900)
    return () => clearTimeout(t)
  }, [naughty])

  function beginRun() {
    endedRef.current    = false
    totalRef.current    = 0
    chestsRef.current   = 0
    digsRef.current     = 0
    streakRef.current   = 0
    bestStreakRef.current = 0
    bestMultRef.current = 1
    depthRef.current    = 1
    surfacedRef.current = false
    startRef.current    = Date.now()
    wardedHereRef.current  = false
    naughtyDepthRef.current = 0

    const built = buildDepth(1 + RANK_OFFSET[rankState.rank])
    setTiles(built.tiles)
    setSpec(built.spec)
    setDepth(1)
    setHold(0)
    setMult(1)
    setTotal(0)
    setShownTotal(0)
    setCharms(charmsForRank(rankState.rank))
    setDugHere(0)
    setFloat(null)
    setPraise(null)
    setFlash(null)
    setDescendKey(k => k + 1)
    setBanner(`${built.spec.curses} curses buried down here`)
    setPromoted(null)
    setResult(null)
    setPhase('play')
  }

  // Quitting pauses outright — there's no clock, but the quit modal
  // shouldn't sit over a live board either.
  function openQuit() {
    if (phase === 'result') return
    setPhase('paused')
  }

  /** Bank a hold and either drop to the next depth or, at the wreck floor,
   *  end the run on the player's own terms. Takes the hold and multiplier
   *  as arguments so the auto-bank on a stripped depth can pass the values
   *  it just computed rather than racing the state updates. */
  function bank(heldAmount: number, multiplier: number, bonus = 0, note?: string) {
    const atFloor = depth >= MAX_DEPTH
    const payout  = Math.round(heldAmount * multiplier) + bonus + (atFloor ? SURFACE_BONUS : 0)
    totalRef.current += payout
    chestsRef.current += 1
    setTotal(totalRef.current)
    playBank()
    setFlash({ key: Date.now(), color: ACCENT })
    setFloat({ text: `+${payout.toLocaleString()}`, key: Date.now(), color: ACCENT })
    setNaughty(null)
    setShowerKey(k => k + 1)

    if (atFloor) {
      surfacedRef.current = true
      setBanner(`Surfaced with ${totalRef.current.toLocaleString()} doubloons`)
      setPhase('surfaced')
      return
    }
    setBanner(note ?? `Banked ${payout.toLocaleString()} doubloons`)
    setPhase('banking')
  }

  function onTileTap(id: number) {
    if (phase !== 'play') return
    let working = tiles
    let tile = working.find(t => t.id === id)
    if (!tile || tile.revealed) return

    // ── First dig of a depth is always safe ──
    // Not a lie so much as a dealing rule: the curses aren't considered
    // placed until you've broken ground. Without it a dive can end on the
    // very first tap with nothing banked, which is the one outcome that
    // makes a player put the game down instead of running it back.
    if (dugHere === 0 && tile.kind === 'curse') {
      const swaps = working.filter(t => !t.revealed && t.kind !== 'curse')
      if (swaps.length > 0) {
        const other = swaps[Math.floor(Math.random() * swaps.length)]
        working = working.map(t => {
          if (t.id === tile!.id) return { ...t, kind: other.kind, value: other.value }
          if (t.id === other.id) return { ...t, kind: 'curse' as TileKind, value: 0 }
          return t
        })
        tile = working.find(t => t.id === id)!
      }
    }

    // ── Curse ──
    if (tile.kind === 'curse') {
      // A charm eats it. The multiplier is the price: the dive survives
      // but the run it was building does not.
      if (charms > 0) {
        setCharms(c => c - 1)
        setTiles(working.map(t => (t.id === id ? { ...t, revealed: true, warded: true } : t)))
        streakRef.current = 0
        wardedHereRef.current = true
        setMult(1)
        playWrongCard()
        setFlash({ key: Date.now(), color: '#2ec4d6' })
        setBanner('The charm holds — multiplier reset')
        return
      }

      playCurse()
      setTiles(working.map(t => (
        t.id === id || t.kind === 'curse' ? { ...t, revealed: true } : t
      )))
      setHold(0)
      setBanner('Cursed — the hold is gone')
      setPhase('busted')
      return
    }

    // ── Loot ──
    const nextMult = Math.min(MULT_CAP, mult + MULT_STEP)
    digsRef.current += 1
    streakRef.current += 1
    bestStreakRef.current = Math.max(bestStreakRef.current, streakRef.current)
    bestMultRef.current   = Math.max(bestMultRef.current, nextMult)

    const nextTiles = working.map(t => (t.id === id ? { ...t, revealed: true } : t))
    const nextHold  = hold + tile.value
    setTiles(nextTiles)
    setHold(nextHold)
    setMult(nextMult)
    setDugHere(n => n + 1)

    if (tile.kind === 'ruby') {
      playRuby()
      setFlash({ key: Date.now(), color: RUBY })
      setPraise({ text: 'RUBY!', key: Date.now() })
      setFloat({ text: `+${tile.value.toLocaleString()}`, key: Date.now(), color: RUBY })
      setBanner('')
    } else {
      playDig()
      playCoin()
      setFloat({ text: `+${tile.value.toLocaleString()}`, key: Date.now(), color: ACCENT })
      if (streakRef.current >= 3 && streakRef.current % 3 === 0) {
        setPraise({ text: PRAISE[Math.floor(Math.random() * PRAISE.length)], key: Date.now() })
      }
      setBanner('')
    }

    // ── Naughty ──────────────────────────────────────────────────
    // One safe tile left, and the charm was never spent — the player has
    // emptied the depth of everything except the curses and is standing
    // over the last of it. The tension is entirely in what they do next,
    // so the pop lands here rather than after the board clears.
    const safeLeft = nextTiles.filter(t => !t.revealed && t.kind !== 'curse').length
    if (safeLeft === 1 && !wardedHereRef.current && naughtyDepthRef.current !== depth) {
      naughtyDepthRef.current = depth
      playNaughty()
      setNaughty(Date.now())
    }

    // ── Depth stripped bare → auto-bank with the clear bonus ──
    if (safeLeft === 0) {
      const bonus = clearBonus(depth)
      bank(nextHold, nextMult, bonus, `Stripped it bare  +${bonus.toLocaleString()} bonus`)
    }
  }

  // ── Render ──
  const rankCfg = getRankConfig(rankState.rank)
  const rules = [
    { icon: '🪙', text: 'Tap buried tiles to dig — every safe one pays into your hold' },
    { icon: '💀', text: 'You are told how many curses are down there. Hit one and the hold is gone' },
    { icon: '📈', text: 'Each safe dig raises your multiplier — it only pays out when you bank' },
    { icon: '⚓', text: `Bank to lock your doubloons in and dive deeper. Depth ${MAX_DEPTH} is the wreck floor` },
    { icon: '🪝', text: 'The deeper you go, the more tiles you must turn over before the bank will open' },
    { icon: '💎', text: 'One ruby is buried in most depths, worth nine ordinary coins' },
    { icon: '🧿', text: 'Charms eat a curse outright — you carry fewer of them the higher you rank' },
  ]

  if (phase === 'info') return (
    <PreGameModal
      gameName={GAME_NAME}
      tagline="Dig deep. Bank early. Nobody does both."
      accent={ACCENT}
      icon={<Skull size={40} />}
      rules={rules}
      rankState={rankState}
      streakRequired={rankCfg.streakRequired}
      onStart={beginRun}
      onClose={onBack}
      autoStart={skipIntro}
      extraContent={<PlunderHatCard style={{ marginBottom: 20 }} />}
    />
  )

  if (phase === 'result' && result) return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <ResultScreen
        payload={result}
        accent={ACCENT}
        onReplay={() => { setResult(null); beginRun() }}
        onBack={onBack}
        promoted={promoted}
        sessionsLeft={sessionsLeft}
        sessionCost={sessionCost}
      />
    </div>
  )

  const hidden     = tiles.filter(t => !t.revealed).length
  const cursesLeft = tiles.filter(t => !t.revealed && t.kind === 'curse').length
  const risk       = hidden > 0 ? cursesLeft / hidden : 0
  const riskPct    = Math.round(risk * 100)
  const riskColor  = risk < 0.15 ? '#3ecf8e' : risk < 0.3 ? ACCENT : risk < 0.45 ? '#ff9a3c' : DANGER
  const payout     = Math.round(hold * mult)
  const atFloor    = depth >= MAX_DEPTH
  const need       = Math.max(0, minDigs(depth) - dugHere)
  const canBank    = phase === 'play' && hold > 0 && need === 0

  // The sea gets darker and colder the further down you go — the
  // background is the depth gauge.
  const shade = Math.min(depth - 1, 6)
  const seaTop = `hsl(198 ${58 - shade * 5}% ${13 - shade}%)`
  const seaMid = `hsl(205 ${52 - shade * 4}% ${8 - shade * 0.8}%)`

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', flex: 1, position: 'relative', overflow: 'hidden',
      background: `linear-gradient(180deg, ${seaTop} 0%, ${seaMid} 55%, #02060a 100%)`,
      transition: 'background 900ms ease',
    }}>
      <style>{`
        @keyframes pl-rise    { 0% { transform: translateY(0) scale(1); opacity: 0 } 12% { opacity: .5 } 100% { transform: translateY(-120vh) scale(1.5); opacity: 0 } }
        @keyframes pl-shaft   { 0%,100% { opacity: .05; transform: translateX(0) skewX(-14deg) } 50% { opacity: .12; transform: translateX(14px) skewX(-11deg) } }
        @keyframes pl-reveal  { 0% { transform: scale(1) } 45% { transform: scale(.82) } 100% { transform: scale(1) } }
        @keyframes pl-ring    { 0% { transform: scale(.4); opacity: .85 } 100% { transform: scale(2.1); opacity: 0 } }
        @keyframes pl-spin    { 0% { transform: rotateY(0) scale(.5); opacity: 0 } 60% { opacity: 1 } 100% { transform: rotateY(720deg) scale(1); opacity: 1 } }
        @keyframes pl-float   { 0% { transform: translate(-50%, 0) scale(.85); opacity: 0 } 18% { opacity: 1 } 100% { transform: translate(-50%, -70px) scale(1.15); opacity: 0 } }
        @keyframes pl-pop     { 0% { transform: translate(-50%,-50%) scale(.5); opacity: 0 } 35% { transform: translate(-50%,-50%) scale(1.15); opacity: 1 } 100% { transform: translate(-50%,-50%) scale(1); opacity: 0 } }
        @keyframes pl-shake   { 0%,100% { transform: translateX(0) } 15% { transform: translateX(-9px) } 35% { transform: translateX(8px) } 55% { transform: translateX(-6px) } 75% { transform: translateX(4px) } }
        @keyframes pl-flash   { 0% { opacity: 0 } 25% { opacity: .55 } 100% { opacity: 0 } }
        @keyframes pl-descend { 0% { transform: translateY(-26px); opacity: 0 } 100% { transform: translateY(0); opacity: 1 } }
        @keyframes pl-pulse   { 0%,100% { box-shadow: 0 0 0 0 ${ACCENT}00 } 50% { box-shadow: 0 0 22px 2px ${ACCENT}55 } }
        @keyframes pl-skullbob{ 0%,100% { transform: translateY(0) rotate(-3deg) } 50% { transform: translateY(-3px) rotate(3deg) } }
        @keyframes pl-burst   { 0% { transform: translate(-50%,-50%) scale(.4); opacity: 0 } 15% { opacity: 1 } 100% { transform: translate(calc(-50% + var(--bx)), calc(-50% + var(--by))) scale(.2); opacity: 0 } }
        @keyframes pl-sheen   { 0%,72% { transform: translateX(-140%) } 100% { transform: translateX(240%) } }
        @keyframes pl-glint   { 0%,60% { transform: translateX(-120%) } 100% { transform: translateX(220%) } }
        @keyframes pl-caustic { 0%,100% { transform: translate(-4%, 0) scale(1.06); opacity: .18 } 50% { transform: translate(4%, 12px) scale(1.14); opacity: .32 } }
        @keyframes pl-coinfly { 0% { transform: translate(0,0) scale(.5); opacity: 0 } 12% { opacity: 1 } 100% { transform: translate(var(--cx), var(--cy)) scale(1.1); opacity: 0 } }
        @keyframes pl-naughty-in    { 0% { transform: translate(-50%,-50%) scale(.45); opacity: 0 } 11% { transform: translate(-50%,-50%) scale(1.08); opacity: 1 } 19% { transform: translate(-50%,-50%) scale(1) } 80% { opacity: 1 } 100% { transform: translate(-50%,-54%) scale(.94); opacity: 0 } }
        @keyframes pl-naughty-shake { 0%,100% { transform: rotate(0) translateX(0) } 22% { transform: rotate(-3.5deg) translateX(-4px) } 48% { transform: rotate(3.5deg) translateX(4px) } 74% { transform: rotate(-2deg) translateX(-2px) } }
      `}</style>

      {/* Light shafts from the surface */}
      {[12, 44, 76].map((left, i) => (
        <div key={i} aria-hidden style={{
          position: 'absolute', top: -40, left: `${left}%`, width: 70, height: '75%',
          background: `linear-gradient(180deg, ${ACCENT}22, transparent 72%)`,
          filter: 'blur(16px)', pointerEvents: 'none',
          animation: `pl-shaft ${9 + i * 2.5}s ease-in-out ${i * 1.4}s infinite`,
        }} />
      ))}

      {/* Caustics — the ceiling of water, rippling. Two offset layers at
          different speeds so the pattern never visibly repeats. */}
      {[0, 1].map(i => (
        <div key={`c${i}`} aria-hidden style={{
          position: 'absolute', top: 0, left: '-10%', width: '120%', height: '46%',
          pointerEvents: 'none', mixBlendMode: 'screen',
          background: `repeating-radial-gradient(circle at ${30 + i * 40}% -20%, ${ACCENT}22 0 3px, transparent 3px 26px)`,
          filter: 'blur(7px)',
          animation: `pl-caustic ${13 + i * 6}s ease-in-out ${i * 3}s infinite`,
        }} />
      ))}

      {/* Seabed — a wrecked hull half-buried at the very bottom. Pure
          silhouette; it darkens as the dive deepens along with the water. */}
      <svg aria-hidden viewBox="0 0 400 90" preserveAspectRatio="none" style={{
        position: 'absolute', bottom: 0, left: 0, width: '100%', height: 92,
        pointerEvents: 'none', opacity: 0.5,
      }}>
        <path d="M0 90 L0 62 Q46 44 92 56 L118 40 L136 58 Q180 34 214 52 L232 30 L248 54 Q300 40 340 58 Q372 68 400 56 L400 90 Z" fill="#010407" />
        <path d="M232 30 L232 8 M232 14 L262 20 L232 26" stroke="#010407" strokeWidth="3" fill="none" />
      </svg>

      {/* Vignette — pulls the eye to the middle of the board */}
      <div aria-hidden style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(ellipse at 50% 42%, transparent 42%, rgba(0,0,0,0.5) 100%)',
      }} />

      {/* Bubbles */}
      {Array.from({ length: 11 }).map((_, i) => (
        <span key={i} aria-hidden style={{
          position: 'absolute', bottom: -20, left: `${5 + ((i * 37) % 90)}%`,
          width: 4 + (i % 4) * 3, height: 4 + (i % 4) * 3, borderRadius: '50%',
          background: 'rgba(180, 225, 255, 0.5)', pointerEvents: 'none',
          animation: `pl-rise ${11 + (i % 5) * 3.5}s linear ${i * 1.3}s infinite`,
        }} />
      ))}

      <GameHUD
        gameName={GAME_NAME}
        accent={ACCENT}
        icon={<Skull size={14} />}
        streak={rankState.currentStreak}
        onQuit={openQuit}
        extraRight={
          <div style={{ display: 'flex', gap: 6 }}>
            <StatChip label="Depth" value={`${depth}/${MAX_DEPTH}`} accent="#2ec4d6" />
            <StatChip label="Doubloons" value={shownTotal.toLocaleString()} accent={ACCENT} />
          </div>
        }
      />

      {/* Risk meter — the whole skill of the game is reading this line */}
      <div style={{ padding: '10px 16px 0', position: 'relative', zIndex: 1 }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          fontSize: 10, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase',
          color: 'rgba(255,255,255,0.42)', marginBottom: 6,
        }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: riskColor }}>
            <Skull size={11} /> {cursesLeft} in {hidden}
          </span>
          <span style={{ color: riskColor }}>{riskPct}% risk</span>
        </div>
        <div style={{
          height: 6, borderRadius: 4, background: 'rgba(255,255,255,0.07)', overflow: 'hidden',
        }}>
          <div style={{
            height: '100%', width: `${Math.min(100, riskPct * 2)}%`,
            background: `linear-gradient(90deg, ${riskColor}88, ${riskColor})`,
            boxShadow: `0 0 12px ${riskColor}88`,
            borderRadius: 4, transition: 'width 300ms ease, background 300ms ease',
          }} />
        </div>
      </div>

      {/* Hold + multiplier + charm */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        padding: '12px 16px 0', position: 'relative', zIndex: 1,
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '8px 14px', borderRadius: 14,
          background: `linear-gradient(150deg, ${ACCENT}1c, rgba(8,14,20,0.85))`,
          border: `1px solid ${hold > 0 ? `${ACCENT}66` : 'rgba(255,255,255,0.08)'}`,
          animation: hold > 0 ? 'pl-pulse 2.2s ease-in-out infinite' : undefined,
        }}>
          <Coins size={15} color={ACCENT} />
          <span style={{ fontSize: 18, fontWeight: 900, color: ACCENT, letterSpacing: 0.4 }}>
            {hold.toLocaleString()}
          </span>
          <span style={{
            fontSize: 11, fontWeight: 900, letterSpacing: 0.6,
            color: mult > 1 ? '#fff' : 'rgba(255,255,255,0.3)',
            padding: '3px 8px', borderRadius: 8,
            background: mult > 1 ? `${RUBY}44` : 'rgba(255,255,255,0.05)',
            border: `1px solid ${mult > 1 ? `${RUBY}88` : 'transparent'}`,
          }}>
            ×{mult.toFixed(2)}
          </span>
        </div>

        {charms > 0 && (
          <div title="Charm — eats one curse" style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '8px 11px', borderRadius: 14,
            background: 'rgba(46,196,214,0.13)', border: '1px solid rgba(46,196,214,0.45)',
            fontSize: 11, fontWeight: 900, color: '#2ec4d6', letterSpacing: 0.6,
          }}>
            <Gem size={13} /> {charms}
          </div>
        )}
      </div>

      {/* Banner / praise */}
      <div style={{
        height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', zIndex: 1, marginTop: 6,
      }}>
        <span style={{
          fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.44)', textAlign: 'center',
        }}>{banner}</span>
      </div>

      {/* Board */}
      <div style={{
        flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '4px 16px 12px', position: 'relative', zIndex: 1,
      }}>
        <div
          key={descendKey}
          style={{
            width: '100%', maxWidth: 400, position: 'relative',
            animation: phase === 'busted'
              ? 'pl-shake 0.45s ease-in-out'
              : 'pl-descend 420ms cubic-bezier(0.2, 0.9, 0.3, 1)',
          }}
        >
          <div style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${spec.cols}, 1fr)`,
            gap: spec.cols >= 5 ? 7 : 9,
          }}>
            {tiles.map((t, i) => {
              const isCurse = t.revealed && t.kind === 'curse' && !t.warded
              const isWard  = t.revealed && t.warded
              const isRuby  = t.revealed && t.kind === 'ruby'
              const face    = isCurse ? DANGER : isWard ? '#2ec4d6' : isRuby ? RUBY : ACCENT

              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => onTileTap(t.id)}
                  disabled={t.revealed || phase !== 'play'}
                  aria-label={t.revealed ? t.kind : 'buried tile'}
                  style={{
                    position: 'relative', aspectRatio: '1', padding: 0, borderRadius: 12,
                    overflow: 'hidden',
                    background: t.revealed
                      ? `linear-gradient(155deg, ${face}2e, rgba(4,9,14,0.94))`
                      : 'linear-gradient(155deg, #33465a, #1a2735 55%, #14202c)',
                    border: t.revealed
                      ? `1.5px solid ${face}99`
                      : '1px solid rgba(255,255,255,0.11)',
                    boxShadow: t.revealed
                      ? `0 0 16px ${face}44, inset 0 0 14px ${face}1f`
                      : 'inset 0 1px 0 rgba(255,255,255,0.09), 0 4px 10px rgba(0,0,0,0.45)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: t.revealed || phase !== 'play' ? 'default' : 'pointer',
                    WebkitTapHighlightColor: 'transparent',
                    transition: 'background 200ms ease, border-color 200ms ease, box-shadow 200ms ease',
                    animation: t.revealed ? 'pl-reveal 260ms ease' : undefined,
                  }}
                >
                  {/* Buried texture — sand ridges */}
                  {!t.revealed && (
                    <span aria-hidden style={{
                      position: 'absolute', inset: 0, opacity: 0.32,
                      background: 'repeating-linear-gradient(125deg, rgba(255,255,255,0.05) 0 2px, transparent 2px 7px)',
                    }} />
                  )}

                  {/* Sheen — a wet glint crossing the sand. Staggered by
                      column then row so it travels the board as a wave
                      rather than every tile flashing at once. */}
                  {!t.revealed && (
                    <span aria-hidden style={{
                      position: 'absolute', top: 0, bottom: 0, width: '55%',
                      background: 'linear-gradient(105deg, transparent, rgba(190,232,255,0.24), transparent)',
                      animation: `pl-sheen 5.5s ease-in-out ${((i % spec.cols) * 0.22 + Math.floor(i / spec.cols) * 0.4).toFixed(2)}s infinite`,
                    }} />
                  )}

                  {/* Reveal ring */}
                  {t.revealed && (
                    <span key={`r${t.id}`} aria-hidden style={{
                      position: 'absolute', left: '50%', top: '50%', width: '70%', height: '70%',
                      marginLeft: '-35%', marginTop: '-35%', borderRadius: '50%',
                      border: `2px solid ${face}`, animation: 'pl-ring 520ms ease-out forwards',
                    }} />
                  )}

                  {/* Loot burst — the tile actually throws something up when
                      you break it open. Curses and warded tiles get nothing:
                      the absence of this is half of what makes a curse land. */}
                  {t.revealed && !isCurse && !isWard && BURST.map(([bx, by], bi) => (
                    <span key={`b${t.id}-${bi}`} aria-hidden style={{
                      position: 'absolute', left: '50%', top: '50%',
                      width: isRuby ? 5 : 4, height: isRuby ? 5 : 4, borderRadius: '50%',
                      background: face, boxShadow: `0 0 7px ${face}`,
                      '--bx': `${bx}px`, '--by': `${by}px`,
                      animation: `pl-burst 640ms cubic-bezier(0.15,0.7,0.35,1) ${bi * 18}ms forwards`,
                    } as CSSProperties} />
                  ))}

                  {!t.revealed ? (
                    <span aria-hidden style={{
                      width: 7, height: 7, borderRadius: '50%',
                      background: 'rgba(255,255,255,0.16)',
                      boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.5)',
                    }} />
                  ) : isCurse ? (
                    <span style={{
                      display: 'flex', color: DANGER,
                      animation: 'pl-skullbob 1.6s ease-in-out infinite',
                      filter: `drop-shadow(0 0 8px ${DANGER}aa)`,
                    }}>
                      <Skull size={22} />
                    </span>
                  ) : isWard ? (
                    <span style={{ display: 'flex', color: '#2ec4d6', filter: 'drop-shadow(0 0 8px #2ec4d6aa)' }}>
                      <Gem size={20} />
                    </span>
                  ) : (
                    <span style={{
                      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
                      animation: `pl-spin 460ms ease-out ${(i % 3) * 20}ms both`,
                    }}>
                      <span style={{
                        position: 'relative', overflow: 'hidden',
                        width: isRuby ? 18 : 16, height: isRuby ? 18 : 16, borderRadius: '50%',
                        background: isRuby
                          ? `radial-gradient(circle at 32% 28%, #ffd0e2, ${RUBY} 62%, #a3134d)`
                          : `radial-gradient(circle at 32% 28%, #fff3c4, ${ACCENT} 58%, #b07d00)`,
                        boxShadow: `0 0 10px ${face}cc, inset 0 -1px 2px rgba(0,0,0,0.45)`,
                        border: `1px solid ${isRuby ? '#ffe0ee' : '#fff0b8'}66`,
                      }}>
                        <span aria-hidden style={{
                          position: 'absolute', top: 0, bottom: 0, width: '60%',
                          background: 'linear-gradient(100deg, transparent, rgba(255,255,255,0.9), transparent)',
                          animation: `pl-glint 2.6s ease-in-out ${(i % 5) * 0.3}s infinite`,
                        }} />
                      </span>
                      <span style={{
                        fontSize: 9, fontWeight: 900, color: face, letterSpacing: 0.2,
                      }}>{t.value}</span>
                    </span>
                  )}
                </button>
              )
            })}
          </div>

          {/* Floating payout */}
          {float && (
            <span key={float.key} style={{
              position: 'absolute', top: '38%', left: '50%', transform: 'translate(-50%, 0)',
              fontSize: 30, fontWeight: 900, color: float.color, pointerEvents: 'none',
              textShadow: `0 0 20px ${float.color}aa`, zIndex: 3,
              animation: 'pl-float 1s ease-out forwards',
            }}>{float.text}</span>
          )}

          {/* Praise pop */}
          {praise && (
            <span key={praise.key} style={{
              position: 'absolute', top: '50%', left: '50%',
              fontSize: 26, fontWeight: 900, letterSpacing: 1.5, color: '#fff',
              pointerEvents: 'none', zIndex: 3, textShadow: `0 0 24px ${ACCENT}`,
              animation: 'pl-pop 900ms ease-out forwards',
            }}>{praise.text}</span>
          )}
        </div>
      </div>

      {/* Bank bar */}
      <div style={{ padding: '0 16px 18px', position: 'relative', zIndex: 2 }}>
        <button
          type="button"
          onClick={() => { if (canBank) bank(hold, mult) }}
          disabled={!canBank}
          style={{
            width: '100%', padding: '15px 18px', borderRadius: 16, border: 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
            background: canBank
              ? `linear-gradient(135deg, ${ACCENT}, #e09b00)`
              : 'rgba(255,255,255,0.05)',
            color: canBank ? '#1a1200' : 'rgba(255,255,255,0.28)',
            fontSize: 15, fontWeight: 900, letterSpacing: 0.6,
            boxShadow: canBank ? `0 8px 26px ${ACCENT}44` : 'none',
            cursor: canBank ? 'pointer' : 'default',
            WebkitTapHighlightColor: 'transparent',
            transition: 'background 200ms ease, box-shadow 200ms ease, color 200ms ease',
            position: 'relative', overflow: 'hidden',
          }}
        >
          {canBank && (
            <span aria-hidden style={{
              position: 'absolute', top: 0, bottom: 0, width: '38%',
              background: 'linear-gradient(100deg, transparent, rgba(255,255,255,0.55), transparent)',
              animation: 'pl-sheen 3.2s ease-in-out infinite',
            }} />
          )}
          <Anchor size={17} />
          {canBank
            ? atFloor
              ? `Bank ${(payout + SURFACE_BONUS).toLocaleString()} & surface`
              : `Bank ${payout.toLocaleString()} & dive deeper`
            : `Dig ${need} more tile${need === 1 ? '' : 's'} to bank`}
        </button>
        {best > 0 && (
          <div style={{
            textAlign: 'center', marginTop: 10,
            fontSize: 10, fontWeight: 700, letterSpacing: 1.2,
            color: 'rgba(255,255,255,0.3)', textTransform: 'uppercase',
          }}>
            Best {best.toLocaleString()}
          </div>
        )}
      </div>

      {/* Full-screen flash — gold on a bank, pink on a ruby, red on a curse */}
      {flash && (
        <div key={flash.key} aria-hidden style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 4,
          background: `radial-gradient(circle at 50% 45%, ${flash.color}55, transparent 68%)`,
          animation: 'pl-flash 700ms ease-out forwards',
        }} />
      )}
      {phase === 'surfaced' && (
        <div aria-hidden style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 5,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: `radial-gradient(circle at 50% 45%, ${ACCENT}3a, rgba(2,6,10,0.82) 72%)`,
          animation: 'pl-descend 400ms ease-out',
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontSize: 13, fontWeight: 900, letterSpacing: 3, textTransform: 'uppercase',
              color: 'rgba(255,255,255,0.6)', marginBottom: 6,
            }}>You made it back up</div>
            <div style={{
              fontSize: 40, fontWeight: 900, color: ACCENT,
              textShadow: `0 0 34px ${ACCENT}aa`,
            }}>{totalRef.current.toLocaleString()}</div>
          </div>
        </div>
      )}
      {phase === 'busted' && (
        <div aria-hidden style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 4,
          background: `radial-gradient(circle at 50% 45%, transparent 32%, ${DANGER}55 100%)`,
          animation: 'pl-flash 1.3s ease-out forwards',
        }} />
      )}

      {/* Coin shower — banking throws the hold up toward the doubloon
          counter in the HUD, so the number going up has a cause you can
          see rather than just ticking on its own. */}
      {showerKey > 0 && (
        <div key={`sh${showerKey}`} aria-hidden style={{
          position: 'absolute', left: '50%', bottom: 96, pointerEvents: 'none', zIndex: 5,
        }}>
          {COIN_FLY.map(([cx, cy], ci) => (
            <span key={ci} style={{
              position: 'absolute', width: 11, height: 11, borderRadius: '50%',
              background: 'radial-gradient(circle at 32% 28%, #fff3c4, #ffcc2b 58%, #b07d00)',
              boxShadow: `0 0 9px ${ACCENT}bb`,
              '--cx': `${cx}px`, '--cy': `${cy}px`,
              animation: `pl-coinfly ${900 + (ci % 4) * 130}ms cubic-bezier(0.18,0.72,0.3,1) ${ci * 34}ms forwards`,
            } as CSSProperties} />
          ))}
        </div>
      )}

      {/* ─── Naughty ────────────────────────────────────────────────
          Fires when a depth has been stripped down to its last safe tile
          without the charm being spent. Deliberately small and centred on
          the board rather than a full-screen takeover: it's a wink at a
          greedy player mid-dive, not an interruption of one. */}
      {naughty && (
        <div key={naughty} aria-hidden style={{
          position: 'absolute', left: '50%', top: '46%',
          zIndex: 7, pointerEvents: 'none', textAlign: 'center',
          animation: 'pl-naughty-in 1900ms ease-out forwards',
        }}>
          {/* Two-layer backdrop: a dark core so "Naughty!" stays legible
              over a board full of lit gold tiles, and a gold bloom on top of
              it. Both are contained circles rather than a full-screen scrim —
              the dive stays visible around the pop. */}
          <div style={{
            position: 'absolute', left: '50%', top: '44%',
            width: 300, height: 300, marginLeft: -150, marginTop: -150,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(2,6,10,0.88) 0%, rgba(2,6,10,0.62) 40%, transparent 70%)',
          }} />
          <div style={{
            position: 'absolute', left: '50%', top: '42%',
            width: 260, height: 260, marginLeft: -130, marginTop: -130,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${ACCENT}3a 0%, ${ACCENT}14 42%, transparent 70%)`,
          }} />
          <img
            src={PIRATE_SRC}
            alt=""
            style={{
              position: 'relative', display: 'block',
              width: 148, height: 148, objectFit: 'contain',
              filter: `drop-shadow(0 8px 18px rgba(0,0,0,0.65)) drop-shadow(0 0 16px ${ACCENT}77)`,
              animation: 'pl-naughty-shake 320ms ease-in-out 3',
            }}
          />
          <div style={{
            position: 'relative', marginTop: -2,
            fontSize: 30, fontWeight: 900, letterSpacing: 1.6, color: '#fff',
            textShadow: `0 2px 0 #7d5200, 0 0 20px ${ACCENT}, 0 0 40px ${ACCENT}66`,
          }}>
            Naughty!
          </div>
        </div>
      )}

      {phase === 'paused' && <QuitModal onConfirm={onBack} onCancel={() => setPhase('play')} />}
    </div>
  )
}
