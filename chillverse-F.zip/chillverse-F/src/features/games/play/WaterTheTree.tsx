// src/features/games/play/WaterTheTree.tsx
// "The Grove" is a standalone HTML/JS game, same iframe-via-srcDoc approach
// as Ludo.tsx (see that file for why srcDoc rather than a static asset URL).
//
// The game itself has no access to Supabase or the logged-in user -- it's a
// sandboxed iframe. This wrapper is the bridge: it holds the real session,
// answers the game's postMessage requests (init / water / refresh) by
// calling Supabase, and relays results back down. See water_the_grove() and
// get_grove_top_gardeners() in the database for the server-side logic.
import { useCallback, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { useAuth } from '../../auth/useAuth'
import { useProfile } from '../../profile/useProfile'
import { supabase } from '../../../shared/lib/supabase'
// eslint-disable-next-line import/no-unresolved
import waterTheTreeHtml from './water-the-tree.html?raw'

type GroveRequest =
  | { type: 'grove:ready' }
  | { type: 'grove:water' }
  | { type: 'grove:refresh' }

export default function WaterTheTree() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { profile } = useProfile()
  const iframeRef = useRef<HTMLIFrameElement>(null)

  const post = useCallback((message: unknown) => {
    iframeRef.current?.contentWindow?.postMessage(message, '*')
  }, [])

  const fetchSharedState = useCallback(async () => {
    const [{ data: state }, { data: gardeners }] = await Promise.all([
      supabase.from('grove_state').select('*').eq('id', 1).single(),
      supabase.rpc('get_grove_top_gardeners', { p_limit: 5 }),
    ])
    return { state, gardeners: gardeners ?? [] }
  }, [])

  useEffect(() => {
    async function handleMessage(e: MessageEvent<GroveRequest>) {
      if (e.source !== iframeRef.current?.contentWindow) return
      if (!e.data || typeof e.data !== 'object') return

      if (e.data.type === 'grove:ready') {
        const { state, gardeners } = await fetchSharedState()
        let myContribution = null
        if (user) {
          const { data } = await supabase.from('grove_contributions').select('*').eq('user_id', user.id).maybeSingle()
          myContribution = data
        }
        post({
          type: 'grove:init',
          user: user ? { id: user.id, name: profile?.display_name || profile?.username || 'a quiet gardener' } : null,
          state, gardeners, myContribution,
        })
        return
      }

      if (e.data.type === 'grove:water') {
        if (!user) { post({ type: 'grove:water:result', error: 'not_authenticated' }); return }
        const { data, error } = await supabase.rpc('water_the_grove')
        if (error) { post({ type: 'grove:water:result', error: error.message }); return }
        const { gardeners } = await fetchSharedState()
        post({ type: 'grove:water:result', result: data, gardeners })
        return
      }

      if (e.data.type === 'grove:refresh') {
        const { state, gardeners } = await fetchSharedState()
        post({ type: 'grove:refresh:result', state, gardeners })
      }
    }

    window.addEventListener('message', handleMessage)
    return () => window.removeEventListener('message', handleMessage)
  }, [user, profile, post, fetchSharedState])

  return createPortal(
    <div style={{ position: 'fixed', inset: 0, zIndex: 500, background: '#070c09' }}>
      <button
        type="button"
        // Was navigate('/multiplayer') — since Grove is reached by pushing
        // this route onto history (see Multiplayer.tsx), that pushed a
        // *second* /multiplayer entry instead of popping back to the
        // existing one, so the hardware/browser back button would then
        // bounce forward into Grove again. navigate(-1) pops properly,
        // same pattern Multiplayer.tsx itself uses to close.
        onClick={() => navigate(-1)}
        style={{
          position: 'absolute', top: 14, left: 14, zIndex: 10,
          width: 36, height: 36, borderRadius: 10, background: 'rgba(0,0,0,0.5)',
          border: '1px solid rgba(232,196,104,0.25)', backdropFilter: 'blur(6px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#EDE7D9', cursor: 'pointer',
        }}
      >
        <ArrowLeft size={16} />
      </button>
      <iframe
        ref={iframeRef}
        title="The Grove -- Water the Tree"
        srcDoc={waterTheTreeHtml}
        style={{ width: '100%', height: '100%', border: 'none' }}
        sandbox="allow-scripts allow-same-origin"
      />
    </div>,
    document.body
  )
}
