// src/features/games/play/ChillLink.tsx
// ─── Chill Link ───────────────────────────────────────────────
// Link the pair. Clear the board.
//
// Loop: a board of paired tiles → tap two matching tiles → they clear if
// a path connects them with at most two turns → clear the whole board to
// bank it and move to a bigger one. One run clock for everything, so the
// pressure is on how fast you can read the board, not on memory.
//
// Every timed transition is driven by a `useEffect` keyed on the phase
// rather than a chain of setTimeouts held in refs. React StrictMode
// (which main.tsx turns on) mounts, unmounts and remounts on the first
// render, and a ref-held timer chain gets wiped by the unmount cleanup
// and never restarts. Effects simply re-run, so the chain heals itself.
import { useState, useRef, useEffect, useCallback } from 'react'
import { Link2, Shuffle } from 'lucide-react'
import type { GameRank, GameEndPayload } from './types'
import { getRankConfig } from './types'
import { useGamePresence } from '../useGamePresence'
import { useAuth } from '../../auth/useAuth'
import { supabase } from '../../../shared/lib/supabase'
import { PreGameModal, GameHUD, StatChip, ResultScreen, QuitModal, TimerBar, useRankStreak } from './GameShell'
import { playTileMatch, playBoardClear, playWrongCard } from '../sfx'

const GAME_ID   = 'chill-link' as const
const GAME_NAME = 'Chill Link'
const ACCENT    = '#f59e0b'
const LINK      = '#ffd45e'   // the connecting line — brighter than the accent

// ─── Tile pool ────────────────────────────────────────────────
// Deliberately emoji rather than art: it keeps the game weightless, it
// themes instantly, and there is no licensed sprite sheet to answer for.
const TILE_POOL = [
  '🍉', '🍒', '🍌', '🍓', '🥑', '🍕', '🍩', '🍪', '🧋', '🍇', '🥥',
  '🍍', '🥝', '🍑', '🧊', '🎧', '🎮', '⚡', '💎', '🌸', '🔥', '🌶️',
]

// ─── Board curve ──────────────────────────────────────────────
// Cell counts are always even — every tile needs a partner. Columns stay
// at or under 6 so a phone never has to render a tile smaller than a
// comfortable tap target.
interface BoardSpec { cols: number; rows: number; kinds: number }
function boardSpec(b: number): BoardSpec {
  if (b <= 1) return { cols: 4, rows: 4, kinds: 6 }   // 16
  if (b === 2) return { cols: 5, rows: 4, kinds: 7 }  // 20
  if (b === 3) return { cols: 6, rows: 4, kinds: 8 }  // 24
  if (b === 4) return { cols: 6, rows: 5, kinds: 9 }  // 30
  if (b === 5) return { cols: 6, rows: 6, kinds: 11 } // 36
  return { cols: 6, rows: 6, kinds: 14 }              // 36, but far busier
}

// ─── Clock ────────────────────────────────────────────────────
// One run clock rather than a per-board timer: clearing a board tops it
// back up, so a good run extends itself and a bad one simply runs out.
const CLOCK_CAP = 95
function startSecForRank(rank: GameRank): number {
  return rank === 'beginner' ? 70 : rank === 'intermediate' ? 65 : rank === 'advanced' ? 60 : 55
}
function boardBonusSec(b: number): number {
  return Math.max(16, 26 - b * 2)
}

// Higher ranks start further along the same curve instead of getting a
// separate one, so the tuning above only has to hold in one place.
const RANK_OFFSET: Record<GameRank, number> = {
  beginner: 0, intermediate: 1, advanced: 2, master: 3,
}

// From intermediate up a bad pair costs time as well as the combo. It is
// the only rule that changes, and it is the one that stops players from
// tapping their way through a board at random.
const HARD_RANKS: GameRank[] = ['intermediate', 'advanced', 'master']
function isHardRank(rank: GameRank): boolean { return HARD_RANKS.includes(rank) }
const WRONG_PENALTY_SEC = 2

const COMBO_WINDOW_MS = 4000
const COMBO_CAP       = 8
const SHUFFLES_PER_RUN = 2

// ─── XP ───────────────────────────────────────────────────────
// Sits between Elementa and The Last Samurai — this one costs 3 sessions,
// so a full run has to be worth the spend. Still capped so a long run
// can't run away with the XP ladder.
const XP_CAP = 200
function xpForRun(pairs: number, boards: number): number {
  if (pairs <= 0) return 0
  return Math.min(XP_CAP, pairs * 3 + boards * 25)
}

const PRAISE = ['Linked!', 'Clean line!', 'Nice read!', 'Snap!', 'Chained it!']

// ─── Tiles ────────────────────────────────────────────────────
interface Tile {
  id: number
  emoji: string
  idx: number      // y * cols + x
}

interface Pt { x: number; y: number }

function shuffleArr<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/** Build a full board: every emoji placed an even number of times, then
 *  scattered across every cell. Boards always start completely full. */
function buildBoard(b: number): { tiles: Tile[]; spec: BoardSpec } {
  const spec  = boardSpec(b)
  const cells = spec.cols * spec.rows
  const pairs = cells / 2
  const kinds = Math.min(spec.kinds, TILE_POOL.length)
  const chosen = shuffleArr(TILE_POOL).slice(0, kinds)

  // Every kind gets at least one pair, the rest are spread at random —
  // that's what produces the "four of the same fruit" texture instead of
  // a board where every tile is unique.
  const faces: string[] = []
  for (let i = 0; i < pairs; i++) {
    const emoji = i < kinds ? chosen[i] : chosen[Math.floor(Math.random() * kinds)]
    faces.push(emoji, emoji)
  }

  const order = shuffleArr(faces)
  return {
    spec,
    tiles: order.map((emoji, i) => ({ id: i, emoji, idx: i })),
  }
}

// ─── Path finding ─────────────────────────────────────────────
// The classic connect rule: a link is legal if it can be drawn through
// empty space with at most two turns. The search runs over a grid with
// one extra ring of always-empty cells around it, which is what lets a
// path route around the outside edge of the board.
//
// It is done as up to three straight segments rather than a generic BFS,
// because the segments themselves are the polyline we draw on screen.
function findPath(
  occupied: Map<number, string>, cols: number, rows: number, a: Pt, b: Pt,
): Pt[] | null {
  const inExtended = (x: number, y: number) => x >= -1 && x <= cols && y >= -1 && y <= rows
  const isOutside  = (x: number, y: number) => x < 0 || x >= cols || y < 0 || y >= rows
  const isEmpty    = (x: number, y: number) => isOutside(x, y) || !occupied.has(y * cols + x)
  const isEnd      = (x: number, y: number) => x === b.x && y === b.y

  const DIRS: Pt[] = [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }]

  /** Walk in one direction until blocked. Returns the empty cells passed
   *  through, and whether the walk ran into the destination tile. */
  function walk(from: Pt, d: Pt): { cells: Pt[]; hit: boolean } {
    const cells: Pt[] = []
    let x = from.x + d.x
    let y = from.y + d.y
    while (inExtended(x, y)) {
      if (isEnd(x, y)) return { cells, hit: true }
      if (!isEmpty(x, y)) break
      cells.push({ x, y })
      x += d.x
      y += d.y
    }
    return { cells, hit: false }
  }

  const perpendicular = (d: Pt) => DIRS.filter(o => o.x !== d.x || o.y !== d.y)
    .filter(o => (d.x === 0 ? o.y === 0 : o.x === 0))

  for (const d1 of DIRS) {
    const leg1 = walk(a, d1)
    if (leg1.hit) return [a, b]                       // 0 turns

    for (const c1 of leg1.cells) {
      for (const d2 of perpendicular(d1)) {
        const leg2 = walk(c1, d2)
        if (leg2.hit) return [a, c1, b]               // 1 turn

        for (const c2 of leg2.cells) {
          for (const d3 of perpendicular(d2)) {
            if (walk(c2, d3).hit) return [a, c1, c2, b] // 2 turns
          }
        }
      }
    }
  }
  return null
}

/** Is there any legal move left? Used to auto-reshuffle a dead board
 *  rather than letting the clock drain on something unplayable. */
function hasAnyMove(tiles: Tile[], cols: number, rows: number): boolean {
  const occupied = new Map(tiles.map(t => [t.idx, t.emoji]))
  for (let i = 0; i < tiles.length; i++) {
    for (let j = i + 1; j < tiles.length; j++) {
      if (tiles[i].emoji !== tiles[j].emoji) continue
      const a = { x: tiles[i].idx % cols, y: Math.floor(tiles[i].idx / cols) }
      const b = { x: tiles[j].idx % cols, y: Math.floor(tiles[j].idx / cols) }
      if (findPath(occupied, cols, rows, a, b)) return true
    }
  }
  return false
}

/** Redeal the surviving tiles across the cells they already occupy. Tries
 *  a few times to land on an arrangement that actually has a move in it. */
function reshuffle(tiles: Tile[], cols: number, rows: number): Tile[] {
  const slots = tiles.map(t => t.idx)
  for (let attempt = 0; attempt < 12; attempt++) {
    const order = shuffleArr(slots)
    const next  = tiles.map((t, i) => ({ ...t, idx: order[i] }))
    if (hasAnyMove(next, cols, rows)) return next
  }
  return tiles.map((t, i) => ({ ...t, idx: shuffleArr(slots)[i] }))
}

interface Props {
  rank: GameRank
  streak?: number
  onEnd: (payload: GameEndPayload) => void
  onBack: () => void
  sessionsLeft?: number
  sessionCost?: number
  skipIntro?: boolean
}

type Phase = 'info' | 'play' | 'boardClear' | 'paused' | 'result'

export default function ChillLink({
  rank: initialRank, streak: initialStreak = 0, onEnd, onBack, sessionsLeft = 99, sessionCost = 3, skipIntro,
}: Props) {
  const [phase, setPhase] = useState<Phase>('info')
  useGamePresence(GAME_ID)
  const { rankState, onCorrect, onWrong } = useRankStreak(GAME_ID, initialRank, initialStreak)
  const { session } = useAuth()

  const [tiles, setTiles]   = useState<Tile[]>([])
  const [spec, setSpec]     = useState<BoardSpec>(boardSpec(1))
  const [board, setBoard]   = useState(1)
  const [score, setScore]   = useState(0)
  const [combo, setCombo]   = useState(1)
  const [best, setBest]     = useState(0)
  const [timeLeft, setTimeLeft]   = useState(70)
  const [shuffles, setShuffles]   = useState(SHUFFLES_PER_RUN)
  const [selected, setSelected]   = useState<number | null>(null)
  const [wrongIds, setWrongIds]   = useState<number[]>([])
  const [link, setLink]     = useState<{ pts: Pt[]; key: number } | null>(null)
  const [banner, setBanner] = useState('')
  const [praise, setPraise] = useState<{ text: string; key: number } | null>(null)
  const [floatScore, setFloatScore] = useState<{ text: string; key: number } | null>(null)
  const [promoted, setPromoted]     = useState<GameRank | null>(null)
  const [result, setResult]         = useState<GameEndPayload | null>(null)
  const [boardW, setBoardW]         = useState(340)

  const scoreRef     = useRef(0)
  const comboRef     = useRef(1)
  const bestComboRef = useRef(1)
  const pairsRef     = useRef(0)
  const boardsRef    = useRef(0)
  const lastMatchRef = useRef(0)
  const startRef     = useRef(Date.now())
  const endedRef     = useRef(false)
  const boardElRef   = useRef<HTMLDivElement | null>(null)

  // ── Board sizing — the tile grid is absolutely positioned so the link
  //    overlay can be drawn over real pixel coordinates, which means the
  //    cell size has to be a measured number, not a percentage ──
  useEffect(() => {
    const el = boardElRef.current
    if (!el) return
    const measure = () => setBoardW(el.clientWidth)
    measure()
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', measure)
      return () => window.removeEventListener('resize', measure)
    }
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [phase, spec.cols, spec.rows])

  // ── Personal best, for the HUD and the game-over card ──
  useEffect(() => {
    const uid = session?.user?.id
    if (!uid) return
    supabase
      .from('game_sessions')
      .select('score')
      .eq('user_id', uid)
      .eq('game', 'chill_link')
      .order('score', { ascending: false })
      .limit(1)
      .maybeSingle<{ score: number }>()
      .then(({ data }) => { if (data?.score) setBest(data.score) }, () => {})
  }, [session?.user?.id])

  // ── Run clock ──
  // Only ever ticks during 'play', so the quit modal and the between-board
  // beat both genuinely pause it.
  useEffect(() => {
    if (phase !== 'play') return
    const id = setInterval(() => setTimeLeft(t => Math.max(0, t - 1)), 1000)
    return () => clearInterval(id)
  }, [phase])

  const finishRun = useCallback(() => {
    if (endedRef.current) return
    endedRef.current = true

    const dur     = Math.floor((Date.now() - startRef.current) / 1000)
    const pairs   = pairsRef.current
    const boards  = boardsRef.current
    const final   = scoreRef.current
    const xp      = xpForRun(pairs, boards)
    const newBest = Math.max(best, final)
    if (final > best) setBest(final)

    const payload: GameEndPayload = {
      gameId: GAME_ID,
      gameName: GAME_NAME,
      rank: rankState.rank,
      score: final,
      xpEarned: xp,
      durationSec: dur,
      streak: rankState.bestStreak,
      correct: pairs,
      total: Math.max(pairs, 1),
      detail: {
        'Boards Cleared': boards,
        'Pairs Linked': pairs,
        'Best Combo': `×${bestComboRef.current}`,
        'Personal Best': newBest.toLocaleString(),
      },
    }

    if (boards >= 1) {
      const { promoted: promo } = onCorrect(getRankConfig(rankState.rank).streakRequired)
      if (promo) setPromoted(promo)
    } else {
      onWrong()
    }

    setResult(payload)
    setPhase('result')
    onEnd(payload)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [best, rankState.rank, rankState.bestStreak])

  // Ending is watched rather than done inside the interval's state updater —
  // a setState callback is not the place to fire a run's worth of side effects.
  useEffect(() => {
    if (phase !== 'play' || timeLeft > 0) return
    setBanner("Time's up")
    finishRun()
  }, [phase, timeLeft, finishRun])

  // ── Board cleared → short beat → next board ──
  useEffect(() => {
    if (phase !== 'boardClear') return
    const t = setTimeout(() => {
      const next = board + 1
      setBoard(next)
      const built = buildBoard(next + RANK_OFFSET[rankState.rank])
      setTiles(built.tiles)
      setSpec(built.spec)
      setSelected(null)
      setLink(null)
      setPraise(null)
      setFloatScore(null)
      setBanner('')
      setPhase('play')
    }, 1000)
    return () => clearTimeout(t)
  }, [phase, board, rankState.rank])

  // ── Link line fades on its own ──
  useEffect(() => {
    if (!link) return
    const t = setTimeout(() => setLink(null), 420)
    return () => clearTimeout(t)
  }, [link])

  // ── Wrong-pair flash clears itself ──
  useEffect(() => {
    if (wrongIds.length === 0) return
    const t = setTimeout(() => setWrongIds([]), 380)
    return () => clearTimeout(t)
  }, [wrongIds])

  function beginRun() {
    endedRef.current  = false
    scoreRef.current  = 0
    comboRef.current  = 1
    bestComboRef.current = 1
    pairsRef.current  = 0
    boardsRef.current = 0
    lastMatchRef.current = 0
    startRef.current  = Date.now()

    const built = buildBoard(1 + RANK_OFFSET[rankState.rank])
    setTiles(built.tiles)
    setSpec(built.spec)
    setBoard(1)
    setScore(0)
    setCombo(1)
    setTimeLeft(startSecForRank(rankState.rank))
    setShuffles(SHUFFLES_PER_RUN)
    setSelected(null)
    setLink(null)
    setWrongIds([])
    setPraise(null)
    setFloatScore(null)
    setBanner('Link a pair')
    setPromoted(null)
    setResult(null)
    setPhase('play')
  }

  // Quitting pauses the clock outright rather than letting it drain behind
  // the modal.
  function openQuit() {
    if (phase === 'result') return
    setPhase('paused')
  }

  function doShuffle(free: boolean) {
    setTiles(prev => reshuffle(prev, spec.cols, spec.rows))
    setSelected(null)
    if (!free) setShuffles(s => Math.max(0, s - 1))
    setBanner(free ? 'No moves left — reshuffled' : 'Reshuffled')
  }

  function onTileTap(id: number) {
    if (phase !== 'play') return
    const tile = tiles.find(t => t.id === id)
    if (!tile) return

    // Tapping the selected tile again just lets it go.
    if (selected === id) { setSelected(null); return }

    if (selected === null) {
      setSelected(id)
      return
    }

    const first = tiles.find(t => t.id === selected)
    if (!first) { setSelected(id); return }

    const occupied = new Map(tiles.map(t => [t.idx, t.emoji]))
    const a = { x: first.idx % spec.cols, y: Math.floor(first.idx / spec.cols) }
    const b = { x: tile.idx  % spec.cols, y: Math.floor(tile.idx  / spec.cols) }
    const path = first.emoji === tile.emoji
      ? findPath(occupied, spec.cols, spec.rows, a, b)
      : null

    // ── No link ──
    if (!path) {
      playWrongCard()
      setWrongIds([first.id, tile.id])
      setSelected(null)
      comboRef.current = 1
      setCombo(1)
      if (isHardRank(rankState.rank)) {
        setTimeLeft(t => Math.max(0, t - WRONG_PENALTY_SEC))
        setBanner(`No link — −${WRONG_PENALTY_SEC}s`)
      } else {
        setBanner('No link there')
      }
      return
    }

    // ── Linked ──
    const now = Date.now()
    const inWindow = lastMatchRef.current > 0 && now - lastMatchRef.current <= COMBO_WINDOW_MS
    comboRef.current = inWindow ? Math.min(COMBO_CAP, comboRef.current + 1) : 1
    lastMatchRef.current = now
    bestComboRef.current = Math.max(bestComboRef.current, comboRef.current)
    setCombo(comboRef.current)

    const gained = 60 * comboRef.current
    scoreRef.current += gained
    pairsRef.current += 1
    setScore(scoreRef.current)

    playTileMatch()
    setLink({ pts: path, key: now })
    setFloatScore({ text: `+${gained}`, key: now })
    if (comboRef.current > 1) {
      setPraise({ text: PRAISE[Math.floor(Math.random() * PRAISE.length)], key: now })
    }
    setBanner('')
    setSelected(null)

    const remaining = tiles.filter(t => t.id !== first.id && t.id !== tile.id)
    setTiles(remaining)

    // ── Board cleared ──
    if (remaining.length === 0) {
      const bonus = 250 * board
      scoreRef.current += bonus
      boardsRef.current += 1
      setScore(scoreRef.current)
      setTimeLeft(t => Math.min(CLOCK_CAP, t + boardBonusSec(board)))
      playBoardClear()
      setBanner(`Board ${board} cleared  +${boardBonusSec(board)}s`)
      setPhase('boardClear')
      return
    }

    // ── Dead board → free reshuffle ──
    if (!hasAnyMove(remaining, spec.cols, spec.rows)) doShuffle(true)
  }

  // ── Render ──
  const rankCfg = getRankConfig(rankState.rank)
  const rules = [
    { icon: '🔗', text: 'Tap two matching tiles to link them away' },
    { icon: '📐', text: 'The link can bend twice — and it can route around the board edge' },
    { icon: '🧹', text: 'Clear the whole board to bank it and top your clock back up' },
    { icon: '⚡', text: 'Link fast, back to back, to build a combo multiplier' },
    { icon: '🔀', text: `${SHUFFLES_PER_RUN} shuffles per run — a dead board reshuffles free` },
    { icon: '⏳', text: 'From Intermediate: a bad pair costs you 2 seconds' },
  ]

  if (phase === 'info') return (
    <PreGameModal
      gameName={GAME_NAME}
      tagline="Link the pair. Clear the board."
      accent={ACCENT}
      icon={<Link2 size={40} />}
      rules={rules}
      rankState={rankState}
      streakRequired={rankCfg.streakRequired}
      onStart={beginRun}
      onClose={onBack}
      autoStart={skipIntro}
    />
  )

  if (phase === 'result' && result) return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <ResultScreen
        payload={result}
        accent={ACCENT}
        onReplay={() => { setResult(null); beginRun() }}
        onBack={onBack}
        promoted={promoted}
        sessionsLeft={sessionsLeft}
        sessionCost={sessionCost}
      />
    </div>
  )

  const gap    = spec.cols >= 6 ? 6 : 8
  const cell   = Math.max(40, Math.floor((boardW - gap * (spec.cols - 1)) / spec.cols))
  const boardH = spec.rows * cell + (spec.rows - 1) * gap
  const startSec = startSecForRank(rankState.rank)
  const pct    = Math.max(0, Math.min(100, (timeLeft / Math.max(startSec, CLOCK_CAP)) * 100))
  const center = (p: Pt) => ({
    cx: p.x * (cell + gap) + cell / 2,
    cy: p.y * (cell + gap) + cell / 2,
  })

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', flex: 1, position: 'relative', overflow: 'hidden',
      background: 'linear-gradient(180deg, #0b1016 0%, #101823 55%, #16120b 100%)',
    }}>
      <style>{`
        @keyframes cl-pop  { 0% { transform: scale(.7); opacity: 0 } 40% { transform: scale(1.06); opacity: 1 } 100% { transform: scale(1); opacity: 1 } }
        @keyframes cl-rise { 0% { transform: translate(-50%, 0) scale(.9); opacity: 0 } 20% { opacity: 1 } 100% { transform: translate(-50%, -44px) scale(1.1); opacity: 0 } }
        @keyframes cl-shake { 0%,100% { transform: translateX(0) } 25% { transform: translateX(-4px) } 75% { transform: translateX(4px) } }
        @keyframes cl-draw { from { stroke-dashoffset: 400 } to { stroke-dashoffset: 0 } }
        @keyframes cl-drift { 0% { transform: translateY(0) } 50% { transform: translateY(-14px) } 100% { transform: translateY(0) } }
      `}</style>

      {/* Warm glow behind the board */}
      <div aria-hidden style={{
        position: 'absolute', top: '10%', left: '50%', transform: 'translateX(-50%)',
        width: 260, height: 260, borderRadius: '50%',
        background: `radial-gradient(circle, ${ACCENT}33, transparent 70%)`,
        filter: 'blur(26px)', pointerEvents: 'none',
      }} />

      {/* Drifting tiles in the background — quiet, just enough motion */}
      {['🍒', '🧊', '🍇', '💎'].map((e, i) => (
        <span key={i} aria-hidden style={{
          position: 'absolute', top: `${18 + i * 19}%`, left: `${6 + i * 25}%`,
          fontSize: 20, opacity: 0.08, pointerEvents: 'none',
          animation: `cl-drift ${7 + i * 1.6}s ease-in-out ${i * 0.8}s infinite`,
        }}>{e}</span>
      ))}

      <GameHUD
        gameName={GAME_NAME}
        accent={ACCENT}
        icon={<Link2 size={14} />}
        streak={rankState.currentStreak}
        onQuit={openQuit}
        extraRight={
          <div style={{ display: 'flex', gap: 6 }}>
            <StatChip label="Board" value={board} accent={ACCENT} />
            <StatChip label="Score" value={score.toLocaleString()} accent={LINK} />
          </div>
        }
      />

      {/* Clock */}
      <div style={{ padding: '10px 16px 0', position: 'relative', zIndex: 1 }}>
        <TimerBar pct={pct} accent={ACCENT} urgent secondsLeft={timeLeft} />
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginTop: 8, fontSize: 11, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase',
        }}>
          <span style={{ color: timeLeft <= 10 ? 'var(--red)' : 'rgba(255,255,255,0.5)' }}>
            {timeLeft}s
          </span>
          <span style={{ color: combo > 1 ? LINK : 'rgba(255,255,255,0.32)' }}>Combo ×{combo}</span>
          <button
            type="button"
            onClick={() => { if (shuffles > 0 && phase === 'play') doShuffle(false) }}
            disabled={shuffles === 0 || phase !== 'play'}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              padding: '5px 10px', borderRadius: 20,
              background: shuffles > 0 ? `${ACCENT}1f` : 'rgba(255,255,255,0.05)',
              border: `1px solid ${shuffles > 0 ? `${ACCENT}55` : 'rgba(255,255,255,0.08)'}`,
              color: shuffles > 0 ? ACCENT : 'rgba(255,255,255,0.28)',
              fontSize: 10, fontWeight: 800, letterSpacing: 1,
              cursor: shuffles > 0 ? 'pointer' : 'default',
              WebkitTapHighlightColor: 'transparent',
            }}
          >
            <Shuffle size={11} /> {shuffles}
          </button>
        </div>
      </div>

      {/* Banner / praise */}
      <div style={{
        height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', zIndex: 1,
      }}>
        {praise ? (
          <span key={praise.key} style={{ fontSize: 13, fontWeight: 800, color: LINK, animation: 'cl-pop 0.3s ease' }}>
            {praise.text}
          </span>
        ) : (
          <span style={{ fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.42)' }}>{banner}</span>
        )}
      </div>

      {/* Board */}
      <div style={{
        flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '8px 16px 24px', position: 'relative', zIndex: 1,
      }}>
        <div style={{ width: '100%', maxWidth: 400, position: 'relative' }}>
          <div ref={boardElRef} style={{ position: 'relative', width: '100%', height: boardH }}>
            {tiles.map(t => {
              const x = t.idx % spec.cols
              const y = Math.floor(t.idx / spec.cols)
              const isSel   = selected === t.id
              const isWrong = wrongIds.includes(t.id)
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => onTileTap(t.id)}
                  aria-label={t.emoji}
                  style={{
                    position: 'absolute', width: cell, height: cell, left: 0, top: 0,
                    transform: `translate(${x * (cell + gap)}px, ${y * (cell + gap)}px)`,
                    transition: 'transform 220ms cubic-bezier(0.4, 0, 0.2, 1)',
                    padding: 0, borderRadius: 12,
                    background: isSel
                      ? `linear-gradient(160deg, ${ACCENT}44, rgba(20,24,34,0.95))`
                      : 'linear-gradient(160deg, rgba(244,246,252,0.96), rgba(214,220,233,0.96))',
                    border: isWrong ? '2px solid var(--red)'
                      : isSel ? `2px solid ${LINK}` : '1px solid rgba(255,255,255,0.5)',
                    boxShadow: isSel
                      ? `0 0 18px ${LINK}88, inset 0 0 12px ${LINK}33`
                      : '0 3px 8px rgba(0,0,0,0.4)',
                    animation: isWrong ? 'cl-shake 0.16s ease-in-out 2' : undefined,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: Math.max(18, cell * 0.5), lineHeight: 1,
                    cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
                  }}
                >
                  {t.emoji}
                </button>
              )
            })}

            {/* Link line — drawn over the board, allowed to spill past the
                edge because a legal path can route around the outside. */}
            {link && (
              <svg
                key={link.key}
                aria-hidden
                style={{
                  position: 'absolute', left: -(cell + gap), top: -(cell + gap),
                  width: boardW + (cell + gap) * 2, height: boardH + (cell + gap) * 2,
                  pointerEvents: 'none', overflow: 'visible',
                }}
              >
                <polyline
                  points={link.pts.map(p => {
                    const c = center(p)
                    return `${c.cx + cell + gap},${c.cy + cell + gap}`
                  }).join(' ')}
                  fill="none"
                  stroke={LINK}
                  strokeWidth={4}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray={400}
                  style={{
                    filter: `drop-shadow(0 0 8px ${LINK})`,
                    animation: 'cl-draw 0.18s ease-out forwards',
                  }}
                />
              </svg>
            )}
          </div>

          {floatScore && (
            <span key={floatScore.key} style={{
              position: 'absolute', top: '40%', left: '50%', transform: 'translate(-50%, 0)',
              fontSize: 24, fontWeight: 900, color: LINK, pointerEvents: 'none',
              textShadow: `0 0 16px ${LINK}88`, animation: 'cl-rise 0.85s ease-out forwards',
            }}>{floatScore.text}</span>
          )}
        </div>
      </div>

      {best > 0 && (
        <div style={{
          textAlign: 'center', paddingBottom: 14, position: 'relative', zIndex: 1,
          fontSize: 10, fontWeight: 700, letterSpacing: 1.2,
          color: 'rgba(255,255,255,0.32)', textTransform: 'uppercase',
        }}>
          Best {best.toLocaleString()}
        </div>
      )}

      {phase === 'paused' && <QuitModal onConfirm={onBack} onCancel={() => setPhase('play')} />}
    </div>
  )
}
