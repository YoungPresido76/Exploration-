// src/pages/games/WordBlitz.tsx
//
// See the word → catch the letters → build the word → survive the speed.
//
// Two combo layers:
//  - Word Combo: fast, spiky, per-letter. Resets on any wrong/trap tap or
//    miss. Drives the score multiplier for the word currently in progress.
//  - Chain Combo: slower, persistent. +1 only when a word finishes Perfect
//    (zero wrong taps, zero trap taps, zero misses). Feeds directly into
//    the shared rank/streak system (useRankStreak) so Word Blitz gets the
//    same rank badge/promotion/XP bonus every other game gets, for free.
import { useState, useEffect, useRef } from 'react'
import { Type, Flame, Zap } from 'lucide-react'
import type { GameRank, GameEndPayload } from './types'
import { useGamePresence } from '../useGamePresence'
import { getRankConfig } from './types'
import { PreGameModal, GameHUD, StatChip, ResultScreen, QuitModal, TimerBar, useRankStreak } from './GameShell'
import { playLetterHit, playLetterTrap, playWordComplete, playWordPerfect, playWrongCard } from '../sfx'
import { pickWord, ONBOARDING_WORDS, type WordTier } from './wordBlitzData'

const ACCENT = '#84cc16'
const GAME_ID = 'word-blitz' as const
const ROUND_MS = 90_000
const LANES = 5

// ─── Palette — deliberately its own sci-fi glass look rather than the
// shared app tokens, matching the locked reference design exactly.
const PAL = {
  bgTop: '#1a1030',
  bgMid: '#0a0614',
  bgDeep: '#05030b',
  purple: '#B24BF3',
  blue: '#4FC3FF',
  green: '#39FF9E',
  white: '#F5F0FF',
  muted: '#8B84A8',
  mutedDim: '#6B6484',
  red: '#ff4d5d',
}
// Each lane gets its own tint — this, not fancy lane graphics, is most of
// what reads as "futuristic": every letter glows in its lane's color.
const LANE_COLORS = [PAL.purple, PAL.blue, PAL.green, PAL.white, PAL.purple]

// ─── Scoring constants ─────────────────────────────────────────────────
const LETTER_POINTS = 10
const WRONG_PENALTY = 8
const PERFECT_BONUS = 50
const MISS_TIME_PENALTY_MS = 1000
const XP_PER_LETTER = 4
const XP_PER_WORD = 10
const XP_PER_PERFECT_WORD = 2

function lengthBonus(len: number): number {
  if (len <= 3) return 50
  if (len === 4) return 75
  if (len === 5) return 100
  if (len === 6) return 150
  if (len === 7) return 200
  return 300
}

// ─── Difficulty tiers — locked spec, time-based (0-90s) ───────────────
interface Tier {
  name: string
  startSec: number
  spawnMs: number
  fallMs: number
  minLen: number
  maxLen: number
  flashChance: number
  guaranteeMs: number
  wordTier: WordTier
}

const TIERS: Tier[] = [
  { name: 'Warm-up',      startSec: 0,  spawnMs: 1400, fallMs: 3200, minLen: 3, maxLen: 5, flashChance: 0,    guaranteeMs: 2500, wordTier: 'easy' },
  { name: 'Acceleration', startSec: 20, spawnMs: 1100, fallMs: 2600, minLen: 4, maxLen: 6, flashChance: 0.10, guaranteeMs: 2500, wordTier: 'medium' },
  { name: 'Blitz',        startSec: 40, spawnMs: 850,  fallMs: 2100, minLen: 5, maxLen: 7, flashChance: 0.20, guaranteeMs: 2000, wordTier: 'medium' },
  { name: 'Overdrive',    startSec: 60, spawnMs: 650,  fallMs: 1700, minLen: 6, maxLen: 8, flashChance: 0.30, guaranteeMs: 1700, wordTier: 'hard' },
  { name: 'Chaos',        startSec: 75, spawnMs: 500,  fallMs: 1300, minLen: 7, maxLen: 8, flashChance: 0.40, guaranteeMs: 1500, wordTier: 'hard' },
]

// Cross-session difficulty lever, same pattern as ArrowDash/SpeedMath/
// PatternMemory: the elapsed-time ramp above still plays out the same
// shape every round (Warm-up → Chaos), rank just scales the whole thing
// faster as the player climbs. Lower multiplier = faster spawn/fall and a
// tighter guarantee window.
const RANK_SPEED_MULTIPLIER: Record<GameRank, number> = {
  beginner:     1,
  intermediate: 0.88,
  advanced:     0.78,
  master:       0.68,
}

function getTier(elapsedSec: number, rank: GameRank): Tier {
  let base = TIERS[0]
  for (const tier of TIERS) {
    if (elapsedSec >= tier.startSec) base = tier
  }
  const mult = RANK_SPEED_MULTIPLIER[rank]
  if (mult === 1) return base
  return {
    ...base,
    spawnMs: Math.round(base.spawnMs * mult),
    fallMs: Math.round(base.fallMs * mult),
    guaranteeMs: Math.round(base.guaranteeMs * mult),
  }
}

interface FallingLetter {
  id: number
  lane: number
  char: string
  spawnAt: number
  fallMs: number
  flashStart: number | null
  flashEnd: number | null
}

interface Popup {
  id: number
  lane: number
  text: string
  color: string
}

interface Props {
  rank: GameRank
  streak?: number
  onEnd: (payload: GameEndPayload) => void
  onBack: () => void
  sessionsLeft?: number
  sessionCost?: number
  skipIntro?: boolean
}

export default function WordBlitz({ rank: initialRank, streak: initialStreak = 0, onEnd, onBack, sessionsLeft = 99, sessionCost = 1, skipIntro }: Props) {
  const [phase, setPhase] = useState<'info' | 'play' | 'result' | 'quit'>('info')
  useGamePresence(GAME_ID)
  const { rankState, onCorrect, onWrong } = useRankStreak(GAME_ID, initialRank, initialStreak)

  // ── Rendered state (mirrors refs, updated only on meaningful events) ──
  const [score, setScore] = useState(0)
  const [wordCombo, setWordCombo] = useState(0)
  const [chainCombo, setChainCombo] = useState(0)
  const [timeLeftSec, setTimeLeftSec] = useState(90)
  const [currentWord, setCurrentWord] = useState('')
  const [wordProgress, setWordProgress] = useState(0)
  const [letters, setLetters] = useState<FallingLetter[]>([])
  const [popups, setPopups] = useState<Popup[]>([])
  const [wordCompleteFlash, setWordCompleteFlash] = useState<{ word: string; gained: number; secLeft: number } | null>(null)
  const [missFlash, setMissFlash] = useState(false)
  const [promoted, setPromoted] = useState<GameRank | null>(null)
  const [result, setResult] = useState<GameEndPayload | null>(null)

  // ── Live-logic refs (source of truth during play, avoids stale closures) ──
  const phaseRef = useRef(phase)
  const startRef = useRef(Date.now())
  const scoreRef = useRef(0)
  const wordComboRef = useRef(0)
  const chainComboRef = useRef(0)
  const bestWordComboRef = useRef(0)
  const bestChainComboRef = useRef(0)
  const timeLeftMsRef = useRef(ROUND_MS)
  const currentWordRef = useRef('')
  const nextWordRef = useRef('')
  const wordProgressRef = useRef(0)
  const wordHasMistakeRef = useRef(false)
  const wordQueueRef = useRef<string[]>([...ONBOARDING_WORDS])
  const correctTapsRef = useRef(0)
  const totalTapsRef = useRef(0)
  const wordsCompletedRef = useRef(0)
  const perfectWordsRef = useRef(0)
  const missCountRef = useRef(0)
  const longestWordRef = useRef(0)
  const sessionXpRef = useRef(0)
  const nextIdRef = useRef(1)
  const lettersRef = useRef<FallingLetter[]>([])
  const laneOccupancyRef = useRef<(number | null)[]>(Array(LANES).fill(null))
  const duplicateCountsRef = useRef<Map<string, number>>(new Map())
  const lastRequiredSpawnAtRef = useRef(Date.now())
  const lastRequiredLaneRef = useRef(-1)
  const spawnTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const expireTimersRef = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map())
  const countdownIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const celebrateIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => { phaseRef.current = phase }, [phase])

  function clearAllTimers() {
    if (spawnTimerRef.current) clearTimeout(spawnTimerRef.current)
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current)
    if (celebrateIntervalRef.current) clearInterval(celebrateIntervalRef.current)
    for (const t of expireTimersRef.current.values()) clearTimeout(t)
    expireTimersRef.current.clear()
  }

  function elapsedSec(): number {
    return Math.max(0, (Date.now() - startRef.current) / 1000)
  }

  function pickNextWord(): string {
    if (wordQueueRef.current.length > 0) return wordQueueRef.current.shift()!
    const tier = getTier(elapsedSec(), rankState.rank)
    return pickWord(tier.minLen, tier.maxLen, tier.wordTier, currentWordRef.current)
  }

  function addPopup(lane: number, text: string, color: string) {
    const id = nextIdRef.current++
    setPopups(p => [...p, { id, lane, text, color }])
    setTimeout(() => setPopups(p => p.filter(x => x.id !== id)), 700)
  }

  function removeLetter(id: number) {
    const letter = lettersRef.current.find(l => l.id === id)
    if (letter) {
      laneOccupancyRef.current[letter.lane] = null
      const cur = duplicateCountsRef.current.get(letter.char) ?? 0
      duplicateCountsRef.current.set(letter.char, Math.max(0, cur - 1))
    }
    lettersRef.current = lettersRef.current.filter(l => l.id !== id)
    setLetters(lettersRef.current)
    const t = expireTimersRef.current.get(id)
    if (t) { clearTimeout(t); expireTimersRef.current.delete(id) }
  }

  // ── Word completion ─────────────────────────────────────────────────
  function completeWord() {
    const word = currentWordRef.current
    const perfect = !wordHasMistakeRef.current
    const letterPts = word.length * LETTER_POINTS
    const bonus = lengthBonus(word.length)
    const perfectBonus = perfect ? PERFECT_BONUS : 0
    const wordMult = Math.min(wordComboRef.current, 10) || 1
    const chainMult = 1 + Math.min(chainComboRef.current * 0.15, 1.0)
    const gained = Math.round((letterPts + bonus + perfectBonus) * wordMult * chainMult)

    scoreRef.current += gained
    setScore(scoreRef.current)
    wordsCompletedRef.current += 1
    longestWordRef.current = Math.max(longestWordRef.current, word.length)
    bestWordComboRef.current = Math.max(bestWordComboRef.current, wordComboRef.current)

    if (perfect) {
      perfectWordsRef.current += 1
      chainComboRef.current += 1
      const rankCfg = getRankConfig(rankState.rank)
      const { promoted: promo } = onCorrect(rankCfg.streakRequired)
      if (promo) setPromoted(promo)
    } else {
      chainComboRef.current = 0
      onWrong()
    }
    bestChainComboRef.current = Math.max(bestChainComboRef.current, chainComboRef.current)
    setChainCombo(chainComboRef.current)
    // Staggered on purpose: this fires in the same tick as the final
    // letter's playLetterHit() (handleCorrectTap runs, then calls
    // completeWord() synchronously). Firing both at t=0 let the sharp
    // letter blip mask the word-complete chime's onset. A ~110ms gap is
    // enough for the ear to separate them without feeling delayed.
    setTimeout(() => { if (perfect) playWordPerfect(); else playWordComplete() }, 110)

    sessionXpRef.current += XP_PER_WORD + (perfect ? XP_PER_PERFECT_WORD : 0)
    if (spawnTimerRef.current) clearTimeout(spawnTimerRef.current)

    const CELEBRATE_SECONDS = 2
    setWordCompleteFlash({ word, gained, secLeft: CELEBRATE_SECONDS })
    let secLeft = CELEBRATE_SECONDS
    celebrateIntervalRef.current = setInterval(() => {
      secLeft -= 1
      if (secLeft <= 0) {
        if (celebrateIntervalRef.current) clearInterval(celebrateIntervalRef.current)
        if (phaseRef.current !== 'play') return
        startNextWord()
        setWordCompleteFlash(null)
        scheduleNextSpawn()
      } else {
        setWordCompleteFlash(prev => prev ? { ...prev, secLeft } : prev)
      }
    }, 1000)
  }

  function startNextWord() {
    currentWordRef.current = nextWordRef.current || pickNextWord()
    nextWordRef.current = pickNextWord()
    wordProgressRef.current = 0
    wordHasMistakeRef.current = false
    lastRequiredSpawnAtRef.current = Date.now()
    setCurrentWord(currentWordRef.current)
    setWordProgress(0)
  }

  // ── Tap handling ────────────────────────────────────────────────────
  function handleCorrectTap(lane: number) {
    correctTapsRef.current += 1
    wordComboRef.current += 1
    setWordCombo(wordComboRef.current)
    sessionXpRef.current += XP_PER_LETTER
    wordProgressRef.current += 1
    setWordProgress(wordProgressRef.current)
    lastRequiredSpawnAtRef.current = Date.now()
    playLetterHit()
    addPopup(lane, '+10', 'var(--green, #3ecf8e)')
    if (wordProgressRef.current >= currentWordRef.current.length) completeWord()
  }

  function handleWrongTap(lane: number) {
    scoreRef.current = Math.max(0, scoreRef.current - WRONG_PENALTY)
    setScore(scoreRef.current)
    wordComboRef.current = 0
    setWordCombo(0)
    wordHasMistakeRef.current = true
    playWrongCard()
    addPopup(lane, `-${WRONG_PENALTY}`, 'var(--red, #ff4d4d)')
  }

  function handleTrapTap() {
    // Tapping a flashing trap letter ends the run immediately — no more
    // score/time deduction, this is a fail state. (endGame() switches phase
    // to 'result' synchronously, so a lane popup here would never actually
    // render — skipped rather than left as dead code.)
    playLetterTrap()
    endGame()
  }

  function handleMiss(silent = false, lane?: number) {
    wordComboRef.current = 0
    setWordCombo(0)
    wordHasMistakeRef.current = true
    missCountRef.current += 1
    timeLeftMsRef.current = Math.max(0, timeLeftMsRef.current - MISS_TIME_PENALTY_MS)
    setTimeLeftSec(Math.ceil(timeLeftMsRef.current / 1000))
    setMissFlash(true)
    setTimeout(() => setMissFlash(false), 400)
    if (lane !== undefined) addPopup(lane, `MISS -${MISS_TIME_PENALTY_MS / 1000}s`, PAL.red)
    if (!silent) playWrongCard()
    if (timeLeftMsRef.current <= 0) endGame()
  }

  function tap(id: number) {
    if (phaseRef.current !== 'play') return
    const letter = lettersRef.current.find(l => l.id === id)
    if (!letter) return
    removeLetter(id)
    totalTapsRef.current += 1

    const now = Date.now()
    const sinceSpawn = now - letter.spawnAt
    const flashing = letter.flashStart != null && letter.flashEnd != null &&
      sinceSpawn >= letter.flashStart && sinceSpawn <= letter.flashEnd

    if (flashing) { handleTrapTap(); return }

    const requiredChar = currentWordRef.current[wordProgressRef.current]
    if (letter.char === requiredChar) handleCorrectTap(letter.lane)
    else handleWrongTap(letter.lane)
  }

  // ── Spawning ────────────────────────────────────────────────────────
  function trySpawnLetter() {
    const tier = getTier(elapsedSec(), rankState.rank)
    const freeLanes: number[] = []
    laneOccupancyRef.current.forEach((occ, i) => { if (occ === null) freeLanes.push(i) })
    if (freeLanes.length === 0) return

    const requiredChar = currentWordRef.current[wordProgressRef.current]
    const requiredDupeCount = duplicateCountsRef.current.get(requiredChar) ?? 0
    const forceRequired = requiredChar !== undefined &&
      (Date.now() - lastRequiredSpawnAtRef.current) > tier.guaranteeMs &&
      requiredDupeCount < 2

    let char: string
    if (forceRequired) {
      char = requiredChar
    } else {
      const pool = new Set<string>((currentWordRef.current + nextWordRef.current).split(''))
      // Bias the pool toward the required letter so it appears organically
      // even without the guarantee kicking in.
      const weighted: string[] = []
      pool.forEach(c => {
        const dupes = duplicateCountsRef.current.get(c) ?? 0
        if (dupes >= 2) return // duplicate cap
        weighted.push(c)
        if (c === requiredChar) weighted.push(c) // extra weight
      })
      if (weighted.length === 0) return
      char = weighted[Math.floor(Math.random() * weighted.length)]
    }

    let lane: number
    if (char === requiredChar && freeLanes.length > 1) {
      const alt = freeLanes.filter(l => l !== lastRequiredLaneRef.current)
      lane = alt.length > 0 ? alt[Math.floor(Math.random() * alt.length)] : freeLanes[0]
    } else {
      lane = freeLanes[Math.floor(Math.random() * freeLanes.length)]
    }

    let flashStart: number | null = null
    let flashEnd: number | null = null
    if (tier.flashChance > 0 && Math.random() < tier.flashChance) {
      const windowStart = tier.fallMs * 0.30
      const windowEnd = tier.fallMs * 0.70
      const start = windowStart + Math.random() * (windowEnd - windowStart)
      const dur = Math.min(1000, tier.fallMs - start - 80)
      if (dur > 150) { flashStart = start; flashEnd = start + dur }
    }

    const id = nextIdRef.current++
    const newLetter: FallingLetter = { id, lane, char, spawnAt: Date.now(), fallMs: tier.fallMs, flashStart, flashEnd }
    lettersRef.current = [...lettersRef.current, newLetter]
    setLetters(lettersRef.current)
    laneOccupancyRef.current[lane] = id
    duplicateCountsRef.current.set(char, (duplicateCountsRef.current.get(char) ?? 0) + 1)
    if (char === requiredChar) {
      lastRequiredSpawnAtRef.current = Date.now()
      lastRequiredLaneRef.current = lane
    }

    const expireTimer = setTimeout(() => {
      const stillThere = lettersRef.current.find(l => l.id === id)
      if (!stillThere) return
      const isRequired = stillThere.char === currentWordRef.current[wordProgressRef.current]
      const wasTrap = stillThere.flashStart != null
      removeLetter(id)
      if (isRequired && phaseRef.current === 'play') handleMiss(wasTrap, stillThere.lane)
    }, tier.fallMs)
    expireTimersRef.current.set(id, expireTimer)
  }

  function scheduleNextSpawn() {
    if (phaseRef.current !== 'play') return
    const tier = getTier(elapsedSec(), rankState.rank)
    spawnTimerRef.current = setTimeout(() => {
      if (phaseRef.current !== 'play') return
      trySpawnLetter()
      scheduleNextSpawn()
    }, tier.spawnMs)
  }

  // ── Lifecycle ───────────────────────────────────────────────────────
  function endGame() {
    clearAllTimers()
    const dur = Math.floor((Date.now() - startRef.current) / 1000)
    const payload: GameEndPayload = {
      gameId: GAME_ID,
      gameName: 'Word Blitz',
      rank: rankState.rank,
      score: scoreRef.current,
      xpEarned: Math.round(sessionXpRef.current),
      durationSec: dur,
      streak: rankState.bestStreak,
      correct: correctTapsRef.current,
      total: totalTapsRef.current,
      detail: {
        'Words · Perfect · Best Combo · Longest': `${wordsCompletedRef.current} · ${perfectWordsRef.current} perfect · ×${bestWordComboRef.current} · ${longestWordRef.current} longest`,
      },
    }
    setResult(payload)
    setPhase('result')
    onEnd(payload)
  }

  function start() {
    scoreRef.current = 0; wordComboRef.current = 0; chainComboRef.current = 0
    bestWordComboRef.current = 0; bestChainComboRef.current = 0
    timeLeftMsRef.current = ROUND_MS
    wordProgressRef.current = 0; wordHasMistakeRef.current = false
    correctTapsRef.current = 0; totalTapsRef.current = 0
    wordsCompletedRef.current = 0; perfectWordsRef.current = 0; missCountRef.current = 0
    longestWordRef.current = 0; sessionXpRef.current = 0
    lettersRef.current = []; laneOccupancyRef.current = Array(LANES).fill(null)
    duplicateCountsRef.current = new Map()
    wordQueueRef.current = [...ONBOARDING_WORDS]
    lastRequiredSpawnAtRef.current = Date.now()
    lastRequiredLaneRef.current = -1
    startRef.current = Date.now()

    setScore(0); setWordCombo(0); setChainCombo(0); setTimeLeftSec(90)
    setLetters([]); setPopups([]); setWordCompleteFlash(null); setMissFlash(false)
    setPromoted(null)

    currentWordRef.current = pickNextWord()
    nextWordRef.current = pickNextWord()
    setCurrentWord(currentWordRef.current)
    setWordProgress(0)

    setPhase('play')
    phaseRef.current = 'play' // set synchronously — the useEffect that mirrors
    // `phase` into this ref only runs after this render commits, but
    // scheduleNextSpawn() below reads it immediately in this same tick.
    // Without this line the very first spawn check sees the old phase,
    // bails out, and no letters ever fall.

    countdownIntervalRef.current = setInterval(() => {
      // Real-time countdown tick. Miss/trap penalties dock time instantly
      // in their own handlers — this just keeps the displayed clock
      // flowing between them.
      timeLeftMsRef.current = Math.max(0, timeLeftMsRef.current - 200)
      setTimeLeftSec(Math.ceil(timeLeftMsRef.current / 1000))
      if (timeLeftMsRef.current <= 0) endGame()
    }, 200)

    scheduleNextSpawn()
  }

  useEffect(() => () => clearAllTimers(), [])

  const rankCfg = getRankConfig(rankState.rank)
  const timerPct = (timeLeftMsRef.current / ROUND_MS) * 100

  const rules = [
    { icon: '👀', text: 'Tap the letters that spell the target word, in order' },
    { icon: '🔥', text: 'Word Combo builds per correct letter — any wrong tap or miss resets it' },
    { icon: '⛓️', text: 'Chain Combo grows only on Perfect words — zero mistakes in the whole word' },
    { icon: '🚫', text: 'Flashing red letters are traps — tap one and it\u2019s game over, even the right letter' },
    { icon: '⏱️', text: '90 seconds. Misses cost you 1 second each' },
    { icon: '⚡', text: `Letters fall faster the higher your rank — ${rankCfg.label} runs at ${Math.round(RANK_SPEED_MULTIPLIER[rankState.rank] * 100)}% of base pace` },
  ]

  if (phase === 'info') return (
    <PreGameModal
      gameName="Word Blitz"
      tagline="See the word. Catch the letters. Survive the speed."
      accent={ACCENT}
      icon={<Type size={40} />}
      rules={rules}
      rankState={rankState}
      streakRequired={rankCfg.streakRequired}
      onStart={start}
      onClose={onBack}
      autoStart={skipIntro}
    />
  )

  if (phase === 'result' && result) return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <ResultScreen payload={result} accent={ACCENT} onReplay={() => { setResult(null); start() }} onBack={onBack} promoted={promoted} sessionsLeft={sessionsLeft} sessionCost={sessionCost} />
    </div>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: `radial-gradient(circle at 50% 0%, ${PAL.bgTop} 0%, ${PAL.bgMid} 35%, ${PAL.bgDeep} 75%)`, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: 260, height: 260, borderRadius: '50%', filter: 'blur(90px)', opacity: 0.15, background: PAL.purple, top: '5%', left: '-8%', pointerEvents: 'none' }} />

      <GameHUD
        gameName="Word Blitz"
        accent={PAL.purple}
        icon={<Type size={14} />}
        streak={rankState.currentStreak}
        onQuit={() => setPhase('quit')}
        extraRight={
          <div style={{ display: 'flex', gap: 6 }}>
            <StatChip label="Score" value={score} accent={PAL.green} />
            {chainCombo > 0 && (
              <div style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                background: `${PAL.green}1f`, border: `1px solid ${PAL.green}59`,
                borderRadius: 12, padding: '7px 11px', minWidth: 46,
                boxShadow: `0 0 12px ${PAL.green}40`,
              }}>
                <span style={{ fontSize: 15, fontWeight: 800, fontFamily: 'monospace', color: PAL.green, display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Flame size={12} />×{chainCombo}
                </span>
                <span style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.8px', color: PAL.green, marginTop: 1 }}>Chain</span>
              </div>
            )}
          </div>
        }
      />

      {/* Target word + progress dots — purple glass panel, matches reference */}
      <div style={{ padding: '10px 18px 14px', textAlign: 'center' }}>
        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '2.5px', color: PAL.mutedDim, marginBottom: 8, textTransform: 'uppercase' }}>Target Word</div>
        <div style={{
          border: `1px solid ${PAL.purple}4d`, borderRadius: 16,
          background: `${PAL.purple}0d`, padding: '16px 10px 12px',
        }}>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: 26, fontWeight: 900, letterSpacing: '2px' }}>
            {currentWord.split('').map((ch, i) => (
              <span key={i} style={{ display: 'flex', alignItems: 'center' }}>
                <span style={{
                  color: i < wordProgress ? PAL.green : PAL.white,
                  opacity: i < wordProgress ? 0.55 : 1,
                  padding: '0 4px', transition: 'opacity 0.25s, color 0.25s',
                }}>{ch}</span>
                {i < currentWord.length - 1 && <span style={{ width: 1, height: 20, background: `${PAL.purple}40`, margin: '0 2px' }} />}
              </span>
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 12 }}>
            {currentWord.split('').map((_, i) => (
              i < wordProgress
                ? <span key={i} style={{
                    width: 17, height: 17, borderRadius: '50%', background: PAL.green,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    boxShadow: `0 0 10px ${PAL.green}99`, color: PAL.bgDeep, fontSize: 10, fontWeight: 900,
                  }}>✓</span>
                : <span key={i} style={{ width: 17, height: 17, borderRadius: '50%', border: `1.5px solid ${PAL.purple}66` }} />
            ))}
          </div>
        </div>
      </div>

      {/* Word Combo — twitchy, disposable, near the falling letters */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 4 }}>
        {wordCombo >= 2 && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 4,
            background: `${PAL.purple}1a`, border: `1px solid ${PAL.purple}55`,
            borderRadius: 14, padding: '3px 12px',
            fontSize: 12, fontWeight: 800, color: PAL.purple,
            animation: 'wbComboPop 0.2s ease-out',
          }}>
            <Zap size={11} /> Combo ×{wordCombo}
          </div>
        )}
      </div>

      {/* Falling letters play area — mostly transparent, faint purple hairline
          borders top/bottom, letting the page's own dark gradient show
          through rather than a boxed panel. */}
      <div style={{
        flex: 1, minHeight: 340, position: 'relative', margin: '4px 8px',
        borderTop: `1px solid ${missFlash ? PAL.red : `${PAL.purple}1a`}`,
        borderBottom: `1px solid ${missFlash ? PAL.red : `${PAL.purple}1a`}`,
        boxShadow: missFlash ? `0 0 24px ${PAL.red}66 inset` : 'none',
        overflow: 'hidden', transition: 'border-color 0.2s, box-shadow 0.2s',
      }}>
        {/* Lane guides — barely-there purple hairlines */}
        <div style={{ position: 'absolute', inset: 0, display: 'flex' }}>
          {Array.from({ length: LANES }).map((_, i) => (
            <div key={i} style={{ flex: 1, borderRight: i < LANES - 1 ? `1px solid ${PAL.purple}18` : 'none' }} />
          ))}
        </div>

        {letters.map(l => (
          <FallingLetterChip key={l.id} letter={l} laneWidth={100 / LANES} laneColor={LANE_COLORS[l.lane % LANE_COLORS.length]} onTap={() => tap(l.id)} />
        ))}

        {popups.map(p => (
          <div key={p.id} style={{
            position: 'absolute', left: `${(p.lane + 0.5) * (100 / LANES)}%`, top: '40%',
            transform: 'translateX(-50%)', fontSize: 13, fontWeight: 800, color: p.color,
            animation: 'wbPopupFloat 0.7s ease-out forwards', pointerEvents: 'none', whiteSpace: 'nowrap',
          }}>{p.text}</div>
        ))}

        {/* Word complete overlay — pulsing burst, gradient headline, +score
            pill, live "next word in" countdown. Matches the reference. */}
        {wordCompleteFlash && (
          <div style={{
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 12,
            background: 'rgba(4,2,10,0.85)',
            backdropFilter: 'blur(4px)', animation: 'wbWordComplete 0.35s cubic-bezier(0.34,1.56,0.64,1) both',
          }}>
            <div style={{
              position: 'absolute', width: 220, height: 220, borderRadius: '50%',
              background: `radial-gradient(circle, ${PAL.green}59, transparent 70%)`,
              animation: 'wbBurstPulse 1.4s ease-out infinite',
            }} />
            <span style={{
              position: 'relative', fontSize: 30, fontWeight: 900, fontStyle: 'italic',
              lineHeight: 1.05, textAlign: 'center', textTransform: 'uppercase',
              background: `linear-gradient(180deg, #fff, #8fffc4 60%, ${PAL.green})`,
              WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent',
              filter: `drop-shadow(0 0 16px ${PAL.green}80)`,
            } as React.CSSProperties}>Word<br />Complete!</span>
            <span style={{
              position: 'relative', padding: '8px 22px', borderRadius: 20,
              border: `1px solid ${PAL.green}80`, background: `${PAL.green}1a`,
              color: PAL.green, fontWeight: 900, fontSize: 16, fontFamily: 'monospace',
            }}>+{wordCompleteFlash.gained}</span>
            <span style={{
              position: 'relative', padding: '6px 16px', borderRadius: 20,
              background: `${PAL.purple}26`, border: `1px solid ${PAL.purple}4d`,
              fontSize: 11, letterSpacing: '1px', color: '#D9B8FF', fontWeight: 700, textTransform: 'uppercase',
            }}>Next word in {wordCompleteFlash.secLeft}</span>

            {/* Combo / Streak — matches the reference's bottom stat row,
                shown here inline in the overlay instead of a separate
                persistent bar. Values are frozen at their post-word state
                since neither resets until the next tap. */}
            <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 14, marginTop: 2 }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '1px', color: PAL.mutedDim, textTransform: 'uppercase' }}>Combo</span>
                <span style={{ fontSize: 15, fontWeight: 900, fontFamily: 'monospace', color: PAL.purple }}>×{Math.min(wordCombo, 10)}</span>
              </div>
              <div style={{ width: 1, height: 24, background: `${PAL.purple}26` }} />
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '1px', color: PAL.mutedDim, textTransform: 'uppercase' }}>Streak</span>
                <span style={{ fontSize: 15, fontWeight: 900, fontFamily: 'monospace', color: PAL.green }}>{chainCombo} words</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Timer */}
      <div style={{ padding: '8px 16px 12px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
          <div style={{
            fontSize: 11, fontWeight: 700, color: PAL.blue,
            background: `${PAL.blue}18`, border: `1px solid ${PAL.blue}33`,
            borderRadius: 10, padding: '3px 9px',
          }}>{getTier(elapsedSec(), rankState.rank).name}</div>
          <span style={{ fontSize: 13, fontWeight: 800, fontFamily: 'monospace', color: timeLeftSec <= 10 ? PAL.red : PAL.white }}>
            {String(Math.floor(timeLeftSec / 60)).padStart(2, '0')}:{String(timeLeftSec % 60).padStart(2, '0')}
          </span>
        </div>
        <TimerBar pct={timerPct} accent={PAL.purple} urgent secondsLeft={timeLeftSec} />
      </div>

      {phase === 'quit' && (
        <QuitModal
          onConfirm={() => { clearAllTimers(); onBack() }}
          onCancel={() => setPhase('play')}
        />
      )}

      <style>{`
        @keyframes wbComboPop {
          0% { transform: scale(0.8); opacity: 0; }
          100% { transform: scale(1); opacity: 1; }
        }
        @keyframes wbPopupFloat {
          0% { transform: translate(-50%, 0); opacity: 1; }
          100% { transform: translate(-50%, -28px); opacity: 0; }
        }
        @keyframes wbWordComplete {
          0% { transform: scale(0.85); opacity: 0; }
          100% { transform: scale(1); opacity: 1; }
        }
        @keyframes wbBurstPulse {
          0% { opacity: 0.55; transform: scale(0.9); }
          100% { opacity: 0; transform: scale(1.6); }
        }
        @keyframes wbTrapFlash {
          0%, 100% { background: var(--wb-letter-bg); border-color: var(--wb-letter-border); box-shadow: 0 0 16px var(--wb-letter-glow); }
          50% { background: rgba(90,10,20,.9); border-color: #ff4d5d; box-shadow: 0 0 22px rgba(255,50,70,.6); color: #ff4d5d; }
        }
        @keyframes wbFall {
          from { top: -46px; }
          to { top: 100%; }
        }
      `}</style>
    </div>
  )
}

// ─── Falling letter chip ────────────────────────────────────────────
// Fall is a real CSS @keyframes animation (wbFall, declared in the parent's
// <style> block), started the instant this mounts. Deliberately NOT a
// CSS transition flipped one frame after mount via rAF+state — that trick
// depends on the browser painting the "before" value before the "after"
// value lands, and on some devices those two writes get coalesced into a
// single paint, silently skipping the animation (and, depending on layout,
// leaving the letter effectively invisible). A keyframe animation has no
// such race — it just plays from its 0% state the moment it's attached.
function FallingLetterChip({ letter, laneWidth, laneColor, onTap }: {
  letter: FallingLetter
  laneWidth: number
  laneColor: string
  onTap: () => void
}) {
  const hasFlash = letter.flashStart != null && letter.flashEnd != null
  const flashDelay = letter.flashStart ?? 0
  const flashDur = hasFlash ? (letter.flashEnd! - letter.flashStart!) : 0

  return (
    <button
      type="button"
      onPointerDown={(e) => { e.preventDefault(); onTap() }}
      style={{
        '--wb-letter-bg': 'rgba(15,10,30,.85)',
        '--wb-letter-border': `${laneColor}55`,
        '--wb-letter-glow': `${laneColor}33`,
        position: 'absolute',
        left: `${letter.lane * laneWidth}%`, width: `${laneWidth}%`,
        top: '-46px',
        animationName: 'wbFall',
        animationDuration: `${letter.fallMs}ms`,
        animationTimingFunction: 'linear',
        animationFillMode: 'forwards',
        transform: 'translateY(-100%)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '0 6px', background: 'transparent', border: 'none', outline: 'none',
        cursor: 'pointer', WebkitTapHighlightColor: 'transparent', touchAction: 'manipulation',
      } as React.CSSProperties}
    >
      {/* Comet trail — a static gradient bar trailing upward behind the
          letter. No animation of its own needed: it's a child of the
          falling button, so it rides along with the same wbFall motion. */}
      <div style={{
        position: 'absolute', left: '50%', bottom: '50%',
        transform: 'translateX(-50%)', width: 3, height: 68,
        background: `linear-gradient(to bottom, transparent, ${laneColor} 88%)`,
        opacity: 0.45, borderRadius: 4, pointerEvents: 'none',
      }} />
      {/* Glass tile, not a solid chip — translucent dark glass with a
          lane-tinted border and outer glow so it visibly "lights up"
          rather than reading as an opaque button. */}
      <span
        style={{
          width: 42, height: 42, borderRadius: 13,
          background: 'var(--wb-letter-bg)', border: '1px solid var(--wb-letter-border)',
          boxShadow: `0 0 16px var(--wb-letter-glow)`,
          backdropFilter: 'blur(2px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18, fontWeight: 800, color: laneColor,
          cursor: 'pointer', userSelect: 'none',
          animationName: hasFlash ? 'wbTrapFlash' : 'none',
          animationDuration: `${flashDur}ms`,
          animationDelay: `${flashDelay}ms`,
          animationIterationCount: 1,
          animationTimingFunction: 'ease-in-out',
          animationFillMode: 'both',
        } as React.CSSProperties}
      >
        {letter.char}
      </span>
    </button>
  )
}
