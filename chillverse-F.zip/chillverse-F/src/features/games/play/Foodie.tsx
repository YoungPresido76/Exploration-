// src/features/games/play/Foodie.tsx
// "Foodie" — a photo of a dish appears, name it.
// Two modes: 4 Options (tap) or Type It (type the name, fuzzy matched).
// 3 lives · costs 4 sessions · 20 XP per correct (35 in Type It).
import { useState, useEffect, useRef } from 'react'
import { UtensilsCrossed, WifiOff, RefreshCw, Heart } from 'lucide-react'
import type { GameRank, GameEndPayload } from './types'
import { getRankConfig } from './types'
import { PreGameModal, GameHUD, StatChip, ResultScreen, QuitModal, TimerBar, useRankStreak } from './GameShell'
import { useFoodQuestions } from '../useFoodQuestions'
import { useGamePresence } from '../useGamePresence'
import { ripple } from '../../../shared/lib/ripple'

const ACCENT  = '#ff8a3c'
const GAME_ID = 'foodie' as const

const MAX_LIVES = 3

// Type It is meaningfully harder — no options to reverse-engineer from —
// so it pays close to double.
const XP_CHOICE = 20
const XP_TYPE   = 35

type Mode = 'choice' | 'type'

interface RankFoodConfig {
  rounds: number
  /** seconds per photo */
  timer: number
  streakRequired: number
}

// Higher ranks get more rounds and less time. The category pool also gets
// harder per rank — that part lives in useFoodQuestions.
const RANK_CONFIG: Record<GameRank, RankFoodConfig> = {
  beginner:     { rounds: 8,  timer: 15, streakRequired: 5 },
  intermediate: { rounds: 10, timer: 13, streakRequired: 5 },
  advanced:     { rounds: 10, timer: 11, streakRequired: 5 },
  master:       { rounds: 12, timer: 9,  streakRequired: 5 },
}

// ─── Fuzzy match (same approach as Close Call) ─────────────────
function normalize(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ')
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)])
  for (let j = 0; j <= n; j++) dp[0][j] = j
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
  return dp[m][n]
}

function isClose(userInput: string, accepted: string[]): boolean {
  const u = normalize(userInput)
  if (u.length < 3) return false
  for (const ans of accepted) {
    const a = normalize(ans)
    if (!a) continue
    if (u === a) return true
    // Typos: 1 char for short names, 2 for longer ones.
    const threshold = a.length <= 6 ? 1 : 2
    if (levenshtein(u, a) <= threshold) return true
    // Typed the distinctive part of a long name ("fajita" for
    // "Chicken Fajita Mac and Cheese").
    if (a.includes(u) && u.length >= 5) return true
  }
  return false
}

interface Props {
  rank: GameRank
  streak?: number
  onEnd: (payload: GameEndPayload) => void
  onBack: () => void
  sessionsLeft?: number
  sessionCost?: number
  skipIntro?: boolean
  /** 'choice' (default) or 'type' — chosen in GameDetailModal */
  initialMode?: Mode
}

export default function Foodie({
  rank: initialRank, streak: initialStreak = 0, onEnd, onBack,
  sessionsLeft = 99, sessionCost = 4, skipIntro, initialMode = 'choice',
}: Props) {
  const [phase, setPhase] = useState<'info' | 'play' | 'result' | 'quit'>('info')
  useGamePresence(GAME_ID)
  const { rankState, onCorrect, onWrong } = useRankStreak(GAME_ID, initialRank, initialStreak)
  const { questions, fetchState, error, fetchQuestions } = useFoodQuestions()

  const mode = initialMode
  const xpPerCorrect = mode === 'type' ? XP_TYPE : XP_CHOICE

  const [qIdx,         setQIdx]         = useState(0)
  const [score,        setScore]        = useState(0)
  const [lives,        setLives]        = useState(MAX_LIVES)
  const [timeLeft,     setTimeLeft]     = useState(RANK_CONFIG[initialRank].timer)
  const [selected,     setSelected]     = useState<number | null>(null)
  const [input,        setInput]        = useState('')
  const [reveal,       setReveal]       = useState<null | 'correct' | 'wrong' | 'timeout'>(null)
  const [correctCount, setCorrectCount] = useState(0)
  const [promoted,     setPromoted]     = useState<GameRank | null>(null)
  const [result,       setResult]       = useState<GameEndPayload | null>(null)
  const [endReason,    setEndReason]    = useState<'completed' | 'out-of-lives'>('completed')

  const scoreRef    = useRef(0)
  const correctRef  = useRef(0)
  const livesRef    = useRef(MAX_LIVES)
  const qIdxRef     = useRef(0)
  const startRef    = useRef(Date.now())
  const tickRef     = useRef<ReturnType<typeof setInterval> | null>(null)
  const advanceRef  = useRef<ReturnType<typeof setTimeout>  | null>(null)
  const inputRef    = useRef<HTMLInputElement>(null)

  const cfg = RANK_CONFIG[rankState.rank]

  function clearTimers() {
    if (tickRef.current)    clearInterval(tickRef.current)
    if (advanceRef.current) clearTimeout(advanceRef.current)
  }

  function endGame(reason: 'completed' | 'out-of-lives') {
    clearTimers()
    const dur = Math.floor((Date.now() - startRef.current) / 1000)
    const payload: GameEndPayload = {
      gameId:      GAME_ID,
      gameName:    'Foodie',
      rank:        rankState.rank,
      score:       scoreRef.current,
      xpEarned:    correctRef.current * xpPerCorrect,
      durationSec: dur,
      streak:      rankState.bestStreak,
      correct:     correctRef.current,
      total:       cfg.rounds,
      detail: {
        'Mode':       mode === 'type' ? 'Type It' : '4 Options',
        'Identified': correctRef.current,
        'Rounds':     cfg.rounds,
        'Lives left': livesRef.current,
        'End reason': reason === 'out-of-lives' ? 'Out of lives' : 'Completed',
      },
    }
    setEndReason(reason)
    setResult(payload)
    setPhase('result')
    onEnd(payload)
  }

  function startTimer() {
    clearTimers()
    setTimeLeft(cfg.timer)
    tickRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          clearInterval(tickRef.current!)
          handleMiss('timeout')
          return 0
        }
        return t - 1
      })
    }, 1000)
  }

  function nextRound() {
    setSelected(null)
    setInput('')
    setReveal(null)
    qIdxRef.current += 1
    if (qIdxRef.current >= questions.length) { endGame('completed'); return }
    setQIdx(qIdxRef.current)
    startTimer()
    if (mode === 'type') setTimeout(() => inputRef.current?.focus(), 80)
  }

  function handleHit(timeRemaining: number) {
    clearTimers()
    // Base points + a speed bonus, so knowing it *fast* still matters
    // even though XP is flat per correct answer.
    const base = mode === 'type' ? 100 : 60
    const pts  = base + timeRemaining * 5
    scoreRef.current += pts
    correctRef.current += 1
    setScore(scoreRef.current)
    setCorrectCount(correctRef.current)
    setReveal('correct')

    const { promoted: promo } = onCorrect(getRankConfig(rankState.rank).streakRequired)
    if (promo) setPromoted(promo)

    advanceRef.current = setTimeout(nextRound, 1100)
  }

  function handleMiss(kind: 'wrong' | 'timeout') {
    clearTimers()
    onWrong()
    livesRef.current -= 1
    setLives(livesRef.current)
    setReveal(kind)

    advanceRef.current = setTimeout(() => {
      if (livesRef.current <= 0) { endGame('out-of-lives'); return }
      nextRound()
    }, 1400)
  }

  function pick(idx: number) {
    if (selected !== null || reveal) return
    setSelected(idx)
    const q = questions[qIdxRef.current]
    if (idx === q.correct) handleHit(timeLeft)
    else handleMiss('wrong')
  }

  function submitTyped() {
    if (reveal || !input.trim()) return
    const q = questions[qIdxRef.current]
    if (isClose(input, q.accepted)) handleHit(timeLeft)
    else handleMiss('wrong')
  }

  function handleStart() {
    fetchQuestions(rankState.rank, RANK_CONFIG[rankState.rank].rounds)
  }

  // Once photos are loaded + preloaded, run the round.
  useEffect(() => {
    if (fetchState !== 'ready' || questions.length === 0) return
    setQIdx(0); setScore(0); setCorrectCount(0); setSelected(null)
    setInput(''); setReveal(null); setLives(MAX_LIVES)
    setPromoted(null); setResult(null); setEndReason('completed')
    qIdxRef.current = 0; scoreRef.current = 0; correctRef.current = 0
    livesRef.current = MAX_LIVES
    startRef.current = Date.now()
    setPhase('play')
    startTimer()
    if (mode === 'type') setTimeout(() => inputRef.current?.focus(), 200)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchState, questions])

  useEffect(() => () => clearTimers(), [])

  const rankCfg  = getRankConfig(rankState.rank)
  const q        = questions[qIdx]
  const timerPct = (timeLeft / cfg.timer) * 100

  const rules = [
    { icon: '🍽', text: `${cfg.rounds} dishes per game — name each one` },
    { icon: mode === 'type' ? '⌨️' : '🔢', text: mode === 'type' ? 'Type the dish name — close spelling counts' : 'Pick the right name from 4 options' },
    { icon: '⏱', text: `${cfg.timer}s per dish` },
    { icon: '❤️', text: `${MAX_LIVES} lives — 3 misses and it's over` },
    { icon: '🔥', text: '5 correct in a row = rank up' },
    { icon: '⭐', text: `${xpPerCorrect} XP per correct answer. Costs ${sessionCost} sessions.` },
  ]

  // ── Info screen ───────────────────────────────────────────
  if (phase === 'info') return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <PreGameModal
        gameName="Foodie"
        tagline="Name the dish. Don't drool."
        accent={ACCENT}
        icon={<UtensilsCrossed size={40} />}
        rules={rules}
        rankState={rankState}
        streakRequired={rankCfg.streakRequired}
        onStart={handleStart}
        onClose={onBack}
        autoStart={skipIntro}
      />

      {fetchState === 'loading' && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 999,
          background: 'var(--overlay-scrim)', backdropFilter: 'blur(8px)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16,
        }}>
          <div style={{
            width: 52, height: 52, borderRadius: '50%',
            border: `3px solid ${ACCENT}33`, borderTopColor: ACCENT,
            animation: 'spin 0.8s linear infinite',
          }} />
          <p style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>Plating up…</p>
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading fresh dishes, no repeats</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
        </div>
      )}

      {fetchState === 'error' && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 999,
          background: 'var(--overlay-scrim)', backdropFilter: 'blur(8px)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: 24,
        }}>
          <WifiOff size={40} style={{ color: '#ff4f4f' }} />
          <p style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', textAlign: 'center' }}>Kitchen's closed</p>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>{error}</p>
          <button type="button" onClick={handleStart}
            style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: ACCENT, color: '#fff', border: 'none', borderRadius: 12, padding: '10px 20px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>
            <RefreshCw size={14} /> Try Again
          </button>
          <button type="button" onClick={onBack}
            style={{ fontSize: 12, color: 'var(--text-muted)', background: 'none', border: 'none', cursor: 'pointer' }}>
            Go back
          </button>
        </div>
      )}
    </div>
  )

  // ── Result screen ─────────────────────────────────────────
  if (phase === 'result' && result) return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      {endReason === 'out-of-lives' && (
        <div style={{
          margin: '16px 16px 0', padding: '12px 16px', borderRadius: 14,
          background: 'rgba(255,79,79,0.1)', border: '1px solid rgba(255,79,79,0.3)',
          fontSize: 13, fontWeight: 700, color: '#ff4f4f', textAlign: 'center',
        }}>
          💔 Out of lives — session over
        </div>
      )}
      <ResultScreen
        payload={result}
        accent={ACCENT}
        onReplay={() => { setResult(null); handleStart() }}
        onBack={onBack}
        promoted={promoted}
        sessionsLeft={sessionsLeft}
        sessionCost={sessionCost}
      />
    </div>
  )

  // ── Play screen ───────────────────────────────────────────
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--bg)', position: 'relative' }}>
      <div style={{ position: 'absolute', width: 220, height: 220, borderRadius: '50%', filter: 'blur(80px)', opacity: 0.07, background: ACCENT, top: '10%', right: '-5%', pointerEvents: 'none' }} />

      <GameHUD
        gameName="Foodie"
        accent={ACCENT}
        icon={<UtensilsCrossed size={14} />}
        streak={rankState.currentStreak}
        onQuit={() => setPhase('quit')}
        extraRight={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 2 }}>
              {Array.from({ length: MAX_LIVES }).map((_, i) => (
                <Heart key={i} size={13}
                  fill={i < lives ? '#ff4f4f' : 'transparent'}
                  style={{ color: i < lives ? '#ff4f4f' : 'var(--text-dim)' }} />
              ))}
            </div>
            <StatChip label="Score" value={score} accent={ACCENT} />
            <StatChip label={`${qIdx + 1}/${questions.length}`} value={`${correctCount}✓`} />
          </div>
        }
      />

      {/* Timer */}
      <div style={{ padding: '8px 16px 4px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-dim)', marginBottom: 5 }}>
          <span>{mode === 'type' ? 'Type the dish' : 'Name this dish'}</span>
          <span style={{ fontWeight: 700, color: timeLeft <= 3 ? '#ff4f4f' : 'var(--text-dim)' }}>{timeLeft}s</span>
        </div>
        <TimerBar pct={timerPct} accent={timeLeft <= 3 ? '#ff4f4f' : ACCENT} urgent={timeLeft <= 3} />
      </div>

      {/* The dish */}
      <div className="neu-card" style={{ margin: '10px 16px', padding: 8, flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ position: 'relative', flex: 1, minHeight: 160, borderRadius: 14, overflow: 'hidden', background: 'var(--surface2)' }}>
          {q && (
            <img
              key={q.id}
              src={q.image}
              alt="Guess this dish"
              style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
            />
          )}

          {/* Reveal overlay */}
          {reveal && q && (
            <div style={{
              position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 6, padding: 16, textAlign: 'center',
              background: reveal === 'correct' ? 'rgba(62,207,142,0.85)' : 'var(--overlay-scrim)',
              backdropFilter: 'blur(2px)',
            }}>
              <p style={{ fontSize: 13, fontWeight: 800, color: '#fff', letterSpacing: 0.4 }}>
                {reveal === 'correct' ? `✅ +${xpPerCorrect} XP` : reveal === 'timeout' ? '⏰ Too slow' : '❌ Not quite'}
              </p>
              <p style={{ fontSize: 16, fontWeight: 800, color: '#fff', lineHeight: 1.35 }}>{q.answer}</p>
              <p style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.75)' }}>{q.category}</p>
            </div>
          )}
        </div>
      </div>

      {/* Answer area */}
      {mode === 'choice' ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, padding: '8px 16px 20px' }}>
          {q?.options.map((opt, i) => {
            const isCorrect  = i === q.correct
            const isSelected = selected === i
            let bg = 'var(--surface)'; let border = 'rgba(255,255,255,0.07)'
            if (reveal) {
              if (isCorrect)       { bg = 'rgba(62,207,142,0.12)'; border = 'rgba(62,207,142,0.5)' }
              else if (isSelected) { bg = 'rgba(255,79,79,0.12)';  border = 'rgba(255,79,79,0.5)'  }
            }
            return (
              <button key={`${q.id}-${i}`} type="button" className="ripple-wrap"
                onClick={(e) => { ripple(e); pick(i) }}
                style={{
                  padding: '14px 10px', borderRadius: 14, fontSize: 12.5, fontWeight: 600,
                  cursor: reveal ? 'default' : 'pointer', background: bg,
                  border: `1px solid ${border}`, boxShadow: 'var(--elev-raise-sm)',
                  color: 'var(--text)', textAlign: 'center', lineHeight: 1.35,
                  transition: 'background-color var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out)',
                }}>
                {opt}
              </button>
            )
          })}
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 8, padding: '8px 16px 20px' }}>
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') submitTyped() }}
            disabled={!!reveal}
            placeholder="What dish is this?"
            autoComplete="off" autoCorrect="off" autoCapitalize="none" spellCheck={false}
            style={{
              flex: 1, padding: '14px 14px', borderRadius: 14, fontSize: 14, fontWeight: 600,
              background: 'var(--surface)', border: '1px solid rgba(255,255,255,0.07)',
              color: 'var(--text)', outline: 'none', boxShadow: 'var(--elev-inset)',
            }}
          />
          <button type="button" className="ripple-wrap"
            onClick={(e) => { ripple(e); submitTyped() }}
            disabled={!!reveal || !input.trim()}
            style={{
              padding: '14px 20px', borderRadius: 14, fontSize: 13, fontWeight: 800, border: 'none',
              background: (!!reveal || !input.trim()) ? 'var(--surface2)' : ACCENT,
              color: (!!reveal || !input.trim()) ? 'var(--text-muted)' : '#fff',
              cursor: (!!reveal || !input.trim()) ? 'not-allowed' : 'pointer',
            }}>
            Serve
          </button>
        </div>
      )}

      {phase === 'quit' && <QuitModal onConfirm={onBack} onCancel={() => setPhase('play')} />}
    </div>
  )
}
