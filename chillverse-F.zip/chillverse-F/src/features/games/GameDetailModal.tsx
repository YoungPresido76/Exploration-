// src/features/games/GameDetailModal.tsx
//
// Discord-style "activity" detail sheet. Tapping a game card opens this
// instead of jumping straight into the game.
//
// Phone AND tablet: a bottom sheet that slides up and covers almost the
// full screen (not literally edge-to-edge — it has rounded top corners
// and a sliver of backdrop above it), same as the rest of the app's
// sheets (see ProfilePreviewModal). This is keyed off touch/pointer type,
// NOT just viewport width — a tablet's width alone can be wide enough to
// look "desktop-sized" while still being a touch device, which used to
// wrongly push it into the desktop layout below.
//
// Real desktop (mouse/trackpad, i.e. `pointer: fine`, above a width
// floor): a centered dialog card that does NOT cover the full screen.
//
// Back arrow (top-left) closes it. "…" (top-right) opens Copy Game ID /
// Favorite. Favoriting pins the card to the top of its section on the
// lobby and adds a star badge to it.
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import {
  ArrowLeft, MoreVertical, Copy, Check, Star, Play, Lock, Zap, Crown, Users, Tag, Flame,
  HeartPulse,
} from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { getRankConfig, RankProgressBar } from './play/GameShell'
import PlunderHatCard from './PlunderHatCard'
import type { GameMeta } from './games'
import type { GameRank } from './play/types'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

interface Props {
  game: GameMeta
  rank: GameRank
  streak: number
  bestStreak: number
  isFavorite: boolean
  onToggleFavorite: () => void
  locked: boolean
  lockedReason: string | null
  /** The game's feature flag is OFF, but the viewer is staff and is being
   *  let through anyway. Shown as an amber "players can't see this" notice
   *  so an admin testing a locked game is never confused about whether the
   *  kill switch actually took effect. */
  staffBypass?: boolean
  /**
   * A live action offered *instead of* the dead "Locked" button, for locks
   * the player can actually clear from here (being down in PvP). Distinct
   * from onUpgrade, which is specifically the Pro upsell and paints itself
   * as one. Ignored unless `locked`.
   */
  onLockedAction?: () => void
  lockedActionLabel?: string
  /** Play is mid-flight (verifying the session allowance server-side) or the
   *  gate hasn't finished loading. Shown as a "Checking…" state so the button
   *  reads as not-yet-ready rather than as a hard lock. */
  busy?: boolean
  /** Supplied only when the lock is a subscription one — turns the dead
   *  "Locked" button into a route to the Pro page. */
  onUpgrade?: () => void
  onPlay: (difficulty?: string) => void
  onClose: () => void
}

// Games that need a pre-play choice collected before Play is tapped. Add
// entries here (instead of the game showing its own second intro screen)
// so every solo game funnels through this one detail sheet.
const DIFFICULTY_OPTIONS: Partial<Record<string, { value: string; label: string }[]>> = {
  'tac-zone': [
    { value: 'easy', label: 'Easy' },
    { value: 'hard', label: 'Hard' },
    { value: 'expert', label: 'Expert' },
  ],
  // Foodie answer mode. NOTE the default selection below is index 1, so
  // the *second* entry is what a player gets if they just hit Play —
  // '4 Options' is deliberately second so the easier mode is the default.
  'foodie': [
    { value: 'type',   label: 'Type It (35 XP)' },
    { value: 'choice', label: '4 Options (20 XP)' },
  ],
}

// Sheet height on phone/tablet — a percentage of the viewport, so it
// always "almost covers" the screen proportionally rather than either
// looking cramped or reading as a flat full-page swap.
const SHEET_HEIGHT_VH = 92

function computeIsDesktop(): boolean {
  if (typeof window === 'undefined') return false
  const pointerFine = window.matchMedia ? window.matchMedia('(pointer: fine)').matches : true
  // Fine pointer (mouse/trackpad) AND enough width — a touch tablet can
  // easily be wider than this, but won't have a fine pointer, so it
  // still correctly falls through to the sheet layout below.
  return pointerFine && window.innerWidth >= 820
}

export default function GameDetailModal({
  game, rank, streak, bestStreak, isFavorite, onToggleFavorite, locked, lockedReason, staffBypass,
  busy = false, onUpgrade, onLockedAction, lockedActionLabel, onPlay, onClose,
}: Props) {
  const Icon = game.icon
  const cost = game.sessionCost ?? 1
  const rankCfg = getRankConfig(rank)

  const [isDesktop, setIsDesktop] = useState(computeIsDesktop)
  const [entered, setEntered] = useState(false)
  const [closing, setClosing] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [idCopied, setIdCopied] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  const difficultyOptions = DIFFICULTY_OPTIONS[game.id]
  const [difficulty, setDifficulty] = useState<string | undefined>(difficultyOptions?.[1]?.value ?? difficultyOptions?.[0]?.value)

  useEffect(() => {
    function onResize() { setIsDesktop(computeIsDesktop()) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  useEffect(() => {
    const t = requestAnimationFrame(() => setEntered(true))
    document.body.style.overflow = 'hidden'
    return () => { cancelAnimationFrame(t); document.body.style.overflow = '' }
  }, [])

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [])

  function close() {
    setClosing(true)
    setTimeout(onClose, 220)
  }

  // Drag-to-dismiss from anywhere inside the sheet — engages only when the
  // content under the finger is already scrolled to the top, so the body
  // still scrolls normally. See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(close)

  function handleCopyId() {
    navigator.clipboard?.writeText(game.id).catch(() => {})
    setIdCopied(true)
    setTimeout(() => { setIdCopied(false); setMenuOpen(false) }, 900)
  }

  const hasBanner = !!game.bannerUrl
  const description = game.description ?? game.tagline

  // ── Layout, split by device class ──────────────────────────────
  const sheetStyle: React.CSSProperties = isDesktop
    ? {
        width: 'min(92vw, 460px)',
        height: 'auto',
        maxHeight: '85vh',
        borderRadius: 20,
        transform: entered && !closing ? 'scale(1)' : 'scale(0.94)',
        opacity: entered && !closing ? 1 : 0,
        transition: 'transform 0.24s cubic-bezier(0.32,0.72,0,1), opacity 0.2s ease-out',
        boxShadow: 'var(--elev-popover)',
      }
    : {
        width: '100%',
        height: `${SHEET_HEIGHT_VH}vh`,
        maxHeight: `${SHEET_HEIGHT_VH}vh`,
        borderRadius: '20px 20px 0 0',
        marginTop: 'auto',
        transform: entered && !closing ? `translateY(${dragY}px)` : 'translateY(100%)',
        transition: dragging ? 'none' : 'transform 0.32s cubic-bezier(0.32,0.72,0,1)',
        boxShadow: '0 -12px 40px -12px var(--sh)',
      }

  return createPortal(
    <div
      onClick={close}
      style={{
        position: 'fixed', inset: 0, zIndex: 21000,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: isDesktop ? 'center' : 'flex-end', justifyContent: 'center',
        opacity: entered && !closing ? 1 : 0, transition: 'opacity 0.2s ease-out',
      }}
    >
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          ...sheetStyle,
          background: 'var(--bg)',
          overflowY: 'auto', overscrollBehavior: 'contain',
          position: 'relative',
        }}
      >
        {!isDesktop && (
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)', margin: '10px auto 0' }} />
        )}

        {/* Icon strip — accent-tinted, holds the small game icon like the
            app icon above a Discord activity banner. */}
        <div style={{
          position: 'relative', height: 64,
          background: `linear-gradient(135deg, ${game.accent}55, ${game.accent}22)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginTop: isDesktop ? 0 : 4,
        }}>
          <div style={{
            width: 52, height: 52, borderRadius: 16, background: 'var(--bg)',
            border: `1px solid ${game.accent}55`, boxShadow: `0 4px 16px ${game.accent}40`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon size={24} style={{ color: game.accent }} />
          </div>

          <button
            type="button" onClick={close}
            style={{ position: 'absolute', top: 10, left: 10, width: 30, height: 30, borderRadius: 9, background: 'rgba(0,0,0,0.32)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <ArrowLeft size={15} color="#fff" />
          </button>

          <div ref={menuRef} style={{ position: 'absolute', top: 10, right: 10, zIndex: 2 }}>
            <button
              type="button" onClick={() => setMenuOpen(v => !v)}
              style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(0,0,0,0.32)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
            >
              <MoreVertical size={15} color="#fff" />
            </button>
            {menuOpen && (
              <div style={{
                position: 'absolute', top: 36, right: 0, minWidth: 200, background: 'var(--surface2)',
                border: '1px solid var(--border)', borderRadius: 14, padding: 6,
                boxShadow: 'var(--elev-raise)',
              }}>
                <MenuItem
                  icon={idCopied ? <Check size={14} /> : <Copy size={14} />}
                  label={idCopied ? 'Copied!' : 'Copy Game ID'}
                  onClick={handleCopyId}
                />
                <MenuItem
                  icon={<Star size={14} style={{ color: isFavorite ? '#f5c542' : undefined }} fill={isFavorite ? '#f5c542' : 'none'} />}
                  label={isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                  onClick={() => { onToggleFavorite(); setMenuOpen(false) }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Banner — real image if we have one, otherwise the game's own
            icon blown up on an accent gradient so it's never blank. */}
        <div style={{
          position: 'relative', height: isDesktop ? 180 : 200,
          background: hasBanner ? '#000' : `linear-gradient(135deg, ${game.accent}33, ${game.accent}0d)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
        }}>
          {hasBanner ? (
            <img src={game.bannerUrl} alt={game.name} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center' }} />
          ) : (
            <Icon size={64} style={{ color: game.accent, opacity: 0.7 }} />
          )}
        </div>

        <div style={{ padding: '18px 20px 26px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <h2 style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)' }}>{game.name}</h2>
            {isFavorite && <Star size={15} style={{ color: '#f5c542' }} fill="#f5c542" />}
            {game.requiresPro && <Crown size={14} style={{ color: '#9b6dff' }} />}
          </div>

          {/* Category / players — quick-glance info row, Discord-style */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 12, flexWrap: 'wrap' }}>
            {game.players && (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text-dim)' }}>
                <Users size={12} /> {game.players}
              </span>
            )}
            {game.category && (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text-dim)' }}>
                <Tag size={12} /> {game.category}
              </span>
            )}
          </div>

          {/* About */}
          <p style={{ fontSize: 13, color: 'var(--text-dim)', lineHeight: 1.55, marginBottom: 16 }}>{description}</p>

          {/* Info chips */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
            <span className="chip">{game.unlimitedPlays ? '∞ Unlimited plays' : `${game.maxPlays ?? 7} plays / day`}</span>
            {cost > 1 && (
              <span className="chip" style={{ color: game.accent }}>
                <Zap size={10} style={{ marginRight: 2, verticalAlign: -1 }} /> {cost} sessions
              </span>
            )}
            {game.requiresPro && <span className="chip" style={{ color: '#9b6dff' }}>Pro only</span>}
            {game.tags?.map(tag => (
              <span key={tag} className="chip">{tag}</span>
            ))}
          </div>

          {/* Plunder's leaderboard prize. The detail sheet is the only
              "about this game" screen a player actually sees — Games.tsx
              launches with skipIntro, so the in-game PreGameModal never
              renders from this path. */}
          {game.dbKey === 'plunder' && <PlunderHatCard style={{ marginBottom: 16 }} />}

          {/* Difficulty picker — e.g. Tac Zone's Easy/Hard/Expert. Lives
              here now instead of a second intro screen inside the game
              itself. */}
          {difficultyOptions && (
            <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
              {difficultyOptions.map(opt => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={(e) => { ripple(e); setDifficulty(opt.value) }}
                  style={{
                    flex: 1, padding: '9px 0', borderRadius: 12, fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
                    background: difficulty === opt.value ? `${game.accent}22` : 'var(--surface2)',
                    color: difficulty === opt.value ? game.accent : 'var(--text-dim)',
                    border: difficulty === opt.value ? `1px solid ${game.accent}55` : '1px solid var(--border)',
                  }}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}

          {/* Rank + personal best */}
          <div style={{ marginBottom: 10 }}>
            <RankProgressBar rank={rank} streak={streak} streakRequired={rankCfg.streakRequired} />
          </div>
          {bestStreak > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16 }}>
              <Flame size={12} style={{ color: 'var(--accent2)' }} />
              <span style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>Best streak: <strong style={{ color: 'var(--text-dim)' }}>{bestStreak}</strong></span>
            </div>
          )}

          {staffBypass && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(245,197,66,0.09)', border: '1px solid rgba(245,197,66,0.3)', borderRadius: 12, padding: '10px 12px', marginBottom: 14 }}>
              <Lock size={14} style={{ color: '#f5c542', flexShrink: 0 }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#f5c542' }}>Locked for players — you're in as staff</span>
            </div>
          )}

          {locked && lockedReason && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(155,109,255,0.08)', border: '1px solid rgba(155,109,255,0.25)', borderRadius: 12, padding: '10px 12px', marginBottom: 14 }}>
              <Lock size={14} style={{ color: '#9b6dff', flexShrink: 0 }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#9b6dff' }}>{lockedReason}</span>
            </div>
          )}

          {(() => {
            // Three states, in priority order: an upgrade prompt (a live
            // button that routes to /pro), a "checking" placeholder while the
            // session allowance is being verified, then the usual play/lock.
            const isUpsell = locked && !!onUpgrade
            const isLockedAction = locked && !isUpsell && !!onLockedAction
            const isChecking = !isUpsell && !isLockedAction && busy
            const disabled = isChecking || (locked && !isUpsell && !isLockedAction)
            const filled = isUpsell || isLockedAction || !locked

            return (
              <button
                type="button"
                className="ripple-wrap"
                onClick={(e) => {
                  if (disabled) return
                  ripple(e)
                  if (isUpsell) { onUpgrade!(); return }
                  if (isLockedAction) { onLockedAction!(); return }
                  onPlay(difficulty)
                }}
                disabled={disabled}
                style={{
                  width: '100%', padding: '13px 16px', borderRadius: 14, border: 'none',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  fontSize: 14, fontWeight: 800, cursor: disabled ? 'not-allowed' : 'pointer',
                  background: !filled
                    ? 'var(--surface2)'
                    : isUpsell
                      ? 'linear-gradient(135deg, #9b6dff, #6d4fd6)'
                      : isLockedAction
                        ? 'linear-gradient(135deg, #ff4d6d, #ff8a5c)'
                        : `linear-gradient(135deg, ${game.accent}, ${game.accent}cc)`,
                  color: filled ? '#fff' : 'var(--text-muted)',
                  opacity: isChecking ? 0.7 : 1,
                  boxShadow: !filled
                    ? 'none'
                    : isUpsell
                      ? '0 6px 20px rgba(155,109,255,0.35)'
                      : isLockedAction
                        ? '0 6px 20px rgba(255,77,109,0.32)'
                        : `0 6px 20px ${game.accent}40`,
                }}
              >
                {isUpsell ? <Crown size={15} />
                  : isLockedAction ? <HeartPulse size={15} />
                  : isChecking ? null
                  : locked ? <Lock size={15} />
                  : <Play size={15} fill="#fff" />}
                {isUpsell ? 'See Pro plans'
                  : isLockedAction ? (lockedActionLabel ?? 'Fix this')
                  : isChecking ? 'Checking…'
                  : locked ? 'Locked'
                  : 'Play'}
              </button>
            )
          })()}
        </div>
      </div>
    </div>,
    document.body,
  )
}

function MenuItem({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      type="button" onClick={onClick}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 9, padding: '9px 10px', borderRadius: 9,
        background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
        fontSize: 12.5, fontWeight: 600, color: 'var(--text)',
      }}
      onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface3)')}
      onMouseLeave={e => (e.currentTarget.style.background = 'none')}
    >
      {icon}
      {label}
    </button>
  )
}
