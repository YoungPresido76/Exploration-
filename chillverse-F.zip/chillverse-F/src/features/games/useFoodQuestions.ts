// src/features/games/useFoodQuestions.ts
//
// Fetches food photos + names from TheMealDB (themealdb.com).
// Free, no signup, no card — same deal as Open Trivia DB in
// useTriviaQuestions. We use the public test key `1`.
//
//   NOTE FOR PROD: TheMealDB asks that published apps use a supporter
//   key (one-off £10 on their Patreon) instead of the shared test key.
//   Swap MEALDB_KEY below for VITE_MEALDB_KEY once you have one — the
//   URL shape is identical, only the key segment changes.
//
// Design notes:
//  • We pull whole categories at once (filter.php?c=Seafood returns ~40
//    meals with names + thumbnails in ONE request) instead of hitting
//    random.php per question. 3 requests ≈ 120 candidate meals.
//  • Category payloads are cached in localStorage for 24h, so a player
//    running the game back-to-back does zero network calls after the
//    first round.
//  • Recently-served meals are remembered in a ring buffer so you don't
//    get the same dish twice in a row across sessions.
//  • Images are preloaded before the game starts — a food guessing game
//    where the photo pops in late is unplayable.

import { useState, useCallback, useRef } from 'react'
import type { GameRank } from './play/types'

const MEALDB_KEY  = '1'
const MEALDB_BASE = `https://www.themealdb.com/api/json/v1/${MEALDB_KEY}`

// ── Categories, grouped by how guessable they are ──────────────
// Beginners get visually distinctive stuff (Dessert, Seafood, Pasta).
// Higher ranks get categories where dishes look similar to each other,
// which is what actually makes this hard.
const EASY_CATEGORIES = ['Dessert', 'Seafood', 'Pasta', 'Breakfast', 'Vegetarian']
const HARD_CATEGORIES = ['Beef', 'Chicken', 'Lamb', 'Pork', 'Side', 'Starter', 'Miscellaneous', 'Goat', 'Vegan']

const RANK_CATEGORIES: Record<GameRank, string[]> = {
  beginner:     EASY_CATEGORIES,
  intermediate: [...EASY_CATEGORIES, ...HARD_CATEGORIES.slice(0, 3)],
  advanced:     [...EASY_CATEGORIES.slice(0, 2), ...HARD_CATEGORIES],
  master:       HARD_CATEGORIES,
}

// ── Shapes ─────────────────────────────────────────────────────
interface MealDBMeal {
  idMeal: string
  strMeal: string
  strMealThumb: string
}

export interface FoodQuestion {
  id: string
  /** Full-size photo of the dish */
  image: string
  /** The real name, e.g. "Chicken Fajita Mac and Cheese" */
  answer: string
  /** Where it came from — revealed after the answer, adds a bit of flavour */
  category: string
  /** 4 shuffled options (multiple-choice mode) */
  options: [string, string, string, string]
  correct: 0 | 1 | 2 | 3
  /** Extra strings accepted in type-it mode (see acceptedFor) */
  accepted: string[]
}

export type FetchState = 'idle' | 'loading' | 'ready' | 'error'

// ── localStorage caching ───────────────────────────────────────
const CACHE_PREFIX = 'foodie_cat_'
const CACHE_TTL_MS = 24 * 60 * 60 * 1000
const SEEN_KEY     = 'foodie_seen_ids'
const SEEN_MAX     = 120

interface CachedCategory { at: number; meals: MealDBMeal[] }

function readCache(category: string): MealDBMeal[] | null {
  try {
    const raw = localStorage.getItem(CACHE_PREFIX + category)
    if (!raw) return null
    const parsed = JSON.parse(raw) as CachedCategory
    if (!parsed?.meals?.length || Date.now() - parsed.at > CACHE_TTL_MS) return null
    return parsed.meals
  } catch { return null }
}

function writeCache(category: string, meals: MealDBMeal[]) {
  try {
    localStorage.setItem(CACHE_PREFIX + category, JSON.stringify({ at: Date.now(), meals } as CachedCategory))
  } catch { /* quota — not worth failing the game over */ }
}

function readSeen(): string[] {
  try { return JSON.parse(localStorage.getItem(SEEN_KEY) ?? '[]') as string[] } catch { return [] }
}

function pushSeen(ids: string[]) {
  try {
    const next = [...ids, ...readSeen()].slice(0, SEEN_MAX)
    localStorage.setItem(SEEN_KEY, JSON.stringify(next))
  } catch { /* ignore */ }
}

// ── Helpers ────────────────────────────────────────────────────
function shuffle<T>(arr: T[]): T[] {
  const out = [...arr]
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[out[i], out[j]] = [out[j], out[i]]
  }
  return out
}

async function fetchCategory(category: string): Promise<MealDBMeal[]> {
  const cached = readCache(category)
  if (cached) return cached

  const res = await fetch(`${MEALDB_BASE}/filter.php?c=${encodeURIComponent(category)}`)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  const data = await res.json() as { meals: MealDBMeal[] | null }
  const meals = (data.meals ?? []).filter(m => m.strMeal && m.strMealThumb)
  if (meals.length) writeCache(category, meals)
  return meals
}

/** Preload an image; resolves either way so one dead URL can't hang the game. */
function preload(src: string): Promise<void> {
  return new Promise(resolve => {
    const img = new Image()
    img.onload = () => resolve()
    img.onerror = () => resolve()
    img.src = src
  })
}

/**
 * Extra answers we'll accept in type-it mode. Meal names in TheMealDB are
 * long ("Chicken Fajita Mac and Cheese") and nobody types that on a phone,
 * so we accept the distinctive chunks too. Filler words are dropped so
 * "and", "with", "the" can't be typed to win.
 */
const FILLER = new Set(['and', 'with', 'the', 'a', 'of', 'in', 'on', 'de', 'la', 'style'])

function acceptedFor(name: string): string[] {
  const words = name.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(Boolean)
  const meaningful = words.filter(w => !FILLER.has(w) && w.length >= 4)
  const variants = new Set<string>([name.toLowerCase()])
  // whole name minus filler, e.g. "chicken fajita mac cheese"
  if (meaningful.length) variants.add(meaningful.join(' '))
  // last two meaningful words — usually the actual dish, e.g. "mac cheese"
  if (meaningful.length >= 2) variants.add(meaningful.slice(-2).join(' '))
  // single-word dishes ("Lasagne", "Kumpir") should match on their own
  if (meaningful.length === 1) variants.add(meaningful[0])
  return [...variants]
}

// Distractors should be plausible but not accidentally correct — reject
// any option that shares a strong keyword with the real answer.
function tooSimilar(a: string, b: string): boolean {
  const key = (s: string) => new Set(
    s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(w => w.length >= 5 && !FILLER.has(w)),
  )
  const ka = key(a), kb = key(b)
  for (const w of ka) if (kb.has(w)) return true
  return false
}

// ── Hook ───────────────────────────────────────────────────────
export function useFoodQuestions() {
  const [questions,  setQuestions]  = useState<FoodQuestion[]>([])
  const [fetchState, setFetchState] = useState<FetchState>('idle')
  const [error,      setError]      = useState<string | null>(null)
  const inFlight = useRef(false)

  const fetchQuestions = useCallback(async (rank: GameRank, amount: number) => {
    if (inFlight.current) return
    inFlight.current = true
    setFetchState('loading')
    setError(null)

    try {
      // 3 categories is plenty: ~100+ meals, and it keeps us to at most
      // 3 network calls (usually 0 thanks to the 24h cache).
      const pool = shuffle(RANK_CATEGORIES[rank] ?? EASY_CATEGORIES).slice(0, 3)
      const results = await Promise.all(pool.map(async c => {
        try { return (await fetchCategory(c)).map(m => ({ ...m, category: c })) }
        catch { return [] as (MealDBMeal & { category: string })[] }
      }))

      const all = results.flat()
      if (all.length < 8) throw new Error('Not enough meals returned')

      // Prefer dishes the player hasn't seen recently; fall back to the
      // full pool once they've chewed through it.
      const seen  = new Set(readSeen())
      const fresh = all.filter(m => !seen.has(m.idMeal))
      const source = fresh.length >= amount + 6 ? fresh : all

      const picked = shuffle(source).slice(0, amount)

      const built: FoodQuestion[] = picked.map(meal => {
        const distractors = shuffle(all)
          .filter(m => m.idMeal !== meal.idMeal && !tooSimilar(m.strMeal, meal.strMeal))
          .slice(0, 3)
          .map(m => m.strMeal)

        // Extremely unlikely, but never ship a 2-option "4 options" grid.
        while (distractors.length < 3) distractors.push(shuffle(all)[0].strMeal)

        const options = shuffle([meal.strMeal, ...distractors]) as [string, string, string, string]
        return {
          id:       meal.idMeal,
          image:    meal.strMealThumb,
          answer:   meal.strMeal,
          category: meal.category,
          options,
          correct:  options.indexOf(meal.strMeal) as 0 | 1 | 2 | 3,
          accepted: acceptedFor(meal.strMeal),
        }
      })

      // Preload every photo before we hand the game over. Capped at 6s so
      // a slow connection stalls the round instead of bricking it.
      await Promise.race([
        Promise.all(built.map(q => preload(q.image))),
        new Promise(r => setTimeout(r, 6000)),
      ])

      pushSeen(built.map(q => q.id))
      setQuestions(built)
      setFetchState('ready')
    } catch (err) {
      console.error('[useFoodQuestions]', err)
      setError('Could not load food photos. Check your connection and try again.')
      setFetchState('error')
    } finally {
      inFlight.current = false
    }
  }, [])

  const reset = useCallback(() => {
    setQuestions([])
    setFetchState('idle')
    setError(null)
  }, [])

  return { questions, fetchState, error, fetchQuestions, reset }
}
