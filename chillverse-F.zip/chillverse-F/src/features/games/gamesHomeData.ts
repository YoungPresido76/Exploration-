// src/features/games/gamesHomeData.ts
// Data for the new Games Home page: Trending Now, ranked by two signals —
// recently-added games (NEW) and recently-popular games (HOT).
import { supabase } from '../../shared/lib/supabase'
import { GAMES, type GameMeta } from './games'

// How far back "recent play" counts toward the HOT ranking.
const HOT_WINDOW_DAYS = 10
// A game is tagged NEW if its very first session (all-time) falls within
// this many days of now — i.e. it hasn't been out long, not just quiet.
const NEW_WINDOW_DAYS = 14
const HOT_TAG_TOP_N = 5
const MAX_TRENDING_CARDS = 6

export interface TrendingEntry {
  key: string            // dbKey
  meta: GameMeta
  playerCount: number     // distinct players in the HOT_WINDOW_DAYS window
  isHot: boolean
  isNew: boolean
}

interface GameStatsRow {
  game: string
  players_in_window: number
  first_played_at: string | null
}

/**
 * Trending Now = the games worth surfacing right now, for one of two
 * reasons: they just shipped (NEW — first ever session within
 * NEW_WINDOW_DAYS) or they're getting played a lot right now (HOT — top
 * HOT_TAG_TOP_N by distinct players within HOT_WINDOW_DAYS). NEW games lead
 * the row, then HOT games, then the row is topped up with the next
 * most-played games (untagged) up to MAX_TRENDING_CARDS so the row doesn't
 * look sparse on a quiet day.
 *
 * Solo catalog only — multiplayer titles (Chess, Ludo) live under
 * /multiplayer and no longer surface here, since they routed around the
 * Pro-subscription gate when picked up from this row.
 */
export async function fetchTrendingGames(): Promise<TrendingEntry[]> {
  const since = new Date(Date.now() - HOT_WINDOW_DAYS * 24 * 60 * 60 * 1000).toISOString()
  const newCutoff = Date.now() - NEW_WINDOW_DAYS * 24 * 60 * 60 * 1000

  const { data, error } = await supabase.rpc('get_trending_game_stats', { p_window_start: since })
  const stats = new Map<string, GameStatsRow>()
  if (!error && data) {
    for (const row of data as GameStatsRow[]) stats.set(row.game, row)
  }

  const isRecentlyAdded = (g: GameMeta) => {
    const firstPlayed = stats.get(g.dbKey)?.first_played_at
    return !!firstPlayed && new Date(firstPlayed).getTime() >= newCutoff
  }

  const ranked = GAMES
    .map(g => ({ game: g, playerCount: stats.get(g.dbKey)?.players_in_window ?? 0 }))
    .sort((a, b) => b.playerCount - a.playerCount)

  const hotKeys = new Set(ranked.filter(r => r.playerCount > 0).slice(0, HOT_TAG_TOP_N).map(r => r.game.dbKey))

  const newGames = GAMES.filter(isRecentlyAdded)
  const hotGames = ranked.filter(r => hotKeys.has(r.game.dbKey) && !isRecentlyAdded(r.game)).map(r => r.game)

  const ordered: GameMeta[] = [...newGames, ...hotGames]

  // Top the row up with the next most-played games so it doesn't look thin
  // when there's little recent activity.
  for (const { game } of ranked) {
    if (ordered.length >= MAX_TRENDING_CARDS) break
    if (ordered.some(g => g.dbKey === game.dbKey)) continue
    ordered.push(game)
  }

  return ordered.slice(0, MAX_TRENDING_CARDS).map(game => ({
    key: game.dbKey,
    meta: game,
    playerCount: stats.get(game.dbKey)?.players_in_window ?? 0,
    isHot: hotKeys.has(game.dbKey),
    isNew: isRecentlyAdded(game),
  }))
}
