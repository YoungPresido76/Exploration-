// src/pages/Games.tsx
import { useState, useEffect, useCallback, useRef } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Lock } from 'lucide-react'
import {
  getPlaysToday, saveGameSession, savePlayerRank, getAllPlayerRanks,
  getGlobalSessionInfo, tryConsumeSession, type GameKey,
} from './gameSession'
import { GAMES, type GameId, type GameMeta } from './games'
import { useAuth } from '../auth/useAuth'
import { useProfile } from '../profile/useProfile'
import { getSessionLimits, isProActive } from '../../shared/lib/proPlans'
import Toast, { useToast } from '../../shared/components/Toast'
import { triggerAchievementCheck } from '../achievements/triggerAchievements'
import { updateMissionProgress } from '../missions/weeklyMissions'
import type { GameRank } from './play/types'
import type { GameEndPayload } from './play/types'
import PageOnboarding from '../onboarding/PageOnboarding'
import GameDetailModal from './GameDetailModal'
import { savePinnedGames } from './favorites'
import { useFeatureFlags } from '../../shared/lib/featureFlags'
import { useModRole } from '../moderation/useModRole'
import { useCelebrationBlock } from '../levelup/useLevelUp'
import { useMyPvpStatus } from '../pvp/useMyPvpStatus'
import PvpDownModal, { PVP_DOWN_MESSAGE } from '../pvp/PvpDownModal'

// ── Game imports ─────────────────────────────────────────────
import ArrowDash from './play/ArrowDash'
import PatternMemory from './play/PatternMemory'
import RapidSort from './play/RapidSort'
import TriviaClash from './play/TriviaClash'
import TacZone from './play/TacZone'
import TwoTruthsOneFalse from './play/TwoTruthsOneFalse'
import SpeedMath from './play/SpeedMath'
import LiarsGrid from './play/LiarsGrid'
import Hangman from './play/Hangman'
import CloseCall from './play/CloseCall'
import PatternKing from './play/PatternKing'
import Uno from './play/Uno'
import ColourBlock from './play/ColourBlock'
import TileMerge from './play/TileMerge'
import Foodie from './play/Foodie'
import TheLastSamurai from './play/TheLastSamurai'
import Elementa from './play/Elementa'
import ChillLink from './play/ChillLink'
import Plunder from './play/Plunder'
import WordBlitz from './play/WordBlitz'

// ─── Constants ───────────────────────────────────────────────
const MAX_PLAYS    = 7

/** The daily play cap for one game. Most games use the shared default;
 *  a game can ration itself harder via `maxPlays` in games.ts. */
function playCapFor(meta: GameMeta): number {
  return meta.maxPlays ?? MAX_PLAYS
}

// ─── Main component ───────────────────────────────────────────
export default function Games({ onBack, openGameId, onFavoritesChanged }: { onBack?: () => void; openGameId?: GameId | null; onFavoritesChanged?: () => void } = {}) {
  const navigate  = useNavigate()
  const location  = useLocation()
  const { session } = useAuth()
  const userId = session?.user?.id ?? null
  const { profile, loading: profileLoading, refetch: refetchProfile } = useProfile()
  const { isEnabled: isFlagEnabled, getFlag: getFeatureFlag } = useFeatureFlags()
  // Staff bypass the game kill switches, same posture FeatureFlagGate already
  // takes for the Feed / Highlights / Lab flags. Locking a game is a decision
  // about what players can reach, not a reason to stop the people who threw
  // the switch from testing what they just turned off.
  const { isStaff } = useModRole()
  // Being knocked out in PvP locks you out of games until you regenerate.
  // Deliberately NOT bypassed for staff: this is a game-state consequence,
  // not an admin kill switch, and staff play under the same rules.
  const { down: pvpDown } = useMyPvpStatus()
  const [showPvpDown, setShowPvpDown] = useState(false)
  const { limit: GLOBAL_LIMIT, cooldownHours: SESSION_COOLDOWN_HRS } = getSessionLimits(profile)
  const isPro = isProActive(profile)
  const { toast, showToast } = useToast()

  const [activeGame, setActiveGame]   = useState<GameId | null>(null)

  // Hold off any LEVEL UP celebration for as long as a game is open.
  // `activeGame` stays set through the whole session — the game itself
  // AND the win/lose ResultScreen that follows it — so this single block
  // covers both. It's released when the player taps Done/Play Again back
  // to the lobby, at which point the queued overlay pops. See
  // src/features/levelup/levelUpBus.ts.
  useCelebrationBlock(activeGame !== null, 'solo-game')
  const [selectedGame, setSelectedGame] = useState<GameId | null>(null)
  const [activeDifficulty, setActiveDifficulty] = useState<string | undefined>(undefined)
  const [favorites, setFavorites] = useState<Set<GameId>>(new Set())

  // Pinned games live on the profile row (private, per-user), not
  // localStorage — so they follow the player across devices. `profile`
  // is already fetched by useProfile() for isPro/pro_tier above, so this
  // just mirrors its pinned_games column into local Set state whenever
  // it (re)loads, rather than firing a second network request.
  useEffect(() => {
    setFavorites(new Set((profile?.pinned_games ?? []) as GameId[]))
  }, [profile?.pinned_games])

  const toggleFavorite = useCallback((id: GameId) => {
    if (!userId) return
    setFavorites(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      savePinnedGames(userId, next)
        .then(() => { refetchProfile(); onFavoritesChanged?.() })
        .catch(console.error)
      return next
    })
  }, [userId, refetchProfile, onFavoritesChanged])

  const [playsToday,  setPlaysToday]  = useState<Partial<Record<GameId, number>>>({})
  const [ranks,       setRanks]       = useState<Partial<Record<GameId, GameRank>>>({})
  const [streaks,     setStreaks]     = useState<Partial<Record<GameId, number>>>({})
  const [allTimeStreaks, setAllTimeStreaks] = useState<Partial<Record<GameId, number>>>({})
  // Two separate loads feed the lock check — per-game play counts and the
  // global session allowance — and the gate needs BOTH plus the profile
  // (which decides the tier's limit and Pro access). A single `dataLoaded`
  // flag set from the plays fetch alone left the session count at its
  // initial 0 while claiming to be ready.
  const [playsLoaded,   setPlaysLoaded]   = useState(false)
  const [sessionLoaded, setSessionLoaded] = useState(false)
  const [globalCount, setGlobalCount] = useState(0)
  const [, setGlobalReset] = useState(0)
  const [launching, setLaunching] = useState(false)
  const launchingRef = useRef(false)
  const gateReady = playsLoaded && sessionLoaded && !profileLoading

  // Set only by launchGame(), after the server has confirmed there's room.
  // handleResult refuses to bank anything for a run that isn't listed here,
  // so a game somehow started outside that path earns nothing.
  const authorizedGame = useRef<GameId | null>(null)

  // In-app browsing (Trending Now / Favorite Games / Categories, from
  // GamesZone) hands the id straight through as a prop instead of a
  // router deep link — this always opens the detail sheet (GameDetailModal)
  // first, same screen every time, never this page's own old grid.
  useEffect(() => {
    if (openGameId) setSelectedGame(openGameId)
  }, [openGameId])

  const refreshGlobalInfo = useCallback(async () => {
    if (!userId) return
    const info = await getGlobalSessionInfo(userId, GLOBAL_LIMIT)
    // Mark the load done either way. If we held this false on a failed read
    // the gate below would sit on "Checking your sessions…" forever with the
    // button disabled — a network blip would brick the whole games list until
    // a reload. On failure the counts stay at their defaults, which reads as
    // unlocked, and launchGame's own server check is what actually decides.
    setSessionLoaded(true)
    if (!info.ok) return          // a failed read is not "0 sessions used"
    setGlobalCount(info.count)
    setGlobalReset(info.resetAt)
  }, [userId, GLOBAL_LIMIT])

  /**
   * The one way into a game. Every caller — the detail sheet's Play button,
   * deep links from post tags and the Multiplayer hub — goes through here.
   *
   * The checks are re-run against the server at the moment of the tap rather
   * than read off component state, because state is exactly what's unreliable
   * here: it's zero-until-loaded (tap fast enough and nothing was locked yet)
   * and it goes stale the moment the player has a second tab open. The button
   * is also held in a "checking" state for the duration so it can't be
   * double-fired while the round-trip is in flight.
   */
  const launchGame = useCallback(async (id: GameId, difficulty?: string) => {
    const meta = GAMES.find(g => g.id === id)
    if (!meta || !userId) return

    // Re-entrancy is guarded with a ref, not the `launching` state below.
    // Two taps landing in the same frame both read the same pre-update state
    // value and both sail past it; a ref is written synchronously, so the
    // second tap sees the first. The state only drives the button's
    // disabled/"Checking…" appearance.
    if (launchingRef.current) return
    launchingRef.current = true

    try {
      // Checked before every other gate so a downed player gets the reason
      // that actually applies, not "Pro game" or a session-limit toast.
      if (pvpDown) {
        setShowPvpDown(true)
        return
      }
      if (!isFlagEnabled(`game:${meta.dbKey}`) && !isStaff) {
        showToast({ message: 'This game is temporarily unavailable', icon: Lock, iconColor: 'var(--text-muted)' })
        return
      }
      if (meta.requiresPro && !isPro) {
        showToast({ message: `${meta.name} is a Pro game`, icon: Lock, iconColor: '#9b6dff' })
        navigate('/pro')
        return
      }

      setLaunching(true)
      const cost = meta.sessionCost ?? 1
      const [info, plays] = await Promise.all([
        getGlobalSessionInfo(userId, GLOBAL_LIMIT),
        meta.unlimitedPlays ? Promise.resolve(0) : getPlaysToday(userId, meta.dbKey),
      ])

      setSessionLoaded(true)
      if (!info.ok) {
        showToast({ message: "Couldn't check your sessions — try again", icon: Lock, iconColor: 'var(--red, #ff4f4f)' })
        return
      }

      setGlobalCount(info.count)
      setGlobalReset(info.resetAt)
      if (!meta.unlimitedPlays) setPlaysToday(p => ({ ...p, [id]: plays }))

      if (info.count + cost > GLOBAL_LIMIT) {
        showToast({ message: 'Not enough sessions left', icon: Lock, iconColor: '#9b6dff' })
        return
      }
      // Staff bypass the daily cap, matching the posture they already have
      // on feature-flag gates — a locked game still opens for them.
      if (!meta.unlimitedPlays && !isStaff && plays >= playCapFor(meta)) {
        showToast({
          message: meta.limitMessage ?? `Daily limit reached for ${meta.name}`,
          icon: Lock, iconColor: '#9b6dff',
        })
        return
      }

      authorizedGame.current = id
      setSelectedGame(null)
      setActiveDifficulty(difficulty)
      setActiveGame(id)
    } finally {
      launchingRef.current = false
      setLaunching(false)
    }
  }, [userId, isFlagEnabled, isStaff, isPro, pvpDown, GLOBAL_LIMIT, navigate, showToast])

  // Deep-link support: navigate('/games', { state: { openGame: 'tac-zone' } })
  // lets a post's game tag, or Multiplayer's "Vs AI" hub (which already
  // shows its own brief pre-game sheet), jump straight into that game.
  // launchGame applies the same Pro / daily-play / session checks the Play
  // button does, so this path can't be used to step around them.
  useEffect(() => {
    const openGame = (location.state as { openGame?: GameId } | null)?.openGame
    if (!openGame || !gateReady) return

    launchGame(openGame)

    // Clear the pending nav state either way, so this can't re-fire or be raced.
    navigate(location.pathname, { replace: true, state: null })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gateReady])

  useEffect(() => {
    if (!userId) return
    refreshGlobalInfo()
    Promise.all(GAMES.map(g => getPlaysToday(userId, g.dbKey))).then(counts => {
      const map: Partial<Record<GameId, number>> = {}
      GAMES.forEach((g, i) => { map[g.id] = counts[i] })
      setPlaysToday(map)
      setPlaysLoaded(true)
    })
    getAllPlayerRanks(userId).then(allRanks => {
      const rankMap:    Partial<Record<GameId, GameRank>> = {}
      const streakMap:  Partial<Record<GameId, number>>   = {}
      const allTimeMap: Partial<Record<GameId, number>>   = {}
      GAMES.forEach(g => {
        const row = allRanks[g.dbKey as GameKey]
        rankMap[g.id]    = row?.rank ?? 'beginner'
        streakMap[g.id]  = row?.current_streak ?? 0
        allTimeMap[g.id] = row?.all_time_streak ?? 0
      })
      setRanks(rankMap)
      setStreaks(streakMap)
      setAllTimeStreaks(allTimeMap)
    })
  }, [userId])

  async function handleResult(payload: GameEndPayload) {
    const game = GAMES.find(g => g.id === payload.gameId)
    if (!game || !userId) return

    // Only a run that launchGame() cleared can bank anything. This is what
    // stops the reported "tap Play before it loads and you still get XP" —
    // the run may have started, but the result goes nowhere.
    if (authorizedGame.current !== payload.gameId) {
      console.warn('[Games] discarding result from an unauthorized run:', payload.gameId)
      return
    }

    const cost = game.sessionCost ?? 1

    // Consume BEFORE saving, and let the server decide. try_consume_session
    // refuses instead of incrementing past the cap, which also covers the
    // paths the launch check can't see: replaying from the result screen
    // (that stays inside the game component) and a second tab burning the
    // same allowance.
    const consumed = await tryConsumeSession(userId, cost, GLOBAL_LIMIT, SESSION_COOLDOWN_HRS)
    if (consumed) {
      setGlobalCount(consumed.count)
      setGlobalReset(consumed.resetAt)
      if (!consumed.allowed) {
        // Allowance ran out mid-run. Nothing was charged and nothing is
        // saved — no session row, no XP, no mission or achievement progress.
        authorizedGame.current = null
        return
      }
    } else {
      // Couldn't reach the server. That's "unknown", not "denied" — the
      // launch check already passed, so let the result through and reconcile
      // the counter on the next read.
      refreshGlobalInfo()
    }

    setPlaysToday(p => ({ ...p, [payload.gameId]: (p[payload.gameId as GameId] ?? 0) + 1 }))
    setRanks(r => ({ ...r, [payload.gameId]: payload.rank }))
    setStreaks(s => ({ ...s, [payload.gameId]: payload.streak }))
    setAllTimeStreaks(a => ({ ...a, [payload.gameId]: Math.max(payload.streak, a[payload.gameId as GameId] ?? 0) }))

    await saveGameSession(userId, {
      game: game.dbKey,
      score: payload.score,
      xpEarned: payload.xpEarned,
      durationSec: payload.durationSec,
      rank: payload.rank,
      streak: payload.streak,
      metadata: payload.detail as Record<string, unknown>,
    })

    await savePlayerRank(userId, game.dbKey, payload.rank, payload.streak,
      Math.max(payload.streak, allTimeStreaks[payload.gameId as GameId] ?? 0))

    // Fire achievement check in background
    triggerAchievementCheck(userId).catch(console.error)

    // NOTE: referral crediting used to happen here (first completed game),
    // but that was replaced by immediate server-side crediting at account
    // creation — see handle_new_user() in migration 0093. This call is
    // dead code now, removed to fix the build.

    // ── Weekly mission progress ──────────────────────────────
    updateMissionProgress(userId, 'sessions_played', 1).catch(console.error)

    if (payload.score > 0) {
      updateMissionProgress(userId, 'games_won', 1).catch(console.error)
    }

    if (payload.streak >= 3) {
      updateMissionProgress(userId, 'win_streak', payload.streak, true).catch(console.error)
    }

    updateMissionProgress(userId, 'unique_games_played', 1).catch(console.error)

    const gameMetricMap: Partial<Record<GameId, string[]>> = {
      'hangman':        ['hangman_played'],
      'speed-math':     ['speed_math_played'],
      'pattern-memory': ['pattern_memory_played'],
      'arrow-dash':     ['arrow_dash_played'],
      'rapid-sort':     ['rapid_sort_played'],
      'tac-zone':       ['tac_zone_played'],
      'two-truths':     ['two_truths_played'],
      'liars-grid':     ['liars_grid_played'],
      'trivia-clash':   ['trivia_clash_played'],
      'close-call':     ['close_call_played'],
      'pattern-king':   ['pattern_king_played'],
      'colour-block':   ['colour_block_played'],
      'tile-merge':     ['tile_merge_played'],
      'foodie':         ['foodie_played'],
      'word-blitz':     ['word_blitz_played'],
    }
    const extraMetrics = gameMetricMap[payload.gameId as GameId]
    if (extraMetrics) {
      for (const mk of extraMetrics) {
        updateMissionProgress(userId, mk, 1).catch(console.error)
      }
    }

    if (payload.gameId === 'hangman' && payload.correct > 0) {
      updateMissionProgress(userId, 'hangman_correct', payload.correct).catch(console.error)
    }

    if (payload.gameId === 'speed-math' && payload.total > 0) {
      const acc = Math.round((payload.correct / payload.total) * 100)
      if (acc >= 80) updateMissionProgress(userId, 'speed_math_80pct', 1).catch(console.error)
    }

    if (payload.gameId === 'pattern-memory' && payload.correct === payload.total && payload.total > 0) {
      updateMissionProgress(userId, 'pattern_memory_perfect', 1).catch(console.error)
    }

    if (payload.gameId === 'uno' && payload.score > 0) {
      updateMissionProgress(userId, 'uno_won', 1).catch(console.error)
    }

    updateMissionProgress(userId, 'games_today', 1).catch(console.error)

    if (payload.xpEarned > 0) {
      updateMissionProgress(userId, 'xp_earned', payload.xpEarned).catch(console.error)
    }

    refreshGlobalInfo()
  }

  const activeGameDef = activeGame ? GAMES.find(g => g.id === activeGame) : null
  const sessionsLeft = Math.max(0, GLOBAL_LIMIT - globalCount)

  const gameProps = {
    rank: (activeGame ? (ranks[activeGame] ?? 'beginner') : 'beginner') as GameRank,
    streak: activeGame ? (streaks[activeGame] ?? 0) : 0,
    onEnd: handleResult,
    onBack: () => { authorizedGame.current = null; setActiveGame(null); onBack?.() },
    sessionsLeft,
    sessionCost: activeGameDef?.sessionCost ?? 1,
    // Every solo game launch here is always preceded by an equivalent
    // intro — either GameDetailModal (image1-style detail sheet) or,
    // for deep-linked entries (a post's game tag, Multiplayer's "Vs AI"
    // hub sheet), the screen that sent the player here. So the game's
    // own internal info/rules screen would just be a redundant second
    // intro — skip it every time.
    skipIntro: true,
  }
  const tacZoneProps = { ...gameProps, initialMode: activeDifficulty as 'easy' | 'hard' | 'expert' | undefined }
  // Foodie reuses the same detail-sheet choice slot for its answer mode
  // (4 Options vs Type It) rather than showing a second intro screen.
  const foodieProps  = { ...gameProps, initialMode: (activeDifficulty === 'type' ? 'type' : 'choice') as 'choice' | 'type' }

  if (activeGame === 'arrow-dash')     return <ArrowDash         {...gameProps} />
  if (activeGame === 'pattern-memory') return <PatternMemory     {...gameProps} />
  if (activeGame === 'rapid-sort')     return <RapidSort         {...gameProps} />
  if (activeGame === 'trivia-clash')   return <TriviaClash       {...gameProps} />
  if (activeGame === 'tac-zone')       return <TacZone           {...tacZoneProps} />
  if (activeGame === 'two-truths')     return <TwoTruthsOneFalse {...gameProps} />
  if (activeGame === 'speed-math')     return <SpeedMath         {...gameProps} />
  if (activeGame === 'liars-grid')     return <LiarsGrid         {...gameProps} />
  if (activeGame === 'hangman')        return <Hangman           {...gameProps} />
  if (activeGame === 'close-call')     return <CloseCall         {...gameProps} />
  if (activeGame === 'pattern-king')   return <PatternKing       {...gameProps} />
  if (activeGame === 'uno')            return <Uno                {...gameProps} />
  if (activeGame === 'colour-block')   return <ColourBlock         {...gameProps} />
  if (activeGame === 'tile-merge')     return <TileMerge           {...gameProps} />
  if (activeGame === 'foodie')         return <Foodie              {...foodieProps} />
  if (activeGame === 'the-last-samurai') return <TheLastSamurai   {...gameProps} />
  if (activeGame === 'elementa')       return <Elementa            {...gameProps} />
  if (activeGame === 'chill-link')     return <ChillLink           {...gameProps} />
  if (activeGame === 'plunder')        return <Plunder             {...gameProps} />
  if (activeGame === 'word-blitz')     return <WordBlitz           {...gameProps} />

  return (
    <div>
      <PageOnboarding pageKey="games" />

      {selectedGame && (() => {
        const meta = GAMES.find(g => g.id === selectedGame)
        if (!meta) return null
        const cost = meta.sessionCost ?? 1
        // requiresPro was only ever decoration — a crown on the card and a
        // "Pro only" chip — with nothing checking it, so Uno and Colour Block
        // were fully playable on a free account from the Games Zone. This is
        // the check that was missing. Held off until the profile has loaded
        // so a subscriber doesn't get told to upgrade during the fetch.
        const needsPro = !profileLoading && !!meta.requiresPro && !isPro
        const maxed = gateReady && !meta.unlimitedPlays && !isStaff && (playsToday[selectedGame] ?? 0) >= playCapFor(meta)
        const notEnoughSessions = gateReady && (globalCount + cost > GLOBAL_LIMIT)
        // The flag being off and the game being locked are now two different
        // things: staff see the notice but keep the Play button.
        const flagOff = !isFlagEnabled(`game:${meta.dbKey}`)
        const disabledByFlag = flagOff && !isStaff
        // Locked until proven otherwise. Previously the limit checks were
        // gated on the data having loaded, which left the button live and
        // playable during the fetch — the window the session-limit bypass
        // lived in.
        const locked = pvpDown || !gateReady || needsPro || maxed || notEnoughSessions || disabledByFlag
        // An admin-written lock message (Ops console → feature flag → gate
        // editor) wins over the generic copy, so turning a game off can say
        // *why* instead of a flat "unavailable".
        const flagGate = getFeatureFlag(`game:${meta.dbKey}`)
        const lockedReason = pvpDown
          ? PVP_DOWN_MESSAGE
          : disabledByFlag
          ? (flagGate?.gate_message || flagGate?.gate_title || 'Temporarily unavailable')
          : needsPro
          ? 'Pro only — needs Orbit or Void'
          : !gateReady
          ? 'Checking your sessions…'
          : maxed
          ? (meta.limitMessage ?? 'Daily limit reached')
          : notEnoughSessions
            ? 'Not enough sessions left'
            : null

        return (
          <GameDetailModal
            game={meta}
            rank={(ranks[selectedGame] ?? 'beginner') as GameRank}
            streak={streaks[selectedGame] ?? 0}
            bestStreak={allTimeStreaks[selectedGame] ?? 0}
            isFavorite={favorites.has(selectedGame)}
            onToggleFavorite={() => toggleFavorite(selectedGame)}
            locked={locked}
            lockedReason={lockedReason}
            staffBypass={flagOff && isStaff && !pvpDown}
            busy={launching || (!gateReady && !needsPro && !disabledByFlag && !pvpDown)}
            onUpgrade={needsPro && !pvpDown ? () => navigate('/pro') : undefined}
            onLockedAction={pvpDown ? () => setShowPvpDown(true) : undefined}
            lockedActionLabel="Regenerate"
            onPlay={(difficulty) => launchGame(selectedGame, difficulty)}
            onClose={() => { setSelectedGame(null); if (onBack) onBack() }}
          />
        )
      })()}

      {showPvpDown && (
        <PvpDownModal
          userId={userId}
          action="play games"
          onClose={() => setShowPvpDown(false)}
        />
      )}

      <Toast toast={toast} />
    </div>
  )
}
