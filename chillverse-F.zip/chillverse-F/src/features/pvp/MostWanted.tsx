// src/features/pvp/MostWanted.tsx
//
// Public board of every player currently at 4+ stars — the bulk view of
// what WantedLevel already shows one-at-a-time on a PvP profile. Anyone
// hitting the threshold lands here automatically; there's nothing to
// opt into or out of, same as stars themselves.
//
// Data comes from get_most_wanted() (0118_most_wanted_board.sql), which
// mirrors get_pvp_state()'s read pattern: stars and HP are computed at
// read time, not stored, so what's on screen is never stale the way a
// cached snapshot would be.
import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { AlertTriangle, ArrowUpDown, Flame, Info, Skull, Swords, Trophy } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { getUserRankTier } from '../profile/ranks'
import Avatar from '../../shared/components/Avatar'
import AttackSheet from './AttackSheet'
import { getMostWanted, type MostWantedEntry } from './pvp'
import ClubBoard from './ClubBoard'
import EliminationBoard from './EliminationBoard'
import { refreshElimination } from './useElimination'
import BountyBoard from './BountyBoard'

type SortMode = 'stars' | 'hp'
type ArenaTab = 'wanted' | 'clubs' | 'elimination'

const TIER: Record<number, { label: string; color: string; softGlow: string }> = {
  4: { label: 'WANTED',       color: '#f5a742', softGlow: 'rgba(245,167,66,0.08)' },
  5: { label: 'MOST WANTED',  color: '#ff8a3d', softGlow: 'rgba(255,138,61,0.08)' },
  6: { label: 'PUBLIC ENEMY', color: '#ff4d6d', softGlow: 'rgba(255,77,109,0.08)' },
}

function tierFor(stars: number) {
  return TIER[Math.min(stars, 6)] ?? TIER[4]
}

function timeAgo(iso: string | null): string {
  if (!iso) return 'a while ago'
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`
  return new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short' })
}

function StarRow({ stars, color }: { stars: number; color: string }) {
  return (
    <div style={{ display: 'flex', gap: 2 }}>
      {Array.from({ length: 6 }, (_, i) => {
        const filled = i < stars
        return (
          <svg key={i} width={12} height={12} viewBox="0 0 24 24"
            fill={filled ? color : 'var(--surface3)'}
            style={{ filter: filled ? `drop-shadow(0 0 3px ${color}99)` : 'none' }}>
            <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.7 7-6.3-3.9L5.7 21l1.7-7L2 9.2l7.1-.6z" />
          </svg>
        )
      })}
    </div>
  )
}

function WantedCard({
  entry, isMe, onAttack,
}: { entry: MostWantedEntry; isMe: boolean; onAttack: (entry: MostWantedEntry) => void }) {
  const tier = tierFor(entry.stars)
  const rank = getUserRankTier(entry.active_rank_xp)
  const name = entry.display_name || entry.username
  const hpPct = entry.max_hp > 0 ? Math.round((entry.hp / entry.max_hp) * 100) : 0

  return (
    <div className="neu-card" style={{
      position: 'relative', display: 'flex', gap: 12, alignItems: 'center',
      padding: 14, borderRadius: 16,
      border: `1px solid ${tier.color}33`,
      background: `linear-gradient(150deg, ${tier.softGlow}, var(--surface))`,
    }}>
      <div style={{
        position: 'absolute', top: 10, right: 12, transform: 'rotate(-8deg)',
        border: `1.5px solid ${tier.color}`, borderRadius: 6, padding: '2px 6px',
        color: tier.color, fontSize: 8.5, fontWeight: 800, letterSpacing: 0.8,
        textTransform: 'uppercase', background: 'var(--surface)',
      }}>
        {tier.label}
      </div>

      <Avatar src={entry.avatar} name={name} userId={entry.user_id} size={48} />

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <p style={{ fontSize: 14.5, fontWeight: 800, color: 'var(--text)', margin: 0 }}>{name}</p>
          <span style={{ fontSize: 10.5, fontWeight: 700, color: rank.color }}>{rank.name}</span>
        </div>
        {/* last_attack_at is THIS player's own last strike on someone —
            not when the viewer last hit them, and unrelated to the
            viewer's own per-target cooldown with this player (that's
            checked separately, in AttackSheet, right before an attack).
            Worded as "last on the attack" rather than "last attacked" so
            it doesn't read as if it's about the viewer's own cooldown. */}
        <p style={{ fontSize: 10.5, color: 'var(--text-dim)', margin: '1px 0 7px' }}>
          @{entry.username} · last on the attack {timeAgo(entry.last_attack_at)}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <StarRow stars={entry.stars} color={tier.color} />
          <div style={{
            flex: 1, height: 5, borderRadius: 3, background: 'var(--surface3)',
            boxShadow: 'var(--elev-inset)', overflow: 'hidden', minWidth: 36,
          }}>
            <div style={{
              width: `${hpPct}%`, height: '100%', borderRadius: 3,
              background: hpPct <= 33 ? '#ff4d6d' : hpPct <= 66 ? '#f5a742' : '#3ecf8e',
            }} />
          </div>
          <span style={{ fontSize: 10, color: 'var(--text-dim)', fontWeight: 700, flexShrink: 0 }}>{entry.hp} HP</span>
        </div>
      </div>

      {isMe ? (
        <span style={{
          flexShrink: 0, fontSize: 9.5, fontWeight: 800, color: 'var(--text-dim)',
          textTransform: 'uppercase', letterSpacing: 0.5, padding: '0 4px', textAlign: 'center',
        }}>
          This is you
        </span>
      ) : (
        <button
          type="button"
          onClick={() => onAttack(entry)}
          aria-label={`Attack ${name}`}
          style={{
            flexShrink: 0, width: 38, height: 38, borderRadius: 11, border: 'none', cursor: 'pointer',
            display: 'grid', placeItems: 'center',
            background: `linear-gradient(135deg, ${tier.color}, #ff4d6d)`,
            boxShadow: `0 4px 14px ${tier.color}55`,
          }}
        >
          <Swords size={16} color="#fff" />
        </button>
      )}
    </div>
  )
}

export default function MostWanted() {
  const { user } = useAuth()
  const myUserId = user?.id ?? ''

  const [entries, setEntries] = useState<MostWantedEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sortBy, setSortBy] = useState<SortMode>('stars')
  // The screen is now Arena, with Most Wanted as its first board. Kept on
  // the existing /most-wanted route deliberately: the dock, deep links and
  // several notification routes already point there, and renaming the URL
  // would break every one of them for no gain.
  //
  // The board is picked by ?tab= rather than by local state alone, so a
  // notification can deep-link straight to the round a player was just
  // knocked out of. Unknown values fall through to Most Wanted.
  const [params, setParams] = useSearchParams()
  const requested = params.get('tab')
  const tab: ArenaTab =
    requested === 'clubs' || requested === 'elimination' ? requested : 'wanted'

  function setTab(next: ArenaTab) {
    // replace, not push: flicking between boards should not stack up
    // history entries the back gesture then has to walk through.
    setParams(next === 'wanted' ? {} : { tab: next }, { replace: true })
  }
  const [target, setTarget] = useState<MostWantedEntry | null>(null)
  // Board explanation used to live as two permanent blocks of copy (an
  // intro paragraph up top, a decay-rule footnote at the bottom). Both are
  // folded into this single popover behind the info icon instead, so the
  // page reads as a leaderboard first and an explainer only on request.
  const [infoOpen, setInfoOpen] = useState(false)

  useEffect(() => {
    let active = true
    async function load() {
      setLoading(true)
      setError(null)
      try {
        const rows = await getMostWanted()
        if (active) setEntries(rows)
      } catch (err) {
        if (active) setError(err instanceof Error ? err.message : 'Could not load the board.')
      } finally {
        if (active) setLoading(false)
      }
    }
    load()
    return () => { active = false }
  }, [])

  const sorted = useMemo(() => {
    const list = [...entries]
    if (sortBy === 'stars') list.sort((a, b) => b.stars - a.stars || a.hp - b.hp)
    else list.sort((a, b) => a.hp - b.hp)
    return list
  }, [entries, sortBy])

  function handleResolved() {
    setTarget(null)
    getMostWanted().then(setEntries).catch(() => {})
    // An attack launched from the Elimination board changes HP, kills, the
    // pot and possibly the survivor count. Refreshing the shared store is
    // what makes that board re-read itself — it keys its own fetch on the
    // status object.
    refreshElimination()
  }

  return (
    <div style={{ padding: '16px 16px 40px' }}>
      <div style={{ position: 'relative', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Swords size={18} color="#ff4d6d" />
          <h1 style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0, flex: 1 }}>Arena</h1>
          {tab === 'wanted' && <div style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', borderRadius: 20,
            background: 'rgba(255,77,109,0.12)', border: '1px solid rgba(255,77,109,0.3)', flexShrink: 0,
          }}>
            <Flame size={12} color="#ff4d6d" />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: '#ff4d6d' }}>
              {loading ? '…' : `${entries.length} wanted`}
            </span>
          </div>}
          {tab === 'wanted' && <button
            type="button"
            onClick={() => setInfoOpen(v => !v)}
            aria-label="How Most Wanted works"
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              width: 26, height: 26, borderRadius: '50%', cursor: 'pointer',
              background: infoOpen ? 'var(--surface3)' : 'var(--surface)',
              border: `1px solid ${infoOpen ? 'var(--border-strong)' : 'var(--border)'}`,
              color: 'var(--text-dim)',
            }}
          >
            <Info size={13} />
          </button>}
        </div>

        {/* Combined explainer — everything the old intro paragraph and the
            bottom decay-rule footnote used to say, in one place, shown only
            when asked for. */}
        {infoOpen && (
          <>
            <div style={{ position: 'fixed', inset: 0, zIndex: 99 }} onClick={() => setInfoOpen(false)} />
            <div style={{
              position: 'absolute', top: '100%', right: 0, marginTop: 8, zIndex: 100,
              width: 250, padding: '12px 14px', borderRadius: 14,
              background: 'var(--surface2)', border: '1px solid var(--border)',
              boxShadow: 'var(--elev-popover)',
            }}>
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.55 }}>
                Hit 4 stars or more in PvP and you're on this board automatically — every player can see it and come after you. You stay listed until your stars decay all the way down to 2, so a quick dip below 4 won't pull you off.
              </p>
            </div>
          </>
        )}
      </div>

      {/* Board switcher. */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
        {([
          { id: 'wanted' as const, label: 'Most Wanted', icon: AlertTriangle },
          { id: 'clubs' as const, label: 'Clubs', icon: Trophy },
          { id: 'elimination' as const, label: 'Elimination', icon: Skull },
        ]).map(t => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              padding: '9px 6px', borderRadius: 13, cursor: 'pointer', fontFamily: 'inherit',
              fontSize: 11, fontWeight: 800, whiteSpace: 'nowrap',
              background: tab === t.id ? 'rgba(255,77,109,0.13)' : 'var(--surface)',
              border: `1px solid ${tab === t.id ? 'rgba(255,77,109,0.38)' : 'var(--border)'}`,
              color: tab === t.id ? '#ff4d6d' : 'var(--text-dim)',
            }}
          >
            <t.icon size={13} /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'elimination' ? (
        <EliminationBoard
          onAttack={e => setTarget({
            // EliminationBoard hands back an EliminationEntry; AttackSheet
            // only needs an id and a name, so adapt here rather than widen
            // its props — the same shim BountyBoard uses below.
            user_id: e.user_id,
            username: e.username,
            display_name: e.display_name ?? '',
            avatar: e.avatar,
            hp: e.hp,
            max_hp: e.max_hp,
            stars: 0,
            last_attack_at: null,
            active_rank_xp: e.active_rank_xp,
          })}
        />
      ) : tab === 'clubs' ? <ClubBoard /> : <>

      {/* Contracts sit above the star board, not on a tab of their own:
          a bounty IS a wanted notice, and there is usually zero or one
          live at a time. Renders nothing when none are open. */}
      {myUserId && (
        <BountyBoard
          myUserId={myUserId}
          onHunt={b => setTarget({
            // BountyBoard hands back a Bounty; AttackSheet only needs the
            // id and a name, so adapt rather than widening its props.
            user_id: b.target_id,
            username: b.username,
            display_name: b.display_name ?? '',
            avatar: b.avatar,
            hp: b.target_hp,
            max_hp: b.target_max_hp,
            stars: 0,
            last_attack_at: null,
            active_rank_xp: 0,
          })}
        />
      )}

      <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
        {([
          { id: 'stars' as const, label: 'Highest stars' },
          { id: 'hp' as const, label: 'Lowest HP' },
        ]).map(opt => (
          <button
            key={opt.id}
            type="button"
            onClick={() => setSortBy(opt.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 12,
              fontSize: 11.5, fontWeight: 700, cursor: 'pointer',
              background: sortBy === opt.id ? 'rgba(245,167,66,0.14)' : 'transparent',
              border: `1px solid ${sortBy === opt.id ? '#f5a74255' : 'var(--border)'}`,
              color: sortBy === opt.id ? '#f5a742' : 'var(--text-dim)',
            }}
          >
            <ArrowUpDown size={11} /> {opt.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
          <span style={{
            width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
            borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
          }} />
        </div>
      ) : error ? (
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '40px 0' }}>{error}</p>
      ) : sorted.length === 0 ? (
        <div className="neu-card" style={{ padding: '32px 20px', textAlign: 'center' }}>
          <AlertTriangle size={22} color="var(--text-dim)" style={{ marginBottom: 8 }} />
          <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: '0 0 4px' }}>Nobody's wanted right now</p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>
            Reach 4 stars in PvP and you'll be the first name on this board.
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {sorted.map(entry => (
            <WantedCard
              key={entry.user_id}
              entry={entry}
              isMe={entry.user_id === myUserId}
              onAttack={setTarget}
            />
          ))}
        </div>
      )}

      </>}

      {target && myUserId && (
        <AttackSheet
          open={!!target}
          myUserId={myUserId}
          targetId={target.user_id}
          targetName={target.display_name || target.username}
          onClose={() => setTarget(null)}
          onResolved={handleResolved}
        />
      )}
    </div>
  )
}
