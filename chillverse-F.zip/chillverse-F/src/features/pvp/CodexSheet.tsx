// src/features/pvp/CodexSheet.tsx
//
// A card's codex: what it is, how to use it well, and what the people who
// have mastered it know. Sections open by rank, so the writing is itself
// part of the reward rather than a wall of tips handed over at purchase.
//
// A locked section still shows its heading. Knowing there IS a "Master's
// note" and not being able to read it is the pull; hiding the row entirely
// would just look like the card had less to say.
import { Lock, BookOpen, X } from 'lucide-react'
import { RANK_COLOR, masteryProgress, type CardMastery } from './useCardMastery'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

export default function CodexSheet({ card, onClose }: {
  card: CardMastery
  onClose: () => void
}) {
  const color = RANK_COLOR[card.rank] ?? '#8d97ab'
  const pct = Math.round(masteryProgress(card) * 100)

  // Drag-to-dismiss from anywhere inside the sheet — engages only when the
  // content under the finger is already scrolled to the top, so the body
  // still scrolls normally. See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(onClose)

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20200,
        background: 'rgba(0,0,0,0.62)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: 'flex-end',
      }}
    >
      <div
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        // Covers the dock rather than sitting above it — the sheet is the
        // whole task here, so `--dock-space` anchoring would leave a
        // pointless strip of nav under a full-height reading view.
        className="sheet-or-modal sheet-or-modal-over-dock"
        style={{
          width: '100%', maxHeight: '86vh', overflowY: 'auto',
          background: 'var(--surface)', borderTopLeftRadius: 22, borderTopRightRadius: 22,
          border: '1px solid var(--border)', borderBottom: 'none',
          padding: '10px 20px 40px',
          transform: `translateY(${dragY}px)`,
          transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.32,0.72,0,1)',
        }}
      >
        <div style={{
          width: 38, height: 4, borderRadius: 3, background: 'var(--border-strong)',
          margin: '0 auto 16px',
        }} />

        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 13, marginBottom: 16 }}>
          {card.image_url
            ? <img src={card.image_url} alt="" style={{
                width: 54, height: 54, borderRadius: 13, objectFit: 'cover',
                border: `1px solid ${color}55`, flexShrink: 0,
              }} />
            : <div style={{
                width: 54, height: 54, borderRadius: 13, flexShrink: 0,
                background: `${color}22`, border: `1px solid ${color}55`,
                display: 'grid', placeItems: 'center',
              }}><BookOpen size={20} style={{ color }} /></div>}

          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)' }}>{card.name}</p>
            <p style={{ fontSize: 12, fontWeight: 700, color, marginTop: 2 }}>
              {card.rank_name}
              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
                {' · '}{card.uses} use{card.uses === 1 ? '' : 's'}
              </span>
            </p>
          </div>

          <button
            onClick={onClose}
            aria-label="Close"
            style={{
              background: 'none', border: 'none', color: 'var(--text-muted)',
              padding: 4, cursor: 'pointer', flexShrink: 0,
            }}
          ><X size={19} /></button>
        </div>

        <div style={{
          height: 8, borderRadius: 6, background: 'var(--surface3)',
          overflow: 'hidden', marginBottom: 6,
        }}>
          <div style={{
            width: `${pct}%`, height: '100%', borderRadius: 6,
            background: `linear-gradient(90deg, ${color}, ${color}aa)`,
            boxShadow: `0 0 10px ${color}55`,
            transition: 'width 0.5s cubic-bezier(0.22,1,0.36,1)',
          }} />
        </div>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginBottom: 22 }}>
          {card.next_threshold == null
            ? 'Mastered. Every page is open.'
            : `${card.points} of ${card.next_threshold} toward ${nextRankName(card.rank)}`}
        </p>

        {card.codex.map((section, i) => (
          <section key={i} style={{ marginBottom: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 7 }}>
              {!section.unlocked && <Lock size={12} style={{ color: 'var(--text-muted)' }} />}
              <p style={{
                fontSize: 13.5, fontWeight: 800,
                color: section.unlocked ? 'var(--text)' : 'var(--text-muted)',
              }}>
                {section.heading}
              </p>
            </div>

            {section.unlocked ? (
              <p style={{
                fontSize: 14, lineHeight: 1.65, color: 'var(--text-dim)',
                // Slight indent and a rule: this is the part people came to
                // read, and it should not look like UI copy.
                borderLeft: `2px solid ${color}44`, paddingLeft: 13,
              }}>
                {section.body}
              </p>
            ) : (
              <p style={{
                fontSize: 12.5, color: 'var(--text-muted)', fontStyle: 'italic',
                borderLeft: '2px solid var(--border)', paddingLeft: 13,
              }}>
                Opens at {rankName(section.rank_required)}.
              </p>
            )}
          </section>
        ))}
      </div>
    </div>
  )
}

function rankName(rank: number): string {
  return ['Novice', 'Apprentice', 'Adept', 'Expert', 'Master'][rank] ?? 'Novice'
}

function nextRankName(rank: number): string {
  return rankName(Math.min(4, rank + 1))
}
