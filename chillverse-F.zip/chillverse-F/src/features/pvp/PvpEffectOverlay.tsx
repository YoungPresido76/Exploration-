// src/features/pvp/PvpEffectOverlay.tsx
//
// Plays card effects full-screen. Mount once, next to <LevelUpOverlay />
// in AppLayout.
//
// Two triggers, one component:
//   • you land an attack  → pvp.ts enqueues the result immediately
//   • you were hit while away → drained from get_unseen_pvp_attacks on
//     mount and played one at a time
//
// The particle markup mirrors the preview harness exactly; only the
// keyframes in pvp-effects.css decide how anything moves.
import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import {
  getPvpEffectSnapshot, subscribePvpEffects, dismissPvpEffect, enqueuePvpEffect,
  type PvpEffectEvent,
} from './pvpEffectBus'
import {
  getUnseenAttacks, markAttacksSeen,
  COMBO_TIER_COLOR, COMBO_TIER_LABEL, killStreakLabel,
} from './pvp'
import { refreshMyPvpStatus } from './useMyPvpStatus'
import { supabase } from '../../shared/lib/supabase'
import { loadComboNames, comboNameFor } from './comboNames'
import { BUILD, FALLBACK } from '../../shared/effects/cardEffectBuild'
import './pvp-effects.css'

/* ── Overlay ────────────────────────────────────────────────────────── */

export default function PvpEffectOverlay({ enabled = true }: { enabled?: boolean }) {
  const snap = useSyncExternalStore(subscribePvpEffects, getPvpEffectSnapshot, getPvpEffectSnapshot)
  const current: PvpEffectEvent | undefined = snap.blocked ? undefined : snap.queue[0]

  const fxRef = useRef<HTMLDivElement>(null)
  const [phase, setPhase] = useState<'idle' | 'playing'>('idle')
  const drained = useRef(false)

  const reduced = typeof window !== 'undefined'
    && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

  // Drain attacks received while away — once per mount. Deliberately does
  // not mark them seen until each has actually finished playing, so a
  // reload mid-animation doesn't silently swallow the hit.
  // The signature table is tiny and cached for the session; loading it
  // here means comboNameFor() is a synchronous lookup by the time any
  // stamp renders.
  useEffect(() => { loadComboNames() }, [])

  useEffect(() => {
    if (!enabled || drained.current) return
    drained.current = true
    getUnseenAttacks()
      .then(list => {
        // A hit that landed while we were away may have knocked us out, so
        // any Games / Exploration gate mounted right now needs to re-read.
        if (list.some(a => a.target_died)) refreshMyPvpStatus()
        for (const a of list) {
          enqueuePvpEffect({
            id: a.id,
            animationKeys: a.animation_keys?.length ? a.animation_keys : ['buster_crack'],
            durationMs: 1400 * Math.max(1, a.animation_keys?.length ?? 1),
            damage: Math.round(a.damage_dealt),
            incoming: true,
            attackerName: a.attacker_username,
            targetDied: a.target_died,
            comboTier: a.combo_tier,
            cardIds: a.card_ids,
          })
        }
      })
      .catch(() => { /* offline: the rows stay unseen and replay next time */ })
  }, [enabled])

  // Live delivery. The mount drain above only runs once, so a player who
  // is already sitting in the app would otherwise not see an incoming hit
  // until they next navigated — which is exactly the delay this fixes.
  // RLS on pvp_attacks limits SELECT to attacker or target, and realtime
  // honours RLS, so this only ever receives rows about your own fights.
  useEffect(() => {
    if (!enabled) return
    let channel: ReturnType<typeof supabase.channel> | null = null
    let cancelled = false

    supabase.auth.getUser().then(({ data }) => {
      const myId = data.user?.id
      if (!myId || cancelled) return

      channel = supabase
        .channel(`pvp_incoming_${myId}`)
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'pvp_attacks', filter: `target_id=eq.${myId}` },
          payload => {
            const a = payload.new as {
              id: string; attacker_id: string; animation_keys: string[] | null
              damage_dealt: number; target_died: boolean
              combo_tier: 'wild' | 'chaos' | 'brutal' | null
              card_ids: string[] | null
            }
            // Same reason as the drain above: if this one put us down, the
            // lock on games and exploration has to take effect immediately,
            // not on the next navigation.
            if (a.target_died) refreshMyPvpStatus()
            enqueuePvpEffect({
              id: a.id,
              animationKeys: a.animation_keys?.length ? a.animation_keys : ['buster_crack'],
              durationMs: 1400 * Math.max(1, a.animation_keys?.length ?? 1),
              damage: Math.round(a.damage_dealt),
              incoming: true,
              // The realtime row has no username join; the effect plays
              // immediately and the name is not worth a round-trip.
              attackerName: undefined,
              targetDied: a.target_died,
              // Realtime hands over the whole row, so the tier arrives with
              // it — no extra round-trip just to know it was a combo.
              comboTier: a.combo_tier,
            cardIds: a.card_ids,
            })
          },
        )
        .subscribe()
    })

    return () => {
      cancelled = true
      if (channel) supabase.removeChannel(channel)
    }
  }, [enabled])

  // Belt and braces: realtime can drop a message if the socket was asleep
  // (backgrounded tab, phone locked), so re-drain whenever the app comes
  // back to the foreground. enqueuePvpEffect dedupes by attack id, so an
  // event delivered twice still plays once.
  useEffect(() => {
    if (!enabled) return
    const recheck = () => {
      if (document.visibilityState !== 'visible') return
      getUnseenAttacks()
        .then(list => {
          for (const a of list) {
            enqueuePvpEffect({
              id: a.id,
              animationKeys: a.animation_keys?.length ? a.animation_keys : ['buster_crack'],
              durationMs: 1400 * Math.max(1, a.animation_keys?.length ?? 1),
              damage: Math.round(a.damage_dealt),
              incoming: true,
              attackerName: a.attacker_username,
              targetDied: a.target_died,
              comboTier: a.combo_tier,
            cardIds: a.card_ids,
            })
          }
        })
        .catch(() => {})
    }
    document.addEventListener('visibilitychange', recheck)
    window.addEventListener('focus', recheck)
    return () => {
      document.removeEventListener('visibilitychange', recheck)
      window.removeEventListener('focus', recheck)
    }
  }, [enabled])

  const finish = useCallback((event: PvpEffectEvent) => {
    if (event.incoming) void markAttacksSeen([event.id]).catch(() => {})
    // A Rust Curse that just landed on us starts the corruption veil.
    // Re-reading here rather than setting a local flag is deliberate: the
    // veil's window comes from the effect row's own timestamps, so a
    // reload can't clear it and a second curse correctly restarts it.
    if (event.incoming && event.animationKeys.includes('rust_bloom')) {
      refreshMyPvpStatus()
    }
    setPhase('idle')
    dismissPvpEffect()
  }, [])

  useEffect(() => {
    if (!current || !fxRef.current) return

    const node = fxRef.current
    const keys = current.animationKeys.length ? current.animationKeys : ['buster_crack']

    // Combo: play sequentially, not stacked.
    let cancelled = false
    const timers: number[] = []
    const per = Math.max(600, current.durationMs / keys.length)

    setPhase('playing')

    keys.forEach((key, i) => {
      timers.push(window.setTimeout(() => {
        if (cancelled) return
        node.innerHTML = (BUILD[key] ?? FALLBACK)()
        node.classList.remove('pvpfx-go')
        void node.offsetWidth              // reflow so a repeat key replays
        node.classList.add('pvpfx-go')
      }, i * per))
    })

    timers.push(window.setTimeout(() => {
      if (cancelled) return
      node.classList.remove('pvpfx-go')
      node.innerHTML = ''
      finish(current)
    }, keys.length * per + 300))

    return () => {
      cancelled = true
      for (const t of timers) window.clearTimeout(t)
    }
  }, [current, finish])

  if (!enabled || !current) return null

  const speed = reduced ? 0.6 : 1

  return (
    <div
      className="pvp-overlay"
      data-reduced={reduced ? 'true' : 'false'}
      data-juice={reduced ? 'false' : 'true'}
      style={{ ['--pvp-speed' as string]: speed }}
      aria-live="polite"
    >
      <div className="pvpfx-fx" ref={fxRef} />

      {phase === 'playing' && (
        <div style={{
          position: 'absolute', left: 0, right: 0, top: '18%', textAlign: 'center',
          pointerEvents: 'none',
        }}>
          <p style={{
            fontSize: 13, fontWeight: 700, letterSpacing: 0.4,
            color: 'rgba(255,255,255,0.82)', textShadow: '0 2px 14px rgba(0,0,0,0.8)',
          }}>
            {/* A self-buff is not an exchange, so none of the attack copy
                applies — "Attack landed" over your own heal reads as a
                bug. It gets its own line and its own number. */}
            {current.selfBuff
              ? current.label ?? 'Card played'
              : current.incoming
                ? `${current.attackerName ?? 'Someone'} attacked you`
                : current.absorbed ? 'Blocked by their shield' : 'Attack landed'}
          </p>
          {current.selfBuff && typeof current.healed === 'number' && current.healed > 0 && (
            <p style={{
              fontSize: 46, fontWeight: 800, marginTop: 4, color: '#5ce39b',
              textShadow: '0 3px 22px rgba(0,0,0,0.8)',
            }}>
              +{current.healed}
            </p>
          )}
          {!current.selfBuff && current.damage > 0 && (
            <p style={{
              fontSize: 46, fontWeight: 800, marginTop: 4,
              color: current.incoming ? '#ff6b85' : '#fff',
              textShadow: '0 3px 22px rgba(0,0,0,0.8)',
            }}>
              −{current.damage}
            </p>
          )}
          {current.targetDied && (
            <p style={{ fontSize: 14, fontWeight: 800, color: '#ff4d6d', marginTop: 2 }}>
              {current.incoming ? 'You went down' : 'They went down'}
            </p>
          )}

          {/* ── Callouts ──────────────────────────────────────────────
              Order is the point: the combo stamp is about the ATTACK,
              the streak is about the DAY, and First Blood is about the
              whole app — so they read outward from the hit. All three
              can stack on one very good attack. */}

          {/* A signature (HEX / BLAZE / COVEN) beats the rarity tier when
              the card set matches, and can fire on a TWO-card play, which
              has no tier at all — hence the || rather than nesting it
              inside the comboTier check. */}
          {(() => {
            const signature = comboNameFor(current.cardIds)
            if (!signature && !current.comboTier) return null
            const label = signature ? signature.name : COMBO_TIER_LABEL[current.comboTier!]
            const colour = signature ? signature.colour : COMBO_TIER_COLOR[current.comboTier!]
            return (
              <p className="pvpfx-stamp" style={{ ['--stamp' as string]: colour, marginTop: 10 }}>
                <span className="pvpfx-stamp-ring" aria-hidden="true" />
                {label}
              </p>
            )
          })()}

          {/* Kill 1 shows nothing — killStreakLabel returns null — because
              "They went down" above has already said it, and a callout on
              every kill would flatten the whole ladder. */}
          {!current.incoming && typeof current.killStreak === 'number'
            && killStreakLabel(current.killStreak) && (
            <p className="pvpfx-streak" style={{ marginTop: 6 }}>
              {killStreakLabel(current.killStreak)}
            </p>
          )}

          {/* Revenge sits below the combo stamp and above First Blood: it
              describes WHY this hit was allowed, which is smaller news than
              the day's first kill but bigger than the streak. */}
          {!current.incoming && current.revenge && (
            <p className="pvpfx-revenge" style={{ marginTop: 6 }}>
              REVENGE
            </p>
          )}

          {current.firstBlood && (
            <p className="pvpfx-firstblood" style={{ marginTop: 8 }}>
              FIRST BLOOD
            </p>
          )}
        </div>
      )}
    </div>
  )
}
