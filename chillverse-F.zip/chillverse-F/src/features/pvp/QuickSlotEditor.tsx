// src/features/pvp/QuickSlotEditor.tsx
//
// Edits the 3-card quick panel. Lives in Inventory next to the existing
// equip flow.
//
// Only 'attack' and 'mark' cards can be slotted — Shield is used on
// yourself and Necromancy fires on its own, so putting either in an
// attack slot would be a dead tap. They are shown in a separate group
// rather than hidden, otherwise a player who bought Necromancy would
// think it vanished.
import { useMemo, useState } from 'react'
import { Swords, Check, Shield, Sparkles } from 'lucide-react'
import { setQuickSlot, pvpErrorMessage, isAttackCard, type PvpCard } from './pvp'
import { usePvpCards, useQuickSlots } from './usePvpCards'

const RARITY_COLOR: Record<string, string> = {
  Common: '#8b95a5', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
}

export default function QuickSlotEditor({ userId }: { userId: string }) {
  const { owned, loading: cardsLoading } = usePvpCards()
  const { bySlot, loading: slotsLoading, refetch } = useQuickSlots(userId)
  const [activeSlot, setActiveSlot] = useState<1 | 2 | 3>(1)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const attackCards = useMemo(() => owned.filter(isAttackCard), [owned])
  const otherCards = useMemo(() => owned.filter(c => !isAttackCard(c)), [owned])
  const slotted = useMemo(() => new Set(bySlot.filter(Boolean) as string[]), [bySlot])

  async function assign(card: PvpCard) {
    if (busy) return
    setBusy(true)
    setError(null)
    try {
      // Tapping a card already in the active slot clears it.
      const clearing = bySlot[activeSlot - 1] === card.item_id
      await setQuickSlot(activeSlot, clearing ? null : card.item_id)
      refetch()
    } catch (e) {
      setError(pvpErrorMessage(e))
    } finally {
      setBusy(false)
    }
  }

  if (cardsLoading || slotsLoading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: '34px 0' }}>
        <span style={{
          width: 20, height: 20, borderRadius: '50%', border: '2px solid var(--surface3)',
          borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
        }} />
      </div>
    )
  }

  if (owned.length === 0) {
    return (
      <p style={{
        fontSize: 13, color: 'var(--text-muted)', textAlign: 'center',
        padding: '28px 16px', border: '1px dashed var(--border-strong)', borderRadius: 14,
      }}>
        No battle cards yet. Pick some up in the Mall to start attacking.
      </p>
    )
  }

  return (
    <div>
      <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 12 }}>
        Pick a slot, then tap a card to put it there. These three are what you can reach in a fight.
      </p>

      {/* Slots */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
        {([1, 2, 3] as const).map(slot => {
          const itemId = bySlot[slot - 1]
          const card = itemId ? owned.find(c => c.item_id === itemId) : undefined
          const active = activeSlot === slot
          const color = card ? RARITY_COLOR[card.rarity] : 'var(--border-strong)'
          return (
            <button
              key={slot}
              type="button"
              onClick={() => setActiveSlot(slot)}
              style={{
                flex: 1, height: 92, borderRadius: 14, cursor: 'pointer', padding: 9,
                border: active ? `2px solid var(--accent)` : `1px ${card ? 'solid' : 'dashed'} ${color}`,
                background: card ? `linear-gradient(160deg, ${color}22, var(--surface))` : 'var(--surface)',
                boxShadow: active ? 'var(--elev-raise)' : 'none',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
                transition: 'all 0.18s ease',
              }}
            >
              <span style={{ fontSize: 9.5, fontWeight: 800, letterSpacing: 0.6, color: 'var(--text-dim)' }}>
                SLOT {slot}
              </span>
              {card ? (
                <span style={{
                  fontSize: 12, fontWeight: 800, color: 'var(--text)', textAlign: 'center',
                  lineHeight: 1.2, overflow: 'hidden',
                }}>
                  {card.name}
                </span>
              ) : (
                <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>Empty</span>
              )}
            </button>
          )
        })}
      </div>

      {error && (
        <p style={{
          fontSize: 12.5, color: '#ff8095', background: 'rgba(255,77,109,0.10)',
          border: '1px solid rgba(255,77,109,0.3)', borderRadius: 12,
          padding: '10px 13px', marginBottom: 14,
        }}>
          {error}
        </p>
      )}

      <SectionLabel icon={<Swords size={12} />} text={`Attack cards · tap to put in slot ${activeSlot}`} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
        {attackCards.length === 0 && (
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>None yet.</p>
        )}
        {attackCards.map(card => (
          <CardRow
            key={card.item_id}
            card={card}
            inSlot={slotted.has(card.item_id)}
            inActiveSlot={bySlot[activeSlot - 1] === card.item_id}
            onTap={() => assign(card)}
          />
        ))}
      </div>

      {otherCards.length > 0 && (
        <>
          <SectionLabel icon={<Sparkles size={12} />} text="Used another way" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {otherCards.map(card => (
              <div key={card.item_id} style={{
                display: 'flex', alignItems: 'center', gap: 11, padding: '11px 13px',
                borderRadius: 13, border: '1px solid var(--border)', background: 'var(--surface)',
                opacity: 0.85,
              }}>
                <Shield size={15} style={{ color: RARITY_COLOR[card.rarity], flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{card.name}</p>
                  <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                    {card.card_kind === 'passive'
                      ? 'Works on its own while you own it'
                      : 'Use on yourself, not in a slot'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

function SectionLabel({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 9 }}>
      <span style={{ color: 'var(--text-dim)', display: 'flex' }}>{icon}</span>
      <span style={{
        fontSize: 10.5, fontWeight: 800, letterSpacing: 0.7, textTransform: 'uppercase',
        color: 'var(--text-dim)',
      }}>
        {text}
      </span>
    </div>
  )
}

function CardRow({ card, inSlot, inActiveSlot, onTap }: {
  card: PvpCard; inSlot: boolean; inActiveSlot: boolean; onTap: () => void
}) {
  const color = RARITY_COLOR[card.rarity] ?? 'var(--text-muted)'
  return (
    <button
      type="button"
      onClick={onTap}
      style={{
        display: 'flex', alignItems: 'center', gap: 11, padding: '11px 13px',
        borderRadius: 13, cursor: 'pointer', width: '100%', textAlign: 'left',
        border: inActiveSlot ? `1.5px solid ${color}` : '1px solid var(--border)',
        background: inSlot ? `linear-gradient(160deg, ${color}18, var(--surface))` : 'var(--surface)',
      }}
    >
      <span style={{
        width: 30, height: 30, borderRadius: 9, flexShrink: 0, display: 'grid', placeItems: 'center',
        background: `${color}22`, border: `1px solid ${color}44`,
      }}>
        <Swords size={14} style={{ color }} />
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{card.name}</p>
        <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
          Lv {card.card_level} · {Math.round(card.current_damage)} dmg
          {card.cooldown_minutes >= 60 && ` · ${card.cooldown_minutes / 60}h recharge`}
        </p>
      </div>
      {inSlot && <Check size={15} style={{ color, flexShrink: 0 }} />}
    </button>
  )
}
