// src/features/pvp/BountyBoard.tsx
//
// The permanent home for live contracts, above the Most Wanted list.
//
// Kept as a strip on that tab rather than a fourth Arena tab: a bounty IS
// a wanted notice, and there are usually zero or one of them — a tab that
// is empty most of the week is worse than a section that simply isn't
// there when nothing is live.
//
// Unlike the poster, this one DOES show a bounty on your own head. You
// came here and looked.
import { Clock, Swords } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { useBounties } from './useBounties'
import type { Bounty } from './bounties'

const PARCHMENT = '#c9a86a'

function hoursLeft(iso: string): string {
  const ms = new Date(iso).getTime() - Date.now()
  if (ms <= 0) return 'expiring'
  const hours = Math.floor(ms / 3_600_000)
  if (hours >= 1) return `${hours}h left`
  return `${Math.max(1, Math.floor(ms / 60_000))}m left`
}

function BountyRow({ bounty, isMe, onHunt }: {
  bounty: Bounty; isMe: boolean; onHunt: (b: Bounty) => void
}) {
  const name = bounty.display_name || bounty.username

  return (
    <div
      className="neu-card"
      style={{
        display: 'flex', alignItems: 'center', gap: 11, padding: '12px 13px',
        borderRadius: 15,
        border: `1px solid ${PARCHMENT}44`,
        background: `linear-gradient(150deg, rgba(201,168,106,0.13), var(--surface))`,
      }}
    >
      <Avatar src={bounty.avatar} name={name} userId={bounty.target_id} size={42} />

      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontFamily: "'Grenze Gotisch', Georgia, serif",
          fontSize: 9.5, letterSpacing: 2, color: PARCHMENT,
          margin: 0, textTransform: 'uppercase',
        }}>
          Wanted
        </p>
        <p style={{
          fontSize: 13.5, fontWeight: 800, color: 'var(--text)', margin: '1px 0 0',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {name}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 3 }}>
          <Clock size={10} color="var(--text-dim)" />
          <span style={{ fontSize: 10, color: 'var(--text-dim)', fontWeight: 600 }}>
            {hoursLeft(bounty.expires_at)}
          </span>
        </div>
      </div>

      <div style={{ flexShrink: 0, textAlign: 'right' }}>
        <p style={{
          fontSize: 15, fontWeight: 800, color: PARCHMENT, margin: 0,
          fontVariantNumeric: 'tabular-nums',
        }}>
          💎 {bounty.reward_gems.toLocaleString()}
        </p>
        {isMe ? (
          <p style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-dim)', margin: '3px 0 0' }}>
            That's you
          </p>
        ) : (
          <button
            type="button"
            onClick={() => onHunt(bounty)}
            style={{
              marginTop: 4, padding: '5px 11px', borderRadius: 9, border: 'none',
              cursor: 'pointer', fontFamily: 'inherit', fontSize: 10.5, fontWeight: 800,
              color: '#2a1a08',
              background: `linear-gradient(135deg, ${PARCHMENT}, #e0c184)`,
              display: 'inline-flex', alignItems: 'center', gap: 5,
            }}
          >
            <Swords size={11} /> Hunt
          </button>
        )}
      </div>
    </div>
  )
}

export default function BountyBoard({ myUserId, onHunt }: {
  myUserId: string
  onHunt: (bounty: Bounty) => void
}) {
  const { bounties } = useBounties()

  // Renders nothing at all when no contract is live — this sits above the
  // Most Wanted list and must not push it down with an empty state.
  if (bounties.length === 0) return null

  return (
    <div style={{ marginBottom: 14 }}>
      <p style={{
        fontSize: 10.5, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase',
        color: PARCHMENT, margin: '0 0 8px',
      }}>
        {bounties.length === 1 ? 'Open contract' : `Open contracts · ${bounties.length}`}
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {bounties.map(b => (
          <BountyRow
            key={b.id}
            bounty={b}
            isMe={b.target_id === myUserId}
            onHunt={onHunt}
          />
        ))}
      </div>
    </div>
  )
}
