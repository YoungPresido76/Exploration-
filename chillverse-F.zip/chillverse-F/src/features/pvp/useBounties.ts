// src/features/pvp/useBounties.ts
//
// Live contracts, shared app-wide, plus the "have I been shown this poster
// yet" bookkeeping.
//
// Two consumers with different needs, one store:
//   • BountyPoster (in AppLayout) wants the newest contract this user has
//     never been shown — once per user, ever, exactly like What's New.
//   • BountyBoard (the Arena strip) wants all of them, seen or not.
//
// Delivery is REALTIME rather than polled. "Placing one broadcasts a live
// site-wide overlay" only means something if the poster lands while people
// are already in the app, and pvp_bounties joined the supabase_realtime
// publication in 0158a for exactly this. The interval below is a safety
// net for a dropped socket and for expiry, not the primary path.
import { useSyncExternalStore } from 'react'
import { supabase } from '../../shared/lib/supabase'
import { getActiveBounties, type Bounty } from './bounties'

const SEEN_KEY_PREFIX = 'cv_bounty_seen_'
const REFRESH_MS = 5 * 60 * 1000

interface Snapshot {
  bounties: Bounty[]
  loaded: boolean
}

let snapshot: Snapshot = { bounties: [], loaded: false }
let inflight: Promise<void> | null = null
let channel: ReturnType<typeof supabase.channel> | null = null
let timer: ReturnType<typeof setInterval> | null = null
const listeners = new Set<() => void>()

function commit(next: Snapshot) {
  snapshot = next
  for (const l of listeners) l()
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)

  if (listeners.size === 1) {
    void reload()
    // One channel and one interval for the whole app, not one per mounted
    // component — the poster and the Arena strip can both be alive at once.
    channel = supabase
      .channel('pvp-bounties-live')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'pvp_bounties' },
        () => { void reload() })
      .subscribe()
    timer = setInterval(() => { void reload() }, REFRESH_MS)
  }

  return () => {
    listeners.delete(listener)
    if (listeners.size === 0) {
      if (channel) { void supabase.removeChannel(channel); channel = null }
      if (timer) { clearInterval(timer); timer = null }
    }
  }
}

function getSnapshot(): Snapshot {
  return snapshot
}

async function reload(): Promise<void> {
  if (inflight) return inflight
  inflight = getActiveBounties()
    .then(bounties => commit({ bounties, loaded: true }))
    // Silent. A poster we can't fetch should mean no poster, never an
    // error state on top of whatever the player was actually doing.
    .catch(() => commit({ bounties: snapshot.bounties, loaded: true }))
    .finally(() => { inflight = null })
  return inflight
}

export function refreshBounties(): void {
  void reload()
}

export function useBounties(): Snapshot {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
}

// ── Seen bookkeeping ────────────────────────────────────────────────────

function seenKey(userId: string, bountyId: string): string {
  return `${SEEN_KEY_PREFIX}${userId}_${bountyId}`
}

export function hasSeenBounty(userId: string, bountyId: string): boolean {
  try {
    return localStorage.getItem(seenKey(userId, bountyId)) !== null
  } catch {
    // Private-mode Safari throws on localStorage. Treating that as "seen"
    // is the kinder failure: showing the same poster on every navigation
    // is far worse than never showing it.
    return true
  }
}

export function markBountySeen(userId: string, bountyId: string): void {
  try {
    localStorage.setItem(seenKey(userId, bountyId), Date.now().toString())
  } catch { /* see above */ }

  // Load-bearing. usePendingBountyPoster derives its answer from the store
  // AND from localStorage, and localStorage is not reactive — without this
  // nudge, dismissing the poster would write the seen mark and then leave
  // it sitting on screen, because nothing told React to look again.
  commit({ ...snapshot })
}

/**
 * The one contract to slam on screen right now, or null.
 *
 * Skips a bounty on the VIEWER'S OWN head — they already got a
 * notification saying there's a price on them, and a poster inviting the
 * whole app to hunt you reads very differently when you're the target.
 * It still shows on the Arena board, where they've chosen to look.
 */
export function usePendingBountyPoster(userId: string | null): Bounty | null {
  const { bounties } = useBounties()
  if (!userId) return null
  return bounties.find(b => b.target_id !== userId && !hasSeenBounty(userId, b.id)) ?? null
}
