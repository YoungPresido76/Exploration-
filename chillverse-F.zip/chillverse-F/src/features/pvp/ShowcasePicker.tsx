// src/features/pvp/ShowcasePicker.tsx
//
// Choose the card of choice and up to three showcase cards shown on your
// Battle profile. The RPC (set_pvp_showcase) and the display existed
// already; this is the missing middle.
//
// Any owned card can be showcased, including Shield and Necromancy —
// unlike the quick slots, this is about what you want to show off, not
// what you can attack with.
import { useEffect, useState } from 'react'
import { Star, Check, X } from 'lucide-react'
import { setShowcase, pvpErrorMessage, type PvpCard } from './pvp'
import { usePvpCards } from './usePvpCards'

const RARITY_COLOR: Record<string, string> = {
  Common: '#8b95a5', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
}

interface ShowcasePickerProps {
  open: boolean
  currentFavorite: string | null
  currentShowcase: string[]
  onClose: () => void
  onSaved: () => void
}

export default function ShowcasePicker({
  open, currentFavorite, currentShowcase, onClose, onSaved,
}: ShowcasePickerProps) {
  const { owned, loading } = usePvpCards()
  const [favorite, setFavorite] = useState<string | null>(currentFavorite)
  const [picked, setPicked] = useState<string[]>(currentShowcase)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Re-seed whenever the sheet reopens, so cancelling truly discards.
  useEffect(() => {
    if (open) {
      setFavorite(currentFavorite)
      setPicked(currentShowcase)
      setError(null)
    }
  }, [open, currentFavorite, currentShowcase])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    if (open) window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  // Lock the page behind the sheet while it's open. A fixed-position
  // overlay does not stop the page underneath from scrolling, which on
  // mobile reads as the sheet drifting off-screen. Inner content still
  // scrolls via its own overflowY.
  useEffect(() => {
    if (!open) return
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [open])

  if (!open) return null

  function toggleShowcase(itemId: string) {
    setError(null)
    setPicked(prev => {
      if (prev.includes(itemId)) return prev.filter(id => id !== itemId)
      // Rolling pick at the cap: tapping a fourth replaces the oldest
      // rather than doing nothing, which reads as a broken button.
      if (prev.length >= 3) return [...prev.slice(1), itemId]
      return [...prev, itemId]
    })
  }

  async function save() {
    if (busy) return
    setBusy(true)
    setError(null)
    try {
      await setShowcase(favorite, picked)
      onSaved()
      onClose()
    } catch (e) {
      setError(pvpErrorMessage(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20001, display: 'flex', alignItems: 'flex-end',
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxHeight: '80vh', overflowY: 'auto',
          background: 'var(--surface2)', borderRadius: '22px 22px 0 0', padding: '20px 18px 30px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <p style={{ fontSize: 16.5, fontWeight: 800, color: 'var(--text)' }}>Showcase cards</p>
          <button type="button" onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
            <X size={18} />
          </button>
        </div>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 16 }}>
          Tap the star to set your card of choice. Tap a card to show it off — up to three.
        </p>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '30px 0' }}>
            <span style={{
              width: 20, height: 20, borderRadius: '50%', border: '2px solid var(--surface3)',
              borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
            }} />
          </div>
        ) : owned.length === 0 ? (
          <p style={{
            fontSize: 13, color: 'var(--text-muted)', textAlign: 'center',
            padding: '28px 16px', border: '1px dashed var(--border-strong)', borderRadius: 14,
          }}>
            You don’t own any battle cards yet.
          </p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 18 }}>
            {owned.map(card => (
              <Row
                key={card.item_id}
                card={card}
                isFavorite={favorite === card.item_id}
                showcaseIndex={picked.indexOf(card.item_id)}
                onToggleFavorite={() => setFavorite(f => f === card.item_id ? null : card.item_id)}
                onToggleShowcase={() => toggleShowcase(card.item_id)}
              />
            ))}
          </div>
        )}

        {error && (
          <p style={{
            fontSize: 12.5, color: '#ff8095', background: 'rgba(255,77,109,0.10)',
            border: '1px solid rgba(255,77,109,0.3)', borderRadius: 12,
            padding: '10px 13px', marginBottom: 14,
          }}>
            {error}
          </p>
        )}

        <button
          type="button"
          onClick={save}
          disabled={busy || loading}
          style={{
            width: '100%', padding: 14, borderRadius: 16, border: 'none',
            cursor: busy ? 'wait' : 'pointer', fontSize: 14, fontWeight: 800, color: '#fff',
            background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
          }}
        >
          {busy ? 'Saving…' : 'Save'}
        </button>
      </div>
    </div>
  )
}

function Row({ card, isFavorite, showcaseIndex, onToggleFavorite, onToggleShowcase }: {
  card: PvpCard
  isFavorite: boolean
  showcaseIndex: number
  onToggleFavorite: () => void
  onToggleShowcase: () => void
}) {
  const color = RARITY_COLOR[card.rarity] ?? 'var(--text-muted)'
  const inShowcase = showcaseIndex >= 0

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '9px 11px', borderRadius: 13,
      border: inShowcase ? `1.5px solid ${color}` : '1px solid var(--border)',
      background: inShowcase ? `linear-gradient(160deg, ${color}18, var(--surface))` : 'var(--surface)',
    }}>
      {/* Card of choice */}
      <button
        type="button"
        onClick={onToggleFavorite}
        aria-label={`Set ${card.name} as card of choice`}
        style={{
          background: 'none', border: 'none', cursor: 'pointer', padding: 3, flexShrink: 0,
          color: isFavorite ? '#f5c542' : 'var(--text-muted)',
        }}
      >
        <Star size={17} fill={isFavorite ? 'currentColor' : 'none'} />
      </button>

      {/* Showcase toggle covers the rest of the row */}
      <button
        type="button"
        onClick={onToggleShowcase}
        style={{
          flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: 10,
          background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
          padding: 0, font: 'inherit', color: 'inherit',
        }}
      >
        {card.image_url ? (
          <img
            src={card.image_url}
            alt=""
            style={{ width: 34, height: 34, borderRadius: 9, objectFit: 'cover', flexShrink: 0, border: `1px solid ${color}44` }}
          />
        ) : (
          <span style={{
            width: 34, height: 34, borderRadius: 9, flexShrink: 0,
            background: `${color}22`, border: `1px solid ${color}44`,
          }} />
        )}

        <span style={{ flex: 1, minWidth: 0 }}>
          <span style={{ display: 'block', fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>
            {card.name}
          </span>
          <span style={{ display: 'block', fontSize: 10.5, color }}>
            {card.rarity} · Lv {card.card_level}
          </span>
        </span>

        {inShowcase && (
          <span style={{
            width: 20, height: 20, borderRadius: '50%', flexShrink: 0,
            background: color, color: '#fff', fontSize: 11, fontWeight: 800,
            display: 'grid', placeItems: 'center',
          }}>
            {showcaseIndex + 1}
          </span>
        )}
        {!inShowcase && <Check size={15} style={{ color: 'var(--text-muted)', opacity: 0.3, flexShrink: 0 }} />}
      </button>
    </div>
  )
}
