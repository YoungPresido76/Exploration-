// src/features/pvp/AttackSheet.tsx
//
// The attack flow: opens from another player's PvP profile, shows the
// three cards in your quick panel, and lets you pick one — or two for a
// combo. Resolution is entirely server-side; this only sends card ids.
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Clock, Swords, X, Zap, Bolt, ShieldAlert, Crosshair, Ticket } from 'lucide-react'
import { supabase } from '../../shared/lib/supabase'
import {
  attackPlayer, cardBlockedUntil, formatCooldownRemaining, pvpErrorMessage,
  getTargetCooldown, isOwnCooldownActive, skipCardCooldown,
  COMBO_TIER_COLOR, COMBO_TIER_LABEL, getRevengeShot, isVoucherlessAttack,
  type PvpAttackResult, type PvpCard, type PvpComboTier, type RevengeShot,
} from './pvp'
import { enqueuePvpEffect } from './pvpEffectBus'
import { loadComboNames, comboNameFor } from './comboNames'
import { refreshFirstBlood } from './useFirstBlood'
import { usePvpCards, useQuickSlots } from './usePvpCards'
import { playPvpAttack } from '../games/sfx'
import { triggerAchievementCheck } from '../achievements/triggerAchievements'
import { useSheetDrag } from '../../shared/hooks/useBottomSheet'

/**
 * How many "Quick Charge" consumables the player currently holds. Fetched
 * fresh each time the sheet opens rather than folded into usePvpCards —
 * it's shop inventory, not battle-card inventory, and only this sheet
 * needs it.
 */
function useQuickChargeCount(userId: string, open: boolean) {
  const [count, setCount] = useState(0)
  const [tick, setTick] = useState(0)
  const refetch = () => setTick(t => t + 1)

  // Cached for the session, so the signature preview can match the moment
  // a second card is picked. Above the `if (!open)` bail-out below —
  // hooks cannot sit after an early return.
  useEffect(() => { loadComboNames() }, [])

  useEffect(() => {
    if (!open) return
    let active = true
    supabase
      .from('user_inventory')
      .select('quantity, item:mall_items!inner(sub_category)')
      .eq('user_id', userId)
      .eq('item.sub_category', 'PvP Quick Charge')
      .maybeSingle()
      .then(({ data }) => {
        if (!active) return
        setCount((data as { quantity: number } | null)?.quantity ?? 0)
      })
    return () => { active = false }
  }, [userId, open, tick])

  return { count, refetch }
}

/**
 * When this player may be hit again — the per-target lock (length set by
 * pvp_config().target_cooldown_min, currently 2.5h).
 *
 * Before this the lock was invisible: the sheet showed every card as ready,
 * the player picked one, tapped Attack, and only then got told they'd hit
 * this person recently. Now it's stated up front, with a way out.
 */
function useTargetCooldown(targetId: string, open: boolean) {
  const [endsAt, setEndsAt] = useState<string | null>(null)
  const [tick, setTick] = useState(0)
  const refetch = useCallback(() => setTick(t => t + 1), [])

  useEffect(() => {
    if (!open) return
    let active = true
    getTargetCooldown(targetId)
      .then(at => { if (active) setEndsAt(at) })
      // Don't invent a lock we couldn't confirm — the RPC is the authority
      // and will reject the attack itself if one really is in force.
      .catch(() => { if (active) setEndsAt(null) })
    return () => { active = false }
  }, [targetId, open, tick])

  return { endsAt, refetch }
}

/**
 * The revenge shot owed to you against this player, if any.
 *
 * Fetched alongside the target lock rather than folded into it, because the
 * two answer opposite questions — one says you're blocked, the other says
 * the block doesn't apply. When a shot is live the lock banner is hidden
 * entirely: showing "you hit them recently" next to "locks don't apply"
 * reads as a contradiction.
 */
function useRevengeShot(targetId: string, open: boolean) {
  const [shot, setShot] = useState<RevengeShot | null>(null)
  const [tick, setTick] = useState(0)
  const refetch = useCallback(() => setTick(t => t + 1), [])

  useEffect(() => {
    if (!open) return
    let active = true
    getRevengeShot(targetId)
      .then(s => { if (active) setShot(s) })
      // Same posture as the lock: never invent one we couldn't confirm.
      // The server decides, and it simply won't apply the bonus.
      .catch(() => { if (active) setShot(null) })
    return () => { active = false }
  }, [targetId, open, tick])

  return { shot, refetch }
}

const RARITY_COLOR: Record<string, string> = {
  Common: '#8b95a5', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
}

/** Must match the CASE in pvp_attack — the server is still the authority,
 *  this only previews what the trio will be called. */
const RARITY_SCORE: Record<string, number> = {
  Common: 1, Rare: 2, Epic: 3, Mythic: 4,
}

/**
 * Which named combo a three-card hand will produce.
 *
 * Returns null for anything that isn't three cards, so the caller doesn't
 * need its own length check. An unknown rarity scores 1, matching the
 * server's `else 1` — a new rarity should downgrade the headline, never
 * make the sheet disagree with the result the player then sees.
 */
function comboTierFor(rarities: (string | undefined)[]): PvpComboTier | null {
  if (rarities.length !== 3 || rarities.some(r => r === undefined)) return null
  const score = rarities.reduce<number>((sum, r) => sum + (RARITY_SCORE[r as string] ?? 1), 0)
  if (score >= 9) return 'brutal'
  if (score >= 7) return 'chaos'
  return 'wild'
}

/**
 * Whether this particular attack earns the player nothing — they're still
 * fighting in a live elimination round and the target isn't in it. Asked
 * once per open, because neither side of that answer can change while the
 * sheet is on screen.
 */
function useVoucherlessAttack(targetId: string, open: boolean) {
  const [voucherless, setVoucherless] = useState(false)

  useEffect(() => {
    if (!open) { setVoucherless(false); return }
    let active = true
    isVoucherlessAttack(targetId).then(v => { if (active) setVoucherless(v) })
    return () => { active = false }
  }, [targetId, open])

  return voucherless
}

interface AttackSheetProps {
  open: boolean
  myUserId: string
  targetId: string
  targetName: string
  onClose: () => void
  /** Fires after a successful attack so the profile can refetch HP. */
  onResolved: (result: PvpAttackResult) => void
}

export default function AttackSheet({
  open, myUserId, targetId, targetName, onClose, onResolved,
}: AttackSheetProps) {
  const { cards, refetch: refetchCards } = usePvpCards()
  const { bySlot, loading } = useQuickSlots(myUserId)
  const { count: quickChargeCount, refetch: refetchQuickCharge } = useQuickChargeCount(myUserId, open)
  const { endsAt: targetCooldownEndsAt, refetch: refetchTargetCooldown } = useTargetCooldown(targetId, open)
  const { shot: revengeShot, refetch: refetchRevenge } = useRevengeShot(targetId, open)
  const voucherless = useVoucherlessAttack(targetId, open)
  // Reset per sheet, deliberately. The warning is about one specific swing
  // costing you a card and a cooldown for zero return, so it should be
  // taken again the next time they line one up rather than dismissed once
  // for the weekend.
  const [riskAccepted, setRiskAccepted] = useState(false)
  useEffect(() => { if (!open) setRiskAccepted(false) }, [open])
  const [picked, setPicked] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [skippingId, setSkippingId] = useState<string | null>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (open) {
      const id = requestAnimationFrame(() => setVisible(true))
      return () => cancelAnimationFrame(id)
    }
    setVisible(false)
    setPicked([])
    setError(null)
  }, [open])

  // Cooldown labels are computed from cooldown_ends_at on every render, so
  // a plain re-render tick is all a live countdown needs — no refetch.
  const [, setTick] = useState(0)
  useEffect(() => {
    if (!open) return
    const id = setInterval(() => setTick(t => t + 1), 15_000)
    return () => clearInterval(id)
  }, [open])

  const byId = useMemo(() => new Map(cards.map(c => [c.item_id, c])), [cards])
  const slotted = useMemo(
    () => bySlot.map(id => (id ? byId.get(id) ?? null : null)),
    [bySlot, byId],
  )
  const hasAnyCard = slotted.some(Boolean)
  // Which card a Quick Charge is spent THROUGH matters: it clears the
  // global + per-target locks whatever you pick, but only that one card's
  // own recharge. So prefer a card that's actually recharging — the charge
  // then does double duty instead of half-wasting itself on a ready card.
  const owned = slotted.filter((c): c is PvpCard => !!c)
  const chargeCarrier = owned.find(isOwnCooldownActive) ?? owned[0] ?? null
  // A live revenge shot overrides the lock, so the lock is not worth
  // mentioning — it isn't going to stop anything.
  const targetLockRemaining = revengeShot ? null : formatCooldownRemaining(targetCooldownEndsAt)
  const revengeRemaining = formatCooldownRemaining(revengeShot?.expires_at ?? null)

  function toggle(card: PvpCard) {
    if (formatCooldownRemaining(cardBlockedUntil(card))) return   // still recharging — not a valid pick
    setError(null)
    setPicked(prev => {
      if (prev.includes(card.item_id)) return prev.filter(id => id !== card.item_id)
      // Three slots, three max — so there is no rolling-pick case left to
      // handle. Every tap either adds or removes, and a full hand can only
      // be changed by untapping something, which is what makes committing
      // the whole kit feel like a decision.
      if (prev.length >= 3) return prev
      return [...prev, card.item_id]
    })
  }

  async function confirm() {
    if (picked.length === 0 || busy) return
    // Server-side this attack is perfectly legal; the gate is purely so
    // nobody spends a card on a zero-return swing by accident and reads it
    // as a bug afterwards.
    if (voucherless && !riskAccepted) return
    setBusy(true)
    setError(null)
    try {
      const result = await attackPlayer(targetId, picked)

      // Fire-and-forget — checks solo kills, revenge kills, brutal combos,
      // First Blood, Elimination survival, and Most Wanted, same
      // convention as every other triggerAchievementCheck call site.
      triggerAchievementCheck(myUserId).catch(console.error)

      // Both the card timers and the per-target lock have just changed.
      refetchTargetCooldown()
      // The shot we just spent is now settled, so the banner must go.
      refetchRevenge()

      // Refresh so the cards just used carry their new cooldown_ends_at —
      // otherwise the sheet would keep showing them as ready until the
      // next unrelated refetch (e.g. an upgrade).
      refetchCards()

      // Play the attacker's own effect. Nothing else did this — the bus
      // was only ever fed by the incoming-attack drain, which is why an
      // attack looked like it did nothing from the attacker's side.
      // Close first so the sheet is not sitting over the animation.
      onClose()
      playPvpAttack()
      enqueuePvpEffect({
        id: result.attack_id,
        animationKeys: result.animation_keys?.length ? result.animation_keys : ['buster_crack'],
        durationMs: 1400 * Math.max(1, result.animation_keys?.length ?? 1),
        damage: Math.round(result.damage),
        incoming: false,
        targetDied: result.target_died,
        healed: result.healed,
        absorbed: result.absorbed_by_shield,
        comboTier: result.combo_tier,
        // Lets the overlay resolve a signature name (HEX / BLAZE / COVEN)
        // from the same set the server just scored.
        cardIds: picked,
        killStreak: result.kill_streak,
        firstBlood: result.first_blood,
        revenge: result.was_revenge,
      })

      // A curse on YOU bites after your own attack resolves, so it queues
      // second and plays second — the order on screen matches the order it
      // happened in. Stamped with the clock rather than the attack id
      // because the queue dedupes by id and this is a separate beat of the
      // same attack.
      if (result.curse_bite > 0) {
        enqueuePvpEffect({
          id: `curse:${result.attack_id}:${Date.now()}`,
          animationKeys: ['curse_bite'],
          durationMs: 1500,
          damage: result.curse_bite,
          incoming: true,
          selfBuff: false,
          attackerName: result.curse_source_name ?? undefined,
          targetDied: result.curse_killed_you,
          label: result.curse_source_name
            ? `${result.curse_source_name}'s curse`
            : 'The curse',
        })
      }
      // The store still holds the pre-kill answer (usually "nobody yet"),
      // and the marker on your own profile reads from the store rather
      // than from this result — so it has to be told.
      if (result.first_blood) refreshFirstBlood()
      onResolved(result)
    } catch (e) {
      setError(pvpErrorMessage(e))
    } finally {
      setBusy(false)
    }
  }

  async function skipCooldown(card: PvpCard) {
    if (skippingId) return
    setSkippingId(card.item_id)
    setError(null)
    try {
      // The target id matters: a Quick Charge now clears the per-target lock
      // too, but the server can only see that lock if we name who it's on.
      await skipCardCooldown(card.item_id, targetId)
      refetchCards()
      refetchQuickCharge()
      refetchTargetCooldown()
    } catch (e) {
      setError(pvpErrorMessage(e))
    } finally {
      setSkippingId(null)
    }
  }

  // Lock the page behind the sheet while it's open, and hide the portaled
  // dock (see body.cv-sheet-open in index.css — same mechanism Mall's buy
  // sheet, RegionMap's sheet, and ProfilePreviewModal already use). Without
  // the class the dock stays visible *and interactive* on top of this sheet,
  // since the dock is portaled to <body> and sits in its own stacking
  // context — z-index alone on this sheet can't reliably outrank it. A
  // fixed-position overlay also does not stop the page underneath from
  // scrolling on its own, which on mobile reads as the sheet drifting
  // off-screen, hence the body overflow lock too. Inner content still
  // scrolls via its own overflowY.
  useEffect(() => {
    if (!open) return
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [open])

  // Drag-to-dismiss from anywhere inside the sheet — engages only when the
  // content under the finger is already scrolled to the top, so the card
  // list still scrolls normally. Declared ABOVE the `if (!open)` bail-out:
  // hooks can't sit after an early return. See useBottomSheet.ts.
  const { dragY, dragging, sheetProps } = useSheetDrag(onClose)

  if (!open) return null

  // Two states, not one: a 2-card combo and a 3-card play look and cost
  // different things, so the button can't collapse them into "isCombo".
  const isCombo = picked.length === 2
  const isTriple = picked.length === 3
  // The tier is scored by rarity, and the sheet can work it out before the
  // attack lands — showing it up front is what makes the third card a
  // choice ("this trio is only WILD, swap one") instead of a surprise.
  const previewTier = isTriple ? comboTierFor(picked.map(id => byId.get(id)?.rarity)) : null
  // A signature can fire on two cards as well, so it is checked for any
  // multi-card pick, not just a trio.
  const previewSignature = picked.length >= 2 ? comboNameFor(picked) : null

  return (
    <div
      className="sheet-or-modal"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20000, display: 'flex', alignItems: 'flex-end',
        background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(3px)',
        opacity: visible ? 1 : 0, transition: 'opacity 0.25s ease',
      }}
    >
      <div
        className="sheet-or-modal-inner"
        {...sheetProps}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: 'var(--surface2)', borderRadius: '22px 22px 0 0',
          // Plain 24px, not calc(var(--dock-space) + 24px): the outer
          // overlay's inline `inset: 0` (above) already overrides the
          // `.sheet-or-modal` class's `bottom: var(--dock-space, 0px)` rule
          // — inline styles win over stylesheet rules regardless of
          // selector — so this card already sits flush against the true
          // viewport bottom. The `cv-sheet-open` class added in the effect
          // above is what actually clears the dock (hides the portaled
          // .dock-layer via index.css), so there's nothing left to paint
          // over this button. This is just normal breathing room below it.
          padding: '22px 20px 24px',
          transform: visible ? `translateY(${dragY}px)` : 'translateY(100%)',
          transition: dragging ? 'none' : 'transform 0.32s cubic-bezier(0.22,1,0.36,1)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <p style={{ fontSize: 17, fontWeight: 800, color: 'var(--text)' }}>Attack {targetName}</p>
          <button type="button" onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
            <X size={18} />
          </button>
        </div>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 18 }}>
          Pick a card, two to combo, or all three for a named hit.
        </p>

        {/* Revenge banner. Nothing to activate — if a shot is live the
            server spends it automatically on the next attack you send this
            player. This only makes that visible before the tap, so the
            free hit isn't a surprise discovered afterwards. */}
        {revengeShot && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16,
            padding: '11px 13px', borderRadius: 13,
            background: 'rgba(255,45,85,0.10)', border: '1px solid rgba(255,45,85,0.34)',
          }}>
            <Crosshair size={15} style={{ color: '#ff4d6d', flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 12, fontWeight: 800, color: '#ff4d6d' }}>
                Revenge shot ready
              </p>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 1, lineHeight: 1.35 }}>
                {revengeShot.from_kill
                  ? `${targetName} put you down. `
                  : `${targetName} hit you. `}
                No cooldowns apply and Vouchers pay +50%
                {revengeRemaining ? ` — expires in ${revengeRemaining}` : ''}.
              </p>
            </div>
          </div>
        )}

        {targetLockRemaining && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16,
            padding: '11px 13px', borderRadius: 13,
            background: 'rgba(255,180,84,0.09)', border: '1px solid rgba(255,180,84,0.28)',
          }}>
            <ShieldAlert size={15} style={{ color: '#ffb454', flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 12, fontWeight: 800, color: '#ffb454' }}>
                You hit {targetName} recently
              </p>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 1 }}>
                Free to attack again in {targetLockRemaining}
              </p>
            </div>
            {quickChargeCount > 0 && chargeCarrier && (
              <button
                type="button"
                onClick={() => skipCooldown(chargeCarrier)}
                disabled={!!skippingId}
                style={{
                  display: 'flex', alignItems: 'center', gap: 4, flexShrink: 0,
                  fontSize: 10.5, fontWeight: 800, color: '#fff', border: 'none',
                  borderRadius: 9, padding: '7px 9px',
                  cursor: skippingId ? 'not-allowed' : 'pointer',
                  background: 'linear-gradient(135deg,#4f8ef7,#9b6dff)',
                  opacity: skippingId ? 0.6 : 1,
                }}
              >
                <Bolt size={11} /> {skippingId ? 'Clearing…' : 'Clear it'}
              </button>
            )}
          </div>
        )}

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '30px 0' }}>
            <span style={{
              width: 20, height: 20, borderRadius: '50%', border: '2px solid var(--surface3)',
              borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
            }} />
          </div>
        ) : !hasAnyCard ? (
          <p style={{
            fontSize: 13, color: 'var(--text-muted)', textAlign: 'center',
            padding: '26px 14px', border: '1px dashed var(--border-strong)', borderRadius: 14,
          }}>
            Your quick panel is empty. Add cards to it from your inventory first.
          </p>
        ) : (
          <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
            {slotted.map((card, i) => (
              <SlotCard
                key={i}
                card={card}
                index={picked.indexOf(card?.item_id ?? '')}
                onTap={() => card && toggle(card)}
                canSkip={quickChargeCount > 0}
                skipping={!!card && skippingId === card.item_id}
                onSkip={() => card && skipCooldown(card)}
              />
            ))}
          </div>
        )}

        {quickChargeCount === 0
          && (!!targetLockRemaining || slotted.some(c => c && formatCooldownRemaining(cardBlockedUntil(c)))) && (
          <p style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: -10, marginBottom: 16 }}>
            A Quick Charge from the Mall clears the breather between attacks and the
            lock on this player, plus the recharge on whichever card you spend it through.
          </p>
        )}

        {error && (
          <p style={{
            fontSize: 12.5, color: '#ff8095', background: 'rgba(255,77,109,0.10)',
            border: '1px solid rgba(255,77,109,0.3)', borderRadius: 12,
            padding: '10px 13px', marginBottom: 14,
          }}>
            {error}
          </p>
        )}

        {/* Tier preview. Shown BEFORE the tap, not after: the whole point
            of a named combo is that you can build for it, and a player who
            only finds out it was WILD once the damage is done can't. It
            also states the cost, because committing all three cards is the
            part that isn't obvious from the card faces. */}
        {(previewSignature || previewTier) && (() => {
          // The signature is the headline when the card set matches one —
          // it is the thing the player deliberately built for. The tier
          // line stays underneath so the cost is still stated.
          const colour = previewSignature ? previewSignature.colour : COMBO_TIER_COLOR[previewTier!]
          const label  = previewSignature ? previewSignature.name  : COMBO_TIER_LABEL[previewTier!]
          return (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14,
              padding: '11px 13px', borderRadius: 13,
              background: `${colour}14`,
              border: `1px solid ${colour}55`,
            }}>
              <span style={{
                fontFamily: "'Bangers', system-ui, sans-serif",
                fontSize: 22, letterSpacing: 1.4, lineHeight: 1,
                color: colour,
              }}>
                {label}
              </span>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', lineHeight: 1.35, flex: 1 }}>
                {previewTier
                  ? <>+60% damage — but all three cards go on recharge and the lock
                      on {targetName} lasts twice as long.</>
                  : <>+25% damage — both cards go on recharge.</>}
              </p>
            </div>
          )
        })()}

        {/* Elimination weekend, swinging at someone outside it. The button
            below is greyed until this is accepted — not because the server
            would refuse (it wouldn't), but because the attack costs a card
            and a cooldown and returns literally nothing, which reads as a
            bug unless it's said out loud first. */}
        {voucherless && (
          <div style={{
            display: 'flex', gap: 10, alignItems: 'flex-start',
            padding: '12px 13px', borderRadius: 14, marginBottom: 10,
            background: 'rgba(255,77,109,0.10)',
            border: '1px solid rgba(255,77,109,0.32)',
          }}>
            <Ticket size={15} color="#ff4d6d" style={{ flexShrink: 0, marginTop: 1 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 12, fontWeight: 800, color: 'var(--text)', margin: 0 }}>
                You signed into Elimination Weekend
              </p>
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '3px 0 0', lineHeight: 1.5 }}>
                {targetName} isn't in the round, so this attack pays no
                Vouchers and no takedown on the board. Continue at your own
                risk.
              </p>
              {!riskAccepted && (
                <button
                  type="button"
                  onClick={() => setRiskAccepted(true)}
                  style={{
                    marginTop: 9, padding: '7px 14px', borderRadius: 10,
                    border: '1px solid rgba(255,77,109,0.45)', cursor: 'pointer',
                    fontFamily: 'inherit', fontSize: 11.5, fontWeight: 800,
                    color: '#ff4d6d', background: 'rgba(255,77,109,0.14)',
                  }}
                >
                  Yes, attack anyway
                </button>
              )}
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={confirm}
          disabled={picked.length === 0 || busy || (voucherless && !riskAccepted)}
          style={{
            width: '100%', padding: 15, borderRadius: 16, border: 'none',
            cursor: picked.length === 0 || busy || (voucherless && !riskAccepted)
              ? 'not-allowed' : 'pointer',
            fontSize: 14.5, fontWeight: 800,
            color: picked.length === 0 || (voucherless && !riskAccepted)
              ? 'var(--text-muted)' : '#fff',
            background: picked.length === 0 || (voucherless && !riskAccepted)
              ? 'var(--surface3)'
              : previewTier
                // Tinted to the tier it will actually produce, so the
                // button itself is the confirmation of what you built.
                ? `linear-gradient(135deg, ${COMBO_TIER_COLOR[previewTier]}, #1a1a1f)`
                : revengeShot
                  ? 'linear-gradient(135deg,#ff2d55,#7a0016)'
                  : isCombo
                    ? 'linear-gradient(135deg,#f5a742,#ff4d6d)'
                    : 'linear-gradient(135deg,var(--accent),var(--accent2))',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            transition: 'background 0.3s ease',
          }}
        >
          {isCombo || isTriple
            ? <Zap size={16} />
            : revengeShot ? <Crosshair size={16} /> : <Swords size={16} />}
          {busy
            ? 'Attacking…'
            : voucherless && !riskAccepted
              ? 'Pays nothing — confirm above'
              : previewTier
              // The tier name wins over "Revenge": the combo is the rarer
              // thing to have built, and the banner above already says a
              // shot is live.
              ? `${COMBO_TIER_LABEL[previewTier]} attack`
              : picked.length === 0
                ? 'Pick a card'
                : revengeShot
                  ? 'Revenge attack'
                  : isCombo ? 'Combo attack' : 'Attack'}
        </button>
      </div>
    </div>
  )
}

interface SlotCardProps {
  card: PvpCard | null
  index: number
  onTap: () => void
  /** Whether the player holds at least one Quick Charge to offer. */
  canSkip: boolean
  skipping: boolean
  onSkip: () => void
}

function SlotCard({ card, index, onTap, canSkip, skipping, onSkip }: SlotCardProps) {
  if (!card) {
    return (
      <div style={{
        flex: 1, height: 118, borderRadius: 14, border: '1px dashed var(--border-strong)',
        display: 'grid', placeItems: 'center', fontSize: 11, color: 'var(--text-muted)',
      }}>
        Empty
      </div>
    )
  }

  const color = RARITY_COLOR[card.rarity] ?? 'var(--text-muted)'
  const selected = index >= 0
  const recharging = formatCooldownRemaining(cardBlockedUntil(card))
  // A Quick Charge now clears the card's own recharge AND the shared
  // breather between attacks, so it's worth offering for either — it used
  // to be withheld unless the card's own timer was the thing in the way.
  const offerSkip = !!recharging && canSkip

  // A <button> can't contain another <button> (the Skip control), so this
  // is a div with button semantics — same disabled/hover/selected behavior
  // as before, just valid nesting underneath.
  return (
    <div
      role="button"
      tabIndex={recharging ? -1 : 0}
      onClick={() => { if (!recharging) onTap() }}
      onKeyDown={e => { if (!recharging && (e.key === 'Enter' || e.key === ' ')) onTap() }}
      style={{
        flex: 1, minWidth: 0, height: 118, padding: '11px 10px', borderRadius: 14,
        cursor: recharging ? 'not-allowed' : 'pointer', textAlign: 'left', position: 'relative',
        border: selected ? `2px solid ${color}` : '1px solid var(--border)',
        background: selected
          ? `linear-gradient(160deg, ${color}30, var(--surface))`
          : 'var(--surface)',
        boxShadow: selected ? `0 0 0 1px ${color}55, 0 8px 20px rgba(0,0,0,0.3)` : 'var(--elev-raise-sm)',
        transform: selected ? 'translateY(-3px)' : 'none',
        transition: 'all 0.2s cubic-bezier(0.22,1,0.36,1)',
        opacity: recharging ? 0.55 : 1,
      }}
    >
      {selected && (
        <span style={{
          position: 'absolute', top: 7, right: 7, width: 19, height: 19, borderRadius: '50%',
          background: color, color: '#fff', fontSize: 11, fontWeight: 800,
          display: 'grid', placeItems: 'center',
        }}>
          {index + 1}
        </span>
      )}
      <p style={{ fontSize: 9, fontWeight: 800, letterSpacing: 0.7, textTransform: 'uppercase', color }}>
        {card.rarity}
      </p>
      <p style={{
        fontSize: 12.5, fontWeight: 800, color: 'var(--text)', marginTop: 3, lineHeight: 1.25,
      }}>
        {card.name}
      </p>
      {recharging ? (
        <div style={{
          position: 'absolute', bottom: 8, left: 8, right: 8,
          display: 'flex', flexDirection: 'column', gap: 4,
        }}>
          <span style={{
            display: 'flex', alignItems: 'center', gap: 4,
            fontSize: 10.5, fontWeight: 700, color: '#ffb454',
          }}>
            <Clock size={11} /> Ready in {recharging}
          </span>
          {offerSkip && (
            <button
              type="button"
              onClick={e => { e.stopPropagation(); onSkip() }}
              disabled={skipping}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3,
                fontSize: 10, fontWeight: 800, color: '#fff', border: 'none', borderRadius: 8,
                padding: '4px 6px', cursor: skipping ? 'not-allowed' : 'pointer',
                background: 'linear-gradient(135deg,#4f8ef7,#9b6dff)',
                opacity: skipping ? 0.6 : 1,
              }}
            >
              <Bolt size={10} /> {skipping ? 'Skipping…' : 'Quick Charge'}
            </button>
          )}
        </div>
      ) : (
        <p style={{ fontSize: 10.5, color: 'var(--text-dim)', marginTop: 'auto', position: 'absolute', bottom: 10, left: 10 }}>
          Lv {card.card_level}{card.base_damage > 0 && ` · ${Math.round(card.current_damage)} dmg`}
        </p>
      )}
    </div>
  )
}
