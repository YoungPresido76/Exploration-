// src/features/pvp/ClubBoard.tsx
//
// The weekly club league, shown as a tab on the Arena screen.
//
// The ranking is the sum of each club's FOUR biggest damage dealers, never
// the club total. That choice is the whole feature: a total ranks clubs by
// how hard they recruited, which no amount of playing well can overturn.
// On the live data it already pays off — the 9-member club sits behind the
// 7-member one, because four of the smaller club's players hit harder.
//
// Clubs under three members are filtered out server-side. They can't field
// four fighters, so listing them would only ever show them losing.
//
// Tapping a row opens ClubQuickSheet — the same sheet a club slot on someone's
// profile opens — rather than expanding an inline list of that club's best
// fighters. A league table is where you go to find a club worth joining, and
// the fighters were the one thing already on the row; the description, banner,
// leader and join button were not.
//
// The row itself stays deliberately bare: rank, picture, name, damage. An
// avatar stack of the top four and a "2 of 9 fought" line both lived here
// briefly and were cut — on a table of four clubs they read as clutter, and
// neither is the thing you are scanning the board for.
//
// Invite-only clubs are stopped at the row with a toast, exactly as on a
// profile: public_club_preview raises club_is_private for outsiders, so
// opening the sheet for one could only ever fail.
import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronRight, Info, Lock, Swords, Users } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { BadgeIcon } from '../badges/badgeIcons'
import ClubQuickSheet from '../clubs/ClubQuickSheet'
import { PRIVATE_CLUB_TOAST } from '../clubs/publicClubs'
import Toast, { useToast } from '../../shared/components/Toast'
import { useProfilePreviewOptional } from '../../context/ProfilePreview'
import { localStamp } from '../../shared/lib/localTime'
import { getClubPvpBoard, type ClubBoardEntry } from './pvp'

const PODIUM = ['#f5c542', '#c9d1d9', '#cd7f32']

/**
 * The Monday 00:00 Lagos boundaries, as epoch milliseconds.
 *
 * Lagos is UTC+1 year-round (no DST), so both ends can be computed from UTC
 * arithmetic without a timezone library. The board's week is the server's,
 * but neither boundary is ever PRINTED as a Lagos time — the reset shows as
 * a countdown, and the start renders through localStamp on whatever clock
 * the reader's device is set to. "Damage counts from Monday" was wrong for
 * anyone far enough west that the week actually turns over on their Sunday.
 */
function lagosWeekBounds(): { startMs: number; resetInMs: number } {
  const now = new Date()
  const lagos = new Date(now.getTime() + 60 * 60 * 1000)
  const dow = lagos.getUTCDay()              // 0 = Sunday
  const daysSinceMonday = (dow === 0 ? 7 : dow) - 1
  const startLagos = Date.UTC(
    lagos.getUTCFullYear(), lagos.getUTCMonth(), lagos.getUTCDate() - daysSinceMonday,
    0, 0, 0,
  )
  // Back out of Lagos time into a real instant.
  const startMs = startLagos - 60 * 60 * 1000
  return { startMs, resetInMs: startMs + 7 * 24 * 3_600_000 - now.getTime() }
}

/** Milliseconds until the week rolls over. */
function nextResetMs(): number {
  return lagosWeekBounds().resetInMs
}

function formatResetIn(ms: number): string {
  if (ms <= 0) return 'any moment'
  const hours = Math.floor(ms / 3_600_000)
  if (hours >= 24) return `${Math.floor(hours / 24)}d ${hours % 24}h`
  if (hours >= 1) return `${hours}h`
  return `${Math.max(1, Math.floor(ms / 60_000))}m`
}

function ClubRow({ entry, rank, onOpen }: {
  entry: ClubBoardEntry
  rank: number
  onOpen: (entry: ClubBoardEntry) => void
}) {
  const accent = PODIUM[rank - 1] ?? 'var(--text-dim)'
  const isLeader = rank === 1 && entry.top_damage > 0
  const locked = entry.join_mode === 'invite' && !entry.viewer_is_member

  return (
    <div
      className="neu-card"
      style={{
        padding: 0, overflow: 'hidden',
        border: isLeader ? '1px solid rgba(245,197,66,0.42)' : '1px solid var(--border)',
        background: isLeader
          ? 'linear-gradient(150deg, rgba(245,197,66,0.10), var(--surface))'
          : 'var(--surface)',
      }}
    >
      <button
        type="button"
        onClick={() => onOpen(entry)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 11,
          padding: '13px 14px', background: 'none', border: 'none',
          cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
        }}
      >
        <span style={{
          flexShrink: 0, width: 24, height: 24, borderRadius: '50%',
          display: 'grid', placeItems: 'center',
          fontSize: 11.5, fontWeight: 800, color: rank <= 3 ? '#0d0d10' : 'var(--text-dim)',
          background: rank <= 3 ? accent : 'var(--surface3)',
        }}>
          {rank}
        </span>

        {entry.icon_url
          ? <Avatar src={entry.icon_url} name={entry.club_name} size={34} />
          : (
            <span style={{
              flexShrink: 0, width: 34, height: 34, borderRadius: 11,
              display: 'grid', placeItems: 'center',
              background: 'var(--surface3)', color: 'var(--text-dim)',
            }}>
              <Users size={16} />
            </span>
          )}

        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{
            fontSize: 13.5, fontWeight: 800, color: 'var(--text)',
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
            display: 'flex', alignItems: 'center', gap: 5,
          }}>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{entry.club_name}</span>
            {locked && <Lock size={11} style={{ flexShrink: 0, color: 'var(--text-dim)' }} />}
          </p>
        </div>

        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <p style={{ fontSize: 14, fontWeight: 800, color: isLeader ? '#f5c542' : 'var(--text)' }}>
            {Math.round(entry.top_damage).toLocaleString()}
          </p>
          <p style={{ fontSize: 9, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.3 }}>
            top 4 dmg
          </p>
        </div>

        <ChevronRight size={15} style={{ flexShrink: 0, color: 'var(--text-dim)' }} />
      </button>
    </div>
  )
}

export default function ClubBoard() {
  const [entries, setEntries] = useState<ClubBoardEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [infoOpen, setInfoOpen] = useState(false)
  const [resetIn, setResetIn] = useState(() => nextResetMs())
  const [openClub, setOpenClub] = useState<ClubBoardEntry | null>(null)
  const { toast, showToast } = useToast()
  const navigate = useNavigate()
  // Optional rather than required: this screen renders inside AppLayout, so
  // the provider is there — but a leaf that throws when it isn't would take
  // the whole Arena tab down for a profile tap that is only a nicety.
  const preview = useProfilePreviewOptional()

  function tapClub(entry: ClubBoardEntry) {
    if (entry.join_mode === 'invite' && !entry.viewer_is_member) {
      showToast({ message: PRIVATE_CLUB_TOAST, icon: Lock, iconColor: 'var(--text-muted)' })
      return
    }
    setOpenClub(entry)
  }

  const load = useCallback(() => {
    setLoading(true)
    getClubPvpBoard()
      .then(rows => { setEntries(rows); setError(null) })
      .catch(() => setError("Couldn't load the club board."))
      .finally(() => setLoading(false))
  }, [])

  useEffect(load, [load])

  // Coarse tick — the label is in hours and days, so a minute is plenty.
  useEffect(() => {
    const id = setInterval(() => setResetIn(nextResetMs()), 60_000)
    return () => clearInterval(id)
  }, [])

  return (
    <div>
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <p style={{ flex: 1, fontSize: 11.5, color: 'var(--text-muted)' }}>
          Resets in {formatResetIn(resetIn)}
        </p>
        <button
          type="button"
          onClick={() => setInfoOpen(v => !v)}
          aria-label="How the club board works"
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            width: 26, height: 26, borderRadius: '50%', cursor: 'pointer',
            background: infoOpen ? 'var(--surface3)' : 'var(--surface)',
            border: `1px solid ${infoOpen ? 'var(--border-strong)' : 'var(--border)'}`,
            color: 'var(--text-dim)',
          }}
        >
          <Info size={13} />
        </button>

        {infoOpen && (
          <>
            <div style={{ position: 'fixed', inset: 0, zIndex: 99 }} onClick={() => setInfoOpen(false)} />
            <div style={{
              position: 'absolute', top: '100%', right: 0, marginTop: 8, zIndex: 100,
              width: 262, padding: '12px 14px', borderRadius: 14,
              background: 'var(--surface2)', border: '1px solid var(--border)',
              boxShadow: 'var(--elev-popover)',
            }}>
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.55 }}>
                Clubs are ranked by their four biggest damage dealers of the week, not by club total — so a bigger club doesn't win by size alone. Clubs need at least 3 members to appear. The board resets weekly, and everyone who fought for the winning club keeps the PvP Champ badge.
              </p>
            </div>
          </>
        )}
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
          <span style={{
            width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
            borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
          }} />
        </div>
      ) : error ? (
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '40px 0' }}>{error}</p>
      ) : entries.length === 0 ? (
        <div className="neu-card" style={{ padding: '32px 20px', textAlign: 'center' }}>
          <Users size={22} color="var(--text-dim)" style={{ marginBottom: 8 }} />
          <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: '0 0 4px' }}>No clubs on the board yet</p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>
            A club needs at least 3 members to compete. Recruit, then fight.
          </p>
        </div>
      ) : (
        <>
          {/* The prize, stated before the table. A league nobody knows the
              reward for is just a list of numbers. */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12,
            padding: '11px 13px', borderRadius: 13,
            background: 'rgba(245,197,66,0.09)', border: '1px solid rgba(245,197,66,0.28)',
          }}>
            <span style={{ color: '#f5c542', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              <BadgeIcon iconKey="hand-fist" size={16} />
            </span>
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', lineHeight: 1.4 }}>
              Everyone who fights for the winning club keeps the <strong style={{ color: '#f5c542' }}>PvP Champ</strong> badge for good.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {entries.map((entry, i) => (
              <ClubRow key={entry.room_id} entry={entry} rank={i + 1} onOpen={tapClub} />
            ))}
          </div>

          <p style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
            fontSize: 10.5, color: 'var(--text-dim)', marginTop: 16,
          }}>
            <Swords size={11} /> Damage counts from {localStamp(new Date(lagosWeekBounds().startMs).toISOString())}
          </p>
        </>
      )}

      {openClub && (
        <ClubQuickSheet
          roomId={openClub.room_id}
          fallbackName={openClub.club_name}
          fallbackIconKey={openClub.icon_key}
          fallbackIconUrl={openClub.icon_url}
          onClose={() => setOpenClub(null)}
          onOpenClub={roomId => { setOpenClub(null); navigate(`/clubs/${roomId}`) }}
          onOpenProfile={preview
            ? userId => { setOpenClub(null); preview.openProfilePreview(userId) }
            : undefined}
        />
      )}

      <Toast toast={toast} />
    </div>
  )
}
