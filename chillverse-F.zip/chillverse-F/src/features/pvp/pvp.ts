// src/features/pvp/pvp.ts
//
// Types and API wrappers for the PvP card-battle feature.
//
// Every shape here mirrors an RPC defined in migrations 0105-0107. If you
// change a `returns table (...)` signature in SQL, change the matching
// interface here — Postgres will not warn you, the field will just arrive
// as undefined at runtime.
//
// NOTE on damage: the client never sends or computes a damage number. It
// sends a target id and up to two card ids; every figure comes back from
// the server. `current_damage` below is display-only.
import { supabase } from '../../shared/lib/supabase'
import type { ClubJoinMode } from '../clubs/clubs'

// ── Vocabulary (mirrors the SQL check constraints) ──────────────────────

/** pvp_state.status — only these two persist. Everything timed is an effect. */
export type PvpStatus = 'alive' | 'dead'

/** Derived label for the profile page, computed server-side on every read. */
export type PvpDisplayStatus =
  | 'alive' | 'dead' | 'poisoned' | 'petrified' | 'corrupted' | 'shielded'
  // Ordered worst-first server-side: a player behind a black plate is not
  // meaningfully poisoned yet, so 'obsidian' outranks the rest.
  | 'burning' | 'cursed' | 'blessed' | 'obsidian'

export type PvpEffectType =
  | 'damage' | 'poison' | 'corrupt' | 'petrify' | 'shield'
  | 'shield_break' | 'mark' | 'revive' | 'lifesteal' | 'heal'
  | 'burn' | 'curse' | 'halo' | 'obsidian'

/** How a card is played — not the same as what it does. */
export type PvpCardKind = 'attack' | 'self_buff' | 'passive' | 'mark'

// ── Shapes ──────────────────────────────────────────────────────────────

/** get_pvp_state(p_user_id) — safe to call for any player, not just yourself. */
export interface PvpState {
  hp: number
  max_hp: number
  status: PvpStatus
  display_status: PvpDisplayStatus
  regen_frozen_until: string | null
  /** Ceil'd whole-star count — use for jail-threshold logic and "X from jail" text. */
  stars: number
  /**
   * Raw, unrounded decay value (e.g. 3.4) at the moment this was fetched.
   * Stars drain continuously server-side at 1 per 6h (pvp_current_stars),
   * same idea as HP regen — this is the number to animate/tick locally
   * for a star that visibly empties instead of jumping a whole star at a
   * time. `stars` (above) stays ceil'd because jail and Most Wanted
   * thresholds are checked against the whole number.
   */
  stars_exact: number
  jailed_until: string | null
  is_jailed: boolean
  jail_offenses: number
  is_poisoned: boolean
  is_petrified: boolean
  is_marked: boolean
  shield_charges: number
  favorite_card_id: string | null
  showcase_card_ids: string[]
  /** True while a Rust Curse is still running on this player. */
  is_corrupted: boolean
  /**
   * When the corruption LANDED — not when it ends. The screen-edge veil
   * runs for the first two minutes only while the debuff itself runs far
   * longer, so the client needs the start to know where it is in that
   * window. Driving the veil off a server timestamp instead of a local
   * timer is what stops a player clearing it by reloading the app.
   */
  corrupt_started_at: string | null
  corrupt_expires_at: string | null
  /** Percent of their own damage this player is currently losing. 0 when clean. */
  corrupt_penalty_pct: number

  /** Fire Torrent: regeneration stopped, with its own tag rather than poison's. */
  is_burning: boolean
  burn_expires_at: string | null

  /**
   * Curse I. `curse_pct` is taken off MAX health, not current, every time
   * this player attacks anyone — 10% of current could never reach zero, so
   * the curse would nag forever and never kill.
   */
  is_cursed: boolean
  curse_expires_at: string | null
  curse_pct: number
  /** Who cast it. Their name goes on the kill if the curse finishes you. */
  curse_source_id: string | null

  /**
   * Bonus health pools stacked ON TOP of hp/max_hp — they are not included
   * in either. Damage drains them before real health, soonest expiry
   * first, so Halo always burns before Obsidian.
   */
  halo_hp: number
  halo_expires_at: string | null
  obsidian_hp: number
  obsidian_expires_at: string | null

  /**
   * Medusa Curse. `is_petrified` above says you're stone; these two say
   * when it breaks and how hard.
   *
   * `petrify_shatter` is 0 for a plain Petrify, which expires quietly, and
   * 50 for a Medusa Curse, which detonates. The stone veil only draws a
   * countdown when there is something to count down TO, so a Petrify shows
   * the badge and a Medusa shows the clock.
   */
  petrify_expires_at: string | null
  petrify_shatter: number
}

/** get_pvp_cards() — full catalog joined with the caller's ownership. */
export interface PvpCard {
  item_id: string
  name: string
  description: string
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic'
  image_url: string | null
  animated_url: string | null
  price_gems: number | null
  price_orbs: number | null
  base_damage: number
  damage_per_level: number
  max_level: number
  effect_type: PvpEffectType
  effect_magnitude: number
  magnitude_per_level: number
  effect_minutes: number
  card_kind: PvpCardKind
  cooldown_minutes: number
  upgrade_copies: number
  upgrade_vouchers: number
  /** Names a CSS keyframe bundle in the client — NOT a media URL. */
  animation_key: string
  animation_ms: number
  /** Both null on every card since the tree was flattened. Kept because the
   *  columns still exist and mastery may want an ordering hint later. */
  tree_tier: number | null
  tree_parent_id: string | null
  flavor: string | null
  /**
   * True = spent on use. A consumable has no recharge (the copies in your
   * bag are the limit), cannot be upgraded, and `copies` is ammunition
   * rather than upgrade fuel. Everything else about it is a normal card:
   * it sits in a quick slot, it combos, and it goes through pvp_attack.
   */
  is_consumable: boolean
  owned: boolean
  /** Duplicate copies held; upgrades consume these. */
  copies: number
  /** 0 when not owned. */
  card_level: number
  current_damage: number
  /** ISO timestamp this specific card can be used again, or null if it's ready now. */
  cooldown_ends_at: string | null
  /** ISO timestamp the 10-minute cooldown between ANY attacks lifts, or null if ready now. */
  global_cooldown_ends_at: string | null
}

/** Resolved result of pvp_attack — returned as jsonb. */
export interface PvpAttackResult {
  attack_id: string
  damage: number
  absorbed_by_shield: boolean
  shield_broken: boolean
  target_hp: number
  target_died: boolean
  target_revived: boolean
  vouchers_earned: number
  /** Cut redirected to whoever planted an Inferno Mark on the target. */
  marker_cut: number
  healed: number
  stars_gained: number
  was_retaliation: boolean
  /** Play these in order — this is the attacker's own animation. */
  animation_keys: string[]
  /** How much of YOUR OWN damage was eaten by corruption on you. 0 normally. */
  corrupt_penalty_pct: number
  /**
   * Null for a one- or two-card attack. Set only on a three-card play, and
   * named by the RARITY SCORE of the trio (Common 1 / Rare 2 / Epic 3 /
   * Mythic 4, summed) rather than by matching rarities — a "three of a
   * kind" rule is unplayable, since no rarity has three cards that can be
   * used in an attack.
   */
  combo_tier: PvpComboTier | null
  /** 0 for a single card, 25 for a two-card combo, 60 for any three-card. */
  combo_bonus_pct: number
  /**
   * How many players you've put down today (Lagos midnight boundary),
   * INCLUDING this one. 0 when this attack didn't kill.
   */
  kill_streak: number
  /**
   * True only for the single attack that lands the first kill in the whole
   * app each day. Exactly one player per day can see this true.
   */
  first_blood: boolean
  /** True when this attack spent a revenge shot (see getRevengeShot). */
  was_revenge: boolean
  /** Extra Vouchers the revenge bonus added on top. 0 on a normal attack. */
  revenge_bonus_vouchers: number
  /** True if an elimination round was running when this attack resolved. */
  elimination_active: boolean
  /**
   * True when this attack knocked the target out of a live elimination
   * round — i.e. target_died AND elimination_active. Worth distinguishing
   * from a plain kill: they cannot Regenerate back until the round closes.
   */
  elimination_kill: boolean
  /** Diamonds paid out for an open bounty this kill collected. 0 normally. */
  bounty_gems: number
  /** How many of the cards played were spent on use. */
  spent_consumables: number
  /**
   * How much of your damage the target's Halo/Obsidian pools ate before
   * anything reached their real health. You are still paid for all of it.
   */
  absorbed_by_armour: number
  /**
   * What a curse on YOU took out of you for making this attack — 10% of
   * your max health, applied after the attack lands and ignoring your own
   * shields and armour. 0 when you aren't cursed.
   */
  curse_bite: number
  /** True when that bite is what finished you. The kill goes to the curser. */
  curse_killed_you: boolean
  /** Who cursed you, for the "X's curse killed you" line. */
  curse_source_name: string | null
}

/** The three named three-card combos, ordered weakest kit → strongest. */
export type PvpComboTier = 'wild' | 'chaos' | 'brutal'

export const COMBO_TIER_LABEL: Record<PvpComboTier, string> = {
  wild: 'WILD', chaos: 'CHAOS', brutal: 'BRUTAL',
}

export const COMBO_TIER_COLOR: Record<PvpComboTier, string> = {
  wild: '#f5a742', chaos: '#b06dff', brutal: '#ff2d55',
}

/**
 * Kill-streak headline for a given number of kills today.
 *
 * Kill 1 gets nothing on purpose: the overlay already says "They went
 * down", and a callout on every single kill would make the ladder
 * meaningless within a day. FIRST BLOOD is separate and additive — it's
 * awarded app-wide, so most players' first kill of the day is just a kill.
 *
 * Rampage is deliberately left at 6 even though the sixth kill usually
 * jails you (stars cap at pvp_config().jail_star_threshold, also 6). Going
 * to jail for it is the point.
 */
export function killStreakLabel(kills: number): string | null {
  if (kills >= 6) return 'RAMPAGE'
  if (kills === 5) return 'ULTRA KILL'
  if (kills === 4) return 'MEGA KILL'
  if (kills === 3) return 'TRIPLE KILL'
  if (kills === 2) return 'DOUBLE KILL'
  return null
}

/** An attack you received while offline, awaiting its CSS replay. */
export interface UnseenPvpAttack {
  id: string
  attacker_id: string
  attacker_username: string
  card_ids: string[]
  animation_keys: string[]
  damage_dealt: number
  effect_type: PvpEffectType | null
  target_died: boolean
  /**
   * Set only when the attack that hit you was a three-card play. Read off
   * the stored row rather than recomputed, because the victim's side never
   * sees pvp_attack's return value.
   */
  combo_tier: PvpComboTier | null
  created_at: string
}

/** One row of get_pvp_attack_history(p_limit) — every attack against you, newest first. */
export interface PvpAttackHistoryEntry {
  id: string
  attacker_id: string
  attacker_username: string
  attacker_display_name: string | null
  attacker_avatar: string | null
  card_ids: string[]
  /** Same order as card_ids. Empty for a card that's since been removed from the catalog. */
  card_names: string[]
  card_rarities: string[]
  damage_dealt: number
  effect_type: PvpEffectType | null
  vouchers_earned: number
  stars_gained: number
  was_retaliation: boolean
  target_died: boolean
  /** Set only when that attack was a three-card play. */
  combo_tier: PvpComboTier | null
  /** Set when that attack was a revenge shot answering one of yours. */
  revenge_source_id: string | null
  created_at: string
}

export interface PvpQuickSlot {
  slot_index: 1 | 2 | 3
  item_id: string
}

/** One row of get_most_wanted() — every player currently at 4+ stars. */
export interface MostWantedEntry {
  user_id: string
  username: string
  display_name: string | null
  avatar: string | null
  hp: number
  max_hp: number
  stars: number
  last_attack_at: string | null
  /** Feed straight into getUserRankTier() for the badge, same as ProfilePreviewModal. */
  active_rank_xp: number
}

// ── Error handling ──────────────────────────────────────────────────────

/**
 * The RPCs raise bare lowercase codes (`raise exception 'target_cooldown'`),
 * which arrive in PostgrestError.message. Map them here rather than showing
 * the raw string — supabase-js surfaces it with a `P0001` prefix and no
 * capitalisation.
 */
export const PVP_ERRORS: Record<string, string> = {
  not_authenticated:       'You need to be signed in.',
  invalid_target:          "You can't attack yourself.",
  invalid_card_count:      'Pick one or two cards.',
  duplicate_card:          'Pick two different cards for a combo.',
  card_not_owned:          "You don't own that card.",
  card_not_playable:       "That card can't be used to attack.",
  card_not_in_quick_slots: 'Add that card to your quick panel first.',
  card_on_cooldown:        'That card is still recharging.',
  card_not_on_cooldown:    "Nothing to clear — you're ready to attack.",
  no_quick_charge_item:    'You need a Quick Charge item first.',
  global_cooldown:         'Catch your breath — you attacked very recently.',
  target_cooldown:         "You've already hit this player recently.",
  target_protected_today:  "This player has taken enough damage recently — try again in a bit.",
  target_already_dead:     'They\u2019re already down.',
  target_in_jail:          'That player is in jail.',
  you_are_dead:            'You need to Regenerate before you can attack.',
  you_are_jailed:          "You can't attack while you're in jail.",
  you_are_petrified:       "You're frozen solid and can't attack right now.",
  already_active:          'That effect is already active.',
  heal_cooling_down:       'Second Wind is still recharging.',
  already_full_hp:         "You're already at full health.",
  not_dead:                "You're not down — no need to regenerate.",
  not_jailed:              "You're not in jail.",
  no_regenerate_item:      'You need a Regenerate item first.',
  no_redemption_item:      'You need a Redemption first.',
  no_jailbreak_item:       'You need a Jailbreak first.',
  no_second_chance_item:   'You need a Second Chance first.',
  nothing_to_cleanse:      "You're clean — nothing to burn off.",
  cannot_target_self:      'Second Chance is for other players. Use a Regenerate on yourself.',
  target_not_dead:         "They're still standing — save it.",
  revive_limit:            "You've used both Second Chances. One comes back 24 hours after you spent it.",
  revive_same_target:      "You already brought this player back today. Someone else's turn.",

  // Elimination weekend. Both are raised by design, not by failure — the
  // copy has to explain the rule, because nothing else on screen will.
  elimination_locked:      "You're out until the elimination round closes.",
  elimination_no_heal:     'No healing while an elimination round is running.',
  insufficient_vouchers:   'Not enough Vouchers.',
  not_enough_copies:       'You need more copies of this card to upgrade.',
  max_level:               'This card is already fully upgraded.',
  jailed:                  "You can't buy cards while you're in jail.",
  dead:                    'You need to Regenerate before buying cards.',

  // Raised by purchase_mall_item, which battle cards share with the rest
  // of the shop. Missing these was why an empty wallet produced a generic
  // "Something went wrong" instead of naming the actual problem.
  insufficient_funds:      'Not enough Diamonds for this card.',
  item_not_found:          'That card is no longer available.',
  not_authorized:          'You need to be signed in.',
}

/**
 * Pulls the bare code out of a Postgres error message.
 *
 * Matches LONGEST key first, not insertion order: several codes are
 * substrings of others ('dead' inside 'you_are_dead', 'jailed' inside
 * 'you_are_jailed'), so a naive scan can return the wrong message
 * depending on how the map happens to be ordered.
 */
const PVP_ERROR_KEYS = Object.keys(PVP_ERRORS).sort((a, b) => b.length - a.length)

export function pvpErrorMessage(err: unknown): string {
  const raw = (err as { message?: string } | null)?.message ?? ''
  for (const code of PVP_ERROR_KEYS) {
    if (raw.includes(code)) return PVP_ERRORS[code]
  }
  return 'Something went wrong. Try again.'
}

// ── API ─────────────────────────────────────────────────────────────────

export async function getPvpState(userId: string): Promise<PvpState | null> {
  const { data, error } = await supabase.rpc('get_pvp_state', { p_user_id: userId })
  if (error) throw error
  const row = (data as PvpState[] | null)?.[0]
  return row ?? null
}

export async function getPvpCards(): Promise<PvpCard[]> {
  const { data, error } = await supabase.rpc('get_pvp_cards')
  if (error) throw error
  return (data as PvpCard[] | null) ?? []
}

export async function getQuickSlots(userId: string): Promise<PvpQuickSlot[]> {
  const { data, error } = await supabase
    .from('pvp_quick_slots')
    .select('slot_index, item_id')
    .eq('user_id', userId)
    .order('slot_index')
  if (error) throw error
  return (data as PvpQuickSlot[] | null) ?? []
}

export async function setQuickSlot(slot: 1 | 2 | 3, itemId: string | null): Promise<void> {
  const { error } = await supabase.rpc('set_pvp_quick_slot', { p_slot: slot, p_item_id: itemId })
  if (error) throw error
}

/**
 * Send only the target and the card ids — never a damage figure.
 *
 * One to THREE cards. Three is the whole quick panel, so it puts every one
 * of those cards on recharge at once and doubles the lock on this target
 * (pvp_config().combo3_lock_mult) — that cost is what keeps it a decision
 * rather than the default opening.
 */
export async function attackPlayer(targetId: string, itemIds: string[]): Promise<PvpAttackResult> {
  const { data, error } = await supabase.rpc('pvp_attack', {
    p_target_id: targetId,
    p_item_ids: itemIds,
  })
  if (error) throw error
  return data as PvpAttackResult
}

/**
 * Result of pvp_use_self_buff. The shape differs by effect, because the
 * two self-buffs resolve differently: a shield is a standing charge
 * count, a heal is a one-off number of HP and a recharge deadline.
 */
export type SelfBuffResult =
  | { effect: 'shield'; charges: number; consumable?: boolean; copies_left?: number }
  // Halo and Obsidian are separate members rather than one with an
  // `effect: 'halo' | 'obsidian'` field. Sharing the field makes it a
  // union of literals INSIDE a member, and narrowing that across two
  // sequential checks doesn't remove the member — so the last branch of a
  // heal/halo/obsidian/shield chain still thinks `pool` might be there
  // and `charges` might not.
  | {
      /** `pool` is the server's 50/100 roll. The client is only told the result. */
      effect: 'halo'
      pool: number
      expires_at: string
      consumable?: boolean; copies_left?: number
    }
  | {
      /** `pool` is the plate's hit points — fixed, not rolled. */
      effect: 'obsidian'
      pool: number
      expires_at: string
      consumable?: boolean; copies_left?: number
    }
  | {
      effect: 'heal'; healed: number; hp: number; max_hp: number
      /** Null for a consumable — there is no recharge to wait out. */
      ready_at: string | null
      consumable?: boolean; copies_left?: number
    }
  // Excludes the two above deliberately: PvpEffectType still contains
  // 'heal' and 'shield', so an open fallback member would overlap them
  // and `result.effect === 'heal'` would fail to narrow.
  | {
      effect: Exclude<PvpEffectType, 'heal' | 'shield' | 'halo' | 'obsidian'>
      charges?: number
      consumable?: boolean; copies_left?: number
    }

/**
 * Plays a self_buff card (Shield, Second Wind).
 *
 * Worth knowing: this function existed and was exported for as long as
 * the PvP feature has, and NOTHING in the app ever called it — Shield
 * could be bought but never actually played. useSelfBuffs() is now the
 * single caller, so both cards work through one path.
 */
export async function useSelfBuff(itemId: string): Promise<SelfBuffResult> {
  const { data, error } = await supabase.rpc('pvp_use_self_buff', { p_item_id: itemId })
  if (error) throw error
  return data as SelfBuffResult
}

/**
 * When a self-buff card can next be played, or null if that's right now.
 *
 * Shield refuses while one is already up; Second Wind refuses on a 4-hour
 * recharge. Without this the button looks live and the tap returns an
 * error, which reads as broken rather than as a timer.
 */
export async function selfBuffReadyAt(itemId: string): Promise<string | null> {
  const { data, error } = await supabase.rpc('pvp_self_buff_ready_at', { p_item_id: itemId })
  if (error) throw error
  return (data as string | null) ?? null
}

export async function regenerate(itemId: string) {
  const { data, error } = await supabase.rpc('pvp_regenerate', { p_item_id: itemId })
  if (error) throw error
  return data as { revived: boolean; hp: number }
}

/**
 * Redemption. Burns off every curse standing on you at once — Curse I,
 * Inferno Mark, Rust Curse, Petrify, and a Medusa Curse BEFORE its stone
 * shatters, which is the reason to hold one.
 *
 * Poison and burn are untouched by design: they are damage over time, not
 * curses, and Second Wind is the answer to those.
 *
 * The server refuses when there is nothing to clear rather than eating the
 * copy — see `nothing_to_cleanse`.
 */
export async function cleanse(itemId: string) {
  const { data, error } = await supabase.rpc('pvp_cleanse', { p_item_id: itemId })
  if (error) throw error
  return data as { cleared: string[]; stone_defused: boolean }
}

/**
 * Jailbreak. Walks you out with no Vouchers spent, and zeroes your stars
 * on the way — without that you'd leave at 6 and your next swing would put
 * you straight back in, which reads as the card not working.
 */
export async function useJailbreak(itemId: string) {
  const { data, error } = await supabase.rpc('pvp_use_jailbreak', { p_item_id: itemId })
  if (error) throw error
  return data as { released: boolean }
}

/**
 * Second Chance. Puts a FALLEN player back on their feet at 1 HP.
 *
 * Twice in any rolling 24 hours, never the same person twice inside one.
 * Rolling rather than a Lagos day on purpose: the app's shared events
 * (Duo, elimination, First Blood) all key off midnight in Lagos because
 * everyone has to be on one clock for those, but a personal allowance
 * shouldn't reset at breakfast for a player outside Nigeria — and a fixed
 * boundary would hand anyone four revives across two minutes of midnight.
 */
export async function reviveOther(itemId: string, targetId: string) {
  const { data, error } = await supabase.rpc('pvp_revive_other', {
    p_item_id: itemId, p_target_id: targetId,
  })
  if (error) throw error
  return data as { revived: boolean; hp: number; uses_left: number }
}

/** Uses left on Second Chance, and when the next one comes back. */
export async function reviveQuota(): Promise<{ uses_left: number; next_at: string | null }> {
  const { data, error } = await supabase.rpc('pvp_revive_quota')
  if (error) throw error
  const row = (data as { uses_left: number; next_at: string | null }[] | null)?.[0]
  return row ?? { uses_left: 0, next_at: null }
}

/**
 * Burns one "Quick Charge" consumable. What it clears:
 *
 *   • the shared cooldown between any two attacks  — for every card
 *   • the per-target lock on whoever you name      — for every card
 *   • THIS card's own recharge                     — this card only
 *
 * Other cards keep their own recharge timers. That's the deliberate limit:
 * per-card cooldowns are what make a rare card feel rare, and one charge
 * resetting a whole deck would let a player carry a single card and buy a
 * full reset for the price of one consumable.
 *
 * Pass `targetId` whenever you know it (i.e. from the attack sheet). Without
 * it the server can't see the per-target lock, so it would refuse with
 * `card_not_on_cooldown` in the one case the player most wants cleared.
 *
 * See 0145 + 0146 — before those this only ever cleared the single card,
 * which is why a spent charge still produced "You've already hit this
 * player recently".
 */
export async function skipCardCooldown(itemId: string, targetId?: string | null) {
  const { data, error } = await supabase.rpc('pvp_skip_cooldown', {
    p_item_id: itemId,
    p_target_id: targetId ?? null,
  })
  if (error) throw error
  return data as { item_id: string; skipped: boolean; cleared_all?: boolean }
}

/**
 * When you may attack this player again, or null if that's right now.
 *
 * The per-target lock length lives in pvp_config().target_cooldown_min
 * (currently 2.5h), tunable server-side without a client release. It used
 * to be invisible until the attack was rejected — this is what lets the
 * sheet say so up front.
 */
export async function getTargetCooldown(targetId: string): Promise<string | null> {
  const { data, error } = await supabase.rpc('pvp_target_cooldown', { p_target_id: targetId })
  if (error) throw error
  return (data as string | null) ?? null
}

/** The two PvP utility consumables, which live in the shop rather than the card catalog. */
export type PvpConsumable =
  | 'PvP Regenerate' | 'PvP Quick Charge'
  | 'PvP Redemption' | 'PvP Jailbreak' | 'PvP Second Chance'

/**
 * How many of a PvP consumable the player holds, and the item id needed to
 * spend it. Returns null when they hold none.
 *
 * These are ordinary `mall_items` rows (category `xp_booster`), not battle
 * cards, so they're deliberately not part of usePvpCards().
 */
export async function findPvpConsumable(
  userId: string, subCategory: PvpConsumable,
): Promise<{ itemId: string; quantity: number } | null> {
  const { data, error } = await supabase
    .from('user_inventory')
    .select('item_id, quantity, item:mall_items!inner(sub_category)')
    .eq('user_id', userId)
    .eq('item.sub_category', subCategory)
    .gt('quantity', 0)
    .maybeSingle()
  if (error) throw error
  const row = data as { item_id: string; quantity: number } | null
  return row ? { itemId: row.item_id, quantity: row.quantity } : null
}

export async function payBail() {
  const { data, error } = await supabase.rpc('pvp_pay_bail')
  if (error) throw error
  return data as { released: boolean; vouchers_spent: number }
}

export async function upgradeCard(itemId: string): Promise<number> {
  const { data, error } = await supabase.rpc('upgrade_pvp_card', { p_item_id: itemId })
  if (error) throw error
  return data as number
}

export async function setShowcase(favorite: string | null, showcase: string[]): Promise<void> {
  const { error } = await supabase.rpc('set_pvp_showcase', {
    p_favorite: favorite,
    p_showcase: showcase,
  })
  if (error) throw error
}

export async function getUnseenAttacks(): Promise<UnseenPvpAttack[]> {
  const { data, error } = await supabase.rpc('get_unseen_pvp_attacks')
  if (error) throw error
  return (data as UnseenPvpAttack[] | null) ?? []
}

export async function markAttacksSeen(ids: string[]): Promise<void> {
  if (ids.length === 0) return
  const { error } = await supabase.rpc('mark_pvp_attacks_seen', { p_ids: ids })
  if (error) throw error
}

/** Full history of attacks against you (not just unseen), newest first. */
export async function getPvpAttackHistory(limit = 30): Promise<PvpAttackHistoryEntry[]> {
  const { data, error } = await supabase.rpc('get_pvp_attack_history', { p_limit: limit })
  if (error) throw error
  return (data as PvpAttackHistoryEntry[] | null) ?? []
}

/** Every player currently at 4+ stars, highest stars first (ties broken by lowest HP). */
export async function getMostWanted(): Promise<MostWantedEntry[]> {
  const { data, error } = await supabase.rpc('get_most_wanted')
  if (error) throw error
  return (data as MostWantedEntry[] | null) ?? []
}

/** Today's First Blood holder — the whole app has one, or none yet. */
export interface FirstBloodHolder {
  user_id: string
  username: string
  display_name: string | null
  claimed_at: string
}

/**
 * Who took First Blood today, or null if nobody has yet.
 *
 * The RPC filters on the Lagos day server-side, so it starts returning
 * nothing the moment the day rolls over. That IS the expiry: there is no
 * client timer to keep the marker alive past midnight, and no way to clear
 * it early by reloading.
 */
export async function getFirstBloodToday(): Promise<FirstBloodHolder | null> {
  const { data, error } = await supabase.rpc('pvp_first_blood_today')
  if (error) throw error
  return (data as FirstBloodHolder[] | null)?.[0] ?? null
}

/** A live counter-attack you're owed against one specific player. */
export interface RevengeShot {
  /** The attack of theirs this answers. Spending it marks that hit as settled. */
  source_attack_id: string
  expires_at: string
  /** True when their hit killed you — which is why the window is longer. */
  from_kill: boolean
}

/**
 * The revenge shot you hold against this player, or null if none.
 *
 * Spending one ignores the per-target lock AND the shared breather between
 * attacks, and pays +50% Vouchers. It never pays stars: the server already
 * zeroes stars on any counter inside 24h so two friends can't farm each
 * other's Most Wanted rating, and paying revenge in stars would undo that.
 *
 * The window is 60 minutes normally and 3 HOURS if their hit killed you —
 * a dead player can't attack until they Regenerate, so a flat hour would
 * make the hardest hits the only ones you could never answer.
 *
 * There is nothing to "activate": if a shot is live, the next attack you
 * send that player automatically uses it. This call is only so the sheet
 * can say so before the tap.
 */
export async function getRevengeShot(targetId: string): Promise<RevengeShot | null> {
  const { data, error } = await supabase.rpc('pvp_revenge_available', { p_target_id: targetId })
  if (error) throw error
  return (data as RevengeShot[] | null)?.[0] ?? null
}

// ── Display helpers ─────────────────────────────────────────────────────

export const RARITY_ORDER: Record<PvpCard['rarity'], number> = {
  Common: 0, Rare: 1, Epic: 2, Mythic: 3,
}

/**
 * Damage a card would deal at a given level. Mirrors public.pvp_card_damage.
 * Display only — the server recomputes this on every attack and does not
 * trust anything sent from here.
 */
export function cardDamageAtLevel(card: PvpCard, level: number): number {
  return card.base_damage + card.damage_per_level * Math.max(0, level - 1)
}

/** Shield charges / revive HP at a level. Mirrors the SQL magnitude maths. */
export function cardMagnitudeAtLevel(card: PvpCard, level: number): number {
  return card.effect_magnitude + card.magnitude_per_level * Math.max(0, level - 1)
}

export function canUpgrade(card: PvpCard): boolean {
  // Mirrors the not_upgradeable guard in upgrade_pvp_card(). Copies of a
  // consumable are ammunition — spending three to gain a level would take
  // three uses away for nothing.
  if (card.is_consumable) return false
  return card.owned
    && card.card_level < card.max_level
    && card.copies >= 1 + card.upgrade_copies
}

/** Spent on use. `copies` is how many uses are left, not upgrade fuel. */
export function isConsumableCard(card: PvpCard): boolean {
  return card.is_consumable
}

/** True while the sentence is still running. */
export function isJailed(state: PvpState | null): boolean {
  return !!state?.is_jailed
}

/** Cards that may be placed in a quick slot and used to attack. */
export function isAttackCard(card: PvpCard): boolean {
  return card.card_kind === 'attack' || card.card_kind === 'mark'
}

/** Cards played on yourself rather than at someone — Shield, Second Wind. */
export function isSelfBuffCard(card: PvpCard): boolean {
  return card.card_kind === 'self_buff'
}

/**
 * The later of a card's own recharge and the shared 10-minute cooldown
 * between any two attacks — whichever one is actually still blocking the
 * next attack with this card. Mirrors the two checks pvp_attack() makes
 * server-side, so the client never shows "ready" while the RPC would
 * still reject the attack (or vice versa).
 */
export function cardBlockedUntil(card: PvpCard): string | null {
  const own = card.cooldown_ends_at
  const global = card.global_cooldown_ends_at
  if (!own) return global
  if (!global) return own
  return new Date(own).getTime() >= new Date(global).getTime() ? own : global
}

/**
 * True only when this specific card's own recharge is what's blocking it
 * right now — not the shared global cooldown.
 *
 * This used to decide whether to offer Quick Charge, back when a charge
 * only cleared the one card. It no longer does (see skipCardCooldown), so
 * the offer is now made whenever ANY cooldown is in the way; this is kept
 * for copy that needs to distinguish the two.
 */
export function isOwnCooldownActive(card: PvpCard): boolean {
  if (!card.cooldown_ends_at) return false
  return new Date(card.cooldown_ends_at).getTime() > Date.now()
}

/** "12m" / "1h 5m" remaining-time label, or null once the deadline has passed (or there wasn't one). */
export function formatCooldownRemaining(endsAt: string | null): string | null {
  if (!endsAt) return null
  const msLeft = new Date(endsAt).getTime() - Date.now()
  if (msLeft <= 0) return null
  const totalMinutes = Math.ceil(msLeft / 60000)
  const hours = Math.floor(totalMinutes / 60)
  const minutes = totalMinutes % 60
  if (hours > 0) return minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`
  return `${minutes}m`
}

// ── Club Arena board ────────────────────────────────────────────────────

/** One member's contribution inside a club's top four. */
export interface ClubBoardMember {
  user_id: string
  username: string
  display_name: string | null
  avatar: string | null
  damage: number
}

/** One row of get_club_pvp_board() — already ordered, best club first. */
export interface ClubBoardEntry {
  room_id: string
  club_name: string
  icon_key: string | null
  icon_url: string | null
  member_count: number
  /** How many members dealt any damage this week — can exceed the top four. */
  fighters: number
  /** Sum of the club's four biggest damage dealers. This is the ranking. */
  top_damage: number
  top_members: ClubBoardMember[]
  /**
   * Carried so a row can decide, before the tap, whether the club sheet will
   * open at all: public_club_preview refuses an invite-only club to a
   * non-member, exactly as it does for a club slot on a profile.
   */
  join_mode: ClubJoinMode
  viewer_is_member: boolean
}

/**
 * The weekly club board, best first.
 *
 * Ranked on the club's TOP FOUR damage dealers rather than its total. A
 * total would just rank clubs by recruiting, which nobody can beat by
 * playing better — and on this app the biggest club is currently NOT the
 * strongest, which is exactly the outcome worth preserving.
 *
 * Clubs under 3 members are excluded server-side: they can never field
 * four fighters, so listing them would only ever show them losing.
 *
 * Pass a week start (Monday, Lagos) to read a past week; omit it for the
 * week in progress.
 */
export async function getClubPvpBoard(weekStart?: string): Promise<ClubBoardEntry[]> {
  const { data, error } = await supabase.rpc('get_club_pvp_board', {
    p_week_start: weekStart ?? null,
  })
  if (error) throw error
  return (data as ClubBoardEntry[] | null) ?? []
}

// ── Elimination weekend ─────────────────────────────────────────────────

/**
 * pvp_elimination_status().
 *
 * Read `starts_at` / `ends_at` against `is_active`: while a round runs they
 * describe THAT round, and the rest of the week they describe the NEXT one.
 * Either way they're what a countdown should point at. `board_key` names
 * the round the counts belong to, which between rounds is last weekend's,
 * not the upcoming one — an empty board for a round nobody has played is
 * worse than showing the last result.
 */
export interface EliminationStatus {
  board_key: string
  starts_at: string
  ends_at: string
  is_active: boolean
  entrants: number
  standing: number
  fallen: number
  me_entered: boolean
  me_eliminated: boolean
  me_eliminated_at: string | null
  me_eliminated_by_name: string | null
  me_kills: number
  /**
   * Vouchers paid to everyone still standing at the close. Owner-editable
   * (app_config.pvp_elimination_reward), so never hardcode it in copy —
   * pvp_elimination_close reads the same value at payout time.
   */
  survivor_reward: number

  /* ── Registration ──────────────────────────────────────────────────
   * Keyed to a DIFFERENT round than the fields above. `board_key` is the
   * live round, or last weekend's between rounds, because an empty board
   * for a round nobody has played is worse than the last result.
   * `registration_key` is always the current-or-upcoming Friday, because
   * that is what signing up signs you up for. They coincide only while a
   * round is live — never read one for the other.
   */
  registration_key: string
  registration_opens_at: string
  registration_closes_at: string
  /** Wednesday 00:00 → Friday 12:00 Lagos, eight hours clear of the bell. */
  registration_open: boolean
  me_registered: boolean
  registered_count: number
  /** Owner-set, shown at the top of the registration sheet. */
  banner_url: string | null

  /* ── Worth ─────────────────────────────────────────────────────────
   * Surviving is no longer enough on its own (0170a). The payout is
   * scored per player: kills pay base + 1 each, a fighter who never
   * finished anyone gets half base, and an idle survivor gets nothing.
   * All three numbers below are computed server-side by the SAME
   * function the payout uses, so what the board promises is what the
   * wallet receives — never re-derive them in the client.
   */
  /** Direct attacks you've landed inside this round. Curse bites excluded. */
  me_attacks: number
  /** What you'd be paid if the round closed right now. 0 once eliminated. */
  me_reward: number
  /** The same sum across everyone still standing — the pot on the line. */
  reward_pot: number
  /** Leader by kills among the standing. Null until someone draws blood. */
  top_name: string | null
  top_kills: number | null
}

/** What pvp_elimination_register() hands back. */
export interface EliminationRegisterResult {
  registered: boolean
  /** True when you were already on the roster — a double tap, not an error. */
  already: boolean
  window_key: string
  registered_count: number
}

/**
 * Join the roster for the upcoming round.
 *
 * There is nothing to pay and nothing to approve: the tap is the whole of
 * it. Refused outside the Wednesday-to-Friday-noon window, which is the
 * only failure worth wording for a player.
 */
export async function registerForElimination(): Promise<EliminationRegisterResult> {
  const { data, error } = await supabase.rpc('pvp_elimination_register')
  if (error) {
    if (error.message.includes('registration_closed')) {
      throw new Error('Registration is closed for this round.')
    }
    throw new Error(error.message)
  }
  return data as EliminationRegisterResult
}

/** One entrant on the elimination board. */
export interface EliminationEntry {
  user_id: string
  username: string
  display_name: string | null
  avatar: string | null
  active_rank_xp: number
  hp: number
  max_hp: number
  kills: number
  joined_at: string
  /** Null while they're still standing. */
  eliminated_at: string | null
  eliminated_by: string | null
  eliminated_by_name: string | null
}

/**
 * True when THIS attack would pay the caller nothing at all: you are still
 * fighting in a live elimination round, and the target is not. While you're
 * in the round every attack pays 0 Vouchers (0170c) — against another
 * entrant that's the trade, because the kill is worth 40+ on the board, but
 * against an outsider there is no board kill either, so the swing is pure
 * loss. The attack sheet asks before it lets you take it.
 *
 * Fails CLOSED-to-false on error, matching every other PvP gate: a warning
 * we can't confirm must never become a blocked button.
 */
export async function isVoucherlessAttack(targetId: string): Promise<boolean> {
  const { data, error } = await supabase.rpc('pvp_voucherless_attack', {
    p_target_id: targetId,
  })
  if (error) return false
  return data === true
}

/* ── Spectating a round ─────────────────────────────────────────────────
 * Anyone not fighting — never registered, or already knocked out — gets a
 * different screen entirely (0171a). They see the scoreboard, the people
 * they FOLLOW who are in it, and one thing to do: cheer. A cheer carries no
 * gameplay effect by design; the moment it does, spectators become a
 * resource to farm.
 */

/** One followed player who is in the current round. */
export interface EliminationFollow {
  user_id: string
  username: string
  display_name: string | null
  avatar: string | null
  active_rank_xp: number
  hp: number
  max_hp: number
  kills: number
  eliminated_at: string | null
  eliminated_by_name: string | null
  /** You've already cheered them this round — it's one each. */
  cheered: boolean
}

export async function getEliminationFollowing(): Promise<EliminationFollow[]> {
  const { data, error } = await supabase.rpc('get_pvp_elimination_following')
  if (error) throw error
  return (data as EliminationFollow[] | null) ?? []
}

/** A cheer that has landed but not yet been shown to the fighter. */
export interface Cheer {
  id: string
  from_user: string
  username: string
  display_name: string | null
  avatar: string | null
  created_at: string
}

/**
 * Send one. Refused for a target who is already out (`not_in_round`) —
 * cheering someone after they've been knocked out reads as mockery.
 * Returns `already: true` on a second attempt rather than throwing, since a
 * double tap is not an error.
 */
export async function sendCheer(targetId: string): Promise<{ sent: boolean; already: boolean }> {
  const { data, error } = await supabase.rpc('pvp_send_cheer', { p_target_id: targetId })
  if (error) {
    if (error.message.includes('not_in_round')) throw new Error("They're already out of the round.")
    if (error.message.includes('no_round')) throw new Error('No round is running right now.')
    throw new Error(error.message)
  }
  return data as { sent: boolean; already: boolean }
}

export async function getUnseenCheers(): Promise<Cheer[]> {
  const { data, error } = await supabase.rpc('pvp_unseen_cheers')
  if (error) return []
  return (data as Cheer[] | null) ?? []
}

export async function markCheersSeen(): Promise<void> {
  await supabase.rpc('pvp_mark_cheers_seen')
}

export async function getEliminationStatus(): Promise<EliminationStatus | null> {
  const { data, error } = await supabase.rpc('pvp_elimination_status')
  if (error) throw error
  return (data as EliminationStatus[] | null)?.[0] ?? null
}

/**
 * The board, standing players first (by kills, then HP), then the fallen
 * most-recent first. Omit the key for the current or most recent round.
 */
export async function getEliminationBoard(windowKey?: string): Promise<EliminationEntry[]> {
  const { data, error } = await supabase.rpc('get_pvp_elimination_board', {
    p_window_key: windowKey ?? null,
  })
  if (error) throw error
  return (data as EliminationEntry[] | null) ?? []
}

/**
 * pvp_elimination_recap() — the story of a round that has already closed.
 *
 * Every figure counts ENTRANTS only: outsiders can and do attack people in
 * a round, but the recap is the roster's story. `hero_damage` and
 * `dmg_total` include indirect ticks (poison, burn, a Medusa shatter),
 * because the player who planted them earned them; the attack COUNT behind
 * the payout rule excludes them, exactly as pvp_elimination_status does.
 *
 * The hero slot answers a different question depending on how it ended —
 * `hero_survived` says which. With survivors it's whoever came out on top
 * by kills; on a total wipe it's whoever lasted longest.
 *
 * Every player field is nullable: a round with entrants but no eliminations
 * and no damage returns a row with the counts and nothing else.
 */
export interface EliminationRecap {
  window_key: string
  starts_at: string
  ends_at: string
  entrants: number
  survivors: number
  /** Vouchers actually paid at the close. 0 on a wipe — nobody banks. */
  vouchers_paid: number

  hero_user_id: string | null
  hero_username: string | null
  hero_display_name: string | null
  hero_avatar: string | null
  hero_survived: boolean | null
  /** Seconds from the opening bell to their elimination, or to the close. */
  hero_lasted_seconds: number | null
  hero_kills: number | null
  hero_damage: number | null

  first_user_id: string | null
  first_username: string | null
  first_display_name: string | null
  first_avatar: string | null
  first_lasted_seconds: number | null

  dmg_user_id: string | null
  dmg_username: string | null
  dmg_display_name: string | null
  dmg_avatar: string | null
  dmg_total: number | null
  dmg_kills: number | null
}

/**
 * Omit the key for the most recent round that has actually finished — which
 * during a live round means last weekend's, not the half-written one. Null
 * when no round has ever been played.
 */
export async function getEliminationRecap(windowKey?: string): Promise<EliminationRecap | null> {
  const { data, error } = await supabase.rpc('pvp_elimination_recap', {
    p_window_key: windowKey ?? null,
  })
  if (error) throw error
  return (data as EliminationRecap[] | null)?.[0] ?? null
}
