// src/features/pvp/pvpEffectBus.ts
//
// Queue behind the PvP card-effect overlay, deliberately shaped like
// levelUpBus: effects are *detected* when they resolve, but not always
// *shown* then. Two jobs:
//
//  1. QUEUE — an attack you land plays immediately; attacks that landed
//     on you while away arrive in a batch on login and must play one
//     after another rather than on top of each other.
//
//  2. BLOCKS — anything can say "not now". A full-screen hit landing in
//     the middle of a game would be worse than showing it late, so the
//     same routes that block level-up celebrations should block these.
//
// Module-level rather than context: attacks resolve in pvp.ts, which is
// plain async code with no access to a provider.

export interface PvpEffectEvent {
  /** Stable key — the attack id, so the same hit can't queue twice. */
  id: string
  /** Animation keys in play order. Two entries for a combo. */
  animationKeys: string[]
  /** Total ms the sequence should run. */
  durationMs: number
  damage: number
  /** true = you were hit; false = you landed it. Drives the copy. */
  incoming: boolean
  attackerName?: string
  targetDied?: boolean
  healed?: number
  absorbed?: boolean
  /**
   * A card you played on YOURSELF (Shield, Second Wind) rather than an
   * exchange with another player.
   *
   * This exists because the queue used to have exactly two feeders — an
   * attack you land, and an attack that lands on you — so a self-buff had
   * no way in at all and its animation never played. It also needs its
   * own copy: "Attack landed" over a heal is nonsense, and the damage
   * readout has to count up rather than down.
   */
  selfBuff?: boolean
  /** Headline for a self-buff, e.g. "Second Wind". */
  label?: string
  /**
   * Set only on a three-card play — 'wild' | 'chaos' | 'brutal'. Drives the
   * shaking stamp. Deliberately carried on the EVENT rather than looked up
   * from the attack result inside the overlay: the incoming side (someone
   * comboed YOU) has no attack result to read, only a realtime row, so the
   * two feeders have to be able to supply it independently.
   */
  comboTier?: 'wild' | 'chaos' | 'brutal' | null
  /**
   * The cards played, in order. Carried for the same reason comboTier is:
   * a signature name (HEX / BLAZE / COVEN) is resolved from the card set,
   * and the incoming side has only a realtime row to work from. Optional
   * because a self-buff has no attack behind it.
   */
  cardIds?: string[] | null
  /** Kills you've landed today including this one. Only set on your own kills. */
  killStreak?: number
  /** True only on the attack that took the day's app-wide First Blood. */
  firstBlood?: boolean
  /** True when this attack spent a revenge shot. Attacker's side only. */
  revenge?: boolean
}

interface Snapshot {
  queue: PvpEffectEvent[]
  blocked: boolean
}

let snapshot: Snapshot = { queue: [], blocked: false }
const listeners = new Set<() => void>()
const blocks = new Map<string, string>()
let tokenSeq = 0

function commit(next: Snapshot) {
  snapshot = next
  for (const listener of listeners) listener()
}

export function subscribePvpEffects(listener: () => void): () => void {
  listeners.add(listener)
  return () => { listeners.delete(listener) }
}

export function getPvpEffectSnapshot(): Snapshot {
  return snapshot
}

export function enqueuePvpEffect(event: PvpEffectEvent): void {
  if (snapshot.queue.some(e => e.id === event.id)) return
  commit({ ...snapshot, queue: [...snapshot.queue, event] })
}

export function dismissPvpEffect(): void {
  if (snapshot.queue.length === 0) return
  commit({ ...snapshot, queue: snapshot.queue.slice(1) })
}

export function blockPvpEffects(reason: string): () => void {
  const token = `${reason}#${++tokenSeq}`
  blocks.set(token, reason)
  syncBlocked()
  return () => { blocks.delete(token); syncBlocked() }
}

function syncBlocked() {
  const blocked = blocks.size > 0
  if (blocked === snapshot.blocked) return
  commit({ ...snapshot, blocked })
}
