// src/features/pvp/EliminationBoard.tsx
//
// Elimination weekend, as the third board on Arena — read as a dashboard
// rather than a list.
//
// The round runs Friday 20:00 to Monday 00:00 Africa/Lagos — that is the
// server's clock, and it must never be printed as-is to a player: see
// shared/lib/localTime for why, and use it for anything a reader needs to
// plan around. No HP regen for anyone, no Regenerate, no Second Wind, and a
// death puts you out until it closes. Since 0170a, surviving is not the whole game — the payout is
// scored per player (base + 1 a kill, half base if you fought and never
// finished anyone, nothing at all if you idled), so the two numbers a
// player actually acts on are who is on top and what they are personally
// worth. Those get a card each, above the roll call.
//
// Every figure on this screen comes from pvp_elimination_status(), which
// runs the same scoring function the payout runs. Nothing here re-derives
// a reward client-side; a board that promises a number the wallet will not
// honour is worse than no board.
//
// Between rounds this screen does not render at all — EliminationRecap
// takes over the moment a round closes, because a board full of frozen
// final numbers and dead attack buttons reads as a bug. Everything below
// the two early returns therefore runs ONLY while a round is live; the
// remaining `live` guards are kept so the file still stands on its own if
// that early return is ever lifted.
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Clock, Crown, Heart, Info, Skull, Swords, Ticket, Users } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import Avatar from '../../shared/components/Avatar'
import { getUserRankTier } from '../profile/ranks'
import { localStamp, localWindowLabel } from '../../shared/lib/localTime'
import {
  getEliminationBoard, getUnseenCheers, markCheersSeen,
  type Cheer, type EliminationEntry,
} from './pvp'
import { useElimination, refreshElimination } from './useElimination'
import EliminationBriefModal, {
  shouldShowBrief, markBriefSeen, shouldShowIdleWarning, markIdleWarned,
} from './EliminationBriefModal'
import EliminationSpectator from './EliminationSpectator'
import EliminationRecap from './EliminationRecap'
import CheerPopup from './CheerPopup'
import './pvp-effects.css'

const ALIVE = '#3ecf8e'
const OUT = '#ff4d6d'
const GOLD = '#f5c542'

/** How close to the bell the idle warning starts firing. */
const IDLE_WARNING_WINDOW_MS = 12 * 60 * 60 * 1000

/** "2d 4h" / "6h" / "18m" — the same shape ClubBoard's reset line uses. */
function formatGap(ms: number): string {
  if (ms <= 0) return 'any moment'
  const mins = Math.floor(ms / 60_000)
  const hours = Math.floor(mins / 60)
  if (hours >= 24) return `${Math.floor(hours / 24)}d ${hours % 24}h`
  if (hours >= 1) return `${hours}h ${mins % 60}m`
  return `${Math.max(1, mins)}m`
}

function timeAgo(iso: string | null): string {
  if (!iso) return ''
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 60_000) return 'just now'
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`
  return `${Math.floor(diff / 86_400_000)}d ago`
}

/* ── Cards ──────────────────────────────────────────────────────────── */

function StatCard({
  eyebrow, icon: Icon, tone, children,
}: {
  eyebrow: string
  icon: LucideIcon
  tone: string
  children: React.ReactNode
}) {
  return (
    <div
      className="neu-card"
      style={{
        flex: 1, minWidth: 0, padding: '12px 12px 13px', borderRadius: 16,
        border: `1px solid ${tone}4d`,
        background: `linear-gradient(150deg, ${tone}1f, var(--surface))`,
      }}
    >
      <p style={{
        display: 'flex', alignItems: 'center', gap: 5, margin: '0 0 9px',
        fontSize: 8.5, fontWeight: 900, letterSpacing: 1.2,
        textTransform: 'uppercase', color: tone,
      }}>
        <Icon size={11} /> {eyebrow}
      </p>
      {children}
    </div>
  )
}

/** Who is on top right now, taken from the board rather than a second call. */
function TopCard({ leader }: { leader: EliminationEntry | null }) {
  return (
    <StatCard eyebrow="Top of the yard" icon={Crown} tone={GOLD}>
      {leader ? (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <Avatar
              src={leader.avatar}
              name={leader.display_name || leader.username}
              ownerId={leader.user_id}
              size={34}
            />
            <div style={{ minWidth: 0 }}>
              <p style={{
                fontSize: 12.5, fontWeight: 800, color: 'var(--text)', margin: 0,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>
                {leader.display_name || leader.username}
              </p>
              <p style={{ fontSize: 10, fontWeight: 700, color: GOLD, margin: '1px 0 0' }}>
                {leader.kills} {leader.kills === 1 ? 'takedown' : 'takedowns'}
              </p>
            </div>
          </div>
          <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '9px 0 0', lineHeight: 1.45 }}>
            Take them down and the seat is yours.
          </p>
        </>
      ) : (
        <>
          <p style={{
            fontFamily: "'Bangers', system-ui, sans-serif", fontSize: 21, letterSpacing: 1,
            color: 'var(--text)', margin: 0,
          }}>
            No blood yet
          </p>
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '5px 0 0', lineHeight: 1.45 }}>
            First kill takes this seat.
          </p>
        </>
      )}
    </StatCard>
  )
}

/**
 * What the viewer is personally worth. `me_reward` is scored server-side by
 * the same function the payout uses, so this card is a quote, not an
 * estimate — the breakdown underneath only explains where it came from.
 */
function WorthCard({
  reward, myReward, myKills, myAttacks, entered, eliminated,
}: {
  reward: number
  myReward: number
  myKills: number
  myAttacks: number
  entered: boolean
  eliminated: boolean
}) {
  const tone = eliminated ? OUT : myReward > 0 ? ALIVE : 'var(--text-dim)'

  const breakdown = !entered
    ? 'Not in this round'
    : eliminated
      ? 'You went down. Nothing pays.'
      : myKills > 0
        ? `${reward} base · +1 × ${myKills} ${myKills === 1 ? 'kill' : 'kills'}`
        : myAttacks >= 3
          ? 'Half pay — you fought, never finished'
          : `Idle. One kill makes it ${reward + 1}.`

  return (
    <StatCard eyebrow="Your worth now" icon={Ticket} tone={eliminated ? OUT : ALIVE}>
      <p style={{
        fontFamily: "'Bangers', system-ui, sans-serif", fontSize: 34, lineHeight: 1,
        letterSpacing: 1.5, color: tone, margin: '2px 0 0',
      }}>
        {myReward}
      </p>
      <p style={{ fontSize: 9.5, color: 'var(--text-muted)', margin: '3px 0 0' }}>
        Vouchers, if you last to the bell
      </p>
      <span style={{
        display: 'inline-block', marginTop: 7, padding: '2px 6px', borderRadius: 7,
        fontSize: 9, fontWeight: 800, color: tone,
        background: eliminated ? 'rgba(255,77,109,0.14)' : 'var(--surface2)',
        border: `1px solid ${eliminated ? 'rgba(255,77,109,0.32)' : 'var(--border)'}`,
      }}>
        {breakdown}
      </span>
    </StatCard>
  )
}

/* ── Rows ───────────────────────────────────────────────────────────── */

function EntrantRow({
  entry, isMe, onAttack,
}: {
  entry: EliminationEntry
  isMe: boolean
  onAttack?: (entry: EliminationEntry) => void
}) {
  const out = entry.eliminated_at !== null
  const name = entry.display_name || entry.username
  const rank = getUserRankTier(entry.active_rank_xp)
  const hpPct = entry.max_hp > 0 ? Math.round((entry.hp / entry.max_hp) * 100) : 0
  // Attacking from here is a shortcut into the same AttackSheet the profile
  // opens, so every cooldown, lock and refusal still comes from the server.
  // The button is only withheld where there is provably nothing to hit.
  const canStrike = !!onAttack && !isMe && !out

  return (
    <div
      className="neu-card"
      style={{
        display: 'flex', alignItems: 'center', gap: 11, padding: '12px 13px',
        borderRadius: 15,
        border: `1px solid ${isMe ? 'var(--accent)55' : out ? 'var(--border)' : `${ALIVE}33`}`,
        background: out
          ? 'var(--surface)'
          : `linear-gradient(150deg, ${ALIVE}0f, var(--surface))`,
        // Eliminated rows are dimmed rather than hidden. Seeing who went
        // out, and to whom, is most of what makes the survivor count mean
        // anything.
        opacity: out ? 0.62 : 1,
      }}
    >
      <div style={{ position: 'relative', flexShrink: 0 }}>
        <Avatar src={entry.avatar} name={name} ownerId={entry.user_id} size={40} />
        {out && (
          <span style={{
            position: 'absolute', inset: 0, borderRadius: '50%',
            display: 'grid', placeItems: 'center',
            background: 'rgba(10,10,14,0.55)',
          }}>
            <Skull size={15} color={OUT} />
          </span>
        )}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <p style={{
            fontSize: 13.5, fontWeight: 800, color: 'var(--text)', margin: 0,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            textDecoration: out ? 'line-through' : 'none',
          }}>
            {name}
          </p>
          <span style={{ fontSize: 10, fontWeight: 700, color: rank.color, flexShrink: 0 }}>
            {rank.name}
          </span>
        </div>

        {out ? (
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 0' }}>
            Taken out{entry.eliminated_by_name ? ` by ${entry.eliminated_by_name}` : ''} · {timeAgo(entry.eliminated_at)}
          </p>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 5 }}>
            <div style={{
              flex: 1, height: 4, borderRadius: 3, background: 'var(--surface3)',
              boxShadow: 'var(--elev-inset)', overflow: 'hidden', minWidth: 30,
            }}>
              <div style={{
                width: `${hpPct}%`, height: '100%', borderRadius: 3,
                background: hpPct <= 33 ? OUT : hpPct <= 66 ? '#f5a742' : ALIVE,
              }} />
            </div>
            <span style={{
              fontSize: 9.5, fontWeight: 700, color: 'var(--text-dim)', flexShrink: 0,
              fontVariantNumeric: 'tabular-nums',
            }}>
              {entry.hp} HP
            </span>
          </div>
        )}
      </div>

      {entry.kills > 0 && (
        <div style={{
          flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4,
          padding: '4px 8px', borderRadius: 9,
          background: 'rgba(255,77,109,0.12)', border: '1px solid rgba(255,77,109,0.28)',
        }}>
          <Swords size={11} color={OUT} />
          <span style={{ fontSize: 11, fontWeight: 800, color: OUT }}>{entry.kills}</span>
        </div>
      )}

      {canStrike && (
        <button
          type="button"
          onClick={() => onAttack?.(entry)}
          aria-label={`Attack ${name}`}
          style={{
            flexShrink: 0, width: 36, height: 36, borderRadius: 12,
            border: 'none', cursor: 'pointer', display: 'grid', placeItems: 'center',
            background: `linear-gradient(135deg, #f5a742, ${OUT})`,
            boxShadow: `0 4px 13px ${OUT}44`,
          }}
        >
          <Swords size={15} color="#fff" />
        </button>
      )}
    </div>
  )
}

/* ── Board ──────────────────────────────────────────────────────────── */

interface Props {
  /**
   * Opens the Arena's AttackSheet on this entrant. Optional so the board
   * still renders for a signed-out or read-only mount; the button simply
   * doesn't appear.
   */
  onAttack?: (entry: EliminationEntry) => void
}

export default function EliminationBoard({ onAttack }: Props) {
  const { user } = useAuth()
  const myUserId = user?.id ?? ''
  const { status, loaded } = useElimination()

  const [entries, setEntries] = useState<EliminationEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [infoOpen, setInfoOpen] = useState(false)
  const [modal, setModal] = useState<'brief' | 'idle' | null>(null)
  const [cheers, setCheers] = useState<Cheer[]>([])
  // Re-rendered on a timer purely so the countdown ticks. The board data
  // itself is not re-fetched on this interval — a minute-resolution clock
  // does not need a minute-resolution round trip.
  const [, setClockTick] = useState(0)

  const load = useCallback(() => {
    let active = true
    setLoading(true)
    setError(null)
    getEliminationBoard()
      .then(rows => { if (active) setEntries(rows) })
      .catch(err => {
        if (active) setError(err instanceof Error ? err.message : 'Could not load the round.')
      })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])

  useEffect(() => { refreshElimination() }, [])

  // Cheers waiting for a fighter. The toast already fired when each one was
  // sent; this is for the ones that landed while they were away. Only
  // fetched for someone actually in the round — nobody else can receive one.
  const fighting = status?.is_active === true && status.me_entered && !status.me_eliminated
  useEffect(() => {
    if (!fighting) return
    let active = true
    getUnseenCheers().then(rows => { if (active) setCheers(rows) })
    return () => { active = false }
  }, [fighting])

  // Keyed on the status object, so an attack that calls refreshElimination()
  // pulls fresh rows too — HP and kills on this board move together with the
  // counts in the header above it.
  useEffect(() => load(), [load, status])

  useEffect(() => {
    const id = window.setInterval(() => setClockTick(t => t + 1), 30_000)
    return () => window.clearInterval(id)
  }, [])

  const live = status?.is_active === true
  const standing = status?.standing ?? 0
  const entrants = status?.entrants ?? 0
  // Owner-editable, so it is never written into the copy. The 15 is only a
  // stand-in for the split second before the status lands, and matches the
  // column default — the board must never promise a number the payout won't
  // honour, and pvp_elimination_close reads the same config value.
  const reward = status?.survivor_reward ?? 15
  const pot = status?.reward_pot ?? 0

  const targetIso = live ? status?.ends_at : status?.starts_at
  const gapMs = targetIso ? new Date(targetIso).getTime() - Date.now() : 0

  const leader = useMemo(() => {
    const alive = entries.filter(e => e.eliminated_at === null && e.kills > 0)
    if (alive.length === 0) return null
    return alive.reduce((best, e) => (e.kills > best.kills ? e : best))
  }, [entries])

  // The board already arrives fallen-last and most-recent-first, so the top
  // three of that tail is the kill feed — no second query for it.
  const lastBlood = useMemo(
    () => entries.filter(e => e.eliminated_at !== null).slice(0, 3),
    [entries],
  )

  // One modal at a time, and the brief always wins: a player seeing the
  // rules for the first time should not be told off in the same breath.
  useEffect(() => {
    if (!live || !status || modal) return
    if (shouldShowBrief()) { setModal('brief'); return }
    const nearlyOver = new Date(status.ends_at).getTime() - Date.now() <= IDLE_WARNING_WINDOW_MS
    if (
      nearlyOver && status.me_entered && !status.me_eliminated &&
      status.me_kills === 0 && shouldShowIdleWarning(status.board_key)
    ) {
      setModal('idle')
    }
  }, [live, status, modal])

  function closeModal() {
    if (modal === 'brief') markBriefSeen()
    if (modal === 'idle' && status) markIdleWarned(status.board_key)
    setModal(null)
  }

  // The round is over. Nobody — survivor, casualty or bystander — has an
  // action left, so nobody gets an action screen: the countdown and the
  // recap replace the whole board. This check comes FIRST because a
  // survivor is neither eliminated nor a spectator and would otherwise be
  // left staring at a frozen live board all week.
  if (status && !status.is_active) {
    return <EliminationRecap status={status} />
  }

  // Not in this round — never registered, or already knocked out. They get
  // a different screen entirely rather than this one with everything
  // greyed out. See EliminationSpectator for why.
  if (status && (!status.me_entered || status.me_eliminated)) {
    return <EliminationSpectator status={status} />
  }

  return (
    <div>
      {/* ── Headline ─────────────────────────────────────────────────── */}
      <div
        className={`neu-card${live ? ' elim-hero' : ''}`}
        style={{
          position: 'relative', padding: '20px 18px 17px', borderRadius: 18, marginBottom: 10,
          border: `1px solid ${live ? `${OUT}4d` : 'var(--border)'}`,
          background: live
            ? `radial-gradient(120% 90% at 50% -10%, ${OUT}2b, transparent 62%), linear-gradient(160deg, ${OUT}17, ${ALIVE}0d 70%, var(--surface))`
            : 'var(--surface)',
          textAlign: 'center', overflow: 'hidden',
        }}
      >
        <button
          type="button"
          onClick={() => setInfoOpen(v => !v)}
          aria-label="How elimination weekend works"
          style={{
            position: 'absolute', top: 12, right: 12, zIndex: 1,
            width: 24, height: 24, borderRadius: '50%', cursor: 'pointer',
            display: 'grid', placeItems: 'center',
            background: infoOpen ? 'var(--surface3)' : 'transparent',
            border: `1px solid ${infoOpen ? 'var(--border-strong)' : 'var(--border)'}`,
            color: 'var(--text-dim)',
          }}
        >
          <Info size={12} />
        </button>

        {live ? (
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 5,
            padding: '3px 9px', borderRadius: 20,
            background: `${OUT}29`, border: `1px solid ${OUT}73`,
            fontSize: 8.5, fontWeight: 900, letterSpacing: 1,
            textTransform: 'uppercase', color: OUT,
          }}>
            <span className="elim-dot" style={{
              width: 5, height: 5, borderRadius: '50%', background: OUT, display: 'block',
            }} />
            Round in progress
          </span>
        ) : (
          <p style={{
            fontSize: 10.5, fontWeight: 800, letterSpacing: 1.4, textTransform: 'uppercase',
            color: 'var(--text-dim)', margin: '0 0 8px',
          }}>
            {entrants > 0 ? 'Last round' : 'Elimination weekend'}
          </p>
        )}

        {entrants > 0 ? (
          <>
            <p style={{
              fontFamily: "'Bangers', system-ui, sans-serif",
              fontSize: 58, lineHeight: 1, letterSpacing: 2,
              color: 'var(--text)', margin: live ? '8px 0 0' : 0,
              textShadow: live ? `0 0 24px ${ALIVE}66` : 'none',
            }}>
              {loaded ? standing : '—'}
            </p>
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', margin: '2px 0 0' }}>
              {live ? 'still standing' : 'survived'}
              <span style={{ color: 'var(--text-dim)', fontWeight: 600 }}> of {entrants}</span>
            </p>
          </>
        ) : (
          <p style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', margin: 0 }}>
            Nobody has played a round yet
          </p>
        )}

        <div style={{
          display: 'flex', flexWrap: 'wrap', justifyContent: 'center',
          gap: 6, marginTop: 13,
        }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '7px 13px', borderRadius: 20,
            background: 'var(--surface2)', border: '1px solid var(--border)',
          }}>
            <Clock size={12} color="var(--text-dim)" />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)' }}>
              {live ? `Closes in ${formatGap(gapMs)}` : `Next round in ${formatGap(gapMs)}`}
            </span>
          </span>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '7px 13px', borderRadius: 20,
            background: `${ALIVE}14`, border: `1px solid ${ALIVE}3d`,
          }}>
            <Ticket size={12} color={ALIVE} />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: ALIVE }}>
              {reward} base · +1 a kill
            </span>
          </span>
        </div>

        {infoOpen && (
          <p style={{
            fontSize: 11.5, color: 'var(--text-muted)', lineHeight: 1.6,
            margin: '14px 0 0', textAlign: 'left',
            padding: '12px 13px', borderRadius: 13,
            background: 'var(--surface2)', border: '1px solid var(--border)',
          }}>
            From {localWindowLabel(status?.starts_at, status?.ends_at)}, registered
            players don't heal — no passive regen, no Regenerate, no Second Wind.
            Go down and you're out until the round closes, and you forfeit
            everything, kills included. Last to the bell and it pays {reward} plus
            1 a takedown. Fight without finishing anyone and it's half. Do nothing
            and it's nothing. You have to sign up: registration closes{' '}
            {localStamp(status?.registration_closes_at)}, from the card on your
            dashboard. Anyone can take a registrant down, entered or not. Games and
            Exploration stay open either way.
          </p>
        )}
      </div>

      {/* ── The two cards ────────────────────────────────────────────── */}
      {entrants > 0 && (
        <div style={{ display: 'flex', gap: 9, marginBottom: 9 }}>
          <TopCard leader={leader} />
          <WorthCard
            reward={reward}
            myReward={status?.me_reward ?? 0}
            myKills={status?.me_kills ?? 0}
            myAttacks={status?.me_attacks ?? 0}
            entered={status?.me_entered ?? false}
            eliminated={status?.me_eliminated ?? false}
          />
        </div>
      )}

      {/* ── The pot ──────────────────────────────────────────────────── */}
      {entrants > 0 && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10,
          padding: '11px 14px', borderRadius: 15,
          border: `1px solid ${GOLD}42`,
          background: `linear-gradient(100deg, ${GOLD}17, var(--surface) 72%)`,
        }}>
          <Ticket size={16} color={GOLD} style={{ flexShrink: 0 }} />
          <div style={{ minWidth: 0 }}>
            <p style={{
              fontFamily: "'Bangers', system-ui, sans-serif", fontSize: 19,
              letterSpacing: 1, color: GOLD, margin: 0,
            }}>
              {pot} Vouchers
            </p>
            <p style={{ fontSize: 10.5, fontWeight: 600, color: 'var(--text-muted)', margin: '1px 0 0' }}>
              {live ? `on the line across ${standing} still standing` : 'paid out for this round'}
            </p>
          </div>
        </div>
      )}

      {/* ── Last blood ───────────────────────────────────────────────── */}
      {lastBlood.length > 0 && (
        <div className="neu-card" style={{
          padding: '11px 13px', borderRadius: 15, marginBottom: 10,
          border: '1px solid var(--border)',
        }}>
          <p style={{
            display: 'flex', alignItems: 'center', gap: 5, margin: '0 0 6px',
            fontSize: 8.5, fontWeight: 900, letterSpacing: 1.2,
            textTransform: 'uppercase', color: OUT,
          }}>
            <Skull size={11} /> Last blood
          </p>
          {lastBlood.map(e => (
            <div key={e.user_id} style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '4px 0', fontSize: 11, color: 'var(--text-muted)',
            }}>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                <b style={{ color: 'var(--text)', fontWeight: 800 }}>
                  {e.display_name || e.username}
                </b>
                {e.eliminated_by_name
                  ? <> was taken out by <b style={{ color: 'var(--text)', fontWeight: 800 }}>{e.eliminated_by_name}</b></>
                  : ' went down'}
              </span>
              <span style={{ marginLeft: 'auto', flexShrink: 0, fontSize: 9.5, color: 'var(--text-dim)' }}>
                {timeAgo(e.eliminated_at)}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Sign-ups open and no round running: the board is showing last
          weekend's result, which is not the thing to act on. Point at the
          dashboard card, which is where registering actually happens — this
          board is deliberately not a second entry point for it. */}
      {!live && status?.registration_open && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12,
          padding: '11px 14px', borderRadius: 14,
          background: status.me_registered ? `${ALIVE}14` : 'var(--surface2)',
          border: `1px solid ${status.me_registered ? `${ALIVE}3d` : 'var(--border)'}`,
        }}>
          <Ticket size={15} color={status.me_registered ? ALIVE : 'var(--text-dim)'} />
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, flex: 1 }}>
            {status.me_registered
              ? `You're registered for this weekend.`
              : `Sign-ups are open for this weekend — register from your dashboard.`}
            <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
              {' '}{status.registered_count} in so far.
            </span>
          </p>
        </div>
      )}

      {/* ── Your standing ────────────────────────────────────────────── */}
      {status?.me_entered && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12,
          padding: '11px 14px', borderRadius: 14,
          background: status.me_eliminated ? 'rgba(255,77,109,0.10)' : `${ALIVE}14`,
          border: `1px solid ${status.me_eliminated ? 'rgba(255,77,109,0.3)' : `${ALIVE}3d`}`,
        }}>
          {status.me_eliminated
            ? <Skull size={15} color={OUT} />
            : <Heart size={15} color={ALIVE} />}
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, flex: 1 }}>
            {status.me_eliminated
              ? `You were taken out${status.me_eliminated_by_name ? ` by ${status.me_eliminated_by_name}` : ''} — nothing pays out.`
              : live
                ? status.me_kills > 0
                  ? `Still in it, ${status.me_kills} down. Last to the bell and it's ${status.me_reward} Vouchers.`
                  : `Still in it — but nobody has fallen to you yet.`
                : `You made it through. ${status.me_reward} Vouchers paid.`}
          </p>
        </div>
      )}

      {/* ── Entrants ─────────────────────────────────────────────────── */}
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '48px 0' }}>
          <span style={{
            width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
            borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
          }} />
        </div>
      ) : error ? (
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '36px 0' }}>
          {error}
        </p>
      ) : entries.length === 0 ? (
        <div className="neu-card" style={{ padding: '30px 20px', textAlign: 'center' }}>
          <Users size={22} color="var(--text-dim)" style={{ marginBottom: 8 }} />
          <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: '0 0 4px' }}>
            No entrants yet
          </p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>
            Throw the first punch once the round opens and you're on this board.
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {entries.map(entry => (
            <EntrantRow
              key={entry.user_id}
              entry={entry}
              isMe={entry.user_id === myUserId}
              onAttack={live ? onAttack : undefined}
            />
          ))}
        </div>
      )}

      {cheers.length > 0 && (
        <CheerPopup
          cheers={cheers}
          onClose={() => { setCheers([]); void markCheersSeen() }}
        />
      )}

      {modal && (
        <EliminationBriefModal
          kind={modal}
          reward={reward}
          attacks={status?.me_attacks ?? 0}
          timeLeft={formatGap(gapMs)}
          onClose={closeModal}
        />
      )}
    </div>
  )
}
