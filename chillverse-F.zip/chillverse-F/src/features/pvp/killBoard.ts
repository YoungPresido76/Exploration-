// src/features/pvp/killBoard.ts
//
// The all-time eliminations board, and where the caller sits on it.
//
// Kept out of pvp.ts on purpose — that file is already the shared surface
// for combat state, cards, attacks, bounties and the elimination round, and
// this is a self-contained read with two RPCs and no writes.
//
// Neither figure is stored anywhere. Both RPCs aggregate pvp_attacks from
// the beginning of time, which is what "never resets" actually means here:
// there is no counter to wipe, no window to roll, and the board was already
// correct on the day it shipped.
import { supabase } from '../../shared/lib/supabase'

/** One row of get_pvp_kill_board(). */
export interface KillBoardEntry {
  rank: number
  user_id: string
  username: string
  display_name: string | null
  avatar: string | null
  active_rank_xp: number
  /** Every player they have ever finished off. */
  kills: number
  /** Total damage dealt, all time. Breaks ties on kills. */
  damage: number
  /**
   * Read from player_badges, not recomputed from these numbers — so if the
   * refresh cron hasn't caught up, the board shows the skull where the
   * skull actually is rather than where it ought to be.
   */
  is_boss: boolean
}

/** What pvp_my_kill_standing() hands back — always exactly one row. */
export interface MyKillStanding {
  /** 0 when you've never finished anyone. Not a rank, an absence of one. */
  my_rank: number
  my_kills: number
  my_damage: number
  /** How many players have at least one kill — the size of the ladder. */
  ranked_total: number
  /** The player one place above you, and their count. Null at rank 1 or 0. */
  next_name: string | null
  next_kills: number | null
}

export async function getKillBoard(limit = 50): Promise<KillBoardEntry[]> {
  const { data, error } = await supabase.rpc('get_pvp_kill_board', { p_limit: limit })
  if (error) throw error
  return (data as KillBoardEntry[] | null) ?? []
}

export async function getMyKillStanding(): Promise<MyKillStanding | null> {
  const { data, error } = await supabase.rpc('pvp_my_kill_standing')
  if (error) throw error
  return (data as MyKillStanding[] | null)?.[0] ?? null
}
