// src/features/pvp/SkillTree.tsx
//
// Your battle deck: every card, plus the consumables you're carrying.
//
// This was a tier ladder with each card locked behind the one before it.
// That lock was never real — purchase_mall_item has no parent check, so
// the RPC would always have sold you a Mythic first — and it broke
// outright once Shield Buster (the root) became a consumable. So nothing
// is locked here any more; the screen's job is now to show what you have
// and how much of it is left.
//
// The route stays /skill-tree. The dock, You.tsx and the Inventory menu
// all point at it, same reason /most-wanted survived becoming Arena.
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Check, Swords, ChevronRight, Zap, BookOpen } from 'lucide-react'
import { usePvpCards } from './usePvpCards'
import { useCardMastery, masteryProgress, RANK_COLOR, type CardMastery } from './useCardMastery'
import CodexSheet from './CodexSheet'
import { usePageHeader } from '../../context/PageHeader'
import type { PvpCard } from './pvp'

const RARITY_COLOR: Record<string, string> = {
  Common: '#8b95a5', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
}

export default function SkillTree() {
  const navigate = useNavigate()
  // Preserves the original back destination (the Link pointed at
  // /dashboard specifically, not generic browser-back).
  usePageHeader({ title: 'Battle Deck', onBack: () => navigate('/dashboard') })
  const { permanent, consumables, ladder, loading } = usePvpCards()
  // No separate loading state: the deck renders from usePvpCards and the
  // mastery bars appear underneath when they arrive. Blocking the whole
  // screen on a second round trip would be slower for no gain.
  const { cards: mastery } = useCardMastery()
  const [open, setOpen] = useState<CardMastery | null>(null)

  // Keyed by item so a row can find its own progress without the two
  // hooks having to agree on ordering.
  const masteryById = useMemo(
    () => new Map(mastery.map(m => [m.item_id, m])),
    [mastery],
  )

  const ownedCount = useMemo(() => permanent.filter(c => c.owned).length, [permanent])
  const carrying = useMemo(
    () => consumables.reduce((sum, c) => sum + (c.owned ? c.copies : 0), 0),
    [consumables],
  )
  const mastered = useMemo(() => mastery.filter(m => m.rank >= 4).length, [mastery])

  return (
    <div style={{ paddingBottom: 40 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px 20px' }}>
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            {loading
              ? 'Loading…'
              : `${ownedCount} of ${permanent.length} cards${carrying > 0 ? ` · ${carrying} consumable${carrying === 1 ? '' : 's'} carried` : ''}${mastered > 0 ? ` · ${mastered} mastered` : ''}`}
          </p>
        </div>
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
          <span style={{
            width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
            borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
          }} />
        </div>
      ) : (
        <div style={{ padding: '0 20px' }}>
          {/* Consumables first: they're the thing that runs out, so they're
              the thing worth checking before a fight. */}
          {consumables.length > 0 && (
            <section style={{ marginBottom: 26 }}>
              <SectionLabel label="Consumables" color="#3ecf8e" icon={<Zap size={11} />} />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {consumables.map(card => (
                  <DeckRow key={card.item_id} card={card}
                    mastery={masteryById.get(card.item_id)}
                    onOpenCodex={setOpen} />
                ))}
              </div>
            </section>
          )}

          {ladder.map(group => (
            <section key={group.rarity} style={{ marginBottom: 22 }}>
              <SectionLabel
                label={group.rarity}
                color={RARITY_COLOR[group.rarity] ?? 'var(--text-muted)'}
              />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {group.nodes.map(card => (
                  <DeckRow key={card.item_id} card={card}
                    mastery={masteryById.get(card.item_id)}
                    onOpenCodex={setOpen} />
                ))}
              </div>
            </section>
          ))}

          {open && <CodexSheet card={open} onClose={() => setOpen(null)} />}

          <Link
            to="/mall"
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              marginTop: 22, padding: 14, borderRadius: 16, textDecoration: 'none',
              fontSize: 13.5, fontWeight: 700, color: '#fff',
              background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
            }}
          >
            <Swords size={15} /> Get cards in the Mall
          </Link>
        </div>
      )}
    </div>
  )
}

function SectionLabel({ label, color, icon }: { label: string; color: string; icon?: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
      {icon
        ? <span style={{ color, display: 'flex' }}>{icon}</span>
        : <span style={{
            width: 7, height: 7, borderRadius: '50%', background: color, boxShadow: `0 0 8px ${color}`,
          }} />}
      <span style={{
        fontSize: 10.5, fontWeight: 800, letterSpacing: 0.9, textTransform: 'uppercase', color,
      }}>
        {label}
      </span>
      <span style={{ flex: 1, height: 1, background: 'var(--border)' }} />
    </div>
  )
}

function DeckRow({ card, mastery, onOpenCodex }: {
  card: PvpCard
  mastery?: CardMastery
  onOpenCodex: (m: CardMastery) => void
}) {
  const color = RARITY_COLOR[card.rarity] ?? 'var(--text-muted)'
  const uses = card.is_consumable ? card.copies : 0
  const rankColor = mastery ? RANK_COLOR[mastery.rank] ?? color : color
  const pct = mastery ? Math.round(masteryProgress(mastery) * 100) : 0

  return (
    <div style={{
      padding: '13px 14px', borderRadius: 15,
      border: card.owned ? `1px solid ${color}66` : '1px dashed var(--border-strong)',
      background: card.owned
        ? `linear-gradient(160deg, ${color}16, var(--surface))`
        : 'var(--surface)',
      opacity: card.owned ? 1 : 0.72,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 40, height: 40, borderRadius: 12, flexShrink: 0, display: 'grid', placeItems: 'center',
          background: card.owned ? `${color}26` : 'var(--surface3)',
          border: `1px solid ${card.owned ? `${color}55` : 'var(--border)'}`,
        }}>
          {card.owned
            ? card.is_consumable
              ? <Zap size={16} style={{ color }} />
              : <Check size={17} style={{ color }} />
            : <Swords size={16} style={{ color: 'var(--text-muted)' }} />}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>{card.name}</p>
            {card.owned && (card.is_consumable
              ? (
                <span style={{
                  fontSize: 9.5, fontWeight: 800, color, background: `${color}22`,
                  padding: '2px 6px', borderRadius: 6,
                }}>
                  ×{uses}
                </span>
              )
              : card.card_level > 1 && (
                <span style={{
                  fontSize: 9.5, fontWeight: 800, color, background: `${color}22`,
                  padding: '2px 6px', borderRadius: 6,
                }}>
                  LV {card.card_level}
                </span>
              ))}
          </div>

          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2, lineHeight: 1.4 }}>
            {!card.owned
              ? 'Not owned yet'
              : card.is_consumable
                ? uses === 1 ? 'One use left' : `${uses} uses left`
                : card.base_damage > 0
                  ? `${Math.round(card.current_damage)} damage${card.copies > 1 ? ` · ${card.copies} copies` : ''}`
                  : card.flavor ?? 'Owned'}
          </p>
        </div>

        {!card.owned && (
          <Link to="/mall" style={{ color, display: 'flex', flexShrink: 0 }} aria-label={`Get ${card.name}`}>
            <ChevronRight size={17} />
          </Link>
        )}
      </div>

      {/* Mastery lives under the row rather than beside it: the bar needs
          the full width to be readable at all, and squeezing it next to
          the damage line made both unreadable. */}
      {mastery && (
        <button
          onClick={() => onOpenCodex(mastery)}
          style={{
            display: 'flex', alignItems: 'center', gap: 9, width: '100%',
            marginTop: 11, padding: 0, background: 'none', border: 'none',
            cursor: 'pointer', textAlign: 'left',
          }}
        >
          <div style={{
            flex: 1, height: 5, borderRadius: 4, background: 'var(--surface3)', overflow: 'hidden',
          }}>
            <div style={{
              width: `${pct}%`, height: '100%', borderRadius: 4,
              background: `linear-gradient(90deg, ${rankColor}, ${rankColor}aa)`,
              transition: 'width 0.5s cubic-bezier(0.22,1,0.36,1)',
            }} />
          </div>
          <span style={{
            fontSize: 10, fontWeight: 800, letterSpacing: 0.4, color: rankColor, flexShrink: 0,
          }}>
            {mastery.rank_name.toUpperCase()}
          </span>
          <BookOpen size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
        </button>
      )}
    </div>
  )
}
