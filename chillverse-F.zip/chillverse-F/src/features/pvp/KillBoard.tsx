// src/features/pvp/KillBoard.tsx
//
// The Kill Board — every elimination anyone has ever landed, ranked, and
// the skull that goes to whoever is on top.
//
// This is the individual counterpart to the Arena's club board: same sport,
// no teams, and no week. It is deliberately its own page rather than a
// fourth Arena tab — the Arena's three boards are all about the state of
// play RIGHT NOW (who's wanted, whose club is winning this week, who's
// alive in the round), and this one is the opposite of that. It is the
// permanent record.
//
// The fact that nothing resets is the whole promise of the screen, so it
// lives behind the ⓘ rather than in a subtitle: a line of copy that never
// changes stops being read after the second visit, but a player who wants
// to know why their number never went down can still find out.
//
// Everything on a row is inert except the profile picture, which opens that
// player's profile — Avatar's `userId` prop is what wires that up (ownerId
// carries identity for decorations WITHOUT a click handler, which is not
// what's wanted here).
import { useEffect, useMemo, useState } from 'react'
import { Info, Skull, Swords } from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import Avatar from '../../shared/components/Avatar'
import { getUserRankTier } from '../profile/ranks'
import {
  getKillBoard, getMyKillStanding,
  type KillBoardEntry, type MyKillStanding,
} from './killBoard'
import './pvp-effects.css'

const BONE = '#e6e1da'
const OUT = '#ff4d6d'
const ACCENT = 'var(--accent)'

/* ── Atmosphere ─────────────────────────────────────────────────────────
 * Sixteen embers is enough to read as a drift and few enough not to cost
 * anything. Positions are generated once per mount, not per render, so
 * they don't jump every time the board refetches. */
const EMBERS = 16

function Atmosphere() {
  const embers = useMemo(
    () => Array.from({ length: EMBERS }, () => ({
      x: `${Math.random() * 100}%`,
      size: `${2 + Math.random() * 4}px`,
      dur: `${9 + Math.random() * 9}s`,
      delay: `${-Math.random() * 14}s`,
      drift: `${Math.random() * 60 - 30}px`,
    })),
    [],
  )

  return (
    <div className="kb-atmos" aria-hidden="true">
      <div className="kb-glow" />
      {embers.map((e, i) => (
        <span
          key={i}
          className="kb-ember"
          style={{
            '--x': e.x, '--size': e.size, '--dur': e.dur,
            '--delay': e.delay, '--drift': e.drift,
          } as React.CSSProperties}
        />
      ))}
    </div>
  )
}

/* ── Rows ───────────────────────────────────────────────────────────── */

/** Rank 1: the whole point of the board, so it gets its own shape. */
function BossCard({ entry }: { entry: KillBoardEntry }) {
  const name = entry.display_name || entry.username
  const rank = getUserRankTier(entry.active_rank_xp)

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '15px 14px', borderRadius: 18, marginBottom: 12,
      border: `1px solid ${BONE}52`,
      background: `linear-gradient(150deg, ${BONE}1a, rgba(255,59,48,0.06) 55%, var(--surface))`,
    }}>
      <div style={{ position: 'relative', flexShrink: 0 }}>
        <Avatar src={entry.avatar} name={name} userId={entry.user_id} size={52} />
        {entry.is_boss && (
          <span style={{
            position: 'absolute', bottom: -3, right: -4,
            width: 22, height: 22, borderRadius: '50%',
            display: 'grid', placeItems: 'center',
            background: 'var(--surface2)', border: `1px solid ${BONE}80`,
          }}>
            <Skull size={12} color={BONE} />
          </span>
        )}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          margin: 0, fontSize: 9, fontWeight: 900, letterSpacing: 1.3,
          textTransform: 'uppercase', color: BONE,
        }}>
          {entry.is_boss ? 'PvP Boss' : 'Top of the board'}
        </p>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 3 }}>
          <p style={{
            margin: 0, fontSize: 16, fontWeight: 800, color: 'var(--text)',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>
            {name}
          </p>
          <span style={{ fontSize: 10, fontWeight: 700, color: rank.color, flexShrink: 0 }}>
            {rank.name}
          </span>
        </div>
        <p style={{ margin: '2px 0 0', fontSize: 11.5, color: 'var(--text-muted)' }}>
          <b style={{ color: OUT, fontVariantNumeric: 'tabular-nums' }}>{entry.kills}</b>
          {entry.kills === 1 ? ' elimination' : ' eliminations'}
          <span style={{ fontVariantNumeric: 'tabular-nums' }}>
            {' · '}{entry.damage.toLocaleString()} damage
          </span>
        </p>
      </div>
    </div>
  )
}

function Row({ entry, isMe }: { entry: KillBoardEntry; isMe: boolean }) {
  const name = entry.display_name || entry.username

  return (
    <div className="neu-card" style={{
      display: 'flex', alignItems: 'center', gap: 11,
      padding: '11px 13px', borderRadius: 15,
      border: `1px solid ${isMe ? 'rgba(255,138,61,0.4)' : 'var(--border)'}`,
      background: isMe
        ? 'linear-gradient(140deg, rgba(255,138,61,0.10), var(--surface))'
        : 'var(--surface)',
    }}>
      <span style={{
        width: 22, flexShrink: 0, textAlign: 'center',
        fontSize: 13, fontWeight: 900,
        color: isMe ? ACCENT : 'var(--text-dim)',
        fontVariantNumeric: 'tabular-nums',
      }}>
        {entry.rank}
      </span>

      <Avatar src={entry.avatar} name={name} userId={entry.user_id} size={38} />

      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          margin: 0, fontSize: 13.5, fontWeight: 800, color: 'var(--text)',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {isMe ? 'You' : name}
        </p>
        <p style={{
          margin: '2px 0 0', fontSize: 10.5, color: 'var(--text-muted)',
          fontVariantNumeric: 'tabular-nums',
        }}>
          {entry.damage.toLocaleString()} damage
        </p>
      </div>

      <p style={{
        margin: 0, fontFamily: "'Bangers', system-ui, sans-serif",
        fontSize: 22, letterSpacing: 1, color: isMe ? ACCENT : OUT,
        fontVariantNumeric: 'tabular-nums',
      }}>
        {entry.kills}
      </p>
    </div>
  )
}

/** Pinned under the list when the caller isn't in the slice above it. */
function MyStanding({ standing }: { standing: MyKillStanding }) {
  const unranked = standing.my_rank === 0

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 11, marginTop: 12,
      padding: '12px 13px', borderRadius: 15,
      border: '1px solid rgba(255,138,61,0.4)',
      background: 'linear-gradient(140deg, rgba(255,138,61,0.10), var(--surface))',
    }}>
      <span style={{
        width: 22, flexShrink: 0, textAlign: 'center', fontSize: 13,
        fontWeight: 900, color: ACCENT, fontVariantNumeric: 'tabular-nums',
      }}>
        {unranked ? '—' : standing.my_rank}
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontSize: 13.5, fontWeight: 800, color: 'var(--text)' }}>You</p>
        <p style={{ margin: '2px 0 0', fontSize: 10.5, color: 'var(--text-muted)' }}>
          {unranked
            ? 'One takedown puts you on the board'
            : standing.next_name && standing.next_kills !== null
              ? `${standing.next_kills - standing.my_kills} more to pass ${standing.next_name}`
              : 'Nobody above you'}
        </p>
      </div>
      <p style={{
        margin: 0, fontFamily: "'Bangers', system-ui, sans-serif",
        fontSize: 22, letterSpacing: 1, color: ACCENT,
        fontVariantNumeric: 'tabular-nums',
      }}>
        {standing.my_kills}
      </p>
    </div>
  )
}

/* ── Page ───────────────────────────────────────────────────────────── */

export default function KillBoard() {
  const { session } = useAuth()
  const myId = session?.user?.id ?? null

  const [entries, setEntries] = useState<KillBoardEntry[]>([])
  const [standing, setStanding] = useState<MyKillStanding | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [infoOpen, setInfoOpen] = useState(false)

  useEffect(() => {
    let active = true
    Promise.all([getKillBoard(50), getMyKillStanding()])
      .then(([rows, mine]) => {
        if (!active) return
        setEntries(rows)
        setStanding(mine)
      })
      .catch(err => {
        if (active) setError(err instanceof Error ? err.message : 'Could not load the board.')
      })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])

  const boss = entries[0] ?? null
  const rest = entries.slice(1)
  // Only pin the caller's own row when it isn't already in the list above.
  const showMine = !!standing && !entries.some(e => e.user_id === myId)

  return (
    <div style={{ position: 'relative', padding: '16px 16px 40px' }}>
      <Atmosphere />

      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ position: 'relative', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Skull size={18} color={BONE} />
            <h1 style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', margin: 0, flex: 1 }}>
              Kill Board
            </h1>
            {!loading && !error && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0,
                padding: '7px 12px', borderRadius: 20,
                background: 'rgba(255,77,109,0.12)', border: '1px solid rgba(255,77,109,0.3)',
              }}>
                <Swords size={12} color={OUT} />
                <span style={{ fontSize: 11.5, fontWeight: 700, color: OUT }}>
                  {standing?.ranked_total ?? entries.length} ranked
                </span>
              </div>
            )}
            <button
              type="button"
              onClick={() => setInfoOpen(v => !v)}
              aria-label="How the Kill Board works"
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                width: 26, height: 26, borderRadius: '50%', cursor: 'pointer',
                background: infoOpen ? 'var(--surface3)' : 'var(--surface)',
                border: `1px solid ${infoOpen ? 'var(--border-strong)' : 'var(--border)'}`,
                color: 'var(--text-dim)',
              }}
            >
              <Info size={13} />
            </button>
          </div>

          {infoOpen && (
            <>
              <div style={{ position: 'fixed', inset: 0, zIndex: 99 }} onClick={() => setInfoOpen(false)} />
              <div style={{
                position: 'absolute', top: '100%', right: 0, marginTop: 8, zIndex: 100,
                width: 258, padding: '12px 14px', borderRadius: 14,
                background: 'var(--surface2)', border: '1px solid var(--border)',
                boxShadow: 'var(--elev-popover)',
              }}>
                <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.55 }}>
                  Every player you've ever finished off, counted from the day you
                  started. Nothing here resets — not weekly, not after an
                  elimination round, not ever. The only way your number moves is up.
                  Ties are broken by total damage. Whoever sits at number one wears
                  the skull and holds the <b style={{ color: BONE }}>PvP Boss</b> badge
                  until somebody takes it off them.
                </p>
              </div>
            </>
          )}
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
            <span style={{
              width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
              borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
            }} />
          </div>
        ) : error ? (
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', padding: '40px 0' }}>
            {error}
          </p>
        ) : entries.length === 0 ? (
          <div className="neu-card" style={{ padding: '34px 20px', textAlign: 'center' }}>
            <Skull size={22} color="var(--text-dim)" style={{ marginBottom: 8 }} />
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: '0 0 4px' }}>
              Nobody has taken anyone down yet
            </p>
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
              The first player to finish someone opens this board — and wears the
              skull until they're beaten.
            </p>
          </div>
        ) : (
          <>
            {boss && <BossCard entry={boss} />}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {rest.map(entry => (
                <Row key={entry.user_id} entry={entry} isMe={entry.user_id === myId} />
              ))}
            </div>
            {showMine && standing && <MyStanding standing={standing} />}
          </>
        )}
      </div>
    </div>
  )
}
