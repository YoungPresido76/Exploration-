// src/features/pvp/StoneVeil.tsx
//
// The ten minutes a Medusa Curse buys. The attack animation is a moment;
// this is the wait.
//
// Mount once, next to <CorruptionVeil /> in AppLayout.
//
// Sibling of CorruptionVeil, and deliberately so — same edge-only
// vignette geometry, same "driven off a server timestamp, never a
// setTimeout" rule. Three things differ, each for a reason:
//
//  1. RED, not brown. Rust is a debuff you carry around; this is a fuse.
//
//  2. It runs the FULL ten minutes rather than rust's two. Rust's veil is
//     an alert and the badge carries the rest, so a long veil would be
//     punishment. This veil IS the clock — it ends when the damage lands.
//
//  3. It carries a live countdown. Nothing else in the app tells the
//     player when the stone breaks.
//
// A plain Petrify (shatter 0) gets the veil and the word, but no clock:
// it expires quietly, and counting down to nothing would be a lie.
import { useEffect, useMemo, useState } from 'react'
import { useMyPvpStatus } from './useMyPvpStatus'
import './pvp-effects.css'

/** Matches the .pvp-veil-out animation, so the fade isn't cut short. */
const FADE_MS = 2_600
/** Below this, everything on screen quickens. */
const URGENT_MS = 60_000

function mmss(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000))
  return String(Math.floor(total / 60)).padStart(2, '0') + ':' + String(total % 60).padStart(2, '0')
}

export default function StoneVeil({ enabled = true }: { enabled?: boolean }) {
  const { petrified, petrifyExpiresAt, petrifyShatter } = useMyPvpStatus()

  // Recomputed rather than stored, so a second stone landing (which moves
  // the expiry forward) restarts the veil instead of being swallowed by a
  // timer that's already running.
  const endsAt = useMemo(() => {
    if (!petrified || !petrifyExpiresAt) return null
    return new Date(petrifyExpiresAt).getTime()
  }, [petrified, petrifyExpiresAt])

  const [phase, setPhase] = useState<'off' | 'on' | 'fading'>('off')
  const [left, setLeft] = useState(0)

  useEffect(() => {
    if (!enabled || endsAt == null) { setPhase('off'); return }

    const tick = () => {
      const ms = endsAt - Date.now()
      setLeft(ms)
      // Reopening the app with 40 seconds left should pick up where the
      // clock actually is, including starting straight into the fade
      // rather than replaying the whole ten minutes.
      if (ms <= 0) setPhase('off')
      else if (ms <= FADE_MS) setPhase('fading')
      else setPhase('on')
    }

    tick()
    // 250ms rather than 1000: a second-resolution clock driven on a
    // one-second interval visibly stutters, because the interval and the
    // second boundary drift apart.
    const id = window.setInterval(tick, 250)
    return () => window.clearInterval(id)
  }, [enabled, endsAt])

  if (phase === 'off') return null

  const urgent = left <= URGENT_MS
  const isMedusa = petrifyShatter > 0

  return (
    <div className={`pvp-stone${urgent ? ' pvp-stone-urgent' : ''}`}>
      <div
        className={`pvp-stone-veil${phase === 'fading' ? ' pvp-veil-out' : ''}`}
        aria-hidden="true"
      />

      {/* Hairline veining in the corners — the one thing rust doesn't
          have, and what makes this read as petrified rather than as
          "you are bleeding". */}
      <svg className="pvp-stone-cracks" viewBox="0 0 380 760" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0 92 L44 140 L28 196 L74 236" strokeWidth="1.4" />
        <path d="M44 140 L96 128" strokeWidth="1" />
        <path d="M380 168 L330 208 L346 262 L300 300" strokeWidth="1.4" />
        <path d="M330 208 L286 190" strokeWidth="1" />
        <path d="M0 604 L52 566 L40 512" strokeWidth="1.2" />
        <path d="M380 636 L322 596 L338 548" strokeWidth="1.2" />
        <path d="M148 0 L166 46 L134 82" strokeWidth="1" />
        <path d="M226 760 L212 706 L246 668" strokeWidth="1" />
      </svg>

      <div className="pvp-stone-pill" role="status">
        <i />
        {isMedusa ? 'CURSED' : 'PETRIFIED'}
        {isMedusa && <b>{mmss(left)}</b>}
      </div>
    </div>
  )
}
