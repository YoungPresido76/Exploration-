// src/features/pvp/BountyPoster.tsx
//
// The wanted poster. Deliberately shares NOTHING with PromoOverlay's
// chrome — it borrows the delivery idea (one at a time, once per user
// ever, slotted into AppLayout's priority chain) and nothing else. A
// bounty that looked like the daily announcement would read as another
// admin notice rather than as a contract.
//
// All of it is CSS and type, no image assets: the parchment is a
// clip-path polygon over layered gradients, the stains are radial
// gradients, the seal is a blob with a border-radius. Grenze Gotisch is
// already loaded in index.html for the pirate profile skin.
import { useEffect } from 'react'
import { Swords, X } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import type { Bounty } from './bounties'

interface BountyPosterProps {
  bounty: Bounty
  /** Fired by both buttons and the scrim — the poster is one-shot either way. */
  onDismiss: () => void
  /** Opens the target's profile with the attack sheet already up. */
  onAccept: (targetId: string) => void
}

export default function BountyPoster({ bounty, onDismiss, onAccept }: BountyPosterProps) {
  const name = bounty.display_name || bounty.username

  // Same body lock + dock hide every other full-screen sheet uses. The
  // dock is portaled to <body> in its own stacking context, so z-index
  // alone can't outrank it — see .sheet-or-modal-over-dock in index.css.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  return (
    <div
      className="sheet-or-modal sheet-or-modal-over-dock"
      onClick={onDismiss}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050,
        display: 'grid', placeItems: 'center', padding: 20,
        background: 'radial-gradient(circle at 50% 40%, rgba(40,20,6,0.72), rgba(0,0,0,0.88))',
        backdropFilter: 'blur(4px)',
        animation: 'cvBountyFade 0.22s ease',
      }}
    >
      <style>{`
        @keyframes cvBountyFade { from { opacity: 0 } to { opacity: 1 } }
        /* Slams in, then settles. The overshoot and the two shakes are one
           keyframe track rather than two animations so they can't drift
           out of step on a slow device. */
        @keyframes cvBountySlam {
          0%   { opacity: 0; transform: scale(1.5) rotate(-7deg) }
          55%  { opacity: 1; transform: scale(0.95) rotate(1.4deg) }
          68%  { transform: scale(1.02) rotate(-1.6deg) }
          80%  { transform: scale(0.99) rotate(1deg) }
          90%  { transform: rotate(-0.5deg) }
          100% { transform: scale(1) rotate(-0.8deg) }
        }
        @keyframes cvBountySeal {
          from { opacity: 0; transform: scale(2.2) rotate(20deg) }
          to   { opacity: 1; transform: scale(1) rotate(-9deg) }
        }
        .cv-bounty-sheet {
          animation: cvBountySlam 0.62s cubic-bezier(0.2,0.9,0.3,1.1) both;
        }
        @media (prefers-reduced-motion: reduce) {
          .cv-bounty-sheet { animation: cvBountyFade 0.25s ease both }
        }
      `}</style>

      <div
        className="cv-bounty-sheet"
        onClick={e => e.stopPropagation()}
        style={{
          position: 'relative', width: '100%', maxWidth: 330,
          padding: '30px 24px 26px',
          // Aged paper: a warm base, two blotches of damp, and a vignette
          // that darkens toward the torn edges.
          background: `
            radial-gradient(ellipse at 22% 18%, rgba(120,82,36,0.20), transparent 46%),
            radial-gradient(ellipse at 82% 74%, rgba(96,60,22,0.24), transparent 44%),
            radial-gradient(ellipse at 50% 50%, #efdcb4 8%, #e4cfa4 42%, #d8c095 74%, #b99a6a 100%)
          `,
          // Torn top and bottom. The left/right stay straight so the copy
          // has a reliable measure to sit in.
          clipPath: `polygon(
            0% 3%, 9% 0%, 19% 3.4%, 31% 0.6%, 43% 3.6%, 55% 0.4%, 68% 3.4%, 80% 0.8%, 91% 3.6%, 100% 1.4%,
            100% 97%, 90% 100%, 79% 96.6%, 67% 99.4%, 55% 96.4%, 43% 99.6%, 31% 96.6%, 19% 99.2%, 8% 96.4%, 0% 98.6%
          )`,
          boxShadow: '0 26px 60px rgba(0,0,0,0.7)',
          textAlign: 'center',
        }}
      >
        <button
          type="button" onClick={onDismiss} aria-label="Ignore"
          style={{
            position: 'absolute', top: 16, right: 14, background: 'none',
            border: 'none', cursor: 'pointer', color: 'rgba(74,48,20,0.5)', padding: 4,
          }}
        >
          <X size={16} />
        </button>

        <p style={{
          fontFamily: "'Grenze Gotisch', Georgia, serif",
          fontSize: 46, lineHeight: 1, letterSpacing: 5,
          color: '#3d2410', margin: '0 0 2px',
          textShadow: '0 1px 0 rgba(255,245,220,0.55)',
        }}>
          WANTED
        </p>
        <p style={{
          fontFamily: "'Grenze Gotisch', Georgia, serif",
          fontSize: 13, letterSpacing: 3.5, color: 'rgba(61,36,16,0.62)',
          margin: '0 0 18px', textTransform: 'uppercase',
        }}>
          Dead or alive
        </p>

        <div style={{
          display: 'inline-block', padding: 5, borderRadius: '50%',
          background: 'rgba(61,36,16,0.10)',
          border: '2px solid rgba(61,36,16,0.42)',
          boxShadow: 'inset 0 2px 10px rgba(61,36,16,0.25)',
        }}>
          {/* No userId — the poster's own buttons own every tap here, and
              passing it would wire a second, competing action onto the
              avatar itself. */}
          <Avatar src={bounty.avatar} name={name} size={96} />
        </div>

        <p style={{
          fontFamily: "'Grenze Gotisch', Georgia, serif",
          fontSize: 26, lineHeight: 1.15, color: '#3d2410',
          margin: '14px 0 0', wordBreak: 'break-word',
        }}>
          {name}
        </p>
        <p style={{
          fontSize: 11, color: 'rgba(61,36,16,0.6)', margin: '1px 0 0', fontWeight: 600,
        }}>
          @{bounty.username}
        </p>

        <div style={{
          margin: '16px auto 0', width: '78%', height: 1,
          background: 'linear-gradient(90deg, transparent, rgba(61,36,16,0.4), transparent)',
        }} />

        <p style={{
          fontFamily: "'Grenze Gotisch', Georgia, serif",
          fontSize: 15, letterSpacing: 2.4, color: 'rgba(61,36,16,0.66)',
          margin: '12px 0 2px', textTransform: 'uppercase',
        }}>
          Reward
        </p>
        <p style={{
          fontFamily: "'Grenze Gotisch', Georgia, serif",
          fontSize: 40, lineHeight: 1.05, color: '#7a2d10', margin: 0,
          textShadow: '0 1px 0 rgba(255,245,220,0.5)',
        }}>
          💎 {bounty.reward_gems.toLocaleString()}
        </p>

        {bounty.note && (
          <p style={{
            fontSize: 12, fontStyle: 'italic', lineHeight: 1.5,
            color: 'rgba(61,36,16,0.72)', margin: '12px 4px 0',
          }}>
            “{bounty.note}”
          </p>
        )}

        <p style={{
          fontSize: 12.5, fontWeight: 700, color: 'rgba(61,36,16,0.8)',
          margin: '14px 0 18px',
        }}>
          Take them down to collect.
        </p>

        <button
          type="button"
          onClick={() => onAccept(bounty.target_id)}
          style={{
            width: '100%', padding: '13px', borderRadius: 4, cursor: 'pointer',
            fontFamily: "'Grenze Gotisch', Georgia, serif",
            fontSize: 19, letterSpacing: 1.4, color: '#f3e2bd',
            background: 'linear-gradient(180deg, #6d2a12, #4a1a0a)',
            border: '1px solid rgba(61,36,16,0.75)',
            boxShadow: '0 4px 0 rgba(45,24,10,0.55), inset 0 1px 0 rgba(255,220,170,0.18)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
          }}
        >
          <Swords size={16} /> Accept the contract
        </button>

        <button
          type="button"
          onClick={onDismiss}
          style={{
            marginTop: 9, background: 'none', border: 'none', cursor: 'pointer',
            fontSize: 12, fontWeight: 700, color: 'rgba(61,36,16,0.55)',
            fontFamily: 'inherit', padding: 6,
          }}
        >
          Ignore
        </button>

        {/* Wax seal. Sits half off the corner so the poster reads as
            something stamped and nailed up rather than a card. */}
        <div
          aria-hidden
          style={{
            position: 'absolute', bottom: 14, left: -14,
            width: 62, height: 62,
            background: 'radial-gradient(circle at 34% 30%, #a8321c, #6d1c0c 70%)',
            borderRadius: '46% 54% 52% 48% / 50% 44% 56% 50%',
            boxShadow: 'inset 0 -3px 8px rgba(0,0,0,0.42), 0 3px 9px rgba(0,0,0,0.42)',
            display: 'grid', placeItems: 'center',
            fontFamily: "'Grenze Gotisch', Georgia, serif",
            fontSize: 25, color: 'rgba(255,222,190,0.82)',
            animation: 'cvBountySeal 0.4s 0.5s cubic-bezier(0.2,0.9,0.3,1.3) both',
          }}
        >
          CV
        </div>
      </div>
    </div>
  )
}
