// src/features/pvp/EliminationDashboardCard.tsx
//
// Elimination Weekend on the dashboard.
//
// Four states, and the card is only ever in one of them:
//
//   dormant       Monday to Tuesday. Greyed out, and tapping toasts rather
//                 than opening anything — there is genuinely nothing to do
//                 yet, and a sheet that says "come back Wednesday" is worse
//                 than a one-line toast that says it in place.
//   registering   Wednesday 00:00 → Friday 12:00 Lagos (server clock — the
//                 card itself only ever shows countdowns). Opens the sheet.
//   registered    Same window, already signed up. Still opens the sheet, so
//                 the rules stay readable, but the button inside is spent.
//   live          Friday 20:00 → Monday 00:00. Points at the Arena, whether
//                 you're fighting in it or watching it.
//
// It reads useElimination, which is a module-level store shared with the
// Arena tab and the down-modal — mounting this card costs a subscription,
// not another round trip.
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronRight, Skull, Clock, Check, Users } from 'lucide-react'
import Toast, { useToast } from '../../shared/components/Toast'
import { useElimination } from './useElimination'
import EliminationRegisterSheet from './EliminationRegisterSheet'

const DANGER = '#ff4d6d'
const ALIVE = '#3ecf8e'
const GOLD = '#f5c542'

/**
 * The live line inside the card while a round runs.
 *
 * One message at a time on a 3.2s rotation rather than a marquee: a phone
 * card is ~200px of usable width, and text that slides past is unreadable
 * at that size. Swapping in place also means no keyframes and nothing
 * animating off-screen when the dashboard is scrolled away.
 */
function Ticker({ lines }: { lines: { text: string; color: string }[] }) {
  const [i, setI] = useState(0)
  const [shown, setShown] = useState(true)

  useEffect(() => {
    if (lines.length <= 1) return
    // Fade out, swap, fade back — two timers so the text never changes
    // while it is still visible.
    const hide = window.setInterval(() => {
      setShown(false)
      window.setTimeout(() => {
        setI(n => (n + 1) % lines.length)
        setShown(true)
      }, 240)
    }, 3200)
    return () => window.clearInterval(hide)
  }, [lines.length])

  // A shrinking list (someone gets eliminated) must not strand the index
  // past the end of it.
  const line = lines[Math.min(i, lines.length - 1)]
  if (!line) return null

  return (
    // A fixed height so the card doesn't jump as lines of different lengths
    // swap through, but tall enough to clear descenders and the 4px slide —
    // the first cut of this was 15px and clipped every line in half.
    <div style={{ height: 19, display: 'flex', alignItems: 'center', overflow: 'hidden' }}>
      <span style={{
        display: 'block', fontSize: 11.5, fontWeight: 800, lineHeight: 1.35,
        color: line.color, whiteSpace: 'nowrap',
        overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%',
        opacity: shown ? 1 : 0,
        transform: shown ? 'translateY(0)' : 'translateY(4px)',
        transition: 'opacity .22s ease, transform .22s ease',
      }}>
        {line.text}
      </span>
    </div>
  )
}

/** Deliberately light. The card is a nudge, not a countdown clock. */
function gapLabel(iso: string | null): string {
  if (!iso) return ''
  const ms = new Date(iso).getTime() - Date.now()
  if (ms <= 0) return 'any moment'
  const hours = Math.floor(ms / 3_600_000)
  if (hours >= 24) return `${Math.floor(hours / 24)}d ${hours % 24}h`
  if (hours >= 1) return `${hours}h`
  return `${Math.max(1, Math.floor(ms / 60_000))}m`
}

export default function EliminationDashboardCard() {
  const { status, loaded } = useElimination()
  const [sheetOpen, setSheetOpen] = useState(false)
  const { toast, showToast } = useToast()
  const navigate = useNavigate()

  // What the round is worth, live. Every figure comes from
  // pvp_elimination_status(), which scores them with the same function the
  // payout uses — nothing here is re-derived, so the ticker can't quote a
  // number the wallet won't honour. Lines that would say nothing (no pot,
  // no leader, not entered) are left out rather than shown as zero.
  //
  // ABOVE the early return, deliberately. This component returns null until
  // the status lands, so a hook placed after that line runs on the second
  // render and not the first — which is React #310 ("rendered more hooks
  // than during the previous render") and takes the whole dashboard down.
  // Every hook in this file has to sit above that return.
  const tickerLines = useMemo(() => {
    if (!status?.is_active) return []
    const out: { text: string; color: string }[] = []
    if (status.reward_pot > 0) {
      out.push({ text: `🎟 ${status.reward_pot} Vouchers on the line`, color: GOLD })
    }
    if (status.me_entered && !status.me_eliminated) {
      out.push({
        text: status.me_reward > 0
          ? `Your worth: ${status.me_reward} Vouchers`
          : 'Your worth: nothing yet — go hunting',
        color: status.me_reward > 0 ? ALIVE : 'var(--text-muted)',
      })
    }
    if (status.top_name && status.top_kills) {
      out.push({
        text: `👑 ${status.top_name} leads · ${status.top_kills} ${status.top_kills === 1 ? 'kill' : 'kills'}`,
        color: DANGER,
      })
    }
    out.push({ text: '+1 Voucher every takedown', color: 'var(--text-muted)' })
    return out
  }, [status])

  // Until the status lands there is nothing honest to draw, and a skeleton
  // for one small card is more flicker than it's worth.
  if (!loaded || !status) return null

  const live = status.is_active
  const open = status.registration_open
  const mine = status.me_registered

  const state: 'live' | 'registered' | 'registering' | 'dormant' =
    live ? 'live' : mine && open ? 'registered' : open ? 'registering' : 'dormant'

  const dormant = state === 'dormant'

  function tap() {
    if (state === 'live') { navigate('/most-wanted?tab=elimination'); return }
    if (dormant) {
      showToast({
        message: `Chill — only on weekends. Sign-ups open in ${gapLabel(status?.registration_opens_at ?? null)}.`,
        icon: Clock,
        iconColor: 'var(--text-muted)',
      })
      return
    }
    setSheetOpen(true)
  }

  const accent = dormant ? 'var(--text-dim)' : state === 'registered' ? ALIVE : DANGER

  const subtitle =
    state === 'live'
      ? `${status.standing} still standing · ends in ${gapLabel(status.ends_at)}`
      : state === 'registered'
        // A countdown rather than "Friday 20:00": that wall clock is
        // Lagos's, and a card this narrow has no room for a zone label.
        ? `You're in — starts in ${gapLabel(status.starts_at)}`
        : state === 'registering'
          ? `Sign-ups close in ${gapLabel(status.registration_closes_at)}`
          : `Sign-ups open in ${gapLabel(status.registration_opens_at)}`

  return (
    <>
      <button
        type="button"
        onClick={tap}
        className="neu-card"
        style={{
          width: '100%', display: 'block',
          padding: 16, marginTop: 12, cursor: 'pointer',
          fontFamily: 'inherit', textAlign: 'left',
          position: 'relative', overflow: 'hidden',
          opacity: dormant ? 0.55 : 1,
          border: dormant ? '1px solid var(--border)' : `1px solid ${accent}3d`,
          background: dormant
            ? 'var(--surface)'
            : `linear-gradient(140deg, ${accent}12, var(--surface))`,
        }}
      >
       <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{
          width: 46, height: 46, borderRadius: 14, flexShrink: 0,
          display: 'grid', placeItems: 'center',
          background: dormant ? 'var(--surface3)' : `${accent}1f`,
          border: dormant ? '1px solid var(--border)' : `1px solid ${accent}44`,
          color: accent,
        }}>
          {state === 'registered' ? <Check size={20} /> : <Skull size={20} />}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 2 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
              Elimination Weekend
            </span>
            {live && (
              <span style={{
                fontSize: 8.5, fontWeight: 900, letterSpacing: 0.8,
                textTransform: 'uppercase', color: DANGER,
                padding: '2px 6px', borderRadius: 6,
                background: `${DANGER}1f`, border: `1px solid ${DANGER}55`,
              }}>
                Live
              </span>
            )}
          </div>
          <div style={{
            fontSize: 11.5, color: 'var(--text-muted)',
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          }}>
            {subtitle}
          </div>

          {!dormant && status.registered_count > 0 && !live && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 5, marginTop: 6,
              fontSize: 10.5, fontWeight: 700, color: accent,
            }}>
              <Users size={11} /> {status.registered_count} registered
            </div>
          )}
        </div>

        <ChevronRight size={19} style={{ flexShrink: 0, color: dormant ? 'var(--text-dim)' : accent }} />
       </div>

        {/* The live line gets the full width of the card on its own row,
            under a hairline. Nested beside the subtitle it had ~150px to
            work with between the icon and the chevron, and every line was
            clipped mid-word. This is the only part of the card that
            changes while you look at it, so it earns the space. */}
        {live && tickerLines.length > 0 && (
          <div style={{
            marginTop: 11, paddingTop: 10,
            borderTop: `1px solid ${accent}26`,
          }}>
            <Ticker lines={tickerLines} />
          </div>
        )}
      </button>

      {sheetOpen && (
        <EliminationRegisterSheet
          status={status}
          onClose={() => setSheetOpen(false)}
        />
      )}

      <Toast toast={toast} />
    </>
  )
}
