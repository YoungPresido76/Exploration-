// src/features/pvp/EliminationSpectator.tsx
//
// What the round looks like when you're not in it.
//
// Two groups land here: players who never registered, and players who did
// and have already been knocked out. Neither can act on the fighters' board
// — no attack button does anything for them, the reward figures are not
// theirs, and the roll call of nineteen strangers is somebody else's
// business. Showing them the same screen with everything greyed out makes
// the round feel closed. This makes it feel like a stadium.
//
// So: the score, the people they follow who are in it, and one thing to do.
// A cheer carries NO gameplay effect — no HP, no vouchers, no board
// position — and that is deliberate. The moment it does, spectators become
// a resource to farm and fighters start begging for taps.
import { useCallback, useEffect, useState } from 'react'
import { Clock, Eye, PartyPopper, Skull, Ticket, UserPlus } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import Toast, { useToast } from '../../shared/components/Toast'
import { getUserRankTier } from '../profile/ranks'
import {
  getEliminationFollowing, sendCheer,
  type EliminationFollow, type EliminationStatus,
} from './pvp'

const ALIVE = '#3ecf8e'
const OUT = '#ff4d6d'
const GOLD = '#f5c542'
const CHEER = '#c084fc'

function formatGap(ms: number): string {
  if (ms <= 0) return 'any moment'
  const mins = Math.floor(ms / 60_000)
  const hours = Math.floor(mins / 60)
  if (hours >= 24) return `${Math.floor(hours / 24)}d ${hours % 24}h`
  if (hours >= 1) return `${hours}h ${mins % 60}m`
  return `${Math.max(1, mins)}m`
}

/* ── The one line that moves ────────────────────────────────────────────
 * Same rotation the dashboard card uses. "In spectator mode" is always
 * first, because that is the thing this screen has to say before anything
 * else explains itself. */
function SpectatorTicker({ lines }: { lines: { text: string; color: string }[] }) {
  const [i, setI] = useState(0)
  const [shown, setShown] = useState(true)

  useEffect(() => {
    if (lines.length <= 1) return
    const id = window.setInterval(() => {
      setShown(false)
      window.setTimeout(() => {
        setI(n => (n + 1) % lines.length)
        setShown(true)
      }, 240)
    }, 3200)
    return () => window.clearInterval(id)
  }, [lines.length])

  const line = lines[Math.min(i, lines.length - 1)]
  if (!line) return null

  return (
    <div style={{ height: 19, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <span style={{
        fontSize: 11.5, fontWeight: 800, lineHeight: 1.35, color: line.color,
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%',
        opacity: shown ? 1 : 0,
        transform: shown ? 'translateY(0)' : 'translateY(4px)',
        transition: 'opacity .22s ease, transform .22s ease',
      }}>
        {line.text}
      </span>
    </div>
  )
}

/* ── Confirm sheet ─────────────────────────────────────────────────────── */

function CheerModal({
  target, busy, onSend, onClose,
}: {
  target: EliminationFollow
  busy: boolean
  onSend: () => void
  onClose: () => void
}) {
  const name = target.display_name || target.username

  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [])

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050, display: 'grid', placeItems: 'center',
        padding: 22, background: 'rgba(4,4,6,0.86)', backdropFilter: 'blur(3px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 330, padding: '24px 20px 20px', borderRadius: 20,
          textAlign: 'center', border: `1px solid ${CHEER}52`,
          background: `radial-gradient(120% 80% at 50% 0%, ${CHEER}26, var(--surface) 68%)`,
          boxShadow: '0 26px 60px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{
          width: 54, height: 54, borderRadius: '50%', margin: '0 auto',
          display: 'grid', placeItems: 'center',
          background: `${CHEER}24`, border: `1px solid ${CHEER}66`,
        }}>
          <PartyPopper size={25} color={CHEER} />
        </div>

        <h3 style={{
          fontFamily: "'Bangers', system-ui, sans-serif", fontSize: 25, letterSpacing: 1,
          color: 'var(--text)', margin: '13px 0 0',
        }}>
          Send a cheer
        </h3>
        <p style={{ fontSize: 12.5, lineHeight: 1.6, color: 'var(--text-muted)', margin: '9px 0 0' }}>
          <b style={{ color: 'var(--text)' }}>@{target.username}</b> gets it right now, while
          they're still standing. It won't heal them or win them anything — it
          just tells them somebody's watching.
        </p>
        <p style={{ fontSize: 11, color: 'var(--text-dim)', margin: '8px 0 0' }}>
          One cheer each per round.
        </p>

        <button
          type="button"
          onClick={onSend}
          disabled={busy}
          style={{
            width: '100%', marginTop: 17, padding: '12px 14px', borderRadius: 13,
            border: 'none', cursor: busy ? 'not-allowed' : 'pointer', fontFamily: 'inherit',
            fontSize: 13, fontWeight: 800, color: '#fff',
            background: `linear-gradient(120deg, ${CHEER}, #7c3aed)`,
            boxShadow: `0 8px 22px ${CHEER}3d`, opacity: busy ? 0.6 : 1,
          }}
        >
          {busy ? 'Sending…' : `Cheer ${name}`}
        </button>
        <button
          type="button"
          onClick={onClose}
          style={{
            width: '100%', marginTop: 8, padding: '10px', borderRadius: 12,
            background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            fontSize: 12.5, fontWeight: 700, color: 'var(--text-muted)',
          }}
        >
          Not now
        </button>
      </div>
    </div>
  )
}

/* ── Rows ───────────────────────────────────────────────────────────────── */

function FollowRow({
  entry, onCheer,
}: {
  entry: EliminationFollow
  onCheer: (entry: EliminationFollow) => void
}) {
  const out = entry.eliminated_at !== null
  const name = entry.display_name || entry.username
  const rank = getUserRankTier(entry.active_rank_xp)
  const hpPct = entry.max_hp > 0 ? Math.round((entry.hp / entry.max_hp) * 100) : 0

  return (
    <div
      className="neu-card"
      style={{
        display: 'flex', alignItems: 'center', gap: 11, padding: '12px 13px', borderRadius: 15,
        border: `1px solid ${out ? 'var(--border)' : `${ALIVE}33`}`,
        background: out ? 'var(--surface)' : `linear-gradient(150deg, ${ALIVE}0f, var(--surface))`,
        opacity: out ? 0.62 : 1,
      }}
    >
      <div style={{ position: 'relative', flexShrink: 0 }}>
        <Avatar src={entry.avatar} name={name} ownerId={entry.user_id} size={40} />
        {out && (
          <span style={{
            position: 'absolute', inset: 0, borderRadius: '50%',
            display: 'grid', placeItems: 'center', background: 'rgba(10,10,14,0.55)',
          }}>
            <Skull size={15} color={OUT} />
          </span>
        )}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <p style={{
            fontSize: 13.5, fontWeight: 800, color: 'var(--text)', margin: 0,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            textDecoration: out ? 'line-through' : 'none',
          }}>
            {name}
          </p>
          <span style={{ fontSize: 10, fontWeight: 700, color: rank.color, flexShrink: 0 }}>
            {rank.name}
          </span>
        </div>
        {out ? (
          <p style={{ fontSize: 10.5, color: 'var(--text-muted)', margin: '2px 0 0' }}>
            Out{entry.eliminated_by_name ? ` — ${entry.eliminated_by_name} got them` : ''}
          </p>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 5 }}>
            <div style={{
              flex: 1, height: 4, borderRadius: 3, background: 'var(--surface3)',
              boxShadow: 'var(--elev-inset)', overflow: 'hidden', minWidth: 30,
            }}>
              <div style={{
                width: `${hpPct}%`, height: '100%', borderRadius: 3,
                background: hpPct <= 33 ? OUT : hpPct <= 66 ? '#f5a742' : ALIVE,
              }} />
            </div>
            <span style={{
              fontSize: 9.5, fontWeight: 700, color: 'var(--text-dim)', flexShrink: 0,
              fontVariantNumeric: 'tabular-nums',
            }}>
              {entry.hp} HP
            </span>
          </div>
        )}
      </div>

      {/* Spent cheers stay visible rather than disappearing — a row that
          loses its button looks broken, and "already sent" is information. */}
      {!out && (
        <button
          type="button"
          onClick={() => onCheer(entry)}
          disabled={entry.cheered}
          aria-label={entry.cheered ? `Already cheered ${name}` : `Cheer ${name}`}
          style={{
            flexShrink: 0, minWidth: 38, height: 36, padding: '0 10px', borderRadius: 12,
            cursor: entry.cheered ? 'default' : 'pointer',
            display: 'grid', placeItems: 'center', fontSize: 17, lineHeight: 1,
            background: entry.cheered ? 'var(--surface2)' : `${CHEER}1f`,
            border: `1px solid ${entry.cheered ? 'var(--border)' : `${CHEER}52`}`,
            opacity: entry.cheered ? 0.5 : 1,
          }}
        >
          🎉
        </button>
      )}
    </div>
  )
}

/* ── Screen ─────────────────────────────────────────────────────────────── */

export default function EliminationSpectator({ status }: { status: EliminationStatus }) {
  const [rows, setRows] = useState<EliminationFollow[]>([])
  const [loading, setLoading] = useState(true)
  const [picked, setPicked] = useState<EliminationFollow | null>(null)
  const [sending, setSending] = useState(false)
  const { toast, showToast } = useToast()
  const [, setClockTick] = useState(0)

  const load = useCallback(() => {
    let active = true
    setLoading(true)
    getEliminationFollowing()
      .then(r => { if (active) setRows(r) })
      .catch(() => { if (active) setRows([]) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])

  useEffect(() => load(), [load])

  useEffect(() => {
    const id = window.setInterval(() => setClockTick(t => t + 1), 30_000)
    return () => window.clearInterval(id)
  }, [])

  const live = status.is_active
  const gapMs = new Date(live ? status.ends_at : status.starts_at).getTime() - Date.now()

  async function cheer() {
    if (!picked || sending) return
    setSending(true)
    try {
      const res = await sendCheer(picked.user_id)
      // Flip the row locally rather than refetching the list: one boolean
      // changed and the round is otherwise unmoved.
      setRows(prev => prev.map(r => (r.user_id === picked.user_id ? { ...r, cheered: true } : r)))
      showToast({
        message: res.already
          ? `You already cheered ${picked.display_name || picked.username}.`
          : `Cheer sent to ${picked.display_name || picked.username}.`,
        icon: PartyPopper,
        iconColor: CHEER,
      })
      setPicked(null)
    } catch (err) {
      showToast({
        message: err instanceof Error ? err.message : 'Could not send that cheer.',
        icon: PartyPopper,
        iconColor: 'var(--text-muted)',
      })
    } finally {
      setSending(false)
    }
  }

  const tickerLines = [
    { text: '👀 In spectator mode', color: 'var(--text-muted)' },
    ...(status.reward_pot > 0
      ? [{ text: `🎟 ${status.reward_pot} Vouchers on the line`, color: GOLD }]
      : []),
    ...(status.top_name && status.top_kills
      ? [{ text: `👑 ${status.top_name} leads · ${status.top_kills} ${status.top_kills === 1 ? 'kill' : 'kills'}`, color: OUT }]
      : []),
  ]

  return (
    <div>
      {/* ── The score, and nothing to press ──────────────────────────── */}
      <div
        className={`neu-card${live ? ' elim-hero' : ''}`}
        style={{
          position: 'relative', padding: '20px 18px 15px', borderRadius: 18, marginBottom: 10,
          border: '1px solid var(--border)',
          background: live
            ? `radial-gradient(120% 90% at 50% -10%, ${OUT}17, transparent 62%), var(--surface)`
            : 'var(--surface)',
          textAlign: 'center', overflow: 'hidden',
        }}
      >
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 10px',
          borderRadius: 20, background: 'var(--surface2)', border: '1px solid var(--border)',
          fontSize: 8.5, fontWeight: 900, letterSpacing: 1, textTransform: 'uppercase',
          color: 'var(--text-dim)',
        }}>
          <Eye size={10} /> Spectating
        </span>

        <p style={{
          fontFamily: "'Bangers', system-ui, sans-serif", fontSize: 54, lineHeight: 1,
          letterSpacing: 2, color: 'var(--text)', margin: '8px 0 0',
        }}>
          {status.standing}
        </p>
        <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', margin: '2px 0 0' }}>
          {live ? 'still standing' : 'survived'}
          <span style={{ color: 'var(--text-dim)', fontWeight: 600 }}> of {status.entrants}</span>
        </p>

        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 12 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 13px',
            borderRadius: 20, background: 'var(--surface2)', border: '1px solid var(--border)',
          }}>
            <Clock size={12} color="var(--text-dim)" />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)' }}>
              {live ? `Closes in ${formatGap(gapMs)}` : `Next round in ${formatGap(gapMs)}`}
            </span>
          </span>
        </div>

        <div style={{ marginTop: 10, paddingTop: 9, borderTop: '1px solid var(--border)' }}>
          <SpectatorTicker lines={tickerLines} />
        </div>
      </div>

      {/* Knocked out rather than never entered: say so once, and say that
          the rest of the app is theirs again — that is the question they
          actually have when they land here. */}
      {status.me_entered && status.me_eliminated && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10,
          padding: '11px 14px', borderRadius: 14,
          background: 'rgba(255,77,109,0.10)', border: '1px solid rgba(255,77,109,0.3)',
        }}>
          <Skull size={15} color={OUT} style={{ flexShrink: 0 }} />
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, flex: 1 }}>
            You were taken out{status.me_eliminated_by_name ? ` by ${status.me_eliminated_by_name}` : ''}.
            <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
              {' '}Regenerate and get on with your week — you're free of the round.
            </span>
          </p>
        </div>
      )}

      {/* ── Who you follow, and how they're holding up ───────────────── */}
      <p style={{
        display: 'flex', alignItems: 'center', gap: 5, margin: '14px 0 8px',
        fontSize: 9, fontWeight: 900, letterSpacing: 1.3, textTransform: 'uppercase',
        color: 'var(--text-dim)',
      }}>
        <Ticket size={11} /> People you follow in the round
      </p>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
          <span style={{
            width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
            borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
          }} />
        </div>
      ) : rows.length === 0 ? (
        <div className="neu-card" style={{ padding: '30px 20px', textAlign: 'center' }}>
          <UserPlus size={22} color="var(--text-dim)" style={{ marginBottom: 8 }} />
          <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', margin: '0 0 4px' }}>
            Nobody you follow is in this one
          </p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
            Follow a few fighters and you'll see them here next weekend — alive,
            or not.
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {rows.map(r => (
            <FollowRow key={r.user_id} entry={r} onCheer={setPicked} />
          ))}
        </div>
      )}

      {picked && (
        <CheerModal
          target={picked}
          busy={sending}
          onSend={cheer}
          onClose={() => { if (!sending) setPicked(null) }}
        />
      )}

      <Toast toast={toast} />
    </div>
  )
}
