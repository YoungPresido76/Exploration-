// src/features/pvp/CorruptionVeil.tsx
//
// The lingering half of Rust Curse. The attack animation is a moment;
// this is the state. For two minutes after a curse lands, the corrupted
// player's screen edges rust over wherever they are in the app.
//
// Mount once, next to <PvpEffectOverlay /> in AppLayout.
//
// Three things worth knowing about the design:
//
//  1. It is driven off the effect row's own `corrupt_started_at`, never a
//     local timer. A debuff you can dismiss by force-quitting the app is
//     not a debuff, and a setTimeout is exactly that.
//
//  2. The veil (2 min) is much shorter than the curse (90 min) on
//     purpose. The veil is the alert; the `corrupted` badge on the PvP
//     panel carries the rest. A brown rim for an hour and a half would
//     stop being information and start being punishment.
//
//  3. Edge-only. The centre is never painted, so this can sit over chat,
//     the feed, or a game without making any of them unusable.
import { useEffect, useMemo, useState } from 'react'
import { useMyPvpStatus } from './useMyPvpStatus'
import './pvp-effects.css'

/** How long the screen stays rusted after a curse lands. */
const VEIL_MS = 120_000
/** Matches the .pvp-veil-out animation, so the fade isn't cut short. */
const FADE_MS = 2_600

export default function CorruptionVeil({ enabled = true }: { enabled?: boolean }) {
  const { corrupted, corruptStartedAt } = useMyPvpStatus()

  // Recomputed rather than stored, so a second curse landing (which moves
  // corrupt_started_at forward) restarts the veil instead of being
  // swallowed by a timer that's already running.
  const endsAt = useMemo(() => {
    if (!corrupted || !corruptStartedAt) return null
    return new Date(corruptStartedAt).getTime() + VEIL_MS
  }, [corrupted, corruptStartedAt])

  const [phase, setPhase] = useState<'off' | 'on' | 'fading'>('off')

  useEffect(() => {
    if (!enabled || endsAt == null) { setPhase('off'); return }

    const msLeft = endsAt - Date.now()
    if (msLeft <= 0) { setPhase('off'); return }

    // Landing mid-window (an app reopened 90 seconds after the hit) should
    // pick up where the clock actually is, including starting straight
    // into the fade rather than replaying the full two minutes.
    setPhase(msLeft <= FADE_MS ? 'fading' : 'on')

    const timers: number[] = []
    if (msLeft > FADE_MS) {
      timers.push(window.setTimeout(() => setPhase('fading'), msLeft - FADE_MS))
    }
    timers.push(window.setTimeout(() => setPhase('off'), msLeft))

    return () => { for (const t of timers) window.clearTimeout(t) }
  }, [enabled, endsAt])

  // The caption only rides along with a veil that started recently.
  // Reopening the app 80 seconds in should show the rust, not announce it
  // as news.
  const fresh = endsAt != null && endsAt - Date.now() > VEIL_MS - 8_000

  if (phase === 'off') return null

  return (
    <>
      <div
        className={`pvp-corrupt-veil${phase === 'fading' ? ' pvp-veil-out' : ''}`}
        aria-hidden="true"
      />
      {fresh && phase === 'on' && (
        <div className="pvp-corrupt-pill" role="status">
          <i />
          CORRUPTED — your attacks land weaker
        </div>
      )}
    </>
  )
}
