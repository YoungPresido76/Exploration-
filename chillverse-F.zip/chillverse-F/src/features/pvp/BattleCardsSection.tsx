// src/features/pvp/BattleCardsSection.tsx
//
// The Mall's "Battle Cards" section. Cards are ordinary mall_items with
// category = 'pvp_card', so purchasing reuses purchase_mall_item — the
// same RPC and wallet ledger as every other item.
//
// Buying a card you already own is intentional, not a mistake: the
// second copy is what upgrades consume. The UI says so explicitly,
// because a shop that looks like it is selling a duplicate reads as
// broken otherwise.
//
// Card grid + detail sheet deliberately mirror the Mall's Consumables
// section (RectCard grid, ItemModal-style bottom sheet) rather than the
// old bespoke notched-card design, per product direction: Battle Cards
// should look and behave like every other Mall shelf, not like its own
// mini-app.
//
// Battle Cards are also NOT wishlistable — on purpose. A wishlist is for
// "I want this one day"; a Battle Card is something you buy for yourself
// to use right now, not something to pine after. No heart, no wishlist
// count, anywhere in this file.
import { useEffect, useMemo, useState } from 'react'
import { ShoppingBag, Swords, X } from 'lucide-react'
import { ripple } from '../../shared/lib/ripple'
import { useRealViewportHeight, useSheetDrag } from '../../shared/hooks/useBottomSheet'
import { supabase } from '../../shared/lib/supabase'
import { usePvpCards } from './usePvpCards'
import { useWallet } from '../economy/useWallet'
import { pvpErrorMessage, type PvpCard, type PvpEffectType } from './pvp'

const RARITY_COLOR: Record<string, string> = {
  Common: '#888899', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
}
const RARITY_ORDER = ['Mythic', 'Epic', 'Rare', 'Common'] as const

/** Power tag derived from effect_type, never stored: a card's role is
 *  already implied by what it does, so a hand-typed tag would drift. */
const POWER_TAG: Record<PvpEffectType, { label: string; color: string }> = {
  damage:       { label: 'Offensive',  color: '#ff4d6d' },
  shield_break: { label: 'Offensive',  color: '#ff4d6d' },
  poison:       { label: 'Control',    color: '#8ede4b' },
  petrify:      { label: 'Control',    color: '#5fd0ff' },
  corrupt:      { label: 'Control',    color: '#e28c31' },
  shield:       { label: 'Protective', color: '#f5c542' },
  revive:       { label: 'Protective', color: '#f5c542' },
  heal:         { label: 'Protective', color: '#3ecf8e' },
  lifesteal:    { label: 'Sustain',    color: '#ff3355' },
  mark:         { label: 'Cursed',     color: '#ff9ec7' },
  burn:         { label: 'Offensive',  color: '#ff5a1f' },
  curse:        { label: 'Cursed',     color: '#ff4d4d' },
  halo:         { label: 'Protective', color: '#ffd76e' },
  obsidian:     { label: 'Protective', color: '#c9c9c9' },
}

function cooldownLabel(mins: number): string {
  if (mins <= 0) return '—'
  return mins >= 60 ? `${mins / 60}h` : `${mins}m`
}

/** Plain-language summary built from the card's own stats. */
function effectLine(card: PvpCard): string {
  const mag = Math.round(card.effect_magnitude)

  const lines: Record<PvpEffectType, string> = {
    damage:       'A clean hit with nothing attached — it simply takes a large piece of someone.',
    poison:       `Poisons the target: ${mag} extra damage and their health stops recovering for ${card.effect_minutes} minutes.`,
    corrupt:      `Corrodes them for ${Math.round(card.effect_minutes / 60)}h — every attack THEY make lands ${mag}% weaker.`,
    petrify:      `Freezes them out of attacking anyone for ${card.effect_minutes} minutes.`,
    shield:       `Absorbs the next ${mag} attack${mag === 1 ? '' : 's'} on you completely.`,
    shield_break: 'Light damage, but it shatters any shield the target is holding outright.',
    mark:         `Brands them for ${Math.round(card.effect_minutes / 60)}h — everyone else who attacks them hands you ${mag}% of their vouchers.`,
    revive:       `Never played, only held. When you fall it brings you back at ${mag} health, using up one copy.`,
    lifesteal:    `Every point of damage returns ${mag}% of itself to your own health.`,
    heal:         `Played on yourself: ${mag} health back, once every ${Math.round(card.cooldown_minutes / 60)} hours.`,
    burn:         `Heavy damage, and the burn stops their health recovering for ${card.effect_minutes} minutes.`,
    curse:        `For ${Math.round(card.effect_minutes / 60)}h, every attack they make costs them ${mag}% of their health.`,
    halo:         `Bonus health stacked on top of your bar for ${Math.round(card.effect_minutes / 60)}h.`,
    obsidian:     `A ${mag} HP plate over your health that has to be broken through.`,
  }
  return lines[card.effect_type] ?? card.description
}

// Same fixed sheet height the rest of the Mall's item sheets use (see
// BUY_SHEET_HEIGHT_VH in Mall.tsx) — kept as a local copy since that one
// isn't exported, and duplicating one number is cheaper than threading
// it across files.
const BUY_SHEET_HEIGHT_VH = 92
// Same "whole image, shrunk to fit" frame height Mall.tsx uses for
// avatar/other items — Battle Cards get the identical treatment.
const MOCK_TOTAL_H = 194

interface BattleCardsSectionProps {
  userId: string | null
  onPurchased?: () => void
}

export default function BattleCardsSection({ userId, onPurchased }: BattleCardsSectionProps) {
  const { cards, loading, refetch } = usePvpCards()
  const { wallet } = useWallet()
  // Null wallet means no row yet, which is 0 Diamonds — not "unknown".
  const diamonds = wallet?.gem_balance ?? 0
  const [buying, setBuying] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [detail, setDetail] = useState<PvpCard | null>(null)

  // Permanent cards ONLY. Battle Consumables left this page entirely --
  // they are sold on the Mall's Consumables shelf beside the boosters and
  // potions, which is where a single-use item belongs. They still show in
  // the Battle Deck and still ride the quick slots; this is a shop
  // decision, not a combat one.
  //
  // Sorted rarity-first (Mythic → Common) but rendered as one flat grid,
  // same as the Consumables shelf — no section headers.
  const shopCards = useMemo(() => {
    const rank = new Map(RARITY_ORDER.map((r, i) => [r, i]))
    return cards
      .filter(c => !c.is_consumable)
      .slice()
      .sort((a, b) => (rank.get(a.rarity) ?? 99) - (rank.get(b.rarity) ?? 99))
  }, [cards])

  async function buy(card: PvpCard) {
    if (!userId || buying) return
    setBuying(card.item_id)
    setError(null)
    try {
      const { error: rpcError } = await supabase.rpc('purchase_mall_item', {
        p_user_id: userId,
        p_item_id: card.item_id,
      })
      if (rpcError) throw rpcError
      refetch()
      onPurchased?.()
      setDetail(null)
    } catch (e) {
      setError(pvpErrorMessage(e))
    } finally {
      setBuying(null)
    }
  }

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: '46px 0' }}>
        <span style={{
          width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
          borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
        }} />
      </div>
    )
  }

  return (
    <div>
      {error && (
        <p style={{
          fontSize: 12.5, color: '#ff8095', background: 'rgba(255,77,109,0.10)',
          border: '1px solid rgba(255,77,109,0.3)', borderRadius: 12, padding: '10px 13px',
          marginBottom: 16,
        }}>
          {error}
        </p>
      )}

      {shopCards.length === 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
          <Swords size={28} style={{ opacity: 0.35 }} />
          <div style={{ fontSize: 13 }}>No battle cards available yet.</div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
          {shopCards.map(card => (
            <BattleCardTile key={card.item_id} card={card} onSelect={setDetail} />
          ))}
        </div>
      )}

      {detail && (
        <BattleCardModal
          card={detail}
          diamonds={diamonds}
          busy={buying === detail.item_id}
          onBuy={() => buy(detail)}
          onClose={() => setDetail(null)}
        />
      )}
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   GRID TILE — deliberately styled to match Mall.tsx's RectCard
   (image, name, rarity badge, price row). No stats, no heart.
══════════════════════════════════════════════════════ */
function BattleCardTile({ card, onSelect }: { card: PvpCard; onSelect: (card: PvpCard) => void }) {
  const color = RARITY_COLOR[card.rarity] ?? '#8b95a5'
  const isMythic = card.rarity === 'Mythic'
  const price = card.price_gems ?? card.price_orbs ?? 0

  return (
    <div
      onClick={(e) => { ripple(e); onSelect(card) }}
      className="ripple-wrap"
      style={{
        background: 'var(--surface)', border: isMythic ? '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' : '1px solid rgba(255,255,255,0.05)',
        borderRadius: 18, padding: 12, cursor: 'pointer', position: 'relative',
        boxShadow: isMythic ? '0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent),4px 4px 10px var(--neu-dark)' : '4px 4px 10px var(--neu-dark),-2px -2px 8px var(--neu-light)',
      }}
    >
      <div style={{ width: '100%', aspectRatio: '3 / 4', borderRadius: 14, marginBottom: 10, overflow: 'hidden', background: 'var(--surface2)', position: 'relative' }}>
        {card.image_url ? (
          <img src={card.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color }}>
            <Swords size={26} />
          </div>
        )}
        {/* Owned copy count — inventory fact, not a wishlist affordance. */}
        {card.owned && (
          <div style={{
            position: 'absolute', top: 6, right: 6, background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(4px)',
            borderRadius: 8, padding: '2px 7px', fontSize: 9.5, fontWeight: 800, color: '#fff',
          }}>
            ×{card.copies}
          </div>
        )}
      </div>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', marginBottom: 5, lineHeight: 1.3 }}>{card.name}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 9.5, fontWeight: 700, padding: '2px 7px', borderRadius: 8, background: `${color}22`, color, whiteSpace: 'nowrap' }}>
          {card.rarity}
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11.5, fontWeight: 700, color: 'var(--text)' }}>
          💎 {price.toLocaleString()}
        </span>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   DETAIL SHEET — deliberately styled to match Mall.tsx's ItemModal
   (drag handle, slide-up bottom sheet, contained image frame, price
   panel, single buy button). Close button only in the header — no
   preview toggle, no wishlist heart.
══════════════════════════════════════════════════════ */
function BattleCardModal({ card, diamonds, busy, onBuy, onClose }: {
  card: PvpCard
  diamonds: number
  busy: boolean
  onBuy: () => void
  onClose: () => void
}) {
  const realVh = useRealViewportHeight()
  const sheetHeightPx = Math.round(realVh * (BUY_SHEET_HEIGHT_VH / 100))
  const { dragY, dragging, dragHandleProps, sheetProps } = useSheetDrag(onClose)

  // Same "lock the page behind the sheet, hide the portaled dock" pattern
  // every other Mall sheet uses (see ItemModal in Mall.tsx).
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const color = RARITY_COLOR[card.rarity] ?? '#8b95a5'
  const tag = POWER_TAG[card.effect_type]
  const price = card.price_gems ?? card.price_orbs ?? 0
  const canAfford = card.price_gems == null || diamonds >= card.price_gems
  const shortBy = card.price_gems != null ? Math.max(0, card.price_gems - diamonds) : 0

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
      style={{
        position: 'fixed', inset: 0, zIndex: 800, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      {/* sheetProps: drag-to-dismiss from anywhere inside the sheet, not just
          the handle — engages only when the content under the finger is
          already scrolled to the top. See useBottomSheet.ts. */}
      <div {...sheetProps} style={{
        background: 'var(--surface)', borderRadius: '20px 20px 0 0', padding: '0 20px 24px', width: '100%', maxWidth: 460,
        border: '1px solid var(--border)', borderBottom: 'none', boxShadow: '0 -12px 40px -12px var(--sh)',
        position: 'relative', height: sheetHeightPx, maxHeight: sheetHeightPx, overflowY: 'auto', overscrollBehavior: 'contain',
        display: 'flex', flexDirection: 'column',
        transform: `translateY(${dragY}px)`,
        transition: dragging ? 'none' : 'transform 0.28s cubic-bezier(0.16,1,0.3,1)',
        animation: dragging ? undefined : 'slideUp 0.28s cubic-bezier(0.16,1,0.3,1) both',
      }}>
        <div
          {...dragHandleProps}
          style={{ ...dragHandleProps.style, padding: '10px 0 8px', margin: '0 auto', flexShrink: 0, display: 'flex', justifyContent: 'center' }}
        >
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.22)' }} />
        </div>

        {/* Header: close only. No preview toggle, no wishlist heart —
            Battle Cards are bought for yourself, not wishlisted. */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', margin: '14px 0', flexShrink: 0 }}>
          <button onClick={onClose} style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(255,255,255,0.06)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)' }}>
            <X size={14} />
          </button>
        </div>

        {/* Whole-image frame — same treatment Mall.tsx gives avatar/other
            items: shrunk to fit (objectFit: contain), nothing cropped. */}
        <div style={{
          width: '100%', height: MOCK_TOTAL_H,
          borderRadius: 16, marginBottom: 16, overflow: 'hidden', background: 'var(--surface2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 14,
        }}>
          {card.image_url ? (
            <img src={card.image_url} alt={card.name} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
          ) : (
            <Swords size={40} color={color} />
          )}
        </div>

        {tag && (
          <div style={{ fontSize: 10.5, color: tag.color, textAlign: 'center', textTransform: 'uppercase', letterSpacing: 0.6, fontWeight: 700, marginBottom: 6 }}>
            {tag.label}
          </div>
        )}
        <div style={{ fontSize: 18, fontWeight: 800, textAlign: 'center', marginBottom: 6, color: 'var(--text)' }}>{card.name}</div>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 14 }}>
          <span style={{ fontSize: 9.5, fontWeight: 700, padding: '2px 7px', borderRadius: 8, background: `${color}22`, color }}>
            {card.rarity}
          </span>
        </div>
        <div style={{ fontSize: 12.5, color: 'var(--text-dim)', textAlign: 'center', lineHeight: 1.6, marginBottom: 18 }}>
          {effectLine(card)}
        </div>

        {/* Card-specific facts, in the same bordered-row pattern the rest
            of the Mall's item sheets use for supplemental info. */}
        <div style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderTop: '1px solid var(--border)' }}>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Damage</span>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>
              {card.base_damage > 0 ? Math.round(card.current_damage) : '—'}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderTop: '1px solid var(--border)' }}>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Recharge</span>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{cooldownLabel(card.cooldown_minutes)}</span>
          </div>
          {card.owned && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Owned</span>
              <span style={{ fontSize: 13, fontWeight: 700, color }}>
                Lv {card.card_level} · {card.copies} cop{card.copies === 1 ? 'y' : 'ies'}
              </span>
            </div>
          )}
        </div>

        <div style={{ marginTop: 'auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'var(--surface2)', borderRadius: 12, padding: 12, marginBottom: 14, fontSize: 18, fontWeight: 800, color: 'var(--text)' }}>
            💎 {price.toLocaleString()} {card.price_gems == null && card.price_orbs != null ? 'Orbs' : 'Diamonds'}
          </div>
          {!canAfford && (
            <div style={{ fontSize: 11, color: '#ff6b6b', textAlign: 'center', marginBottom: 10 }}>
              You need {shortBy.toLocaleString()} more 💎
            </div>
          )}
          <button
            disabled={busy || !canAfford}
            onClick={(e) => { ripple(e); onBuy() }}
            className="ripple-wrap"
            style={{
              width: '100%', padding: 13, borderRadius: 14, border: 'none',
              cursor: busy || !canAfford ? 'not-allowed' : 'pointer',
              background: busy || !canAfford ? 'var(--surface3)' : 'linear-gradient(135deg,var(--accent),var(--accent2))',
              color: busy || !canAfford ? 'var(--text-muted)' : '#fff',
              fontSize: 14, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              boxShadow: busy || !canAfford ? 'none' : '0 4px 16px color-mix(in srgb, var(--accent) 35%, transparent)',
              transition: 'background-color var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)',
            }}
          >
            <ShoppingBag size={14} />
            {busy ? 'Buying…' : !canAfford ? 'Not enough Diamonds' : card.owned ? 'Buy another copy' : 'Buy card'}
          </button>
        </div>
      </div>
    </div>
  )
}
