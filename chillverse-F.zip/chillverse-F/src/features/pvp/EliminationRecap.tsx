// src/features/pvp/EliminationRecap.tsx
//
// What the Elimination tab shows once a round is over.
//
// Until now there was no such screen: between rounds the live board simply
// kept rendering with its final numbers frozen in place, so the weekend the
// whole roster died read as "0 survived of 19" underneath a SPECTATING pill
// and a list of strikethrough names with cheer buttons that could no longer
// do anything. Accurate, and completely dead.
//
// A closed round has exactly two things to say: when the next one starts,
// and what happened in this one. So the screen is a countdown and a recap,
// and NOTHING on it is pressable — no attack buttons, no cheers, no roll
// call. Registering happens on the dashboard card, which is deliberately
// the only entry point for it; this screen only points at it.
//
// The three recap slots come straight from pvp_elimination_recap(), which
// scores them server-side. One player can hold more than one slot — on the
// 28 Aug round the same fighter was last to fall AND top damage — and that
// repetition is left alone on purpose. It reads as dominance, which is the
// truth of what happened, and swapping in a runner-up to fill the tile
// would be inventing a result nobody earned.
import { useEffect, useState } from 'react'
import { Clock, Crown, Skull, Swords, Ticket, Trophy } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import { formatDuration, formatSeconds, localStamp, localZoneAbbr } from '../../shared/lib/localTime'
import { getEliminationRecap, type EliminationRecap as Recap, type EliminationStatus } from './pvp'

const OUT = '#ff4d6d'
const ALIVE = '#3ecf8e'
const GOLD = '#f5c542'

/* ── Pieces ─────────────────────────────────────────────────────────── */

function Tag({ children, color }: { children: React.ReactNode; color: string }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 10px',
      borderRadius: 20, background: 'var(--surface2)', border: `1px solid ${color}4d`,
      fontSize: 8.5, fontWeight: 900, letterSpacing: 1, textTransform: 'uppercase',
      color,
    }}>
      {children}
    </span>
  )
}

/** One of the two small tiles under the hero. */
function MiniSlot({
  eyebrow, icon: Icon, color, name, avatar, userId, detail,
}: {
  eyebrow: string
  icon: LucideIcon
  color: string
  name: string
  avatar: string | null
  userId: string | null
  detail: string
}) {
  return (
    <div className="neu-card" style={{
      flex: 1, minWidth: 0, padding: '13px 12px', borderRadius: 15,
      border: '1px solid var(--border)',
    }}>
      <Tag color={color}><Icon size={10} /> {eyebrow}</Tag>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginTop: 10 }}>
        <Avatar src={avatar} name={name} ownerId={userId ?? undefined} size={32} />
        <div style={{ minWidth: 0 }}>
          <p style={{
            margin: 0, fontSize: 12.5, fontWeight: 800, color: 'var(--text)',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>
            {name}
          </p>
          <p style={{ margin: '1px 0 0', fontSize: 10.5, color: 'var(--text-muted)' }}>
            {detail}
          </p>
        </div>
      </div>
    </div>
  )
}

function HeroStat({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div style={{
      flex: 1, padding: 9, borderRadius: 11, textAlign: 'center',
      background: 'var(--surface2)',
    }}>
      <p style={{
        margin: 0, fontSize: 17, fontWeight: 900, color,
        fontVariantNumeric: 'tabular-nums',
      }}>
        {value}
      </p>
      <p style={{
        margin: '1px 0 0', fontSize: 9.5, fontWeight: 800,
        letterSpacing: 0.6, color: 'var(--text-dim)',
      }}>
        {label}
      </p>
    </div>
  )
}

/* ── Screen ─────────────────────────────────────────────────────────── */

export default function EliminationRecap({ status }: { status: EliminationStatus }) {
  const [recap, setRecap] = useState<Recap | null>(null)
  const [loaded, setLoaded] = useState(false)
  const [, setTick] = useState(0)

  useEffect(() => {
    let active = true
    getEliminationRecap()
      .then(r => { if (active) setRecap(r) })
      .catch(() => { if (active) setRecap(null) })
      .finally(() => { if (active) setLoaded(true) })
    return () => { active = false }
  }, [])

  // The countdown is the point of this screen, so it can't go stale while
  // somebody sits on the tab.
  useEffect(() => {
    const id = window.setInterval(() => setTick(t => t + 1), 30_000)
    return () => window.clearInterval(id)
  }, [])

  const gapMs = new Date(status.starts_at).getTime() - Date.now()
  const played = !!recap && recap.entrants > 0
  const wiped = played && recap!.survivors === 0

  const heroName = recap?.hero_display_name || recap?.hero_username || ''
  const firstName = recap?.first_display_name || recap?.first_username || ''
  const dmgName = recap?.dmg_display_name || recap?.dmg_username || ''

  return (
    <div>
      {/* ── The verdict ──────────────────────────────────────────────── */}
      <div
        className="neu-card"
        style={{
          position: 'relative', padding: '20px 18px 15px', borderRadius: 18,
          marginBottom: 10, textAlign: 'center', overflow: 'hidden',
          border: '1px solid var(--border)',
          background: played
            ? `radial-gradient(120% 90% at 50% -10%, ${GOLD}1a, transparent 62%), var(--surface)`
            : 'var(--surface)',
        }}
      >
        <Tag color={played ? GOLD : 'var(--text-dim)'}>
          {played ? 'Round over' : 'Elimination weekend'}
        </Tag>

        {!loaded ? (
          <p style={{
            fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', margin: '16px 0 4px',
          }}>
            Counting the bodies…
          </p>
        ) : played ? (
          <>
            <p style={{
              fontFamily: "'Bangers', system-ui, sans-serif",
              fontSize: wiped ? 38 : 54, lineHeight: 1.05, letterSpacing: 2,
              color: wiped ? OUT : 'var(--text)', margin: '10px 0 0',
            }}>
              {wiped ? 'NO SURVIVORS' : recap!.survivors}
            </p>
            <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', margin: '4px 0 0' }}>
              {wiped
                ? `All ${recap!.entrants} entrants fell`
                : <>survived<span style={{ color: 'var(--text-dim)', fontWeight: 600 }}> of {recap!.entrants}</span></>}
              <span style={{ color: 'var(--text-dim)', fontWeight: 600 }}>
                {' · '}
                {recap!.vouchers_paid > 0
                  ? `${recap!.vouchers_paid} Vouchers paid`
                  : 'nothing paid out'}
              </span>
            </p>
          </>
        ) : (
          <p style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text)', margin: '14px 0 0' }}>
            Nobody has played a round yet
          </p>
        )}

        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 13 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 13px',
            borderRadius: 20, background: 'var(--surface2)', border: '1px solid var(--border)',
          }}>
            <Clock size={12} color="var(--text-dim)" />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)' }}>
              Next round in {formatDuration(gapMs)}
            </span>
          </span>
        </div>

        {/* The one absolute time on this screen, in the reader's own zone —
            a countdown says how long, this says when to be there. */}
        <div style={{ marginTop: 11, paddingTop: 10, borderTop: '1px solid var(--border)' }}>
          <p style={{
            margin: 0, fontSize: 11.5, fontWeight: 800, color: 'var(--text-dim)',
          }}>
            Opens {localStamp(status.starts_at)} {localZoneAbbr(status.starts_at)}
          </p>
        </div>
      </div>

      {/* ── Where signing up happens ─────────────────────────────────── */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14,
        padding: '12px 14px', borderRadius: 14,
        background: status.me_registered ? `${ALIVE}1a` : 'var(--surface2)',
        border: `1px solid ${status.me_registered ? `${ALIVE}4d` : 'var(--border)'}`,
      }}>
        <Ticket size={15} color={status.me_registered ? ALIVE : 'var(--text-dim)'} style={{ flexShrink: 0 }} />
        <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', margin: 0, flex: 1 }}>
          {status.me_registered ? (
            <>
              You're in for the next one.
              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
                {' '}{status.registered_count} registered so far.
              </span>
            </>
          ) : status.registration_open ? (
            <>
              Sign-ups are open.
              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
                {' '}Register from the card on your dashboard — closes in{' '}
                {formatDuration(new Date(status.registration_closes_at).getTime() - Date.now())}.
              </span>
            </>
          ) : (
            <>
              Sign-ups open in {formatDuration(new Date(status.registration_opens_at).getTime() - Date.now())}.
              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
                {' '}One tap from your dashboard when they do.
              </span>
            </>
          )}
        </p>
      </div>

      {/* ── Recap ────────────────────────────────────────────────────── */}
      {played && (
        <>
          <p style={{
            display: 'flex', alignItems: 'center', gap: 5, margin: '0 0 8px',
            fontSize: 9, fontWeight: 900, letterSpacing: 1.3,
            textTransform: 'uppercase', color: 'var(--text-dim)',
          }}>
            <Trophy size={11} /> Round recap
          </p>

          {recap!.hero_user_id && (
            <div className="neu-card" style={{
              padding: '16px 15px', borderRadius: 18, marginBottom: 8,
              border: `1px solid ${GOLD}47`,
              background: `linear-gradient(150deg, ${GOLD}1a, var(--surface))`,
            }}>
              <Tag color={GOLD}>
                <Crown size={10} />
                {recap!.hero_survived ? 'Top survivor' : 'Last one standing'}
              </Tag>

              <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginTop: 11 }}>
                <Avatar
                  src={recap!.hero_avatar}
                  name={heroName}
                  ownerId={recap!.hero_user_id ?? undefined}
                  size={44}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{
                    margin: 0, fontSize: 15, fontWeight: 800, color: 'var(--text)',
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>
                    {heroName}
                  </p>
                  <p style={{ margin: '2px 0 0', fontSize: 11.5, fontWeight: 600, color: 'var(--text-muted)' }}>
                    {recap!.hero_survived
                      ? 'Made it to the bell'
                      : `Held out ${formatSeconds(recap!.hero_lasted_seconds ?? 0)}`}
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <HeroStat value={String(recap!.hero_kills ?? 0)} label="KILLS" color={OUT} />
                <HeroStat
                  value={(recap!.hero_damage ?? 0).toLocaleString()}
                  label="DAMAGE"
                  color="var(--accent)"
                />
              </div>
            </div>
          )}

          <div style={{ display: 'flex', gap: 8 }}>
            {recap!.first_user_id && (
              <MiniSlot
                eyebrow="First to fall"
                icon={Skull}
                color={OUT}
                name={firstName}
                avatar={recap!.first_avatar}
                userId={recap!.first_user_id}
                detail={`out in ${formatSeconds(recap!.first_lasted_seconds ?? 0)}`}
              />
            )}
            {recap!.dmg_user_id && (
              <MiniSlot
                eyebrow="Most damage"
                icon={Swords}
                color="var(--accent)"
                name={dmgName}
                avatar={recap!.dmg_avatar}
                userId={recap!.dmg_user_id}
                detail={`${(recap!.dmg_total ?? 0).toLocaleString()} dealt`}
              />
            )}
          </div>

          <p style={{
            fontSize: 10.5, color: 'var(--text-dim)', lineHeight: 1.6,
            margin: '14px 0 0', textAlign: 'center',
          }}>
            Round of {localStamp(recap!.starts_at)}, {recap!.entrants} entered.
          </p>
        </>
      )}
    </div>
  )
}
