// src/features/pvp/EliminationRegisterSheet.tsx
//
// The sign-up sheet for Elimination Weekend, drawn up from the dashboard
// card.
//
// Deliberately a sheet and not a page. There is exactly one action on it and
// the answer arrives instantly — no fee, no username, no approval queue — so
// a route with a back stack would be ceremony around a single tap. It follows
// ClubQuickSheet's shape so the handoff feels like the rest of the app.
//
// The banner is owner-set (app_config.elimination_banner_url) and may be
// absent, in which case the header falls back to a flat treatment rather than
// a placeholder image — the same call ClubQuickSheet makes for a club with no
// banner.
//
// One number is shown at the top and it is the roster count, not the standing
// count. Before the bell nobody has been eliminated, so "12 registered" is the
// only figure that means anything; the standing/fallen split belongs on the
// Arena board once the round is running.
import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Users, ShieldOff, Ticket, Clock, Check, Skull } from 'lucide-react'
import { localStamp, localWindowLabel } from '../../shared/lib/localTime'
import { registerForElimination, type EliminationStatus } from './pvp'
import { refreshElimination } from './useElimination'

const SHEET_HEIGHT_VH = 85
const WIDE_BREAKPOINT = 640
const DANGER = '#ff4d6d'
const ALIVE = '#3ecf8e'

function lagos(iso: string | null): string {
  if (!iso) return ''
  return new Date(iso).toLocaleString([], {
    weekday: 'short', hour: 'numeric', minute: '2-digit',
  })
}

function Rule({ Icon, title, body, tint }: {
  Icon: typeof ShieldOff; title: string; body: string; tint: string
}) {
  return (
    <div style={{ display: 'flex', gap: 11, alignItems: 'flex-start' }}>
      <span style={{
        width: 30, height: 30, borderRadius: 10, flexShrink: 0,
        display: 'grid', placeItems: 'center',
        background: `${tint}1c`, border: `1px solid ${tint}3d`,
      }}>
        <Icon size={14} color={tint} />
      </span>
      <div style={{ minWidth: 0 }}>
        <p style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text)', margin: 0 }}>{title}</p>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '2px 0 0', lineHeight: 1.5 }}>
          {body}
        </p>
      </div>
    </div>
  )
}

export default function EliminationRegisterSheet({ status, onClose, onRegistered }: {
  status: EliminationStatus
  onClose: () => void
  /** Fires after a successful sign-up so the caller can re-read its own copy. */
  onRegistered?: () => void
}) {
  const [visible, setVisible] = useState(false)
  const [isWide, setIsWide] = useState(
    () => typeof window !== 'undefined' && window.innerWidth >= WIDE_BREAKPOINT,
  )
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [count, setCount] = useState(status.registered_count)
  const [registered, setRegistered] = useState(status.me_registered)

  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [])

  useEffect(() => { requestAnimationFrame(() => setVisible(true)) }, [])

  useEffect(() => {
    function onResize() { setIsWide(window.innerWidth >= WIDE_BREAKPOINT) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  async function register() {
    if (busy || registered) return
    setBusy(true); setError(null)
    try {
      const res = await registerForElimination()
      setRegistered(true)
      setCount(res.registered_count)
      refreshElimination()
      onRegistered?.()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not register.')
    } finally {
      setBusy(false)
    }
  }

  const closed = !status.registration_open

  return createPortal(
    <>
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0, zIndex: 20090,
          background: 'rgba(0,0,0,0.6)',
          opacity: visible ? 1 : 0, transition: 'opacity 0.22s ease',
        }}
      />

      <div style={{
        position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 20100,
        height: `${SHEET_HEIGHT_VH}vh`,
        maxWidth: isWide ? 520 : undefined,
        margin: isWide ? '0 auto' : undefined,
        borderRadius: '22px 22px 0 0', overflow: 'hidden',
        background: 'var(--surface)', border: '1px solid var(--border)',
        borderBottom: 'none',
        transform: visible ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform 0.28s cubic-bezier(0.32,0.72,0,1)',
        display: 'flex', flexDirection: 'column',
      }}>

        {/* ── Banner ───────────────────────────────────────────────── */}
        <div style={{
          position: 'relative', flexShrink: 0, height: 150,
          background: status.banner_url
            ? `center/cover no-repeat url(${status.banner_url})`
            : `linear-gradient(140deg, ${DANGER}2e, #1a0e14)`,
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            background: 'linear-gradient(to top, var(--surface) 2%, rgba(0,0,0,0.35) 55%, rgba(0,0,0,0.1))',
          }} />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            style={{
              position: 'absolute', top: 12, right: 12, zIndex: 2,
              width: 32, height: 32, borderRadius: '50%', border: 'none',
              cursor: 'pointer', display: 'grid', placeItems: 'center',
              background: 'rgba(0,0,0,0.5)', color: '#fff',
            }}
          >
            <X size={16} />
          </button>

          <div style={{ position: 'absolute', left: 18, right: 18, bottom: 12, zIndex: 1 }}>
            {/* The Lagos window, rendered on the reader's clock. The
                weekday is part of what changes: for a player far enough
                west this round ends on a Sunday afternoon, and printing
                "Monday 00:00" told them to survive past a deadline that
                does not exist where they live. */}
            <p style={{
              fontSize: 9.5, fontWeight: 800, letterSpacing: 1.4,
              textTransform: 'uppercase', color: DANGER, margin: '0 0 3px',
            }}>
              {localWindowLabel(status.starts_at, status.ends_at)}
            </p>
            <h2 style={{
              fontSize: 25, fontWeight: 900, color: '#fff', margin: 0,
              lineHeight: 1.05, letterSpacing: -0.4,
              textShadow: '0 2px 12px rgba(0,0,0,0.6)',
            }}>
              Elimination Weekend
            </h2>
          </div>
        </div>

        {/* ── Body ─────────────────────────────────────────────────── */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 18px 26px' }}>

          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            padding: '12px 14px', borderRadius: 14, marginBottom: 16,
            background: 'var(--surface2)', border: '1px solid var(--border)',
          }}>
            <Users size={15} color="var(--text-dim)" />
            <span style={{ fontSize: 20, fontWeight: 900, color: 'var(--text)' }}>
              {count}
            </span>
            <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)' }}>
              {count === 1 ? 'registered' : 'registered'}
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 13, marginBottom: 18 }}>
            <Rule
              Icon={ShieldOff}
              tint={DANGER}
              title="Nothing heals you"
              body="From the moment it starts until it closes: no passive regen, no Regenerate, no Second Wind. Shield and Revive still work."
            />
            <Rule
              Icon={Skull}
              tint={DANGER}
              title="One death and you're out"
              body="Anyone can take you down, registered or not — signing up buys you a shot at the payout, not protection. Games and Exploration stay open to you either way."
            />
            <Rule
              Icon={Ticket}
              tint={ALIVE}
              title={`${status.survivor_reward} Vouchers to survive`}
              body={`Paid to everyone still standing when it closes, ${localStamp(status.ends_at)} your time. Flat — the same whether you hunted or hid.`}
            />
          </div>

          {/* ── The action ─────────────────────────────────────────── */}
          {registered ? (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '14px 16px', borderRadius: 15,
              background: `${ALIVE}14`, border: `1px solid ${ALIVE}3d`,
            }}>
              <Check size={17} color={ALIVE} />
              <div style={{ minWidth: 0 }}>
                <p style={{ fontSize: 13, fontWeight: 800, color: ALIVE, margin: 0 }}>
                  You're on the roster
                </p>
                <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: '2px 0 0' }}>
                  We'll ping you when it starts.
                </p>
              </div>
            </div>
          ) : closed ? (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '14px 16px', borderRadius: 15,
              background: 'var(--surface2)', border: '1px solid var(--border)',
            }}>
              <Clock size={17} color="var(--text-dim)" />
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
                Registration is closed. It opens again {lagos(status.registration_opens_at)}.
              </p>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={register}
                disabled={busy}
                style={{
                  width: '100%', padding: 15, borderRadius: 16, border: 'none',
                  cursor: busy ? 'not-allowed' : 'pointer',
                  fontFamily: 'inherit', fontSize: 14.5, fontWeight: 800, color: '#fff',
                  background: `linear-gradient(135deg, ${DANGER}, #ff8a5c)`,
                  boxShadow: `0 6px 20px ${DANGER}45`,
                  opacity: busy ? 0.65 : 1,
                }}
              >
                {busy ? 'Registering…' : 'Register'}
              </button>
              <p style={{
                fontSize: 11, color: 'var(--text-dim)', textAlign: 'center',
                margin: '10px 0 0',
              }}>
                Closes {lagos(status.registration_closes_at)} — nothing to pay.
              </p>
            </>
          )}

          {error && (
            <p style={{ fontSize: 11.5, color: '#ff8095', textAlign: 'center', margin: '10px 0 0' }}>
              {error}
            </p>
          )}
        </div>
      </div>
    </>,
    document.body,
  )
}
