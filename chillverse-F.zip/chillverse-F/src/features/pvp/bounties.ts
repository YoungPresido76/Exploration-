// src/features/pvp/bounties.ts
//
// Admin-placed contracts. Everything here mirrors migrations 0158a-0158c.
//
// There is no "active" column and no cron sweeping expired rows: a bounty
// is live while it has no claim, no cancel, and is still inside its 72
// hours, and get_active_bounties() is the only thing that decides that. An
// unclaimed contract dies by simply falling out of that query.
import { supabase } from '../../shared/lib/supabase'
import { isPending } from '../admin/adminRequests'

export interface Bounty {
  id: string
  target_id: string
  username: string
  display_name: string | null
  avatar: string | null
  reward_gems: number
  /** Optional line the admin wrote on the poster. */
  note: string | null
  placed_at: string
  expires_at: string
  target_status: 'alive' | 'dead'
  target_hp: number
  target_max_hp: number
}

/** Live contracts, richest first. */
export async function getActiveBounties(): Promise<Bounty[]> {
  const { data, error } = await supabase.rpc('get_active_bounties')
  if (error) throw error
  return (data as Bounty[] | null) ?? []
}

// ── Admin ───────────────────────────────────────────────────────────────

/**
 * Place a contract. Admin only, server-enforced.
 *
 * The reward is capped at 10,000 Diamonds server-side. That ceiling is
 * deliberate: a bounty mints diamonds with no purchase behind them, and a
 * slipped zero can't be undone once the winner has spent them.
 */
export async function placeBounty(
  targetId: string, rewardGems: number, note?: string,
): Promise<{ pending: boolean }> {
  const { data, error } = await supabase.rpc('admin_place_bounty', {
    p_target_id: targetId,
    p_reward_gems: rewardGems,
    p_note: note?.trim() || null,
  })
  if (error) throw error
  // Only the platform owner places a contract outright; any other admin's
  // goes to the approval queue first (migration 0160b).
  return { pending: isPending(data) }
}

export async function cancelBounty(id: string): Promise<void> {
  const { error } = await supabase.rpc('admin_cancel_bounty', { p_id: id })
  if (error) throw error
}

/**
 * The RPCs raise `CV_ADMIN_VALIDATION: <reason>` / `CV_ADMIN_FORBIDDEN:
 * <reason>`, which arrive wrapped in Postgres noise. Pull the readable
 * half out rather than showing the raw string.
 */
export function bountyErrorMessage(err: unknown): string {
  const raw = (err as { message?: string } | null)?.message ?? ''
  const match = raw.match(/CV_ADMIN_(?:VALIDATION|FORBIDDEN):\s*(.+)/)
  if (match) return match[1].trim()
  return 'Could not do that. Try again.'
}
