// src/features/pvp/PvpDownModal.tsx
//
// The one screen a player sees when they try to do something while they're
// down in PvP. Shown by Games and Exploration.
//
// It carries the Regenerate action itself rather than sending the player to
// the Profile page to find it. That's deliberate: PvpProfilePanel's
// Regenerate button takes an `onRegenerate` prop that NEITHER call site was
// passing, so tapping it did nothing at all. Rather than route people to a
// dead end, the action lives here and shares useRegenerate() with the
// profile panel, which now calls it too.

import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { HeartPulse, ShoppingBag, X } from 'lucide-react'
import { useRegenerate } from './useRegenerate'

/** The copy every lock in the app shows. One string so they can't drift. */
export const PVP_DOWN_MESSAGE = 'You died in PvP, regenerate first'

interface PvpDownModalProps {
  userId: string | null
  /** What they were trying to do — "play games", "explore". */
  action?: string
  onClose: () => void
}

export default function PvpDownModal({ userId, action, onClose }: PvpDownModalProps) {
  const navigate = useNavigate()
  const { count, busy, error, run } = useRegenerate(userId)

  // Same body lock + dock hide the other sheets use (see body.cv-sheet-open
  // in index.css) — the dock is portaled to <body> and sits in its own
  // stacking context, so z-index alone can't outrank it.
  useEffect(() => {
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.body.classList.add('cv-sheet-open')
    return () => {
      document.body.style.overflow = original
      document.body.classList.remove('cv-sheet-open')
    }
  }, [])

  async function onRegenerate() {
    const ok = await run()
    if (ok) onClose()
  }

  return (
    <div
      className="sheet-or-modal sheet-or-modal-over-dock"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20000,
        display: 'grid', placeItems: 'center', padding: 22,
        background: 'rgba(0,0,0,0.62)', backdropFilter: 'blur(3px)',
        animation: 'cvPvpDownIn 0.2s ease',
      }}
    >
      {/* Scoped rather than reused: `fadeIn` / `modalUp` are declared inside
          Exploration.tsx's own <style> block, not globally, so relying on
          them here would silently do nothing from the Games page. */}
      <style>{`
        @keyframes cvPvpDownIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes cvPvpDownUp {
          from { opacity: 0; transform: translateY(24px) scale(0.96) }
          to   { opacity: 1; transform: translateY(0) scale(1) }
        }
      `}</style>

      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 340, padding: '24px 22px 22px',
          borderRadius: 22, background: 'var(--surface2)',
          border: '1px solid rgba(255,77,109,0.28)',
          boxShadow: '0 18px 50px rgba(0,0,0,0.5)',
          animation: 'cvPvpDownUp 0.28s cubic-bezier(0.22,1,0.36,1)',
          position: 'relative',
        }}
      >
        <button
          type="button" onClick={onClose}
          style={{
            position: 'absolute', top: 14, right: 14, background: 'none',
            border: 'none', cursor: 'pointer', color: 'var(--text-muted)',
          }}
        >
          <X size={17} />
        </button>

        <div style={{
          width: 46, height: 46, borderRadius: 15, display: 'grid', placeItems: 'center',
          background: 'rgba(255,77,109,0.14)', border: '1px solid rgba(255,77,109,0.35)',
          marginBottom: 14,
        }}>
          <HeartPulse size={22} style={{ color: '#ff4d6d' }} />
        </div>

        <p style={{ fontSize: 16.5, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>
          {PVP_DOWN_MESSAGE}
        </p>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: 18 }}>
          {action
            ? `You can't ${action} while you're down. `
            : ''}
          Get back on your feet and you're free to go again.
        </p>

        {error && (
          <p style={{
            fontSize: 12, color: '#ff8095', background: 'rgba(255,77,109,0.10)',
            border: '1px solid rgba(255,77,109,0.3)', borderRadius: 12,
            padding: '9px 12px', marginBottom: 12,
          }}>
            {error}
          </p>
        )}

        {count > 0 ? (
          <button
            type="button" onClick={onRegenerate} disabled={busy}
            style={{
              width: '100%', padding: 14, borderRadius: 16, border: 'none',
              cursor: busy ? 'not-allowed' : 'pointer',
              fontSize: 14, fontWeight: 800, color: '#fff',
              background: 'linear-gradient(135deg,#ff4d6d,#ff8a5c)',
              boxShadow: '0 6px 18px rgba(255,77,109,0.32)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              opacity: busy ? 0.65 : 1,
            }}
          >
            <HeartPulse size={16} />
            {busy ? 'Regenerating…' : `Regenerate  ·  ${count} left`}
          </button>
        ) : (
          <button
            type="button"
            onClick={() => { onClose(); navigate('/mall') }}
            style={{
              width: '100%', padding: 14, borderRadius: 16, border: 'none', cursor: 'pointer',
              fontSize: 14, fontWeight: 800, color: '#fff',
              background: 'linear-gradient(135deg,var(--accent),var(--accent2))',
              boxShadow: 'var(--elev-raise)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}
          >
            <ShoppingBag size={16} /> Get a Regenerate
          </button>
        )}
      </div>
    </div>
  )
}
