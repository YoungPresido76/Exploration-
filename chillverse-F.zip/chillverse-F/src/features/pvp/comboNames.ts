// src/features/pvp/comboNames.ts
//
// Named signature combos — HEX, BLAZE, COVEN.
//
// A signature name is a pure function of which cards were played, and
// card_ids already ride every surface that shows a combo: the attack
// result you get back, the victim's unseen-attack rows, and the history
// rows. So the name is resolved here rather than stored on pvp_attacks,
// and pvp_attack itself is untouched — no new OUT column, no DROP +
// CREATE of a 650-line function, no re-checking every unqualified
// reference in it (see the 0165g outage).
//
// The table is fetched once per session and cached at module level. New
// names are added by inserting a row in pvp_combo_names; nothing here
// needs to change for that.
import { supabase } from '../../shared/lib/supabase'

export interface ComboName {
  name: string
  colour: string
  cardIds: string[]
}

let cache: ComboName[] | null = null
let inflight: Promise<ComboName[]> | null = null

/**
 * Load the signature table. Safe to call repeatedly — the second call
 * gets the same promise, and every call after that gets the cache.
 */
export function loadComboNames(): Promise<ComboName[]> {
  if (cache) return Promise.resolve(cache)
  if (inflight) return inflight

  // Promise.resolve() first: the supabase builder is a PromiseLike, not a
  // real Promise, so .catch/.finally aren't on it.
  const run = Promise.resolve(supabase.rpc('get_pvp_combo_names'))
    .then(({ data, error }) => {
      if (error) throw error
      const rows = (data ?? []) as { name: string; colour: string; card_ids: string[] }[]
      // Already ordered by sort desc from the RPC, so the first match
      // wins — a three-card signature beats a two-card one sitting
      // inside the same hand.
      const mapped = rows.map(r => ({ name: r.name, colour: r.colour, cardIds: r.card_ids ?? [] }))
      cache = mapped
      return mapped
    })
    .catch(() => {
      // A missing table or an offline moment must never stop an attack
      // animation from playing — the tier stamp is the fallback.
      cache = []
      return [] as ComboName[]
    })
    .finally(() => { inflight = null })

  inflight = run

  return run
}

/**
 * The signature name for a set of played cards, or null.
 *
 * Match rule is containment, not equality: playing Curse I + Medusa Curse
 * alongside a third card still reads HEX. Returns null until the table
 * has loaded, which is why loadComboNames() is kicked off on mount.
 */
export function comboNameFor(cardIds: string[] | null | undefined): ComboName | null {
  if (!cache || !cardIds?.length) return null
  const played = new Set(cardIds)
  for (const combo of cache) {
    if (combo.cardIds.length < 2) continue
    if (combo.cardIds.every(id => played.has(id))) return combo
  }
  return null
}
