// src/features/pvp/FirstBloodMarker.tsx
//
// The glowing red "First Blood" strip that sits directly under the
// followers row on a profile, for whoever landed the first kill in the app
// today. Renders nothing for everyone else, which is almost everyone.
//
// It appears on PRIVATE profiles too. That's consistent rather than an
// oversight: badges, achievements and the PvP panel are all already
// ungated on a followers-only profile (see 0153), and hiding a kill that
// happened in public would be the odd choice.
//
// No PNG — the glow, the drip and the pulse are all CSS, so this costs
// nothing to ship and themes correctly in both light and dark.
import { Droplet } from 'lucide-react'
import { useHasFirstBlood } from './useFirstBlood'
import './pvp-effects.css'

interface FirstBloodMarkerProps {
  userId: string | null | undefined
  /** true when the viewer is looking at their own profile — changes the copy only. */
  isMe?: boolean
  /**
   * 'panel' is the boxed row used inside the profile preview sheet, which
   * already sits on a --surface card. 'page' is the standalone version for
   * the full profile page, which needs its own card treatment.
   */
  variant?: 'panel' | 'page'
}

export default function FirstBloodMarker({
  userId, isMe = false, variant = 'panel',
}: FirstBloodMarkerProps) {
  const has = useHasFirstBlood(userId)
  if (!has) return null

  return (
    <div
      className="cv-firstblood"
      data-variant={variant}
      role="note"
      aria-label="First Blood today"
    >
      <span className="cv-firstblood-orb">
        <Droplet size={14} />
      </span>
      <span className="cv-firstblood-text">
        <span className="cv-firstblood-title">First Blood</span>
        <span className="cv-firstblood-sub">
          {isMe
            ? 'You drew first blood today'
            : 'Drew first blood today'}
        </span>
      </span>
      <span className="cv-firstblood-drip" aria-hidden="true" />
    </div>
  )
}
