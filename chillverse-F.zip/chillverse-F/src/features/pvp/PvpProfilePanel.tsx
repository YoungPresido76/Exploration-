// src/features/pvp/PvpProfilePanel.tsx
//
// The combat side of a player's profile. Renders inside the existing
// Profile / PlayerProfile page below the banner and avatar, replacing the
// social stats block when the player flips to the PvP view.
//
// Design note: this deliberately reads harder than the social profile.
// Everything is driven by one status accent — ice for petrified, toxic
// green for poisoned, ember for dead or critical HP — so the whole panel
// changes character with the player's condition rather than showing a
// small coloured label on an otherwise identical page. The wanted-level
// row is the signature element: six stars that fill as they accrue, so
// the jail threshold is legible at a glance instead of being a number.
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Swords, Skull, Snowflake, Biohazard, ShieldCheck, Crosshair, Lock, Pencil, Info, X, Star, ShoppingBag, HeartPulse, Sparkles, Flame, Skull as SkullIcon, Sun, Hexagon, KeyRound, Sparkle, Hourglass } from 'lucide-react'
import { usePvpState } from './usePvpState'
import { usePvpCards } from './usePvpCards'
import ShowcasePicker from './ShowcasePicker'
import Avatar from '../../shared/components/Avatar'
import { cardMagnitudeAtLevel, getPvpAttackHistory } from './pvp'
import { useRegenerate } from './useRegenerate'
import { useRedemption, useJailbreakItem, useSecondChance } from './usePvpUtilities'
import { useAuth } from '../auth/useAuth'
import { useElimination } from './useElimination'
import { useSelfBuffs, type PlayableSelfBuff } from './useSelfBuffs'
import type { PvpAttackHistoryEntry, PvpCard, PvpDisplayStatus, PvpState } from './pvp'

/* ── Status accent ─────────────────────────────────────────────────── */

interface StatusLook {
  label: string
  color: string
  glow: string
  Icon: typeof Swords
}

/**
 * `marked` is not one of the server's display_status values — get_pvp_state
 * returns it as the separate `is_marked` flag, because a mark is a brand
 * somebody else put on you rather than a condition of your own body. It was
 * therefore the one state with no icon and no colour: a marked player read as
 * plain "Alive", green swords, with the mark mentioned only in the small
 * print. It gets the same treatment as the rest here, in the pink of the
 * card that plants it.
 */
/**
 * `medusa` is not one of the server's display_status values either. Medusa
 * Curse is seeded as effect_type 'petrify', which is what gives it the
 * ten-minute lock for free — but it meant the panel showed a Medusa stone
 * as plain ice-blue "Petrified", indistinguishable from the card that
 * merely freezes you. The two are not the same threat: one expires
 * quietly, the other detonates for 50. `petrify_shatter` already tells
 * them apart (0 vs the magnitude), so the split is free.
 */
type PanelStatus = PvpDisplayStatus | 'marked' | 'medusa'

const STATUS_LOOK: Record<PanelStatus, StatusLook> = {
  alive:     { label: 'Alive',     color: '#3ecf8e', glow: 'rgba(62,207,142,0.18)', Icon: Swords },
  dead:      { label: 'Down',      color: '#ff4d6d', glow: 'rgba(255,77,109,0.20)', Icon: Skull },
  poisoned:  { label: 'Poisoned',  color: '#8ede4b', glow: 'rgba(142,222,75,0.20)', Icon: Biohazard },
  petrified: { label: 'Petrified', color: '#5fd0ff', glow: 'rgba(95,208,255,0.20)', Icon: Snowflake },
  // Stone grey against Petrify's ice, over the red the victim already sees
  // on the stone veil — the two screens have to read as the same event.
  medusa:    { label: 'Medusa Curse', color: '#b9b2ad', glow: 'rgba(255,59,48,0.18)', Icon: Hourglass },
  corrupted: { label: 'Corrupted', color: '#e28c31', glow: 'rgba(226,140,49,0.20)', Icon: Biohazard },
  shielded:  { label: 'Shielded',  color: '#f5c542', glow: 'rgba(245,197,66,0.20)', Icon: ShieldCheck },
  marked:    { label: 'Marked',    color: '#ff5fa2', glow: 'rgba(255,95,162,0.20)', Icon: Crosshair },
  burning:   { label: 'Burning',   color: '#ff5a1f', glow: 'rgba(255,90,31,0.20)',  Icon: Flame },
  cursed:    { label: 'Cursed',    color: '#ff4d4d', glow: 'rgba(255,77,77,0.22)',  Icon: SkullIcon },
  blessed:   { label: 'Blessed',   color: '#ffd76e', glow: 'rgba(255,215,110,0.20)', Icon: Sun },
  obsidian:  { label: 'Obsidian',  color: '#c9c9c9', glow: 'rgba(120,120,140,0.22)', Icon: Hexagon },
}

/**
 * A mark only takes the header when nothing else is happening. Down,
 * petrified, corrupted, poisoned and shielded all describe what the player
 * can do right now; a mark only describes who gets paid for hitting them, so
 * it must never hide a more urgent state. In the screenshot that started
 * this, the player was down AND marked — that still reads "Down".
 */
function panelStatus(state: PvpState): PanelStatus {
  if (state.display_status === 'petrified' && state.petrify_shatter > 0) return 'medusa'
  return state.display_status === 'alive' && state.is_marked ? 'marked' : state.display_status
}

/** HP bar turns to the danger colour before the player is actually down. */
function hpColor(hp: number, max: number, status: PanelStatus): string {
  if (status === 'dead') return '#ff4d6d'
  const pct = max > 0 ? hp / max : 0
  if (pct <= 0.25) return '#ff4d6d'
  if (pct <= 0.5) return '#f5a742'
  // Blessed and Obsidian are drawn as their OWN segments beside this one.
  // Tinting the real health with them too would paint a full green bar
  // grey the moment a plate went up, which reads as being hurt rather than
  // protected.
  if (status === 'obsidian' || status === 'blessed') return STATUS_LOOK.alive.color
  return STATUS_LOOK[status].color
}

function timeUntil(iso: string | null): string {
  if (!iso) return ''
  const ms = new Date(iso).getTime() - Date.now()
  if (ms <= 0) return 'any moment'
  const mins = Math.ceil(ms / 60000)
  if (mins < 60) return `${mins}m`
  const hrs = Math.floor(mins / 60)
  return `${hrs}h ${mins % 60}m`
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`
  return new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short' })
}

const RARITY_COLOR: Record<string, string> = {
  Common: '#8b95a5', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
}

/* ── Pieces ────────────────────────────────────────────────────────── */

function HealthBar({ state, isOwn }: { state: PvpState; isOwn: boolean }) {
  const color = hpColor(state.hp, state.max_hp, panelStatus(state))
  const frozen = state.is_poisoned || state.status === 'dead'
  // Cheap: useElimination is a module-level store, so asking here costs a
  // subscription rather than a second round trip.
  const { status: elim } = useElimination()
  // "A round is running" was the wrong question, and it made this panel lie
  // to two different people: a player who never registered, who is free to
  // Regenerate all weekend, and a registrant already knocked out, who since
  // 0170b is free too. What matters is whether YOU are still fighting.
  const inTheRound =
    elim?.is_active === true && elim.me_entered === true && elim.me_eliminated !== true

  // Halo and Obsidian sit ON TOP of hp/max_hp — the server does not fold
  // them in — so the bar has to widen to hold them rather than squeezing
  // them into the existing 100. Drawn in drain order, left to right:
  // whatever gets hit first is what you see first.
  const obsidian = state.obsidian_hp ?? 0
  const halo = state.halo_hp ?? 0
  const armour = obsidian + halo
  const scale = state.max_hp + armour
  const pctOf = (v: number) => (scale > 0 ? Math.max(0, Math.min(100, (v / scale) * 100)) : 0)

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 7 }}>
        <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase', color: 'var(--text-dim)' }}>
          Health
        </span>
        <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', fontVariantNumeric: 'tabular-nums' }}>
          {state.hp}
          <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)' }}> / {state.max_hp}</span>
          {armour > 0 && (
            <span style={{
              fontSize: 11, fontWeight: 800, marginLeft: 7,
              color: obsidian > 0 ? '#c9c9c9' : '#ffd76e',
            }}>
              +{armour}
            </span>
          )}
        </span>
      </div>

      <div style={{
        height: 12, borderRadius: 8, background: 'var(--surface3)',
        boxShadow: 'var(--elev-inset)', overflow: 'hidden', position: 'relative',
        display: 'flex',
      }}>
        {obsidian > 0 && (
          <div title={`Obsidian · ${obsidian} HP`} style={{
            width: `${pctOf(obsidian)}%`, height: '100%',
            background: 'linear-gradient(180deg,#26262e,#0a0a0c)',
            borderRight: '1px solid #3a3a44',
            transition: 'width 0.6s cubic-bezier(0.22,1,0.36,1)',
          }} />
        )}
        {halo > 0 && (
          <div title={`Blessed · ${halo} HP`} style={{
            width: `${pctOf(halo)}%`, height: '100%',
            background: 'linear-gradient(180deg,#ffd76e,#e0a92c)',
            boxShadow: '0 0 12px rgba(255,215,110,0.45)',
            transition: 'width 0.6s cubic-bezier(0.22,1,0.36,1)',
          }} />
        )}
        <div style={{
          width: `${pctOf(state.hp)}%`, height: '100%',
          background: `linear-gradient(90deg, ${color}, ${color}cc)`,
          boxShadow: `0 0 12px ${color}66`,
          transition: 'width 0.6s cubic-bezier(0.22,1,0.36,1), background 0.4s ease',
        }} />
      </div>

      {isOwn && armour > 0 && (
        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
          {obsidian > 0 && halo > 0
            ? `${halo} blessed HP burns first, then ${obsidian} of Obsidian, then your health.`
            : obsidian > 0
              ? `${obsidian} HP of Obsidian has to be broken through before anything reaches you.`
              : `${halo} bonus HP, and whatever's left when it expires is gone.`}
        </p>
      )}

      {isOwn && (
        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
          {state.status === 'dead'
            ? inTheRound
              ? 'Knocked out of the elimination round. No Regenerate until it closes.'
              : 'No recovery while down — use Regenerate to get back up.'
            : inTheRound
              ? 'Health is frozen while you\u2019re in the elimination round.'
              : frozen
                ? `Recovery frozen${state.regen_frozen_until ? ` for ${timeUntil(state.regen_frozen_until)}` : ''}.`
                : 'Recovers about 8 health an hour.'}
        </p>
      )}
    </div>
  )
}

/**
 * One star in the wanted row. Stars drain continuously server-side
 * (pvp_current_stars — 1 star per 6h), so a star that's mid-decay renders
 * partially filled rather than snapping straight to empty at the next
 * whole number: `fraction` is how much of THIS star is still lit, 0–1.
 * Built as an empty star underneath and a width-clipped filled star on
 * top, since lucide's Star has no native partial-fill support.
 */
function WantedStar({ fraction, color, danger }: { fraction: number; color: string; danger: boolean }) {
  if (fraction <= 0) {
    return <Star size={18} strokeWidth={1.5} fill="transparent" color="var(--surface3)" />
  }
  if (fraction >= 1) {
    return (
      <Star
        size={18}
        strokeWidth={0}
        fill={color}
        color={color}
        style={{ filter: `drop-shadow(0 0 6px ${danger ? 'rgba(255,77,109,0.55)' : 'rgba(245,167,66,0.5)'})` }}
      />
    )
  }
  return (
    <div style={{ position: 'relative', width: 18, height: 18, flexShrink: 0 }}>
      <Star size={18} strokeWidth={1.5} fill="transparent" color="var(--surface3)" style={{ position: 'absolute', inset: 0 }} />
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', width: `${fraction * 100}%` }}>
        <Star
          size={18}
          strokeWidth={0}
          fill={color}
          color={color}
          style={{ filter: `drop-shadow(0 0 6px ${danger ? 'rgba(255,77,109,0.55)' : 'rgba(245,167,66,0.5)'})` }}
        />
      </div>
    </div>
  )
}

/**
 * Wanted level. Six stars rather than a number: the player needs to feel
 * how close jail is, and "4" does not communicate that the way four
 * filled stars next to two empty ones does.
 *
 * `stars` is the ceil'd whole-star count (matches the jail/Most Wanted
 * threshold everywhere else), `exact` is the raw decaying value used
 * only to fill each star proportionally so the row visibly drains
 * instead of dropping a whole star the instant it crosses a boundary.
 */
function WantedLevel({ stars, exact }: { stars: number; exact: number }) {
  const danger = stars >= 4
  const color = danger ? '#ff4d6d' : '#f5a742'
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 7 }}>
        <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase', color: 'var(--text-dim)' }}>
          Wanted level
        </span>
        {danger && (
          <span style={{ fontSize: 10.5, fontWeight: 700, color: '#ff4d6d' }}>
            {6 - stars === 0 ? 'Jailed at 6' : `${6 - stars} from jail`}
          </span>
        )}
      </div>
      <div style={{ display: 'flex', gap: 6 }}>
        {Array.from({ length: 6 }, (_, i) => {
          const fraction = Math.max(0, Math.min(1, exact - i))
          return <WantedStar key={i} fraction={fraction} color={color} danger={danger} />
        })}
      </div>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
        {stars === 0 ? 'Clean record.' : 'Loses about 1 star every 6 hours without attacking.'}
      </p>
    </div>
  )
}

function JailNotice({
  state, isOwn, onBail, viewerId, onReleased,
}: {
  state: PvpState; isOwn: boolean; onBail?: () => void
  viewerId: string | null; onReleased: () => void
}) {
  // Jailbreak sits beside Pay bail rather than replacing it. Bail costs 25
  // Vouchers per hour still to serve (up to 600 on a 24-hour sentence);
  // Jailbreak costs a card and no Vouchers at all. Which is the better deal
  // depends on how long is left, so both stay on screen and the player
  // picks.
  const { count: breakCount, busy: breakBusy, error: breakError, run: runJailbreak } =
    useJailbreakItem(isOwn ? viewerId : null)

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', gap: 10, padding: '13px 15px',
      borderRadius: 14, border: '1px solid rgba(255,77,109,0.35)',
      background: 'rgba(255,77,109,0.10)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Lock size={18} style={{ color: '#ff4d6d', flexShrink: 0 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)' }}>
            {isOwn ? 'You’re in jail' : 'In jail'}
          </p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
            Out in {timeUntil(state.jailed_until)}. {isOwn && 'No attacking or buying cards until then.'}
          </p>
        </div>
        {isOwn && onBail && (
          <button type="button" onClick={onBail} style={{
            flexShrink: 0, padding: '8px 14px', borderRadius: 20, border: 'none', cursor: 'pointer',
            fontSize: 12, fontWeight: 700, color: '#fff', background: 'linear-gradient(135deg,#ff4d6d,#ff8a5c)',
          }}>
            Pay bail
          </button>
        )}
      </div>

      {isOwn && breakCount > 0 && (
        <button
          type="button"
          disabled={breakBusy}
          onClick={async () => {
            const result = await runJailbreak()
            if (result) onReleased()
          }}
          style={{
            width: '100%', padding: '11px', borderRadius: 12, cursor: breakBusy ? 'not-allowed' : 'pointer',
            border: '1px solid rgba(255,255,255,0.16)', background: 'rgba(0,0,0,0.28)',
            fontSize: 12.5, fontWeight: 800, color: '#ffd9dd',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            opacity: breakBusy ? 0.65 : 1,
          }}
        >
          <KeyRound size={14} />
          {breakBusy ? 'Walking out…' : `Use Jailbreak  ·  ${breakCount} left`}
        </button>
      )}
      {breakError && (
        <p style={{ fontSize: 11.5, color: '#ff8095', textAlign: 'center', margin: 0 }}>{breakError}</p>
      )}
    </div>
  )
}

/**
 * Redemption, offered only when there is something for it to burn off.
 * The server refuses an empty cleanse rather than eating the copy, so a
 * button shown on a clean player would be a button that always errors.
 */
function RedemptionRow({
  state, viewerId, onCleansed,
}: { state: PvpState; viewerId: string | null; onCleansed: () => void }) {
  const { count, busy, error, run } = useRedemption(viewerId)

  const cursed = state.is_cursed || state.is_marked || state.is_corrupted || state.is_petrified
  if (!cursed || count === 0) return null

  // A Medusa stone is the one case with a deadline attached, so it gets
  // named. Everything else is just "curses".
  const fuse = state.is_petrified && state.petrify_shatter > 0

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <button
        type="button"
        disabled={busy}
        onClick={async () => {
          const result = await run()
          if (result) onCleansed()
        }}
        style={{
          width: '100%', padding: '13px', borderRadius: 16, cursor: busy ? 'not-allowed' : 'pointer',
          border: '1px solid rgba(255,215,110,0.4)',
          background: 'linear-gradient(135deg,rgba(255,215,110,0.16),rgba(255,215,110,0.05))',
          fontSize: 13.5, fontWeight: 800, color: '#ffd76e',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          opacity: busy ? 0.65 : 1,
        }}
      >
        <Sparkle size={15} />
        {busy ? 'Burning it off…' : `Use Redemption  ·  ${count} left`}
      </button>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', textAlign: 'center', margin: 0 }}>
        {fuse
          ? 'Breaks the stone before it shatters on you.'
          : 'Clears every curse standing on you. Poison and burn stay.'}
      </p>
      {error && (
        <p style={{ fontSize: 11.5, color: '#ff8095', textAlign: 'center', margin: 0 }}>{error}</p>
      )}
    </div>
  )
}

/**
 * Second Chance, on someone ELSE's profile while they're down.
 *
 * Holding copies is not the same as being allowed to spend one — the quota
 * is two per rolling 24 hours and lives server-side — so the button says
 * which of the two is stopping you rather than failing on tap.
 */
function SecondChanceRow({
  targetId, onRevived,
}: { targetId: string; onRevived: () => void }) {
  const { session } = useAuth()
  const viewerId = session?.user?.id ?? null
  const { count, busy, error, run, usesLeft, nextAt } = useSecondChance(viewerId)

  if (!viewerId || count === 0) return null

  const spent = usesLeft <= 0

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <button
        type="button"
        disabled={busy || spent}
        onClick={async () => {
          const result = await run(targetId)
          if (result) onRevived()
        }}
        style={{
          width: '100%', padding: '13px', borderRadius: 16,
          cursor: busy || spent ? 'not-allowed' : 'pointer',
          border: '1px solid rgba(120,220,180,0.4)',
          background: spent
            ? 'var(--surface3)'
            : 'linear-gradient(135deg,rgba(120,220,180,0.18),rgba(120,220,180,0.06))',
          fontSize: 13.5, fontWeight: 800, color: spent ? 'var(--text-muted)' : '#7fe3bd',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          opacity: busy ? 0.65 : 1,
        }}
      >
        <HeartPulse size={15} />
        {busy ? 'Bringing them back…'
          : spent ? 'Both Second Chances used'
          : `Give a Second Chance  ·  ${usesLeft} today`}
      </button>
      <p style={{ fontSize: 11.5, color: 'var(--text-muted)', textAlign: 'center', margin: 0 }}>
        {spent
          ? nextAt ? `One comes back in ${timeUntil(nextAt)}.` : 'One comes back 24 hours after you spent it.'
          : 'Puts them back on their feet at 1 HP. Twice in 24 hours, never the same player twice.'}
      </p>
      {error && (
        <p style={{ fontSize: 11.5, color: '#ff8095', textAlign: 'center', margin: 0 }}>{error}</p>
      )}
    </div>
  )
}

function CardTile({ card, featured }: { card: PvpCard; featured?: boolean }) {
  const rarityColor: Record<string, string> = {
    Common: '#8b95a5', Rare: '#4f8ef7', Epic: '#9b6dff', Mythic: '#f5a742',
  }
  const color = rarityColor[card.rarity] ?? 'var(--text-muted)'
  const imageSize = featured ? 52 : 40
  return (
    <div style={{
      flex: featured ? undefined : 1, minWidth: 0,
      display: 'flex', alignItems: featured ? 'flex-start' : 'center', gap: featured ? 12 : 10,
      padding: featured ? '14px 15px' : '11px 12px',
      borderRadius: 14, border: `1px solid ${color}55`,
      background: `linear-gradient(160deg, ${color}18, var(--surface))`,
      boxShadow: 'var(--elev-raise-sm)',
    }}>
      {card.image_url ? (
        <img
          src={card.image_url}
          alt=""
          style={{
            width: imageSize, height: imageSize, borderRadius: 10, objectFit: 'cover',
            flexShrink: 0, border: `1px solid ${color}44`,
          }}
        />
      ) : (
        <span style={{
          width: imageSize, height: imageSize, borderRadius: 10, flexShrink: 0,
          background: `${color}22`, border: `1px solid ${color}44`,
        }} />
      )}

      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontSize: 9.5, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase',
          color, marginBottom: 3,
        }}>
          {card.rarity}
        </p>
        <p style={{
          fontSize: featured ? 15 : 12.5, fontWeight: 800, color: 'var(--text)',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {card.name}
        </p>
        {featured && card.flavor && (
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 4, fontStyle: 'italic' }}>
            {card.flavor}
          </p>
        )}
        {card.owned && (
          <p style={{ fontSize: 10.5, color: 'var(--text-dim)', marginTop: featured ? 6 : 3, fontWeight: 600 }}>
            Lv {card.card_level}{card.base_damage > 0 && ` · ${Math.round(card.current_damage)} dmg`}
          </p>
        )}
      </div>
    </div>
  )
}

/** Both petrify cards share one effect_type, so the card name is what
 *  separates them in the report — the same reason the status badge splits. */
function isMedusaPlay(entry: PvpAttackHistoryEntry): boolean {
  return entry.card_names.some(n => /medusa/i.test(n))
}

function attackSummary(entry: PvpAttackHistoryEntry): string {
  if (entry.effect_type === 'poison') return 'Poisoned you'
  if (entry.effect_type === 'petrify') {
    return isMedusaPlay(entry) ? 'Cursed you with Medusa' : 'Petrified you'
  }
  if (entry.effect_type === 'corrupt') return 'Corrupted you'
  if (entry.effect_type === 'mark') return 'Marked you'
  if (entry.damage_dealt > 0) return `Hit you for ${Math.round(entry.damage_dealt)}`
  return 'Attacked you'
}

/** Bottom sheet: which card(s) an attack in the report used. */
function AttackDetailSheet({ entry, onClose }: { entry: PvpAttackHistoryEntry | null; onClose: () => void }) {
  // Lock the page behind the sheet while it's open. Without this the
  // background can still scroll under a fixed-position sheet on mobile
  // (address-bar collapse, momentum scroll, etc.), which reads as the
  // sheet itself drifting away from the bottom of the screen. The sheet's
  // own content keeps scrolling independently via its overflowY: auto.
  useEffect(() => {
    if (!entry) return
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = original }
  }, [entry])

  if (!entry) return null
  const cards = entry.card_ids.map((id, i) => ({
    id, name: entry.card_names[i] ?? 'Unknown card', rarity: entry.card_rarities[i] ?? 'Common',
  }))

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 200, background: 'rgba(0,0,0,0.55)',
        display: 'flex', alignItems: 'flex-end',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        className="neu-card"
        style={{
          width: '100%', borderRadius: '20px 20px 0 0', padding: '18px 18px 24px',
          background: 'var(--surface)', maxHeight: '70vh', overflowY: 'auto',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar src={entry.attacker_avatar} name={entry.attacker_display_name ?? entry.attacker_username} userId={entry.attacker_id} size={36} />
            <div>
              <p style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)' }}>
                {entry.attacker_display_name ?? entry.attacker_username}
              </p>
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{timeAgo(entry.created_at)}</p>
            </div>
          </div>
          <button type="button" onClick={onClose} style={{
            background: 'var(--surface3)', border: 'none', borderRadius: 10, width: 30, height: 30,
            display: 'grid', placeItems: 'center', cursor: 'pointer', color: 'var(--text-muted)',
          }}>
            <X size={16} />
          </button>
        </div>

        <p style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase', color: 'var(--text-dim)', marginBottom: 8 }}>
          {attackSummary(entry)}{entry.damage_dealt > 0 ? ` · ${Math.round(entry.damage_dealt)} dmg` : ''}
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {cards.length === 0 && (
            <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Card details aren't available for this attack.</p>
          )}
          {cards.map((card, i) => {
            const color = RARITY_COLOR[card.rarity] ?? 'var(--text-muted)'
            return (
              <div key={`${card.id}-${i}`} style={{
                padding: '11px 13px', borderRadius: 12, border: `1px solid ${color}55`,
                background: `linear-gradient(160deg, ${color}18, var(--surface))`,
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{card.name}</span>
                <span style={{ fontSize: 10, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase', color }}>
                  {card.rarity}
                </span>
              </div>
            )
          })}
        </div>

        {entry.was_retaliation && (
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 12 }}>Retaliation attack.</p>
        )}
      </div>
    </div>
  )
}

/** Own-profile only: who has attacked you, with a tap-through to the card(s) they used. */
function AttackReport() {
  const [entries, setEntries] = useState<PvpAttackHistoryEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<PvpAttackHistoryEntry | null>(null)

  useEffect(() => {
    let cancelled = false
    getPvpAttackHistory(30)
      .then(rows => { if (!cancelled) setEntries(rows) })
      .catch(() => { if (!cancelled) setEntries([]) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [])

  if (loading || entries.length === 0) return null

  return (
    <div>
      <p style={{
        fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase',
        color: 'var(--text-dim)', marginBottom: 8,
      }}>
        Attack report
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {entries.map(entry => (
          <div key={entry.id} className="neu-card" style={{
            display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 14,
          }}>
            <Avatar src={entry.attacker_avatar} name={entry.attacker_display_name ?? entry.attacker_username} userId={entry.attacker_id} size={32} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {entry.attacker_display_name ?? entry.attacker_username}
              </p>
              <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
                {attackSummary(entry)} · {timeAgo(entry.created_at)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSelected(entry)}
              aria-label="View battle card used"
              style={{
                flexShrink: 0, background: 'var(--surface3)', border: 'none', borderRadius: 10,
                width: 30, height: 30, display: 'grid', placeItems: 'center', cursor: 'pointer',
                color: 'var(--text-muted)',
              }}
            >
              <Info size={16} />
            </button>
          </div>
        ))}
      </div>

      <AttackDetailSheet entry={selected} onClose={() => setSelected(null)} />
    </div>
  )
}

/* ── Panel ─────────────────────────────────────────────────────────── */

interface PvpProfilePanelProps {
  userId: string
  /** True when the player is looking at their own profile. */
  isOwn: boolean
  /** Opens the attack sheet. Only rendered when viewing someone else. */
  onAttack?: () => void
  onBail?: () => void
  /**
   * Optional override for the Regenerate button. Left unset, the panel
   * handles it itself — which it now must, because neither call site ever
   * passed this, so the button was inert for as long as it has existed.
   */
  onRegenerate?: () => void
  /**
   * The VIEWER's own jailed_until (not the profile being viewed). Only
   * relevant when isOwn is false — lets the Attack button reflect "I can't
   * attack anyone right now" as well as "this target can't be attacked",
   * which used to be indistinguishable since both only checked the
   * target's state.
   */
  viewerJailedUntil?: string | null
  /**
   * Bump this (e.g. with a counter or Date.now()) whenever the parent
   * knows this player's HP just changed server-side — an attack you just
   * landed on them, most obviously — so the bar updates without the
   * player having to close and reopen the profile.
   */
  refreshSignal?: number
}

export default function PvpProfilePanel({
  userId, isOwn, onAttack, onBail, onRegenerate, viewerJailedUntil, refreshSignal,
}: PvpProfilePanelProps) {
  const { state, loading, refetch } = usePvpState(userId)
  const navigate = useNavigate()
  // The VIEWER, not the profile owner. Second Chance and Jailbreak both
  // spend the viewer's own inventory, and on someone else's profile
  // `userId` is the wrong person entirely.
  const { session } = useAuth()
  const viewerId = session?.user?.id ?? null
  // Only meaningful on your own profile; passing null on someone else's
  // keeps it from reading an inventory that isn't yours to spend.
  const {
    count: regenCount, busy: regenBusy, error: regenError, run: runRegenerate,
  } = useRegenerate(isOwn ? userId : null)
  const { status: elimStatus } = useElimination()
  // Same correction as HealthBar above: still fighting, not merely "a round
  // exists". This gate decides whether the Regenerate button is shown at
  // all, so getting it wrong hides the only action a dead player has.
  const stillFighting =
    elimStatus?.is_active === true &&
    elimStatus.me_entered === true && elimStatus.me_eliminated !== true

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (refreshSignal !== undefined) refetch() }, [refreshSignal])
  const { cards } = usePvpCards()
  const [pickerOpen, setPickerOpen] = useState(false)

  const byId = useMemo(() => new Map(cards.map(c => [c.item_id, c])), [cards])
  const favorite = state?.favorite_card_id ? byId.get(state.favorite_card_id) : undefined
  const showcase = useMemo(
    () => (state?.showcase_card_ids ?? []).map(id => byId.get(id)).filter((c): c is PvpCard => !!c),
    [state, byId],
  )

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
        <span style={{
          width: 22, height: 22, borderRadius: '50%', border: '2px solid var(--surface3)',
          borderTopColor: 'var(--accent)', display: 'block', animation: 'spin 0.8s linear infinite',
        }} />
      </div>
    )
  }

  if (!state) return null

  const look = STATUS_LOOK[panelStatus(state)]
  const markedIsHeadline = panelStatus(state) === 'marked'
  const StatusIcon = look.Icon
  const jailed = state.is_jailed
  const viewerJailed = !!viewerJailedUntil && new Date(viewerJailedUntil) > new Date()
  const attackBlocked = jailed || state.status === 'dead' || viewerJailed

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* Status header — the accent that colours the whole panel */}
      <div className="neu-card" style={{
        padding: 16, borderRadius: 18,
        border: `1px solid ${look.color}44`,
        background: `linear-gradient(150deg, ${look.glow}, var(--surface))`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 11, display: 'grid', placeItems: 'center',
            background: look.glow, border: `1px solid ${look.color}55`,
          }}>
            <StatusIcon size={17} style={{ color: look.color }} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 15, fontWeight: 800, color: look.color }}>{look.label}</p>
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
              {/* Corruption first: it is the only status that changes what
                  YOU can do rather than what is being done to you, so a
                  bare "Corrupted" label with no number is useless. */}
              {/* Stone goes first: it is the only status with a payload
                  waiting on a clock, and a player who can't see the 50
                  coming can't spend a Redemption to stop it. */}
              {state.is_petrified && state.petrify_shatter > 0
                ? `Sealed in stone · shatters for ${state.petrify_shatter} in ${timeUntil(state.petrify_expires_at)}`
                : state.is_petrified
                ? `Frozen out of attacking · ${timeUntil(state.petrify_expires_at)} left`
                : state.is_corrupted && state.corrupt_penalty_pct > 0
                ? `Attacks land ${state.corrupt_penalty_pct}% weaker · ${timeUntil(state.corrupt_expires_at)} left`
                : state.shield_charges > 0
                  ? `Shield holding · ${state.shield_charges} hit${state.shield_charges === 1 ? '' : 's'}`
                  : state.is_marked
                    ? markedIsHeadline
                      /* The header already says "Marked", so the subtitle
                         drops the word and just explains the consequence. */
                      ? 'Attackers share their vouchers with whoever branded them'
                      : 'Marked — attackers share their vouchers with whoever branded them'
                    : 'Battle status'}
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <HealthBar state={state} isOwn={isOwn} />
          <WantedLevel stars={state.stars} exact={state.stars_exact} />
        </div>
      </div>

      {jailed && (
        <JailNotice
          state={state} isOwn={isOwn} onBail={onBail}
          viewerId={viewerId} onReleased={refetch}
        />
      )}

      {/* Own profile, cursed: the way out. Above the Regenerate block on
          purpose — a Medusa stone is on a clock, so if both are on screen
          the one with a deadline goes first. */}
      {isOwn && !jailed && (
        <RedemptionRow state={state} viewerId={viewerId} onCleansed={refetch} />
      )}

      {/* Own profile, down, and knocked out of a live round: there is no
          action, and offering the Regenerate button anyway would just walk
          the player into pvp_regenerate's refusal. Say the rule instead. */}
      {isOwn && state.status === 'dead' && !jailed && stillFighting && (
        <div style={{
          padding: '13px 15px', borderRadius: 16,
          background: 'rgba(255,77,109,0.10)',
          border: '1px solid rgba(255,77,109,0.28)',
        }}>
          <p style={{ fontSize: 13, fontWeight: 800, color: '#ff8095', margin: '0 0 4px' }}>
            Out of the round
          </p>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
            You can't Regenerate until the elimination round closes
            {elimStatus?.ends_at ? ` — ${timeUntil(elimStatus.ends_at)} to go` : ''}.
            Games and Exploration are still open to you.
          </p>
        </div>
      )}

      {/* Own profile, down: the one action that matters */}
      {isOwn && state.status === 'dead' && !jailed && !stillFighting && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button
            type="button"
            disabled={regenBusy}
            onClick={async () => {
              if (onRegenerate) { onRegenerate(); return }
              if (regenCount === 0) { navigate('/mall'); return }
              const ok = await runRegenerate()
              if (ok) refetch()
            }}
            style={{
              width: '100%', padding: '14px', borderRadius: 16, border: 'none',
              cursor: regenBusy ? 'not-allowed' : 'pointer',
              fontSize: 14, fontWeight: 800, color: '#fff',
              background: regenCount === 0 && !onRegenerate
                ? 'linear-gradient(135deg,var(--accent),var(--accent2))'
                : 'linear-gradient(135deg,#ff4d6d,#ff8a5c)',
              boxShadow: '0 6px 18px rgba(255,77,109,0.32)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              opacity: regenBusy ? 0.65 : 1,
            }}
          >
            {regenCount === 0 && !onRegenerate && <ShoppingBag size={16} />}
            {regenBusy
              ? 'Regenerating…'
              : onRegenerate
                ? 'Regenerate'
                : regenCount === 0
                  ? 'Get a Regenerate'
                  : `Regenerate  ·  ${regenCount} left`}
          </button>
          {regenError && (
            <p style={{
              fontSize: 11.5, color: '#ff8095', textAlign: 'center', margin: 0,
            }}>
              {regenError}
            </p>
          )}
        </div>
      )}

      {/* Someone else's profile: attack */}
      {!isOwn && (
        <>
          <button
            type="button"
            onClick={onAttack}
            disabled={attackBlocked}
            style={{
              width: '100%', padding: '14px', borderRadius: 16, border: 'none',
              cursor: attackBlocked ? 'not-allowed' : 'pointer',
              fontSize: 14, fontWeight: 800,
              color: attackBlocked ? 'var(--text-muted)' : '#fff',
              background: attackBlocked
                ? 'var(--surface3)'
                : 'linear-gradient(135deg,var(--accent),var(--accent2))',
              boxShadow: attackBlocked ? 'none' : 'var(--elev-raise)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}
          >
            <Swords size={16} />
            {state.status === 'dead' ? 'Already down'
              : viewerJailed ? "You're in jail"
              : jailed ? 'In jail'
              : 'Attack'}
          </button>
          {viewerJailed && !jailed && state.status !== 'dead' && (
            <p style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              fontSize: 11.5, color: 'var(--text-muted)', margin: '-6px 0 0',
            }}>
              <Lock size={11} /> No attacking until you're out — {timeUntil(viewerJailedUntil ?? null)}
            </p>
          )}

          {/* They're down and you're holding a Second Chance. Not offered
              while they're jailed: the server has no objection, but a
              player who is both dead and in jail has a bigger problem than
              1 HP, and the row would sit under a button that already says
              "In jail". */}
          {state.status === 'dead' && !jailed && (
            <SecondChanceRow targetId={userId} onRevived={refetch} />
          )}
        </>
      )}

      {/* Your own cards, played on yourself. Hidden while down or jailed,
          because the server refuses both and a live button that always
          errors is worse than no button. */}
      {isOwn && state.status !== 'dead' && !jailed && (
        <SelfBuffRow userId={userId} onPlayed={refetch} />
      )}

      {isOwn && <AttackReport />}

      {/* Favourite card */}
      {favorite && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
            <p style={{
              fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase',
              color: 'var(--text-dim)',
            }}>
              Card of choice
            </p>
            {isOwn && (
              <button type="button" onClick={() => setPickerOpen(true)} style={{
                background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)',
                display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 700,
                font: 'inherit', padding: 0,
              }}>
                <Pencil size={11} /> Edit
              </button>
            )}
          </div>
          <CardTile card={favorite} featured />
        </div>
      )}

      {/* Showcase */}
      {showcase.length > 0 && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
            <p style={{
              fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase',
              color: 'var(--text-dim)',
            }}>
              Showcase
            </p>
            {/* Only reachable here when a favourite is not set; otherwise the
                Card of choice header above already offers Edit. */}
            {isOwn && !favorite && (
              <button type="button" onClick={() => setPickerOpen(true)} style={{
                background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)',
                display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 700,
                font: 'inherit', padding: 0,
              }}>
                <Pencil size={11} /> Edit
              </button>
            )}
          </div>
          <div style={{ display: 'flex', gap: 9 }}>
            {showcase.map(card => <CardTile key={card.item_id} card={card} />)}
          </div>
        </div>
      )}

      {/* Empty state doubles as the entry point — previously this told the
          player to pick cards without giving them anywhere to do it. */}
      {isOwn && !favorite && showcase.length === 0 && (
        <button
          type="button"
          onClick={() => setPickerOpen(true)}
          style={{
            fontSize: 12.5, color: 'var(--text-muted)', textAlign: 'center', width: '100%',
            padding: '18px 12px', border: '1px dashed var(--border-strong)', borderRadius: 14,
            background: 'none', cursor: 'pointer', font: 'inherit', lineHeight: 1.5,
          }}
        >
          Pick a card of choice and up to three to show off — they’ll appear here for anyone who visits.
        </button>
      )}

      {isOwn && (
        <ShowcasePicker
          open={pickerOpen}
          currentFavorite={state.favorite_card_id}
          currentShowcase={state.showcase_card_ids ?? []}
          onClose={() => setPickerOpen(false)}
          onSaved={refetch}
        />
      )}
    </div>
  )
}

/* ── Self-buff kit ──────────────────────────────────────────────────
   Shield and Second Wind. Before this, pvp_use_self_buff() had no caller
   anywhere in the app — Shield was purchasable but unplayable — so this
   row is a fix as much as it is a home for the new card. */

function SelfBuffRow({ userId, onPlayed }: { userId: string; onPlayed: () => void }) {
  const { buffs, playing, error, play } = useSelfBuffs(userId)
  const [flash, setFlash] = useState<string | null>(null)

  if (buffs.length === 0) return null

  async function run(buff: PlayableSelfBuff) {
    const result = await play(buff.card.item_id)
    if (!result) return
    const left = result.consumable ? ` · ${result.copies_left ?? 0} left` : ''
    setFlash(
      result.effect === 'heal'
        ? `+${result.healed} HP${left}`
        : result.effect === 'halo'
          ? `Blessed · +${result.pool} HP${left}`
          : result.effect === 'obsidian'
            ? `Obsidian up · ${result.pool} HP plate${left}`
            : `Shield up · ${result.charges ?? 1} hit${(result.charges ?? 1) === 1 ? '' : 's'}${left}`,
    )
    onPlayed()
    window.setTimeout(() => setFlash(null), 2600)
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <p style={{
          fontSize: 11, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase',
          color: 'var(--text-dim)',
        }}>
          Your kit
        </p>
        {flash && (
          <span style={{
            fontSize: 11, fontWeight: 800, color: '#3ecf8e',
            background: 'rgba(62,207,142,0.14)', border: '1px solid rgba(62,207,142,0.35)',
            borderRadius: 999, padding: '2px 8px',
          }}>
            {flash}
          </span>
        )}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {buffs.map(buff => {
          const heal = buff.card.effect_type === 'heal'
          const color = heal ? '#3ecf8e' : '#f5c542'
          const Icon = heal ? HeartPulse : ShieldCheck
          const busy = playing === buff.card.item_id
          const blocked = !buff.ready || busy

          return (
            <button
              key={buff.card.item_id}
              type="button"
              disabled={blocked}
              onClick={() => run(buff)}
              style={{
                display: 'flex', alignItems: 'center', gap: 11, width: '100%',
                padding: '12px 13px', borderRadius: 15, font: 'inherit', textAlign: 'left',
                cursor: blocked ? 'not-allowed' : 'pointer',
                border: `1px solid ${blocked ? 'var(--border)' : `${color}55`}`,
                background: blocked
                  ? 'var(--surface)'
                  : `linear-gradient(150deg, ${color}18, var(--surface))`,
                opacity: busy ? 0.7 : 1,
              }}
            >
              <span style={{
                width: 34, height: 34, borderRadius: 11, flexShrink: 0,
                display: 'grid', placeItems: 'center',
                background: blocked ? 'var(--surface3)' : `${color}22`,
                border: `1px solid ${blocked ? 'var(--border)' : `${color}55`}`,
              }}>
                <Icon size={16} style={{ color: blocked ? 'var(--text-muted)' : color }} />
              </span>

              <span style={{ flex: 1, minWidth: 0 }}>
                <span style={{
                  display: 'block', fontSize: 13.5, fontWeight: 800, color: 'var(--text)',
                }}>
                  {buff.card.name}
                </span>
                <span style={{
                  display: 'block', fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2,
                }}>
                  {busy
                    ? 'Playing…'
                    : buff.ready
                      ? heal
                        ? `Restore ${Math.round(cardMagnitudeAtLevel(buff.card, buff.card.card_level))} HP${buff.card.is_consumable ? ` · ${buff.card.copies} left` : ''}`
                        : `Absorb the next ${Math.round(cardMagnitudeAtLevel(buff.card, buff.card.card_level))} hit${Math.round(cardMagnitudeAtLevel(buff.card, buff.card.card_level)) === 1 ? '' : 's'}${buff.card.is_consumable ? ` · ${buff.card.copies} left` : ''}`
                      // Naming the blocker is the whole point — "unavailable"
                      // tells the player nothing about what to do next. For a
                      // consumable there is no clock to name, only a shop.
                      : buff.card.is_consumable
                        ? 'None left — restock in the Mall'
                        : `Ready in ${timeUntil(buff.readyAt)}`}
                </span>
              </span>

              {!blocked && <Sparkles size={15} style={{ color, flexShrink: 0 }} />}
            </button>
          )
        })}
      </div>

      {error && (
        <p style={{ fontSize: 11.5, color: '#ff8095', marginTop: 7 }}>{error}</p>
      )}
    </div>
  )
}
