// src/features/pvp/EliminationBriefModal.tsx
//
// Two one-shot modals for the elimination round, sharing one shell because
// they are the same object at two moments: the rules on the way in, and the
// consequence of ignoring them on the way out.
//
//   brief   First time a player ever opens the Elimination board. Says the
//           one thing the board cannot say by itself — that kills, not
//           attendance, are what pay.
//   idle    Last stretch of a live round, when you're in it, still standing
//           and have nothing to show. Fires once per round, not once ever:
//           being idle in March says nothing about April.
//
// Both are gated on localStorage rather than a table. Nothing here is worth
// a write, and a player who clears their storage seeing a rule twice is a
// smaller cost than a column that has to be migrated and cleaned up.
import { useEffect } from 'react'
import { Skull, TimerReset } from 'lucide-react'

const DANGER = '#ff4d6d'

const BRIEF_KEY = 'chillverse:elim-brief-seen'
const IDLE_KEY_PREFIX = 'chillverse:elim-idle-warned:'

/** True if the entry brief has never been shown to this browser. */
export function shouldShowBrief(): boolean {
  try { return localStorage.getItem(BRIEF_KEY) !== '1' } catch { return false }
}

export function markBriefSeen(): void {
  try { localStorage.setItem(BRIEF_KEY, '1') } catch { /* private mode */ }
}

/** Keyed per round, so the warning can land again next weekend. */
export function shouldShowIdleWarning(windowKey: string): boolean {
  try { return localStorage.getItem(IDLE_KEY_PREFIX + windowKey) !== '1' } catch { return false }
}

export function markIdleWarned(windowKey: string): void {
  try { localStorage.setItem(IDLE_KEY_PREFIX + windowKey, '1') } catch { /* private mode */ }
}

interface Props {
  kind: 'brief' | 'idle'
  /** Base payout, owner-set — never hardcode it into the copy. */
  reward: number
  /** Only used by the idle warning: half pay is still on the table at 3+. */
  attacks?: number
  /** Only used by the idle warning, e.g. "9h". */
  timeLeft?: string
  onClose: () => void
}

export default function EliminationBriefModal({
  kind, reward, attacks = 0, timeLeft, onClose,
}: Props) {
  // A modal that lands while you're mid-scroll should not also let the page
  // keep moving underneath it.
  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [])

  const idle = kind === 'idle'
  const halfPay = Math.floor(reward / 2)
  const fought = attacks >= 3

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050,
        display: 'grid', placeItems: 'center', padding: 22,
        background: 'rgba(4,4,6,0.86)', backdropFilter: 'blur(3px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 340, padding: '24px 20px 20px',
          borderRadius: 20, textAlign: 'center',
          border: `1px solid ${DANGER}57`,
          background: `radial-gradient(120% 80% at 50% 0%, ${DANGER}29, var(--surface) 68%)`,
          boxShadow: '0 26px 60px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{
          width: 54, height: 54, borderRadius: '50%', margin: '0 auto',
          display: 'grid', placeItems: 'center',
          background: `${DANGER}24`, border: `1px solid ${DANGER}66`,
        }}>
          {idle ? <TimerReset size={25} color={DANGER} /> : <Skull size={25} color={DANGER} />}
        </div>

        <h3 style={{
          fontFamily: "'Bangers', system-ui, sans-serif",
          fontSize: 27, letterSpacing: 1.2, lineHeight: 1.05,
          color: 'var(--text)', margin: '13px 0 0',
        }}>
          {idle ? 'Being idle isn\u2019t allowed here' : 'Nobody here is your friend'}
        </h3>

        {idle ? (
          <>
            <p style={{ fontSize: 12.5, lineHeight: 1.62, color: 'var(--text-muted)', margin: '11px 0 0' }}>
              {timeLeft ? <>Around <b style={{ color: 'var(--text)' }}>{timeLeft}</b> left, and you haven’t
              taken anyone down. </> : <>You haven’t taken anyone down. </>}
              {fought
                ? <>You’ve been swinging, so half pay is still yours — <b style={{ color: 'var(--text)' }}>{halfPay} Vouchers</b>. One
                  kill turns that into {reward + 1}.</>
                : <>Standing still pays <b style={{ color: 'var(--text)' }}>nothing</b>. Landing a kill pays {reward + 1}.</>}
            </p>
            <p style={{ fontSize: 12.5, fontWeight: 700, color: DANGER, margin: '10px 0 0' }}>
              Eliminate, or your reward gets cut short.
            </p>
          </>
        ) : (
          <>
            <p style={{ fontSize: 12.5, lineHeight: 1.62, color: 'var(--text-muted)', margin: '11px 0 0' }}>
              Every takedown adds <b style={{ color: 'var(--text)' }}>+1 Voucher</b> to what you walk away
              with. So there is no reason to spare anyone — not your club, not your duo,
              <b style={{ color: 'var(--text)' }}> not whoever revived you.</b>
            </p>
            <p style={{ fontSize: 12.5, lineHeight: 1.62, color: 'var(--text-muted)', margin: '9px 0 0' }}>
              Survive without a single kill and you leave with nothing.
            </p>
            <p style={{ fontSize: 12.5, fontWeight: 700, color: DANGER, margin: '10px 0 0' }}>
              Every man for himself.
            </p>
          </>
        )}

        <button
          type="button"
          onClick={onClose}
          style={{
            width: '100%', marginTop: 18, padding: '12px 14px', borderRadius: 13,
            border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            fontSize: 13, fontWeight: 800, color: '#fff',
            background: `linear-gradient(120deg, ${DANGER}, #c9184a)`,
            boxShadow: `0 8px 22px ${DANGER}44`,
          }}
        >
          {idle ? 'Go hunting' : 'I\u2019m ready'}
        </button>
      </div>
    </div>
  )
}
