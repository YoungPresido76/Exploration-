// src/features/pvp/BossOrbit.tsx
//
// The PvP Boss's orbit: a star and a snowflake circling the avatar, each
// with a short sparkle trail, on an opened profile only.
//
// It is not an Avatar decoration on purpose. The Plunder crown is wired
// centrally into Avatar and therefore follows its holder into chat, the
// feed, the leaderboards and every row of every board — right for a hat,
// wrong for this. You should have to open somebody's profile to find out
// they're the boss.
//
// Placement rules, learned the hard way from the profile skins:
//
//   - On PlayerProfile this must sit OUTSIDE the [data-cv-part="portrait"]
//     div, in a wrapper. Several skins carry
//     `[data-cv-part="portrait"] > * { border-radius: 2px !important }`,
//     which would square the rings off. Skin selectors are descendant
//     combinators, so an extra ancestor changes nothing.
//   - The parent must be position:relative and sized to the avatar; the
//     orbit insets itself outwards from there by `inset`.
//
// No new state and no fetch: both call sites already load the player's
// badges, so `active` is just "do they hold pvp_boss". When the badge
// moves, the orbit moves with it.
import './pvp-effects.css'

/** One orbiting glyph plus the three dots chasing it. */
interface Orbiter {
  glyph: string
  /** Where it starts on the ring, as a negative animation delay. */
  phase: number
  size: number
  /** Drop-shadow on the glyph and the colour of its trail. */
  halo: string
  trail: string
}

const DURATION = 5.5

const ORBITERS: Orbiter[] = [
  { glyph: '⭐', phase: 0, size: 17, halo: 'rgba(255,220,130,.85)', trail: '#ffe9a8' },
  // Half a lap behind, so there is always one on each side of the face
  // rather than both bunching at the top.
  { glyph: '❄️', phase: -DURATION / 2, size: 16, halo: 'rgba(150,215,255,.85)', trail: '#bfe9ff' },
]

/** Distance behind the glyph, in seconds, and how each dot shrinks. */
const TRAIL = [
  { gap: 0.16, d: 6, o: 0.55 },
  { gap: 0.30, d: 4, o: 0.34 },
  { gap: 0.46, d: 3, o: 0.18 },
]

export default function BossOrbit({
  active, inset = 14,
}: {
  /** True only for the current pvp_boss badge holder. */
  active: boolean
  /** How far the ring sits outside the avatar box, in px. */
  inset?: number
}) {
  if (!active) return null

  return (
    <div
      className="pvp-orbit"
      aria-hidden="true"
      style={{ '--inset': `${inset}px` } as React.CSSProperties}
    >
      <div className="pvp-orbit-halo" />

      {ORBITERS.map(o => (
        <div key={o.glyph} style={{ display: 'contents' }}>
          {TRAIL.map(t => (
            <div
              key={t.gap}
              className="pvp-orbit-trail"
              style={{
                '--dur': `${DURATION}s`,
                '--tdelay': `${o.phase - t.gap}s`,
                '--halo': o.trail,
              } as React.CSSProperties}
            >
              <i style={{ '--d': `${t.d}px`, '--o': t.o } as React.CSSProperties} />
            </div>
          ))}

          <div
            className="pvp-orbit-ring"
            style={{
              '--dur': `${DURATION}s`,
              '--phase': `${o.phase}s`,
              '--size': `${o.size}px`,
              '--halo': o.halo,
            } as React.CSSProperties}
          >
            <b>{o.glyph}</b>
          </div>
        </div>
      ))}
    </div>
  )
}
