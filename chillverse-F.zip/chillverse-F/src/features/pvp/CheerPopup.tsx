// src/features/pvp/CheerPopup.tsx
//
// What a fighter sees when the cheers land.
//
// The notification toast already fires the instant one is sent — this is
// the other half: the next time they open the round, every cheer they
// haven't been shown yet is stacked here with a face on it. One sheet, not
// one per cheer, because five separate popups is a punishment.
//
// Marked seen on close rather than on open, so a cheer that arrives while
// the sheet is already up isn't silently swallowed by a race.
import { useEffect } from 'react'
import { X } from 'lucide-react'
import Avatar from '../../shared/components/Avatar'
import type { Cheer } from './pvp'

const CHEER = '#c084fc'

export default function CheerPopup({
  cheers, onClose,
}: {
  cheers: Cheer[]
  onClose: () => void
}) {
  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [])

  if (cheers.length === 0) return null

  const first = cheers[0]
  const others = cheers.length - 1

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 20050, display: 'grid', placeItems: 'center',
        padding: 22, background: 'rgba(4,4,6,0.86)', backdropFilter: 'blur(3px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 330, padding: '22px 20px 18px', borderRadius: 20,
          textAlign: 'center', position: 'relative',
          border: `1px solid ${CHEER}52`,
          background: `radial-gradient(120% 80% at 50% 0%, ${CHEER}26, var(--surface) 68%)`,
          boxShadow: '0 26px 60px rgba(0,0,0,0.6)',
        }}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          style={{
            position: 'absolute', top: 12, right: 12, width: 26, height: 26, borderRadius: '50%',
            display: 'grid', placeItems: 'center', cursor: 'pointer',
            background: 'var(--surface2)', border: '1px solid var(--border)', color: 'var(--text-muted)',
          }}
        >
          <X size={13} />
        </button>

        <div style={{ fontSize: 34, lineHeight: 1, marginTop: 4 }}>🎉</div>

        {/* One face if it's one cheer; a little row of them if several. The
            avatar is the whole point — a name alone doesn't land. */}
        <div style={{
          display: 'flex', justifyContent: 'center', alignItems: 'center',
          gap: -8, marginTop: 12,
        }}>
          {cheers.slice(0, 4).map((c, i) => (
            <span key={c.id} style={{ marginLeft: i === 0 ? 0 : -10, zIndex: 10 - i }}>
              <Avatar
                src={c.avatar}
                name={c.display_name || c.username}
                ownerId={c.from_user}
                size={cheers.length === 1 ? 62 : 46}
              />
            </span>
          ))}
        </div>

        <h3 style={{
          fontFamily: "'Bangers', system-ui, sans-serif", fontSize: 23, letterSpacing: 0.8,
          lineHeight: 1.15, color: 'var(--text)', margin: '12px 0 0',
        }}>
          {others > 0
            ? `@${first.username} and ${others} other${others === 1 ? '' : 's'} are cheering you on`
            : `@${first.username} is cheering you on`}
        </h3>
        <p style={{ fontSize: 12.5, lineHeight: 1.6, color: 'var(--text-muted)', margin: '9px 0 0' }}>
          They’re watching you from outside the round. Don’t go down.
        </p>

        <button
          type="button"
          onClick={onClose}
          style={{
            width: '100%', marginTop: 16, padding: '12px 14px', borderRadius: 13,
            border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            fontSize: 13, fontWeight: 800, color: '#fff',
            background: `linear-gradient(120deg, ${CHEER}, #7c3aed)`,
            boxShadow: `0 8px 22px ${CHEER}3d`,
          }}
        >
          Close
        </button>
      </div>
    </div>
  )
}
