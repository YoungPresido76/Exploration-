import { useEffect, lazy, Suspense } from 'react'
import { Routes, Route, Outlet, useNavigate } from 'react-router-dom'
import Landing from '../features/marketing/Landing'
import About from '../features/marketing/About'
import FAQ from '../features/marketing/FAQ'
import Login from '../features/auth/Login'
import Signup from '../features/auth/Signup'
import ForgotPassword from '../features/auth/ForgotPassword'
import Privacy from '../features/marketing/Privacy'
import Terms from '../features/marketing/Terms'
import Dashboard from '../features/dashboard/Dashboard'
import ComingSoon from '../features/marketing/ComingSoon'
import AppLayout from '../layout/AppLayout'
import ClubRouteResolver from '../features/clubs/ClubRouteResolver'
import BlogLayout from '../layout/BlogLayout'
import SupportLayout from '../layout/SupportLayout'
import ProtectedRoute from '../features/auth/ProtectedRoute'
import FeatureFlagGate from '../shared/components/FeatureFlagGate'
import CVLoader from '../shared/components/CVLoader'
import { supabase, supabaseConfigError } from '../shared/lib/supabase'
import { vibrate } from '../shared/lib/vibrate'
import { updateStreak } from '../features/auth/auth'
import { triggerAchievementCheck } from '../features/achievements/triggerAchievements'
import { subscribeToPush } from '../features/notifications/push'
import { consumePendingReferralCode, getDeviceId } from '../features/referral/referral'
import OfflineOverlay from '../shared/components/OfflineOverlay'
import ProRoute from '../shared/components/ProRoute'

const PlayIndex            = lazy(() => import('../features/marketing/PlayIndex'))
const PlayGame             = lazy(() => import('../features/marketing/PlayGame'))
const GamesZone            = lazy(() => import('../features/games/GamesZone'))
const ChampionshipHub      = lazy(() => import('../features/championship/ChampionshipHub'))
const BracketView          = lazy(() => import('../features/championship/BracketView'))
const LoadoutBuilder       = lazy(() => import('../features/championship/LoadoutBuilder'))
const ChampionshipMatchSheet = lazy(() => import('../features/championship/ChampionshipMatchSheet'))
const ChampionshipRules    = lazy(() => import('../features/championship/ChampionshipRules'))
const HallOfChampions      = lazy(() => import('../features/championship/HallOfChampions'))
const ChampionshipSpectateSheet = lazy(() => import('../features/championship/ChampionshipSpectateSheet'))
const GroveStageDetail     = lazy(() => import('../features/games/GroveStageDetail'))
const ProfileRedirect    = lazy(() => import('../features/profile/ProfileRedirect'))
const You                = lazy(() => import('../features/profile/You'))
const ChatHub             = lazy(() => import('../features/chat/ChatHub'))
const QotdThread          = lazy(() => import('../features/chat/QotdThread'))
const Streak             = lazy(() => import('../features/missions/Streak'))
const Settings           = lazy(() => import('../features/settings/Settings'))
const AppTheme           = lazy(() => import('../features/settings/AppTheme'))
const AccountSettings    = lazy(() => import('../features/settings/AccountSettings'))
const SocialSettings     = lazy(() => import('../features/settings/SocialSettings'))
const BlockedAccounts    = lazy(() => import('../features/settings/BlockedAccounts'))
const PrivacySettings    = lazy(() => import('../features/settings/PrivacySettings'))
const AppNotifications   = lazy(() => import('../features/settings/AppNotifications'))
const OtherNotifications = lazy(() => import('../features/settings/OtherNotifications'))
const SubscriptionSettings = lazy(() => import('../features/settings/SubscriptionSettings'))
const Ranks              = lazy(() => import('../features/profile/Ranks'))
const Usage              = lazy(() => import('../features/profile/Usage'))
const Watch              = lazy(() => import('../features/watch/Watch'))
const Mall               = lazy(() => import('../features/economy/Mall'))
const BuyDiamonds        = lazy(() => import('../features/economy/BuyDiamonds'))
const Achievements       = lazy(() => import('../features/achievements/Achievements'))
const Artifacts          = lazy(() => import('../features/economy/Artifacts'))
const Notifications      = lazy(() => import('../features/notifications/Notifications'))
const Inventory          = lazy(() => import('../features/economy/Inventory'))
const SkillTree          = lazy(() => import('../features/pvp/SkillTree'))
const MostWanted         = lazy(() => import('../features/pvp/MostWanted'))
const KillBoard          = lazy(() => import('../features/pvp/KillBoard'))
const Wallet             = lazy(() => import('../features/economy/Wallet'))
const WeeklyMissions     = lazy(() => import('../features/missions/WeeklyMissions'))
const Exploration        = lazy(() => import('../features/exploration/Exploration'))
const VerificationPage   = lazy(() => import('../features/verification/VerificationPage'))
const Version            = lazy(() => import('../features/marketing/Version'))
const HaloAI             = lazy(() => import('../features/halo-ai/HaloAI'))
const Pro                = lazy(() => import('../features/economy/Pro'))
const Multiplayer        = lazy(() => import('../features/multiplayer/Multiplayer'))
const Rooms              = lazy(() => import('../features/multiplayer/Rooms'))
const Room                = lazy(() => import('../features/multiplayer/Room'))
const ClubsList           = lazy(() => import('../features/clubs/ClubsList'))
const ClubChat             = lazy(() => import('../features/clubs/ClubChat'))
const ClubInfo             = lazy(() => import('../features/clubs/ClubInfo'))
const ClubSettings         = lazy(() => import('../features/clubs/ClubSettings'))
const FeedPage            = lazy(() => import('../features/posts/FeedPage'))
const SinglePostPage      = lazy(() => import('../features/posts/SinglePostPage'))
const HighlightsPage      = lazy(() => import('../features/highlights/HighlightsFeed'))
const ReferralPage        = lazy(() => import('../features/referral/Referral'))
const SearchPage          = lazy(() => import('../features/search/SearchPage'))
const Support             = lazy(() => import('../features/support/Support'))
const SupportCategory     = lazy(() => import('../features/support/SupportCategory'))
const SupportArticle      = lazy(() => import('../features/support/SupportArticle'))
const NewTicket           = lazy(() => import('../features/support/NewTicket'))
const MyTickets           = lazy(() => import('../features/support/MyTickets'))
const FeedbackHome        = lazy(() => import('../features/support/feedback/FeedbackHome'))
const FeedbackTopic       = lazy(() => import('../features/support/feedback/FeedbackTopic'))
const FeedbackPost        = lazy(() => import('../features/support/feedback/FeedbackPost'))
const NewFeedback         = lazy(() => import('../features/support/feedback/NewFeedback'))
const AdminSupport        = lazy(() => import('../features/support/AdminSupport'))
const ModerationPanel     = lazy(() => import('../features/moderation/ModerationPanel'))
const Lab                 = lazy(() => import('../features/collab/Lab'))
const CollabPage          = lazy(() => import('../features/collab/CollabPage'))
const AdminDashboard      = lazy(() => import('../features/admin/AdminDashboard'))
const AdminUserDetail     = lazy(() => import('../features/admin/AdminUserDetail'))
const AdminFlashSalePage  = lazy(() => import('../features/admin/AdminFlashSalePage'))
const AdminRedeemCodesPage = lazy(() => import('../features/admin/AdminRedeemCodesPage'))
const AboutAdminPanel     = lazy(() => import('../features/marketing/AboutAdminPanel'))
const Leaderboards        = lazy(() => import('../features/leaderboards/Leaderboards'))
const GameLeaderboardPage = lazy(() => import('../features/leaderboards/GameLeaderboardPage'))
const ChessPage            = lazy(() => import('../features/games/play/ChessPage'))
const Ludo                 = lazy(() => import('../features/games/play/Ludo'))
const WaterTheTree          = lazy(() => import('../features/games/play/WaterTheTree'))
const Blog                = lazy(() => import('../features/blog/Blog'))
const BlogPostPage        = lazy(() => import('../features/blog/BlogPostPage'))
const BlogSeriesPage      = lazy(() => import('../features/blog/BlogSeriesPage'))
const UpdateLog           = lazy(() => import('../features/blog/UpdateLog'))
const AdminBlog           = lazy(() => import('../features/blog/AdminBlog'))
const EditorialRoom       = lazy(() => import('../features/marketing/EditorialRoom'))
const AnnouncementPage    = lazy(() => import('../features/marketing/AnnouncementPage'))
const WorkLanding         = lazy(() => import('../features/careers/WorkLanding'))
const JobDetail           = lazy(() => import('../features/careers/JobDetail'))
const JobApplyForm        = lazy(() => import('../features/careers/JobApplyForm'))
const CareersAdmin        = lazy(() => import('../features/careers/admin/CareersAdmin'))
const Events              = lazy(() => import('../features/events/Events'))
const EventsAdmin         = lazy(() => import('../features/events/admin/EventsAdmin'))

const Fallback = () => (
  <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
    <CVLoader width={140} />
  </div>
)

// chillverse.com.ng/status now redirects to the official Statuspage.io page.
// Kept as a component (not a raw <a>) so it works with direct navigation,
// bookmarks, and shared links — anything that hits /status server-side too.
const STATUS_PAGE_URL = 'https://chillverse.statuspage.io/'
const StatusRedirect = () => {
  useEffect(() => {
    window.location.replace(STATUS_PAGE_URL)
  }, [])
  return (
    <div style={{ color: 'var(--text-dim)', padding: 40, textAlign: 'center' }}>
      Redirecting to status page…
    </div>
  )
}

// Pre-auth entry points only — a SIGNED-IN user landing on one of these
// (e.g. a stale /login tab) gets bounced straight into the app. /privacy
// and /terms are deliberately NOT in this list: they're legitimate pages
// a logged-in user can land on too — e.g. tapping the "Terms and
// Conditions" link from a moderation notice in chat — and should just
// render normally instead of redirecting to /dashboard.
const AUTH_REDIRECT_PATHS = ['/', '/login', '/signup', '/forgot-password']

export default function App() {
  const navigate = useNavigate()

  useEffect(() => {
    if (supabaseConfigError) return

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      // IMPORTANT: Supabase only fires 'SIGNED_IN' for a fresh sign-in
      // action (password login, signup, or an OAuth redirect completing).
      // A user who was ALREADY logged in — the common case, since a
      // session persists across reloads — gets 'INITIAL_SESSION' instead
      // when the app loads. Reacting to 'SIGNED_IN' only meant existing
      // users were silently skipped and never got the push-notification
      // permission prompt at all. Both events need to run this block.
      // Bumps the public "Active Users" counter shown on /editorial-room
      // (see migration 0098). Only a genuine fresh sign-in should count —
      // NOT 'INITIAL_SESSION', which fires on every reload of an already-
      // logged-in tab and would inflate the number on every page load.
      if (event === 'SIGNED_IN' && session) {
        supabase.rpc('increment_auth_activity_counter').then(() => {}, () => {})
      }

      const isRelevantAuthEvent =
        (event === 'SIGNED_IN' || event === 'INITIAL_SESSION') && !!session

      if (isRelevantAuthEvent) {
        const streakFlagKey = `streak_done_${session.user.id}`
        const alreadyRanStreakThisSession = sessionStorage.getItem(streakFlagKey)

        if (!alreadyRanStreakThisSession) {
          sessionStorage.setItem(streakFlagKey, '1')
          await updateStreak(session.user.id)
          vibrate([12, 50, 12]) // streak check-in haptic
          triggerAchievementCheck(session.user.id).catch(console.error)
        }

        // BUG FIX (cross-account push notifications, part 2): this used to
        // be gated behind a `push_prompted_${userId}` localStorage flag so
        // subscribeToPush() would only ever run once per user per device —
        // meant to avoid re-showing the native "Allow notifications?"
        // prompt on every reload. That's unnecessary: subscribeToPush()
        // already only calls Notification.requestPermission() when
        // permission is still undecided (see push.ts) — the browser itself
        // never re-shows the prompt once permission has been granted or
        // denied, regardless of how many times this runs. Worse, now that
        // signOut() properly unsubscribes this device on logout (auth.ts),
        // that permanent flag meant a returning account would silently
        // never get re-subscribed after their first-ever login on this
        // device. Calling it on every relevant auth event is cheap and
        // idempotent — it reuses the existing service worker registration
        // and Push subscription if one exists, and the upsert is a no-op
        // when nothing's changed — so there's no real cost to removing the
        // gate, and it closes the leak instead of reopening it.
        // Fire-and-forget: never awaited so it can't delay the dashboard
        // redirect below, and subscribeToPush() itself never throws (see
        // push.ts) so it's safe uncaught.
        subscribeToPush(session.user.id)

        // Credit a referral for Google/OAuth signups. Email signups get
        // this for free via handle_new_user() reading signUp()'s `data`
        // metadata, but OAuth has no equivalent pass-through — Signup.tsx
        // stashes the ?ref= code before starting the Google redirect (see
        // referral.ts), and this is where it gets applied once the
        // post-redirect session actually exists. No-op (returns
        // {applied:false}) for ordinary logins, since nothing was stashed.
        // Fire-and-forget: never blocks the dashboard redirect below.
        const pendingReferralCode = consumePendingReferralCode()
        if (pendingReferralCode) {
          supabase.rpc('apply_oauth_referral', {
            p_referral_code: pendingReferralCode,
            p_device_id: getDeviceId(),
          }).then(() => {}, () => {})
        }

        const pendingInvite = sessionStorage.getItem('chillverse_pending_invite')
        if (pendingInvite) {
          sessionStorage.removeItem('chillverse_pending_invite')
          navigate(pendingInvite, { replace: true })
        } else if (AUTH_REDIRECT_PATHS.includes(window.location.pathname)) {
          navigate('/dashboard', { replace: true })
        }
      }
    })
    return () => subscription.unsubscribe()
  }, [navigate])

  if (supabaseConfigError) {
    return (
      <>
        <OfflineOverlay />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', padding: 24, textAlign: 'center', fontFamily: 'sans-serif' }}>
          <div>
            <h1 style={{ fontSize: 20, marginBottom: 8 }}>Chillverse is misconfigured</h1>
            <p style={{ color: '#888' }}>{supabaseConfigError}</p>
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      <OfflineOverlay />
      <Routes>
        <Route path="/"                element={<Landing />} />
        <Route path="/about"           element={<About />} />
        <Route path="/faq"             element={<FAQ />} />
        <Route path="/login"           element={<Login />} />
        <Route path="/signup"          element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/privacy"         element={<Privacy />} />
        <Route path="/terms"           element={<Terms />} />

        {/* Careers — public, reachable signed-in or not (like /about, /blog).
            /work/admin gates itself internally via useModRole, same pattern
            as /blog/admin. */}
        <Route path="/work"              element={<Suspense fallback={<Fallback />}><WorkLanding /></Suspense>} />
        <Route path="/work/admin"        element={<Suspense fallback={<Fallback />}><CareersAdmin /></Suspense>} />
        <Route path="/work/:slug/apply"  element={<Suspense fallback={<Fallback />}><JobApplyForm /></Suspense>} />
        <Route path="/work/:slug"        element={<Suspense fallback={<Fallback />}><JobDetail /></Suspense>} />

        {/* Public games directory. Readable signed out — this is the only
            place a visitor or a crawler can see what the games actually are,
            since /games itself is behind auth and Disallowed in robots.txt. */}
        <Route path="/play"              element={<Suspense fallback={<Fallback />}><PlayIndex /></Suspense>} />
        <Route path="/play/:slug"        element={<Suspense fallback={<Fallback />}><PlayGame /></Suspense>} />

        <Route path="/status"          element={<StatusRedirect />} />

        <Route path="/watch" element={<ProtectedRoute><Suspense fallback={<Fallback />}><Watch /></Suspense></ProtectedRoute>} />

        <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
          <Route path="/dashboard"        element={<Dashboard />} />
          <Route path="/coming-soon"      element={<ComingSoon />} />
          <Route path="/games"            element={<Suspense fallback={<Fallback />}><GamesZone /></Suspense>} />
          {/* One gate over all seven championship screens rather than a
              FeatureFlagGate inside each component: a player can arrive at
              /championship/bracket straight from a notification without ever
              passing through the hub, so gating the hub alone would leave six
              back doors open. Staff bypass it — FeatureFlagGate has always
              done that, so an owner can still work on a closed championship.
              The dashboard card is deliberately left visible: tapping it is
              how a player finds out the series is closed. */}
          <Route element={<FeatureFlagGate flagKey="system:championship"><Outlet /></FeatureFlagGate>}>
            <Route path="/championship"     element={<Suspense fallback={<Fallback />}><ChampionshipHub /></Suspense>} />
            <Route path="/championship/bracket" element={<Suspense fallback={<Fallback />}><BracketView /></Suspense>} />
            <Route path="/championship/loadout" element={<Suspense fallback={<Fallback />}><LoadoutBuilder /></Suspense>} />
            <Route path="/championship/my-match" element={<Suspense fallback={<Fallback />}><ChampionshipMatchSheet /></Suspense>} />
            <Route path="/championship/rules" element={<Suspense fallback={<Fallback />}><ChampionshipRules /></Suspense>} />
            <Route path="/championship/hall-of-champions" element={<Suspense fallback={<Fallback />}><HallOfChampions /></Suspense>} />
            <Route path="/championship/spectate/:matchId" element={<Suspense fallback={<Fallback />}><ChampionshipSpectateSheet /></Suspense>} />
          </Route>
          <Route path="/leaderboards"     element={<Suspense fallback={<Fallback />}><Leaderboards /></Suspense>} />
          <Route path="/leaderboards/:gameId" element={<Suspense fallback={<Fallback />}><GameLeaderboardPage /></Suspense>} />
          <Route path="/most-wanted"      element={<Suspense fallback={<Fallback />}><MostWanted /></Suspense>} />
          <Route path="/kill-board"       element={<Suspense fallback={<Fallback />}><KillBoard /></Suspense>} />
          <Route path="/exploration"      element={<Suspense fallback={<Fallback />}><Exploration /></Suspense>} />
          <Route path="/mall"             element={<Suspense fallback={<Fallback />}><Mall /></Suspense>} />
          <Route path="/buy-diamonds"     element={<Suspense fallback={<Fallback />}><BuyDiamonds /></Suspense>} />
          <Route path="/you"              element={<Suspense fallback={<Fallback />}><You /></Suspense>} />
          <Route path="/profile"          element={<Suspense fallback={<Fallback />}><ProfileRedirect /></Suspense>} />
          <Route path="/profile/:userId"  element={<Suspense fallback={<Fallback />}><ProfileRedirect /></Suspense>} />
          <Route path="/chat"             element={<Suspense fallback={<Fallback />}><ChatHub /></Suspense>} />
          <Route path="/chat/qotd"        element={<Suspense fallback={<Fallback />}><QotdThread /></Suspense>} />
          <Route path="/streak"           element={<Suspense fallback={<Fallback />}><Streak /></Suspense>} />
          <Route path="/settings"         element={<Suspense fallback={<Fallback />}><Settings /></Suspense>} />
          <Route path="/settings/theme"   element={<Suspense fallback={<Fallback />}><AppTheme /></Suspense>} />
          <Route path="/settings/account" element={<Suspense fallback={<Fallback />}><AccountSettings /></Suspense>} />
          <Route path="/settings/social"  element={<Suspense fallback={<Fallback />}><SocialSettings /></Suspense>} />
          <Route path="/settings/social/blocked" element={<Suspense fallback={<Fallback />}><BlockedAccounts /></Suspense>} />
          <Route path="/settings/privacy" element={<Suspense fallback={<Fallback />}><PrivacySettings /></Suspense>} />
          <Route path="/settings/notifications" element={<Suspense fallback={<Fallback />}><AppNotifications /></Suspense>} />
          <Route path="/settings/other-notifications" element={<Suspense fallback={<Fallback />}><OtherNotifications /></Suspense>} />
          <Route path="/settings/other-notifications/:section" element={<Suspense fallback={<Fallback />}><OtherNotifications /></Suspense>} />
          <Route path="/settings/subscription" element={<Suspense fallback={<Fallback />}><SubscriptionSettings /></Suspense>} />
          <Route path="/ranks"            element={<Suspense fallback={<Fallback />}><Ranks /></Suspense>} />
          <Route path="/usage"            element={<Suspense fallback={<Fallback />}><Usage /></Suspense>} />
          <Route path="/achievements"     element={<Suspense fallback={<Fallback />}><Achievements /></Suspense>} />
          <Route path="/artifacts"        element={<Suspense fallback={<Fallback />}><Artifacts /></Suspense>} />
          <Route path="/notifications"    element={<Suspense fallback={<Fallback />}><Notifications /></Suspense>} />
          <Route path="/inventory"        element={<Suspense fallback={<Fallback />}><Inventory /></Suspense>} />
          <Route path="/skill-tree"       element={<Suspense fallback={<Fallback />}><SkillTree /></Suspense>} />
          <Route path="/wallet"           element={<Suspense fallback={<Fallback />}><Wallet /></Suspense>} />
          <Route path="/weekly-missions"  element={<Suspense fallback={<Fallback />}><WeeklyMissions /></Suspense>} />
          <Route path="/version"          element={<Suspense fallback={<Fallback />}><Version /></Suspense>} />
          <Route path="/verification"     element={<Suspense fallback={<Fallback />}><VerificationPage /></Suspense>} />
          <Route path="/halo"             element={<Suspense fallback={<Fallback />}><HaloAI /></Suspense>} />
          <Route path="/pro"              element={<Suspense fallback={<Fallback />}><Pro /></Suspense>} />
          <Route path="/multiplayer"      element={<ProRoute><Suspense fallback={<Fallback />}><Multiplayer /></Suspense></ProRoute>} />
          <Route path="/play/chess"       element={<ProRoute><Suspense fallback={<Fallback />}><ChessPage /></Suspense></ProRoute>} />
          <Route path="/play/ludo"        element={<ProRoute><Suspense fallback={<Fallback />}><Ludo /></Suspense></ProRoute>} />
          <Route path="/play/water-the-tree" element={<Suspense fallback={<Fallback />}><WaterTheTree /></Suspense>} />
          {/* No ProRoute/session gating here on purpose -- anyone can see a
              grove milestone from its notification or highlight card, Void
              plan or not, without opening the game itself. */}
          <Route path="/grove/stage/:stageIndex" element={<Suspense fallback={<Fallback />}><GroveStageDetail /></Suspense>} />
          <Route path="/rooms"            element={<ProRoute><Suspense fallback={<Fallback />}><Rooms /></Suspense></ProRoute>} />
          <Route path="/rooms/:roomId"    element={<ProRoute><Suspense fallback={<Fallback />}><Room /></Suspense></ProRoute>} />
          <Route path="/clubs"            element={<Suspense fallback={<Fallback />}><ClubsList /></Suspense>} />
          <Route path="/clubs/:roomId"    element={<ClubRouteResolver><Suspense fallback={<Fallback />}><ClubChat /></Suspense></ClubRouteResolver>} />
          <Route path="/clubs/:roomId/info"     element={<ClubRouteResolver><Suspense fallback={<Fallback />}><ClubInfo /></Suspense></ClubRouteResolver>} />
          <Route path="/clubs/:roomId/settings" element={<ClubRouteResolver><Suspense fallback={<Fallback />}><ClubSettings /></Suspense></ClubRouteResolver>} />
          <Route path="/feed"             element={<Suspense fallback={<Fallback />}><FeedPage /></Suspense>} />
          <Route path="/feed/highlights"  element={<Suspense fallback={<Fallback />}><HighlightsPage /></Suspense>} />
          <Route path="/feed/:postId"     element={<Suspense fallback={<Fallback />}><SinglePostPage /></Suspense>} />
          <Route path="/referral"         element={<Suspense fallback={<Fallback />}><ReferralPage /></Suspense>} />
          <Route path="/search"           element={<Suspense fallback={<Fallback />}><SearchPage /></Suspense>} />
          {/* The Lab — reached from the Social tab's second story. /lab is the
              hub of places; each place is its own route under it. */}
          <Route path="/lab"              element={<Suspense fallback={<Fallback />}><Lab /></Suspense>} />
          <Route path="/lab/collab"       element={<Suspense fallback={<Fallback />}><CollabPage /></Suspense>} />
          <Route path="/moderation"       element={<Suspense fallback={<Fallback />}><ModerationPanel /></Suspense>} />
          <Route path="/admin"            element={<Suspense fallback={<Fallback />}><AdminDashboard /></Suspense>} />
          <Route path="/admin/users/:userId" element={<Suspense fallback={<Fallback />}><AdminUserDetail /></Suspense>} />
          <Route path="/admin/flash-sales"   element={<Suspense fallback={<Fallback />}><AdminFlashSalePage /></Suspense>} />
          <Route path="/admin/redeem-codes"  element={<Suspense fallback={<Fallback />}><AdminRedeemCodesPage /></Suspense>} />
          <Route path="/about/admin"      element={<Suspense fallback={<Fallback />}><AboutAdminPanel /></Suspense>} />
          <Route path="/events"           element={<Suspense fallback={<Fallback />}><Events /></Suspense>} />
          <Route path="/events/admin"     element={<Suspense fallback={<Fallback />}><EventsAdmin /></Suspense>} />
        </Route>

        {/* Blog — a separate public surface (like discord.com/blog vs discord.com),
            reachable and readable by anyone, signed in or not. NOT behind ProtectedRoute
            or AppLayout. /blog/admin is still gated (staff-only) inside AdminBlog itself. */}
        <Route element={<BlogLayout />}>
          <Route path="/blog"                element={<Suspense fallback={<Fallback />}><Blog /></Suspense>} />
          <Route path="/blog/updates"        element={<Suspense fallback={<Fallback />}><UpdateLog /></Suspense>} />
          <Route path="/blog/series/:series" element={<Suspense fallback={<Fallback />}><BlogSeriesPage /></Suspense>} />
          <Route path="/blog/admin"          element={<Suspense fallback={<Fallback />}><AdminBlog /></Suspense>} />
          <Route path="/blog/:slug"          element={<Suspense fallback={<Fallback />}><BlogPostPage /></Suspense>} />
          <Route path="/editorial-room"                       element={<Suspense fallback={<Fallback />}><EditorialRoom /></Suspense>} />
          <Route path="/editorial-room/announcement/:postId"  element={<Suspense fallback={<Fallback />}><AnnouncementPage /></Suspense>} />
        </Route>

        {/* Help center — served at support.chillverse.com.ng (see vercel.json) and
            also reachable at chillverse.com.ng/support. Public: articles, search
            and the feedback board all read fine signed out, exactly like
            support.discord.com. Voting and ticket submission bounce to /login
            with a `next` param. NOT behind ProtectedRoute or AppLayout. */}
        <Route element={<SupportLayout />}>
          <Route path="/support"                           element={<Suspense fallback={<Fallback />}><Support /></Suspense>} />
          <Route path="/support/admin"                     element={<Suspense fallback={<Fallback />}><AdminSupport /></Suspense>} />
          <Route path="/support/tickets"                   element={<Suspense fallback={<Fallback />}><MyTickets /></Suspense>} />
          <Route path="/support/tickets/new"               element={<Suspense fallback={<Fallback />}><NewTicket /></Suspense>} />
          <Route path="/support/feedback"                  element={<Suspense fallback={<Fallback />}><FeedbackHome /></Suspense>} />
          <Route path="/support/feedback/new"              element={<Suspense fallback={<Fallback />}><NewFeedback /></Suspense>} />
          <Route path="/support/feedback/post/:postId"     element={<Suspense fallback={<Fallback />}><FeedbackPost /></Suspense>} />
          <Route path="/support/feedback/:topicSlug"       element={<Suspense fallback={<Fallback />}><FeedbackTopic /></Suspense>} />
          <Route path="/support/:categorySlug"             element={<Suspense fallback={<Fallback />}><SupportCategory /></Suspense>} />
          <Route path="/support/:categorySlug/:articleSlug" element={<Suspense fallback={<Fallback />}><SupportArticle /></Suspense>} />
        </Route>
      </Routes>
    </>
  )
}
