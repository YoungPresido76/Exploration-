// api/og.js
//
// WHY THIS EXISTS
// ---------------
// scripts/prerender.mjs already writes a real static page per blog post with
// its own title, description and hero image — and it works. But it is a
// BUILD-TIME snapshot. Anything that changes in the blog after the last
// Vercel deploy (a new post, a re-publish, an edited title) has no static
// page, so Vercel's SPA rewrite hands the crawler dist/index.html and the
// share card shows the homepage's "Play. Win. Dominate." instead of the post.
// That is exactly what was happening on production: the deployed sitemap
// listed 8 posts while the database had more, and the two newest posts
// unfurled as the site itself.
//
// Feed posts are worse: /feed/:postId is behind ProtectedRoute and Disallowed
// in robots.txt, so it can never be prerendered at all.
//
// This function renders the tags on demand, straight from the database, so a
// link is correct the second it is shared. vercel.json routes here ONLY when
// the user-agent is a social unfurler — real visitors and search engines
// never touch it (see the note on Googlebot in vercel.json).
//
// No dependencies on purpose: node's global fetch plus string building. A
// share card is one <head>; pulling in a Supabase client for two REST reads
// would add install weight to every deploy for nothing.

const SITE_URL = 'https://chillverse.com.ng'
const SUPABASE_URL = process.env.VITE_SUPABASE_URL
const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY

// The homepage card, used whenever we can't do better: unknown slug, deleted
// post, hidden post, database hiccup. Falling back to a correct generic card
// is always better than emitting a broken one.
const DEFAULT_CARD = {
  title: 'Chillverse — Play. Win. Dominate.',
  description:
    'Play fast-paced games, build streaks, climb the leaderboard, and chat with your crew — all in one social gaming universe. Join Chillverse free.',
  image: `${SITE_URL}/og-image-4-banner.png`,
  type: 'website',
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/** Strips the markdownLite syntax scripts/prerender.mjs also strips, so a
 *  description never unfurls as raw `##` and `**` noise. */
function stripMarkdown(text) {
  return String(text ?? '')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\{\{[^}]*\}\}/g, ' ')
    .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/[#>*_`~]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

function clamp(text, max) {
  const clean = String(text ?? '').trim()
  if (clean.length <= max) return clean
  return `${clean.slice(0, max - 1).trimEnd()}…`
}

async function supabaseGet(path) {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return null
  // A crawler waits a very short time before giving up and rendering nothing,
  // so a slow database must not hold the response — we'd rather serve the
  // default card fast than the right card too late.
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 2500)
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` },
      signal: controller.signal,
    })
    if (!res.ok) return null
    return await res.json()
  } catch {
    return null
  } finally {
    clearTimeout(timeout)
  }
}

async function blogCard(slug) {
  // Only published posts. A draft or archived post shared by its author gets
  // the default card rather than leaking an unpublished headline.
  const rows = await supabaseGet(
    `blog_posts?select=slug,title,excerpt,content,hero_image_url,published_at,updated_at` +
      `&slug=eq.${encodeURIComponent(slug)}&is_published=eq.true&limit=1`
  )
  const post = Array.isArray(rows) ? rows[0] : null
  if (!post) return null

  return {
    title: `${post.title} — Chillverse`,
    description: clamp(post.excerpt || stripMarkdown(post.content), 160) || DEFAULT_CARD.description,
    image: post.hero_image_url || DEFAULT_CARD.image,
    type: 'article',
    publishedAt: post.published_at,
    modifiedAt: post.updated_at || post.published_at,
  }
}

async function postCard(postId) {
  // Author + image only, by design. public_post_preview deliberately does not
  // return the post body: a /feed link can be forwarded to anyone, and the
  // feed is not a public surface. It also returns nothing for a hidden post,
  // one marked as a violation, or one by a currently banned account — all of
  // which correctly fall through to the default card.
  const rows = await supabaseGet(
    `rpc/public_post_preview?p_post_id=${encodeURIComponent(postId)}`
  )
  const preview = Array.isArray(rows) ? rows[0] : null
  if (!preview) return null

  const name = preview.display_name || preview.username
  return {
    // Some posts are written by the brand itself (author_type 'system' /
    // 'admin' with no profile behind them), so there isn't always a person
    // to name.
    title: name ? `${name} on Chillverse` : 'A post on Chillverse',
    description: preview.username
      ? `See what @${preview.username} posted on Chillverse.`
      : 'Open Chillverse to see this post.',
    image: preview.image_url || DEFAULT_CARD.image,
    type: 'article',
  }
}

function renderHtml(card, canonicalUrl) {
  const title = escapeHtml(card.title)
  const description = escapeHtml(card.description)
  const image = escapeHtml(card.image)
  const url = escapeHtml(canonicalUrl)

  // This body is only ever seen by an unfurler, but the redirect matters: if
  // a human ever reaches this URL directly (a copied link, a debugger), they
  // land on the real page instead of a blank document.
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>${title}</title>
    <meta name="description" content="${description}" />
    <link rel="canonical" href="${url}" />

    <meta property="og:type" content="${escapeHtml(card.type)}" />
    <meta property="og:url" content="${url}" />
    <meta property="og:title" content="${title}" />
    <meta property="og:description" content="${description}" />
    <meta property="og:image" content="${image}" />
    <meta property="og:site_name" content="Chillverse" />
    <meta property="og:locale" content="en_NG" />
    ${card.publishedAt ? `<meta property="article:published_time" content="${escapeHtml(card.publishedAt)}" />` : ''}
    ${card.modifiedAt ? `<meta property="article:modified_time" content="${escapeHtml(card.modifiedAt)}" />` : ''}

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:url" content="${url}" />
    <meta name="twitter:title" content="${title}" />
    <meta name="twitter:description" content="${description}" />
    <meta name="twitter:image" content="${image}" />

    <meta http-equiv="refresh" content="0; url=${url}" />
  </head>
  <body>
    <p><a href="${url}">${title}</a></p>
  </body>
</html>
`
}

export default async function handler(req, res) {
  const { type, slug, id } = req.query ?? {}

  let card = null
  let canonicalUrl = SITE_URL

  try {
    if (type === 'blog' && slug) {
      canonicalUrl = `${SITE_URL}/blog/${slug}`
      card = await blogCard(slug)
    } else if (type === 'post' && id) {
      canonicalUrl = `${SITE_URL}/feed/${id}`
      card = await postCard(id)
    }
  } catch {
    card = null
  }

  // s-maxage keeps a hot link off the database on every re-scrape, but stays
  // short enough that fixing a typo in a post title shows up in new shares
  // within minutes rather than at the next deploy — the whole point of this
  // function.
  res.setHeader('Content-Type', 'text/html; charset=utf-8')
  res.setHeader('Cache-Control', 'public, s-maxage=300, stale-while-revalidate=86400')
  res.status(200).send(renderHtml(card ?? DEFAULT_CARD, canonicalUrl))
}
